namespace FMS_PDFReportService.Data.Queries.FmsDos;

public static class DosPhaseCheckQueries
{
    // SQL: EXTRACTED from cac.dmt:L80209 (LoadPhaseCheckEquip — standard feeder variant)
    // MUST validate against production Ingres schema
    public const string LoadPhaseChecksForFeeder = @"
        SELECT DISTINCT
               P.Card,
               O.Object AS Equip,
               O.Name AS EquipName,
               O.Type AS EquipClass,
               O.TypeName AS EquipClassName,
               G.Reference AS PrintID,
               OB.Object AS SPC_Equip,
               OB.Name AS SPC_EquipName,
               OB.Type AS SPC_EquipClass,
               OB.TypeName AS SPC_EquipClassName,
               GB.Reference AS SPC_PrintID,
               P.IssueTime,
               P.CompletionTime
        FROM   Udb_Object O,
               Udb_Object OB,
               Udb_Grouping G,
               Udb_Grouping GB,
               FMS_PhaseCheck P
        WHERE  G.Grouping IN ({0}) AND
               G.Relationship = 52 AND
               G.Member = O.Object AND
               P.PhaseCheckEquip = O.Object AND
               GB.Grouping IN ({0}) AND
               GB.Relationship = 52 AND
               GB.Member = OB.Object AND
               P.SatisfyEquip = OB.Object AND
               P.WorkPermit = ? AND
               P.Card IN ({1})
        ORDER BY PrintID, EquipName";

    // SQL: EXTRACTED from cac.dmt:L80154 (LoadPhaseCheckEquip — archive variant)
    // MUST validate against production Ingres schema
    public const string LoadPhaseChecksForFeederArchive = @"
        SELECT DISTINCT
               P.Card,
               O.Object AS Equip,
               O.Name AS EquipName,
               O.Type AS EquipClass,
               O.TypeName AS EquipClassName,
               G.Reference AS PrintID,
               OB.Object AS SPC_Equip,
               OB.Name AS SPC_EquipName,
               OB.Type AS SPC_EquipClass,
               OB.TypeName AS SPC_EquipClassName,
               GB.Reference AS SPC_PrintID,
               P.IssueTime,
               P.CompletionTime
        FROM   Udb_Object O,
               Udb_Object OB,
               Udb_Grouping G,
               Udb_Grouping GB,
               FMS_ArchivePhaseCheck P
        WHERE  G.Grouping = ? AND
               G.Relationship = 52 AND
               G.Member = O.Object AND
               P.PhaseCheckEquip = O.Object AND
               GB.Grouping = ? AND
               GB.Relationship = 52 AND
               GB.Member = OB.Object AND
               P.SatisfyEquip = OB.Object AND
               P.WorkPermit = ? AND
               P.Card = ?
        ORDER BY PrintID, EquipName";

    // SQL: EXTRACTED from cac.dmt:L80109 (LoadPhaseCheckEquip — 3G/network variant with dynamic WHERE)
    // MUST validate against production Ingres schema
    public const string LoadPhaseChecksNetwork = @"
        SELECT DISTINCT
               CTO.Card,
               O.Object AS Equip,
               O.Name AS EquipName,
               O.Type AS EquipClass,
               O.TypeName AS EquipClassName,
               '' AS PrintID,
               OB.Object AS SPC_Equip,
               OB.Name AS SPC_EquipName,
               OB.Type AS SPC_EquipClass,
               OB.TypeName AS SPC_EquipClassName,
               '' AS SPC_PrintID,
               P.IssueTime,
               P.CompletionTime
        FROM   Udb_Object O,
               Udb_Object OB,
               Udb_Grouping G,
               Udb_Grouping GB,
               FMS_PhaseCheck P,
               TFMS_CardToObject CTO,
               TFMS_CardToObject CTOB
        WHERE  CTO.Card IN ({0}) AND
               CTO.Object = G.Grouping AND
               G.Relationship = 52 AND
               G.Member = O.Object AND
               P.PhaseCheckEquip = O.Object AND
               CTOB.Card IN ({0}) AND
               CTOB.Object = GB.Grouping AND
               GB.Relationship = 52 AND
               GB.Member = OB.Object AND
               P.SatisfyEquip = OB.Object AND
               P.WorkPermit = ? AND
               P.Card IN ({0})
        ORDER BY EquipName";

    // PrintID sub-select for network cards (cac.dmt:L80131)
    public const string LoadPrintIdForEquip = @"
        SELECT IFNULL(MIN(G.Reference),'') AS PrintID
        FROM   Udb_Grouping G,
               TFMS_CardToObject CTO
        WHERE  G.Member = ? AND
               G.Relationship = 52 AND
               G.Grouping = CTO.Object AND
               CTO.Card = ?";

    // All outstanding: loads all active FMS cards with phase checks
    // SQL: INFERRED from cac.dmt pattern — queries FMS_PhaseCheck without card filter
    // MUST validate against production Ingres schema
    public const string LoadAllOutstandingPhaseChecks = @"
        SELECT DISTINCT
               P.Card,
               O.Object AS Equip,
               O.Name AS EquipName,
               O.Type AS EquipClass,
               O.TypeName AS EquipClassName,
               G.Reference AS PrintID,
               OB.Object AS SPC_Equip,
               OB.Name AS SPC_EquipName,
               OB.Type AS SPC_EquipClass,
               OB.TypeName AS SPC_EquipClassName,
               GB.Reference AS SPC_PrintID,
               P.IssueTime,
               P.CompletionTime
        FROM   Udb_Object O,
               Udb_Object OB,
               Udb_Grouping G,
               Udb_Grouping GB,
               FMS_PhaseCheck P
        WHERE  G.Grouping IN (
                   SELECT CTO.Object FROM TFMS_CardToObject CTO WHERE CTO.Card = P.Card
               ) AND
               G.Relationship = 52 AND
               G.Member = O.Object AND
               P.PhaseCheckEquip = O.Object AND
               P.CompletionTime = '' AND
               GB.Grouping IN (
                   SELECT CTO2.Object FROM TFMS_CardToObject CTO2 WHERE CTO2.Card = P.Card
               ) AND
               GB.Relationship = 52 AND
               GB.Member = OB.Object AND
               P.SatisfyEquip = OB.Object
        ORDER BY PrintID, EquipName";
}
