namespace FMS_PDFReportService.Data.Queries.FmsDos;

public static class DosRSMovesQueries
{
    // SQL: EXTRACTED from cac.dmt:L114439 (LoadOutstandingRSMoves, SpecialGrouping=TRUE)
    // — MUST validate against production Ingres schema
    public const string LoadFMSOutstandingRSMovesSpecial = @"
        SELECT  G.Grouping AS MoveEquipClass,
                C.FeederName AS MoveEquipClassName,
                C.Card,
                JC.Seq,
                J.Job,
                J.TOIssued,
                J.TOComplete,
                JC.PrintId,
                J.EquipClassName,
                J.EquipName,
                J.Grounds,
                J.TOMove,
                J.RSIssued,
                J.RSComplete
        FROM    FMS_CARD C,
                SOA_JOB J,
                TFMS_CardToObject CTO,
                SOA_JobControl JC,
                UDB_Grouping G
        WHERE   C.Status >= 20 AND C.Status < 50
                AND C.CutIn IS NOT NULL
                AND C.Card = JC.Card
                AND JC.StepPair IN (100, 150)
                AND JC.Job = J.Job
                AND J.JobClass <> 0
                AND J.Status = ''
                AND J.RSComplete IS NULL
                AND C.Card = CTO.Card
                AND CTO.Object = G.Member
                AND G.MemberType = 40
                AND G.Relationship = 52
                AND G.GroupingType = 10131
        ORDER BY MoveEquipClass, MoveEquipClassName, Seq";

    // SQL: EXTRACTED from cac.dmt:L114439 (LoadOutstandingRSMoves, SpecialGrouping=FALSE — Division)
    // — MUST validate against production Ingres schema
    public const string LoadFMSOutstandingRSMovesDivision = @"
        SELECT  G.Grouping AS MoveEquipClass,
                C.FeederName AS MoveEquipClassName,
                C.Card,
                JC.Seq,
                J.Job,
                J.TOIssued,
                J.TOComplete,
                JC.PrintId,
                J.EquipClassName,
                J.EquipName,
                J.Grounds,
                J.TOMove,
                J.RSIssued,
                J.RSComplete
        FROM    FMS_CARD C,
                SOA_JOB J,
                TFMS_CardToObject CTO,
                SOA_JobControl JC,
                UDB_Grouping G
        WHERE   C.Status >= 20 AND C.Status < 50
                AND C.CutIn IS NOT NULL
                AND C.Card = JC.Card
                AND JC.StepPair IN (100, 150)
                AND JC.Job = J.Job
                AND J.JobClass <> 0
                AND J.Status = ''
                AND J.RSComplete IS NULL
                AND C.Card = CTO.Card
                AND CTO.Object = G.Member
                AND G.MemberType = 40
                AND G.Relationship = 52
                AND G.GroupingType = 4
        ORDER BY MoveEquipClass, MoveEquipClassName, Seq";

    // SQL: EXTRACTED from soa.dmt:L19468 (TOMS Outstanding RS Moves)
    // — MUST validate against production Ingres schema
    public const string LoadTOMSOutstandingRSMoves = @"
        SELECT  AC.CardName AS MoveEquipClassName,
                AC.Card,
                J.Job,
                JC.Seq,
                J.TOIssued,
                J.TOComplete,
                JC.PrintId,
                J.EquipClassName,
                J.EquipName,
                J.Grounds,
                J.TOMove,
                J.RSIssued,
                J.RSComplete
        FROM    SOA_ActiveCard AC,
                SOA_Job J,
                SOA_Card C,
                SOA_JobControl JC
        WHERE   AC.Card = C.Card
                AND C.CutIn IS NOT NULL
                AND AC.Card = JC.Card
                AND JC.Job = J.Job
                AND J.MoveCategory = 0
                AND J.Status = ''
                AND J.RSComplete IS NULL
                AND J.TOComplete IS NOT NULL";

    // SQL: EXTRACTED from soa.dmt:L19468 (secondary query — division grouping per card)
    // — MUST validate against production Ingres schema
    public const string LoadTOMSRSMoveDivisions = @"
        SELECT  G.Grouping AS MoveEquipClass
        FROM    Udb_Grouping G,
                SOA_ActiveObject AO
        WHERE   AO.Card = @Card
                AND G.Member = AO.Object
                AND G.Relationship = 52
                AND G.GroupingType = 4
                AND G.MemberType IN (40, 10)";
}
