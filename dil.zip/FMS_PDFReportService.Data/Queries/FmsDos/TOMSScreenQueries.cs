namespace FMS_PDFReportService.Data.Queries.FmsDos;

/// <summary>
/// SQL queries for TOMS Information Items and Inactive Cards DOS screen reports.
/// </summary>
public static class TOMSScreenQueries
{
    // SQL: EXTRACTED from soa.dmt:L21789 (ReportInformationItems) — MUST validate against production Ingres schema
    // Active info items joined with equipment, category, job, and UDB objects
    public const string LoadInformationItems = @"
        SELECT  I.Job,
                I.Category,
                C.Name AS CategoryName,
                I.Severity,
                E.Division,
                O1.Name AS DivisionName,
                E.Substation,
                O2.Description AS SubstationName,
                J.TOIssued,
                J.RSComplete,
                I.Title,
                O3.TypeName + '  ' + O3.Name AS EquipmentChar
        FROM    SLC_InformationItem I,
                SLC_InformationItemEquip E,
                SLC_ItemCategory C,
                SOA_Job J,
                Udb_Object O1,
                Udb_Object O2,
                Udb_Object O3
        WHERE   I.Job = E.Job
            AND I.Category = C.Category
            AND I.Job = J.Job
            AND E.Substation = O2.Object
            AND E.Division = O1.Object
            AND E.Equip = O3.Object
            AND J.SwItemStatus = 20

        UNION

        SELECT  I.Job,
                I.Category,
                C.Name,
                I.Severity,
                E.Division,
                O1.Name,
                E.Substation,
                O2.Description,
                J.TOIssued,
                J.RSComplete,
                I.Title,
                O3.TypeName + '  ' + O3.Name
        FROM    SLC_ArchiveInfItem I,
                SLC_ArchiveInfItemEquip E,
                SLC_ItemCategory C,
                SOA_ArchiveJob J,
                Udb_Object O1,
                Udb_Object O2,
                Udb_Object O3
        WHERE   I.Job = E.Job
            AND I.Category = C.Category
            AND I.Job = J.Job
            AND E.Substation = O2.Object
            AND E.Division = O1.Object
            AND E.Equip = O3.Object

        ORDER BY 6, 8, 9 DESC";

    // SQL: EXTRACTED from soa.dmt:L21789 — filtered variant with division parameter
    public const string LoadInformationItemsByDivision = @"
        SELECT  I.Job,
                I.Category,
                C.Name AS CategoryName,
                I.Severity,
                E.Division,
                O1.Name AS DivisionName,
                E.Substation,
                O2.Description AS SubstationName,
                J.TOIssued,
                J.RSComplete,
                I.Title,
                O3.TypeName + '  ' + O3.Name AS EquipmentChar
        FROM    SLC_InformationItem I,
                SLC_InformationItemEquip E,
                SLC_ItemCategory C,
                SOA_Job J,
                Udb_Object O1,
                Udb_Object O2,
                Udb_Object O3
        WHERE   E.Division = @Division
            AND I.Job = E.Job
            AND I.Category = C.Category
            AND I.Job = J.Job
            AND E.Substation = O2.Object
            AND E.Division = O1.Object
            AND E.Equip = O3.Object
            AND J.SwItemStatus = 20

        UNION

        SELECT  I.Job,
                I.Category,
                C.Name,
                I.Severity,
                E.Division,
                O1.Name,
                E.Substation,
                O2.Description,
                J.TOIssued,
                J.RSComplete,
                I.Title,
                O3.TypeName + '  ' + O3.Name
        FROM    SLC_ArchiveInfItem I,
                SLC_ArchiveInfItemEquip E,
                SLC_ItemCategory C,
                SOA_ArchiveJob J,
                Udb_Object O1,
                Udb_Object O2,
                Udb_Object O3
        WHERE   E.Division = @Division
            AND I.Job = E.Job
            AND I.Category = C.Category
            AND I.Job = J.Job
            AND E.Substation = O2.Object
            AND E.Division = O1.Object
            AND E.Equip = O3.Object

        ORDER BY 6, 8, 9 DESC";

    // SQL: EXTRACTED from soa.dmt:L11520 (InactiveCardReview) — MUST validate against production Ingres schema
    // Loads active cards for TFMS/SLC applications in given divisions
    public const string LoadInactiveCards = @"
        SELECT  AC.Card,
                AC.Application,
                AC.CardName,
                C.Note
        FROM    SOA_ActiveCard AC,
                SOA_Card C
        WHERE   AC.Application IN ('TFMS', 'SLC')
            AND AC.Card = C.Card
            AND AC.Division IN ({0})";

    // SQL: EXTRACTED from soa.dmt:L11520 — get switching items for SLC cards
    public const string LoadInactiveCardSwitchingItems = @"
        SELECT  J.TOMove AS SwitchingItemName,
                J.Job AS SwitchingItem
        FROM    SOA_JobControl JC,
                SOA_Job J
        WHERE   JC.Card = @Card
            AND JC.Job = J.Job
            AND J.MoveCategory = 2
            AND J.ShadowLink = 0
            AND J.SwItemStatus = 20";

    // SQL: EXTRACTED from soa.dmt InactiveReviewLogSelect include — last activity time per card/item
    public const string LoadLastActivityTime = @"
        SELECT  MAX(Time) AS LastTime
        FROM    SOA_Log
        WHERE   Card = @Card
            AND SwitchingItem = @SwitchingItem";

    // SQL: EXTRACTED from soa.dmt:L11520 — inactivity period from system parameters
    public const string LoadInactivityPeriod = @"
        SELECT  SLCInactivityPeriods
        FROM    SLC_SystemParameters";
}
