namespace FMS_PDFReportService.Data.Queries.FmsDos;

/// <summary>
/// SQL queries for TOMS Milestone Summary DOS screen report.
/// SQL: EXTRACTED from cac.dmt:L224010 (Load_MilestoneData) — MUST validate against production Ingres schema
/// </summary>
public static class MilestoneQueries
{
    // SQL: EXTRACTED from cac.dmt:L224122 — main card select
    // Filter 1 = Active Out of Service (CutOut IS NOT NULL, CutIn IS NULL, Status < Card$Closed)
    // Filter 2 = Active InService (CutIn IS NOT NULL, Status < Card$Closed)
    // {0} = dynamic WHERE clause portion for filter, {1} = division IN list
    public const string LoadActiveCardsOutOfService = @"
        SELECT DISTINCT
               C.Card,
               AC.CardName,
               IFNULL(C.Cutout, '') AS Cutout,
               IFNULL(C.Cutin, '') AS Cutin,
               C.CardClass,
               C.CardClassName
        FROM   SOA_ActiveCard AC,
               SOA_Card C
        WHERE  C.CutOut IS NOT NULL
               AND C.Cutout <> ' '
               AND C.Cutin IS NULL
               AND C.Status < 50
               AND C.Card = AC.Card
               AND AC.TypeOfCard = 12003
               AND AC.Division IN ({0})
        ORDER BY AC.CardName";

    // SQL: EXTRACTED from cac.dmt:L224048 — Filter 2: Active InService
    public const string LoadActiveCardsInService = @"
        SELECT DISTINCT
               C.Card,
               AC.CardName,
               IFNULL(C.Cutout, '') AS Cutout,
               IFNULL(C.Cutin, '') AS Cutin,
               C.CardClass,
               C.CardClassName
        FROM   SOA_ActiveCard AC,
               SOA_Card C
        WHERE  C.CutIn IS NOT NULL
               AND C.CutIn <> ' '
               AND C.Status < 50
               AND C.Card = AC.Card
               AND AC.TypeOfCard = 12003
               AND AC.Division IN ({0})
        ORDER BY AC.CardName";

    // SQL: EXTRACTED from cac.dmt:L224146 — operating steps per card
    public const string LoadOperatingSteps = @"
        SELECT OS.Card,
               OS.OperatingStep,
               OS.OperatingStepName,
               OS.StartTime,
               OS.EndTime,
               OS.DurationMins
        FROM   TFMS_OperatingStep OS
        WHERE  OS.Card = @Card";
}
