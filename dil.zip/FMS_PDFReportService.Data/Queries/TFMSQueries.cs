namespace FMS_PDFReportService.Data.Queries
{
    /// <summary>
    /// SQL query constants for TFMS/TOMS card data retrieval.
    /// Ported from CardTFMS_ASE, Job_ASE, CardLogClass_ASE, WorkPermit_ASE.
    /// </summary>
    public static class TFMSQueries
    {
        public const string LoadCardHeader = @"
            SELECT C.Card, C.CardNumber, C.Description, C.FeederNames
            FROM   TFMS_Card C
            WHERE  C.Card = ?";

        public const string LoadCardHeaderArchive = @"
            SELECT C.Card, C.CardNumber, C.Description, C.FeederNames
            FROM   TFMS_ArchiveCard C
            WHERE  C.Card = ?";

        public const string LoadChecklist = @"
            SELECT CL.Card, CL.Desk,
                   CL.PermitsReturned, CL.GroundsRemoved,
                   CL.DisconnectsClosed, CL.HSGSReset,
                   CL.RelaySysNormal, CL.OilPresNormal,
                   CL.EquipCanBeEnerg, CL.EquipPrepForServ,
                   CL.CheckedStnLogCrd, CL.AmmeterClearPerf,
                   CL.AcceptanceLetter
            FROM   TFMS_CheckList CL
            WHERE  CL.Card = ?";

        public const string LoadChecklistArchive = @"
            SELECT CL.Card, CL.Desk,
                   CL.PermitsReturned, CL.GroundsRemoved,
                   CL.DisconnectsClosed, CL.HSGSReset,
                   CL.RelaySysNormal, CL.OilPresNormal,
                   CL.EquipCanBeEnerg, CL.EquipPrepForServ,
                   CL.CheckedStnLogCrd, CL.AmmeterClearPerf,
                   CL.AcceptanceLetter
            FROM   TFMS_ArchiveCheckList CL
            WHERE  CL.Card = ?";

        public const string LoadPrepBy = @"
            SELECT CP.Desk, O.Name AS DeskName,
                   CP.PreparedBy, CP.CheckedBy
            FROM   TFMS_CardPrepBy CP,
                   Udb_Object O
            WHERE  CP.Card = ? AND
                   CP.Desk = O.Object
            UNION
            SELECT CP.Desk, 'OldDataNoDesk' AS DeskName,
                   CP.PreparedBy, CP.CheckedBy
            FROM   TFMS_CardPrepBy CP
            WHERE  CP.Card = ? AND CP.Desk = 1";

        public const string LoadPrepByArchive = @"
            SELECT CP.Desk, O.Name AS DeskName,
                   CP.PreparedBy, CP.CheckedBy
            FROM   TFMS_ArchiveCardPrepBy CP,
                   Udb_Object O
            WHERE  CP.Card = ? AND
                   CP.Desk = O.Object
            UNION
            SELECT CP.Desk, 'OldDataNoDesk' AS DeskName,
                   CP.PreparedBy, CP.CheckedBy
            FROM   TFMS_ArchiveCardPrepBy CP
            WHERE  CP.Card = ? AND CP.Desk = 1";

        public const string LoadCardObjects = @"
            SELECT CTO.Object, CTO.Name, CTO.Status AS ObjectStatus, CTO.ValidatedBy,
                   O.Type AS ObjectType, O.TypeName
            FROM   TFMS_CardToObject CTO,
                   Udb_Object O
            WHERE  CTO.Card = ? AND
                   CTO.Object = O.Object";

        public const string LoadCardObjectsArchive = @"
            SELECT CTO.Object, CTO.Name, CTO.Status AS ObjectStatus, CTO.ValidatedBy,
                   O.Type AS ObjectType, O.TypeName
            FROM   TFMS_ArchiveCardToObject CTO,
                   Udb_Object O
            WHERE  CTO.Card = ? AND
                   CTO.Object = O.Object";

        public const string LoadJobs = @"
            SELECT J.Job, SJ.Card, SJ.Seq,
                   J.Status, J.JobClass,
                   J.Equip, J.EquipClass, J.EquipClassName, J.EquipName,
                   SJ.StepPair, J.Grounds, J.MoveType,
                   J.TOMove, J.TOMoveRules, J.TOOperator, J.TOIssued, J.TOComplete,
                   J.GroundOn,
                   J.RSMove, J.RSMoveRules, J.RSOperator, J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   SJ.MoveEquipClass,
                   J.Substation, O.Name AS SubstationName,
                   O.PrimaryGroupingName, O.Type AS StructureType,
                   J.ShadowLink, J.MoveCategory,
                   SJ.StepLevel, J.ControlCard,
                   J.MoveFGColor, J.MoveBGColor, J.DeskName
            FROM   SOA_Job J,
                   SOA_JobControl SJ,
                   Udb_Object O
            WHERE  SJ.Card = ? AND
                   SJ.Job = J.Job AND
                   J.Substation = O.Object AND
                   J.Status <> 'Del'
            ORDER BY SJ.StepPair, SJ.StepLevel, SJ.Seq";

        public const string LoadJobsArchive = @"
            SELECT J.Job, J.Card, J.Seq,
                   J.Status, J.JobClass,
                   J.Equip, J.EquipClass, J.EquipClassName, J.EquipName,
                   J.StepPair, J.MoveType,
                   J.TOMove, J.TOOperator, J.TOIssued, J.TOComplete,
                   J.RSMove, J.RSOperator, J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   J.Substation, J.MoveCategory, J.StepLevel,
                   J.MoveFGColor, J.MoveBGColor,
                   0 AS Grounds, ? AS ControlCard
            FROM   SOA_ArchiveJob J
            WHERE  J.Card = ? AND
                   J.Status <> 'Del'
            ORDER BY J.StepPair, J.StepLevel, J.Seq";

        public const string LoadCardLog = @"
            SELECT CL.Card, CL.SwitchingItem, CL.Log,
                   CL.LogStatus, CL.LogTime,
                   CL.EnteredBy, O.Description AS EnteredByName
            FROM   SOA_CardLog CL,
                   Udb_Object O
            WHERE  CL.Card = ? AND
                   CL.EnteredBy = O.Object
            ORDER BY CL.LogTime DESC";

        public const string LoadCardLogArchive = @"
            SELECT CL.Card, CL.SwitchingItem, CL.Log,
                   CL.LogStatus, CL.LogTime,
                   CL.EnteredBy, O.Description AS EnteredByName
            FROM   SOA_ArchiveCardLog CL,
                   Udb_Object O
            WHERE  CL.Card = ? AND
                   CL.EnteredBy = O.Object
            ORDER BY CL.LogTime DESC";

        public const string LoadWorkPermits = @"
            SELECT 1 AS CardType, 'TOMS' AS CardTypeName,
                   '' AS CardName, '' AS CardStatus,
                   J.Job, J.Status, J.JobClass,
                   JC.Card, JC.Seq,
                   J.Equip, J.EquipClass, J.EquipClassName,
                   JC.MoveEquipClass, JC.PrintID,
                   J.EquipName,
                   '' AS Subsordesk,
                   J.Substation,
                   JC.StepPair, J.MoveType,
                   J.TOMove, J.TOMoveRules, J.TOOperator,
                   J.TOIssued, J.TOComplete,
                   J.RSMove, J.RSMoveRules, J.RSOperator,
                   J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   J.MoveFGColor,
                   1 AS IsWorkPermit
            FROM   SOA_Job J,
                   SOA_JobControl JC
            WHERE  JC.Card = ? AND
                   JC.Job = J.Job AND
                   J.Status IN ('', 'OPC') AND
                   JC.StepPair = 3 AND
                   J.JobClass <> 0
            ORDER BY JC.Seq";

        public const string LoadWorkPermitsArchive = @"
            SELECT 1 AS CardType, 'TOMS' AS CardTypeName,
                   '' AS CardName, 'Cls' AS CardStatus,
                   J.Job, J.Status, J.JobClass,
                   J.Card, J.Seq,
                   J.Equip, J.EquipClass, J.EquipClassName,
                   0 AS MoveEquipClass, J.PrintID,
                   J.EquipName,
                   '' AS Subsordesk,
                   J.Substation,
                   J.StepPair, J.MoveType,
                   J.TOMove, '' AS TOMoveRules, J.TOOperator,
                   J.TOIssued, J.TOComplete,
                   J.RSMove, '' AS RSMoveRules, J.RSOperator,
                   J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   J.MoveFGColor,
                   1 AS IsWorkPermit
            FROM   SOA_ArchiveJob J
            WHERE  J.Card = ? AND
                   J.Status <> 'Del' AND
                   J.StepPair = 3 AND
                   J.JobClass <> 0
            ORDER BY J.Seq";
    }
}
