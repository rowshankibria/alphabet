namespace FMS_PDFReportService.Data.Queries
{
    /// <summary>
    /// SQL for the shared UDB type dictionary, used by the UDB Type Hierarchy report.
    /// Both tables are small (~2k types / ~3.6k edges), so the tree is assembled in memory
    /// rather than with a recursive query.
    /// </summary>
    public static class UDBQueries
    {
        public const string LoadTypes = @"
            SELECT T.Type, T.BaseType, T.Name, T.Description
            FROM   Udb_Type T";

        public const string LoadSuperTypes = @"
            SELECT S.Type, S.SuperType
            FROM   Udb_SuperType S";
    }
}
