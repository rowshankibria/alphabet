namespace FMS_PDFReportService.Data.Queries
{
    /// <summary>
    /// SQL query constants for ISWP (In-Service Work Permit) data retrieval.
    /// Ported from InServicePermit_ASE via OpenROAD procedure calls.
    /// </summary>
    public static class ISWPQueries
    {
        public const string LoadPermitDetail = @"
            SELECT P.ISPermit AS PermitId, P.Job, P.Substation,
                   O.Name AS SubstationName,
                   P.ObjectName, P.CurrentStatus AS Status, P.WorkGroup,
                   P.PermitMove, P.PreIssued, P.ShiftStartTime,
                   P.Application, '' AS Description
            FROM   SOA_InServicePermit P,
                   Udb_Object O
            WHERE  P.ISPermit = ? AND
                   P.Substation = O.Object";

        public const string LoadRequestDetail = @"
            SELECT R.ISPermit AS PermitId,
                   P.CurrentStatus AS Status,
                   R.PermitMove,
                   R.relaycaldetail AS RelayCalibrationDetail,
                   R.alarmcktdetail AS AlarmCircuitsDetail,
                   R.equipandduration AS Duration,
                   R.removectrlfeed AS ControlFeedRemove,
                   R.ctrlfeedequip AS ControlFeedEquipment,
                   R.asbaffectequip AS AsbestosEquipment,
                   R.asbestoswork AS AsbestosDescription,
                   R.gndlevelwork AS GroundLevelWork,
                   R.remark AS Remarks
            FROM   SOA_ISPermitRequest R,
                   SOA_InServicePermit P
            WHERE  R.ISPermit = ? AND
                   R.ISPermit = P.ISPermit";

        public const string LoadEquipment = @"
            SELECT E.PrimaryEquip, E.TypeName, E.Name
            FROM   IR_OpOrderFeeders E
            WHERE  E.ISPermit = ?";

        public const string LoadConditions = @"
            SELECT C.JobClass, C.MoveText
            FROM   SOA_ISPCondition C
            WHERE  C.ISPermit = ?
            ORDER BY C.JobClass";

        public const string LoadPermitLog = @"
            SELECT L.LogTime, O.Description AS LogUpdateByName, L.LogText
            FROM   SOA_ISPLog L,
                   Udb_Object O
            WHERE  L.ISPermit = ? AND
                   L.LogUpdateBy = O.Object AND
                   L.LogType IN (0, 2)
            ORDER BY L.LogTime DESC";

        public const string LoadRequestLog = @"
            SELECT L.LogTime, O.Description AS LogUpdateByName, L.LogText
            FROM   SOA_ISPLog L,
                   Udb_Object O
            WHERE  L.ISPermit = ? AND
                   L.LogUpdateBy = O.Object AND
                   L.LogType IN (1, 2)
            ORDER BY L.LogTime DESC";
    }
}
