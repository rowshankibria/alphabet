namespace FMS_PDFReportService.Data.Queries
{
    /// <summary>
    /// SQL query constants for DSO (Dielectric Switching Order) card data retrieval.
    /// Ported from CardDSO_ASE, Job_ASE.
    /// </summary>
    public static class DSOQueries
    {
        public const string LoadCardHeader = @"
            SELECT DC.Card, DC.CCNumber, DC.OpNumber,
                   DC.CardClass, DC.CardClassName,
                   DC.Status, DC.ScopeofWork,
                   DC.Opened, DC.Activated, DC.Closed,
                   DC.FeederNames,
                   DC.PreparedBy, DC.CheckedBy,
                   DC.CheckedBy2, DC.TemplateName
            FROM   DSO_Card DC
            WHERE  DC.Card = ?";

        public const string LoadCardObjects = @"
            SELECT CTO.Object, CTO.Type, CTO.Name
            FROM   TFMS_CardToObject CTO
            WHERE  CTO.Card = ?
            ORDER BY CTO.Name";

        public const string LoadIsEmergency = @"
            SELECT 1
            FROM   FMS_ObjectStatus OS
            WHERE  OS.Object = ? AND
                   OS.Status = 10050";

        public const string LoadLastEditTime = @"
            SELECT MAX(Time)
            FROM   SOA_Log
            WHERE  Card = ?";

        public const string LoadJobs = @"
            SELECT J.Job, SJ.Card, SJ.Seq,
                   J.Status, J.JobClass,
                   J.Equip, J.EquipClass, J.EquipClassName, J.EquipName,
                   SJ.StepPair, J.Grounds, J.MoveType,
                   J.TOMove, J.TOMoveRules, J.TOOperator, J.TOIssued, J.TOComplete,
                   J.GroundOn,
                   J.RSMove, J.RSMoveRules, J.RSOperator, J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   SJ.MoveEquipClass,
                   J.Substation, O.Name AS SubstationName,
                   J.MoveCategory, SJ.StepLevel, J.ControlCard,
                   J.MoveFGColor, J.MoveBGColor
            FROM   SOA_Job J,
                   SOA_JobControl SJ,
                   Udb_Object O
            WHERE  SJ.Card = ? AND
                   SJ.Job = J.Job AND
                   J.Substation = O.Object AND
                   J.Status <> 'Del'
            ORDER BY SJ.Seq";

        public const string LoadCardLog = @"
            SELECT CL.Card, 0 AS SwitchingItem, CL.Log,
                   CL.LogStatus, CL.LogTime,
                   CL.EnteredBy, O.Description AS EnteredByName
            FROM   SOA_CardLog CL,
                   Udb_Object O
            WHERE  CL.Card = ? AND
                   CL.EnteredBy = O.Object
            ORDER BY CL.LogTime DESC";

        public const string LoadCardLogArchive = @"
            SELECT CL.Card, 0 AS SwitchingItem, CL.Log,
                   CL.LogStatus, CL.LogTime,
                   CL.EnteredBy, O.Description AS EnteredByName
            FROM   SOA_ArchiveCardLog CL,
                   Udb_Object O
            WHERE  CL.Card = ? AND
                   CL.EnteredBy = O.Object
            ORDER BY CL.LogTime DESC";

        // From OpenROAD fms_online.dmt LoadDeletedCards — cards closed since last check
        public const string GetDeletedCards = @"
            SELECT DISTINCT C.Card, C.FeederNames
            FROM   DSO_Card C,
                   SOA_Log L
            WHERE  L.Time > @LastCheck
            AND    L.Card = C.Card
            AND    C.Status = 50
            AND    C.Closed > @LastCheck
            ORDER BY C.FeederNames";

        // From OpenROAD fms_online.dmt LoadUpdatedCards — active cards modified since last check
        public const string GetUpdatedCards = @"
            SELECT DISTINCT C.Card, C.FeederNames
            FROM   DSO_Card C,
                   SOA_Log L
            WHERE  L.Time > @LastCheck
            AND    L.Card = C.Card
            AND    C.Status <> 50
            ORDER BY C.FeederNames";

        // :LastCheck sentinel — reads last check timestamp from SOA_Log
        public const string GetLastCheckTimestamp = @"
            SELECT IFNULL(MAX(L.Time), @DefaultLookback)
            FROM   SOA_Log L
            WHERE  L.Time > @DefaultLookback
            AND    L.Card = -13
            AND    L.SwitchingItem = 0
            AND    LOWERCASE(L.Item) = @ItemName";

        // :LastCheck sentinel — records new check timestamp in SOA_Log.
        // Uses legacy stored proc SOA_LogInsert which atomically allocates a fresh
        // RowKey from SOA_LogLastKey — direct INSERT collides on unique index soa_log$1.
        public const string RecordCheckTimestamp = @"
            EXECUTE PROCEDURE SOA_LogInsert (
                Card = -13,
                SwitchingItem = 0,
                Job = NULL,
                Item = ?,
                Old = ?,
                New = ?,
                Time = DATE('now'),
                UserName = 'dso_reportmonitor')";
    }
}
