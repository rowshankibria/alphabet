namespace FMS_PDFReportService.Data.Queries
{
    /// <summary>
    /// SQL query constants for FMS card data retrieval.
    /// Ported from FMS_Card_ASE, Job_ASE, and related legacy ASE classes.
    /// All use ODBC ? parameter placeholders.
    /// </summary>
    public static class FMSQueries
    {
        public const string LoadCardHeader = @"
            SELECT C.Card, C.Activated, C.SubstationName, C.TypeOfCard,
                   C.Feeder, C.FeederName, C.FeederStatus, C.FeederStatusName,
                   C.Status, C.CardClass, C.CardClassName, C.Position,
                   C.StationGround, C.GroundsOn, C.DeadMoves, C.DeadMovesTO,
                   C.Loop1, C.Loop2, C.Loop3, C.Loop4,
                   C.Assoc, C.Relays, C.Notifications, C.Validated,
                   C.CutOut, C.CutIn, C.OpenAutoPlus, C.PhaseChecks,
                   C.EstTimeInService, C.EstTimeComplete, C.ActTimeComplete,
                   C.WorkpermitFlag, C.XferFlag, C.NotifyFlag,
                   C.ProcessAutoExecution, C.Closed, C.NetworkFeeder, C.TV_Bogey
            FROM   FMS_Card C
            WHERE  C.Card = ?";

        public const string LoadCardHeaderArchive = @"
            SELECT C.Card, C.Activated, C.SubstationName, C.TypeOfCard,
                   C.Feeder, C.FeederName, C.FeederStatus, C.FeederStatusName,
                   C.Status, C.CardClass, C.CardClassName, C.Position,
                   C.StationGround, C.GroundsOn, C.DeadMoves, C.DeadMovesTO,
                   C.Loop1, C.Loop2, C.Loop3, C.Loop4,
                   C.Assoc, C.Relays, C.Notifications, C.Validated,
                   C.CutOut, C.CutIn, C.OpenAutoPlus, C.PhaseChecks,
                   C.EstTimeInService, C.EstTimeComplete, C.ActTimeComplete,
                   C.WorkpermitFlag, 0 AS XferFlag, C.NotifyFlag,
                   0 AS ProcessAutoExecution, C.Closed, C.NetworkFeeder, C.TV_Bogey
            FROM   FMS_ArchiveCard C
            WHERE  C.Card = ?";

        public const string LoadJobs = @"
            SELECT J.Job, J.Status, J.JobClass,
                   SJ.Card, SJ.Seq,
                   J.Equip, J.EquipClass, SJ.MoveEquipClass,
                   J.EquipClassName, SJ.PrintID,
                   J.EquipName, SJ.StepPair,
                   J.Grounds, J.MoveType,
                   J.TOMove, J.TOOperator, J.TOIssued, J.TOComplete,
                   J.GroundOn,
                   J.RSMove, J.RSOperator, J.RSIssued, J.RSComplete,
                   J.TOMoveRules, J.RSMoveRules,
                   J.Response, J.MoveFGColor, J.MoveBGColor,
                   J.ControlCard, J.Substation,
                   J.MoveCategory, J.ActivityIdentifier
            FROM   SOA_JobControl SJ,
                   SOA_Job J
            WHERE  SJ.Card = ? AND
                   SJ.Job = J.Job AND
                   J.Status <> 'Del' AND
                   J.Status <> 'Hid'
            ORDER BY SJ.Seq";

        public const string LoadJobsArchive = @"
            SELECT J.Job, J.Status, J.JobClass,
                   J.Card, J.Seq,
                   J.Equip, J.MoveEquipClass, J.EquipClass,
                   J.EquipClassName, J.PrintID,
                   J.EquipName, J.StepPair,
                   J.G AS Grounds, J.MoveType,
                   J.TOMove, J.TOOperator, J.TOIssued, J.TOComplete,
                   J.GroundOn,
                   J.RSMove, J.RSOperator, J.RSIssued, J.RSComplete,
                   J.TOMoveRules, J.RSMoveRules,
                   J.Response, J.Colors AS MoveFGColor, 0 AS MoveBGColor,
                   J.Card AS ControlCard, 0 AS Substation,
                   0 AS MoveCategory, J.MoveOrigin AS ActivityIdentifier
            FROM   FMS_ArchiveJob J
            WHERE  J.Card = ? AND
                   J.Status <> 'Del' AND
                   J.Status <> 'Hid'
            ORDER BY J.Seq";

        public const string LoadCardNote = @"
            SELECT Note AS NoteText, ShowNoteFlag
            FROM   SOA_Card
            WHERE  Card = ?";

        public const string LoadNetworkObjects = @"
            SELECT CTO.Object, CTO.Type, CTO.Name, O.ValidatedBy
            FROM   TFMS_CardToObject CTO,
                   Udb_Object O
            WHERE  CTO.Card = ? AND
                   CTO.Object = O.Object";

        public const string LoadNetworkObjectsArchive = @"
            SELECT Object, Type, Name, '' AS ValidatedBy
            FROM   TFMS_ArchiveCardToObject
            WHERE  Card = ?";

        public const string LoadOperatingStep = @"
            SELECT OS.OperatingStepName, OS.StartTime
            FROM   FMS_OperatingStepStatus OS
            WHERE  OS.Card = ? AND
                   OS.EndTime = '' AND
                   OS.OperatingStep <> 0 AND
                   OS.StartTime = (
                       SELECT MAX(OS2.StartTime)
                       FROM   FMS_OperatingStepStatus OS2,
                              Udb_SuperType S
                       WHERE  OS2.Card = ? AND
                              OS2.EndTime = '' AND
                              OS2.OperatingStep <> 0 AND
                              OS2.OperatingStep = S.Type AND
                              S.SuperType = 10028
                   )";

        public const string LoadCurrentDelay = @"
            SELECT OS.OperatingStepName, OS.StartTime
            FROM   FMS_OperatingStepStatus OS
            WHERE  OS.Card = ? AND
                   OS.EndTime = '' AND
                   OS.OperatingStep <> 0 AND
                   OS.StartTime = (
                       SELECT MAX(OS2.StartTime)
                       FROM   FMS_OperatingStepStatus OS2,
                              Udb_SuperType S
                       WHERE  OS2.Card = ? AND
                              OS2.EndTime = '' AND
                              OS2.OperatingStep <> 0 AND
                              OS2.OperatingStep = S.Type AND
                              S.SuperType = 10029
                   )";

        public const string LoadChecklist = @"
            SELECT CL.Card, CL.VerifyPrint, CL.RequiredPaperwork,
                   CL.NewEquipment, CL.RFPSubmitted, CL.ProtectionLinked,
                   CL.TCContinuity, CL.TagsLinked
            FROM   FMS_CheckList CL
            WHERE  CL.Card = ?";

        public const string LoadFeederLog = @"
            SELECT FL.Card, FL.Log, FL.LogStatus, FL.LogTime,
                   FL.EnteredBy, O.Description AS EnteredByName
            FROM   FMS_FeederLog FL,
                   Udb_Object O
            WHERE  FL.Card = ? AND
                   FL.EnteredBy = O.Object
            ORDER BY FL.LogTime DESC";

        public const string LoadFeederLogArchive = @"
            SELECT FL.Card, FL.Log, FL.LogStatus, FL.LogTime,
                   FL.EnteredBy, O.Description AS EnteredByName
            FROM   FMS_ArchiveFeederLog FL,
                   Udb_Object O
            WHERE  FL.Card = ? AND
                   FL.EnteredBy = O.Object
            ORDER BY FL.LogTime DESC";

        public const string LoadWorkPermits = @"
            SELECT 0 AS CardType, 'FMS' AS CardTypeName,
                   C.FeederName AS CardName, '' AS CardStatus,
                   J.Job, J.Status, J.JobClass,
                   JC.Card, JC.Seq,
                   J.Equip, J.EquipClass, J.EquipClassName,
                   JC.MoveEquipClass, JC.PrintID,
                   J.EquipName,
                   C.SubstationName AS Subsordesk,
                   J.Substation,
                   JC.StepPair, J.MoveType,
                   J.TOMove, J.TOMoveRules, J.TOOperator,
                   J.TOIssued, J.TOComplete,
                   J.RSMove, J.RSMoveRules, J.RSOperator,
                   J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   J.MoveFGColor,
                   1 AS IsWorkPermit
            FROM   SOA_Job J,
                   SOA_JobControl JC,
                   FMS_Card C,
                   FMS_WorkPermit WP
            WHERE  C.Card = ? AND
                   JC.Card = C.Card AND
                   JC.Job = J.Job AND
                   WP.PermitJobID = J.Job AND   -- DOS cac.dmt L105443 — restricts jobs to registered permits, removes duplicates
                   J.Status = '' AND            -- DOS cac.dmt L105406 non-IncludeHidden branch
                   JC.StepPair = 600 AND        -- StepHeading$OTW (verified: db-scripts/IR/ir_fcr_dbprocedures.sql, FMS Merge Design Note)
                   J.JobClass <> 0
            ORDER BY JC.Seq";

        public const string LoadWorkPermitsArchive = @"
            SELECT 0 AS CardType, 'FMS' AS CardTypeName,
                   C.FeederName AS CardName, 'Cls' AS CardStatus,
                   J.Job, J.Status, J.JobClass,
                   J.Card, J.Seq,
                   J.Equip, J.EquipClass, J.EquipClassName,
                   J.MoveEquipClass, J.PrintID,
                   J.EquipName,
                   C.SubstationName AS Subsordesk,
                   0 AS Substation,
                   J.StepPair, J.MoveType,
                   J.TOMove, '' AS TOMoveRules, J.TOOperator,
                   J.TOIssued, J.TOComplete,
                   J.RSMove, '' AS RSMoveRules, J.RSOperator,
                   J.RSIssued, J.RSComplete,
                   J.Response, J.MoveOrigin AS ActivityIdentifier,
                   J.Colors AS MoveFGColor,
                   1 AS IsWorkPermit
            FROM   FMS_ArchiveJob J,
                   FMS_ArchiveCard C
            WHERE  C.Card = ? AND
                   J.Card = C.Card AND
                   J.Status <> 'Del' AND
                   J.StepPair = 600 AND   -- StepHeading$OTW (verified: deliverables/ASE_SQL_Queries_Card_Printing.md §6.4)
                   J.JobClass <> 0
            ORDER BY J.Seq";

        // === Protection queries — ported from cac_include_scripts.dmt LoadProtectionMove (L3383-L3757)
        // and cac.dmt WorkPermit_ASE.LoadWorkPermits protection-links block (L247669-L247696 live, L247906-L247935 archive).
        // Constant values verified in FMS_DatabaseService/Business/Constant.vb: Type$TLSApp=15001,
        // Card$Open=10, Card$Closed=50, MoveCategory$Fake=-99, JobStatus$NIS='NIS'.

        // Protection-link table (live). PermitCardType=0 avoids conflicts with TLS Job IDs (per DOS comment).
        public const string LoadProtectionLinks = @"
            SELECT PermitCardType    AS PermitCardType,
                   PermitJobID       AS PermitJobID,
                   PermitCard        AS PermitCard,
                   ProtectionCardType AS ProtectionCardType,
                   ProtectionJobID   AS ProtectionJobID,
                   ProtectionCard    AS ProtectionCard,
                   PrePost           AS PrePost,
                   Seq               AS Seq
            FROM   FMS_WorkPermitProtection
            WHERE  PermitJobID = ? AND
                   PermitCardType = 0
            ORDER BY Seq";

        // Protection-link table (archive) — archive rows have no PrePost/Seq columns per DOS L247919-L247931.
        public const string LoadProtectionLinksArchive = @"
            SELECT PermitCardType    AS PermitCardType,
                   PermitJobID       AS PermitJobID,
                   PermitCard        AS PermitCard,
                   ProtectionCardType AS ProtectionCardType,
                   ProtectionJobID   AS ProtectionJobID,
                   ProtectionCard    AS ProtectionCard
            FROM   FMS_ArchiveWPProtection
            WHERE  PermitJobID = ? AND
                   PermitCardType = 0";

        // Cascade source 1: active card in SOA_ActiveCard (cross-application view: FMS/TFMS/SLC/DSO/SDS).
        // C.Application is the FMS/TFMS/SLC/DSO/SDS discriminator; MoveCategory triggers the Fake→Bnk post-hook.
        public const string LoadProtectionMove_Active = @"
            SELECT C.Application     AS CardTypeName,
                   C.CardName        AS CardName,
                   O.Name            AS SubstationName,
                   JC.PrintID        AS PrintID,
                   J.EquipClassName  AS EquipClassName,
                   J.EquipName       AS EquipName,
                   J.TOMove          AS TOMove,
                   J.TOIssued        AS TOIssued,
                   J.TOComplete      AS TOComplete,
                   J.RSIssued        AS RSIssued,
                   J.RSComplete      AS RSComplete,
                   J.MoveCategory    AS MoveCategory,
                   JC.Card           AS Card
            FROM   SOA_Job J,
                   SOA_JobControl JC,
                   SOA_ActiveCard C,
                   UDB_Object O
            WHERE  J.Job = ? AND
                   J.Status IN ('', 'NIS') AND
                   J.SwItemStatus < 50 AND
                   J.ControlCard = C.Card AND
                   C.Card = JC.Card AND
                   JC.Job = J.Job AND
                   J.Substation = O.Object";

        // Cascade source 2: open card (SOA_Card WHERE Status=Card$Open=10). SOA_Card has no CardName —
        // caller looks it up separately from FMS_Card or TFMS_Card via the two constants below.
        public const string LoadProtectionMove_Open = @"
            SELECT C.Application     AS CardTypeName,
                   ''                AS CardName,
                   O.Name            AS SubstationName,
                   JC.PrintID        AS PrintID,
                   J.EquipClassName  AS EquipClassName,
                   J.EquipName       AS EquipName,
                   J.TOMove          AS TOMove,
                   J.TOIssued        AS TOIssued,
                   J.TOComplete      AS TOComplete,
                   J.RSIssued        AS RSIssued,
                   J.RSComplete      AS RSComplete,
                   0                 AS MoveCategory,
                   JC.Card           AS Card
            FROM   SOA_Job J,
                   SOA_JobControl JC,
                   SOA_Card C,
                   UDB_Object O
            WHERE  J.Job = ? AND
                   J.Status IN ('', 'NIS') AND
                   J.SwItemStatus < 50 AND
                   J.ControlCard = C.Card AND
                   C.Status = 10 AND
                   C.Card = JC.Card AND
                   JC.Job = J.Job AND
                   J.Substation = O.Object";

        public const string LoadOpenCardFmsName = @"
            SELECT FeederName FROM FMS_Card WHERE Card = ?";

        public const string LoadOpenCardTfmsName = @"
            SELECT FeederNames FROM TFMS_Card WHERE Card = ?";

        // Cascade source 3: New/Drop Bank. SOA_Job only — no JC, no C, no O. Subsordesk from J.DeskName.
        public const string LoadProtectionMove_Bank = @"
            SELECT J.EquipClassName  AS EquipClassName,
                   J.EquipName       AS EquipName,
                   J.TOMove          AS TOMove,
                   J.TOIssued        AS TOIssued,
                   J.TOComplete      AS TOComplete,
                   J.RSIssued        AS RSIssued,
                   J.RSComplete      AS RSComplete,
                   J.DeskName        AS SubstationName
            FROM   SOA_Job J
            WHERE  J.Job = ? AND
                   J.Status IN ('', 'NIS') AND
                   J.SwItemStatus < 50";

        // Cascade source 4: archived FMS. FMS_ArchiveJob has its own PrintID column (unlike Sources 5/6).
        public const string LoadProtectionMove_ArchiveFms = @"
            SELECT C.FeederName      AS CardName,
                   J.PrintID         AS PrintID,
                   J.EquipClassName  AS EquipClassName,
                   J.EquipName       AS EquipName,
                   J.TOMove          AS TOMove,
                   J.TOIssued        AS TOIssued,
                   J.TOComplete      AS TOComplete,
                   J.RSIssued        AS RSIssued,
                   J.RSComplete      AS RSComplete
            FROM   FMS_ArchiveJob J,
                   FMS_ArchiveCard C
            WHERE  C.Card = J.Card AND
                   J.Job = ? AND
                   J.Status IN ('', 'NIS')";

        // Cascade source 5: archived SLC. DOS quirk (L3676-L3705): PrintID column is not selected here.
        public const string LoadProtectionMove_ArchiveSlc = @"
            SELECT C.CardName        AS CardName,
                   O.Name            AS SubstationName,
                   J.EquipClassName  AS EquipClassName,
                   J.EquipName       AS EquipName,
                   J.TOMove          AS TOMove,
                   J.TOIssued        AS TOIssued,
                   J.TOComplete      AS TOComplete,
                   J.RSIssued        AS RSIssued,
                   J.RSComplete      AS RSComplete
            FROM   SOA_ArchiveJob J,
                   SOA_ActiveCard C,
                   UDB_Object O
            WHERE  C.Application = 'SLC' AND
                   C.Card = J.Card AND
                   J.Status IN ('', 'NIS') AND
                   J.Job = ? AND
                   J.Substation = O.Object";

        // Cascade source 6: archived TFMS. Same DOS PrintID quirk as source 5.
        public const string LoadProtectionMove_ArchiveTfms = @"
            SELECT C.FeederNames     AS CardName,
                   O.Name            AS SubstationName,
                   J.EquipClassName  AS EquipClassName,
                   J.EquipName       AS EquipName,
                   J.TOMove          AS TOMove,
                   J.TOIssued        AS TOIssued,
                   J.TOComplete      AS TOComplete,
                   J.RSIssued        AS RSIssued,
                   J.RSComplete      AS RSComplete
            FROM   SOA_ArchiveJob J,
                   TFMS_ArchiveCard C,
                   UDB_Object O
            WHERE  C.Card = J.Card AND
                   J.Job = ? AND
                   J.Status IN ('', 'NIS') AND
                   J.Substation = O.Object";

        // TLS branch — taken when ProtectionCardType = Type$TLSApp (15001). Union of live TC_Job + archived TC_ArchiveJob.
        // TC_Card.Status < 4 = TLS "not closed" (TC_Card_Closed=4). TC_ArchiveJob rows are always considered 'Cls'.
        // Neither TLS source has PrintID / EquipClassName / EquipName columns per DOS L3413-L3474.
        public const string LoadProtectionMove_Tls = @"
            SELECT J.LineNumber      AS CardName,
                   J.SubstationName  AS SubstationName,
                   J.TOMove          AS TOMove,
                   J.TOIssued        AS TOIssued,
                   J.TOComplete      AS TOComplete,
                   J.RSIssued        AS RSIssued,
                   J.RSComplete      AS RSComplete,
                   ''                AS CardStatus
            FROM   TC_Job J,
                   TC_Card C
            WHERE  C.Card = ? AND
                   C.Status < 4 AND
                   C.Card = J.Card AND
                   J.Job = ? AND
                   J.Status IN ('', 'NIS')
            UNION
            SELECT J.LineNumber,
                   J.SubstationName,
                   J.TOMove,
                   J.TOIssued,
                   J.TOComplete,
                   J.RSIssued,
                   J.RSComplete,
                   'Cls'
            FROM   TC_ArchiveJob J,
                   TC_ArchiveCard C
            WHERE  C.Card = ? AND
                   C.Card = J.Card AND
                   J.Job = ? AND
                   J.Status IN ('', 'NIS')";

        public const string LoadProtectionRequired = @"
            SELECT ProtectionRequired
            FROM   FMS_WorkPermit
            WHERE  PermitJobId = ?";

        // Ported from cac.dmt METHOD LoadPhaseCheckEquip (L80204-L80238) — regular-FMS branch only.
        // NOT PORTED YET: NetworkFeeder>0 (3G/33kV) branch, TypeOfCard=4kV branch, StepDown card-list expansion.
        // Those cards will silently under-report phase checks until B2.1.
        // Relationship=52 is Interaction$MemberOf (Constant.vb:154). The old value 20003 was wrong.
        public const string LoadPhaseChecks = @"
            SELECT P.Card               AS Card,
                   G.Reference          AS PrintID,
                   O.TypeName           AS EquipClassName,
                   O.Name               AS EquipName,
                   GB.Reference         AS SPC_PrintID,
                   OB.TypeName          AS SPC_EquipClassName,
                   OB.Name              AS SPC_EquipName,
                   P.IssueTime          AS IssueTime,
                   P.CompletionTime     AS CompletionTime
            FROM   Udb_Object O,
                   Udb_Object OB,
                   Udb_Grouping G,
                   Udb_Grouping GB,
                   FMS_PhaseCheck P
            WHERE  G.Grouping = ? AND
                   G.Relationship = 52 AND
                   G.Member = O.Object AND
                   P.PhaseCheckEquip = O.Object AND
                   GB.Grouping = ? AND
                   GB.Relationship = 52 AND
                   GB.Member = OB.Object AND
                   P.SatisfyEquip = OB.Object AND
                   P.WorkPermit = ? AND
                   P.Card = ?
            ORDER BY G.Reference, O.Name";

        // Ported from cac.dmt METHOD LoadPhaseCheckEquip (L80244-L80281) archive branch — regular-FMS only.
        public const string LoadPhaseChecksArchive = @"
            SELECT P.Card               AS Card,
                   G.Reference          AS PrintID,
                   O.TypeName           AS EquipClassName,
                   O.Name               AS EquipName,
                   GB.Reference         AS SPC_PrintID,
                   OB.TypeName          AS SPC_EquipClassName,
                   OB.Name               AS SPC_EquipName,
                   P.IssueTime          AS IssueTime,
                   P.CompletionTime     AS CompletionTime
            FROM   Udb_Object O,
                   Udb_Object OB,
                   Udb_Grouping G,
                   Udb_Grouping GB,
                   FMS_ArchivePhaseCheck P
            WHERE  G.Grouping = ? AND
                   G.Relationship = 52 AND
                   G.Member = O.Object AND
                   P.PhaseCheckEquip = O.Object AND
                   GB.Grouping = ? AND
                   GB.Relationship = 52 AND
                   GB.Member = OB.Object AND
                   P.SatisfyEquip = OB.Object AND
                   P.WorkPermit = ? AND
                   P.Card = ?
            ORDER BY G.Reference, O.Name";

        public const string LoadLocationTags = @"
            -- Ported from cac.dmt METHOD LoadWP_LocTags (L248128-L248175).
            -- LEFT OUTER JOIN preserves locations that have no tags; C# sets HasTag=false and
            -- blanks the tag columns (DOS prints these rows, e.g. Status 'TAG NOT NEEDED').
            -- IR_WorkLocation / IR_WorkLocationTag are the same tables for live and archived cards.
            SELECT WL.WPLocation           AS WPLocation,
                   WL.LocationStructure    AS LocationStructure,
                   WL.LocationStreet       AS LocationStreet,
                   WL.LocationStatus       AS LocationStatus,
                   WLT.TagType             AS TagType,
                   WLT.TagNumber           AS TagNumber,
                   WLT.Phases              AS Phases,
                   WLT.BrassTag            AS BrassTag,
                   WLT.PlasticTag          AS PlasticTag,
                   WLT.TagNotes            AS TagNotes
            FROM   IR_WorkLocation WL LEFT OUTER JOIN IR_WorkLocationTag WLT
                   ON WLT.WorkPermit = WL.WorkPermit AND WLT.WPLocation = WL.WPLocation
            WHERE  WL.WorkPermit = ?
            ORDER BY WL.WPLocation, WLT.TagType, WLT.TagNumber";

        public const string LoadRelaySummary = @"
            SELECT B.SwitchingItem, B.CreationTime,
                   B.BusSection, O.Name AS BusSectionName,
                   B.BDPhaseA, B.BDPhaseB, B.BDPhaseC, B.BDRelayName,
                   B.BDLastUpd, B.BDLastUpdBy,
                   B.BOCPhaseA, B.BOCPhaseB, B.BOCPhaseC, B.BOCPhaseN,
                   B.BOCRelayName, B.BOCLastUpd, B.BOCLastUpdBy,
                   B.FBMPR, B.FBMPRValue, B.FBMPRTime, B.FBMPRUpdBy,
                   B.FTFeeder, B.FTPhaseA, B.FTPhaseB, B.FTPhaseC, B.FTPhaseN,
                   B.FTRelayName, B.FTLastUpd, B.FTLastUpdBy
            FROM   SOA_BusFaultOutage B,
                   Udb_Object O
            WHERE  B.SwitchingItem = ? AND
                   B.BusSection = O.Object";

        public const string LoadRelayTargets = @"
            SELECT RT.Comment, RT.Job, RT.Line,
                   RT.RelayName, RT.TimeStamp,
                   RT.TypeA, RT.TypeB, RT.TypeC,
                   RT.TypeInst, RT.TypeText,
                   RT.SubstationName, RT.Substation,
                   RT.Sequence, RT.IsVerbal
            FROM   IR_RelayTargets RT,
                   SOA_JobControl JC
            WHERE  JC.Card = ? AND
                   JC.SwitchingItem = ? AND
                   JC.Job = RT.Job
            UNION
            SELECT RT.Comment, RT.Job, RT.Line,
                   RT.RelayName, RT.TimeStamp,
                   RT.TypeA, RT.TypeB, RT.TypeC,
                   RT.TypeInst, RT.TypeText,
                   RT.SubstationName, RT.Substation,
                   RT.Sequence, RT.IsVerbal
            FROM   IR_RelayTargets RT
            WHERE  RT.Job = ?
            ORDER BY SubstationName, Sequence, TimeStamp";

        public const string LoadRelayTargetsArchive = @"
            SELECT RT.Comment, RT.Job, RT.Line,
                   RT.RelayName, RT.TimeStamp,
                   RT.TypeA, RT.TypeB, RT.TypeC,
                   RT.TypeInst, RT.TypeText,
                   RT.SubstationName, RT.Substation,
                   RT.Sequence, RT.IsVerbal
            FROM   IR_RelayTargets RT,
                   SOA_ArchiveJob J
            WHERE  J.Card = ? AND
                   J.SwitchingItem = ? AND
                   J.Job = RT.Job
            UNION
            SELECT RT.Comment, RT.Job, RT.Line,
                   RT.RelayName, RT.TimeStamp,
                   RT.TypeA, RT.TypeB, RT.TypeC,
                   RT.TypeInst, RT.TypeText,
                   RT.SubstationName, RT.Substation,
                   RT.Sequence, RT.IsVerbal
            FROM   IR_RelayTargets RT
            WHERE  RT.Job = ?
            ORDER BY SubstationName, Sequence, TimeStamp";

        // ---- FMS Relay Summary: SQL VERIFIED from Relay_ASE.LoadRelaySummary (cas.dmt L187437), CardType = FMS (non-SLC) ----
        public const string LoadFmsRelayOps = @"
            SELECT R.Line, R.FeederName, R.Equip, R.EquipName, R.EquipClassName,
                   R.RelayType, R.RelayTypeName, R.RelayClassName, R.RelayName,
                   R.Operation, R.TimeStamp
            FROM   CAC_RelayOps R,
                   CAC_RelayOpsControl RC,
                   Udb_Object O,
                   Udb_Object OO
            WHERE  RC.Card = ?
              AND  R.RelayOp = RC.RelayOp
              AND  R.Equip = O.Object
              AND  O.PrimaryGrouping = OO.Object
            ORDER BY R.Line, R.RelayClassName, R.RelayTypeName, R.EquipName, R.Operation";

        public const string LoadFmsRelayOpsArchive = @"
            SELECT R.Line, R.FeederName, R.Equip, R.EquipName, R.EquipClassName,
                   R.RelayType, R.RelayTypeName, R.RelayClassName, R.RelayName,
                   R.Operation, R.TimeStamp
            FROM   CAC_ArchiveRelayOps R,
                   CAC_ArchiveROControl RC,
                   Udb_Object O,
                   Udb_Object OO
            WHERE  RC.Card = ?
              AND  R.RelayOp = RC.RelayOp
              AND  R.Equip = O.Object
              AND  O.PrimaryGrouping = OO.Object
            ORDER BY R.Line, R.RelayClassName, R.RelayTypeName, R.EquipName, R.Operation";

        // Open-auto equipment on the card; 0 = MoveCategory$Normal, 52 = Interaction$MemberOf, 40 = Type$Feeder.
        public const string LoadFmsRelayEquip = @"
            SELECT DISTINCT F.Name AS FeederName, J.Equip, S.RelayType AS RelayClass
            FROM   Udb_Object F,
                   Udb_Grouping G,
                   Udb_Switch S,
                   SOA_Job J,
                   SOA_JobControl JC
            WHERE  JC.Card = ?
              AND  JC.SwitchingItem = ?
              AND  JC.Job = J.Job
              AND  J.MoveCategory = 0
              AND  J.Status IN ('', 'NIS')
              AND  J.EquipClass IN (SELECT EquipClass FROM FMS_OpenAutoEquip)
              AND  J.Equip = G.Member
              AND  G.Relationship = 52
              AND  G.Grouping = F.Object
              AND  F.Type IN (SELECT Type FROM Udb_ExtendedType WHERE SuperType = 40)
              AND  J.Equip = S.Object";

        public const string LoadFmsRelayEquipArchive = @"
            SELECT DISTINCT F.Name AS FeederName, J.Equip, S.RelayType AS RelayClass
            FROM   Udb_Object F,
                   Udb_Grouping G,
                   Udb_Switch S,
                   FMS_ArchiveJob J
            WHERE  J.Card = ?
              AND  J.Status = ''
              AND  J.EquipClass IN (SELECT EquipClass FROM FMS_OpenAutoEquip)
              AND  J.Equip = G.Member
              AND  G.Relationship = 52
              AND  G.Grouping = F.Object
              AND  F.Type IN (SELECT Type FROM Udb_ExtendedType WHERE SuperType = 40)
              AND  J.Equip = S.Object";

        // 31 = Type$Relay
        public const string LoadRelayClasses = @"
            SELECT T.Type AS RelayClass, S.SuperType AS ParentRelayInt
            FROM   Udb_Type T,
                   Udb_SuperType S
            WHERE  T.Type IN (SELECT Type FROM Udb_ExtendedType WHERE SuperType = 31)
              AND  S.Type = T.Type";

        public const string LoadRelayTypes = @"
            SELECT Type, RelayType
            FROM   CAC_RelayTypes";

        public const string LoadRegisteredTags = @"
            SELECT R.Feeder, R.TagNumber, R.LocationStructure, R.LocationStreet,
                   R.TagSentDate, R.TagSentBy, R.Phases,
                   R.BrassTag, R.PlasticTag, R.TagNotes,
                   R.ExpirationDate, R.WarningDate, R.LastValidatedDate
            FROM   FMS_RegTag R
            WHERE  R.Feeder = ?
            ORDER BY R.TagNumber";





        // ---- Color inputs (SetFMSColors) ----
        public const string ColorNow = @"SELECT date('now') AS Now";

        public const string ColorFodMoves = @"
            SELECT FOJ.Job, FOJ.TORS, FOJ.JobStatus
            FROM   IR_FODOrder FO, IR_FODOrderJobs FOJ
            WHERE  FO.Card = ? AND
                   FO.OrderNumber = FOJ.OrderNumber AND
                   FOJ.JobStatus IN (10, 15, 20, 50)";

        public const string ColorFaultMoves = @"
            SELECT F.Job
            FROM   SOA_JobControl JC, FMS_Fault F
            WHERE  JC.Card = ? AND
                   JC.Job = F.Job AND
                   F.FODFaultStatus = 10";

        public const string ColorPaPermit = @"
            SELECT J.Job, 0 AS TORS
            FROM   FMS_AutomationBlock AB, IR_WorkPermit WP, SOA_Job J
            WHERE  AB.Card = ? AND AB.BlockStatus <= 15 AND
                   AB.Block = WP.WorkPermit AND AB.Block = J.Job AND
                   J.TOIssued IS NULL";

        public const string ColorPaFodTO = @"
            SELECT J.Job, FOJ.TORS
            FROM   FMS_AutomationBlock AB, IR_FODOrderJobs FOJ, SOA_Job J
            WHERE  AB.Card = ? AND AB.BlockStatus <= 15 AND
                   AB.Block = FOJ.OrderNumber AND FOJ.TORS = 0 AND
                   FOJ.Job = J.Job AND J.TOIssued IS NULL";

        public const string ColorPaFodRS = @"
            SELECT J.Job, FOJ.TORS
            FROM   FMS_AutomationBlock AB, IR_FODOrderJobs FOJ, SOA_Job J
            WHERE  AB.Card = ? AND AB.BlockStatus <= 15 AND
                   AB.Block = FOJ.OrderNumber AND FOJ.TORS = 1 AND
                   FOJ.Job = J.Job AND J.RSIssued IS NULL";

        public const string ColorPaOpTO = @"
            SELECT J.Job, OJ.TORS
            FROM   FMS_AutomationBlock AB, IR_OpOrderJobs OJ, SOA_Job J
            WHERE  AB.Card = ? AND AB.BlockStatus <= 15 AND
                   AB.Block = OJ.OrderNumber AND OJ.TORS = 0 AND
                   OJ.Job = J.Job AND J.TOIssued IS NULL";

        public const string ColorPaOpRS = @"
            SELECT J.Job, OJ.TORS
            FROM   FMS_AutomationBlock AB, IR_OpOrderJobs OJ, SOA_Job J
            WHERE  AB.Card = ? AND AB.BlockStatus <= 15 AND
                   AB.Block = OJ.OrderNumber AND OJ.TORS = 1 AND
                   OJ.Job = J.Job AND J.RSIssued IS NULL";

        public const string ColorOpOrders = @"
            SELECT OJ.Job, OJ.TORS, O.OrderNumber, O.OrderStatus
            FROM   SOA_JobControl JC, IR_OpOrderJobs OJ, IR_OperatingOrder O
            WHERE  JC.Card = ? AND
                   JC.Job = OJ.Job AND
                   OJ.OrderNumber = O.OrderNumber";

        public const string ColorPermits = @"
            SELECT WP.WorkPermit, WP.PermitStatus
            FROM   SOA_JobControl JC, IR_WorkPermit WP
            WHERE  JC.Card = ? AND
                   JC.Job = WP.WorkPermit";

        public const string ColorAlerts = @"
            SELECT B.Type, B.Object, B.Status, B.AlertTime, B.InitialAlert
            FROM   TM_BogeyAlert B
            WHERE  B.Card = ?";



        // ca.dmt LoadCard 67934-67936
        public const string LoadFotCount = @"
            SELECT FOTCount
            FROM   IR_FOTCount
            WHERE  Card = ?";

        // ca.dmt LoadPhaseCheckMoves 104408-104433
        public const string LoadOpenPhaseChecks = @"
            SELECT PhaseCheckEquip, SatisfyEquip
            FROM   FMS_PhaseCheck
            WHERE  Card = ? AND
                   CompletionTime IS NULL
            UNION
            SELECT P.PhaseCheckEquip, P.SatisfyEquip
            FROM   FMS_PhaseCheck P,
                   FMS_StepDownLink L
            WHERE ((L.Card = ? AND L.StepDownCard = P.Card) OR
                   (L.StepDownCard = ? AND L.Card = P.Card)) AND
                   P.CompletionTime IS NULL
            UNION
            SELECT P.PhaseCheckEquip, P.SatisfyEquip
            FROM   FMS_PhaseCheck P,
                   FMS_PortionLink L
            WHERE ((L.Card = ? AND L.PortionCard = P.Card) OR
                   (L.PortionCard = ? AND L.Card = P.Card)) AND
                   P.CompletionTime IS NULL";

    }
}
