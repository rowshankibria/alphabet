namespace FMS_PDFReportService.Data.Queries
{
    /// <summary>
    /// SQL query constants for TLS (Telephone Line Switching) card data retrieval.
    /// Ported from TLSCard_ASE, TLSJob_ASE.
    /// </summary>
    public static class TLSQueries
    {
        public const string LoadCardHeader = @"
            SELECT Card, Circuit, Linenumber, AltLine1, AltLine2,
                   LineType, CardType, LineTypeName, RouteName,
                   TroubleCategory, TroubleCategoryName,
                   FunctionArea, FunctionAreaName,
                   ReasonForFailure, ValidatedBy,
                   ShowNote, Notes,
                   Status, Carrier, CarrierName,
                   Opened, Closed, Priority
            FROM   TC_Card
            WHERE  Card = ?";

        public const string LoadCardHeaderArchive = @"
            SELECT Card, Circuit, Linenumber, AltLine1, AltLine2,
                   LineType, CardType, LineTypeName, RouteName,
                   TroubleCategory, TroubleCategoryName,
                   FunctionArea, FunctionAreaName,
                   ReasonForFailure, '' AS ValidatedBy,
                   ShowNote, Notes,
                   Status, Carrier, CarrierName,
                   Opened, Closed, 0 AS Priority
            FROM   TC_ArchiveCard
            WHERE  Card = ?";

        public const string LoadCardNote = @"
            SELECT Note AS CardNote
            FROM   TC_CardNote
            WHERE  Card = ?";

        public const string LoadJobs = @"
            SELECT Job, Card, Status, Seq, JobClass, JobClassSeq,
                   Circuit, Linenumber, CircuitClass, CircuitClassName,
                   StepPair, MoveType,
                   TOMoveRules, TOOperator, TOOperatorName, TOIssued,
                   TOComplete, TOMove, TOStep,
                   Results, ResultsCode, ResultsCodeName,
                   Substation, SubstationName,
                   Organization, OrganizationName,
                   RSMoveRules, RSOperator, RSOperatorName,
                   RSIssued, RSComplete, RSMove, RSStep,
                   InitialSwitchPos, FinalSwitchPos,
                   InService, OutService
            FROM   TC_Job
            WHERE  Card = ? AND
                   Status <> 'Del' AND
                   Status <> 'Hid'
            ORDER BY StepPair, Seq, Job";

        public const string LoadJobsArchive = @"
            SELECT Job, Card, Status, Seq, JobClass, JobClassSeq,
                   Circuit, Linenumber, CircuitClass, CircuitClassName,
                   StepPair, MoveType,
                   TOMoveRules, TOOperator, TOOperatorName, TOIssued,
                   TOComplete, TOMove, TOStep,
                   Results, ResultsCode, ResultsCodeName,
                   Substation, SubstationName,
                   Organization, OrganizationName,
                   RSMoveRules, RSOperator, RSOperatorName,
                   RSIssued, RSComplete, RSMove, RSStep,
                   InitialSwitchPos, FinalSwitchPos,
                   InService, OutService
            FROM   TC_ArchiveJob
            WHERE  Card = ? AND
                   Status <> 'Del'
            ORDER BY StepPair, Seq, Job";

        public const string LoadLineOOS = @"
            SELECT C.Card, C.Linenumber, C.RouteName,
                   C.CarrierName, C.TroubleCategoryName,
                   C.Opened, C.Status
            FROM   TC_Card C
            WHERE  C.Status <> 0
            ORDER BY C.Linenumber";

        public const string LoadCircuitChanges = @"
            SELECT C.Card, C.Linenumber, C.RouteName,
                   J.TOComplete AS ChangeDate,
                   J.TOMove AS ChangeDescription
            FROM   TC_Card C,
                   TC_Job J
            WHERE  C.Card = J.Card AND
                   J.TOComplete BETWEEN ? AND ?
            ORDER BY C.Linenumber, J.TOComplete";

        public const string LoadRevisionLog = @"
            SELECT C.Card, C.Linenumber, C.RouteName,
                   J.RSComplete AS RevisionDate,
                   J.RSMove AS RevisionDescription
            FROM   TC_Card C,
                   TC_Job J
            WHERE  C.Card = J.Card AND
                   J.RSComplete BETWEEN ? AND ?
            ORDER BY C.Linenumber, J.RSComplete";
    }
}
