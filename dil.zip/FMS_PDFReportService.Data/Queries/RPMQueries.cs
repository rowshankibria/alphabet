namespace FMS_PDFReportService.Data.Queries
{
    /// <summary>
    /// SQL query constants for RPM (Relay Protection Matrix) data retrieval.
    /// Ported from RPM_ASE via OpenROAD procedure calls.
    /// </summary>
    public static class RPMQueries
    {
        public const string LoadAllGroupings = @"
            SELECT G.Grouping AS GroupId, O.Name AS GroupName
            FROM   Udb_Grouping G,
                   Udb_Object O
            WHERE  G.GroupingType = 10060 AND
                   G.Grouping = O.Object
            ORDER BY O.Name";

        public const string LoadMatrix = @"
            SELECT G.Grouping AS GroupId, O.Name AS GroupName
            FROM   Udb_Grouping G,
                   Udb_Object O
            WHERE  G.Grouping = ? AND
                   G.Grouping = O.Object";

        public const string LoadFeeders = @"
            SELECT F.Feeder AS FeederId, O.Name AS FeederName, F.Grouping AS GroupId
            FROM   RPM_Feeder F,
                   Udb_Object O
            WHERE  F.Grouping = ? AND
                   F.Feeder = O.Object
            ORDER BY O.Name";

        public const string LoadCircuits = @"
            SELECT C.Circuit AS CircuitId, O.Name AS CircuitName,
                   C.CircuitType, C.RouteName, C.SubstationName,
                   C.Grouping AS GroupId
            FROM   RPM_Circuit C,
                   Udb_Object O
            WHERE  C.Grouping = ? AND
                   C.Circuit = O.Object
            ORDER BY O.Name";

        public const string LoadMatrixGrid = @"
            SELECT M.Feeder AS FeederId, M.Circuit AS CircuitId,
                   M.Status AS StatusValue, M.Grouping AS GroupId
            FROM   RPM_Matrix M
            WHERE  M.Grouping = ?";

        public const string LoadNotes = @"
            SELECT N.Note_ID AS NoteId, N.Note AS NoteText, N.Grouping AS GroupId
            FROM   CAC_Relay_Note N
            WHERE  N.Grouping = ?
            ORDER BY N.Note_Seq, N.Note_ID";

        public const string LoadRelayInfo = @"
            SELECT R.RelayId, R.RelayName, R.RelayType,
                   R.BackupRelay, R.TransferTrip,
                   R.Grouping AS GroupId
            FROM   RPM_RelayInfo R
            WHERE  R.Grouping = ?
            ORDER BY R.RelayName";

        public const string LoadDiagrams = @"
            SELECT D.DiagramId, D.DiagramPath, D.DiagramName,
                   D.Grouping AS GroupId
            FROM   RPM_Diagram D
            WHERE  D.Grouping = ?
            ORDER BY D.DiagramId";

        public const string LoadCircuitTypes = @"
            SELECT T.TypeId, T.TypeName, T.Description
            FROM   RPM_CircuitType T
            ORDER BY T.TypeName";
    }
}
