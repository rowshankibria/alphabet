namespace FMS_PDFReportService.Data.Queries
{
    /// <summary>
    /// SQL query constants for Steam/SDS card data retrieval.
    /// Ported from SDS_Card class. Uses sds_db database.
    /// </summary>
    public static class SteamQueries
    {
        public const string LoadCardHeader = @"
            SELECT Card, MSONumber, SoleAuthority,
                   Station, StationName,
                   CardClass, CardClassName,
                   Status, Opened, Activated, Closed,
                   PreparedBy, CheckedBy
            FROM   SDS_Card
            WHERE  Card = ?";

        public const string LoadCardMains = @"
            SELECT M.Main, M.MainName,
                   V.ISOValve, V.ISOValveName, V.ISOValveStatus
            FROM   SDS_CardMain M,
                   SDS_CardMainValve V
            WHERE  M.Card = ? AND
                   M.Card = V.Card AND
                   M.Main = V.Main
            ORDER BY M.MainName";

        public const string LoadJobs = @"
            SELECT J.Job, SJ.Card, SJ.Seq,
                   J.Status, J.JobClass,
                   J.Equip, J.EquipClass, J.EquipClassName, J.EquipName,
                   SJ.StepPair, J.Grounds, J.MoveType,
                   J.TOMove, J.TOMoveRules, J.TOOperator, J.TOIssued, J.TOComplete,
                   J.GroundOn,
                   J.RSMove, J.RSMoveRules, J.RSOperator, J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   SJ.MoveEquipClass,
                   J.Substation, O.Name AS SubstationName,
                   J.MoveCategory, SJ.StepLevel, J.ControlCard,
                   J.MoveFGColor, J.MoveBGColor
            FROM   SOA_Job J,
                   SOA_JobControl SJ,
                   Udb_Object O
            WHERE  SJ.Card = ? AND
                   SJ.Job = J.Job AND
                   J.Substation = O.Object AND
                   J.Status <> 'Del'
            ORDER BY SJ.StepPair, SJ.StepLevel, SJ.Seq";

        public const string GetActiveCardIds = @"
            SELECT Card
            FROM   SDS_Card
            WHERE  Status <> 0";

        // From OpenROAD cas.dmt LoadActiveList — runs against dso_db, not sds_db
        public const string GetActiveCards = @"
            SELECT Card, CardName
            FROM   SOA_ActiveCard
            WHERE  CardStatus = 20
            AND    TypeOfCard IN (16001, 16008, 16009)
            ORDER BY CardName";
    }
}
