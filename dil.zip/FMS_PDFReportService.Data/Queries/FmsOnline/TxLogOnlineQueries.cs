namespace FMS_PDFReportService.Data.Queries.FmsOnline;

/// <summary>
/// SQL queries for Transaction Log and Incomplete Jobs web reports.
/// SQL: VERIFIED — copied from FMS_DatabaseService/Business/soa/TransactionLog.vb
/// and FMS_DatabaseService/Business/soa/Job.vb
/// </summary>
public static class TxLogOnlineQueries
{
    // SQL: VERIFIED — copied from TransactionLog.vb:LoadSOATxLog (L90) — active card, SOA_Log + SOA_Job/FMS_ArchiveJob
    // Tables: SOA_Log, SOA_Job, FMS_ArchiveJob
    public const string SOATxLogActive = @"
        SELECT L.Time, '' as PrintID, J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.TOOperator, J.RSMove, J.RSOperator,
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   SOA_Log L, SOA_Job J
        WHERE  L.Card = @Card
          AND  L.SwitchingItem = @SwitchingItem
          AND  L.Job = J.Job
        UNION
        SELECT L.Time, J.PrintID, J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.TOOperator, J.RSMove, J.RSOperator,
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   SOA_Log L, FMS_ArchiveJob J
        WHERE  L.Card = @Card
          AND  L.SwitchingItem = @SwitchingItem
          AND  L.Card = J.Card
          AND  L.Job = J.Job
        UNION
        SELECT L.Time, '', 0, '', '', '', 0, '', 0,
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   SOA_Log L
        WHERE  L.Card = @Card
          AND  L.SwitchingItem = @SwitchingItem
          AND  L.Job IS NULL
        ORDER BY Time DESC";

    // SQL: VERIFIED — copied from TransactionLog.vb:LoadSOATxLog (L165) — archive card, FMS application
    // Tables: FMS_ArchiveLog, FMS_ArchiveJob, SOA_Job
    public const string FMSArchiveTxLog = @"
        SELECT L.Time, '' as PrintID, J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.TOOperator, J.RSMove, J.RSOperator,
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   FMS_ArchiveLog L, FMS_ArchiveJob J
        WHERE  L.Card = @Card
          AND  J.Job = L.Job
        UNION
        SELECT L.Time, '', J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.TOOperator, J.RSMove, J.RSOperator,
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   FMS_ArchiveLog L, SOA_Job J
        WHERE  L.Card = @Card
          AND  J.Job = L.Job
        UNION
        SELECT L.Time, '', 0, '', '', '', 0, '', 0,
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   FMS_ArchiveLog L
        WHERE  L.Card = @Card
          AND  L.Job IS NULL
        ORDER BY Time DESC";

    // SQL: VERIFIED — copied from TransactionLog.vb:LoadSOATxLog (L195) — archive card, SOA/other application
    // Tables: SOA_ArchiveLog, SOA_ArchiveJob, SOA_Job
    public const string SOAArchiveTxLog = @"
        SELECT L.Time, '' as PrintID, J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.TOOperator, J.RSMove, J.RSOperator,
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   SOA_ArchiveLog L, SOA_ArchiveJob J
        WHERE  L.Card = @Card
          AND  L.SwitchingItem = @SwitchingItem
          AND  J.Job = L.Job
        UNION
        SELECT L.Time, '', J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.TOOperator, J.RSMove, J.RSOperator,
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   SOA_ArchiveLog L, SOA_Job J
        WHERE  L.Card = @Card
          AND  L.SwitchingItem = @SwitchingItem
          AND  J.Job = L.Job
        UNION
        SELECT L.Time, '', 0, '', '', '', 0, '', 0,
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   SOA_ArchiveLog L
        WHERE  L.Card = @Card
          AND  L.SwitchingItem = @SwitchingItem
          AND  L.Job IS NULL
        ORDER BY Time DESC";

    // SQL: VERIFIED — copied from TransactionLog.vb:LoadSOATxLog (L82) — FMS feeder lookup
    // Tables: FMS_Card
    public const string LookupFeeder = @"
        SELECT Feeder FROM FMS_Card WHERE Card = @Card";

    // SQL: VERIFIED — copied from TransactionLog.vb:LoadSOATxLog (L135) — PrintID lookup
    // Tables: Udb_Grouping
    public const string LookupPrintID = @"
        SELECT Reference FROM Udb_Grouping
        WHERE  Grouping = @Feeder
          AND  Relationship = 10
          AND  Member = @Equip";

    // SQL: VERIFIED — copied from TransactionLog.vb:LoadTLSTxLog (L280) — active TLS card
    // Tables: TC_Log, TC_Job
    public const string TLSTxLogActive = @"
        SELECT L.Time, J.TOMove, J.TOOperator, IFNULL(J.TOOperatorName,'') as TOOperatorName,
               J.RSMove, J.RSOperator, IFNULL(J.RSOperatorName,'') as RSOperatorName,
               J.Substation, J.SubstationName,
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   TC_Log L, TC_Job J
        WHERE  L.Card = @Card
          AND  J.Job = L.Job
        UNION
        SELECT L.Time, '', 0, '', '', 0, '', 0, '',
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   TC_Log L
        WHERE  L.Card = @Card
          AND  L.Job IS NULL
        ORDER BY Time DESC";

    // SQL: VERIFIED — copied from TransactionLog.vb:LoadTLSTxLog (L300) — archive TLS card
    // Tables: TC_ArchiveLog, TC_ArchiveJob
    public const string TLSTxLogArchive = @"
        SELECT L.Time, J.TOMove, J.TOOperator, IFNULL(J.TOOperatorName,'') as TOOperatorName,
               J.RSMove, J.RSOperator, IFNULL(J.RSOperatorName,'') as RSOperatorName,
               J.Substation, J.SubstationName,
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   TC_ArchiveLog L, TC_ArchiveJob J
        WHERE  L.Card = @Card
          AND  J.Job = L.Job
        UNION
        SELECT L.Time, '', 0, '', '', 0, '', 0, '',
               L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   TC_ArchiveLog L
        WHERE  L.Card = @Card
          AND  L.Job IS NULL
        ORDER BY Time DESC";

    // SQL: VERIFIED — copied from Job.vb:LoadIncompleteJob (L555) — active card
    // Tables: SOA_Log, SOA_Job, FMS_ArchiveJob
    public const string IncompleteJobsActive = @"
        SELECT J.Job, L.Time, '' as PrintID, J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.RSMove, L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   SOA_Log L, SOA_Job J
        WHERE  L.Card = @Card
          AND  L.SwitchingItem = @SwitchingItem
          AND  L.Item IN ('TOIssued', 'RSIssued', 'TOOperator', 'RSOperator')
          AND  L.Old <> ''
          AND  L.New = ''
          AND  L.Job = J.Job
        UNION
        SELECT J.Job, L.Time, '', J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.RSMove, L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   SOA_Log L, FMS_ArchiveJob J
        WHERE  L.Card = @Card
          AND  L.Item IN ('TOIssued', 'RSIssued', 'TOOperator', 'RSOperator')
          AND  L.Old <> ''
          AND  L.New = ''
          AND  L.Card = J.Card
          AND  L.Job = J.Job
        ORDER BY Job, Time";

    // SQL: VERIFIED — copied from Job.vb:LoadIncompleteJob (L640) — FMS archive card
    // Tables: FMS_ArchiveLog, FMS_ArchiveJob, SOA_Job
    public const string IncompleteJobsFMSArchive = @"
        SELECT L.Job, L.Time, J.PrintID, J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.RSMove, L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   FMS_ArchiveLog L, FMS_ArchiveJob J
        WHERE  L.Card = @Card
          AND  J.Card = L.Card
          AND  J.Job = L.Job
        UNION
        SELECT L.Job, L.Time, '', J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.RSMove, L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   FMS_ArchiveLog L, SOA_Job J
        WHERE  L.Card = @Card
          AND  L.Item IN ('TOIssued', 'RSIssued', 'TOOperator', 'RSOperator')
          AND  L.Old <> ''
          AND  L.New = ''
          AND  J.Job = L.Job
        ORDER BY Job, Time";

    // SQL: VERIFIED — copied from Job.vb:LoadIncompleteJob (L665) — SOA archive card
    // Tables: SOA_ArchiveLog, SOA_ArchiveJob, SOA_Job
    public const string IncompleteJobsSOAArchive = @"
        SELECT L.Job, L.Time, J.PrintID, J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.RSMove, L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   SOA_ArchiveLog L, SOA_ArchiveJob J
        WHERE  L.Card = @Card
          AND  L.SwitchingItem = @SwitchingItem
          AND  L.Item IN ('TOIssued', 'RSIssued', 'TOOperator', 'RSOperator')
          AND  L.Old <> ''
          AND  L.New = ''
          AND  J.Job = L.Job
        UNION
        SELECT L.Job, L.Time, '', J.Equip, J.EquipName, J.EquipClassName,
               J.TOMove, J.RSMove, L.UserName, L.Item, L.Old, L.New, L.Operator, L.OperatorName
        FROM   SOA_ArchiveLog L, SOA_Job J
        WHERE  L.Card = @Card
          AND  L.SwitchingItem = @SwitchingItem
          AND  L.Item IN ('TOIssued', 'RSIssued', 'TOOperator', 'RSOperator')
          AND  L.Old <> ''
          AND  L.New = ''
          AND  J.Job = L.Job
        ORDER BY Job, Time DESC";

    // SQL: VERIFIED — copied from Job.vb:LoadIncompleteJob (L740) — SSO order remark lookup
    // Tables: IR_OpOrderJobs, IR_OperatingOrder
    public const string LookupSSOOrder = @"
        SELECT OJ.OrderNumber, OO.AckRejectComment, OO.RescindComment,
               OO.ReturnComment, OJ.ReturnRemark, OO.OrderStatus, OO.IssueTime
        FROM   IR_OpOrderJobs OJ, IR_OperatingOrder OO
        WHERE  OJ.Job = @Job
          AND  OJ.TORS = @TORS
          AND  OJ.OrderNumber = OO.OrderNumber
          AND  OO.IssueTime BETWEEN @BeginTime AND @EndTime";

    // SQL: VERIFIED — copied from Job.vb:LoadIncompleteJob (L780) — FOD order remark lookup
    // Tables: IR_FODOrderJobs, IR_FODOrder
    public const string LookupFODOrder = @"
        SELECT OJ.OrderNumber, OJ.AckRejectedComment, OJ.RescindComment,
               OJ.ReturnRemark, OJ.JobStatus
        FROM   IR_FODOrderJobs OJ, IR_FODOrder FO
        WHERE  OJ.Job = @Job
          AND  OJ.TORS = @TORS
          AND  OJ.OrderNumber = FO.OrderNumber
          AND  FO.IssueTime BETWEEN @BeginTime AND @EndTime";

    // SQL: VERIFIED — copied from Job.vb:LoadIncompleteJob (L830) — rejected log lookup
    // Tables: SOA_Log (active) or SOA_ArchiveLog (archive)
    public const string LookupRejectedLogActive = @"
        SELECT Job, Old, New FROM SOA_Log
        WHERE  Job = @Job
          AND  Item = 'Rejected'
          AND  Time BETWEEN @BeginTime AND @EndTime";

    public const string LookupRejectedLogArchive = @"
        SELECT Job, Old, New FROM SOA_ArchiveLog
        WHERE  Job = @Job
          AND  Item = 'Rejected'
          AND  Time BETWEEN @BeginTime AND @EndTime";
}
