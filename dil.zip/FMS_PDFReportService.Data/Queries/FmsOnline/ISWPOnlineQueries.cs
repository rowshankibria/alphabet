namespace FMS_PDFReportService.Data.Queries.FmsOnline;

/// <summary>
/// SQL queries for ISWP web reports.
/// SQL: VERIFIED — copied from FMS_DatabaseService/Business/iswp/ISWP_Report.vb
/// and ISWP_Restriction.vb
/// </summary>
public static class ISWPOnlineQueries
{
    // SQL: VERIFIED — copied from ISWP_Report.vb:LoadMgmtReport (all permits by work group)
    // Tables: SOA_InServicePermit, SOA_ISPermitRequest
    public const string MgmtReportAllPermits = @"
        SELECT P.WorkGroup AS WorkGroup,
               R.StartDate AS ShiftStartTime,
               R.Emergent AS Status
        FROM   SOA_InServicePermit P,
               SOA_ISPermitRequest R
        WHERE  P.ReportTime >= DATE(@StartDate)
          AND  P.ReportTime < DATE(@EndDate)
          AND  P.ISPermit = R.ISPermit
        ORDER BY WorkGroup";

    // SQL: VERIFIED — copied from ISWP_Report.vb:LoadMgmtReport (permits by subgroup)
    // Tables: SOA_InServicePermit, SOA_ISPermitRequest, Udb_Grouping, Udb_Object
    // {0} = WorkGroup name, {1} = GroupingType integer
    public const string MgmtReportSubgroup = @"
        SELECT P.WorkGroup AS WorkGroup,
               R.StartDate AS ShiftStartTime,
               R.Emergent AS Status
        FROM   SOA_InServicePermit P,
               SOA_ISPermitRequest R,
               Udb_Grouping G,
               Udb_Object O
        WHERE  P.ReportTime >= DATE(@StartDate)
          AND  P.ReportTime < DATE(@EndDate)
          AND  P.WorkGroup = @WorkGroup
          AND  P.Substation = G.Member
          AND  G.RelationShip = 52
          AND  G.GroupingType = @GroupingType
          AND  G.Grouping = O.Object
          AND  P.ISPermit = R.ISPermit
        ORDER BY WorkGroup";

    // SQL: VERIFIED — copied from ISWP_Report.vb:LoadNYISOReport
    // Tables: SOA_InServicePermit, UDB_Object, SOA_Job + SOA_ArchiveJob (UNION ALL)
    // {0} = division filter clause (empty or "P.Division IN (...) AND")
    public const string NYISOReport = @"
        SELECT P.Job AS Job,
               P.Division AS Division,
               O.Description AS SubstationName,
               P.PermitMove AS RequestTitle,
               P.NYISOTOName AS NotifiedBy,
               P.NYISOTime AS NotifiedTime,
               IFNULL(J.TOIssued, '') AS IssueTime,
               IFNULL(J.RSComplete, '') AS ReturnTime
        FROM   SOA_InServicePermit P,
               UDB_Object O,
               SOA_Job J
        WHERE  {0}
               P.Substation = O.Object AND
               P.NYISONotified = 1 AND
               P.NYISOTime BETWEEN DATE(@StartDate) AND DATE(@EndDate) AND
               P.Job = J.Job
        UNION ALL
        SELECT P.Job,
               P.Division,
               O.Description,
               P.PermitMove,
               P.NYISOTOName,
               P.NYISOTime,
               IFNULL(J.TOIssued, ''),
               IFNULL(J.RSComplete, '')
        FROM   SOA_InServicePermit P,
               UDB_Object O,
               SOA_ArchiveJob J
        WHERE  {0}
               P.Substation = O.Object AND
               P.NYISONotified = 1 AND
               P.NYISOTime BETWEEN DATE(@StartDate) AND DATE(@EndDate) AND
               P.Job = J.Job
        ORDER BY NotifiedTime";

    // SQL: VERIFIED — copied from ISWP_Report.vb:LoadDeniedByGroup
    // Tables: SOA_InServicePermit, SOA_ISPermitRequest
    // {0} = group filter clause, {1} = status/division clause
    public const string DeniedByGroup = @"
        SELECT P.WorkGroup AS WorkGroup,
               Count(P.WorkGroup) AS Total
        FROM   SOA_InServicePermit P,
               SOA_ISPermitRequest R
        WHERE  {0}
               P.ISPermit = R.ISPermit AND
               R.CurrentStatus = 'DENIED' AND
               P.StatusTime BETWEEN DATE(@StartDate) AND DATE(@EndDate) AND
               P.Division IN ({1})
        GROUP BY P.WorkGroup";

    // SQL: VERIFIED — copied from ISWP_Report.vb:LoadDeniedByGroup (subgroup summary)
    // Tables: SOA_InServicePermit, SOA_ISPermitRequest, Udb_Grouping, Udb_Object
    public const string DeniedBySubgroup = @"
        SELECT O.Name AS WorkGroup,
               Count(O.Name) AS Total
        FROM   SOA_InServicePermit P,
               SOA_ISPermitRequest R,
               Udb_Grouping G,
               Udb_Object O
        WHERE  P.WorkGroup = @ParentGroup AND
               P.Substation = G.Member AND
               G.RelationShip = 52 AND
               G.GroupingType = @GroupingType AND
               G.Grouping = O.Object AND
               P.ISPermit = R.ISPermit AND
               R.CurrentStatus = 'DENIED' AND
               P.StatusTime BETWEEN DATE(@StartDate) AND DATE(@EndDate) AND
               P.Division IN ({0})
        GROUP BY O.Name";

    // SQL: VERIFIED — copied from ISWP_Report.vb:LoadDeniedList
    // Tables: SOA_ISPermitRequest, SOA_InServicePermit, Udb_Object (x2), SOA_ISPLog
    // {0} = group filter clause, {1} = status/division clause
    public const string DeniedList = @"
        SELECT R.ISPermit AS RequestID,
               P.WorkGroup AS WorkGroup,
               OD.Name AS Division,
               OS.Name AS Substation,
               R.PermitMove AS Title,
               P.PreIssued AS ISPreIssued,
               R.SubmitTime AS RequestTime,
               P.StatusTime AS DOApprove,
               L.LogText AS DenyReason
        FROM   SOA_ISPermitRequest R,
               SOA_InServicePermit P,
               Udb_Object OD,
               Udb_Object OS,
               SOA_ISPLog L
        WHERE  {0}
               P.ISPermit = R.ISPermit AND
               R.CurrentStatus = 'DENIED' AND
               P.StatusTime BETWEEN DATE(@StartDate) AND DATE(@EndDate) AND
               P.Division IN ({1}) AND
               P.Division = OD.Object AND
               P.Substation = OS.Object AND
               P.ISPermit = L.ISPermit AND
               P.StatusTime = L.LogTime AND
               L.LogText LIKE 'R%'
        ORDER BY Division, Substation, RequestID";

    // SQL: VERIFIED — copied from ISWP_Restriction.vb:LoadRestrictions
    // Tables: SOA_ISPRestriction, SOA_ISPRestrictionItem, UDB_Object (x2)
    // {0} = dynamic where clause for status/date
    public const string Restrictions = @"
        SELECT DISTINCT
               R.Restriction AS Restriction,
               R.HandsOff AS HandsOff,
               R.Remark AS Remark,
               R.StartTime AS StartTime,
               R.EndTime AS EndTime,
               R.Status AS Status,
               R.EnterTime AS EnterTime,
               R.LiftTime AS LiftTime,
               O1.Description AS EnterByName,
               0 AS Item_Object,
               '' AS Item_Name,
               '' AS Item_Description,
               0 AS Item_Type
        FROM   SOA_ISPRestriction R,
               UDB_Object O1
        WHERE  {0} AND R.EnterBy = O1.Object
        UNION ALL
        SELECT DISTINCT
               R.Restriction,
               R.HandsOff,
               R.Remark,
               R.StartTime,
               R.EndTime,
               R.Status,
               R.EnterTime,
               R.LiftTime,
               O1.Description,
               O2.Object,
               O2.Name,
               O2.Description,
               O2.Type
        FROM   SOA_ISPRestriction R,
               SOA_ISPRestrictionItem I,
               UDB_Object O1,
               UDB_Object O2
        WHERE  {0} AND R.EnterBy = O1.Object
          AND  R.Restriction = I.Restriction
          AND  I.Object = O2.Object
        ORDER BY Restriction DESC, Item_Name ASC";
}
