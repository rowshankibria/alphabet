namespace FMS_PDFReportService.Data.Queries.FmsOnline
{
    // SQL: VERIFIED — copied from FMS_DatabaseService/Business/fms/FMS_Report.vb and Business/soa/RegisteredTags.vb
    public static class FmsOnlineQueries
    {
        // From FMS_Report.vb:GetETStopTag — system parameters
        public const string ETStopTagParameters = @"
            SELECT ETStopTagExpiration AS Expiration, ETStopTagExpirationWarning AS Warning
            FROM FMS_SystemParameters";

        // From FMS_Report.vb:GetETStopTag — main query
        // Constants resolved: Type_ET=20019, Interaction_MemberOf=52, Type_Feeder=40, Prompt_StopTag=10038
        public const string ETStopTagList = @"
            SELECT DISTINCT
                O.Name as Feeder,
                J.EquipName as ET,
                S.StopTag as Tag,
                J.TOComplete as ApplyDate
            FROM SOA_Job J,
                 Udb_ExtendedType ET1,
                 SOA_JobControl JC,
                 SOA_ActiveCard AC,
                 Udb_Grouping G,
                 Udb_ExtendedType ET2,
                 Udb_Switch S,
                 Udb_Object O,
                 FMS_JobAction JA
            WHERE J.EquipClass = ET1.Type
              AND ET1.SuperType = 20019
              AND (J.TOComplete IS NOT NULL AND J.TOComplete <> '')
              AND J.RSComplete IS NULL
              AND J.Equip = G.Member
              AND G.Relationship = 52
              AND G.GroupingType = ET2.Type
              AND ET2.SuperType = 40
              AND G.Grouping = O.Object
              AND J.Job = JC.Job
              AND JC.Card = AC.Card
              AND J.Equip = S.Object
              AND S.StopTag <> ''
              AND J.JobClass = JA.JobClass
              AND JA.Status = 10038
            ORDER BY 1, 2, 3";

        // From FMS_Report.vb:GetPhaseCheck — active cards
        // Constants resolved: Interaction_MemberOf=52, Type_Division=4
        // NOTE: StartDate is injected via string format (matching legacy behavior) — caller must sanitize
        public const string PhaseCheckActive = @"
            SELECT DISTINCT g.Grouping as Division,
                eq.PrimaryGroupingName as Feeder,
                eq.Name as Equipment,
                eq.Object as PhaseCheckEquip,
                c.Status as Status,
                p.IssueTime as Issued,
                p.CompletionTime as Completed,
                op.Description as Operator
            FROM fms_phasecheck p
                LEFT JOIN fms_card c ON p.Card = c.Card
                LEFT JOIN soa_job j ON p.PhaseCheckEquip = j.Equip and p.CompletionTime = j.RSComplete
                LEFT JOIN udb_object op ON j.RSOperator = op.Object,
                udb_object eq,
                udb_grouping g
            WHERE p.IssueTime > DATE('{0}')
              AND p.Card = c.Card
              AND p.PhaseCheckEquip = eq.Object
              AND eq.PrimaryGrouping = g.Member
              AND g.Relationship = 52
              AND g.GroupingType = 4";

        // From FMS_Report.vb:GetPhaseCheck — archived cards
        public const string PhaseCheckArchive = @"
            SELECT DISTINCT g.Grouping as Division,
                eq.PrimaryGroupingName as Feeder,
                eq.Name as Equipment,
                eq.Object as PhaseCheckEquip,
                c.Status as Status,
                p.IssueTime as Issued,
                p.CompletionTime as Completed,
                op.Description as Operator
            FROM fms_phasecheck p
                LEFT JOIN fms_archivecard c ON p.Card = c.Card
                LEFT JOIN fms_archivejob j ON p.PhaseCheckEquip = j.Equip and p.CompletionTime = j.RSComplete
                LEFT JOIN udb_object op ON j.RSOperator = op.Object,
                udb_object eq,
                udb_grouping g
            WHERE p.IssueTime > DATE('{0}')
              AND p.PhaseCheckEquip = eq.Object
              AND eq.PrimaryGrouping = g.Member
              AND g.Relationship = 52
              AND g.GroupingType = 4";

        // From FMS_Report.vb:GetNetworkProtector — main query (sSQLSelect1)
        // Constants resolved: TypeName_NWP=20118, Prompt_SetCurrentlyOpen=10159, kJA_Completion=1,
        //   Interaction_MemberOf=52, Type_Feeder=40
        public const string NetworkProtectorMain = @"
            SELECT
                C.Card as Card,
                S.CurrentlyOpen as CurrentlyOpen,
                C.CutIn as CutIn,
                C.CutOut as CutOut,
                O2.Object as Feeder,
                O2.Name as FeederName,
                O2.Type as FeederType,
                J.Job as Job,
                J.JobClass as JobClass,
                J.TOComplete as MoveCompletion,
                O.Object as NWPId,
                O.Name as NWPName,
                JCl.TOMove as MoveText,
                S.StopTag as StopTag
            FROM Udb_Object O,
                 Udb_ExtendedType ET,
                 SOA_Job J,
                 FMS_JobAction JA,
                 Udb_Switch S,
                 SOA_JobControl JC,
                 SOA_ActiveCard AC,
                 FMS_Card C,
                 Udb_Grouping G,
                 Udb_Object O2,
                 Udb_ExtendedType ET2,
                 FMS_JobClass JCl
            WHERE O.Type = ET.Type
              AND ET.SuperType = 20118
              AND O.Object = J.Equip
              AND J.Status = ''
              AND J.TOComplete IS NOT NULL
              AND (J.RSComplete IS NULL OR J.RSComplete = '')
              AND J.JobClass = JA.JobClass
              AND JA.Status = 10159
              AND JA.TORS = 0
              AND JA.IssueCompl = 1
              AND O.Object = S.Object
              AND J.Job = JC.Job
              AND JC.Card = AC.Card
              AND AC.Card = C.Card
              AND O.Object = G.Member
              AND G.Relationship = 52
              AND G.Grouping = O2.Object
              AND O2.Type = ET2.Type
              AND ET2.SuperType = 40
              AND J.JobClass = JCl.JobClass
            ORDER BY NWPId, MoveCompletion";

        // From FMS_Report.vb:GetNetworkProtector — resolve ISO to feeder (sSQLSelect2)
        // Type_Feeder=40
        public const string NetworkProtectorResolveFeeder = @"
            SELECT O.Object as Feeder,
                   O.Name as FeederName,
                   O.Type as FeederType
            FROM Udb_Grouping G, Udb_Object O
            WHERE G.Member = ?
              AND G.Relationship = 52
              AND G.Grouping = O.Object
              AND O.Type = 40";

        // From FMS_Report.vb:GetNetworkProtector — get network (sSQLSelect3)
        // Type_Network=10136
        public const string NetworkProtectorGetNetwork = @"
            SELECT O.Object as Network,
                   O.Name as NetworkName
            FROM Udb_Grouping G, Udb_Object O
            WHERE G.Member = ?
              AND G.Relationship = 52
              AND G.Grouping = O.Object
              AND O.Type = 10136";

        // From FMS_Report.vb:GetNetworkProtector — fuse/disconnect jobs (sSQLSelect4)
        public const string NetworkProtectorGetJobText = @"
            SELECT DISTINCT JCl.TOMove as JobText
            FROM SOA_JobControl JC,
                 SOA_Job J,
                 FMS_JobClass JCl,
                 NWP_JobClass N
            WHERE JC.Card = ?
              AND JC.Job = J.Job
              AND J.TOComplete IS NOT NULL
              AND J.RSComplete IS NULL
              AND J.JobClass = N.JobClass
              AND J.JobClass = JCl.JobClass";

        // From RegisteredTags.vb:LoadRegTags — all divisions
        // Constants resolved: Type_Feeder=40, Interaction_MemberOf=52, Type_Division=4
        public const string RegisteredTagsAll = @"
            SELECT G.Grouping AS Division,
                O.Object AS Feeder,
                O.Name AS FeederName,
                R.TagNumber AS TagNumber,
                R.LocationStructure AS LocationStructure,
                R.TagSentDate AS TagSentDate,
                R.LocationStreet AS LocationStreet,
                R.TagSentBy AS TagSentBy,
                R.Phases AS Phases,
                R.BrassTag AS BrassTag,
                R.PlasticTag AS PlasticTag,
                R.TagNotes AS TagNotes,
                R.ExpirationDate AS ExpirationDate,
                R.WarningDate AS WarningDate
            FROM UDB_Object O, UDB_Grouping G, FMS_RegTag R
            WHERE O.Type = 40
              AND O.Name NOT LIKE '*OBSOLETE'
              AND O.Object = G.Member
              AND G.Relationship = 52
              AND G.GroupingType = 4
              AND O.Object = R.Feeder
            ORDER BY Division, FeederName, TagSentDate";

        // From RegisteredTags.vb:LoadRegTags — filtered by divisions
        // Division list is injected via string format — caller must validate as integers
        public const string RegisteredTagsFiltered = @"
            SELECT G.Grouping AS Division,
                O.Object AS Feeder,
                O.Name AS FeederName,
                R.TagNumber AS TagNumber,
                R.LocationStructure AS LocationStructure,
                R.TagSentDate AS TagSentDate,
                R.LocationStreet AS LocationStreet,
                R.TagSentBy AS TagSentBy,
                R.Phases AS Phases,
                R.BrassTag AS BrassTag,
                R.PlasticTag AS PlasticTag,
                R.TagNotes AS TagNotes,
                R.ExpirationDate AS ExpirationDate,
                R.WarningDate AS WarningDate
            FROM UDB_Grouping G, UDB_Object O, FMS_RegTag R
            WHERE G.Grouping IN ({0})
              AND G.Relationship = 52
              AND G.MemberType = 40
              AND G.Member = O.Object
              AND O.Object = R.Feeder
            ORDER BY Division, FeederName, TagSentDate";

        // ═══════════════════════════════════════════════════════════════════
        // Step 2: Feeder Reports
        // SQL: EXTRACTED from OpenROAD cac.dmt + cac_include_scripts.dmt
        // MgtRpt_SelectClause (cac_include_scripts.dmt:L3837) builds OutageWhereClause and CardFilterWhereClause
        // ═══════════════════════════════════════════════════════════════════

        // SQL: EXTRACTED from cac.dmt:Load_FeederActivityReport (L71616)
        // Core query: 4-way UNION (Active+3G+Archive+Archive3G)
        // Returns: CardClassName, Card, CutOut, DivisionName — counted in-app as matrix
        // Outage type: {0}=CutOut clause, CardFilter: {1}=card filter, Divisions: {2}
        // Constants: Interaction$RatedAs=53, Type$IsoCard=10111, Type$CardClassTest=20178,
        //   Card$PurgeActive=53, Type$PortionCard=20225
        public const string FeederActivityByDivision = @"
            SELECT C.CardClassName, C.Card, C.CutOut,
                   O.PrimaryGroupingName AS DivisionName
            FROM   FMS_Card C,
                   TFMS_CardToObject CTO,
                   Udb_Object OO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = OO.Object
              AND  OO.PrimaryGrouping = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT C.CardClassName, C.Card, C.CutOut,
                   O.PrimaryGroupingName
            FROM   FMS_Card C,
                   TFMS_CardToObject CTO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT C.CardClassName, C.Card, C.CutOut,
                   O.PrimaryGroupingName
            FROM   FMS_ArchiveCard C,
                   TFMS_ArchiveCardToObject CTO,
                   Udb_Object OO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = OO.Object
              AND  OO.PrimaryGrouping = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT C.CardClassName, C.Card, C.CutOut,
                   O.PrimaryGroupingName
            FROM   FMS_ArchiveCard C,
                   TFMS_ArchiveCardToObject CTO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = O.Object
              AND  O.PrimaryGrouping IN ({2})
            ORDER BY CardClassName";

        // SQL: EXTRACTED from cac.dmt:Load_FeederHistoryData (L73203)
        // Same query structure as Activity but returns operating step data per card
        // Uses same MgtRpt_SelectClause for OutageWhereClause + CardFilterWhereClause
        // Output: Card, DivisionName, FeederName, CardClassName, CutOut, CutIn, etc.
        // Then per-card operating steps loaded from FMS_OperatingStepStatus
        // This is too complex for a single query — needs Repository logic to assemble
        public const string FeederHistoryCards = @"
            SELECT DISTINCT C.Card, O.PrimaryGrouping AS Division,
                   O.PrimaryGroupingName AS DivisionName,
                   O.Description AS SubstationName,
                   C.Feeder, C.FeederName,
                   C.CardClass, C.CardClassName,
                   C.OpenAutoPlus, C.Activated,
                   C.CutOut, C.CutIn, C.Closed, C.Status,
                   C.TV_Bogey
            FROM   FMS_Card C,
                   TFMS_CardToObject CTO,
                   Udb_Object OO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = OO.Object
              AND  OO.PrimaryGrouping = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT DISTINCT C.Card, O.PrimaryGrouping,
                   O.PrimaryGroupingName, O.Description,
                   C.Feeder, C.FeederName,
                   C.CardClass, C.CardClassName,
                   C.OpenAutoPlus, C.Activated,
                   C.CutOut, C.CutIn, C.Closed, C.Status,
                   C.TV_Bogey
            FROM   FMS_Card C,
                   TFMS_CardToObject CTO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT DISTINCT C.Card, O.PrimaryGrouping,
                   O.PrimaryGroupingName, O.Description,
                   C.Feeder, C.FeederName,
                   C.CardClass, C.CardClassName,
                   C.OpenAutoPlus, C.Activated,
                   C.CutOut, C.CutIn, C.Closed, C.Status,
                   C.TV_Bogey
            FROM   FMS_ArchiveCard C,
                   TFMS_ArchiveCardToObject CTO,
                   Udb_Object OO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = OO.Object
              AND  OO.PrimaryGrouping = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT DISTINCT C.Card, O.PrimaryGrouping,
                   O.PrimaryGroupingName, O.Description,
                   C.Feeder, C.FeederName,
                   C.CardClass, C.CardClassName,
                   C.OpenAutoPlus, C.Activated,
                   C.CutOut, C.CutIn, C.Closed, C.Status,
                   C.TV_Bogey
            FROM   FMS_ArchiveCard C,
                   TFMS_ArchiveCardToObject CTO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = O.Object
              AND  O.PrimaryGrouping IN ({2})
            ORDER BY FeederName, Card";

        // SQL: EXTRACTED from cac.dmt:Load_FeederHistoryData — operating steps per card
        // Constants: Type$OperatingStepStatus (SuperType for step types)
        public const string FeederHistoryOperatingSteps = @"
            SELECT OS.Card, OS.OperatingStep, OS.OperatingStepName,
                   OS.StartTime, OS.EndTime, OS.DurationMins
            FROM   FMS_OperatingStepStatus OS,
                   Udb_ExtendedType ET
            WHERE  OS.Card = ?
              AND  OS.OperatingStep = ET.Type
              AND  ET.SuperType = 10132
            ORDER BY OS.OperatingStep";

        // Archive variant
        public const string FeederHistoryOperatingStepsArchive = @"
            SELECT OS.Card, OS.OperatingStep, OS.OperatingStepName,
                   OS.StartTime, OS.EndTime, OS.DurationMins
            FROM   FMS_ArchiveOperatingStep OS,
                   Udb_ExtendedType ET
            WHERE  OS.Card = ?
              AND  OS.OperatingStep = ET.Type
              AND  ET.SuperType = 10132
            ORDER BY OS.OperatingStep";

        // SQL: EXTRACTED from cac.dmt:Load_FeederMilestoneData (L75100)
        // Active open cards with milestone timing
        // Constants: Card$Closed (status threshold), Type$Feeder=40
        public const string FeederMilestoneCards = @"
            SELECT DISTINCT C.Card, C.SubstationName,
                   C.Feeder, C.FeederName,
                   IFNULL(C.Cutout,'') AS CutOut,
                   IFNULL(C.Cutin,'') AS CutIn,
                   IFNULL(C.OpenAutoPlus,'') AS OpenAutoPlus,
                   C.EstTimeInService,
                   C.CardClass, C.CardClassName, C.TV_Bogey
            FROM   FMS_Card C,
                   TFMS_CardToObject CTO,
                   Udb_Object O,
                   Udb_Object O2
            WHERE  C.CutOut IS NOT NULL AND C.Cutout <> ''
              AND  C.Cutin IS NULL
              AND  C.Status < 50
              AND  C.Card = CTO.Card
              AND  CTO.Object = O2.Object
              AND  O2.PrimaryGrouping = O.Object
              AND  O.PrimaryGrouping IN ({0})
            UNION
            SELECT DISTINCT C.Card, C.SubstationName,
                   C.Feeder, C.FeederName,
                   IFNULL(C.Cutout,''), IFNULL(C.Cutin,''),
                   IFNULL(C.OpenAutoPlus,''),
                   C.EstTimeInService,
                   C.CardClass, C.CardClassName, C.TV_Bogey
            FROM   FMS_Card C,
                   TFMS_CardToObject CTO,
                   Udb_Object O
            WHERE  C.CutOut IS NOT NULL AND C.Cutout <> ''
              AND  C.Cutin IS NULL
              AND  C.Status < 50
              AND  C.Card = CTO.Card
              AND  CTO.Object = O.Object
              AND  O.PrimaryGrouping IN ({0})
            ORDER BY SubstationName, FeederName";

        // Milestone operating steps per card
        public const string FeederMilestoneSteps = @"
            SELECT OS.OperatingStep, OS.OperatingStepName,
                   OS.StartTime, OS.EndTime, OS.DurationMins,
                   T.Description AS StepDescription
            FROM   FMS_OperatingStepStatus OS,
                   Udb_ExtendedType ET,
                   Udb_Type T
            WHERE  OS.Card = ?
              AND  OS.OperatingStep = ET.Type
              AND  ET.SuperType = 10132
              AND  ET.Type = T.Type";

        // Milestone system parameters (TV Bogey settings)
        public const string FeederMilestoneBogeyParams = @"
            SELECT TM_BogeyEnabled FROM FMS_SystemParameters";

        public const string FeederMilestoneBogeyForecast = @"
            SELECT B.Forecast, B.DayAhead
            FROM   TV_BogeyHistory B
            WHERE  B.LogDate >= date_trunc('day', date('NOW'))
              AND  B.LogDate = (SELECT IFNULL(MAX(LogDate),'')
                                FROM TV_BogeyHistory)";

        // SQL: EXTRACTED from cac.dmt:LoadOutageFrequencyData (cac_include_scripts.dmt line after L116583)
        // Gets all outage cards per region/division for frequency counting
        // Constants: Card$Purge=55, Type$SCHD=20000, Type$WR=20001(card),
        //   Type$ISO=20098, Type$PortionCard=20225, Interaction$RatedAs=53,
        //   Object$ATSLoad13kv/33kv = specific objects excluded
        // Division filter: {0}=start, {1}=end, {2}=division list
        public const string FeederOutageCards = @"
            SELECT DISTINCT C.Card, C.FeederName, 1 AS Outages
            FROM   FMS_Card C,
                   TFMS_CardToObject CTO,
                   Udb_Object O,
                   Udb_Object OO,
                   Udb_Grouping G,
                   Udb_Rating R
            WHERE  C.CutOut <= '{1}' AND C.CutOut >= '{0}'
              AND  C.Status < 55
              AND  (C.CardClass = 20000 OR C.CardClass = 20001)
              AND  C.TypeOfCard <> 20098
              AND  C.TypeOfCard <> 20225
              AND  C.Card = CTO.Card
              AND  CTO.Object = G.Member
              AND  G.Relationship = 53
              AND  G.Grouping = R.Object
              AND  R.Normal > 4
              AND  G.Member = OO.Object
              AND  OO.PrimaryGrouping = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT DISTINCT C.Card, C.FeederName, 1
            FROM   FMS_Card C,
                   TFMS_CardToObject CTO,
                   Udb_Object O,
                   Udb_Grouping G,
                   Udb_Rating R
            WHERE  C.CutOut <= '{1}' AND C.CutOut >= '{0}'
              AND  C.Status < 55
              AND  (C.CardClass = 20000 OR C.CardClass = 20001)
              AND  C.TypeOfCard <> 20098
              AND  C.TypeOfCard <> 20225
              AND  C.Card = CTO.Card
              AND  CTO.Object = G.Member
              AND  G.Relationship = 53
              AND  G.Grouping = R.Object
              AND  R.Normal > 4
              AND  G.Member = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT DISTINCT C.Card, C.FeederName, 1
            FROM   FMS_ArchiveCard C,
                   TFMS_ArchiveCardToObject CTO,
                   Udb_Object O,
                   Udb_Object OO,
                   Udb_Grouping G,
                   Udb_Rating R
            WHERE  C.CutOut <= '{1}' AND C.CutOut >= '{0}'
              AND  C.Status < 55
              AND  (C.CardClass = 20000 OR C.CardClass = 20001)
              AND  C.TypeOfCard <> 20098
              AND  C.TypeOfCard <> 20225
              AND  C.Card = CTO.Card
              AND  CTO.Object = G.Member
              AND  G.Relationship = 53
              AND  G.Grouping = R.Object
              AND  R.Normal > 4
              AND  G.Member = OO.Object
              AND  OO.PrimaryGrouping = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT DISTINCT C.Card, C.FeederName, 1
            FROM   FMS_ArchiveCard C,
                   TFMS_ArchiveCardToObject CTO,
                   Udb_Object O,
                   Udb_Grouping G,
                   Udb_Rating R
            WHERE  C.CutOut <= '{1}' AND C.CutOut >= '{0}'
              AND  C.Status < 55
              AND  (C.CardClass = 20000 OR C.CardClass = 20001)
              AND  C.TypeOfCard <> 20098
              AND  C.TypeOfCard <> 20225
              AND  C.Card = CTO.Card
              AND  CTO.Object = G.Member
              AND  G.Relationship = 53
              AND  G.Grouping = R.Object
              AND  R.Normal > 4
              AND  G.Member = O.Object
              AND  O.PrimaryGrouping IN ({2})
            ORDER BY FeederName";

        // Total feeders per division (for frequency index calculation)
        public const string FeederOutageTotalFeeders = @"
            SELECT COUNT(DISTINCT G.Member) AS TotalFeeders
            FROM   UDB_Grouping G,
                   UDB_Object O,
                   UDB_Rating R
            WHERE  G.Relationship = 53
              AND  G.Grouping = R.Object
              AND  R.Normal > 4
              AND  G.Member = O.Object
              AND  O.PrimaryGrouping IN ({0})";

        // SQL: Feeder Restoration reuses Load_FeederHistoryData (same queries)
        // See: fms_online.dmt:L3243 — forces DivisionName='all', loads all history,
        // then calls Calc_FeederHistoryTotals per division for averages
        // Repository will reuse FeederHistoryCards + FeederHistoryOperatingSteps queries

        // ═══════════════════════════════════════════════════════════════════
        // Step 3: Equipment/Facility Reports
        // SQL: EXTRACTED from OpenROAD cac.dmt procedures — needs Ingres schema validation
        // ═══════════════════════════════════════════════════════════════════

        // SQL: EXTRACTED from cac.dmt:Load_FailedHiPotFeeders (line 79080)
        // Constants: Type$Feeder=40, Interaction$MemberOf=52, Type$Network=10136,
        //   Interaction$RatedAs=53, Company$ConEdison=20001
        public const string FailedHiPotFeeders = @"
            SELECT O2.Object, O2.Name, O3.PrimaryGrouping
            FROM   UDB_Grouping G1,
                   UDB_Grouping G2,
                   UDB_Object O1,
                   UDB_Object O2,
                   UDB_Object O3,
                   UDB_Rating R
            WHERE  G1.MemberType = 40
              AND  G1.Relationship = 52
              AND  G1.GroupingType = 10136
              AND  G1.Grouping = O1.Object
              AND  O1.PositionX >= 0.2
              AND  G1.Member = G2.Member
              AND  G2.Relationship = 53
              AND  G2.Grouping = R.Object
              AND  (R.Normal > 4 AND R.Normal < 33)
              AND  O2.PrimaryGrouping = O3.Object
              AND  O3.PrimaryGrouping <> 20001
              AND  G1.Member = O2.Object
              AND  O2.Object NOT IN (SELECT Feeder
                                     FROM   FMS_HighPotHistory
                                     WHERE  FRATestFailed = 0
                                       AND  FailedDuration >= 5
                                       AND  TestDate > (Date('now') - '3 years'))
            ORDER BY 3, 2";

        // SQL: EXTRACTED from cac.dmt:Load_HighPotHistory (line 79782)
        // Filter=1: latest passed test per feeder; Filter!=1: all tests in date range
        // Constants: Interaction$MemberOf=52, Type$Substation=5, Type$Network=10136,
        //   Interaction$NonNetworkMemberOf=10454
        // Division filter list is injected — caller must validate as integers
        public const string HiPotHistoryLatestPassed = @"
            SELECT S.PrimaryGroupingName AS DivisionName,
                   S.Description AS SubstationName,
                   N.Description AS NetworkName,
                   H.FeederName,
                   H.Feeder,
                   H.TestDate,
                   H.CardType,
                   H.HighPotType,
                   H.TestTypeKV,
                   H.Duration,
                   H.FRATestFailed
            FROM   FMS_HighPotHistory H,
                   UDB_Grouping SG,
                   UDB_Object S,
                   UDB_Grouping NG,
                   UDB_Object N
            WHERE  H.FRATestFailed = 0
              AND  H.TestDate = (SELECT MAX(F.TestDate)
                                 FROM   FMS_HighPotHistory F
                                 WHERE  F.Feeder = H.Feeder
                                   AND  F.FRATestFailed = 0)
              AND  H.Feeder = SG.Member
              AND  SG.RelationShip = 52
              AND  SG.GroupingType = 5
              AND  SG.Grouping = S.Object
              AND  H.Feeder = NG.Member
              AND  NG.RelationShip = 52
              AND  NG.GroupingType IN (10136, 10454)
              AND  NG.Grouping = N.Object
              AND  S.PrimaryGrouping IN ({0})
            ORDER BY 1 ASC, 2 ASC, 3 ASC, 4 ASC, 6 DESC";

        // SQL: EXTRACTED from cac.dmt:Load_HighPotHistory (line 79782) — all tests variant
        public const string HiPotHistoryAllTests = @"
            SELECT S.PrimaryGroupingName AS DivisionName,
                   S.Description AS SubstationName,
                   N.Description AS NetworkName,
                   H.FeederName,
                   H.Feeder,
                   H.TestDate,
                   H.CardType,
                   H.HighPotType,
                   H.TestTypeKV,
                   H.Duration,
                   H.FRATestFailed
            FROM   FMS_HighPotHistory H,
                   UDB_Grouping SG,
                   UDB_Object S,
                   UDB_Grouping NG,
                   UDB_Object N
            WHERE  H.TestDate BETWEEN '{0}' AND '{1}'
              AND  H.Feeder = SG.Member
              AND  SG.RelationShip = 52
              AND  SG.GroupingType = 5
              AND  SG.Grouping = S.Object
              AND  H.Feeder = NG.Member
              AND  NG.RelationShip = 52
              AND  NG.GroupingType IN (10136, 10454)
              AND  NG.Grouping = N.Object
              AND  S.PrimaryGrouping IN ({2})
            ORDER BY 1 ASC, 2 ASC, 3 ASC, 4 ASC, 6 DESC";

        // Additional filter clauses appended dynamically:
        // By Feeder: " AND H.Feeder = {feederId}"
        // By Substation: " AND S.Object = {substationId}"
        // By Network: " AND N.Object = {networkId} AND S.PrimaryGrouping IN ({divisionList})"
        // Default (no specific filter): " AND S.PrimaryGrouping IN ({divisionList})"

        // SQL: EXTRACTED from cac.dmt:Load_ManholeActivity (line 72237)
        // Takeout records from archive cards
        // Constants: Job$TakeoutInt=0, Job$RestoreInt=1, Prompt$SetCurrentlyOpen=10159,
        //   Prompt$ClearCurrentlyOpen=10160, Type$Feeder=40
        //   SuperType IN (20017,10449,22763,20226,22072) = disconnecting manhole equipment types
        // Division filter list is injected — caller must validate as integers
        public const string ManholeActivityTakeout = @"
            SELECT DISTINCT
                   J.TOComplete AS StartTime,
                   C.Card,
                   C.CardClassName,
                   O2.PrimaryGrouping AS Division,
                   O2.PrimaryGroupingName AS DivisionName,
                   C.Feeder,
                   C.FeederName,
                   J.Equip,
                   J.EquipClassName AS EquipTypeName,
                   J.EquipName,
                   JA.Status,
                   O.Comment
            FROM   FMS_ArchiveCard C,
                   TFMS_ArchiveCardToObject CTO,
                   FMS_ArchiveJob J,
                   Udb_ExtendedType ET,
                   FMS_JobAction JA,
                   Udb_Object O,
                   Udb_Object O1,
                   Udb_Object O2
            WHERE  (J.TOComplete BETWEEN '{0}' AND '{1}')
              AND  J.EquipClass = ET.Type
              AND  ET.SuperType IN (20017,10449,22763,20226,22072)
              AND  J.Equip = O.Object
              AND  J.Card = C.Card
              AND  J.JobClass = JA.JobClass
              AND  J.Status = ''
              AND  JA.TORS = 0
              AND  JA.Status IN (10159, 10160)
              AND  C.Card = CTO.Card
              AND  CTO.Type = 40
              AND  CTO.Object = O1.Object
              AND  O1.PrimaryGrouping = O2.Object
              AND  O2.PrimaryGrouping IN ({2})";

        // SQL: EXTRACTED from cac.dmt:Load_ManholeActivity — restore records
        public const string ManholeActivityRestore = @"
            SELECT DISTINCT
                   J.RSComplete AS StartTime,
                   C.Card,
                   C.CardClassName,
                   O2.PrimaryGrouping AS Division,
                   O2.PrimaryGroupingName AS DivisionName,
                   C.Feeder,
                   C.FeederName,
                   J.Equip,
                   J.EquipClassName AS EquipTypeName,
                   J.EquipName,
                   JA.Status,
                   O.Comment
            FROM   FMS_ArchiveCard C,
                   TFMS_ArchiveCardToObject CTO,
                   FMS_ArchiveJob J,
                   Udb_ExtendedType ET,
                   FMS_JobAction JA,
                   Udb_Object O,
                   Udb_Object O1,
                   Udb_Object O2
            WHERE  (J.RSComplete BETWEEN '{0}' AND '{1}')
              AND  J.EquipClass = ET.Type
              AND  ET.SuperType IN (20017,10449,22763,20226,22072)
              AND  J.Equip = O.Object
              AND  J.Card = C.Card
              AND  J.JobClass = JA.JobClass
              AND  J.Status = ''
              AND  JA.TORS = 1
              AND  JA.Status IN (10159, 10160)
              AND  C.Card = CTO.Card
              AND  CTO.Type = 40
              AND  CTO.Object = O1.Object
              AND  O1.PrimaryGrouping = O2.Object
              AND  O2.PrimaryGrouping IN ({2})";

        // Full manhole activity = Takeout UNION Restore, ORDER BY DivisionName, FeederName, StartTime
        // Post-processing: Status 10159 → 'Open', Status 10160 → 'Close'

        // SQL: EXTRACTED from cac.dmt:Load_ManholeList (line 72427)
        // All manhole equipment by division (non-operated list)
        // Constants: Interaction$MemberOf=52, Type$Feeder=40
        //   SuperType IN (20017,10449,22763,20226,22072)
        public const string ManholeEquipList = @"
            SELECT DISTINCT
                   O2.PrimaryGrouping AS Division,
                   O2.PrimaryGroupingName AS DivisionName,
                   O1.Object AS Feeder,
                   O1.Name AS FeederName,
                   O.Object AS Equip,
                   O.TypeName AS EquipTypeName,
                   O.Name AS EquipName,
                   O.Comment
            FROM   Udb_ExtendedType ET,
                   Udb_Grouping G,
                   Udb_Object O,
                   Udb_Object O1,
                   Udb_Object O2
            WHERE  O.Type = ET.Type
              AND  ET.SuperType IN (20017,10449,22763,20226,22072)
              AND  O.Object = G.Member
              AND  G.Relationship = 52
              AND  G.GroupingType = 40
              AND  G.Grouping = O1.Object
              AND  O1.PrimaryGrouping = O2.Object
              AND  O2.PrimaryGrouping IN ({0})
            ORDER BY DivisionName, FeederName";

        // SQL: EXTRACTED from cac.dmt:LoadMTALines (line 70386)
        // Get MTA lines for feeder(s)
        // Constants: Interaction$MemberOf=52, Type$HTVStd=20122, Type$MTALine=10475
        // Feeder list is injected — caller must validate as integers
        public const string MTALinesByFeeder = @"
            SELECT DISTINCT O.Object, O.Name, O.Description
            FROM   UDB_Grouping G1,
                   UDB_Grouping G2,
                   UDB_ExtendedType ET,
                   UDB_Object O
            WHERE  G1.Grouping IN ({0})
              AND  G1.RelationShip = 52
              AND  G1.MemberType = ET.Type
              AND  ET.SuperType = 20122
              AND  G1.Member = G2.Member
              AND  G2.RelationShip = 52
              AND  G2.GroupingType = 10475
              AND  G2.Grouping = O.Object
            ORDER BY O.Name";

        // SQL: EXTRACTED from cac.dmt:LoadHTVList (line 123032, MTALineClass)
        // Get HTV equipment for a specific MTA line
        // Constants: Interaction$MemberOf=52, Type$Feeder=40, Type$ISOFeeder=10112,
        //   Type$AbstractHTV=10070, Status$CO=10110
        public const string MTALineHTVList = @"
            SELECT G1.Reference AS Sequence,
                   O1.Object AS Equip,
                   O1.Name AS EquipName,
                   G1.MemberType AS EquipClass,
                   S.CurrentlyOpen,
                   G1.Grouping AS PrimaryGrouping,
                   O1.Description AS StationName,
                   O2.Object AS LocationObject,
                   O2.Name AS Feeder,
                   O2.Type AS NetworkType,
                   O2.PrimaryGroupingName AS SubstationName,
                   G3.Grouping AS SourceBkr
            FROM   UDB_Grouping G1,
                   UDB_Grouping G2,
                   UDB_Grouping G3,
                   UDB_Object O1,
                   UDB_Object O2,
                   UDB_Switch S
            WHERE  G1.Grouping = ?
              AND  G1.Relationship = 52
              AND  G1.Member = O1.Object
              AND  O1.Object = G2.Member
              AND  G2.Relationship = 52
              AND  G2.GroupingType IN (40, 10112)
              AND  G2.Grouping = O2.Object
              AND  O1.Object = S.Object
              AND  O1.Object = G3.Member
              AND  G3.Relationship = 52
              AND  G3.GroupingType = 10070
            ORDER BY Sequence";

        // Per-HTV feeder status check (in-service = 1, cut-out = 0)
        // Status$CO=10110
        public const string MTALineFeederStatus = @"
            SELECT 1
            FROM   FMS_ObjectStatus S
            WHERE  S.Object = ?
              AND  S.Status = 10110";

        // Feeder search by name pattern for MTA report
        // Constants: Type$Feeder=40, Type$ISOFeeder=10112
        public const string MTAFeederSearch = @"
            SELECT O.Object
            FROM   UDB_Object O
            WHERE  O.Name LIKE ?
              AND  O.Type IN (40, 10112)
              AND  UPPER(O.TypeName) NOT LIKE '%OBSOLETE%'";

        // ═══════════════════════════════════════════════════════════════════
        // Step 4: Operational Reports
        // SQL: EXTRACTED from OpenROAD cac.dmt
        // ═══════════════════════════════════════════════════════════════════

        // SQL: EXTRACTED from cac.dmt:Load_TvKpi (L77133)
        // 4-way UNION: Active+3G+Archive+Archive3G — same structure as FeederHistory
        // Uses MgtRpt_SelectClause (OutageWhereClause + CardFilterWhereClause)
        // TV_Bogey < 0 = excluded, otherwise included in KPI calculation
        // Duration computed in-app from CutOut/CutIn/EstTimeInService or SOA_Log override
        // {0}=OutageWhereClause, {1}=CardFilterWhereClause, {2}=Division list
        public const string TvKpiCards = @"
            SELECT DISTINCT
                   0 AS IsArchive,
                   C.Card, O.PrimaryGrouping AS Division,
                   O.PrimaryGroupingName AS DivisionName,
                   O.Description AS SubstationName,
                   C.CutOut,
                   IFNULL(C.CutIn,'') AS CutIn,
                   IFNULL(C.EstTimeInService,'') AS EstTimeInService,
                   C.Feeder, C.FeederName,
                   C.CardClass, C.CardClassName,
                   C.TV_Bogey
            FROM   FMS_Card C,
                   TFMS_CardToObject CTO,
                   Udb_Object OO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = OO.Object
              AND  OO.PrimaryGrouping = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT DISTINCT
                   0, C.Card, O.PrimaryGrouping,
                   O.PrimaryGroupingName, C.SubstationName,
                   C.CutOut, IFNULL(C.CutIn,''),
                   IFNULL(C.EstTimeInService,''),
                   C.Feeder, C.FeederName,
                   C.CardClass, C.CardClassName, C.TV_Bogey
            FROM   FMS_Card C,
                   TFMS_CardToObject CTO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT DISTINCT
                   1, C.Card, O.PrimaryGrouping,
                   O.PrimaryGroupingName, O.Description,
                   C.CutOut, IFNULL(C.CutIn, C.Closed),
                   IFNULL(C.EstTimeInService,''),
                   C.Feeder, C.FeederName,
                   C.CardClass, C.CardClassName, C.TV_Bogey
            FROM   FMS_ArchiveCard C,
                   TFMS_ArchiveCardToObject CTO,
                   Udb_Object OO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = OO.Object
              AND  OO.PrimaryGrouping = O.Object
              AND  O.PrimaryGrouping IN ({2})
            UNION
            SELECT DISTINCT
                   1, C.Card, O.PrimaryGrouping,
                   O.PrimaryGroupingName, C.SubstationName,
                   C.CutOut, IFNULL(C.CutIn, C.Closed),
                   IFNULL(C.EstTimeInService,''),
                   C.Feeder, C.FeederName,
                   C.CardClass, C.CardClassName, C.TV_Bogey
            FROM   FMS_ArchiveCard C,
                   TFMS_ArchiveCardToObject CTO,
                   Udb_Object O,
                   Udb_Grouping GR,
                   Udb_Rating R
            WHERE  {0}
              AND  {1}
              AND  CTO.Object = O.Object
              AND  O.PrimaryGrouping IN ({2})
            ORDER BY FeederName, Card";

        // TV KPI duration overrides from SOA_Log
        public const string TvKpiLogOverrides = @"
            SELECT L.Card, L.Old AS Reason, L.New AS DurationMinutes, L.Time
            FROM   SOA_Log L
            WHERE  L.Time > @StartDate
              AND  LOWERCASE(L.Item) = 'tv update duration'
            UNION
            SELECT L.Card, L.Old, L.New, L.Time
            FROM   FMS_ArchiveLog L
            WHERE  L.Time > @StartDate
              AND  LOWERCASE(L.Item) = 'tv update duration'
            ORDER BY Time DESC";

        // SQL: EXTRACTED from cac.dmt:LoadByDivision (L148788)
        // Process Automation — loads FMS_AutomationBlock grouped by day/division
        public const string ProcessAutomationBlocks = @"
            SELECT Card, Division, Block, BlockSeq, BlockEnd, BlockStart,
                   BlockStatus, BlockStopped, BlockTitle,
                   InitiatingDO, InitTime, SendTo, StopReason
            FROM   FMS_AutomationBlock
            WHERE  InitTime >= @StartDate
              AND  InitTime <= @EndDate
            ORDER BY InitTime, BlockSeq";

        // SQL: EXTRACTED from cac.dmt:LoadYellow (L242476)
        // Warning Summary — loads SOA_Warning by date range, grouped by desk/shift
        // WarningType: 0=Yellow, 1=Override; dynamic WHERE built from params
        // {0}=dynamic WHERE clause (LogDate range + WarningType + optional Operator)
        public const string WarningSummaryByDesk = @"
            SELECT UserName, LogDate
            FROM   SOA_Warning
            WHERE  LogDate >= @StartDate
              AND  LogDate < @EndDate
              AND  WarningType = @WarningType
            ORDER BY LogDate";

        // With operator filter
        public const string WarningSummaryByDeskFiltered = @"
            SELECT UserName, LogDate
            FROM   SOA_Warning
            WHERE  LogDate >= @StartDate
              AND  LogDate < @EndDate
              AND  WarningType = @WarningType
              AND  Operator = @Operator
            ORDER BY LogDate";

        // SQL: EXTRACTED from cac.dmt:LoadDO (L242758)
        // Warning Summary by DO — counts grouped by operator and warning type
        public const string WarningSummaryByDO = @"
            SELECT Operator, OperatorName, WarningType, COUNT(WarningType) AS Total
            FROM   SOA_Warning
            WHERE  LogDate >= @StartDate
              AND  LogDate <= @EndDate
              AND  Operator > 0
              AND  (WarningType < 2 OR (WarningType = 3 AND TwoOpConfirmEvent <> ''))
            GROUP BY Operator, OperatorName, WarningType
            ORDER BY Operator";

        // Warning DO threshold data
        public const string WarningSummaryThresholds = @"
            SELECT S.Object AS Operator, S.WarningTime AS LastUpdate
            FROM   FMS_SpeedbumpCnt S
            WHERE  S.Object = @Operator
              AND  S.WarningTime >= @StartDate
              AND  S.WarningTime <= @EndDate";

        // SQL: EXTRACTED from cac.dmt:LoadDO (L130168) — OpActivity_ASE
        // Operation Activity by DO — SOA_Activity grouped by operator/application
        public const string OperationActivityByApplication = @"
            SELECT Operator, OperatorName, Application, COUNT(Application) AS Moves
            FROM   SOA_Activity
            WHERE  LogDate >= @StartDate
              AND  LogDate <= @EndDate
            GROUP BY Operator, OperatorName, Application
            ORDER BY Operator";

        // Operation Activity — issued/completed counts
        public const string OperationActivityByIssueComplete = @"
            SELECT Operator, OperatorName, IssueComplete, COUNT(IssueComplete) AS Moves
            FROM   SOA_Activity
            WHERE  LogDate >= @StartDate
              AND  LogDate <= @EndDate
              AND  IssueComplete <> 0
            GROUP BY Operator, OperatorName, IssueComplete
            ORDER BY Operator";

        // Operation Activity — work permit counts
        public const string OperationActivityByPermit = @"
            SELECT Operator, OperatorName, COUNT(WorkPermit) AS Moves
            FROM   SOA_Activity
            WHERE  LogDate >= @StartDate
              AND  LogDate <= @EndDate
              AND  WorkPermit = 1
            GROUP BY Operator, OperatorName, WorkPermit
            ORDER BY Operator";

        // Operation Activity — by desk (LoadActivity)
        // Returns Division, TypeOfDay, ShiftTime, Moves
        public const string OperationActivityByDesk = @"
            SELECT Division, TypeOfDay, ShiftTime, COUNT(Application) AS Moves
            FROM   SOA_Activity
            WHERE  LogDate >= @StartDate
              AND  LogDate <= @EndDate
              AND  Application = @Application
            GROUP BY Division, TypeOfDay, ShiftTime";

        // SQL: EXTRACTED from cac.dmt:Load_DOScheduledWorkData (L79182)
        // DO Scheduled Work — loads from SOA_Schd_Work_Rpt pre-computed table
        public const string ScheduledWorkData = @"
            SELECT SW.Application, SW.Archive, SW.Card, SW.SwitchingItem,
                   SW.CardClass, SW.CardClassName, SW.CardName,
                   SW.Cutout, SW.DateValue, SW.DOName, SW.DOObject,
                   SW.Gap_Limit, SW.Gap_Update, SW.Tot_Seconds
            FROM   SOA_Schd_Work_Rpt SW
            WHERE  SW.DateValue BETWEEN @StartDate AND @EndDate
            ORDER BY DateValue, Card";

        // Scheduled Work — gap configuration
        public const string ScheduledWorkGap = @"
            SELECT Gap_Limit, Gap_Update
            FROM   SOA_Schd_Work_Gap";

        // ═══════════════════════════════════════════════════════════════════
        // Step 7: TOMS/TLS Parameter Variants
        // SQL: Same as above with Application filter added
        // Schema verified: SOA_Warning.application varchar(4), SOA_Activity.application varchar(4),
        //   SOA_Schd_Work_Rpt.application varchar(4) — all store 'TFMS','FMS','SLC','TLS'
        // ═══════════════════════════════════════════════════════════════════

        // SQL: VERIFIED — same as WarningSummaryByDesk + Application filter
        public const string WarningSummaryByDeskByApp = @"
            SELECT UserName, LogDate
            FROM   SOA_Warning
            WHERE  LogDate >= @StartDate
              AND  LogDate < @EndDate
              AND  WarningType = @WarningType
              AND  Application = @AppName
            ORDER BY LogDate";

        // SQL: VERIFIED — same as WarningSummaryByDO + Application filter
        public const string WarningSummaryByDOByApp = @"
            SELECT Operator, OperatorName, WarningType, COUNT(WarningType) AS Total
            FROM   SOA_Warning
            WHERE  LogDate >= @StartDate
              AND  LogDate <= @EndDate
              AND  Operator > 0
              AND  Application = @AppName
              AND  (WarningType < 2 OR (WarningType = 3 AND TwoOpConfirmEvent <> ''))
            GROUP BY Operator, OperatorName, WarningType
            ORDER BY Operator";

        // SQL: VERIFIED — same as OperationActivityByDesk with string Application filter
        public const string OperationActivityByDeskByApp = @"
            SELECT Division, TypeOfDay, ShiftTime, COUNT(Application) AS Moves
            FROM   SOA_Activity
            WHERE  LogDate >= @StartDate
              AND  LogDate <= @EndDate
              AND  Application = @AppName
            GROUP BY Division, TypeOfDay, ShiftTime";

        // SQL: VERIFIED — same as ScheduledWorkData + Application filter
        public const string ScheduledWorkDataByApp = @"
            SELECT SW.Application, SW.Archive, SW.Card, SW.SwitchingItem,
                   SW.CardClass, SW.CardClassName, SW.CardName,
                   SW.Cutout, SW.DateValue, SW.DOName, SW.DOObject,
                   SW.Gap_Limit, SW.Gap_Update, SW.Tot_Seconds
            FROM   SOA_Schd_Work_Rpt SW
            WHERE  SW.DateValue BETWEEN @StartDate AND @EndDate
              AND  SW.Application = @AppName
            ORDER BY DateValue, Card";

        // ═══════════════════════════════════════════════════════════════════
        // Step 5: SOA Reports
        // SQL: EXTRACTED from OpenROAD cac.dmt
        // Schema verified against: db-scripts/FMS/fms_d1_schema.sql (FMS_WPProtectionResult),
        //   db-scripts/FMS/table_fms_disseminationfile.sql (FMS_DissFileRecord, FMS_DissFileDOXRef),
        //   db-scripts/IR/table_ir_fodorder.sql (IR_FODOrder, IR_FODOrderJobs),
        //   db-scripts/IR/table_ir_operatingorder.sql (IR_OperatingOrder)
        // ═══════════════════════════════════════════════════════════════════

        // SQL: EXTRACTED from cac.dmt:Load_FCRProtectionResult (L79750)
        // Table: FMS_WPProtectionResult — columns verified against fms_d1_schema.sql:L5020
        public const string FCRProtectionResults = @"
            SELECT Operator, OperatorName, Card, FeederName,
                   WorkPermit, TOMove, IssueDate,
                   ProtectionResult, DiffDistance
            FROM   FMS_WPProtectionResult
            WHERE  IssueDate BETWEEN @StartDate AND @EndDate
            ORDER BY OperatorName, IssueDate, FeederName";

        // FCR protection — actual protections per work permit
        // Source: cac.dmt LoadProtections method (called per WPList row)
        public const string FCRActualProtections = @"
            SELECT ActualEquip AS Object, O.Name
            FROM   FMS_WPProtectionActual A,
                   Udb_Object O
            WHERE  A.WorkPermit = @WorkPermit
              AND  A.IssueDate = @IssueDate
              AND  A.ActualEquip = O.Object
            ORDER BY O.Name";

        // FCR protection — suggested protections per work permit
        public const string FCRSuggestedProtections = @"
            SELECT SuggestedEquip AS Object, O.Name
            FROM   FMS_WPProtectionSuggested S,
                   Udb_Object O
            WHERE  S.WorkPermit = @WorkPermit
              AND  S.IssueDate = @IssueDate
              AND  S.SuggestedEquip = O.Object
            ORDER BY O.Name";

        // SQL: EXTRACTED from cac.dmt:LoadDissFileList (L56060)
        // Tables: FMS_DissFileRecord, FMS_DissFileDOXRef — verified against table_fms_disseminationfile.sql
        // Filter: 'ACTIVE' = DFR.Status = 1; 'DATE' = LoadDate range
        public const string DisseminationFilesActive = @"
            SELECT DFR.FileID, DFR.Title, DFR.LoadDate, DFR.LoadUserName,
                   DFR.Status, DFR.InactiveDate
            FROM   FMS_DissFileRecord DFR
            WHERE  DFR.Status = 1
            ORDER BY FileID DESC";

        public const string DisseminationFilesByDate = @"
            SELECT DFR.FileID, DFR.Title, DFR.LoadDate, DFR.LoadUserName,
                   DFR.Status, DFR.InactiveDate
            FROM   FMS_DissFileRecord DFR
            WHERE  DFR.LoadDate >= @StartDate
              AND  DFR.LoadDate < @EndDate
            ORDER BY FileID DESC";

        // Dissemination — DO cross-reference per file
        public const string DisseminationDOXRef = @"
            SELECT SQUEEZE(O.Description) AS DOName,
                   DFX.DOObjID, DFX.Status, DFX.ReviewDate
            FROM   FMS_DissFileDOXRef DFX,
                   Udb_Object O
            WHERE  DFX.FileID = @FileID
              AND  DFX.DOObjID = O.Object
            ORDER BY 1 ASC";

        // SQL: EXTRACTED from cac.dmt:LoadOrders (L138863)
        // FOD/SSO Orders for a card — UNION of IR_FODOrder and IR_OperatingOrder
        // Tables verified against table_ir_fodorder.sql and table_ir_operatingorder.sql
        public const string OrderListForCard = @"
            SELECT 'FOD' AS Interface,
                   '' AS SubstationName,
                   FO.IssueTime, FO.OrderNumber,
                   FO.Priority, FO.IssuedByDO,
                   FO.OrderComment AS Comment,
                   0 AS Status, 'See job(s)' AS StatusName
            FROM   IR_FODOrder FO
            WHERE  FO.Card = @Card
            UNION ALL
            SELECT 'SSO',
                   '', IssueTime, OrderNumber,
                   VARCHAR(Priority), IssuedByDO,
                   '', OrderStatus, ''
            FROM   IR_OperatingOrder
            WHERE  Card = @Card
            ORDER BY IssueTime DESC";

        // Orders by date range and status (for the report page)
        // StatusFilter: 0=Outstanding (<=Closed), else by date range
        public const string OrderListByDateRange = @"
            SELECT 'FOD' AS Interface,
                   '' AS SubstationName,
                   FO.IssueTime, FO.OrderNumber,
                   FO.Priority, FO.IssuedByDO,
                   FO.OrderComment AS Comment,
                   FO.OrderStatus AS Status
            FROM   IR_FODOrder FO
            WHERE  FO.IssueTime BETWEEN @StartDate AND @EndDate
            UNION ALL
            SELECT 'SSO', '',
                   OO.IssueTime, OO.OrderNumber,
                   VARCHAR(OO.Priority), OO.IssuedByDO,
                   '', OO.OrderStatus
            FROM   IR_OperatingOrder OO
            WHERE  OO.IssueTime BETWEEN @StartDate AND @EndDate
            ORDER BY IssueTime DESC";
    }
}
