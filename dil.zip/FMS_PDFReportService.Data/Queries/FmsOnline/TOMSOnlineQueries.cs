namespace FMS_PDFReportService.Data.Queries.FmsOnline;

/// <summary>
/// SQL queries for TOMS web reports (Milestone, XA21 Outage, Outage Request).
/// Source: cac.dmt — Load_MilestoneData (L224010), Load_MilestoneHistory (L223400),
/// Load_XA21Outage (L224781), LoadOutageReport (L147521)
/// </summary>
public static class TOMSOnlineQueries
{
    // SQL: RECONSTRUCTED from Load_MilestoneData/Load_MilestoneHistory (cac.dmt L223400-L224700)
    // Main card query — returns raw cards; operating steps loaded per-card from TFMS_OperatingStep
    // Fix applied 2026-09-22 (S28/S29) — FROM/JOIN ported from Verified sibling
    // MilestoneQueries.LoadActiveCardsOutOfService (S10): TFMS_Card has no TypeOfCard/Status/CardClass
    // columns (phantom-column query-prepare failure); those enums live on SOA_ActiveCard/SOA_Card.
    // Division filter moved from Udb_Grouping membership to SOA_ActiveCard.Division per S10 shape.
    public const string MilestoneCards = @"
        SELECT C.Card,
               AC.CardName,
               IFNULL(C.Cutout, '') AS Cutout,
               IFNULL(C.Cutin, '') AS Cutin,
               IFNULL(C.Closed, '') AS Closed,
               C.CardClass,
               C.CardClassName
        FROM   SOA_ActiveCard AC,
               SOA_Card C
        WHERE  C.Card = AC.Card
          AND  AC.Division IN ({0})
          AND  C.CardClass IN ({1})
          {2}
        ORDER BY CardName";

    // No-ORDER-BY variant of MilestoneCards for composing inside LoadMilestoneHistory's UNION.
    // Fix applied 2026-09-22 (E08) — Ingres/ANSI-SQL disallows ORDER BY inside individual UNION
    // operands; MilestoneCards keeps its terminal ORDER BY for standalone LoadMilestone use.
    public const string MilestoneCardsNoOrder = @"
        SELECT C.Card,
               AC.CardName,
               IFNULL(C.Cutout, '') AS Cutout,
               IFNULL(C.Cutin, '') AS Cutin,
               IFNULL(C.Closed, '') AS Closed,
               C.CardClass,
               C.CardClassName
        FROM   SOA_ActiveCard AC,
               SOA_Card C
        WHERE  C.Card = AC.Card
          AND  AC.Division IN ({0})
          AND  C.CardClass IN ({1})
          {2}";

    // Archive cards (same structure, different tables)
    public const string MilestoneCardsArchive = @"
        SELECT C.Card,
               C.FeederNames AS CardName,
               IFNULL(C.Cutout, '') AS Cutout,
               IFNULL(C.Cutin, '') AS Cutin,
               IFNULL(C.Closed, '') AS Closed,
               C.CardClass,
               C.CardClassName
        FROM   TFMS_ArchiveCard C,
               TFMS_ArchiveCardToObject CTO,
               Udb_Grouping G
        WHERE  C.Card = CTO.Card
          AND  CTO.Object = G.Member
          AND  G.Relationship = 52
          AND  G.Grouping IN ({0})
          AND  C.CardClass IN ({1})
          {2}
        ORDER BY CardName";

    // No-ORDER-BY variant of MilestoneCardsArchive for composing inside LoadMilestoneHistory's UNION.
    // Fix applied 2026-09-22 (E08) — see MilestoneCardsNoOrder note above.
    public const string MilestoneCardsArchiveNoOrder = @"
        SELECT C.Card,
               C.FeederNames AS CardName,
               IFNULL(C.Cutout, '') AS Cutout,
               IFNULL(C.Cutin, '') AS Cutin,
               IFNULL(C.Closed, '') AS Closed,
               C.CardClass,
               C.CardClassName
        FROM   TFMS_ArchiveCard C,
               TFMS_ArchiveCardToObject CTO,
               Udb_Grouping G
        WHERE  C.Card = CTO.Card
          AND  CTO.Object = G.Member
          AND  G.Relationship = 52
          AND  G.Grouping IN ({0})
          AND  C.CardClass IN ({1})
          {2}";

    // Current milestone: active out-of-service filter
    // Fix applied 2026-09-22 (S28) — ported Verified sibling S10 literals (AC.TypeOfCard=12003,
    // C.Status<50) against SOA_ActiveCard/SOA_Card; the C.Card = AC.Card join now lives in
    // MilestoneCards/MilestoneCardsNoOrder's WHERE clause so it is not repeated here.
    public const string MilestoneActiveOutOfService = @"
        AND C.CutOut IS NOT NULL
        AND C.Cutout <> ' '
        AND C.Cutin IS NULL
        AND C.Status < 50
        AND AC.TypeOfCard = 12003";

    // Current milestone: active in-service filter
    // Fix applied 2026-09-22 (S29) — same port as S28 (shared inheritance verdict).
    public const string MilestoneActiveInService = @"
        AND C.CutIn IS NOT NULL
        AND C.CutIn <> ' '
        AND C.Status < 50
        AND AC.TypeOfCard = 12003";

    // Operating steps for a single card
    public const string OperatingStepsForCard = @"
        SELECT OS.OperatingStep,
               OS.OperatingStepName,
               OS.StartTime,
               OS.EndTime,
               OS.DurationMins
        FROM   TFMS_OperatingStep OS
        WHERE  OS.Card = @Card";

    // Report card types (used when CardType = "all")
    public const string ReportCardTypes = @"
        SELECT DISTINCT CardClass
        FROM   SOA_Card
        WHERE  CardClass IN (
            SELECT Type FROM Udb_ExtendedType WHERE SuperType = 7100
        )";

    // SQL: RECONSTRUCTED from Load_XA21Outage (cac.dmt L224781)
    // Tables: XA21_OutageReport X, Udb_Object S (substation), Udb_Object A (outage object), Udb_Object E (equip)
    public const string XA21Outage = @"
        SELECT S.PrimaryGrouping AS Division,
               S.PrimaryGroupingName AS DivisionName,
               X.OutageRecorded AS Recorded,
               X.OutageType,
               A.Name AS OutageObjectName,
               A.TypeName AS OutageObjectTypeName,
               S.Description AS SubstationName,
               E.Name AS EquipName,
               E.TypeName AS EquipClassName,
               X.DeviceTime
        FROM   XA21_OutageReport X,
               Udb_Object S,
               Udb_Object A,
               Udb_Object E
        WHERE  X.OutageRecorded BETWEEN @StartDate AND @EndDate
          AND  X.Substation = S.Object
          AND  X.OutageObject = A.Object
          AND  X.Equip = E.Object
          {0}
        ORDER BY Division, Recorded, DeviceTime";

    // SQL: RECONSTRUCTED from LoadOutageReport (cac.dmt L147521)
    // Tables: SOA_OutageRequest R, SOA_ORWorkItem W, SOA_OutageRequestPermit P
    // Constants: Order$Closed = value varies by deployment, using status filter
    public const string OutageRequestList = @"
        SELECT DISTINCT
               W.Division,
               R.ORNumber,
               R.Status,
               R.CurrentStatus,
               R.Location,
               R.Title,
               R.SkedOutageDate,
               R.ActualOutageDate,
               R.ActualWorkIssueDate,
               R.SkedStartDate,
               R.ActualStartDate,
               R.SkedReturnDate,
               R.ActualReturnDate,
               R.SkedInserviceDate AS SkedInServiceDate,
               R.ActualInserviceDate AS ActualInServiceDate,
               P.WorkGroup
        FROM   SOA_OutageRequest R,
               SOA_ORWorkItem W,
               SOA_OutageRequestPermit P
        WHERE  R.ORNumber = W.ORNumber
          AND  W.ORNumber = P.ORNumber
          AND  W.WorkItem = P.WorkItem
          {0}
        ORDER BY Division, ORNumber";
}
