namespace FMS_PDFReportService.Data.Queries
{
    /// <summary>
    /// SQL query constants for SLC (Substation Log Card) data retrieval.
    /// Ported from CardSLC_ASE.
    /// </summary>
    public static class SLCQueries
    {
        public const string LoadCardHeader = @"
            SELECT C.Card, C.Substation, C.SubstationName,
                   C.MultipleKVFlag, C.GroundsOn,
                   C.AddressLine1, C.AddressLine2,
                   C.AddressLine3, C.AddressLine4,
                   C.OperatorName, C.OperatorDesk,
                   O.Type AS ObjectType, O.TypeName
            FROM   SLC_Card C,
                   Udb_Object O
            WHERE  C.Card = ? AND
                   C.Substation = O.Object";

        public const string LoadJobs = @"
            SELECT J.Job, SJ.Card, SJ.Seq, J.Status, J.JobClass,
                   J.Equip, J.EquipClass, J.EquipClassName, J.EquipName,
                   SJ.StepPair, J.Grounds, J.MoveType,
                   J.TOMove, J.TOMoveRules, J.TOOperator, J.TOIssued, J.TOComplete,
                   J.GroundOn,
                   J.RSMove, J.RSMoveRules, J.RSOperator, J.RSIssued, J.RSComplete,
                   J.Response, J.MoveBGColor, J.MoveFGColor,
                   SJ.StepLevel, J.MoveCategory,
                   J.ActivityIdentifier, J.Grounds,
                   SJ.SwitchingItem,
                   J.Substation, J.ControlCard
            FROM   SOA_Job J,
                   SOA_JobControl SJ
            WHERE  SJ.Card = ? AND
                   SJ.Job = J.Job AND
                   J.Status <> 'Del'
            ORDER BY SJ.SwitchingItem, SJ.StepPair, SJ.StepLevel, SJ.Seq";

        public const string LoadJobsArchive = @"
            SELECT J.Job, J.Card, J.Seq,
                   J.Status, J.JobClass,
                   J.Equip, J.EquipClass, J.EquipClassName, J.EquipName,
                   J.StepPair, J.MoveType,
                   J.TOMove, J.TOOperator, J.TOIssued, J.TOComplete,
                   J.RSMove, J.RSOperator, J.RSIssued, J.RSComplete,
                   J.Response, J.MoveBGColor, J.MoveFGColor,
                   J.StepLevel, J.MoveCategory,
                   J.ActivityIdentifier,
                   0 AS Grounds, J.SwitchingItem,
                   J.Substation, ? AS ControlCard
            FROM   SOA_ArchiveJob J
            WHERE  J.Card = ? AND
                   J.Status <> 'Del'
            ORDER BY J.SwitchingItem, J.StepPair, J.StepLevel, J.Seq";

        public const string LoadCardLog = @"
            SELECT CL.Card, CL.SwitchingItem, CL.Log,
                   CL.LogStatus, CL.LogTime,
                   CL.EnteredBy, O.Description AS EnteredByName
            FROM   SOA_CardLog CL,
                   Udb_Object O
            WHERE  CL.Card = ? AND
                   CL.EnteredBy = O.Object
            ORDER BY CL.SwitchingItem, CL.LogTime DESC";

        public const string LoadCardLogArchive = @"
            SELECT CL.Card, CL.SwitchingItem, CL.Log,
                   CL.LogStatus, CL.LogTime,
                   CL.EnteredBy, O.Description AS EnteredByName
            FROM   SOA_ArchiveCardLog CL,
                   Udb_Object O
            WHERE  CL.Card = ? AND
                   CL.EnteredBy = O.Object
            ORDER BY CL.SwitchingItem, CL.LogTime DESC";

        public const string LoadWorkPermits = @"
            SELECT 2 AS CardType, 'SLC' AS CardTypeName,
                   '' AS CardName, '' AS CardStatus,
                   J.Job, J.Status, J.JobClass,
                   JC.Card, JC.Seq,
                   J.Equip, J.EquipClass, J.EquipClassName,
                   JC.MoveEquipClass, JC.PrintID,
                   J.EquipName,
                   '' AS Subsordesk,
                   J.Substation,
                   JC.StepPair, J.MoveType,
                   J.TOMove, J.TOMoveRules, J.TOOperator,
                   J.TOIssued, J.TOComplete,
                   J.RSMove, J.RSMoveRules, J.RSOperator,
                   J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   J.MoveFGColor,
                   1 AS IsWorkPermit
            FROM   SOA_Job J,
                   SOA_JobControl JC
            WHERE  JC.Card = ? AND
                   JC.Job = J.Job AND
                   J.Status IN ('', 'OPC') AND
                   JC.StepPair = 3 AND
                   J.JobClass <> 0
            ORDER BY JC.SwitchingItem, JC.Seq";

        public const string LoadWorkPermitsArchive = @"
            SELECT 2 AS CardType, 'SLC' AS CardTypeName,
                   '' AS CardName, 'Cls' AS CardStatus,
                   J.Job, J.Status, J.JobClass,
                   J.Card, J.Seq,
                   J.Equip, J.EquipClass, J.EquipClassName,
                   0 AS MoveEquipClass, J.PrintID,
                   J.EquipName,
                   '' AS Subsordesk,
                   J.Substation,
                   J.StepPair, J.MoveType,
                   J.TOMove, '' AS TOMoveRules, J.TOOperator,
                   J.TOIssued, J.TOComplete,
                   J.RSMove, '' AS RSMoveRules, J.RSOperator,
                   J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   J.MoveFGColor,
                   1 AS IsWorkPermit
            FROM   SOA_ArchiveJob J
            WHERE  J.Card = ? AND
                   J.Status <> 'Del' AND
                   J.StepPair = 3 AND
                   J.JobClass <> 0
            ORDER BY J.SwitchingItem, J.Seq";
    }
}
