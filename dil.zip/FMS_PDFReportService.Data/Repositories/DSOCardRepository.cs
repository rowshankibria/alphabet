using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Data.Repositories
{
    public class DSOCardRepository : IDSOCardRepository
    {
        private readonly IConnectionFactory _connectionFactory;
        private static readonly TimeSpan DefaultLookback = TimeSpan.FromDays(30);

        public DSOCardRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public DsoCardHeader LoadCardHeader(int cardId, int archiveFlag)
        {
            using (var conn = _connectionFactory.GetDsoConnection())
            {
                var header = conn.QueryFirstOrDefault<DsoCardHeader>(DSOQueries.LoadCardHeader, new { p1 = cardId });
                if (header == null) return null;

                header.Objects = conn.Query<DsoCardObject>(DSOQueries.LoadCardObjects, new { p1 = cardId }).ToList();

                var isEmergency = conn.QueryFirstOrDefault<int?>(DSOQueries.LoadIsEmergency, new { p1 = cardId });
                header.IsEmergency = isEmergency.HasValue;

                var lastEdit = conn.QueryFirstOrDefault<DateTime?>(DSOQueries.LoadLastEditTime, new { p1 = cardId });
                header.LastEditTime = lastEdit;

                return header;
            }
        }

        public IEnumerable<TfmsJob> LoadJobs(int cardId, int archiveFlag)
        {
            using (var conn = _connectionFactory.GetDsoConnection())
            {
                return conn.Query<TfmsJob>(DSOQueries.LoadJobs, new { p1 = cardId }).ToList();
            }
        }

        public IEnumerable<SoaCardLogEntry> LoadCardLog(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? DSOQueries.LoadCardLogArchive : DSOQueries.LoadCardLog;
            using (var conn = _connectionFactory.GetDsoConnection())
            {
                return conn.Query<SoaCardLogEntry>(sql, new { p1 = cardId }).ToList();
            }
        }

        public IEnumerable<DsoDiscoveryCard> GetDeletedCards(DateTime lastCheck)
        {
            using (var conn = _connectionFactory.GetDsoConnection())
            {
                return conn.Query<DsoDiscoveryCard>(DSOQueries.GetDeletedCards, new { LastCheck = lastCheck }).ToList();
            }
        }

        public IEnumerable<DsoDiscoveryCard> GetUpdatedCards(DateTime lastCheck)
        {
            using (var conn = _connectionFactory.GetDsoConnection())
            {
                return conn.Query<DsoDiscoveryCard>(DSOQueries.GetUpdatedCards, new { LastCheck = lastCheck }).ToList();
            }
        }

        public DateTime GetLastCheckTimestamp(string itemName)
        {
            var defaultLookback = DateTime.UtcNow.Subtract(DefaultLookback);
            using (var conn = _connectionFactory.GetDsoConnection())
            {
                return conn.QueryFirstOrDefault<DateTime>(
                    DSOQueries.GetLastCheckTimestamp,
                    new { DefaultLookback = defaultLookback, ItemName = itemName.ToLowerInvariant() });
            }
        }

        public void RecordCheckTimestamp(string itemName, string oldValue, string newValue)
        {
            using (var conn = _connectionFactory.GetDsoConnection())
            {
                conn.Execute(DSOQueries.RecordCheckTimestamp,
                    new { ItemName = itemName, OldValue = oldValue, NewValue = newValue });
            }
        }
    }
}
