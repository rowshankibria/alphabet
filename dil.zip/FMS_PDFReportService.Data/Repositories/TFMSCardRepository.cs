using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Data.Repositories
{
    public class TFMSCardRepository : ITFMSCardRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public TFMSCardRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public TfmsCardHeader LoadCardHeader(int cardId, int archiveFlag)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                var headerSql = archiveFlag == 1 ? TFMSQueries.LoadCardHeaderArchive : TFMSQueries.LoadCardHeader;
                var header = conn.QueryFirstOrDefault<TfmsCardHeader>(headerSql, new { p1 = cardId });
                if (header == null) return null;

                var clSql = archiveFlag == 1 ? TFMSQueries.LoadChecklistArchive : TFMSQueries.LoadChecklist;
                header.Checklists = conn.Query<TfmsChecklist>(clSql, new { p1 = cardId }).ToList();

                var prepSql = archiveFlag == 1 ? TFMSQueries.LoadPrepByArchive : TFMSQueries.LoadPrepBy;
                header.PrepBy = conn.Query<TfmsCardPrepBy>(prepSql, new { p1 = cardId, p2 = cardId }).ToList();

                var objSql = archiveFlag == 1 ? TFMSQueries.LoadCardObjectsArchive : TFMSQueries.LoadCardObjects;
                header.Objects = conn.Query<TfmsCardObject>(objSql, new { p1 = cardId }).ToList();

                return header;
            }
        }

        public IEnumerable<TfmsJob> LoadJobs(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? TFMSQueries.LoadJobsArchive : TFMSQueries.LoadJobs;
            using (var conn = _connectionFactory.GetConnection())
            {
                var param = archiveFlag == 1 ? new { p1 = cardId, p2 = cardId } : (object)new { p1 = cardId };
                return conn.Query<TfmsJob>(sql, param).ToList();
            }
        }

        public IEnumerable<SoaCardLogEntry> LoadCardLog(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? TFMSQueries.LoadCardLogArchive : TFMSQueries.LoadCardLog;
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<SoaCardLogEntry>(sql, new { p1 = cardId }).ToList();
            }
        }

        public IEnumerable<WorkPermit> LoadWorkPermits(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? TFMSQueries.LoadWorkPermitsArchive : TFMSQueries.LoadWorkPermits;
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<WorkPermit>(sql, new { p1 = cardId }).ToList();
            }
        }
    }
}
