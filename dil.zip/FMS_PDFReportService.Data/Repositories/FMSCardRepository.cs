using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Models;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;
using FMS_PDFReportService.Models.Jobs.Colors;
using FMS_PDFReportService.Models.Jobs.LocationTags;
using FMS_PDFReportService.Models.Jobs.PhaseChecks;
using FMS_PDFReportService.Models.Jobs.Protection;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.Linq;

namespace FMS_PDFReportService.Data.Repositories
{
    public class FMSCardRepository : IFMSCardRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public FMSCardRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public FmsCardHeader LoadCardHeader(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? FMSQueries.LoadCardHeaderArchive : FMSQueries.LoadCardHeader;
            var sw = Stopwatch.StartNew();
            using (var conn = _connectionFactory.GetConnection())
            {
                var result = conn.QueryFirstOrDefault<FmsCardHeader>(sql, new { p1 = cardId });
                // ca.dmt LoadCard 67922-67942: FOT count / Auto+ / CIOA+ (live and archived cards)
                CardHeaderRules.ApplyCardClassSuffix(result,
                    () => conn.QueryFirstOrDefault<int?>(FMSQueries.LoadFotCount, new { p1 = cardId }));

                Log.Debug("FMS LoadCardHeader CardId={CardId} Archive={Archive} in {ElapsedMs}ms",
                    cardId, archiveFlag, sw.ElapsedMilliseconds);
                return result;
            }
        }

        public CardNote LoadCardNote(int cardId)
        {
            var sw = Stopwatch.StartNew();
            using (var conn = _connectionFactory.GetConnection())
            {
                var result = conn.QueryFirstOrDefault<CardNote>(FMSQueries.LoadCardNote, new { p1 = cardId });
                Log.Debug("FMS LoadCardNote CardId={CardId} in {ElapsedMs}ms", cardId, sw.ElapsedMilliseconds);
                return result;
            }
        }

        public IEnumerable<NetworkObject> LoadNetworkObjects(int cardId)
        {
            var sw = Stopwatch.StartNew();
            using (var conn = _connectionFactory.GetConnection())
            {
                var result = conn.Query<NetworkObject>(FMSQueries.LoadNetworkObjects, new { p1 = cardId }).ToList();
                Log.Debug("FMS LoadNetworkObjects CardId={CardId} Rows={Count} in {ElapsedMs}ms",
                    cardId, result.Count, sw.ElapsedMilliseconds);
                return result;
            }
        }

        public OperatingStep LoadOperatingStep(int cardId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.QueryFirstOrDefault<OperatingStep>(
                    FMSQueries.LoadOperatingStep, new { p1 = cardId, p2 = cardId });
            }
        }

        public OperatingStep LoadCurrentDelay(int cardId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.QueryFirstOrDefault<OperatingStep>(
                    FMSQueries.LoadCurrentDelay, new { p1 = cardId, p2 = cardId });
            }
        }

        public FmsChecklist LoadChecklist(int cardId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.QueryFirstOrDefault<FmsChecklist>(FMSQueries.LoadChecklist, new { p1 = cardId });
            }
        }

        public IEnumerable<FmsJob> LoadJobs(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? FMSQueries.LoadJobsArchive : FMSQueries.LoadJobs;
            var sw = Stopwatch.StartNew();
            using (var conn = _connectionFactory.GetConnection())
            {
                var result = conn.Query<FmsJob>(sql, new { p1 = cardId }).ToList();
                Log.Debug("FMS LoadJobs CardId={CardId} Archive={Archive} Rows={Count} in {ElapsedMs}ms",
                    cardId, archiveFlag, result.Count, sw.ElapsedMilliseconds);
                return result;
            }
        }

        public IEnumerable<FeederLogEntry> LoadFeederLog(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? FMSQueries.LoadFeederLogArchive : FMSQueries.LoadFeederLog;
            var sw = Stopwatch.StartNew();
            using (var conn = _connectionFactory.GetConnection())
            {
                var result = conn.Query<FeederLogEntry>(sql, new { p1 = cardId }).ToList();
                Log.Debug("FMS LoadFeederLog CardId={CardId} Archive={Archive} Rows={Count} in {ElapsedMs}ms",
                    cardId, archiveFlag, result.Count, sw.ElapsedMilliseconds);
                return result;
            }
        }

        public IEnumerable<WorkPermit> LoadWorkPermits(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? FMSQueries.LoadWorkPermitsArchive : FMSQueries.LoadWorkPermits;
            using (var conn = _connectionFactory.GetConnection())
            {
                var permits = conn.Query<WorkPermit>(sql, new { p1 = cardId }).ToList();

                foreach (var permit in permits)
                {
                    var protReq = conn.QueryFirstOrDefault<int?>(
                        FMSQueries.LoadProtectionRequired, new { p1 = permit.Job });
                    permit.ProtectionRequired = protReq ?? 0;
                }

                return permits;
            }
        }

        // Priority ordering for the 6-source cascade + TLS branch (lower value wins on ties).
        private enum ProtectionCascadeBranch { Tls = 0, Active = 1, Open = 2, Bank = 3, ArchiveFms = 4, ArchiveSlc = 5, ArchiveTfms = 6 }

        // Deferred-mapping wrapper so LoadProtections can dedup on raw DateTime? values before formatting.
        private class ProtectionCandidate
        {
            public ProtectionMoveFeederCard Row { get; set; }
            public ProtectionCascadeBranch Branch { get; set; }
            public string CardTypeOverride { get; set; }
            public string CardStatusOverride { get; set; }
            public string SubsordeskFallback { get; set; }
        }

        public IEnumerable<PermitProtection> LoadProtections(int permitJob, int archiveFlag)
        {
            // Mirrors DOS WorkPermit_ASE.LoadWorkPermits protection block (cac.dmt L247669-L247935):
            // walk the FMS_WorkPermitProtection links, then per-link run the LoadProtectionMove cascade.
            var linksSql = archiveFlag == 1 ? FMSQueries.LoadProtectionLinksArchive : FMSQueries.LoadProtectionLinks;
            using (var conn = _connectionFactory.GetConnection())
            {
                var links = conn.Query<ProtectionLinkFeederCard>(linksSql, new { p1 = permitJob }).ToList();
                var candidates = new List<ProtectionCandidate>();
                foreach (var link in links)
                {
                    var cand = LoadProtectionCandidate(conn, link);
                    if (cand == null) continue;
                    // DOS silently drops protections whose effective CardTypeName is empty (cac.dmt L247691).
                    var effectiveType = cand.CardTypeOverride ?? cand.Row.CardTypeName;
                    if (string.IsNullOrEmpty((effectiveType ?? string.Empty).Trim())) continue;
                    candidates.Add(cand);
                }

                // D6 dedup: GROUP BY (EquipName, TOIssued, TOComplete) — two rows on the same equipment
                // with different take-out issued or complete times are distinct protection moves and must
                // not collapse. Non-date fields come from the highest-priority cascade branch in the group
                // (Active wins over Bank/Bnk); RSIssued/RSComplete take MAX across members. Rows with no
                // EquipName pass through as their own solo groups.
                var results = new List<PermitProtection>();
                int seq = 1;
                var groups = candidates
                    .Select((c, i) => new { c, i })
                    .GroupBy(x =>
                    {
                        var eq = (x.c.Row.EquipName ?? string.Empty).Trim();
                        if (eq.Length == 0)
                            return ("__solo_" + x.i, (DateTime?)null, (DateTime?)null);
                        return (eq, x.c.Row.TOIssued, x.c.Row.TOComplete);
                    });

                foreach (var g in groups)
                {
                    var members = g.Select(x => x.c).ToList();
                    var winner = members.OrderBy(c => (int)c.Branch).First();
                    var mapped = MapMove(winner.Row, winner.CardTypeOverride, winner.CardStatusOverride, winner.SubsordeskFallback);
                    mapped.PermitJob = permitJob;
                    mapped.Seq = seq++;
                    mapped.TOIssued = FormatShortDateTime(members.Max(m => m.Row.TOIssued));
                    mapped.TOComplete = FormatShortDateTime(members.Max(m => m.Row.TOComplete));
                    mapped.RSIssued = FormatShortDateTime(members.Max(m => m.Row.RSIssued));
                    mapped.RSComplete = FormatShortDateTime(members.Max(m => m.Row.RSComplete));
                    results.Add(mapped);
                }
                return results;
            }
        }

        private ProtectionCandidate LoadProtectionCandidate(IDbConnection conn, ProtectionLinkFeederCard link)
        {
            // TLS branch (cac_include_scripts.dmt L3413-L3474).
            if (link.ProtectionCardType == Constants.Type_TLSApp)
            {
                var tls = conn.QueryFirstOrDefault<ProtectionMoveFeederCard>(
                    FMSQueries.LoadProtectionMove_Tls,
                    new { p1 = link.ProtectionCard, p2 = link.ProtectionJobID, p3 = link.ProtectionCard, p4 = link.ProtectionJobID });
                if (tls == null) return null;
                return new ProtectionCandidate
                {
                    Row = tls,
                    Branch = ProtectionCascadeBranch.Tls,
                    CardTypeOverride = "TLS",
                    CardStatusOverride = tls.CardStatus,
                    SubsordeskFallback = tls.SubstationName
                };
            }

            // Generic 6-source cascade (cac_include_scripts.dmt L3476-L3757); first-match wins.
            var row = conn.QueryFirstOrDefault<ProtectionMoveFeederCard>(
                FMSQueries.LoadProtectionMove_Active, new { p1 = link.ProtectionJobID });
            if (row != null)
            {
                // DOS Fake→Bnk post-hook (cac_include_scripts.dmt L3535-L3540 + L3750).
                if (row.MoveCategory == Constants.MoveCategory_Fake)
                {
                    row.CardName = string.Empty;
                    return new ProtectionCandidate { Row = row, Branch = ProtectionCascadeBranch.Active, CardStatusOverride = "Bnk" };
                }
                return new ProtectionCandidate { Row = row, Branch = ProtectionCascadeBranch.Active };
            }

            row = conn.QueryFirstOrDefault<ProtectionMoveFeederCard>(
                FMSQueries.LoadProtectionMove_Open, new { p1 = link.ProtectionJobID });
            if (row != null)
            {
                // DOS Open-card CardName lookup (L3574-L3590): pick from FMS_Card or TFMS_Card based on Application.
                string cardType = (row.CardTypeName ?? string.Empty).Trim();
                var lookupSql = cardType == "FMS" ? FMSQueries.LoadOpenCardFmsName : FMSQueries.LoadOpenCardTfmsName;
                row.CardName = conn.QueryFirstOrDefault<string>(lookupSql, new { p1 = row.Card }) ?? string.Empty;
                return new ProtectionCandidate { Row = row, Branch = ProtectionCascadeBranch.Open, CardStatusOverride = "Opn" };
            }

            row = conn.QueryFirstOrDefault<ProtectionMoveFeederCard>(
                FMSQueries.LoadProtectionMove_Bank, new { p1 = link.ProtectionJobID });
            if (row != null)
            {
                return new ProtectionCandidate
                {
                    Row = row,
                    Branch = ProtectionCascadeBranch.Bank,
                    CardTypeOverride = "FMS",
                    CardStatusOverride = "Bnk",
                    SubsordeskFallback = row.SubstationName
                };
            }

            row = conn.QueryFirstOrDefault<ProtectionMoveFeederCard>(
                FMSQueries.LoadProtectionMove_ArchiveFms, new { p1 = link.ProtectionJobID });
            if (row != null)
            {
                return new ProtectionCandidate
                {
                    Row = row,
                    Branch = ProtectionCascadeBranch.ArchiveFms,
                    CardTypeOverride = "FMS",
                    CardStatusOverride = "Cls",
                    SubsordeskFallback = row.CardName
                };
            }

            row = conn.QueryFirstOrDefault<ProtectionMoveFeederCard>(
                FMSQueries.LoadProtectionMove_ArchiveSlc, new { p1 = link.ProtectionJobID });
            if (row != null)
            {
                return new ProtectionCandidate
                {
                    Row = row,
                    Branch = ProtectionCascadeBranch.ArchiveSlc,
                    CardTypeOverride = "SLC",
                    CardStatusOverride = "Cls"
                };
            }

            row = conn.QueryFirstOrDefault<ProtectionMoveFeederCard>(
                FMSQueries.LoadProtectionMove_ArchiveTfms, new { p1 = link.ProtectionJobID });
            if (row != null)
            {
                return new ProtectionCandidate
                {
                    Row = row,
                    Branch = ProtectionCascadeBranch.ArchiveTfms,
                    CardTypeOverride = "TFMS",
                    CardStatusOverride = "Cls"
                };
            }

            return null;
        }

        private static PermitProtection MapMove(ProtectionMoveFeederCard r, string cardTypeOverride = null,
            string cardStatusOverride = null, string subsordeskFallback = null)
        {
            string cardTypeName = (cardTypeOverride ?? r.CardTypeName ?? string.Empty).Trim();
            string cardName = (r.CardName ?? string.Empty).Trim();
            string cardStatus = (cardStatusOverride ?? r.CardStatus ?? string.Empty).Trim();
            // FMS Subsordesk post-hook (cac_include_scripts.dmt L3529-L3531): show feeder name, not substation.
            string subsordesk = cardTypeName == "FMS"
                ? cardName
                : (subsordeskFallback ?? r.SubstationName ?? string.Empty).Trim();

            return new PermitProtection
            {
                CardTypeName = cardTypeName,
                Card = string.IsNullOrEmpty(cardStatus) ? cardName : (cardName + " " + cardStatus).Trim(),
                Subsordesk = subsordesk,
                PrintID = (r.PrintID ?? string.Empty).Trim(),
                EquipClassName = (r.EquipClassName ?? string.Empty).Trim(),
                EquipName = (r.EquipName ?? string.Empty).Trim(),
                TOMove = (r.TOMove ?? string.Empty).Trim(),
                TOIssued = FormatShortDateTime(r.TOIssued),
                TOComplete = FormatShortDateTime(r.TOComplete),
                RSIssued = FormatShortDateTime(r.RSIssued),
                RSComplete = FormatShortDateTime(r.RSComplete)
            };
        }

        public IEnumerable<PhaseCheck> LoadPhaseChecks(int cardId, int feederId, int permitJob, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? FMSQueries.LoadPhaseChecksArchive : FMSQueries.LoadPhaseChecks;
            using (var conn = _connectionFactory.GetConnection())
            {
                var rows = conn.Query<PhaseCheckFeederCard>(
                    sql, new { p1 = feederId, p2 = feederId, p3 = permitJob, p4 = cardId }).ToList();
                return rows.Select(r => new PhaseCheck
                {
                    PermitJob = permitJob,
                    Card = r.Card,
                    PrintID = (r.PrintID ?? string.Empty).Trim(),
                    EquipClassName = (r.EquipClassName ?? string.Empty).Trim(),
                    EquipName = (r.EquipName ?? string.Empty).Trim(),
                    SPC_PrintID = (r.SPC_PrintID ?? string.Empty).Trim(),
                    SPC_EquipClassName = (r.SPC_EquipClassName ?? string.Empty).Trim(),
                    SPC_EquipName = (r.SPC_EquipName ?? string.Empty).Trim(),
                    Issued = FormatShortDateTime(r.IssueTime),
                    Complete = FormatShortDateTime(r.CompletionTime)
                }).ToList();
            }
        }

        // DOS util_ToLocalTime(..., gDTShort) short-datetime equivalent (benchmark 1X24: MM/dd HH:mm); empty on null.
        private static string FormatShortDateTime(DateTime? d)
        {
            return d.HasValue ? d.Value.ToString("MM/dd HH:mm") : string.Empty;
        }

        public IEnumerable<LocationTag> LoadLocationTags(int permitJob)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                var rows = conn.Query<LocationTagFeederCard>(FMSQueries.LoadLocationTags, new { p1 = permitJob }).ToList();
                return rows.Select(r =>
                {
                    // LEFT JOIN nulls-on-no-match: any tag column being null means no tag row exists.
                    bool hasTag = r.Phases.HasValue;
                    return new LocationTag
                    {
                        PermitJob = permitJob,
                        WPLocation = r.WPLocation,
                        LocationStructure = (r.LocationStructure ?? string.Empty).Trim(),
                        LocationStreet = (r.LocationStreet ?? string.Empty).Trim(),
                        LocationStatus = (r.LocationStatus ?? string.Empty).Trim(),
                        TagType = hasTag ? (r.TagType ?? string.Empty).Trim() : string.Empty,
                        TagNumber = hasTag ? (r.TagNumber ?? string.Empty).Trim() : string.Empty,
                        Phase = hasTag ? (r.Phases == 1 ? "Yes" : "-") : string.Empty,
                        Brass = hasTag ? (r.BrassTag == 1 ? "Yes" : "-") : string.Empty,
                        Plastic = hasTag ? (r.PlasticTag == 1 ? "Yes" : "-") : string.Empty,
                        TagNotes = hasTag ? (r.TagNotes ?? string.Empty).Trim() : string.Empty,
                        HasTag = hasTag
                    };
                }).ToList();
            }
        }

        public RelaySummaryData LoadRelaySummary(int cardId, int archiveFlag)
        {
            var result = new RelaySummaryData { CardId = cardId };

            using (var conn = _connectionFactory.GetConnection())
            {
                result.BusFaultEntries = conn.Query<BusFaultOutageEntry>(
                    FMSQueries.LoadRelaySummary, new { p1 = cardId }).ToList();

                var relayTargetSql = archiveFlag == 1
                    ? FMSQueries.LoadRelayTargetsArchive
                    : FMSQueries.LoadRelayTargets;

                result.RelayTargets = conn.Query<RelayTargetEntry>(
                    relayTargetSql, new { p1 = cardId, p2 = cardId, p3 = cardId }).ToList();
            }

            return result;
        }

        // Mirrors Relay_ASE.LoadRelaySummary (cas.dmt L187437) + DOS arFMSRelaySummary.Dsr row shaping.
        public List<FmsRelaySummaryRow> LoadFmsRelaySummary(int cardId, int archiveFlag, int switchingItem)
        {
            var sw = Stopwatch.StartNew();
            using (var conn = _connectionFactory.GetConnection())
            {
                var ops = conn.Query<RelayOpRow>(
                    archiveFlag == 1 ? FMSQueries.LoadFmsRelayOpsArchive : FMSQueries.LoadFmsRelayOps,
                    new { p1 = cardId }).ToList();
                var equip = archiveFlag == 1
                    ? conn.Query<FeederRelayEquipRow>(FMSQueries.LoadFmsRelayEquipArchive, new { p1 = cardId }).ToList()
                    : conn.Query<FeederRelayEquipRow>(FMSQueries.LoadFmsRelayEquip, new { p1 = cardId, p2 = switchingItem }).ToList();
                var classes = conn.Query<RelayClassRow>(FMSQueries.LoadRelayClasses).ToList();
                var types = conn.Query<RelayTypeRow>(FMSQueries.LoadRelayTypes).ToList();

                var rows = BuildFmsRelayRows(ops, equip, classes, types);
                Log.Debug("FMS LoadFmsRelaySummary CardId={CardId} Archive={Archive} SwItem={SwItem} Ops={Ops} in {ElapsedMs}ms",
                    cardId, archiveFlag, switchingItem, ops.Count, sw.ElapsedMilliseconds);
                return rows;
            }
        }

        private static List<FmsRelaySummaryRow> BuildFmsRelayRows(List<RelayOpRow> ops, List<FeederRelayEquipRow> equip,
            List<RelayClassRow> classes, List<RelayTypeRow> types)
        {
            // (feeder, equip, relay type) reachable from the card's open-auto equipment via the relay class hierarchy.
            var matchKeys = new HashSet<(string, int, int)>();
            // OR returns before the matching pass when either lookup is empty, leaving RelayTypeName untouched.
            bool hierarchyLoaded = classes.Count > 0 && types.Count > 0;
            if (hierarchyLoaded)
            {
                var typesByClass = types.ToLookup(t => t.Type, t => t.RelayType);
                foreach (var fre in equip)
                {
                    string feeder = (fre.FeederName ?? string.Empty).Trim();
                    foreach (var start in classes.Where(c => c.RelayClass == fre.RelayClass))
                    {
                        var visited = new HashSet<int>();
                        var cur = start;
                        while (cur != null && cur.RelayClass != Constants.Type_Relay && visited.Add(cur.RelayClass))
                        {
                            foreach (var relayType in typesByClass[cur.RelayClass])
                                matchKeys.Add((feeder, fre.Equip, relayType));
                            var parentId = cur.ParentRelayInt;
                            cur = classes.FirstOrDefault(c => c.RelayClass == parentId);
                        }
                    }
                }
            }

            var rows = new List<FmsRelaySummaryRow>();
            foreach (var op in ops)
            {
                // arFMSRelaySummary DataInitialize skips ops without a TimeStamp.
                if (!op.TimeStamp.HasValue) continue;

                int line = op.Line ?? 0;
                string feeder = (op.FeederName ?? string.Empty).Trim();
                bool matched = line == -1 && op.Equip.HasValue && op.RelayType.HasValue &&
                               matchKeys.Contains((feeder, op.Equip.Value, op.RelayType.Value));
                // Unmatched ops are RSOther rows; OR overwrites their RelayTypeName with RelayClassName for FMS Online.
                string relayType = hierarchyLoaded && !matched ? op.RelayClassName : op.RelayTypeName;

                int operation = op.Operation ?? 0;
                bool instant = operation == Constants.RelayOp_Instantaneous ||
                               operation == Constants.RelayOp_Instantaneous + Constants.RelayOp_Time;
                bool time = operation == Constants.RelayOp_Time ||
                            operation == Constants.RelayOp_Instantaneous + Constants.RelayOp_Time;

                rows.Add(new FmsRelaySummaryRow
                {
                    Feeder = feeder,
                    EquipType = (op.EquipClassName ?? string.Empty).Trim(),
                    EquipName = (op.EquipName ?? string.Empty).Trim(),
                    RelayType = (relayType ?? string.Empty).Trim(),
                    RelayName = (op.RelayName ?? string.Empty).Trim(),
                    Line = line == -1 ? string.Empty : (line == 0 ? "1st" : "2nd"),
                    Operated = operation == Constants.RelayOp_Normal ? "Yes" : "-",
                    Instant = instant ? "Yes" : "-",
                    Time = time ? "Yes" : "-",
                    TimeStamp = op.TimeStamp.Value.ToString("MM/dd/yy HH:mm", CultureInfo.InvariantCulture)
                });
            }

            // DOS pads to max(4, count + 1) rows with blank lines.
            int total = Math.Max(4, rows.Count + 1);
            while (rows.Count < total)
                rows.Add(new FmsRelaySummaryRow());

            return rows;
        }

        public IEnumerable<RegisteredTag> LoadRegisteredTags(int feederId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<RegisteredTag>(FMSQueries.LoadRegisteredTags, new { p1 = feederId }).ToList();
            }
        }

        public FmsColorInputs LoadFmsColorInputs(int cardId)
        {
            var sw = Stopwatch.StartNew();
            using (var conn = _connectionFactory.GetConnection())
            {
                var p = new { p1 = cardId };
                var inputs = new FmsColorInputs
                {
                    Now = conn.QueryFirst<DateTime>(FMSQueries.ColorNow),
                    FodMoves = conn.Query<FodMoveFeederCard>(FMSQueries.ColorFodMoves, p).ToList(),
                    FaultMoves = conn.Query<FaultMoveFeederCard>(FMSQueries.ColorFaultMoves, p).ToList(),
                    OpOrders = conn.Query<OpOrderFeederCard>(FMSQueries.ColorOpOrders, p).ToList(),
                    Permits = conn.Query<PermitFeederCard>(FMSQueries.ColorPermits, p).ToList(),
                    Alerts = conn.Query<BogeyAlertFeederCard>(FMSQueries.ColorAlerts, p).ToList()
                };
                inputs.PaMoves.AddRange(conn.Query<PaMoveFeederCard>(FMSQueries.ColorPaPermit, p));
                inputs.PaMoves.AddRange(conn.Query<PaMoveFeederCard>(FMSQueries.ColorPaFodTO, p));
                inputs.PaMoves.AddRange(conn.Query<PaMoveFeederCard>(FMSQueries.ColorPaFodRS, p));
                inputs.PaMoves.AddRange(conn.Query<PaMoveFeederCard>(FMSQueries.ColorPaOpTO, p));
                inputs.PaMoves.AddRange(conn.Query<PaMoveFeederCard>(FMSQueries.ColorPaOpRS, p));

                Log.Debug("FMS LoadFmsColorInputs CardId={CardId} in {ElapsedMs}ms", cardId, sw.ElapsedMilliseconds);
                
                return inputs;
            }
        }

        public IEnumerable<PhaseCheckEquipRow> LoadOpenPhaseChecks(int cardId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<PhaseCheckEquipRow>(FMSQueries.LoadOpenPhaseChecks,
                    new { p1 = cardId, p2 = cardId, p3 = cardId, p4 = cardId, p5 = cardId }).ToList();
            }
        }
    }
}
