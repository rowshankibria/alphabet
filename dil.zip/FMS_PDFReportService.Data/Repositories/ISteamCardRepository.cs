using System.Collections.Generic;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Data.Repositories
{
    public interface ISteamCardRepository
    {
        SteamCardHeader LoadCardHeader(int cardId, int archiveFlag);
        IEnumerable<TfmsJob> LoadJobs(int cardId, int archiveFlag);
        IEnumerable<int> GetActiveCardIds();
        IEnumerable<SteamActiveCard> GetActiveCards();
    }
}
