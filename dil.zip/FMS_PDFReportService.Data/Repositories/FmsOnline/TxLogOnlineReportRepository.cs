using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries.FmsOnline;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsOnline;

public class TxLogOnlineReportRepository : ITxLogOnlineReportRepository
{
    private readonly IConnectionFactory _connectionFactory;

    // SQL: VERIFIED — Interaction_MemberOf constant from Constant.vb
    private const int Interaction_MemberOf = 10;

    // SQL: VERIFIED — Order status constants from Constant.vb
    private const int Order_Rejected = 5;
    private const int Order_ConfirmRejected = 7;
    private const int Order_Rescinded = 8;
    private const int Order_ConfirmRescinded = 10;

    public TxLogOnlineReportRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    // SQL: VERIFIED — copied from TransactionLog.vb:LoadSOATxLog (L59)
    public IEnumerable<SOATxLogItem> LoadSOATxLog(TxLogFilter filter)
    {
        using var conn = _connectionFactory.GetConnection();

        // Lookup feeder for FMS cards
        int feeder = 0;
        if (string.Equals(filter.Application, "FMS", StringComparison.OrdinalIgnoreCase))
        {
            feeder = conn.QueryFirstOrDefault<int>(TxLogOnlineQueries.LookupFeeder, new { filter.Card });
        }

        // Select appropriate query based on archive flag and application
        string sql;
        object parms;

        if (filter.ArchiveCard == 0 || string.Equals(filter.Application, "SDS", StringComparison.OrdinalIgnoreCase))
        {
            sql = TxLogOnlineQueries.SOATxLogActive;
            parms = new { filter.Card, filter.SwitchingItem };
        }
        else if (string.Equals(filter.Application, "FMS", StringComparison.OrdinalIgnoreCase))
        {
            sql = TxLogOnlineQueries.FMSArchiveTxLog;
            parms = new { filter.Card };
        }
        else
        {
            sql = TxLogOnlineQueries.SOAArchiveTxLog;
            parms = new { filter.Card, filter.SwitchingItem };
        }

        var items = conn.Query<SOATxLogItem>(sql, parms).ToList();

        // For FMS cards, lookup PrintID from Udb_Grouping
        if (feeder > 0)
        {
            foreach (var item in items)
            {
                if (item.Equip != 0 && string.IsNullOrEmpty(item.PrintID))
                {
                    var printId = conn.QueryFirstOrDefault<string>(
                        TxLogOnlineQueries.LookupPrintID,
                        new { Feeder = feeder, Equip = item.Equip });
                    if (printId != null)
                        item.PrintID = printId;
                }
            }
        }

        return items;
    }

    // SQL: VERIFIED — copied from TransactionLog.vb:LoadTLSTxLog (L260)
    public IEnumerable<TLSTxLogItem> LoadTLSTxLog(TxLogFilter filter)
    {
        using var conn = _connectionFactory.GetConnection();

        string sql = filter.ArchiveCard == 0
            ? TxLogOnlineQueries.TLSTxLogActive
            : TxLogOnlineQueries.TLSTxLogArchive;

        return conn.Query<TLSTxLogItem>(sql, new { filter.Card });
    }

    // SQL: VERIFIED — copied from Job.vb:LoadIncompleteJob (L512)
    public IEnumerable<IncompleteJobItem> LoadIncompleteJobs(IncompleteJobFilter filter)
    {
        using var conn = _connectionFactory.GetConnection();

        // Lookup feeder for active FMS cards
        int feeder = 0;
        if (filter.ArchiveCard == 0)
        {
            feeder = conn.QueryFirstOrDefault<int>(TxLogOnlineQueries.LookupFeeder, new { filter.Card });
        }

        // Select query based on archive flag and application
        string sql;
        object parms;

        if (filter.ArchiveCard == 0)
        {
            sql = TxLogOnlineQueries.IncompleteJobsActive;
            parms = new { filter.Card, filter.SwitchingItem };
        }
        else if (string.Equals(filter.Application, "FMS", StringComparison.OrdinalIgnoreCase))
        {
            sql = TxLogOnlineQueries.IncompleteJobsFMSArchive;
            parms = new { filter.Card };
        }
        else
        {
            sql = TxLogOnlineQueries.IncompleteJobsSOAArchive;
            parms = new { filter.Card, filter.SwitchingItem };
        }

        var rawEntries = conn.Query<IncompleteJobRaw>(sql, parms).ToList();

        // Lookup PrintID for active FMS cards
        if (feeder > 0)
        {
            foreach (var entry in rawEntries)
            {
                if (entry.Equip != 0 && string.IsNullOrEmpty(entry.PrintID))
                {
                    var printId = conn.QueryFirstOrDefault<string>(
                        TxLogOnlineQueries.LookupPrintID,
                        new { Feeder = feeder, Equip = entry.Equip });
                    if (printId != null)
                        entry.PrintID = printId;
                }
            }
        }

        // Process raw log entries into incomplete job items (same logic as Job.vb L700-870)
        return BuildIncompleteJobs(conn, rawEntries, filter);
    }

    private List<IncompleteJobItem> BuildIncompleteJobs(
        System.Data.IDbConnection conn, List<IncompleteJobRaw> entries, IncompleteJobFilter filter)
    {
        var result = new List<IncompleteJobItem>();

        for (int i = 0; i < entries.Count; i++)
        {
            var entry = entries[i];

            if (entry.Item == "TOIssued" || entry.Item == "RSIssued")
            {
                var ij = new IncompleteJobItem
                {
                    Job = entry.Job,
                    PrintID = entry.PrintID ?? "",
                    EquipName = entry.EquipName ?? "",
                    EquipClassName = entry.EquipClassName ?? "",
                    TORS = entry.Item == "TOIssued" ? 0 : 1,
                    MoveText = entry.Item == "TOIssued" ? (entry.TOMove ?? "") : (entry.RSMove ?? ""),
                    IssuedTime = entry.Old ?? "",
                    IncompleteTime = entry.Time ?? "",
                    OperatorName = "",
                    Remark = ""
                };

                // Lookup order remarks
                LookupOrderRemark(conn, ij, entry, filter);

                result.Add(ij);
            }
            else if (entry.Item == "TOOperator" || entry.Item == "RSOperator")
            {
                // Assign operator name to the previous incomplete job if same job
                if (result.Count > 0 && result[result.Count - 1].Job == entry.Job)
                {
                    result[result.Count - 1].OperatorName = entry.Old ?? "";
                }
            }
        }

        return result;
    }

    private void LookupOrderRemark(
        System.Data.IDbConnection conn, IncompleteJobItem ij, IncompleteJobRaw entry, IncompleteJobFilter filter)
    {
        if (!DateTime.TryParse(entry.Old, out var beginTime) || !DateTime.TryParse(entry.Time, out var endTime))
            return;

        // Check SSO Orders
        var sso = conn.QueryFirstOrDefault<SSOOrderRaw>(
            TxLogOnlineQueries.LookupSSOOrder,
            new { Job = entry.Job, TORS = ij.TORS, BeginTime = beginTime, EndTime = endTime });

        if (sso != null && sso.OrderNumber != 0)
        {
            if (sso.OrderStatus == Order_Rejected || sso.OrderStatus == Order_ConfirmRejected)
                ij.Remark = $"Rejected SSO Order {sso.OrderNumber}: {sso.AckRejectComment}";
            else if (sso.OrderStatus == Order_Rescinded || sso.OrderStatus == Order_ConfirmRescinded)
                ij.Remark = $"Rescinded SSO Order {sso.OrderNumber}: {sso.RescindComment}";
            else
            {
                ij.Remark = $"SSO Order {sso.OrderNumber}: {sso.ReturnComment}";
                if (!string.IsNullOrEmpty(sso.ReturnRemark))
                    ij.Remark += ";" + sso.ReturnRemark;
            }
            return;
        }

        // Check FOD Orders (FMS only)
        if (string.Equals(filter.Application, "FMS", StringComparison.OrdinalIgnoreCase))
        {
            var fod = conn.QueryFirstOrDefault<FODOrderRaw>(
                TxLogOnlineQueries.LookupFODOrder,
                new { Job = entry.Job, TORS = ij.TORS, BeginTime = beginTime, EndTime = endTime });

            if (fod != null && fod.OrderNumber != 0)
            {
                if (fod.JobStatus == Order_Rejected || fod.JobStatus == Order_ConfirmRejected)
                    ij.Remark = $"Rejected FOD Order {fod.OrderNumber}: {fod.AckRejectedComment}";
                else if (fod.JobStatus == Order_Rescinded || fod.JobStatus == Order_ConfirmRescinded)
                    ij.Remark = $"Rescinded FOD Order {fod.OrderNumber}: {fod.RescindComment}";
                else
                    ij.Remark = $"FOD Order {fod.OrderNumber}: {fod.ReturnRemark}";
                return;
            }

            // Check rejected log entries
            var rejBeginTime = endTime.AddSeconds(-10);
            var rejEndTime = endTime.AddSeconds(20);
            string rejSql = filter.ArchiveCard == 0
                ? TxLogOnlineQueries.LookupRejectedLogActive
                : TxLogOnlineQueries.LookupRejectedLogArchive;

            var rej = conn.QueryFirstOrDefault<RejectedLogRaw>(
                rejSql,
                new { Job = entry.Job, BeginTime = rejBeginTime, EndTime = rejEndTime });

            if (rej != null && rej.Job != 0)
            {
                ij.Remark = $"Rejected {rej.Old}: {rej.New}";
            }
        }
    }

    // Raw DTOs for Dapper mapping
    private class IncompleteJobRaw
    {
        public int Job { get; set; }
        public string Time { get; set; }
        public string PrintID { get; set; }
        public int Equip { get; set; }
        public string EquipName { get; set; }
        public string EquipClassName { get; set; }
        public string TOMove { get; set; }
        public string RSMove { get; set; }
        public string UserName { get; set; }
        public string Item { get; set; }
        public string Old { get; set; }
        public string New { get; set; }
        public int Operator { get; set; }
        public string OperatorName { get; set; }
    }

    private class SSOOrderRaw
    {
        public int OrderNumber { get; set; }
        public string AckRejectComment { get; set; }
        public string RescindComment { get; set; }
        public string ReturnComment { get; set; }
        public string ReturnRemark { get; set; }
        public int OrderStatus { get; set; }
    }

    private class FODOrderRaw
    {
        public int OrderNumber { get; set; }
        public string AckRejectedComment { get; set; }
        public string RescindComment { get; set; }
        public string ReturnRemark { get; set; }
        public int JobStatus { get; set; }
    }

    private class RejectedLogRaw
    {
        public int Job { get; set; }
        public string Old { get; set; }
        public string New { get; set; }
    }
}
