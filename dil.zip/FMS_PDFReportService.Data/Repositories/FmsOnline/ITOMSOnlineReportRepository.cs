using System.Collections.Generic;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsOnline;

public interface ITOMSOnlineReportRepository
{
    TomsMilestoneReport LoadMilestone(TomsMilestoneFilter filter);
    TomsMilestoneReport LoadMilestoneHistory(TomsMilestoneFilter filter);
    IEnumerable<XA21OutageItem> LoadXA21Outage(XA21OutageFilter filter);
    IEnumerable<OutageRequestItem> LoadOutageRequest(OutageRequestFilter filter);
}
