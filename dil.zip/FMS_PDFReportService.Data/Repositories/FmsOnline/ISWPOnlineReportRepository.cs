using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries.FmsOnline;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsOnline;

public class ISWPOnlineReportRepository : IISWPOnlineReportRepository
{
    private readonly IConnectionFactory _connectionFactory;

    // SQL: VERIFIED — GroupingType constants from ISWP_Report.vb
    private const int GroupingType_SSM = 22648;
    private const int GroupingType_ECB = 22615;
    private const int GroupingType_PST = 22619;
    private const int GroupingType_TMG = 22642;
    private const int GroupingType_CapC = 22901;

    public ISWPOnlineReportRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    // SQL: VERIFIED — copied from ISWP_Report.vb:LoadMgmtReport
    public ISWPSummaryReport LoadMgmtReport(ISWPSummaryFilter filter)
    {
        var startDate = DateTime.Parse(filter.StartDate).ToString("MM/dd/yyyy HH:mm:ss");
        var endDate = DateTime.Parse(filter.EndDate).AddDays(1).ToString("MM/dd/yyyy HH:mm:ss");
        var parms = new { StartDate = startDate, EndDate = endDate };

        using var conn = _connectionFactory.GetConnection();

        var allPermits = conn.Query<PermitRaw>(ISWPOnlineQueries.MgmtReportAllPermits, parms).ToList();
        var ssmPermits = conn.Query<PermitRaw>(ISWPOnlineQueries.MgmtReportSubgroup,
            new { StartDate = startDate, EndDate = endDate, WorkGroup = "SSM", GroupingType = GroupingType_SSM }).ToList();
        var ecbPermits = conn.Query<PermitRaw>(ISWPOnlineQueries.MgmtReportSubgroup,
            new { StartDate = startDate, EndDate = endDate, WorkGroup = "ECB", GroupingType = GroupingType_ECB }).ToList();
        var pstPermits = conn.Query<PermitRaw>(ISWPOnlineQueries.MgmtReportSubgroup,
            new { StartDate = startDate, EndDate = endDate, WorkGroup = "PST", GroupingType = GroupingType_PST }).ToList();
        var tmgPermits = conn.Query<PermitRaw>(ISWPOnlineQueries.MgmtReportSubgroup,
            new { StartDate = startDate, EndDate = endDate, WorkGroup = "TMG", GroupingType = GroupingType_TMG }).ToList();
        var capCPermits = conn.Query<PermitRaw>(ISWPOnlineQueries.MgmtReportSubgroup,
            new { StartDate = startDate, EndDate = endDate, WorkGroup = "Cap_Const", GroupingType = GroupingType_CapC }).ToList();

        return new ISWPSummaryReport
        {
            ARL = BuildGroupCounts(allPermits),
            ARL_SSM = BuildGroupCounts(ssmPermits),
            ARL_ECB = BuildGroupCounts(ecbPermits),
            ARL_PST = BuildGroupCounts(pstPermits),
            ARL_TMG = BuildGroupCounts(tmgPermits),
            ARL_CapC = BuildGroupCounts(capCPermits)
        };
    }

    // SQL: VERIFIED — copied from ISWP_Report.vb:LoadNYISOReport
    public IEnumerable<NYISOItem> LoadNYISOReport(NYISOFilter filter)
    {
        var startDate = DateTime.Parse(filter.StartDate).ToString("MM/dd/yyyy");
        var endDate = DateTime.Parse(filter.EndDate).AddDays(1).ToString("MM/dd/yyyy");

        // Fix applied 2026-09-22 (E01) — DIV is untrusted API input; only integer-validated
        // division IDs (via ParseIntegerList) are allowed into the interpolated SQL, matching the
        // verified TOMSOnlineReportRepository.ParseIntegerList / FmsOnlineReportRepository.LoadPhaseChecks
        // pattern instead of a raw Replace(";", ",") passthrough.
        string divFilter = "";
        if (!string.IsNullOrEmpty(filter.DivisionName) &&
            !filter.DivisionName.StartsWith("all", StringComparison.OrdinalIgnoreCase))
        {
            var divs = ParseIntegerList(filter.DivisionName);
            if (divs.Length > 0)
                divFilter = "P.Division IN (" + string.Join(",", divs) + ") AND ";
        }

        var sql = string.Format(ISWPOnlineQueries.NYISOReport, divFilter);

        using var conn = _connectionFactory.GetConnection();
        return conn.Query<NYISOItem>(sql, new { StartDate = startDate, EndDate = endDate }).ToList();
    }

    // SQL: VERIFIED — copied from ISWP_Report.vb:LoadDeniedByGroup + LoadDeniedList
    public DeniedReport LoadDeniedReport(DeniedRequestFilter filter)
    {
        var startDate = DateTime.Parse(filter.StartDate).ToString("MM/dd/yyyy");
        var endDate = DateTime.Parse(filter.EndDate).AddDays(1).ToString("MM/dd/yyyy");

        string divClause = BuildDivisionClause(filter.DivisionName);
        string groupFilter = BuildWorkGroupFilter(filter.WorkGroup);

        using var conn = _connectionFactory.GetConnection();

        // Load groups
        var groupSql = string.Format(ISWPOnlineQueries.DeniedByGroup, groupFilter, divClause);
        var groups = conn.Query<DeniedGroupItem>(groupSql, new { StartDate = startDate, EndDate = endDate }).ToList();

        // Load detail list
        var listSql = string.Format(ISWPOnlineQueries.DeniedList, groupFilter, divClause);
        var requests = conn.Query<DeniedRequestItem>(listSql, new { StartDate = startDate, EndDate = endDate }).ToList();

        return new DeniedReport
        {
            Groups = groups.ToArray(),
            Requests = requests.ToArray()
        };
    }

    // SQL: VERIFIED — copied from ISWP_Restriction.vb:LoadRestrictions
    public IEnumerable<RestrictionItem> LoadRestrictions(RestrictionFilter filter)
    {
        string whereClause;
        if (filter.Status == 1)
        {
            var now = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss");
            whereClause = "(R.Status = 1 OR R.Status = 0 AND R.EndTime >= '" + now + "')";
        }
        else
        {
            var startDate = DateTime.Parse(filter.StartDate).ToString("MM/dd/yyyy HH:mm:ss");
            var endDate = DateTime.Parse(filter.EndDate).AddDays(1).ToString("MM/dd/yyyy HH:mm:ss");
            whereClause = "R.Status IN (0, 50) AND " +
                          "R.StartTime < '" + endDate + "' AND " +
                          "(R.EndTime IS NOT NULL AND R.EndTime >= '" + startDate + "' OR " +
                          " R.EndTime IS NULL AND R.LiftTime >= '" + startDate + "')";
        }

        var sql = string.Format(ISWPOnlineQueries.Restrictions, whereClause);

        using var conn = _connectionFactory.GetConnection();
        var rawRows = conn.Query<RestrictionRaw>(sql).ToList();

        // Group by restriction ID (same logic as ISWP_Restriction.vb)
        var result = new List<RestrictionItem>();
        RestrictionItem current = null;
        var currentItems = new List<RestrictionItemObject>();

        foreach (var row in rawRows)
        {
            if (current == null || current.ID != row.Restriction)
            {
                if (current != null)
                {
                    current.Items = currentItems.ToArray();
                    result.Add(current);
                }

                current = new RestrictionItem
                {
                    ID = row.Restriction,
                    HandsOff = row.HandsOff,
                    Status = row.Status,
                    Remark = row.Remark,
                    StartTime = FormatTime(row.StartTime),
                    EndTime = FormatTime(row.EndTime),
                    EnterTime = FormatTime(row.EnterTime),
                    EnterByName = row.EnterByName,
                    LiftTime = FormatTime(row.LiftTime)
                };
                currentItems = new List<RestrictionItemObject>();
            }

            if (row.Item_Object > 0)
            {
                string typeName = row.Item_Type switch
                {
                    3 => "STN",   // Type_Substation
                    14 => "FDR",  // Type_TransmissionFdr
                    22 => "CAP",  // Type_Capacitor
                    _ => "TRF"
                };
                string name = row.Item_Type == 3 ? row.Item_Description : row.Item_Name;

                currentItems.Add(new RestrictionItemObject
                {
                    ID = row.Item_Object,
                    Name = name,
                    TypeName = typeName
                });
            }
        }

        if (current != null)
        {
            current.Items = currentItems.ToArray();
            result.Add(current);
        }

        return result;
    }

    // LoadRequestReport is complex (involves multiple secondary lookups per row).
    // For the PDF report we use a simplified version that returns the base data.
    // The delay calculations would need the full post-processing logic from ISWP_Report.vb.
    // SQL: VERIFIED — base query from ISWP_Report.vb:LoadRequestReport
    public IEnumerable<ISWPRequestItem> LoadRequestReport(ISWPRequestFilter filter)
    {
        var startDate = DateTime.Parse(filter.StartDate);
        var endDate = DateTime.Parse(filter.EndDate).AddDays(1);

        string divClause = BuildDivisionClause(filter.DivisionName);
        string groupFilter = BuildWorkGroupFilter(filter.WorkGroup);

        string idFilter = filter.IDFilter > 0 ? " AND P.ISPermit = " + filter.IDFilter : "";

        // Simplified query — issued permits
        string sql = @"
            SELECT R.ISPermit AS PermitJobID,
                   P.WorkGroup AS WorkGroup,
                   OD.Name AS DivisionName,
                   OS.Name AS SubstationName,
                   R.PermitMove AS RequestTitle,
                   P.PreIssued AS ISPreIssued,
                   R.SubmitTime AS RequestTime,
                   J.TOIssued AS IssueTime
            FROM   SOA_ISPermitRequest R,
                   SOA_InServicePermit P,
                   Udb_Object OD,
                   Udb_Object OS,
                   SOA_Job J
            WHERE  " + groupFilter + @"
                   R.ISPermit = P.ISPermit AND
                   P.Job = J.Job AND
                   (J.TOIssued BETWEEN @StartDate AND @EndDate) AND
                   P.Division = OD.Object AND
                   P.Substation = OS.Object AND
                   P.Division IN (" + divClause + ")" + idFilter + @"
            ORDER BY IssueTime";

        using var conn = _connectionFactory.GetConnection();
        var raw = conn.Query<RequestReportRaw>(sql, new { StartDate = startDate, EndDate = endDate }).ToList();

        return raw.Select(r => new ISWPRequestItem
        {
            PermitName = "IS_" + r.PermitJobID,
            PermitJobID = r.PermitJobID,
            WorkGroup = r.WorkGroup,
            DivisionName = r.DivisionName,
            SubstationName = r.SubstationName,
            RequestTitle = r.RequestTitle,
            ISPreIssued = r.ISPreIssued,
            RequestTime = FormatTime(r.RequestTime),
            IssueTime = FormatTime(r.IssueTime)
        }).ToList();
    }

    #region Helpers

    private static ISWPSummaryGroupCount[] BuildGroupCounts(List<PermitRaw> permits)
    {
        var groups = new Dictionary<string, ISWPSummaryGroupCount>(StringComparer.OrdinalIgnoreCase);

        foreach (var p in permits)
        {
            if (!groups.TryGetValue(p.WorkGroup, out var g))
            {
                g = new ISWPSummaryGroupCount { Name = p.WorkGroup };
                groups[p.WorkGroup] = g;
            }

            bool hasShiftStart = p.ShiftStartTime != null && p.ShiftStartTime != DateTime.MinValue;
            bool isEmergent = p.Status != 0;

            if (hasShiftStart || isEmergent)
                g.Count1++;
            else
                g.Count2++;

            if (isEmergent)
                g.Count3++;
        }

        return groups.Values.OrderBy(g => g.Name).ToArray();
    }

    private static string BuildDivisionClause(string divisionName)
    {
        if (string.IsNullOrEmpty(divisionName) ||
            divisionName.StartsWith("all", StringComparison.OrdinalIgnoreCase))
        {
            return "SELECT Object FROM Udb_Object WHERE Type = 28 AND PrimaryGrouping <> 0";
        }

        return divisionName.Replace(";", ",").TrimEnd(',', ' ');
    }

    // Fix applied 2026-09-22 (E01) — integer-validated division list, mirrors
    // TOMSOnlineReportRepository.ParseIntegerList; rejects any non-numeric/injection payload.
    private static int[] ParseIntegerList(string semicolonDelimited)
    {
        if (string.IsNullOrEmpty(semicolonDelimited)) return Array.Empty<int>();
        return semicolonDelimited
            .Split(new[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
            .Where(s => int.TryParse(s.Trim(), out _))
            .Select(s => int.Parse(s.Trim()))
            .ToArray();
    }

    private static string BuildWorkGroupFilter(string workGroup)
    {
        if (string.IsNullOrEmpty(workGroup))
            return "";

        return "P.WorkGroup = '" + workGroup.Replace("'", "''") + "' AND ";
    }

    private static string FormatTime(object value)
    {
        if (value == null || value == DBNull.Value)
            return "";
        if (value is DateTime dt && dt == DateTime.MinValue)
            return "";
        return value.ToString();
    }

    #endregion

    #region Internal raw types

    private class PermitRaw
    {
        public string WorkGroup { get; set; }
        public DateTime? ShiftStartTime { get; set; }
        public int Status { get; set; }
    }

    private class RequestReportRaw
    {
        public long PermitJobID { get; set; }
        public string WorkGroup { get; set; }
        public string DivisionName { get; set; }
        public string SubstationName { get; set; }
        public string RequestTitle { get; set; }
        public int ISPreIssued { get; set; }
        public DateTime? RequestTime { get; set; }
        public DateTime? IssueTime { get; set; }
    }

    private class RestrictionRaw
    {
        public int Restriction { get; set; }
        public int HandsOff { get; set; }
        public string Remark { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public int Status { get; set; }
        public DateTime? EnterTime { get; set; }
        public DateTime? LiftTime { get; set; }
        public string EnterByName { get; set; }
        public int Item_Object { get; set; }
        public string Item_Name { get; set; }
        public string Item_Description { get; set; }
        public int Item_Type { get; set; }
    }

    #endregion
}
