using System.Collections.Generic;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsOnline;

public interface IISWPOnlineReportRepository
{
    ISWPSummaryReport LoadMgmtReport(ISWPSummaryFilter filter);
    IEnumerable<ISWPRequestItem> LoadRequestReport(ISWPRequestFilter filter);
    IEnumerable<NYISOItem> LoadNYISOReport(NYISOFilter filter);
    DeniedReport LoadDeniedReport(DeniedRequestFilter filter);
    IEnumerable<RestrictionItem> LoadRestrictions(RestrictionFilter filter);
}
