using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Dapper;
using Serilog;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries.FmsOnline;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsOnline
{
    public class FmsOnlineReportRepository : IFmsOnlineReportRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public FmsOnlineReportRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        // SQL: VERIFIED — copied from FMS_Report.vb:GetETStopTag
        public ETStopTagReport LoadETStopTags()
        {
            var sw = Stopwatch.StartNew();
            using (var conn = _connectionFactory.GetConnection())
            {
                var parms = conn.QueryFirstOrDefault<ETStopTagParameters>(FmsOnlineQueries.ETStopTagParameters);
                var tags = conn.Query<ETStopTagItem>(FmsOnlineQueries.ETStopTagList).ToArray();

                Log.Debug("FmsOnline LoadETStopTags: {Count} tags in {ElapsedMs}ms", tags.Length, sw.ElapsedMilliseconds);
                return new ETStopTagReport
                {
                    Expiration = parms?.Expiration ?? 0,
                    Warning = parms?.Warning ?? 0,
                    Tags = tags
                };
            }
        }

        // SQL: VERIFIED — copied from FMS_Report.vb:GetPhaseCheck
        public IEnumerable<PhaseCheckItem> LoadPhaseChecks(string startDate, string divisionFilter)
        {
            var sw = Stopwatch.StartNew();
            var parsedDate = DateTime.Parse(startDate).ToString("MM/dd/yyyy");

            var divisionClause = "";
            if (!string.IsNullOrEmpty(divisionFilter) && divisionFilter != "0")
            {
                var validDivisions = ParseIntegerList(divisionFilter);
                if (validDivisions.Length == 0)
                    return Enumerable.Empty<PhaseCheckItem>();
                divisionClause = " AND g.Grouping IN (" + string.Join(",", validDivisions) + ")";
            }

            var sql = string.Format(FmsOnlineQueries.PhaseCheckActive, parsedDate) + divisionClause
                + " UNION "
                + string.Format(FmsOnlineQueries.PhaseCheckArchive, parsedDate) + divisionClause
                + " ORDER BY Division ASC, Feeder ASC, Issued ASC, Status ASC";

            using (var conn = _connectionFactory.GetConnection())
            {
                var raw = conn.Query<PhaseCheckRaw>(sql).ToList();
                Log.Debug("FmsOnline LoadPhaseChecks: StartDate={StartDate} Div={Division} Rows={Count} in {ElapsedMs}ms",
                    startDate, divisionFilter, raw.Count, sw.ElapsedMilliseconds);
                return DeduplicatePhaseChecks(raw);
            }
        }

        // SQL: VERIFIED — copied from FMS_Report.vb:GetNetworkProtector
        public IEnumerable<NetworkProtectorItem> LoadNetworkProtectors()
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                var rawList = conn.Query<NWPRaw>(FmsOnlineQueries.NetworkProtectorMain).ToList();

                // Deduplicate by NWPId, keeping earliest MoveCompletion; propagate BlockOpen
                var deduped = new List<NWPRaw>();
                foreach (var row in rawList)
                {
                    var contactStatus = "Open";
                    if (row.MoveText != null && row.MoveText.IndexOf("BLOCK OPEN", StringComparison.OrdinalIgnoreCase) >= 0)
                        contactStatus = "Blocked Open";

                    if (deduped.Count > 0 && deduped[deduped.Count - 1].NWPId == row.NWPId)
                    {
                        if (contactStatus == "Blocked Open")
                            deduped[deduped.Count - 1].ContactStatus = contactStatus;
                        continue;
                    }

                    row.ContactStatus = contactStatus;
                    deduped.Add(row);
                }

                // Resolve ISOs to feeders, get networks, get job text
                int? lastFeeder = null;
                int? lastNetwork = null;
                string lastNetworkName = null;
                int? lastCard = null;
                string lastMoveText = null;

                var result = new List<NetworkProtectorItem>();
                foreach (var nwp in deduped)
                {
                    // Resolve feeder if equipment is not a feeder (Type_Feeder=40)
                    if (nwp.FeederType != 40)
                    {
                        var resolved = conn.QueryFirstOrDefault<NWPFeederResolved>(
                            FmsOnlineQueries.NetworkProtectorResolveFeeder, new { p1 = nwp.Feeder });
                        if (resolved != null)
                        {
                            nwp.Feeder = resolved.Feeder;
                            nwp.FeederName = resolved.FeederName;
                            nwp.FeederType = resolved.FeederType;
                        }
                    }

                    // Get network (cache by feeder)
                    if (lastFeeder.HasValue && lastFeeder.Value == nwp.Feeder)
                    {
                        nwp.Network = lastNetwork ?? 0;
                        nwp.NetworkName = lastNetworkName;
                    }
                    else
                    {
                        var net = conn.QueryFirstOrDefault<NWPNetwork>(
                            FmsOnlineQueries.NetworkProtectorGetNetwork, new { p1 = nwp.Feeder });
                        nwp.Network = net?.Network ?? 0;
                        nwp.NetworkName = net?.NetworkName;
                        lastFeeder = nwp.Feeder;
                        lastNetwork = nwp.Network;
                        lastNetworkName = nwp.NetworkName;
                    }

                    // Sanitize stop tag
                    if (!string.IsNullOrEmpty(nwp.StopTag))
                    {
                        var upper = nwp.StopTag.ToUpperInvariant();
                        if (!upper.Contains("SCADA") && !upper.Contains("CONTROL"))
                            nwp.StopTag = "XXXXXXX";
                    }

                    // Feeder status
                    nwp.FeederStatus = (!string.IsNullOrEmpty(nwp.CutOut) && string.IsNullOrEmpty(nwp.CutIn))
                        ? "Out of Service" : "In Service";

                    // Get job text (cache by card)
                    if (lastCard.HasValue && lastCard.Value == nwp.Card)
                    {
                        nwp.MoveText = lastMoveText;
                    }
                    else
                    {
                        var jobs = conn.Query<string>(FmsOnlineQueries.NetworkProtectorGetJobText,
                            new { p1 = nwp.Card }).ToList();
                        nwp.MoveText = jobs.Count > 0 ? string.Join("; ", jobs) : "";
                        lastCard = nwp.Card;
                        lastMoveText = nwp.MoveText;
                    }

                    // Recheck block open after fuse/disconnect text
                    if (nwp.MoveText.IndexOf("BLOCK OPEN", StringComparison.OrdinalIgnoreCase) >= 0)
                        nwp.ContactStatus = "Blocked Open";

                    result.Add(new NetworkProtectorItem
                    {
                        NWPId = nwp.NWPId,
                        NWPName = nwp.NWPName,
                        Card = nwp.Card,
                        CurrentlyOpen = nwp.CurrentlyOpen,
                        CutIn = nwp.CutIn,
                        CutOut = nwp.CutOut,
                        Feeder = nwp.Feeder,
                        FeederName = nwp.FeederName,
                        FeederType = nwp.FeederType,
                        Job = nwp.Job,
                        JobClass = nwp.JobClass,
                        MoveCompletion = nwp.MoveCompletion,
                        MoveText = nwp.MoveText,
                        StopTag = nwp.StopTag,
                        ContactStatus = nwp.ContactStatus,
                        FeederStatus = nwp.FeederStatus,
                        Network = nwp.Network,
                        NetworkName = nwp.NetworkName
                    });
                }

                // Sort by network, feeder, NWP name (matches legacy clsSorting)
                return result.OrderBy(r => r.NetworkName ?? "")
                             .ThenBy(r => r.FeederName ?? "")
                             .ThenBy(r => r.NWPName ?? "")
                             .ToList();
            }
        }

        // SQL: VERIFIED — copied from RegisteredTags.vb:LoadRegTags
        public IEnumerable<RegisteredTagReportItem> LoadRegisteredTags(string divisionFilter)
        {
            string sql;
            if (string.IsNullOrEmpty(divisionFilter) || divisionFilter.Trim().ToUpperInvariant() == "ALL")
            {
                sql = FmsOnlineQueries.RegisteredTagsAll;
            }
            else
            {
                var validDivisions = ParseIntegerList(divisionFilter);
                if (validDivisions.Length == 0)
                    return Enumerable.Empty<RegisteredTagReportItem>();
                sql = string.Format(FmsOnlineQueries.RegisteredTagsFiltered, string.Join(",", validDivisions));
            }

            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<RegisteredTagReportItem>(sql).ToList();
            }
        }

        private static int[] ParseIntegerList(string input)
        {
            if (string.IsNullOrEmpty(input)) return Array.Empty<int>();
            return input.Split(new[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(s => { int v; return int.TryParse(s.Trim(), out v) ? v : (int?)null; })
                        .Where(v => v.HasValue)
                        .Select(v => v.Value)
                        .Distinct()
                        .ToArray();
        }

        private static IEnumerable<PhaseCheckItem> DeduplicatePhaseChecks(List<PhaseCheckRaw> raw)
        {
            long prevEquip = 0;
            DateTime? prevIssue = null;

            foreach (var r in raw)
            {
                if (r.PhaseCheckEquip == prevEquip && r.Issued == prevIssue)
                    continue;

                prevEquip = r.PhaseCheckEquip;
                prevIssue = r.Issued;

                string status;
                if (!r.Status.HasValue || r.Status.Value >= 50) // Card_Closed = 50
                    status = "Closed";
                else
                    status = "Active";

                yield return new PhaseCheckItem
                {
                    Division = r.Division,
                    Feeder = r.Feeder,
                    Equipment = r.Equipment,
                    Issued = r.Issued?.ToString("MM/dd/yyyy HH:mm") ?? "",
                    Completed = r.Completed?.ToString("MM/dd/yyyy HH:mm") ?? "",
                    Operator = r.Operator ?? "",
                    Status = status
                };
            }
        }

        // Internal DTOs for raw Dapper mapping
        private class PhaseCheckRaw
        {
            public int Division { get; set; }
            public string Feeder { get; set; }
            public string Equipment { get; set; }
            public long PhaseCheckEquip { get; set; }
            public int? Status { get; set; }
            public DateTime? Issued { get; set; }
            public DateTime? Completed { get; set; }
            public string Operator { get; set; }
        }

        private class NWPRaw
        {
            public int Card { get; set; }
            public string CurrentlyOpen { get; set; }
            public string CutIn { get; set; }
            public string CutOut { get; set; }
            public int Feeder { get; set; }
            public string FeederName { get; set; }
            public int FeederType { get; set; }
            public int Job { get; set; }
            public int JobClass { get; set; }
            public string MoveCompletion { get; set; }
            public int NWPId { get; set; }
            public string NWPName { get; set; }
            public string MoveText { get; set; }
            public string StopTag { get; set; }
            public string ContactStatus { get; set; }
            public string FeederStatus { get; set; }
            public int Network { get; set; }
            public string NetworkName { get; set; }
        }

        private class NWPFeederResolved
        {
            public int Feeder { get; set; }
            public string FeederName { get; set; }
            public int FeederType { get; set; }
        }

        private class NWPNetwork
        {
            public int Network { get; set; }
            public string NetworkName { get; set; }
        }

        // ═══════════════════════════════════════════════════════════════════
        // Step 2: Feeder Reports
        // SQL: RECONSTRUCTED from ORPDO columns — MUST validate against Ingres schema
        // ═══════════════════════════════════════════════════════════════════

        // SQL: UNKNOWN — source is OpenROAD procedure LoadFdrActivityRpt
        public FeederActivityReport LoadFeederActivity(FeederReportFilter filter)
        {
            using var conn = _connectionFactory.GetConnection();
            var cells = conn.Query<FeederActivityCell>(FmsOnlineQueries.FeederActivityByDivision, new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate,
                DivisionName = filter.DivisionName,
                Network = filter.Network,
                Substation = filter.Substation,
                Feeder = filter.Feeder,
                Outage = filter.Outage,
                KV = filter.KV,
                TVBogey = filter.TVBogey,
                Filter3G = filter.Filter3G
            }).ToArray();

            var columns = cells.Select(c => c.CardClassName).Distinct().ToArray();
            var rows = cells.Select(c => c.DivisionName).Distinct().ToArray();

            return new FeederActivityReport
            {
                CardClassColumns = columns,
                DivisionRows = rows,
                Cells = cells,
                ColumnTotals = columns.Select(col => cells.Where(c => c.CardClassName == col).Sum(c => c.Count)).ToArray(),
                GrandTotal = cells.Sum(c => c.Count)
            };
        }

        // SQL: UNKNOWN — source is OpenROAD procedures LoadFdrHistoryData + CalcFdrHistoryData
        public FeederHistoryReport LoadFeederHistory(FeederReportFilter filter)
        {
            using var conn = _connectionFactory.GetConnection();
            var items = conn.Query<FeederHistoryItem>(FmsOnlineQueries.FeederHistoryCards, new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate,
                DivisionName = filter.DivisionName,
                Network = filter.Network,
                Substation = filter.Substation,
                Feeder = filter.Feeder,
                Outage = filter.Outage,
                KV = filter.KV,
                CardType = filter.CardType,
                MaxHours = filter.MaxHours,
                ExcludePlus = filter.ExcludePlus,
                TVBogey = filter.TVBogey,
                ExcludeWeekend = filter.ExcludeWeekend,
                Filter3G = filter.Filter3G,
                LimitTV = filter.LimitTV
            }).ToArray();

            // Statistics calculation will need to happen here or via SQL
            // Currently returns empty stats — actual computation is in OpenROAD CalcFdrHistoryData
            return new FeederHistoryReport
            {
                AllFeeders = items.Length,
                ValidFeeders = items.Length,
                ValidList = items,
                ValidStats = Array.Empty<FeederHistoryStatistics>(),
                ExceptionList = Array.Empty<FeederHistoryItem>(),
                ExceptionStats = Array.Empty<FeederHistoryStatistics>()
            };
        }

        // SQL: UNKNOWN — source is OpenROAD procedure LoadFdrMilestoneData
        public FeederMilestoneReport LoadFeederMilestone(string divisionName)
        {
            using var conn = _connectionFactory.GetConnection();
            var items = conn.Query<FeederMilestoneItem>(FmsOnlineQueries.FeederMilestoneCards, new
            {
                DivisionName = divisionName
            }).ToArray();

            return new FeederMilestoneReport
            {
                BogeyEnabled = 0,
                TVText = "",
                Feeders = items
            };
        }

        // SQL: UNKNOWN — source is OpenROAD procedure LoadOFR
        public FeederOutageReport LoadFeederOutage(string startDate, string endDate, string divisionName, int reportStatus, int filter)
        {
            using var conn = _connectionFactory.GetConnection();
            var parms = new { StartDate = startDate, EndDate = endDate, DivisionName = divisionName, Filter = filter };

            var summary = conn.Query<FeederOutageSummaryItem>(FmsOnlineQueries.FeederOutageTotalFeeders, parms).ToArray();
            var detail = conn.Query<FeederOutageDetailItem>(FmsOnlineQueries.FeederOutageCards, parms).ToArray();

            return new FeederOutageReport
            {
                Summary = summary,
                Detail = detail
            };
        }

        // SQL: UNKNOWN — source is OpenROAD procedure LoadFdrRestorationData
        public FeederRestorationReport LoadFeederRestoration(FeederReportFilter filter)
        {
            using var conn = _connectionFactory.GetConnection();
            var parms = new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate,
                DivisionName = filter.DivisionName,
                Outage = filter.Outage,
                KV = filter.KV,
                CardType = filter.CardType,
                MaxHours = filter.MaxHours,
                ExcludePlus = filter.ExcludePlus,
                TVBogey = filter.TVBogey,
                ExcludeWeekend = filter.ExcludeWeekend,
                Filter3G = filter.Filter3G,
                LimitTV = filter.LimitTV
            };

            // Both valid and exception come from same query with different ExceptionFlag
            // For now, run once — actual implementation needs two calls or a stored procedure
            var divisions = conn.Query<FeederRestorationDivision>(FmsOnlineQueries.FeederHistoryCards, parms).ToArray();

            return new FeederRestorationReport
            {
                ValidList = divisions,
                ExceptionList = Array.Empty<FeederRestorationDivision>()
            };
        }

        // ═══════════════════════════════════════════════════════════════════
        // Step 3: Equipment/Facility Reports
        // SQL: EXTRACTED from OpenROAD cac.dmt — MUST validate against Ingres schema
        // ═══════════════════════════════════════════════════════════════════

        public IEnumerable<FailedHiPotFeederItem> LoadFailedHiPotFeeders(string divisionName)
        {
            using var conn = _connectionFactory.GetConnection();
            return conn.Query<FailedHiPotFeederItem>(FmsOnlineQueries.FailedHiPotFeeders,
                new { DivisionName = divisionName }).ToList();
        }

        public IEnumerable<HiPotHistoryItem> LoadHiPotHistory(HiPotHistoryFilter filter)
        {
            var sql = filter.ReportType == 1
                ? FmsOnlineQueries.HiPotHistoryLatestPassed
                : FmsOnlineQueries.HiPotHistoryAllTests;

            using var conn = _connectionFactory.GetConnection();
            return conn.Query<HiPotHistoryItem>(sql, new
            {
                Division = filter.Division,
                Substation = filter.Substation,
                Network = filter.Network,
                Feeder = filter.Feeder,
                StartDate = filter.StartDate,
                EndDate = filter.EndDate
            }).ToList();
        }

        public IEnumerable<ManholeActivityItem> LoadManholeActivity(ManholeActivityFilter filter)
        {
            using var conn = _connectionFactory.GetConnection();
            var takeouts = conn.Query<ManholeActivityItem>(FmsOnlineQueries.ManholeActivityTakeout, new
            {
                Division = filter.Division,
                StartDate = filter.StartDate,
                EndDate = filter.EndDate
            });
            var restores = conn.Query<ManholeActivityItem>(FmsOnlineQueries.ManholeActivityRestore, new
            {
                Division = filter.Division,
                StartDate = filter.StartDate,
                EndDate = filter.EndDate
            });
            return takeouts.Concat(restores).OrderBy(r => r.StartTime).ToList();
        }

        public IEnumerable<ManholeEquipItem> LoadManholeEquipList(ManholeActivityFilter filter)
        {
            using var conn = _connectionFactory.GetConnection();
            return conn.Query<ManholeEquipItem>(FmsOnlineQueries.ManholeEquipList, new
            {
                Division = filter.Division
            }).ToList();
        }

        public IEnumerable<MtaLineItem> LoadMTALines(int feeder)
        {
            using var conn = _connectionFactory.GetConnection();
            return conn.Query<MtaLineItem>(FmsOnlineQueries.MTALinesByFeeder, new { Feeder = feeder }).ToList();
        }

        public IEnumerable<MtaHtvItem> LoadMTALineHTVList(int feeder)
        {
            using var conn = _connectionFactory.GetConnection();
            return conn.Query<MtaHtvItem>(FmsOnlineQueries.MTALineHTVList, new { Feeder = feeder }).ToList();
        }

        // ═══════════════════════════════════════════════════════════════════
        // Step 4: Operational Reports
        // SQL: EXTRACTED from OpenROAD cac.dmt — verified against db-scripts/
        // ═══════════════════════════════════════════════════════════════════

        public TvKpiResult LoadTvKpi(TvKpiFilter filter)
        {
            using var conn = _connectionFactory.GetConnection();
            var cards = conn.Query<TvKpiCardItem>(FmsOnlineQueries.TvKpiCards, new
            {
                CardType = filter.CardType,
                StartDate = filter.StartDate,
                EndDate = filter.EndDate
            }).ToList();

            var overrides = conn.Query<int>(FmsOnlineQueries.TvKpiLogOverrides, new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate
            }).ToHashSet();

            var included = cards.Where(c => c.TV_Bogey > 0 && !overrides.Contains(c.Card)).ToList();
            var excluded = cards.Where(c => c.TV_Bogey <= 0 || overrides.Contains(c.Card)).ToList();

            return new TvKpiResult
            {
                TvKpiMinutes = included.Sum(c => (long)c.DurationMinutes),
                TvKpiAvgMinutes = included.Count > 0 ? included.Sum(c => (long)c.DurationMinutes) / included.Count : 0,
                TvKpiEstMinutes = included.Sum(c => (long)c.TV_Bogey),
                TvKpiAvgEstMinutes = included.Count > 0 ? included.Sum(c => (long)c.TV_Bogey) / included.Count : 0,
                IncludedCards = included,
                ExcludedCards = excluded
            };
        }

        public IEnumerable<ProcessAutomationBlock> LoadProcessAutomation(ProcessAutomationFilter filter)
        {
            using var conn = _connectionFactory.GetConnection();
            return conn.Query<ProcessAutomationBlock>(FmsOnlineQueries.ProcessAutomationBlocks, new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate,
                Type = filter.Type
            }).ToList();
        }

        public IEnumerable<WarningByDeskRow> LoadWarningSummaryByDesk(WarningSummaryFilter filter)
        {
            string sql;
            if (!string.IsNullOrEmpty(filter.AppName))
                sql = FmsOnlineQueries.WarningSummaryByDeskByApp;
            else if (filter.ShiftType > 0)
                sql = FmsOnlineQueries.WarningSummaryByDeskFiltered;
            else
                sql = FmsOnlineQueries.WarningSummaryByDesk;

            using var conn = _connectionFactory.GetConnection();
            return conn.Query<WarningByDeskRow>(sql, new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate,
                ShiftType = filter.ShiftType,
                WarnType = filter.WarnType,
                WarningType = filter.WarnType,
                AppName = filter.AppName
            }).ToList();
        }

        public IEnumerable<WarningByDORow> LoadWarningSummaryByDO(WarningSummaryFilter filter)
        {
            var sql = !string.IsNullOrEmpty(filter.AppName)
                ? FmsOnlineQueries.WarningSummaryByDOByApp
                : FmsOnlineQueries.WarningSummaryByDO;

            using var conn = _connectionFactory.GetConnection();
            return conn.Query<WarningByDORow>(sql, new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate,
                WarnType = filter.WarnType,
                AppName = filter.AppName
            }).ToList();
        }

        public IEnumerable<OperationActivityByDeskItem> LoadOperationActivityByDesk(OperationActivityFilter filter)
        {
            var sql = !string.IsNullOrEmpty(filter.AppName)
                ? FmsOnlineQueries.OperationActivityByDeskByApp
                : FmsOnlineQueries.OperationActivityByDesk;

            using var conn = _connectionFactory.GetConnection();
            return conn.Query<OperationActivityByDeskItem>(sql, new
            {
                Application = filter.Application,
                AppName = filter.AppName,
                StartDate = filter.StartDate,
                EndDate = filter.EndDate,
                ShiftType = filter.ShiftType
            }).ToList();
        }

        public IEnumerable<OperationActivityByDOItem> LoadOperationActivityByDO(OperationActivityFilter filter)
        {
            using var conn = _connectionFactory.GetConnection();
            var byApp = conn.Query<OperationActivityByDOItem>(FmsOnlineQueries.OperationActivityByApplication, new
            {
                Application = filter.Application,
                StartDate = filter.StartDate,
                EndDate = filter.EndDate
            }).ToList();

            // Merge issue/complete/permit counts
            var issueCounts = conn.Query<dynamic>(FmsOnlineQueries.OperationActivityByIssueComplete, new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate
            }).ToDictionary(r => (int)r.Operator, r => new { Issued = (int)r.IssuedMoves, Completed = (int)r.CompletedMoves });

            var permitCounts = conn.Query<dynamic>(FmsOnlineQueries.OperationActivityByPermit, new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate
            }).ToDictionary(r => (int)r.Operator, r => (int)r.PermitMoves);

            foreach (var row in byApp)
            {
                if (issueCounts.TryGetValue(row.Operator, out var ic))
                {
                    row.IssuedMoves = ic.Issued;
                    row.CompletedMoves = ic.Completed;
                }
                if (permitCounts.TryGetValue(row.Operator, out var pm))
                    row.PermitMoves = pm;
                row.Moves = row.FMSMoves + row.TFMSMoves + row.SLCMoves + row.TLSMoves;
            }

            return byApp;
        }

        public ScheduledWorkResult LoadScheduledWork(ScheduledWorkFilter filter)
        {
            var sql = !string.IsNullOrEmpty(filter.AppName)
                ? FmsOnlineQueries.ScheduledWorkDataByApp
                : FmsOnlineQueries.ScheduledWorkData;

            using var conn = _connectionFactory.GetConnection();
            var raw = conn.Query<ScheduledWorkRawRow>(sql, new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate,
                AppName = filter.AppName
            }).ToList();

            var gap = conn.QueryFirstOrDefault<dynamic>(FmsOnlineQueries.ScheduledWorkGap);
            int gapLimit = gap?.Gap_Limit ?? 0;
            int gapUpdate = gap?.Gap_Update ?? 0;

            // Group by Date → Card → DO
            var days = raw.GroupBy(r => r.DateValue).Select(dayGroup => new ScheduledWorkDayItem
            {
                DateValue = dayGroup.Key,
                TotSeconds = dayGroup.Sum(r => r.Tot_Seconds),
                GapLimit = gapLimit,
                GapUpdate = gapUpdate,
                Cards = dayGroup.GroupBy(r => r.Card).Select(cardGroup =>
                {
                    var first = cardGroup.First();
                    return new ScheduledWorkCardItem
                    {
                        Application = first.Application,
                        Archive = first.Archive,
                        Card = first.Card,
                        SwitchingItem = first.SwitchingItem,
                        CardClass = first.CardClass,
                        CardClassName = first.CardClassName,
                        CardName = first.CardName,
                        Cutout = first.Cutout,
                        TotSeconds = cardGroup.Sum(r => r.Tot_Seconds),
                        DOList = cardGroup.Select(r => new ScheduledWorkDOItem
                        {
                            DOObject = r.DOObject,
                            DOName = r.DOName,
                            TotSeconds = r.Tot_Seconds
                        }).ToList()
                    };
                }).ToList()
            }).ToList();

            return new ScheduledWorkResult { GapLimit = gapLimit, GapUpdate = gapUpdate, Days = days };
        }

        // ═══════════════════════════════════════════════════════════════════
        // Step 5: SOA Reports
        // SQL: EXTRACTED from OpenROAD cac.dmt — verified against db-scripts/
        // ═══════════════════════════════════════════════════════════════════

        public IEnumerable<FCRProtectionItem> LoadFCRProtections(FCRProtectionFilter filter)
        {
            using var conn = _connectionFactory.GetConnection();
            var results = conn.Query<FCRProtectionItem>(FmsOnlineQueries.FCRProtectionResults, new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate
            }).ToList();

            foreach (var item in results)
            {
                item.ActualProtections = conn.Query<FCRProtectionEquip>(
                    FmsOnlineQueries.FCRActualProtections, new { WorkPermit = item.WorkPermit, IssueDate = item.IssueDate }).ToList();
                item.SuggestedProtections = conn.Query<FCRProtectionEquip>(
                    FmsOnlineQueries.FCRSuggestedProtections, new { WorkPermit = item.WorkPermit, IssueDate = item.IssueDate }).ToList();
            }

            return results;
        }

        public IEnumerable<DisseminationFileItem> LoadDisseminationFiles(DisseminationFilter filter)
        {
            var sql = filter.FilterType == 1
                ? FmsOnlineQueries.DisseminationFilesActive
                : FmsOnlineQueries.DisseminationFilesByDate;

            using var conn = _connectionFactory.GetConnection();
            var files = conn.Query<DisseminationFileItem>(sql, new
            {
                StartDate = filter.StartDate,
                EndDate = filter.EndDate
            }).ToList();

            foreach (var file in files)
            {
                file.DOXRef = conn.Query<DisseminationDOItem>(
                    FmsOnlineQueries.DisseminationDOXRef, new { FileID = file.FileID }).ToList();
            }

            return files;
        }

        public IEnumerable<OrderReportItem> LoadOrders(OrderReportFilter filter)
        {
            var sql = filter.Card > 0
                ? FmsOnlineQueries.OrderListForCard
                : FmsOnlineQueries.OrderListByDateRange;

            using var conn = _connectionFactory.GetConnection();
            return conn.Query<OrderReportItem>(sql, new
            {
                Card = filter.Card,
                Application = filter.Application,
                Status = filter.Status,
                StartDate = filter.StartDate,
                EndDate = filter.EndDate
            }).ToList();
        }
    }
}
