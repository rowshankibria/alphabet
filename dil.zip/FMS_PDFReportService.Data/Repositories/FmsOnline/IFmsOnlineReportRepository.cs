using System.Collections.Generic;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsOnline
{
    public interface IFmsOnlineReportRepository
    {
        ETStopTagReport LoadETStopTags();
        IEnumerable<PhaseCheckItem> LoadPhaseChecks(string startDate, string divisionFilter);
        IEnumerable<NetworkProtectorItem> LoadNetworkProtectors();
        IEnumerable<RegisteredTagReportItem> LoadRegisteredTags(string divisionFilter);

        // Step 2: Feeder Reports — SQL: RECONSTRUCTED from ORPDO columns — MUST validate against Ingres schema
        FeederActivityReport LoadFeederActivity(FeederReportFilter filter);
        FeederHistoryReport LoadFeederHistory(FeederReportFilter filter);
        FeederMilestoneReport LoadFeederMilestone(string divisionName);
        FeederOutageReport LoadFeederOutage(string startDate, string endDate, string divisionName, int reportStatus, int filter);
        FeederRestorationReport LoadFeederRestoration(FeederReportFilter filter);

        // Step 3: Equipment/Facility Reports
        IEnumerable<FailedHiPotFeederItem> LoadFailedHiPotFeeders(string divisionName);
        IEnumerable<HiPotHistoryItem> LoadHiPotHistory(HiPotHistoryFilter filter);
        IEnumerable<ManholeActivityItem> LoadManholeActivity(ManholeActivityFilter filter);
        IEnumerable<ManholeEquipItem> LoadManholeEquipList(ManholeActivityFilter filter);
        IEnumerable<MtaLineItem> LoadMTALines(int feeder);
        IEnumerable<MtaHtvItem> LoadMTALineHTVList(int feeder);

        // Step 4: Operational Reports
        TvKpiResult LoadTvKpi(TvKpiFilter filter);
        IEnumerable<ProcessAutomationBlock> LoadProcessAutomation(ProcessAutomationFilter filter);
        IEnumerable<WarningByDeskRow> LoadWarningSummaryByDesk(WarningSummaryFilter filter);
        IEnumerable<WarningByDORow> LoadWarningSummaryByDO(WarningSummaryFilter filter);
        IEnumerable<OperationActivityByDeskItem> LoadOperationActivityByDesk(OperationActivityFilter filter);
        IEnumerable<OperationActivityByDOItem> LoadOperationActivityByDO(OperationActivityFilter filter);
        ScheduledWorkResult LoadScheduledWork(ScheduledWorkFilter filter);

        // Step 5: SOA Reports
        IEnumerable<FCRProtectionItem> LoadFCRProtections(FCRProtectionFilter filter);
        IEnumerable<DisseminationFileItem> LoadDisseminationFiles(DisseminationFilter filter);
        IEnumerable<OrderReportItem> LoadOrders(OrderReportFilter filter);
    }
}
