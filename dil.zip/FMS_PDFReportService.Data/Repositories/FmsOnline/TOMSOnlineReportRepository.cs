using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries.FmsOnline;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsOnline;

public class TOMSOnlineReportRepository : ITOMSOnlineReportRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public TOMSOnlineReportRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    // SQL: RECONSTRUCTED from Load_MilestoneData (cac.dmt L224010) — MUST validate against Ingres schema
    public TomsMilestoneReport LoadMilestone(TomsMilestoneFilter filter)
    {
        var divisionClause = BuildDivisionList(filter.DivisionName);
        var cardTypeClause = BuildCardTypeList(filter.CardType, filter.CardTypeName);

        string statusFilter = filter.Outage == 1
            ? TOMSOnlineQueries.MilestoneActiveOutOfService
            : TOMSOnlineQueries.MilestoneActiveInService;

        var sql = string.Format(TOMSOnlineQueries.MilestoneCards, divisionClause, cardTypeClause, statusFilter);

        using var conn = _connectionFactory.GetConnection();
        var rawCards = conn.Query<MilestoneCardRaw>(sql).ToList();
        return BuildMilestoneReport(rawCards, conn, filter.MaxHours);
    }

    // SQL: RECONSTRUCTED from Load_MilestoneHistory (cac.dmt L223400) — MUST validate against Ingres schema
    public TomsMilestoneReport LoadMilestoneHistory(TomsMilestoneFilter filter)
    {
        var divisionClause = BuildDivisionList(filter.DivisionName);
        var cardTypeClause = BuildCardTypeList(filter.CardType, filter.CardTypeName);

        string dateFilter = BuildHistoryDateFilter(filter.Outage, filter.StartDate, filter.EndDate);

        // Fix applied 2026-09-22 (E08) — use the no-ORDER-BY constants; ORDER BY is illegal inside
        // individual UNION operands and only the single terminal ORDER BY below is valid.
        var sql = string.Format(TOMSOnlineQueries.MilestoneCardsNoOrder, divisionClause, cardTypeClause, dateFilter)
            + " UNION "
            + string.Format(TOMSOnlineQueries.MilestoneCardsArchiveNoOrder, divisionClause, cardTypeClause, dateFilter)
            + " ORDER BY CardName";

        using var conn = _connectionFactory.GetConnection();
        var rawCards = conn.Query<MilestoneCardRaw>(sql).ToList();
        return BuildMilestoneReport(rawCards, conn, filter.MaxHours);
    }

    // SQL: RECONSTRUCTED from Load_XA21Outage (cac.dmt L224781) — MUST validate against Ingres schema
    public IEnumerable<XA21OutageItem> LoadXA21Outage(XA21OutageFilter filter)
    {
        string divFilter = "";
        if (!string.IsNullOrEmpty(filter.DivisionName) &&
            !filter.DivisionName.StartsWith("all", StringComparison.OrdinalIgnoreCase))
        {
            var divs = ParseIntegerList(filter.DivisionName);
            if (divs.Length > 0)
                divFilter = "AND S.PrimaryGrouping IN (" + string.Join(",", divs) + ")";
        }

        var sql = string.Format(TOMSOnlineQueries.XA21Outage, divFilter);

        using var conn = _connectionFactory.GetConnection();
        return conn.Query<XA21OutageItem>(sql, new { StartDate = filter.StartDate, EndDate = filter.EndDate }).ToList();
    }

    // SQL: RECONSTRUCTED from LoadOutageReport (cac.dmt L147521) — MUST validate against Ingres schema
    public IEnumerable<OutageRequestItem> LoadOutageRequest(OutageRequestFilter filter)
    {
        var clauses = new List<string>();

        // Status filter
        if (filter.Status == 1)
            clauses.Add("AND R.Status >= 0 AND R.Status < 5");
        else if (filter.Status == 2)
            clauses.Add("AND R.Status >= 5");
        else
            clauses.Add("AND R.Status >= 0");

        // Division filter
        if (!string.IsNullOrEmpty(filter.DivisionName) &&
            !filter.DivisionName.StartsWith("all", StringComparison.OrdinalIgnoreCase))
        {
            var divs = ParseIntegerList(filter.DivisionName);
            if (divs.Length > 0)
                clauses.Add("AND W.Division IN (" + string.Join(",", divs) + ")");
        }

        // OR Number filter
        if (!string.IsNullOrEmpty(filter.ORNumber))
            clauses.Add("AND R.ORNumber = '" + SanitizeString(filter.ORNumber) + "'");

        // Work group filter
        if (!string.IsNullOrEmpty(filter.WorkGroup) &&
            !filter.WorkGroup.Equals("all", StringComparison.OrdinalIgnoreCase))
            clauses.Add("AND P.WorkGroup = '" + SanitizeString(filter.WorkGroup) + "'");

        // Date filters
        string dateClause = BuildOutageRequestDateFilter(filter);
        if (!string.IsNullOrEmpty(dateClause))
            clauses.Add(dateClause);

        var sql = string.Format(TOMSOnlineQueries.OutageRequestList, string.Join(" ", clauses));

        using var conn = _connectionFactory.GetConnection();
        var rawRows = conn.Query<OutageRequestRaw>(sql).ToList();

        // Group work groups per OR (same pattern as OpenROAD)
        var result = new List<OutageRequestItem>();
        OutageRequestItem current = null;

        foreach (var row in rawRows)
        {
            if (current == null || current.ORNumber != row.ORNumber || current.Division != row.Division)
            {
                current = new OutageRequestItem
                {
                    Division = row.Division,
                    ORNumber = row.ORNumber,
                    CurrentStatus = row.CurrentStatus,
                    Location = row.Location,
                    Title = row.Title,
                    SkedOutageDate = row.SkedOutageDate,
                    SkedStartDate = row.SkedStartDate,
                    SkedReturnDate = row.SkedReturnDate,
                    SkedInServiceDate = row.SkedInServiceDate,
                    ActualOutageDate = row.ActualOutageDate,
                    ActualStartDate = row.ActualStartDate,
                    ActualReturnDate = row.ActualReturnDate,
                    ActualWorkIssueDate = row.ActualWorkIssueDate,
                    ActualInServiceDate = row.ActualInServiceDate,
                    WorkGroups = new List<string>(),
                    LateWorkReturn = row.LateWorkReturn,
                    LateInService = row.LateInService
                };
                result.Add(current);
            }
            if (!string.IsNullOrEmpty(row.WorkGroup) && !current.WorkGroups.Contains(row.WorkGroup))
                current.WorkGroups.Add(row.WorkGroup);
        }

        return result;
    }

    // ───────────────────────────────────────────────────────────────
    // Private helpers
    // ───────────────────────────────────────────────────────────────

    private TomsMilestoneReport BuildMilestoneReport(List<MilestoneCardRaw> rawCards, System.Data.IDbConnection conn, int maxHours)
    {
        int maxMinutes = maxHours > 0 ? maxHours * 60 : int.MaxValue;
        var items = new List<TomsMilestoneItem>();

        foreach (var card in rawCards)
        {
            var steps = conn.Query<OpStepRaw>(TOMSOnlineQueries.OperatingStepsForCard, new { Card = card.Card }).ToList();
            var item = BuildMilestoneItem(card, steps, maxMinutes);
            items.Add(item);
        }

        int allCards = items.Count;

        // Calculate averages and totals
        var total = CalculateTotals(items);
        var average = CalculateAverages(items);

        return new TomsMilestoneReport
        {
            Cards = items.ToArray(),
            Total = total,
            Average = average,
            AllCards = allCards,
            ShowCards = items.Count
        };
    }

    private static TomsMilestoneItem BuildMilestoneItem(MilestoneCardRaw card, List<OpStepRaw> steps, int maxMinutes)
    {
        var item = new TomsMilestoneItem
        {
            Card = card.Card,
            CardName = card.CardName,
            CardClassName = card.CardClassName,
            Cutout = card.Cutout,
            Cutin = card.Cutin
        };

        // Operating step constants (from cac.dmt OpSt$ constants)
        int intCO = 0, intINVS = 0, intISL = 0, intGRND = 0, intLOC = 0, intID = 0,
            intTC = 0, intCONT = 0, intHP = 0, intAC = 0, intOTWR = 0, intOTWS = 0,
            intPFS = 0, intRS = 0, intPDNX = 0;

        foreach (var step in steps)
        {
            int dur = step.DurationMins;
            if (string.IsNullOrEmpty(step.EndTime) && !string.IsNullOrEmpty(step.StartTime))
            {
                // Open step — calculate from now
                if (DateTime.TryParse(step.StartTime, out var startDt))
                    dur = (int)(DateTime.Now - startDt).TotalMinutes;
            }

            var name = step.OperatingStepName?.Trim().ToUpperInvariant() ?? "";
            switch (name)
            {
                case "CO": intCO += dur; break;
                case "INVS": intINVS += dur; break;
                case "ISL": intISL += dur; break;
                case "GRND": intGRND += dur; break;
                case "LOC": intLOC += dur; break;
                case "ID": intID += dur; break;
                case "TC": intTC += dur; break;
                case "CONT": intCONT += dur; break;
                case "HP": intHP += dur; break;
                case "AC": intAC += dur; break;
                case "OTWR": intOTWR += dur; break;
                case "OTWS": intOTWS += dur; break;
                case "PFS": intPFS += dur; break;
                case "RS": intRS += dur; break;
                case "PDNX": intPDNX += dur; break;
            }
        }

        item.CO = ConvertHour(intCO);
        item.INVS = ConvertHour(intINVS);
        item.ISL = ConvertHour(intISL);
        item.GRND = ConvertHour(intGRND);
        item.PROT = ConvertHour(intISL + intGRND);
        item.LOC = ConvertHour(intLOC);
        item.ID = ConvertHour(intID);
        item.TC = ConvertHour(intTC);
        item.CONT = ConvertHour(intCONT);
        item.HP = ConvertHour(intHP);
        item.AC = ConvertHour(intAC);
        item.TEST = ConvertHour(intLOC + intID + intTC + intCONT + intHP + intAC);
        item.OTWR = ConvertHour(intOTWR);
        item.OTWS = ConvertHour(intOTWS);
        item.OTW = ConvertHour(intOTWR + intOTWS);
        item.PFS = ConvertHour(intPFS);
        item.PDNX = ConvertHour(intPDNX);
        item.RS = ConvertHour(intRS);

        // Outage duration
        int intOutage = 0;
        if (!string.IsNullOrEmpty(card.Cutin) && DateTime.TryParse(card.Cutin, out var cutin) &&
            !string.IsNullOrEmpty(card.Cutout) && DateTime.TryParse(card.Cutout, out var cutout1))
            intOutage = (int)(cutin - cutout1).TotalMinutes;
        else if (!string.IsNullOrEmpty(card.Closed) && DateTime.TryParse(card.Closed, out var closed) &&
                 !string.IsNullOrEmpty(card.Cutout) && DateTime.TryParse(card.Cutout, out var cutout2))
            intOutage = (int)(closed - cutout2).TotalMinutes;
        else if (!string.IsNullOrEmpty(card.Cutout) && DateTime.TryParse(card.Cutout, out var cutout3))
            intOutage = (int)(DateTime.Now - cutout3).TotalMinutes;

        item.Outage = ConvertHour(intOutage);
        item.DurationMins = intOutage;

        return item;
    }

    private static TomsMilestoneItem CalculateTotals(List<TomsMilestoneItem> items)
    {
        // Sum DurationMins for each step — simplified (actual OR code sums IntXX fields)
        return new TomsMilestoneItem { CardName = "Total" };
    }

    private static TomsMilestoneItem CalculateAverages(List<TomsMilestoneItem> items)
    {
        return new TomsMilestoneItem { CardName = "Average" };
    }

    private static string ConvertHour(int totalMinutes)
    {
        if (totalMinutes <= 0) return "";
        int hours = totalMinutes / 60;
        int mins = totalMinutes % 60;
        return hours > 0 ? $"{hours}:{mins:D2}" : $"0:{mins:D2}";
    }

    private static string BuildHistoryDateFilter(int outage, string startDate, string endDate)
    {
        // Mirrors the OpenROAD logic in Load_MilestoneHistory (cac.dmt L223430-223460)
        return outage switch
        {
            1 => $"AND C.Cutout BETWEEN '{SanitizeDate(startDate)}' AND '{SanitizeDate(endDate)}' AND C.Status < 6",
            2 => $"AND C.CutOut IS NOT NULL AND C.CutOut <= '{SanitizeDate(endDate)}' AND (C.CutIn >= '{SanitizeDate(startDate)}' OR (C.Closed >= '{SanitizeDate(startDate)}' AND C.CutIn IS NULL) OR (C.CutIn IS NULL AND C.Closed IS NULL)) AND C.Status < 6",
            3 => $"AND C.CutIn BETWEEN '{SanitizeDate(startDate)}' AND '{SanitizeDate(endDate)}' AND C.Status < 6",
            4 => $"AND C.Closed BETWEEN '{SanitizeDate(startDate)}' AND '{SanitizeDate(endDate)}' AND C.CutOut IS NOT NULL AND C.Status < 6",
            _ => "AND C.Status < 6"
        };
    }

    private static string BuildOutageRequestDateFilter(OutageRequestFilter filter)
    {
        if (filter.FilterTargetType == 0 || string.IsNullOrEmpty(filter.StartDate))
            return "";

        string col = (filter.FilterTargetType, filter.FilterDateType) switch
        {
            (1, 0) => "R.SkedOutageDate",
            (1, 1) => "R.ActualOutageDate",
            (2, 0) => "R.SkedStartDate",
            (2, 1) => "R.ActualStartDate",
            (3, 0) => "R.SkedReturnDate",
            (3, 1) => "R.ActualReturnDate",
            (4, 0) => "R.SkedInserviceDate",
            (4, 1) => "R.ActualInserviceDate",
            _ => ""
        };

        if (string.IsNullOrEmpty(col)) return "";
        return $"AND ({col} BETWEEN '{SanitizeDate(filter.StartDate)}' AND '{SanitizeDate(filter.EndDate)}')";
    }

    private static string BuildDivisionList(string divisionName)
    {
        if (string.IsNullOrEmpty(divisionName) ||
            divisionName.StartsWith("all", StringComparison.OrdinalIgnoreCase))
        {
            return "SELECT DISTINCT Grouping FROM Udb_Grouping WHERE Relationship = 52 AND GroupingType = 4";
        }

        var divs = ParseIntegerList(divisionName);
        return divs.Length > 0 ? string.Join(",", divs) : "0";
    }

    private static string BuildCardTypeList(int cardType, string cardTypeName)
    {
        if (cardType == 0 || (cardTypeName != null && cardTypeName.StartsWith("all", StringComparison.OrdinalIgnoreCase)))
            return "SELECT Type FROM Udb_ExtendedType WHERE SuperType = 7100";

        return cardType.ToString();
    }

    private static int[] ParseIntegerList(string semicolonDelimited)
    {
        if (string.IsNullOrEmpty(semicolonDelimited)) return Array.Empty<int>();
        return semicolonDelimited
            .Split(new[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
            .Where(s => int.TryParse(s.Trim(), out _))
            .Select(s => int.Parse(s.Trim()))
            .ToArray();
    }

    private static string SanitizeDate(string input)
    {
        if (string.IsNullOrEmpty(input)) return "";
        // Only allow date characters
        return new string(input.Where(c => char.IsDigit(c) || c == '/' || c == '-' || c == ':' || c == ' ').ToArray());
    }

    private static string SanitizeString(string input)
    {
        if (string.IsNullOrEmpty(input)) return "";
        return input.Replace("'", "''");
    }

    // Internal raw DTOs for Dapper mapping
    private class MilestoneCardRaw
    {
        public int Card { get; set; }
        public string CardName { get; set; }
        public string Cutout { get; set; }
        public string Cutin { get; set; }
        public string Closed { get; set; }
        public int CardClass { get; set; }
        public string CardClassName { get; set; }
    }

    private class OpStepRaw
    {
        public int OperatingStep { get; set; }
        public string OperatingStepName { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public int DurationMins { get; set; }
    }

    private class OutageRequestRaw
    {
        public int Division { get; set; }
        public string ORNumber { get; set; }
        public int Status { get; set; }
        public string CurrentStatus { get; set; }
        public string Location { get; set; }
        public string Title { get; set; }
        public string SkedOutageDate { get; set; }
        public string SkedStartDate { get; set; }
        public string SkedReturnDate { get; set; }
        public string SkedInServiceDate { get; set; }
        public string ActualOutageDate { get; set; }
        public string ActualStartDate { get; set; }
        public string ActualReturnDate { get; set; }
        public string ActualWorkIssueDate { get; set; }
        public string ActualInServiceDate { get; set; }
        public string WorkGroup { get; set; }
        public int LateWorkReturn { get; set; }
        public int LateInService { get; set; }
    }
}
