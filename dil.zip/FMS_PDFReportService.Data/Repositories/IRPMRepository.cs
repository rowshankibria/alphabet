using System.Collections.Generic;
using FMS_PDFReportService.Models.RPM;

namespace FMS_PDFReportService.Data.Repositories
{
    public interface IRPMRepository
    {
        IEnumerable<RPMGrouping> LoadAllGroupings();
        RPMMatrixData LoadMatrix(int groupId);
        IEnumerable<RPMFeeder> LoadFeeders(int groupId);
        IEnumerable<RPMCircuit> LoadCircuits(int groupId);
        IEnumerable<RPMMatrixCell> LoadMatrixGrid(int groupId);
        IEnumerable<RPMNote> LoadNotes(int groupId);
        IEnumerable<RPMRelayInfo> LoadRelayInfo(int groupId);
        IEnumerable<RPMDiagram> LoadDiagrams(int groupId);
        IEnumerable<RPMCircuitType> LoadCircuitTypes(int reportType);
    }
}
