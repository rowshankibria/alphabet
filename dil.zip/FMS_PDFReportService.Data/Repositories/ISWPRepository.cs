using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Models.Permits;

namespace FMS_PDFReportService.Data.Repositories
{
    public class ISWPRepository : IISWPRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public ISWPRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public ISWPPermitDetail LoadPermitDetail(int permitId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.QueryFirstOrDefault<ISWPPermitDetail>(ISWPQueries.LoadPermitDetail, new { p1 = permitId });
            }
        }

        public ISWPRequestDetail LoadRequestDetail(int permitId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.QueryFirstOrDefault<ISWPRequestDetail>(ISWPQueries.LoadRequestDetail, new { p1 = permitId });
            }
        }

        public IEnumerable<ISWPEquipment> LoadEquipment(int permitId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<ISWPEquipment>(ISWPQueries.LoadEquipment, new { p1 = permitId }).ToList();
            }
        }

        public IEnumerable<ISWPCondition> LoadConditions(int permitId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<ISWPCondition>(ISWPQueries.LoadConditions, new { p1 = permitId }).ToList();
            }
        }

        public IEnumerable<ISWPLogEntry> LoadPermitLog(int permitId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<ISWPLogEntry>(ISWPQueries.LoadPermitLog, new { p1 = permitId }).ToList();
            }
        }

        public IEnumerable<ISWPLogEntry> LoadRequestLog(int permitId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<ISWPLogEntry>(ISWPQueries.LoadRequestLog, new { p1 = permitId }).ToList();
            }
        }
    }
}
