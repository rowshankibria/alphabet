using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Data.Repositories
{
    public class TLSCardRepository : ITLSCardRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public TLSCardRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public TlsCardHeader LoadCardHeader(int cardId, int archiveFlag)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                var sql = archiveFlag == 1 ? TLSQueries.LoadCardHeaderArchive : TLSQueries.LoadCardHeader;
                var header = conn.QueryFirstOrDefault<TlsCardHeader>(sql, new { p1 = cardId });
                if (header == null) return null;

                var note = conn.QueryFirstOrDefault<string>(TLSQueries.LoadCardNote, new { p1 = cardId });
                header.CardNote = note;

                return header;
            }
        }

        public IEnumerable<TlsJob> LoadJobs(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? TLSQueries.LoadJobsArchive : TLSQueries.LoadJobs;
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<TlsJob>(sql, new { p1 = cardId }).ToList();
            }
        }

        public IEnumerable<TlsLineOOS> LoadLineOOS(string divisions, int status)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<TlsLineOOS>(TLSQueries.LoadLineOOS).ToList();
            }
        }

        public IEnumerable<TlsCircuitChange> LoadCircuitChanges(string divisions, string startDate, string endDate)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<TlsCircuitChange>(
                    TLSQueries.LoadCircuitChanges,
                    new { p1 = startDate, p2 = endDate }).ToList();
            }
        }

        public IEnumerable<TlsRevisionLogEntry> LoadRevisionLog(string divisions, string startDate, string endDate)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<TlsRevisionLogEntry>(
                    TLSQueries.LoadRevisionLog,
                    new { p1 = startDate, p2 = endDate }).ToList();
            }
        }
    }
}
