using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Dapper;
using Serilog;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries.FmsDos;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsDos;

public class DosRSMovesRepository : IDosRSMovesRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public DosRSMovesRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    // SQL: EXTRACTED from cac.dmt:L114439 (LoadOutstandingRSMoves) — MUST validate against production Ingres schema
    public IEnumerable<DosRSMoveItem> LoadFMSOutstandingRSMoves(bool useSpecialGrouping)
    {
        var sw = Stopwatch.StartNew();
        var sql = useSpecialGrouping
            ? DosRSMovesQueries.LoadFMSOutstandingRSMovesSpecial
            : DosRSMovesQueries.LoadFMSOutstandingRSMovesDivision;

        using var conn = _connectionFactory.GetConnection();
        var result = conn.Query<DosRSMoveItem>(sql).ToList();
        Log.Debug("DOS LoadFMSOutstandingRSMoves SpecialGrouping={Special} Rows={Count} in {ElapsedMs}ms",
            useSpecialGrouping, result.Count, sw.ElapsedMilliseconds);
        return result;
    }

    // SQL: EXTRACTED from soa.dmt:L19468 (TOMS RS Moves) — MUST validate against production Ingres schema
    public IEnumerable<DosRSMoveItem> LoadTOMSOutstandingRSMoves()
    {
        var sw = Stopwatch.StartNew();
        using var conn = _connectionFactory.GetConnection();
        var moves = conn.Query<DosRSMoveItem>(DosRSMovesQueries.LoadTOMSOutstandingRSMoves).ToList();

        // Secondary query: resolve division grouping per card (soa.dmt:L19468 secondary SELECT)
        foreach (var move in moves.Where(m => m.MoveEquipClass == 0))
        {
            var divisions = conn.Query<int>(DosRSMovesQueries.LoadTOMSRSMoveDivisions, new { Card = move.Card }).ToList();
            if (divisions.Count > 0)
                move.MoveEquipClass = divisions[0];
        }

        Log.Debug("DOS LoadTOMSOutstandingRSMoves Rows={Count} in {ElapsedMs}ms", moves.Count, sw.ElapsedMilliseconds);
        return moves;
    }
}
