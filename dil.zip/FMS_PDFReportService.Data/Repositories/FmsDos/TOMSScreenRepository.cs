using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Dapper;
using Serilog;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries.FmsDos;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsDos;

public class TOMSScreenRepository : ITOMSScreenRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public TOMSScreenRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    // SQL: EXTRACTED from soa.dmt:L21789 (ReportInformationItems) — MUST validate against production Ingres schema
    public IEnumerable<TOMSInformationItemRow> LoadInformationItems(int? divisionFilter = null)
    {
        var sw = Stopwatch.StartNew();
        using var conn = _connectionFactory.GetConnection();
        List<TOMSInformationItemRow> result;
        if (divisionFilter.HasValue && divisionFilter.Value > 0)
        {
            result = conn.Query<TOMSInformationItemRow>(
                TOMSScreenQueries.LoadInformationItemsByDivision,
                new { Division = divisionFilter.Value }).ToList();
        }
        else
        {
            result = conn.Query<TOMSInformationItemRow>(TOMSScreenQueries.LoadInformationItems).ToList();
        }
        Log.Debug("TOMS LoadInformationItems Div={Division} Rows={Count} in {ElapsedMs}ms",
            divisionFilter, result.Count, sw.ElapsedMilliseconds);
        return result;
    }

    // SQL: EXTRACTED from soa.dmt:L11520 (InactiveCardReview) — MUST validate against production Ingres schema
    public IEnumerable<TOMSInactiveCardRow> LoadInactiveCards(IEnumerable<int> divisions)
    {
        var divList = divisions?.ToList();
        if (divList == null || divList.Count == 0)
            return Enumerable.Empty<TOMSInactiveCardRow>();

        using var conn = _connectionFactory.GetConnection();

        // Get inactivity period from system parameters
        var inactivityPeriod = conn.QueryFirstOrDefault<int>(TOMSScreenQueries.LoadInactivityPeriod);
        if (inactivityPeriod <= 0) inactivityPeriod = 30;

        // Load cards — parameterized via string.Format for IN clause (integer list, safe from injection)
        var divisionCsv = string.Join(", ", divList);
        var cardSql = string.Format(TOMSScreenQueries.LoadInactiveCards, divisionCsv);
        var cards = conn.Query<(int Card, string Application, string CardName, string Note)>(cardSql).ToList();

        var results = new List<TOMSInactiveCardRow>();

        foreach (var card in cards)
        {
            if (card.Application == "SLC")
            {
                // For SLC cards, get switching items then check inactivity per item
                var items = conn.Query<(string SwitchingItemName, int SwitchingItem)>(
                    TOMSScreenQueries.LoadInactiveCardSwitchingItems,
                    new { Card = card.Card }).ToList();

                foreach (var item in items)
                {
                    var lastTime = conn.QueryFirstOrDefault<DateTime?>(
                        TOMSScreenQueries.LoadLastActivityTime,
                        new { Card = card.Card, SwitchingItem = item.SwitchingItem });

                    if (lastTime.HasValue)
                    {
                        var days = (int)(DateTime.Now - lastTime.Value).TotalDays;
                        if (days > inactivityPeriod)
                        {
                            results.Add(new TOMSInactiveCardRow
                            {
                                Card = card.Card,
                                Application = card.Application,
                                CardName = card.CardName,
                                SwitchingItem = item.SwitchingItem,
                                SwitchingItemName = item.SwitchingItemName,
                                Note = card.Note,
                                LastActivityTime = lastTime.Value.ToString("MM/dd/yyyy HH:mm"),
                                InactiveDays = days
                            });
                        }
                    }
                }
            }
            else
            {
                // TFMS cards — check inactivity directly (SwitchingItem = 0)
                var lastTime = conn.QueryFirstOrDefault<DateTime?>(
                    TOMSScreenQueries.LoadLastActivityTime,
                    new { Card = card.Card, SwitchingItem = 0 });

                if (lastTime.HasValue)
                {
                    var days = (int)(DateTime.Now - lastTime.Value).TotalDays;
                    if (days > inactivityPeriod)
                    {
                        results.Add(new TOMSInactiveCardRow
                        {
                            Card = card.Card,
                            Application = card.Application,
                            CardName = card.CardName,
                            SwitchingItem = 0,
                            SwitchingItemName = string.Empty,
                            Note = card.Note,
                            LastActivityTime = lastTime.Value.ToString("MM/dd/yyyy HH:mm"),
                            InactiveDays = days
                        });
                    }
                }
            }
        }

        return results;
    }
}
