using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Dapper;
using Serilog;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries.FmsDos;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsDos;

public class DosPhaseCheckRepository : IDosPhaseCheckRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public DosPhaseCheckRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    // SQL: EXTRACTED from cac.dmt:L80209 (standard feeder) / L80252 (archive)
    public IEnumerable<DosPhaseCheckItem> LoadPhaseChecksForFeeder(string feederList, string cardList, int workPermitJob, bool isArchive)
    {
        var sw = Stopwatch.StartNew();
        if (isArchive)
        {
            // Archive variant uses single feeder + single card
            using var conn = _connectionFactory.GetConnection();
            var feederId = int.Parse(feederList.Split(',')[0]);
            var cardId = int.Parse(cardList.Split(',')[0]);
            var result = conn.Query<DosPhaseCheckItem>(
                DosPhaseCheckQueries.LoadPhaseChecksForFeederArchive,
                new { p1 = feederId, p2 = feederId, p3 = workPermitJob, p4 = cardId }).ToList();
            Log.Debug("DOS LoadPhaseChecksForFeeder (archive) Feeder={Feeder} Card={Card} Rows={Count} in {ElapsedMs}ms",
                feederId, cardId, result.Count, sw.ElapsedMilliseconds);
            return result;
        }
        else
        {
            // Active variant uses IN lists — safe: values are system-controlled integer IDs
            var sql = string.Format(DosPhaseCheckQueries.LoadPhaseChecksForFeeder, feederList, cardList);
            using var conn = _connectionFactory.GetConnection();
            var result = conn.Query<DosPhaseCheckItem>(sql, new { p1 = workPermitJob }).ToList();
            Log.Debug("DOS LoadPhaseChecksForFeeder (active) Rows={Count} in {ElapsedMs}ms",
                result.Count, sw.ElapsedMilliseconds);
            return result;
        }
    }

    // SQL: EXTRACTED from cac.dmt:L80109 (3G/network variant)
    public IEnumerable<DosPhaseCheckItem> LoadPhaseChecksNetwork(string cardList, int workPermitJob)
    {
        var sw = Stopwatch.StartNew();
        var sql = string.Format(DosPhaseCheckQueries.LoadPhaseChecksNetwork, cardList);
        using var conn = _connectionFactory.GetConnection();
        var items = conn.Query<DosPhaseCheckItem>(sql, new { p1 = workPermitJob }).ToList();
        Log.Debug("DOS LoadPhaseChecksNetwork Rows={Count} in {ElapsedMs}ms", items.Count, sw.ElapsedMilliseconds);

        // Load PrintIDs via sub-select (cac.dmt:L80131)
        foreach (var item in items)
        {
            var printId = conn.QueryFirstOrDefault<string>(
                DosPhaseCheckQueries.LoadPrintIdForEquip,
                new { p1 = item.Equip, p2 = item.Card });
            item.PrintID = printId ?? "";

            var spcPrintId = conn.QueryFirstOrDefault<string>(
                DosPhaseCheckQueries.LoadPrintIdForEquip,
                new { p1 = item.SPC_Equip, p2 = item.Card });
            item.SPC_PrintID = spcPrintId ?? "";
        }

        return items;
    }

    public IEnumerable<DosPhaseCheckItem> LoadAllOutstandingPhaseChecks()
    {
        using var conn = _connectionFactory.GetConnection();
        return conn.Query<DosPhaseCheckItem>(DosPhaseCheckQueries.LoadAllOutstandingPhaseChecks).ToList();
    }
}
