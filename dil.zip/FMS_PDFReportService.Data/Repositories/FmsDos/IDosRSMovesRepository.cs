using System.Collections.Generic;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsDos;

public interface IDosRSMovesRepository
{
    IEnumerable<DosRSMoveItem> LoadFMSOutstandingRSMoves(bool useSpecialGrouping);
    IEnumerable<DosRSMoveItem> LoadTOMSOutstandingRSMoves();
}
