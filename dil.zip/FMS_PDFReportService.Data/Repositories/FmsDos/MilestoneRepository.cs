using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries.FmsDos;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsDos;

public class MilestoneRepository : IMilestoneRepository
{
    private readonly IConnectionFactory _connectionFactory;

    // Operating step constants — from Constant.vb
    private const int OpSt_CO = 12302;
    private const int OpSt_INVS = 12303;
    private const int OpSt_ISL = 12304;
    private const int OpSt_GRND = 12305;
    private const int OpSt_LOC = 12306;
    private const int OpSt_ID = 12307;
    private const int OpSt_TC = 12308;
    private const int OpSt_CONT = 12309;
    private const int OpSt_HP = 12310;
    private const int OpSt_AC = 12311;
    private const int OpSt_OTWR = 12312;
    private const int OpSt_OTWS = 12313;
    private const int OpSt_PFS = 12314;
    private const int OpSt_RS = 12315;
    private const int OpSt_PDNX = 12316;

    public MilestoneRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    // SQL: EXTRACTED from cac.dmt:L224010 (Load_MilestoneData) — MUST validate against production Ingres schema
    public IEnumerable<TOMSMilestoneRow> LoadMilestoneSummary(int filter, IEnumerable<int> divisions)
    {
        var divList = divisions?.ToList();
        if (divList == null || divList.Count == 0)
            return Enumerable.Empty<TOMSMilestoneRow>();

        if (filter != 1 && filter != 2)
            return Enumerable.Empty<TOMSMilestoneRow>();

        using var conn = _connectionFactory.GetConnection();

        // Build division IN list (integer list, safe from injection)
        var divisionCsv = string.Join(", ", divList);
        var cardSql = filter == 1
            ? string.Format(MilestoneQueries.LoadActiveCardsOutOfService, divisionCsv)
            : string.Format(MilestoneQueries.LoadActiveCardsInService, divisionCsv);

        var cards = conn.Query<(int Card, string CardName, string Cutout, string Cutin, int CardClass, string CardClassName)>(cardSql).ToList();

        var results = new List<TOMSMilestoneRow>();

        foreach (var card in cards)
        {
            var row = new TOMSMilestoneRow
            {
                Card = card.Card,
                CardName = card.CardName,
                CardClassName = card.CardClassName,
                Cutout = card.Cutout,
                Cutin = card.Cutin
            };

            // Load operating steps for this card
            var steps = conn.Query<MilestoneOperatingStepRow>(
                MilestoneQueries.LoadOperatingSteps, new { Card = card.Card }).ToList();

            foreach (var step in steps)
            {
                var duration = CalculateDuration(step);
                AccumulateStep(row, step.OperatingStep, duration);
            }

            // Composite: PROT = ISL + GRND
            row.IntPROT = row.IntISL + row.IntGRND;
            row.PROT = ConvertHour(row.IntPROT);

            // Composite: TEST = LOC + ID + TC + CONT + HP + AC
            row.IntTEST = row.IntLOC + row.IntID + row.IntTC + row.IntCONT + row.IntHP + row.IntAC;
            row.TEST = ConvertHour(row.IntTEST);

            // Composite: OTW = OTWR + OTWS
            row.IntOTW = row.IntOTWR + row.IntOTWS;
            row.OTW = ConvertHour(row.IntOTW);

            // Outage duration
            if (!string.IsNullOrWhiteSpace(row.Cutout))
            {
                if (string.IsNullOrWhiteSpace(row.Cutin))
                {
                    // Still out — calculate from cutout to now (done in SQL or approximated)
                    row.IntOutage = row.IntCO + row.IntINVS + row.IntPROT + row.IntTEST + row.IntOTW + row.IntPFS + row.IntRS + row.IntPDNX;
                }
                else
                {
                    row.IntOutage = row.IntCO + row.IntINVS + row.IntPROT + row.IntTEST + row.IntOTW + row.IntPFS + row.IntRS + row.IntPDNX;
                }
                row.Outage = ConvertHour(row.IntOutage);
            }

            results.Add(row);
        }

        return results;
    }

    private static int CalculateDuration(MilestoneOperatingStepRow step)
    {
        if (string.IsNullOrWhiteSpace(step.EndTime))
        {
            // Still in progress — calculate from StartTime to now
            if (DateTime.TryParse(step.StartTime, out var start))
                return (int)(DateTime.Now - start).TotalMinutes;
            return 0;
        }
        return step.DurationMins;
    }

    private static void AccumulateStep(TOMSMilestoneRow row, int opStep, int duration)
    {
        switch (opStep)
        {
            case OpSt_CO: row.IntCO += duration; row.CO = ConvertHour(row.IntCO); break;
            case OpSt_INVS: row.IntINVS += duration; row.INVS = ConvertHour(row.IntINVS); break;
            case OpSt_ISL: row.IntISL += duration; break;
            case OpSt_GRND: row.IntGRND += duration; break;
            case OpSt_LOC: row.IntLOC += duration; break;
            case OpSt_ID: row.IntID += duration; break;
            case OpSt_TC: row.IntTC += duration; break;
            case OpSt_CONT: row.IntCONT += duration; break;
            case OpSt_HP: row.IntHP += duration; break;
            case OpSt_AC: row.IntAC += duration; break;
            case OpSt_OTWR: row.IntOTWR += duration; break;
            case OpSt_OTWS: row.IntOTWS += duration; break;
            case OpSt_PFS: row.IntPFS += duration; row.PFS = ConvertHour(row.IntPFS); break;
            case OpSt_RS: row.IntRS += duration; row.RS = ConvertHour(row.IntRS); break;
            case OpSt_PDNX: row.IntPDNX += duration; row.PDNX = ConvertHour(row.IntPDNX); break;
        }
    }

    private static string ConvertHour(int totalMinutes)
    {
        if (totalMinutes <= 0) return "";
        var hours = totalMinutes / 60;
        var mins = totalMinutes % 60;
        return $"{hours}:{mins:D2}";
    }
}
