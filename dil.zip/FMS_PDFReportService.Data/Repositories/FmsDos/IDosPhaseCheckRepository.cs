using System.Collections.Generic;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsDos;

public interface IDosPhaseCheckRepository
{
    IEnumerable<DosPhaseCheckItem> LoadPhaseChecksForFeeder(string feederList, string cardList, int workPermitJob, bool isArchive);
    IEnumerable<DosPhaseCheckItem> LoadPhaseChecksNetwork(string cardList, int workPermitJob);
    IEnumerable<DosPhaseCheckItem> LoadAllOutstandingPhaseChecks();
}
