using System.Collections.Generic;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsDos;

public interface ITOMSScreenRepository
{
    IEnumerable<TOMSInformationItemRow> LoadInformationItems(int? divisionFilter = null);
    IEnumerable<TOMSInactiveCardRow> LoadInactiveCards(IEnumerable<int> divisions);
}
