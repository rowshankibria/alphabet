using System.Collections.Generic;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;

namespace FMS_PDFReportService.Data.Repositories.FmsDos;

public interface IMilestoneRepository
{
    IEnumerable<TOMSMilestoneRow> LoadMilestoneSummary(int filter, IEnumerable<int> divisions);
}
