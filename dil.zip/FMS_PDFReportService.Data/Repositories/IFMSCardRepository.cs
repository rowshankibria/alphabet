using System.Collections.Generic;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;
using FMS_PDFReportService.Models.Jobs.Colors;

namespace FMS_PDFReportService.Data.Repositories
{
    public interface IFMSCardRepository
    {
        FmsCardHeader LoadCardHeader(int cardId, int archiveFlag);
        CardNote LoadCardNote(int cardId);
        IEnumerable<NetworkObject> LoadNetworkObjects(int cardId);
        OperatingStep LoadOperatingStep(int cardId);
        OperatingStep LoadCurrentDelay(int cardId);
        FmsChecklist LoadChecklist(int cardId);
        IEnumerable<FmsJob> LoadJobs(int cardId, int archiveFlag);
        IEnumerable<FeederLogEntry> LoadFeederLog(int cardId, int archiveFlag);
        IEnumerable<WorkPermit> LoadWorkPermits(int cardId, int archiveFlag);
        IEnumerable<PermitProtection> LoadProtections(int permitJob, int archiveFlag);
        IEnumerable<PhaseCheck> LoadPhaseChecks(int cardId, int feederId, int permitJob, int archiveFlag);
        IEnumerable<LocationTag> LoadLocationTags(int permitJob);
        RelaySummaryData LoadRelaySummary(int cardId, int archiveFlag);
        List<FmsRelaySummaryRow> LoadFmsRelaySummary(int cardId, int archiveFlag, int switchingItem);
        IEnumerable<RegisteredTag> LoadRegisteredTags(int feederId);
        FmsColorInputs LoadFmsColorInputs(int cardId);
        IEnumerable<PhaseCheckEquipRow> LoadOpenPhaseChecks(int cardId);

    }
}
