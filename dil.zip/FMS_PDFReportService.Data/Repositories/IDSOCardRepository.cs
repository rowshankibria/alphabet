using System;
using System.Collections.Generic;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Data.Repositories
{
    public interface IDSOCardRepository
    {
        DsoCardHeader LoadCardHeader(int cardId, int archiveFlag);
        IEnumerable<TfmsJob> LoadJobs(int cardId, int archiveFlag);
        IEnumerable<SoaCardLogEntry> LoadCardLog(int cardId, int archiveFlag);
        IEnumerable<DsoDiscoveryCard> GetDeletedCards(DateTime lastCheck);
        IEnumerable<DsoDiscoveryCard> GetUpdatedCards(DateTime lastCheck);
        DateTime GetLastCheckTimestamp(string itemName);
        void RecordCheckTimestamp(string itemName, string oldValue, string newValue);
    }
}
