using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Models.Udb;

namespace FMS_PDFReportService.Data.Repositories
{
    public class UDBRepository : IUDBRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public UDBRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public UdbTypeGraph LoadTypeGraph()
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                var types = conn.Query<UdbType>(UDBQueries.LoadTypes).ToList();

                // Udb_Type.Name/Description are fixed-width CHAR columns, so Ingres pads them.
                foreach (var t in types)
                {
                    t.Name = (t.Name ?? string.Empty).TrimEnd();
                    t.Description = (t.Description ?? string.Empty).TrimEnd();
                }

                return new UdbTypeGraph
                {
                    Types = types,
                    Edges = conn.Query<UdbSuperType>(UDBQueries.LoadSuperTypes).ToList()
                };
            }
        }
    }
}
