using FMS_PDFReportService.Models.Udb;

namespace FMS_PDFReportService.Data.Repositories
{
    public interface IUDBRepository
    {
        /// <summary>Loads the whole type dictionary and its direct-parent edges.</summary>
        UdbTypeGraph LoadTypeGraph();
    }
}
