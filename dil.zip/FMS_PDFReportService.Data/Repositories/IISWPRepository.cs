using System.Collections.Generic;
using FMS_PDFReportService.Models.Permits;

namespace FMS_PDFReportService.Data.Repositories
{
    public interface IISWPRepository
    {
        ISWPPermitDetail LoadPermitDetail(int permitId);
        ISWPRequestDetail LoadRequestDetail(int permitId);
        IEnumerable<ISWPEquipment> LoadEquipment(int permitId);
        IEnumerable<ISWPCondition> LoadConditions(int permitId);
        IEnumerable<ISWPLogEntry> LoadPermitLog(int permitId);
        IEnumerable<ISWPLogEntry> LoadRequestLog(int permitId);
    }
}
