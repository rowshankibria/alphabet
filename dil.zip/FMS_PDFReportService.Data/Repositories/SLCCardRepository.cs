using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Data.Repositories
{
    public class SLCCardRepository : ISLCCardRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public SLCCardRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public SlcCardHeader LoadCardHeader(int cardId, int archiveFlag)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.QueryFirstOrDefault<SlcCardHeader>(SLCQueries.LoadCardHeader, new { p1 = cardId });
            }
        }

        public IEnumerable<TfmsJob> LoadJobs(int cardId, int archiveFlag, int slcItemType, int swItemId)
        {
            var sql = archiveFlag == 1 ? SLCQueries.LoadJobsArchive : SLCQueries.LoadJobs;
            using (var conn = _connectionFactory.GetConnection())
            {
                var param = archiveFlag == 1
                    ? new { p1 = cardId, p2 = cardId }
                    : (object)new { p1 = cardId };
                return conn.Query<TfmsJob>(sql, param).ToList();
            }
        }

        public IEnumerable<SoaCardLogEntry> LoadCardLog(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? SLCQueries.LoadCardLogArchive : SLCQueries.LoadCardLog;
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<SoaCardLogEntry>(sql, new { p1 = cardId }).ToList();
            }
        }

        public IEnumerable<WorkPermit> LoadWorkPermits(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? SLCQueries.LoadWorkPermitsArchive : SLCQueries.LoadWorkPermits;
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<WorkPermit>(sql, new { p1 = cardId }).ToList();
            }
        }
    }
}
