using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Models.RPM;

namespace FMS_PDFReportService.Data.Repositories
{
    public class RPMRepository : IRPMRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public RPMRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public IEnumerable<RPMGrouping> LoadAllGroupings()
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<RPMGrouping>(RPMQueries.LoadAllGroupings).ToList();
            }
        }

        public RPMMatrixData LoadMatrix(int groupId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                var group = conn.QueryFirstOrDefault<RPMGrouping>(RPMQueries.LoadMatrix, new { p1 = groupId });
                if (group == null) return null;

                return new RPMMatrixData
                {
                    GroupId = group.GroupId,
                    GroupName = group.GroupName,
                    Feeders = conn.Query<RPMFeeder>(RPMQueries.LoadFeeders, new { p1 = groupId }).ToList(),
                    Circuits = conn.Query<RPMCircuit>(RPMQueries.LoadCircuits, new { p1 = groupId }).ToList(),
                    MatrixGrid = conn.Query<RPMMatrixCell>(RPMQueries.LoadMatrixGrid, new { p1 = groupId }).ToList(),
                    Notes = conn.Query<RPMNote>(RPMQueries.LoadNotes, new { p1 = groupId }).ToList(),
                    RelayInfo = conn.Query<RPMRelayInfo>(RPMQueries.LoadRelayInfo, new { p1 = groupId }).ToList(),
                    Diagrams = conn.Query<RPMDiagram>(RPMQueries.LoadDiagrams, new { p1 = groupId }).ToList()
                };
            }
        }

        public IEnumerable<RPMFeeder> LoadFeeders(int groupId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<RPMFeeder>(RPMQueries.LoadFeeders, new { p1 = groupId }).ToList();
            }
        }

        public IEnumerable<RPMCircuit> LoadCircuits(int groupId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<RPMCircuit>(RPMQueries.LoadCircuits, new { p1 = groupId }).ToList();
            }
        }

        public IEnumerable<RPMMatrixCell> LoadMatrixGrid(int groupId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<RPMMatrixCell>(RPMQueries.LoadMatrixGrid, new { p1 = groupId }).ToList();
            }
        }

        public IEnumerable<RPMNote> LoadNotes(int groupId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<RPMNote>(RPMQueries.LoadNotes, new { p1 = groupId }).ToList();
            }
        }

        public IEnumerable<RPMRelayInfo> LoadRelayInfo(int groupId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<RPMRelayInfo>(RPMQueries.LoadRelayInfo, new { p1 = groupId }).ToList();
            }
        }

        public IEnumerable<RPMDiagram> LoadDiagrams(int groupId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<RPMDiagram>(RPMQueries.LoadDiagrams, new { p1 = groupId }).ToList();
            }
        }

        public IEnumerable<RPMCircuitType> LoadCircuitTypes(int reportType)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<RPMCircuitType>(RPMQueries.LoadCircuitTypes).ToList();
            }
        }
    }
}
