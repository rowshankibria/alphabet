using System.Collections.Generic;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Data.Repositories
{
    public interface ISLCCardRepository
    {
        SlcCardHeader LoadCardHeader(int cardId, int archiveFlag);
        IEnumerable<TfmsJob> LoadJobs(int cardId, int archiveFlag, int slcItemType, int swItemId);
        IEnumerable<SoaCardLogEntry> LoadCardLog(int cardId, int archiveFlag);
        IEnumerable<WorkPermit> LoadWorkPermits(int cardId, int archiveFlag);
    }
}
