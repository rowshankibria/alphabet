using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Data.Repositories
{
    public class SteamCardRepository : ISteamCardRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public SteamCardRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public SteamCardHeader LoadCardHeader(int cardId, int archiveFlag)
        {
            using (var conn = _connectionFactory.GetSdsConnection())
            {
                var header = conn.QueryFirstOrDefault<SteamCardHeader>(SteamQueries.LoadCardHeader, new { p1 = cardId });
                if (header == null) return null;

                header.Mains = conn.Query<SteamCardMain>(SteamQueries.LoadCardMains, new { p1 = cardId }).ToList();
                return header;
            }
        }

        public IEnumerable<TfmsJob> LoadJobs(int cardId, int archiveFlag)
        {
            using (var conn = _connectionFactory.GetSdsConnection())
            {
                return conn.Query<TfmsJob>(SteamQueries.LoadJobs, new { p1 = cardId }).ToList();
            }
        }

        public IEnumerable<int> GetActiveCardIds()
        {
            using (var conn = _connectionFactory.GetSdsConnection())
            {
                return conn.Query<int>(SteamQueries.GetActiveCardIds).ToList();
            }
        }

        public IEnumerable<SteamActiveCard> GetActiveCards()
        {
            // SOA_ActiveCard lives in dso_db, not sds_db
            using (var conn = _connectionFactory.GetDsoConnection())
            {
                return conn.Query<SteamActiveCard>(SteamQueries.GetActiveCards).ToList();
            }
        }
    }
}
