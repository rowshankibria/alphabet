using System.Data;

namespace FMS_PDFReportService.Data.Connection
{
    public interface IConnectionFactory
    {
        IDbConnection GetConnection();
        IDbConnection GetConnection(string databaseName);
        IDbConnection GetDsoConnection();
        IDbConnection GetSdsConnection();
        bool TestConnection();
        bool TestConnection(out string errorMessage);
        string GetCurrentServer();
    }
}
