using System;
using System.Data;
//using System.Data.Odbc;
using FMS_PDFReportService.Models;
using FMS_PDFReportService.Models.Configuration;
using Ingres.Client;
using Serilog;

namespace FMS_PDFReportService.Data.Connection
{
    public class IngresConnectionFactory : IConnectionFactory
    {
        private readonly string _primaryConnectionString;
        private readonly string _secondaryConnectionString;
        private readonly string _dsoDatabase;
        private readonly string _sdsDatabase;
        private bool _usePrimary = true;
        private DateTime _lastFailoverTime = DateTime.MinValue;
        private readonly TimeSpan _failoverCooldown;

        public IngresConnectionFactory()
        {
            var config = ReportConfigProvider.Current;
            _primaryConnectionString = config.PrimaryConnectionString ?? string.Empty;
            _secondaryConnectionString = config.SecondaryConnectionString ?? string.Empty;
            _dsoDatabase = config.DsoDatabase ?? string.Empty;
            _sdsDatabase = config.SdsDatabase ?? string.Empty;
            _failoverCooldown = TimeSpan.FromSeconds(config.FailoverCooldownSeconds);

            EventLogTracer.Info("Data",
                "IngresConnectionFactory constructed. PrimaryConnStrLen=" + _primaryConnectionString.Length +
                ", SecondaryConnStrLen=" + _secondaryConnectionString.Length +
                ", FailoverCooldownSeconds=" + config.FailoverCooldownSeconds +
                ", PrimaryServer=" + config.PrimaryServerDisplayName +
                ", SecondaryServer=" + config.SecondaryServerDisplayName +
                ", FmsDb=" + (config.FmsDatabase ?? "(null)") +
                ", DsoDb=" + (config.DsoDatabase ?? "(null)") +
                ", SdsDb=" + (config.SdsDatabase ?? "(null)"));
        }

        public IDbConnection GetConnection()
        {
            return CreateConnection(_usePrimary ? _primaryConnectionString : _secondaryConnectionString, null);
        }

        public IDbConnection GetConnection(string databaseName)
        {
            var baseConnStr = _usePrimary ? _primaryConnectionString : _secondaryConnectionString;
            var connStr = ReplaceDatabaseInConnectionString(baseConnStr, databaseName);
            return CreateConnection(connStr, databaseName);
        }

        public IDbConnection GetDsoConnection() => GetConnection(_dsoDatabase);

        public IDbConnection GetSdsConnection() => GetConnection(_sdsDatabase);

        public bool TestConnection()
        {
            return TestConnection(out _);
        }

        public bool TestConnection(out string errorMessage)
        {
            errorMessage = null;
            try
            {
                using (var conn = GetConnection())
                {
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = "SELECT 1";
                        cmd.ExecuteScalar();
                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return false;
            }
        }

        public string GetCurrentServer()
        {
            var config = ReportConfigProvider.Current;
            return _usePrimary ? config.PrimaryServerDisplayName : config.SecondaryServerDisplayName;
        }

        private IDbConnection CreateConnection(string connectionString, string databaseName)
        {
            IngresConnection conn = null;
            try
            {
                conn = new IngresConnection(connectionString);
                conn.Open();
                Log.Debug("Database connection opened to {Server}", GetCurrentServer());
                TryReconnectPrimary();
                return conn;
            }
            catch (IngresException ex)
            {
                conn?.Dispose();
                EventLogTracer.Warn("Data",
                    "Database connection FAILED on " + (_usePrimary ? "primary" : "secondary") +
                    " server " + GetCurrentServer() + ": " + ex.Message + ". Attempting failover.");
                Log.Warning(ex, "Database connection failed on {Mode} server {Server}, attempting failover",
                    _usePrimary ? "primary" : "secondary", GetCurrentServer());
                return TryFailover(databaseName);
            }
            catch
            {
                conn?.Dispose();
                throw;
            }
        }

        private IDbConnection TryFailover(string databaseName)
        {
            _usePrimary = !_usePrimary;
            _lastFailoverTime = DateTime.UtcNow;
            var baseConnStr = _usePrimary ? _primaryConnectionString : _secondaryConnectionString;
            // Reapply the originally requested catalog (DSO/SDS) so failover doesn't silently fall back to the base FMS catalog.
            var fallbackConnStr = databaseName == null
                ? baseConnStr
                : ReplaceDatabaseInConnectionString(baseConnStr, databaseName);
            EventLogTracer.Warn("Data",
                "Failover: switching to " + (_usePrimary ? "primary" : "secondary") +
                " server " + GetCurrentServer());
            Log.Warning("Failover: switching to {Mode} server {Server}",
                _usePrimary ? "primary" : "secondary", GetCurrentServer());
            IngresConnection conn = null;
            try
            {
                conn = new IngresConnection(fallbackConnStr);
                conn.Open();
                return conn;
            }
            catch
            {
                conn?.Dispose();
                throw;
            }
        }

        private void TryReconnectPrimary()
        {
            if (_usePrimary || DateTime.UtcNow - _lastFailoverTime < _failoverCooldown)
                return;

            try
            {
                using (var testConn = new IngresConnection(_primaryConnectionString))
                {
                    testConn.Open();
                    _usePrimary = true;
                    Log.Information("Reconnected to primary database server");
                }
            }
            catch
            {
                // Primary still down, stay on secondary
            }
        }

        private static string ReplaceDatabaseInConnectionString(string connectionString, string databaseName)
        {
            if (string.IsNullOrEmpty(connectionString))
                throw new InvalidOperationException(
                    "Cannot substitute database name: base connection string is empty. " +
                    "Check IReportConfig.PrimaryConnectionString / SecondaryConnectionString.");

            if (string.IsNullOrEmpty(databaseName))
                throw new ArgumentException(
                    "Database name is empty. Check IReportConfig.FmsDatabase / DsoDatabase / SdsDatabase.",
                    nameof(databaseName));

            // IngresConnectionStringBuilder normalises the keyword (Database=, Database Name=, etc.)
            // so the substitution works regardless of the exact form used in config.
            var builder = new IngresConnectionStringBuilder(connectionString) { Database = databaseName };
            return builder.ConnectionString;
        }
    }
}
