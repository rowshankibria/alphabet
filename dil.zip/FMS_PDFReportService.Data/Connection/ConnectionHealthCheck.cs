namespace FMS_PDFReportService.Data.Connection
{
    public class ConnectionHealthCheck
    {
        private readonly IConnectionFactory _connectionFactory;

        public ConnectionHealthCheck(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public bool IsPrimaryHealthy()
        {
            return _connectionFactory.TestConnection();
        }

        public string GetActiveServer()
        {
            return _connectionFactory.GetCurrentServer();
        }
    }
}
