# Telerik Nuget Provider Setup

username should be: `nuget.telerik.com\api-key` 
pass : your pass

official instruction: [telerik nuget setup](https://www.telerik.com/aspnet-core-ui/documentation/installation/installation-options/nuget-install#generate-a-nuget-api-key)




# Telerik Report Designer — Viewing ObjectDataSource Fields

This guide explains how to configure the Standalone Telerik Report Designer to resolve `ObjectDataSource` fields from the `FMS_PDFReportService.Models` assembly.

---

## Problem

When opening a `.trdx` file in the Standalone Designer, the Data Explorer shows `objectDataSource1` → `Item` but does not list the actual fields/properties. This is because the designer cannot reflect over the CLR type without access to the compiled assembly.

---

## Steps

### 1. Build the Solution

Build `FMS_PDFReportService.Models` so the DLL is available in the output folder (e.g. `bin\Debug`).

### 2. Copy the DLL to the Designer Folder

Copy `FMS_PDFReportService.Models.dll` to:

```
C:\Program Files (x86)\Progress\Telerik Reporting 2026 Q2\Report Designer\
```

If the Models project has dependencies (e.g. `Newtonsoft.Json.dll`), copy those too.

### 3. Edit the Designer Config Files

Edit **both** config files (run your editor as Administrator):

- `C:\Program Files (x86)\Progress\Telerik Reporting 2026 Q2\Report Designer\Telerik.ReportDesigner.exe.config`
- `C:\Program Files (x86)\Progress\Telerik Reporting 2026 Q2\Report Designer\Telerik.ReportDesigner.x86.exe.config`

Find or add the `<Telerik.Reporting>` section and add the assembly reference:

```xml
<Telerik.Reporting>
    <assemblyReferences>
        <add name="FMS_PDFReportService.Models" version="1.0.0.0" />
    </assemblyReferences>
</Telerik.Reporting>
```

> **Important:** Make sure this section is NOT inside XML comment markers (`<!-- -->`). Do not nest comments.

### 4. Restart the Designer

Close and reopen the Telerik Report Designer. Open the `.trdx` file — the Data Explorer should now display all properties of the bound CLR type (e.g. `FmsJob`) as available fields.

---

## Notes

- If you add new properties to the model class, rebuild and re-copy the DLL.
- The `version` attribute in the config must match the assembly version in the `.trdx` `<DataSource>` element.
- If the designer fails to open a report after the config change, verify the XML is well-formed (no nested comments, no stray `<!--` markers).
 