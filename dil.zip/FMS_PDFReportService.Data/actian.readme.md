# Actian .NET Data Provider Setup

## Overview

This project uses the **Actian .NET Data Provider** (`Actian.Client`) to connect to Ingres databases via the Data Access Server (DAS) protocol. This replaces the previous ODBC-based approach and eliminates the need to install an Ingres ODBC driver.

## Prerequisites

- Actian .NET Data Provider NuGet package (`Actian.Client 3.0.2`)
- The target Ingres server must have **Data Access Server (DAS)** running
- Network access from your machine to the DAS port on the Ingres server

## NuGet Package Installation

1. In Visual Studio: **Tools → NuGet Package Manager → Package Manager Settings**
2. Go to **Package Sources** → click **+**
3. Set **Source** to the folder containing the `.nupkg` file (e.g. `C:\Users\<username>\Downloads`)
4. Give it a name like `Actian Local` → click **Update** → **OK**
5. In **Package Manager Console**, select the `FMS_PDFReportService.Data` project and run:
   ```
   Install-Package Actian.Client -Version 3.0.2 -Source "Actian Local"
   ```

## Connection String Format

```xml
<connectionStrings>
  <add name="IngresPrimary"
       connectionString="Host=<server>;Port=<das-port>;Database=<db>;User ID=<user>;Password=<pwd>;"
       providerName="Ingres.Client" />
</connectionStrings>
```

| Parameter   | Description                          |
|-------------|--------------------------------------|
| `Host`      | Ingres server hostname               |
| `Port`      | DAS port number (see below)          |
| `Database`  | Database name (e.g. `dso_d1`)        |
| `User ID`   | Database user                        |
| `Password`  | Database password                    |

## Finding the DAS Port on an Ingres Server

SSH into the target database server and run:

```bash
# One-liner: shows installation ID, DAS status, and DAS port
echo "Installation: $(ingprenv II_INSTALLATION)"; ingstatus | grep -i "data access"; netstat -tlnp 2>/dev/null | grep iigcd
```

Or step by step:

```bash
# 1. Check installation ID
ingprenv II_INSTALLATION

# 2. Confirm DAS is running
ingstatus
# Look for: Data Access server (iigcd) - 1 running

# 3. If DAS is not running, start it
ingstart -iigcd

# 4. Find the DAS port
netstat -tlnp 2>/dev/null | grep iigcd
# Pick the port in the 21xxx range (primary listener)
```

## Verifying Connectivity from Your Machine

```powershell
# Test if the DAS port is reachable
Test-NetConnection -ComputerName <server-hostname> -Port <das-port>

# TcpTestSucceeded = True means the port is open
# TcpTestSucceeded = False means a firewall is blocking it — contact your network admin
```

## Licensing

The Actian .NET Data Provider is licensed under a royalty-free click-through agreement. It can be installed on any number of machines for **internal use** within the organization. See `LICENSE.txt` in the NuGet package for full terms.
