#!/usr/bin/env bash
# Re-runs: template generation, compile of Models + Data + groupers (against Telerik stubs), 715 checks.
# Needs: Python 3.9+ ; VS 2022 Roslyn csc.exe ; .NET Framework 4.8 reference assemblies.
# Usage: PROJ=<path to Telerik-proj> bash runtests.sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; FX="$(dirname "$HERE")"
PROJ="${PROJ:?set PROJ to the Telerik-proj folder}"
REF="C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.8"
CSC="C:/Program Files/Microsoft Visual Studio/2022/Community/MSBuild/Current/Bin/Roslyn/csc.exe"
cd "$HERE"
python gen_trdx.py "$FX/Templates" > /dev/null          # regenerates the delivered templates (idempotent)
python build.py "$PROJ" out "$FX/Code"
cp -f "$PROJ/FMS_PDFReportService.Data/bin/Debug/Serilog.dll" "$PROJ/FMS_PDFReportService.Data/bin/Debug/Dapper.StrongName.dll" out/
"$CSC" -nologo -noconfig -nostdlib+ -target:exe -langversion:latest -out:out/Tests.exe \
  "-r:$REF/mscorlib.dll" "-r:$REF/System.dll" "-r:$REF/System.Core.dll" "-r:$REF/System.Xml.dll" "-r:$REF/System.Xml.Linq.dll" \
  "-r:$REF/Facades/netstandard.dll" "-r:$REF/Facades/System.Runtime.dll" \
  -r:out/FMS_PDFReportService.Models.dll -r:out/FMS_PDFReportService.Data.dll -r:out/EngineGroupers.dll Tests.cs
./out/Tests.exe "$FX/Templates" rows.json
