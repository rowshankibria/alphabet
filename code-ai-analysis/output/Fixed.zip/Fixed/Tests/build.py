import sys, os, re, subprocess, glob
# usage: build.py <projroot> <outdir> [overlay_dir]
root, out = sys.argv[1], sys.argv[2]
overlay = sys.argv[3] if len(sys.argv) > 3 else None
CSC = r"C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\Roslyn\csc.exe"
REF = r"C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8"
BIN = os.path.join(root, "FMS_PDFReportService.Data", "bin", "Debug")
os.makedirs(out, exist_ok=True)
LANG = "latest"
def files(proj):
    cpath = os.path.join(root, proj, proj + ".csproj")
    if overlay and os.path.exists(os.path.join(overlay, proj, proj + ".csproj")):
        cpath = os.path.join(overlay, proj, proj + ".csproj")
    cs = open(cpath, encoding="utf-8-sig").read()
    res = []
    for inc in re.findall(r'<Compile Include="([^"]+)"', cs):
        rel = os.path.join(proj, inc.replace("\\", os.sep))
        src = os.path.join(root, rel)
        if overlay and os.path.exists(os.path.join(overlay, rel)):
            src = os.path.join(overlay, rel)
        res.append(src)
    return res
def fw(*names): return ["/r:" + os.path.join(REF, n) for n in names]
base = fw("mscorlib.dll","System.dll","System.Core.dll","System.Data.dll","System.Configuration.dll","System.Drawing.dll","Microsoft.CSharp.dll","System.Xml.dll","System.Xml.Linq.dll","System.Transactions.dll",os.path.join("Facades","netstandard.dll"),os.path.join("Facades","System.Runtime.dll"),os.path.join("Facades","System.Threading.Tasks.dll"))
def csc(name, srcs, refs):
    dll = os.path.join(out, name + ".dll")
    cmd = [CSC, "/nologo", "/noconfig", "/nostdlib+", "/target:library", "/langversion:" + LANG, "/warn:0", "/out:" + dll] + base + refs + srcs
    p = subprocess.run(cmd, capture_output=True, text=True)
    errs = [l for l in (p.stdout+p.stderr).splitlines() if "error" in l.lower()]
    print(f"{name}: exit={p.returncode} errors={len(errs)} files={len(srcs)}")
    for l in errs[:40]: print("   ", l.replace(root, "<root>"))
    return p.returncode == 0, dll
ok1, m = csc("FMS_PDFReportService.Models", files("FMS_PDFReportService.Models"),
             ["/r:" + os.path.join(BIN, "Serilog.dll"), "/r:" + os.path.join(BIN, "System.Memory.dll")])
ok2, d = csc("FMS_PDFReportService.Data", files("FMS_PDFReportService.Data"),
             ["/r:" + m, "/r:" + os.path.join(BIN, "Serilog.dll"), "/r:" + os.path.join(BIN, "Dapper.StrongName.dll"), "/r:" + os.path.join(BIN, "Actian.Client.dll")])
# Engine: real IReportGrouper.cs + ReportGroupers.cs against Telerik/renderer stubs
eng = os.path.join(root, "FMS_PDFReportService.Engine")
gsrc = []
for rel in ["Groupers/IReportGrouper.cs", "Groupers/ReportGroupers.cs"]:
    p = os.path.join(eng, rel.replace("/", os.sep))
    if overlay and os.path.exists(os.path.join(overlay, "FMS_PDFReportService.Engine", rel.replace("/", os.sep))):
        p = os.path.join(overlay, "FMS_PDFReportService.Engine", rel.replace("/", os.sep))
    gsrc.append(p)
gsrc.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "enginestub", "Stubs.cs"))
ok3, g = csc("EngineGroupers", gsrc, ["/r:" + m, "/r:" + d])
sys.exit(0 if ok1 and ok2 and ok3 else 1)
