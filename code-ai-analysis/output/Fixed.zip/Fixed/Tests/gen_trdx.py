"""Generates TLSCard.trdx, TFMSCard.trdx, TOMSWorkPermit.trdx, TFMSCardLog.trdx.
Structure follows v1/Fixed/FeederCard1.trdx (sections, margins, footer, column-header group)."""
import os, sys
from xml.sax.saxutils import escape, quoteattr

OUT = sys.argv[1]
NS = "http://schemas.telerik.com/reporting/2026/2.1"
ASM = "FMS_PDFReportService.Models, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null"

def q(v):  # attribute value
    return quoteattr(v)

def tb(name, left, top, width, height, value, size="8pt", bold=False, align=None, valign="Middle",
       border="all", can_grow=False, anchor=False, fmt=None, bindings=(), italic=False):
    attrs = f'Width="{width}in" Height="{height}in" Left="{left}in" Top="{top}in" Value={q(value)}'
    if fmt: attrs += f' Format={q(fmt)}'
    attrs += ' CanGrow="True"'   # every cell grows, so a multi-line value never cuts off or misaligns a row
    if anchor: attrs += ' Anchoring="Top, Bottom"'
    attrs += f' Name="{name}"'
    st = f'<Style{" TextAlign=" + q(align) if align else ""} VerticalAlign="{valign}">'
    bold_attr = ' Bold="True"' if bold else ''
    font = f'<Font Name="Arial" Size="{size}"{bold_attr} />'
    if border == "all":
        b = '<BorderStyle Default="Solid" /><BorderWidth Default="0.5pt" />'
    elif border == "none":
        b = '<BorderStyle Default="None" />'
    elif border == "bottom":
        b = '<BorderStyle Bottom="Solid" /><BorderWidth Bottom="0.5pt" />'
    elif border == "bottom2":
        b = '<BorderStyle Bottom="Solid" /><BorderWidth Bottom="1.5pt" />'
    elif border == "lr":
        b = '<BorderStyle Left="Solid" Right="Solid" /><BorderWidth Left="0.5pt" Right="0.5pt" />'
    else:
        raise ValueError(border)
    x = f'<TextBox {attrs}>{st}{font}{b}</Style>'
    if bindings:
        x += '<Bindings>' + ''.join(f'<Binding Path="{p}" Expression={q(e)} />' for p, e in bindings) + '</Bindings>'
    return x + '</TextBox>'

def report(name, width, dstype, page_header, report_header, detail_h, detail, footer_items,
           groups, params, report_footer=None):
    x = ['<?xml version="1.0" encoding="utf-8"?>',
         f'<Report DataSourceName="ods" Width="{width}in" Name="{name}" PageNumberingStyle="ResetNumberingAndCount" xmlns="{NS}">',
         '<DataSources><ObjectDataSource ParameterValues="null" Name="ods"><DataSource>',
         f'<String>{escape(dstype)}, {escape(ASM)}</String>',
         '</DataSource></ObjectDataSource></DataSources>', '<Items>']
    if page_header is not None:
        h, items = page_header
        x.append(f'<PageHeaderSection PrintOnFirstPage="False" Height="{h}in" Name="pageHeader"><Items>{"".join(items)}</Items></PageHeaderSection>')
    if report_header is not None:
        h, items = report_header
        x.append(f'<ReportHeaderSection Height="{h}in" Name="reportHeader"><Items>{"".join(items)}</Items></ReportHeaderSection>')
    x.append(f'<DetailSection Height="{detail_h}in" Name="detailSection"><Items>{"".join(detail)}</Items></DetailSection>')
    if report_footer is not None:
        h, items = report_footer
        x.append(f'<ReportFooterSection Height="{h}in" Name="reportFooter"><Items>{"".join(items)}</Items></ReportFooterSection>')
    x.append(f'<PageFooterSection Height="0.3in" Name="pageFooter"><Items>{"".join(footer_items)}</Items></PageFooterSection>')
    x.append('</Items>')
    x.append('<PageSettings PaperKind="Letter" Landscape="True" ColumnCount="1" ColumnSpacing="0in"><Margins>'
             '<MarginsU Left="0.15in" Right="0.15in" Top="0.5in" Bottom="0.5in" /></Margins></PageSettings>')
    x.append('<StyleSheet><StyleRule><Style><Padding Left="2pt" Right="2pt" /></Style><Selectors>'
             '<TypeSelector Type="TextItemBase" /><TypeSelector Type="HtmlTextBox" /></Selectors></StyleRule></StyleSheet>')
    x.append('<Groups>' + ''.join(groups) + '</Groups>')
    if params:
        x.append('<ReportParameters>' + ''.join(f'<ReportParameter Name="{p}" AllowNull="True" />' for p in params) + '</ReportParameters>')
    x.append('</Report>')
    return '\n'.join(x) + '\n'

def footer(width):
    return [tb("txtPrintTime", 0, 0.05, 4, 0.2, "=Now()", fmt="{0:MM/dd/yyyy HH:mm}", border="none"),
            tb("txtPageNum", round(width - 2.5, 2), 0.05, 2.5, 0.2, "='Page ' + PageNumber + ' of ' + PageCount",
               align="Right", border="none")]

def column_group(items, h=0.36):
    return ('<Group Name="grpColumns"><GroupHeader>'
            f'<GroupHeaderSection PrintOnEveryPage="True" Height="{h}in" Name="columnHeader"><Items>{"".join(items)}</Items></GroupHeaderSection>'
            '</GroupHeader><GroupFooter><GroupFooterSection Height="0.01in" Name="columnFooter"><Style Visible="False" /></GroupFooterSection>'
            '</GroupFooter><Groupings><Grouping Expression="=1" /></Groupings></Group>')

def P(n): return f"= Parameters.{n}.Value"

ROW = 0.27          # DOS row height (measured 0.268-0.27in)
DATA = "8pt"        # DOS data font: Arial 8
HDR = "8pt"         # column header font (bold)

# --------------------------------------------------------------------------------------------- TLS
def tls():
    W = 10.7
    cols = [  # name, left, width, value, align, bgField, fgField, grow
        ("txtTOOp", 0.0, 0.35, "", "Center", None, None, False),
        ("txtTOIssued", 0.35, 0.75, "= Fields.TOIssuedText", "Center", "TOIssuedBg", None, False),
        ("txtTOComplete", 1.10, 0.75, "= Fields.TOCompleteText", "Center", "TOCompleteBg", None, False),
        ("txtStation", 1.85, 1.10, "= Fields.StationText", None, None, None, True),
        ("txtCircuit", 2.95, 1.10, "= Fields.CircuitText", None, None, None, False),
        ("txtMove", 4.05, 3.50, "= Fields.MoveText", None, "MoveBg", "MoveFg", True),
        ("txtResults", 7.55, 1.10, "= Fields.ResultsText", None, None, None, True),
        ("txtStatus", 8.65, 0.25, "= Fields.StatusText", "Center", None, None, False),
        ("txtRSOp", 8.90, 0.35, "", "Center", None, None, False),
        ("txtRSIssued", 9.25, 0.72, "= Fields.RSIssuedText", "Center", "RSIssuedBg", None, False),
        ("txtRSComplete", 9.97, 0.72, "= Fields.RSCompleteText", "Center", "RSCompleteBg", None, False),
    ]
    detail = []
    for n, l, w, v, a, bg, fg, grow in cols:
        b = []
        if bg: b.append(("Style.BackgroundColor", f"= Fields.{bg}"))
        if fg: b.append(("Style.Color", f"= Fields.{fg}"))
        detail.append(tb(n, l, 0, w, ROW, v, size=DATA, align=a, can_grow=grow, anchor=True, bindings=b))
    hdr = [
        tb("hdrTakeOut", 0, 0, 1.85, 0.18, "Take Out", size=HDR, bold=True, align="Center"),
        tb("hdrStation", 1.85, 0, 1.10, 0.36, "Station", size=HDR, bold=True, align="Center"),
        tb("hdrCircuit", 2.95, 0, 1.10, 0.36, "Circuit", size=HDR, bold=True, align="Center"),
        tb("hdrMove", 4.05, 0, 3.50, 0.36, "Move", size=HDR, bold=True, align="Center"),
        tb("hdrResults", 7.55, 0, 1.10, 0.36, "Results", size=HDR, bold=True, align="Center"),
        tb("hdrStatus", 8.65, 0, 0.25, 0.36, "", size=HDR, bold=True, align="Center"),
        tb("hdrRestore", 8.90, 0, 1.79, 0.18, "Restore", size=HDR, bold=True, align="Center"),
        tb("hdrTOOp", 0, 0.18, 0.35, 0.18, "Op", size=HDR, bold=True, align="Center"),
        tb("hdrTOIssued", 0.35, 0.18, 0.75, 0.18, "Issued", size=HDR, bold=True, align="Center"),
        tb("hdrTOComplete", 1.10, 0.18, 0.75, 0.18, "Complete", size=HDR, bold=True, align="Center"),
        tb("hdrRSOp", 8.90, 0.18, 0.35, 0.18, "Op", size=HDR, bold=True, align="Center"),
        tb("hdrRSIssued", 9.25, 0.18, 0.72, 0.18, "Issued", size=HDR, bold=True, align="Center"),
        tb("hdrRSComplete", 9.97, 0.18, 0.72, 0.18, "Complete", size=HDR, bold=True, align="Center"),
    ]
    rh = [
        tb("txtLinenumber", 0, 0, 2.0, 0.24, P("Linenumber"), size="9pt", bold=True),
        tb("txtLineTypeName", 2.0, 0, 2.0, 0.24, P("LineTypeName"), size="9pt", bold=True),
        tb("lblNote", 4.0, 0, 3.0, 0.24, "Note:", bold=True),
        tb("lblCircuitNote", 7.0, 0, 3.69, 0.24, "Circuit Note:", bold=True),
    ]
    lines = [("Route", "Route:", "RouteName"), ("Carrier", "Carrier:", "CarrierName"),
             ("TypeOfWork", "Type of Work:", "CardTypeName"), ("Feeders", "Fdrs / Nwks:", "FeedersText"),
             ("Stations", "Stations:", "StationsText")]
    top = 0.24
    for key, label, param in lines:
        rh.append(tb("lbl" + key, 0, top, 1.0, 0.24, label, bold=True, align="Right"))
        rh.append(tb("txt" + key, 1.0, top, 3.0, 0.24, P(param), can_grow=(key in ("Feeders", "Stations"))))
        top = round(top + 0.24, 2)
    rh.append(tb("lblClosed", 0, top, 1.0, 0.24, P("ClosedLabel"), bold=True, align="Right"))
    rh.append(tb("txtClosed", 1.0, top, 3.0, 0.24, P("ClosedText")))
    rh += [
        tb("txtCardNote", 4.0, 0.24, 3.0, 1.44, P("CardNote"), valign="Top", can_grow=True),
        tb("txtCircuitNote", 7.0, 0.24, 3.69, 0.48, P("CircuitNote"), valign="Top", can_grow=True),
        tb("lblReason", 7.0, 0.72, 3.69, 0.24, "Reason For Failure:", bold=True),
        tb("txtReason", 7.0, 0.96, 3.69, 0.72, P("ReasonForFailure"), valign="Top", can_grow=True),
    ]
    ph = [tb("pgLinenumber", 0, 0, 2.0, 0.24, P("Linenumber"), size="9pt", bold=True, border="none")]
    params = ["Linenumber", "LineTypeName", "RouteName", "CarrierName", "CardTypeName", "FeedersText",
              "StationsText", "ClosedLabel", "ClosedText", "CardNote", "CircuitNote", "ReasonForFailure"]
    return report("TLSCard", W, "FMS_PDFReportService.Models.Jobs.TlsJob", (0.4, ph), (1.9, rh),
                  ROW, detail, footer(W), [column_group(hdr)], params)

# -------------------------------------------------------------------------------------------- TOMS
def toms():
    W = 10.7
    cols = [  # FeederCard1 grid geometry (== toms-dos.pdf grid)
        ("txtTOOp", 0.0, 0.35, "", "Center", None, None, False, None),
        ("txtTOIssued", 0.35, 0.75, "= Fields.TOIssuedText", "Center", "TOIssuedBg", None, False, None),
        ("txtTOComplete", 1.10, 0.75, "= Fields.TOCompleteText", "Center", "TOCompleteBg", None, False, None),
        ("txtID", 1.85, 0.35, "", "Center", None, None, False, None),
        ("txtType", 2.20, 0.85, "= Fields.TypeText", None, None, "EquipFg", True, None),
        ("txtEquip", 3.05, 0.80, "= Fields.EquipText", None, None, "EquipFg", True, None),
        ("txtG", 3.85, 0.25, "= Fields.GText", "Center", None, "GFg", False, None),
        ("txtMove", 4.10, 3.45, "= Fields.MoveText", None, "MoveBg", "MoveFg", True, "= Not Fields.MoveBold"),
        ("txtOrigin", 7.55, 0.25, "= Fields.OriginText", "Center", "OriginBg", None, False, None),
        ("txtResponse", 7.80, 1.10, "= Fields.ResponseText", None, None, None, True, None),
        ("txtRSOp", 8.90, 0.35, "", "Center", None, None, False, None),
        ("txtRSIssued", 9.25, 0.72, "= Fields.RSIssuedText", "Center", "RSIssuedBg", None, False, None),
        ("txtRSComplete", 9.97, 0.72, "= Fields.RSCompleteText", "Center", "RSCompleteBg", None, False, None),
    ]
    detail = []
    for n, l, w, v, a, bg, fg, grow, vis in cols:
        b = []
        if vis: b.append(("Visible", vis))
        if bg: b.append(("Style.BackgroundColor", f"= Fields.{bg}"))
        if fg: b.append(("Style.Color", f"= Fields.{fg}"))
        detail.append(tb(n, l, 0, w, ROW, v, size=DATA, align=a, can_grow=grow, anchor=True, bindings=b))
    # Heading rows: same cell, bold (the DOS card prints every JobClass 0 row bold)
    detail.append(tb("txtMoveHead", 4.10, 0, 3.45, ROW, "= Fields.MoveText", size=DATA, bold=True,
                     can_grow=True, anchor=True,
                     bindings=[("Visible", "= Fields.MoveBold"), ("Style.BackgroundColor", "= Fields.MoveBg"),
                               ("Style.Color", "= Fields.MoveFg")]))
    hdr = [
        tb("hdrTakeOut", 0, 0, 1.85, 0.18, "Take Out", size=HDR, bold=True, align="Center"),
        tb("hdrID", 1.85, 0, 0.35, 0.36, "ID", size=HDR, bold=True, align="Center"),
        tb("hdrType", 2.20, 0, 0.85, 0.36, "Type", size=HDR, bold=True, align="Center"),
        tb("hdrEquip", 3.05, 0, 0.80, 0.36, "Equipment", size=HDR, bold=True, align="Center"),
        tb("hdrG", 3.85, 0, 0.25, 0.36, "G", size=HDR, bold=True, align="Center"),
        tb("hdrMove", 4.10, 0, 3.45, 0.36, "Move", size=HDR, bold=True, align="Center"),
        tb("hdrOrigin", 7.55, 0, 0.25, 0.36, "", size=HDR, bold=True, align="Center"),
        tb("hdrResponse", 7.80, 0, 1.10, 0.36, "Response", size=HDR, bold=True, align="Center"),
        tb("hdrRestore", 8.90, 0, 1.79, 0.18, "Restore", size=HDR, bold=True, align="Center"),
        tb("hdrTOOp", 0, 0.18, 0.35, 0.18, "Op", size=HDR, bold=True, align="Center"),
        tb("hdrTOIssued", 0.35, 0.18, 0.75, 0.18, "Issued", size=HDR, bold=True, align="Center"),
        tb("hdrTOComplete", 1.10, 0.18, 0.75, 0.18, "Complete", size=HDR, bold=True, align="Center"),
        tb("hdrRSOp", 8.90, 0.18, 0.35, 0.18, "Op", size=HDR, bold=True, align="Center"),
        tb("hdrRSIssued", 9.25, 0.18, 0.72, 0.18, "Issued", size=HDR, bold=True, align="Center"),
        tb("hdrRSComplete", 9.97, 0.18, 0.72, 0.18, "Complete", size=HDR, bold=True, align="Center"),
    ]
    rh = [
        tb("txtCard", 0, 0, 1.05, 0.24, P("CardText"), size="9pt", bold=True),
        tb("txtCardClass", 1.05, 0, 1.6, 0.24, P("CardClassName"), size="9pt", bold=True),
        tb("txtFeederNames", 2.65, 0, 4.75, 0.24, P("FeederNames"), size="9pt", bold=True),
        tb("lblNote", 7.4, 0, 3.29, 0.24, "Note:", bold=True),
        tb("lblCutOut", 0, 0.24, 1.05, 0.24, "Cut Out:", bold=True, align="Right"),
        tb("txtCutOut", 1.05, 0.24, 1.6, 0.24, P("CutOutText")),
        tb("lblCutIn", 0, 0.48, 1.05, 0.24, "Cut In:", bold=True, align="Right"),
        tb("txtCutIn", 1.05, 0.48, 1.6, 0.24, P("CutInText")),
        tb("txtBlank", 0, 0.72, 2.65, 0.48, ""),
        tb("lblClosed", 0, 1.2, 1.05, 0.24, P("ClosedLabel"), bold=True, align="Right"),
        tb("txtClosed", 1.05, 1.2, 1.6, 0.24, P("ClosedText")),
        tb("txtDescription", 2.65, 0.24, 4.75, 1.2, P("Description"), valign="Top", can_grow=True),
        tb("txtNote", 7.4, 0.24, 3.29, 1.2, P("NoteText"), valign="Top", can_grow=True),
    ]
    ph = [tb("pgCard", 0, 0, 1.05, 0.24, P("CardText"), size="9pt", bold=True, border="none"),
          tb("pgCardClass", 1.05, 0, 1.6, 0.24, P("CardClassName"), size="9pt", bold=True, border="none"),
          tb("pgFeederNames", 2.65, 0, 8.04, 0.24, P("FeederNames"), size="9pt", bold=True, border="none")]
    params = ["CardText", "CardClassName", "FeederNames", "Description", "CutOutText", "CutInText",
              "ClosedLabel", "ClosedText", "NoteText"]
    return report("TFMSCard", W, "FMS_PDFReportService.Models.Jobs.TfmsJob", (0.4, ph), (1.66, rh),
                  ROW, detail, footer(W), [column_group(hdr)], params)

# --------------------------------------------------------------------------- TOMS permits + protections
def permits():
    W = 10.7
    title = [tb("txtTitle", 0, 0.05, W, 0.25, '= "Permits and Protections for " + Parameters.FeederNames.Value',
                size="10pt", bold=True, align="Center", border="none")]
    pcols = [("Label", 0, 1.0), ("Issued", 1.0, 1.12), ("ID", 2.12, 0.4), ("Type", 2.52, 1.29),
             ("Equipment", 3.81, 1.13), ("Move", 4.94, 4.6), ("Complete", 9.54, 1.15)]
    gh = []
    for key, l, w in pcols:
        val = "= Fields.PermitLabel" if key == "Label" else key
        gh.append(tb("hdrPermit" + key, l, 0.1, w, 0.22, val, size="8pt", bold=True, align="Center"))
    vals = {"Issued": "= Fields.PermitIssued", "ID": "= Fields.PermitID", "Type": "= Fields.PermitType",
            "Equipment": "= Fields.PermitEquipment", "Move": "= Fields.PermitMove", "Complete": "= Fields.PermitComplete"}
    for key, l, w in pcols[1:]:
        gh.append(tb("txtPermit" + key, l, 0.32, w, 0.27, vals[key], size="8pt",
                     align=("Center" if key in ("Issued", "Complete", "ID") else None),
                     valign="Top", can_grow=(key == "Move"), anchor=True))
    prot = [("System", "system", 1.15, 0.62, "CardTypeName"), ("Card", "Card", 1.77, 0.56, "Card"),
            ("TOIssued", "Issued", 2.33, 0.68, "TOIssued"), ("TOComplete", "Complete", 3.01, 0.70, "TOComplete"),
            ("Station", "Station", 3.71, 0.80, "Subsordesk"), ("PrintID", "ID", 4.51, 0.26, "PrintID"),
            ("Type", "type", 4.77, 0.75, "EquipClassName"), ("Equip", "Equipment", 5.52, 0.75, "EquipName"),
            ("Move", "Move", 6.27, 3.05, "TOMove"), ("RSIssued", "Issued", 9.32, 0.69, "RSIssued"),
            ("RSComplete", "Complete", 10.01, 0.68, "RSComplete")]
    gh.append(tb("lblProtections", 0, 0.65, 1.15, 0.22, "Protections:", size="7.5pt", bold=True, align="Right",
                 border="none"))
    for key, label, l, w, _ in prot:
        gh.append(tb("hdrProt" + key, l, 0.65, w, 0.22, label, size="7.5pt", bold=True, border="bottom"))
    detail = []
    for key, _, l, w, field in prot:
        detail.append(tb("txtProt" + key, l, 0, w, 0.24, f"= Fields.{field}", size="7pt", valign="Top",
                         border="none", can_grow=(key == "Move"), anchor=True,
                         bindings=[("Visible", "= Not Fields.IsEmpty")]))
    detail.append(tb("txtNoProtection", 1.15, 0, 9.54, 0.24, "No protection moves for this permit", size="7pt",
                     valign="Top", border="none", anchor=True, bindings=[("Visible", "= Fields.IsEmpty")]))
    group = ('<Group Name="grpPermit"><GroupHeader>'
             f'<GroupHeaderSection Height="0.9in" Name="permitHeader"><Items>{"".join(gh)}</Items></GroupHeaderSection>'
             '</GroupHeader><GroupFooter><GroupFooterSection Height="0.15in" Name="permitFooter" /></GroupFooter>'
             '<Groupings><Grouping Expression="= Fields.PermitKey" /></Groupings></Group>')
    rf = (0.3, [tb("txtNoPermits", 0, 0.05, W, 0.22, '= "No permits for " + Parameters.FeederNames.Value',
                    border="none", bindings=[("Visible", "= Count(Fields.PermitKey) = 0")])])
    # Title must also print on page 1: page header with PrintOnFirstPage default (True)
    x = report("TOMSWorkPermit", W, "FMS_PDFReportService.Models.Cards.TomsPermitRow", (0.4, title), None,
               0.24, detail, footer(W), [group], ["FeederNames"], report_footer=rf)
    return x.replace('<PageHeaderSection PrintOnFirstPage="False" ', '<PageHeaderSection ')

# ------------------------------------------------------------------------------------------ TOMS log
def cardlog():
    W = 10.7
    title = [tb("txtTitle", 0, 0.05, W, 0.3, '= "TFMS Card Log for " + Parameters.FeederNames.Value',
                size="12pt", bold=True, align="Center", border="none")]
    hdr = [tb("hdrDate", 0, 0, 1.25, 0.24, "Date", size="9pt", bold=True, border="bottom2"),
           tb("hdrStatus", 1.25, 0, 1.15, 0.24, "Status", size="9pt", bold=True, border="bottom2"),
           tb("hdrLog", 2.4, 0, 8.29, 0.24, "Log Entry", size="9pt", bold=True, border="bottom2")]
    detail = [tb("txtDate", 0, 0, 1.25, 0.26, "= Fields.LogTime", size="9pt", fmt="{0:MM/dd/yy HH:mm}",
                 valign="Top", border="bottom", anchor=True),
              tb("txtStatus", 1.25, 0, 1.15, 0.26, "= Fields.LogStatus", size="9pt", valign="Top",
                 border="bottom", anchor=True),
              tb("txtLog", 2.4, 0, 8.29, 0.26, "= Fields.Log", size="9pt", valign="Top", border="bottom",
                 can_grow=True, anchor=True)]
    x = report("TFMSCardLog", W, "FMS_PDFReportService.Models.Cards.SoaCardLogEntry", (0.4, title), None,
               0.26, detail, footer(W), [column_group(hdr, 0.24)], ["FeederNames"])
    return x.replace('<PageHeaderSection PrintOnFirstPage="False" ', '<PageHeaderSection ')

os.makedirs(os.path.join(OUT, "TLS"), exist_ok=True)
os.makedirs(os.path.join(OUT, "TFMS"), exist_ok=True)
for rel, content in [("TLS/TLSCard.trdx", tls()), ("TFMS/TFMSCard.trdx", toms()),
                     ("TFMS/TOMSWorkPermit.trdx", permits()), ("TFMS/TFMSCardLog.trdx", cardlog())]:
    import xml.etree.ElementTree as ET
    ET.register_namespace("", NS)
    root_el = ET.fromstring(content.split("?>", 1)[1].strip())
    ET.indent(root_el, space="  ")
    content = '<?xml version="1.0" encoding="utf-8"?>\n' + ET.tostring(root_el, encoding="unicode") + "\n"
    with open(os.path.join(OUT, rel), "w", encoding="utf-8", newline="\r\n") as f:
        f.write(content)
    print("wrote", rel, len(content))
