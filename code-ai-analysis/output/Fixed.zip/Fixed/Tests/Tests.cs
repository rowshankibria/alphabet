using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Data.Repositories;
using FMS_PDFReportService.Engine.Groupers;
using FMS_PDFReportService.Engine.Rendering;
using FMS_PDFReportService.Models;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;
using FMS_PDFReportService.Models.Jobs.Colors;
using FMS_PDFReportService.Models.Reports;

static class T
{
    public static int Pass, Fail;
    public static List<string> Failures = new List<string>();
    public static void Eq<TV>(TV expected, TV actual, string what)
    {
        if (EqualityComparer<TV>.Default.Equals(expected, actual)) { Pass++; return; }
        Fail++; Failures.Add($"FAIL {what}: expected [{expected}] got [{actual}]");
    }
    public static void True(bool c, string what) { Eq(true, c, what); }
}

class FakeTls : ITLSCardRepository
{
    public TlsCardHeader Header; public List<TlsJob> Jobs = new List<TlsJob>(); public HashSet<int> Coop = new HashSet<int>();
    public int CoopCalls;
    public TlsCardHeader LoadCardHeader(int cardId, int archiveFlag) { return Header; }
    public IEnumerable<TlsJob> LoadJobs(int cardId, int archiveFlag) { return Jobs; }
    public HashSet<int> LoadCoopPendingJobs(IEnumerable<TlsJob> jobs) { CoopCalls++; return Coop; }
    public IEnumerable<TlsLineOOS> LoadLineOOS(string d, int s) { throw new NotSupportedException(); }
    public IEnumerable<TlsCircuitChange> LoadCircuitChanges(string d, string a, string b) { throw new NotSupportedException(); }
    public IEnumerable<TlsRevisionLogEntry> LoadRevisionLog(string d, string a, string b) { throw new NotSupportedException(); }
}

class FakeTfms : ITFMSCardRepository
{
    public TfmsCardHeader Header; public List<TfmsJob> Jobs = new List<TfmsJob>();
    public List<SoaCardLogEntry> Log = new List<SoaCardLogEntry>(); public List<WorkPermit> Permits = new List<WorkPermit>();
    public Dictionary<int, int?> Severity = new Dictionary<int, int?>(); public int SeverityCalls, OldPermitCalls;
    public TfmsCardHeader LoadCardHeader(int cardId, int archiveFlag) { return Header; }
    public IEnumerable<TfmsJob> LoadJobs(int cardId, int archiveFlag) { return Jobs; }
    public IEnumerable<SoaCardLogEntry> LoadCardLog(int cardId, int archiveFlag) { return Log; }
    public IEnumerable<WorkPermit> LoadWorkPermits(int cardId, int archiveFlag) { OldPermitCalls++; return new List<WorkPermit>(); }
    public List<WorkPermit> LoadPermitsWithProtections(int cardId, int archiveFlag) { return Permits; }
    public Dictionary<int, int?> LoadInfoItemEquipSeverity(int cardId) { SeverityCalls++; return Severity; }
}

static class Program
{
    static readonly DateTime EMPTY = new DateTime(9999, 12, 31, 23, 59, 59);   // how the provider surfaces Ingres ''
    static DateTime D(string mmddhhmm, int year = 2026) { return DateTime.ParseExact(year + "/" + mmddhhmm, "yyyy/MM/dd HH:mm", CultureInfo.InvariantCulture); }

    static int Main(string[] args)
    {
        string templates = args[0], jsonOut = args[1];
        TemplateDir = templates;
        TemplateTests(templates);
        TlsRuleTests();
        TfmsRuleTests();
        PermitTests();
        HeaderTests();
        GrouperTests();
        SqlTests();
        File.WriteAllText(jsonOut, BenchmarkJson(), Encoding.UTF8);
        foreach (var f in T.Failures) Console.WriteLine(f);
        Console.WriteLine($"PASSED {T.Pass}  FAILED {T.Fail}");
        return T.Fail == 0 ? 0 : 1;
    }

    // ------------------------------------------------------------------ Pass 1: template integrity
    static void TemplateTests(string dir)
    {
        var expectType = new Dictionary<string, Type>
        {
            { "TLS/TLSCard.trdx", typeof(TlsJob) }, { "TFMS/TFMSCard.trdx", typeof(TfmsJob) },
            { "TFMS/TOMSWorkPermit.trdx", typeof(TomsPermitRow) }, { "TFMS/TFMSCardLog.trdx", typeof(SoaCardLogEntry) },
        };
        foreach (var kv in expectType)
        {
            var path = Path.Combine(dir, kv.Key.Replace('/', Path.DirectorySeparatorChar));
            XDocument doc;
            try { doc = XDocument.Load(path); T.True(true, kv.Key + " well-formed"); }
            catch (Exception ex) { T.True(false, kv.Key + " well-formed: " + ex.Message); continue; }
            XNamespace ns = doc.Root.Name.Namespace;
            var text = File.ReadAllText(path);

            // ObjectDataSource type matches the list the grouper passes
            var ds = doc.Descendants(ns + "String").First().Value;
            T.True(ds.StartsWith(kv.Value.FullName + ","), kv.Key + " datasource type " + kv.Value.FullName);

            // Every Fields.X exists as a public readable property of that type
            var props = new HashSet<string>(kv.Value.GetProperties(BindingFlags.Public | BindingFlags.Instance).Select(p => p.Name));
            foreach (Match m in Regex.Matches(text, @"Fields\.([A-Za-z_][A-Za-z0-9_]*)"))
                T.True(props.Contains(m.Groups[1].Value), kv.Key + " field exists: " + m.Groups[1].Value);

            // Every Parameters.X is declared; every declared parameter is used
            var declared = new HashSet<string>(doc.Descendants(ns + "ReportParameter").Select(e => (string)e.Attribute("Name")));
            var used = new HashSet<string>(Regex.Matches(text, @"Parameters\.([A-Za-z_][A-Za-z0-9_]*)\.Value").Cast<Match>().Select(m => m.Groups[1].Value));
            foreach (var u in used) T.True(declared.Contains(u), kv.Key + " parameter declared: " + u);
            foreach (var d in declared) T.True(used.Contains(d), kv.Key + " parameter used: " + d);

            // Unique item names
            var names = doc.Descendants().Where(e => e.Attribute("Name") != null && e.Name.LocalName == "TextBox").Select(e => (string)e.Attribute("Name")).ToList();
            T.Eq(names.Count, names.Distinct().Count(), kv.Key + " unique TextBox names");

            // Page settings = FeederCard1 (landscape Letter, 0.15/0.15/0.5/0.5) + per-card numbering
            var ps = doc.Descendants(ns + "PageSettings").Single();
            T.Eq("Letter", (string)ps.Attribute("PaperKind"), kv.Key + " PaperKind");
            T.Eq("True", (string)ps.Attribute("Landscape"), kv.Key + " Landscape");
            var mu = doc.Descendants(ns + "MarginsU").Single();
            T.Eq("0.15in|0.15in|0.5in|0.5in", $"{mu.Attribute("Left").Value}|{mu.Attribute("Right").Value}|{mu.Attribute("Top").Value}|{mu.Attribute("Bottom").Value}", kv.Key + " margins");
            T.Eq("ResetNumberingAndCount", (string)doc.Root.Attribute("PageNumberingStyle"), kv.Key + " page numbering");
            var width = In((string)doc.Root.Attribute("Width"));
            T.True(width + 0.15 + 0.15 <= 11.0 + 1e-9, kv.Key + " fits landscape width");

            // No item extends past the report width
            foreach (var tb in doc.Descendants(ns + "TextBox"))
                T.True(In((string)tb.Attribute("Left")) + In((string)tb.Attribute("Width")) <= width + 1e-6, kv.Key + " inside width: " + (string)tb.Attribute("Name"));

            // Every cell can grow (a multi-line value must never be cut off)
            foreach (var tb in doc.Descendants(ns + "TextBox"))
                T.Eq("True", (string)tb.Attribute("CanGrow"), kv.Key + " CanGrow: " + (string)tb.Attribute("Name"));
            // Every row cell is anchored top+bottom, so when one cell wraps the whole row grows and bottom borders line up
            foreach (var tb in doc.Descendants(ns + "DetailSection").Descendants(ns + "TextBox"))
                T.Eq("Top, Bottom", (string)tb.Attribute("Anchoring"), kv.Key + " row cell anchored: " + (string)tb.Attribute("Name"));
            // Work permit fonts not too big: title <= 10pt, everything else <= 8pt
            if (kv.Key == "TFMS/TOMSWorkPermit.trdx")
                foreach (var tb in doc.Descendants(ns + "TextBox"))
                {
                    var size = double.Parse(((string)tb.Descendants(ns + "Font").First().Attribute("Size")).Replace("pt", ""), CultureInfo.InvariantCulture);
                    var max = (string)tb.Attribute("Name") == "txtTitle" ? 10.0 : 8.0;
                    T.True(size <= max, kv.Key + " font " + size + "pt <= " + max + "pt: " + (string)tb.Attribute("Name"));
                }

            // Footer: print time + Page X of Y (FeederCard1)
            T.True(text.Contains("='Page ' + PageNumber + ' of ' + PageCount"), kv.Key + " page x of y");
            T.True(text.Contains("{0:MM/dd/yyyy HH:mm}"), kv.Key + " print time");
        }

        // Grid geometry: detail cells tile the full width without gaps/overlaps; headers line up with cells
        GridCheck(Path.Combine(dir, "TLS", "TLSCard.trdx"), new[] { "txtTOOp", "txtTOIssued", "txtTOComplete", "txtStation", "txtCircuit", "txtMove", "txtResults", "txtStatus", "txtRSOp", "txtRSIssued", "txtRSComplete" });
        GridCheck(Path.Combine(dir, "TFMS", "TFMSCard.trdx"), new[] { "txtTOOp", "txtTOIssued", "txtTOComplete", "txtID", "txtType", "txtEquip", "txtG", "txtMove", "txtOrigin", "txtResponse", "txtRSOp", "txtRSIssued", "txtRSComplete" });

        // TFMS grid = FeederCard1 grid (same column edges as toms-dos.pdf)
        var fc = new[] { 0, 0.35, 1.1, 1.85, 2.2, 3.05, 3.85, 4.1, 7.55, 7.8, 8.9, 9.25, 9.97, 10.69 };
        var tf = Edges(Path.Combine(dir, "TFMS", "TFMSCard.trdx"), new[] { "txtTOOp", "txtTOIssued", "txtTOComplete", "txtID", "txtType", "txtEquip", "txtG", "txtMove", "txtOrigin", "txtResponse", "txtRSOp", "txtRSIssued", "txtRSComplete" });
        T.Eq(string.Join(",", fc), string.Join(",", tf), "TFMS grid edges == FeederCard1");

        // Op and ID cells are blank (benchmark)
        foreach (var f in new[] { "TLS/TLSCard.trdx", "TFMS/TFMSCard.trdx" })
        {
            var doc = XDocument.Load(Path.Combine(dir, f.Replace('/', Path.DirectorySeparatorChar)));
            foreach (var tb in doc.Descendants().Where(e => e.Name.LocalName == "TextBox" && new[] { "txtTOOp", "txtRSOp", "txtID" }.Contains((string)e.Attribute("Name"))))
                T.Eq("", (string)tb.Attribute("Value"), f + " blank cell " + (string)tb.Attribute("Name"));
        }
        // Continuation header only from page 2 (PrependHeader then adds the logo on every page)
        foreach (var f in new[] { "TLS/TLSCard.trdx", "TFMS/TFMSCard.trdx" })
        {
            var doc = XDocument.Load(Path.Combine(dir, f.Replace('/', Path.DirectorySeparatorChar)));
            T.Eq("False", (string)doc.Descendants().First(e => e.Name.LocalName == "PageHeaderSection").Attribute("PrintOnFirstPage"), f + " page header continuation-only");
            T.Eq("True", (string)doc.Descendants().First(e => e.Name.LocalName == "GroupHeaderSection").Attribute("PrintOnEveryPage"), f + " column header every page");
        }
    }

    static double In(string v) { return double.Parse(v.Replace("in", ""), CultureInfo.InvariantCulture); }
    static double[] Edges(string path, string[] order)
    {
        var doc = XDocument.Load(path);
        var det = doc.Descendants().First(e => e.Name.LocalName == "DetailSection");
        var boxes = det.Descendants().Where(e => e.Name.LocalName == "TextBox").ToDictionary(e => (string)e.Attribute("Name"));
        var edges = new List<double> { In((string)boxes[order[0]].Attribute("Left")) };
        foreach (var n in order) edges.Add(Math.Round(In((string)boxes[n].Attribute("Left")) + In((string)boxes[n].Attribute("Width")), 4));
        return edges.ToArray();
    }
    static void GridCheck(string path, string[] order)
    {
        var doc = XDocument.Load(path);
        var det = doc.Descendants().First(e => e.Name.LocalName == "DetailSection");
        var boxes = det.Descendants().Where(e => e.Name.LocalName == "TextBox").ToDictionary(e => (string)e.Attribute("Name"));
        double x = 0;
        foreach (var n in order)
        {
            T.True(boxes.ContainsKey(n), path + " has " + n);
            var l = In((string)boxes[n].Attribute("Left"));
            T.True(Math.Abs(l - x) < 1e-6, $"{Path.GetFileName(path)} {n} starts at {x} (is {l})");
            x = l + In((string)boxes[n].Attribute("Width"));
            T.Eq("Top, Bottom", (string)boxes[n].Attribute("Anchoring"), $"{Path.GetFileName(path)} {n} anchored (row borders stay aligned when a cell grows)");
        }
        T.True(Math.Abs(x - 10.69) < 1e-6, Path.GetFileName(path) + " grid ends at 10.69in (is " + x + ")");
        // headers: every header box left/right edge coincides with a detail edge
        var edges = new HashSet<double>(Edges(path, order).Select(e => Math.Round(e, 4)));
        var hdr = doc.Descendants().First(e => e.Name.LocalName == "GroupHeaderSection");
        foreach (var hb in hdr.Descendants().Where(e => e.Name.LocalName == "TextBox"))
        {
            var l = Math.Round(In((string)hb.Attribute("Left")), 4); var r = Math.Round(l + In((string)hb.Attribute("Width")), 4);
            T.True(edges.Contains(l) && edges.Contains(r), $"{Path.GetFileName(path)} header {(string)hb.Attribute("Name")} aligned with grid");
        }
    }

    // ------------------------------------------------------------------ Pass 2: TLS rules
    static TlsJob TJ(int job, int jobClass, string move, DateTime? toi = null, DateTime? toc = null, DateTime? rsi = null, DateTime? rsc = null,
                     string station = "", string circuit = "96DHZA425413", string results = "", string status = "", int circuitClass = 1, string moveType = "")
    {
        return new TlsJob { Job = job, JobClass = jobClass, TOMove = move, TOIssued = toi, TOComplete = toc, RSIssued = rsi, RSComplete = rsc,
            SubstationName = station, Linenumber = circuit, Results = results, Status = status, CircuitClass = circuitClass, MoveType = moveType };
    }

    // Rows of tls-dos.pdf page 1 (card 96DHZA425413). Gray cells in the benchmark = Ingres empty date.
    public static List<TlsJob> TlsBenchmark()
    {
        string H(string t, int sp) { return new string(' ', sp) + t; }
        return new List<TlsJob>
        {
            TJ(1, 0, H("Alarms", 45), circuit: "", circuitClass: -99),
            TJ(2, 10, "Transmission Operator Notified", rsi: EMPTY, rsc: EMPTY),
            TJ(3, 10, "Check Alarm Status", D("01/05 10:13"), D("01/05 10:32"), D("01/16 08:23"), D("01/16 10:15"), "E29ST", results: "ALERT"),
            TJ(4, 10, "Check Alarm Status", D("01/05 10:13"), D("01/05 13:10"), D("01/16 08:24"), D("01/16 13:01"), "E36ST", results: "ALM CLR"),
            TJ(5, 10, "Check Alarm Status", D("03/25 08:43"), D("03/25 14:43"), D("06/23 14:00"), D("06/23 15:51"), "E29ST", results: "ALERT"),
            TJ(6, 10, "Check Alarm Status", station: "E29ST"),
            TJ(7, 0, H("Switching Operations", 36), circuit: "", circuitClass: -99),
            TJ(8, 0, H("In-Service Work Permits", 30), circuit: "", circuitClass: -99),
            TJ(9, 0, H("Work Permits", 40), circuit: "", circuitClass: -99),
            TJ(10, 10, "To Verizon: NYNY250199", null, EMPTY, EMPTY, null, results: "NTF"),
            TJ(11, 10, "To Verizon: NYNY250217", null, EMPTY, EMPTY, null, results: "NTF"),
            TJ(12, 10, "To PST: Check & Repair", null, EMPTY, EMPTY, null, "E29ST"),
            TJ(13, 10, "To PST: Check & Repair", null, EMPTY, EMPTY, null, "E36ST"),
            TJ(14, 0, H("Notifications/Access", 33), circuit: "", circuitClass: -99),
            TJ(15, 10, "Give To PST:", rsi: EMPTY, rsc: EMPTY),
            TJ(16, 10, "PST Support Request", D("01/05 11:25"), null, EMPTY, EMPTY),
            TJ(17, 10, "Arrangement for Access", rsi: EMPTY, rsc: EMPTY, station: "E29ST"),
            TJ(18, 10, "Arrangement for Access", rsi: EMPTY, rsc: EMPTY, station: "E36ST"),
        };
    }

    static void TlsRuleTests()
    {
        var jobs = TlsBenchmark();
        TlsRowRules.Apply(jobs, 1, new HashSet<int>());
        string G = DosColors.TlsGrayOut, W = DosColors.White;
        // [job] -> TOIssBg TOCmpBg RSIssBg RSCmpBg   (read off tls-dos.pdf page 1)
        var expect = new Dictionary<int, string[]>
        {
            {2,  new[]{W,W,G,G}}, {3,new[]{W,W,W,W}}, {4,new[]{W,W,W,W}}, {5,new[]{W,W,W,W}}, {6,new[]{W,W,W,W}},
            {10, new[]{W,G,G,W}}, {11,new[]{W,G,G,W}}, {12,new[]{W,G,G,W}}, {13,new[]{W,G,G,W}},
            {15, new[]{W,W,G,G}}, {16,new[]{W,W,G,G}}, {17,new[]{W,W,G,G}}, {18,new[]{W,W,G,G}},
        };
        foreach (var j in jobs)
        {
            if (j.JobClass == 0)
            {
                T.Eq(DosColors.Navy, j.MoveFg, $"TLS heading {j.Job} navy");
                T.True(j.IsHeading, $"TLS heading {j.Job} flagged");
                T.Eq(W + W + W + W, j.TOIssuedBg + j.TOCompleteBg + j.RSIssuedBg + j.RSCompleteBg, $"TLS heading {j.Job} white cells");
                T.Eq("", j.StationText + j.CircuitText + j.ResultsText + j.StatusText + j.TOIssuedText + j.RSCompleteText, $"TLS heading {j.Job} empty cells");
                T.True(j.MoveText.StartsWith("   "), $"TLS heading {j.Job} keeps leading spaces");
                continue;
            }
            var e = expect[j.Job];
            T.Eq(string.Join("|", e), string.Join("|", new[] { j.TOIssuedBg, j.TOCompleteBg, j.RSIssuedBg, j.RSCompleteBg }), $"TLS job {j.Job} date backgrounds");
            T.Eq(DosColors.Black, j.MoveFg, $"TLS job {j.Job} black move (no dimming in DOS)");
            T.Eq(W, j.MoveBg, $"TLS job {j.Job} white move bg");
            foreach (var t in new[] { j.TOIssuedText, j.TOCompleteText, j.RSIssuedText, j.RSCompleteText })
                T.True(t != "12/31 23:59", $"TLS job {j.Job} never prints the empty-date value");
        }
        var r3 = jobs.First(x => x.Job == 3);
        T.Eq("01/05 10:13|01/05 10:32|01/16 08:23|01/16 10:15", $"{r3.TOIssuedText}|{r3.TOCompleteText}|{r3.RSIssuedText}|{r3.RSCompleteText}", "TLS date text");
        T.Eq("E29ST|96DHZA425413|ALERT", $"{r3.StationText}|{r3.CircuitText}|{r3.ResultsText}", "TLS station/circuit/results");
        T.Eq("01/05 11:25", jobs.First(x => x.Job == 16).TOIssuedText, "TLS PST support request issued");

        // Status: Xfr -> T, anything else blank
        var s = new[] { TJ(1, 10, "a", status: "Xfr"), TJ(2, 10, "b", status: "Act"), TJ(3, 10, "c", status: null) };
        TlsRowRules.Apply(s, 1, null);
        T.Eq("T||", string.Join("|", s.Select(x => x.StatusText)), "TLS status column");
        // JobClass 0 without -99 is black
        var n = TJ(1, 0, "note", circuitClass: 5); TlsRowRules.ApplyRow(n, 1, null);
        T.Eq(DosColors.Black, n.MoveFg, "TLS JobClass 0 not -99 is black");
        // Co-Op pending
        var c1 = TJ(1, 10, "coop", moveType: "COOP"); var c2 = TJ(2, 10, "coop", moveType: "COOP "); var c3 = TJ(3, 10, "x", moveType: "OTHER");
        TlsRowRules.Apply(new[] { c1, c2, c3 }, 1, new HashSet<int> { 1, 3 });
        T.Eq("#FFB6C1", c1.MoveBg, "TLS coop pending pale red");
        T.Eq(W, c2.MoveBg, "TLS coop not pending stays white");
        T.Eq(W, c3.MoveBg, "TLS non-coop job never pale red");
        // Transferred-on-closed-card branch: only with Card_Closed (50), never with TC status 4
        var x1 = TJ(1, 10, "t", status: "Xfr"); TlsRowRules.ApplyRow(x1, Constants.Card_Closed, null);
        T.Eq(G + G + G + G, x1.TOIssuedBg + x1.TOCompleteBg + x1.RSIssuedBg + x1.RSCompleteBg, "TLS Xfr on Card_Closed grays NULLs (faithful port)");
        var x2 = TJ(1, 10, "t", status: "Xfr"); TlsRowRules.ApplyRow(x2, Constants.TC_Card_Closed, null);
        T.Eq(W + W + W + W, x2.TOIssuedBg + x2.TOCompleteBg + x2.RSIssuedBg + x2.RSCompleteBg, "TLS Xfr with TC status 4 unchanged (OpenROAD dead branch)");
        // null safety
        var z = new TlsJob(); TlsRowRules.ApplyRow(z, 0, null);
        T.Eq("", z.MoveText + z.StationText + z.CircuitText + z.ResultsText, "TLS nulls become empty");
        TlsRowRules.Apply(null, 0, null); T.True(true, "TLS Apply(null) safe");
    }

    // ------------------------------------------------------------------ Pass 2: TOMS rules
    const int CARD = 372937, OTHER = 370001;
    static TfmsJob MJ(int job, int jobClass, string move, string type = "", string equip = "", int eq = 0, int control = CARD,
                      DateTime? toi = null, DateTime? toc = null, DateTime? rsi = null, DateTime? rsc = null, string act = "",
                      int fg = 0, int bg = 0, int? grounds = null, DateTime? groundOn = null, string status = "", int cat = 0, int shadow = 0, string resp = "")
    {
        return new TfmsJob { Job = job, JobClass = jobClass, TOMove = move, EquipClassName = type, EquipName = equip, Equip = eq, ControlCard = control,
            TOIssued = toi, TOComplete = toc, RSIssued = rsi, RSComplete = rsc, ActivityIdentifier = act, MoveFGColor = fg, MoveBGColor = bg,
            Grounds = grounds, GroundOn = groundOn, Status = status, MoveCategory = cat, ShadowLink = shadow, Response = resp };
    }

    // Rows of toms-dos.pdf pages 172-176 (card 372937), reconstructed. Equip ids are illustrative.
    public static List<TfmsJob> TomsBenchmark()
    {
        string H(string t, int sp) { return new string(' ', sp) + t; }
        return new List<TfmsJob>
        {
            MJ(1, 0, H("De - Energize", 30), fg: Constants.CC_BLUE),
            MJ(2, 0, H("Dunwoodie South 138kV Substation", 6), bg: Constants.CC_PALE_BROWN),
            MJ(3, 10, "Open Auto - 2S", "Bkr", "2S", 102, OTHER, D("06/27 20:59"), D("06/27 20:59"), D("06/29 19:01"), D("06/29 19:02")),
            MJ(4, 10, "Open Auto - 3S", "Bkr", "3S", 103, CARD, D("06/27 20:59"), D("06/27 20:59"), D("06/28 14:50"), D("06/28 14:50"), "S"),
            MJ(5, 0, H("Disconnects", 30), fg: Constants.CC_BLUE),
            MJ(6, 10, "(Fdr 99153) - Open, Verify Open & Block Open Transf Disc Sw All Phases - F3S", "ManDiscTrf", "F3S", 201, CARD, D("06/27 22:51"), D("06/27 23:21"), act: "S"),
            MJ(7, 10, "(Bkr 6W) - Block Closed Bkr Disc Sw Al Phases - 6W6", "MOD-Bkr", "6W6", 206, OTHER, D("01/10 19:11"), D("01/10 19:22"), act: "S"),
            MJ(8, 0, H("Relay Protection", 30), fg: Constants.CC_BLUE),
            MJ(9, 10, "Record/Reset", "None", "", 0, CARD, D("06/27 21:03"), D("06/27 22:00"), EMPTY, EMPTY, "S"),
            MJ(10, 10, "(E179ST38 - DUN-S38) - Feeder ISP's isolated - 99153", "ACLineSegment", "99153", 99153, CARD, D("06/28 17:04"), D("06/28 19:51"), act: "S"),
            MJ(11, 0, H("FIELD WORK", 6), bg: Constants.CC_PALE_PINK),
            MJ(12, 10, "(E179ST38 - DUN-S38) - Place Feeder on Reduced Pressure - 99153", "ACLineSegment", "99153", 99153, CARD, fg: Constants.CC_GREEN),
            MJ(13, 0, H("Work Permits", 30), fg: Constants.CC_BLUE),
            MJ(14, 10, "21879516-To PST: Check and repair breaker not closing via supervisory - 2S", "Bkr", "2S", 102, OTHER, D("06/28 16:28"), EMPTY, EMPTY, D("06/28 20:02"), "S", resp: "Incomplete"),
            MJ(15, 0, H("EN - DE - EN", 31), fg: Constants.CC_RED, bg: Constants.CC_PALE_BLUE),
            MJ(16, 10, "(Fdr 42G13T) - Check Dead & Apply portable ground A Phase - 42G13T", "STA-PH", "42G13T", 500, CARD, D("04/26 14:54"), D("04/26 15:29"), act: "S", grounds: 3, groundOn: D("04/26 15:29")),
            MJ(17, 10, "(Fdr 99153) - Hi-Pot B-Ph at 230kV DC for 5 min, as per test letter - 99153: B Phase Only", "Grd-SwFdr", "58", 58, CARD, EMPTY, EMPTY, D("07/05 08:38"), null, "S", grounds: 3, groundOn: null),
            MJ(18, 0, H("Gownus Gas Turbine 1&3 Substation", 6), bg: Constants.CC_PALE_ORANGE),
            MJ(19, 0, H("East River 69 Substation", 6), bg: Constants.CC_PALE_RED),
            MJ(20, 10, "(RS1-RS2) Cut in Spare Bank Bkr - 51", "Bkr-Spare", "51", 51, CARD, D("04/20 02:58"), D("04/20 03:18"), act: "S"),
        };
    }
    public static Dictionary<int, int?> TomsSeverity() { return new Dictionary<int, int?> { { 201, 2 }, { 206, 1 }, { 99153, 2 }, { 51, 3 } }; }

    static void TfmsRuleTests()
    {
        var jobs = TomsBenchmark();
        TfmsRowRules.Apply(jobs, CARD, false, TomsSeverity());
        var J = jobs.ToDictionary(j => j.Job);
        string W = DosColors.White, G = DosColors.TomsGrayOut;
        // headings
        T.Eq(DosColors.Navy + "|" + W + "|True", $"{J[1].MoveFg}|{J[1].MoveBg}|{J[1].MoveBold}", "TOMS De-Energize heading navy bold");
        T.Eq(DosColors.Black + "|#DEB887|True", $"{J[2].MoveFg}|{J[2].MoveBg}|{J[2].MoveBold}", "TOMS substation band BurlyWood");
        T.Eq("#D8BFD8", J[11].MoveBg, "TOMS FIELD WORK Thistle");
        T.Eq(DosColors.Red + "|#87CEFA", $"{J[15].MoveFg}|{J[15].MoveBg}", "TOMS EN-DE-EN red on LightSkyBlue");
        T.Eq("#FFD700", J[18].MoveBg, "TOMS Gownus band Gold");
        T.Eq("#FFB6C1", J[19].MoveBg, "TOMS East River band LightPink");
        foreach (var h in jobs.Where(j => j.JobClass == 0))
        {
            T.Eq("", h.TypeText + h.EquipText + h.GText + h.OriginText + h.ResponseText + h.TOIssuedText + h.RSCompleteText, $"TOMS heading {h.Job} other cells empty");
            T.Eq(W + W + W + W + W, h.TOIssuedBg + h.TOCompleteBg + h.RSIssuedBg + h.RSCompleteBg + h.OriginBg, $"TOMS heading {h.Job} other cells white");
            T.True(h.MoveText.StartsWith(" "), $"TOMS heading {h.Job} keeps leading spaces");
        }
        // gray equipment when the card does not control the move
        T.Eq(DosColors.Gray, J[3].EquipFg, "TOMS 2S not controlled -> gray type/equip");
        T.Eq(DosColors.Black, J[4].EquipFg, "TOMS 3S controlled -> black");
        T.Eq(DosColors.Gray, J[7].EquipFg, "TOMS MOD-Bkr 6W6 not controlled -> gray");
        // S cell severity
        T.Eq("|" + W, $"{J[3].OriginText}|{J[3].OriginBg}", "TOMS no S, white");
        T.Eq("S|" + W, $"{J[4].OriginText}|{J[4].OriginBg}", "TOMS S white (no info item)");
        T.Eq("S|" + DosColors.InfoSeverity2, $"{J[6].OriginText}|{J[6].OriginBg}", "TOMS F3S severity 2 turquoise");
        T.Eq("S|" + DosColors.InfoSeverity1, $"{J[7].OriginText}|{J[7].OriginBg}", "TOMS 6W6 severity 1 yellow");
        T.Eq("|" + DosColors.InfoSeverity2, $"{J[12].OriginText}|{J[12].OriginBg}", "TOMS reduced pressure turquoise without S");
        T.Eq("S|" + DosColors.InfoSeverity3, $"{J[20].OriginText}|{J[20].OriginBg}", "TOMS spare bank severity 3 green");
        // dates
        T.Eq(W + W + G + G, J[9].TOIssuedBg + J[9].TOCompleteBg + J[9].RSIssuedBg + J[9].RSCompleteBg, "TOMS Record/Reset RS gray");
        T.Eq(W + G + G + W, J[14].TOIssuedBg + J[14].TOCompleteBg + J[14].RSIssuedBg + J[14].RSCompleteBg, "TOMS work permit TOComplete+RSIssued gray");
        T.Eq("06/28 16:28||" + "|06/28 20:02", $"{J[14].TOIssuedText}|{J[14].TOCompleteText}|{J[14].RSIssuedText}|{J[14].RSCompleteText}", "TOMS work permit date text");
        T.Eq(G + G, J[17].TOIssuedBg + J[17].TOCompleteBg, "TOMS hi-pot TO gray");
        // ground rule
        T.Eq(DosColors.Red + "|" + DosColors.Red + "|3", $"{J[16].MoveFg}|{J[16].GFg}|{J[16].GText}", "TOMS ground applied -> red move + red G");
        T.Eq(DosColors.Black + "|" + DosColors.Black + "|3", $"{J[17].MoveFg}|{J[17].GFg}|{J[17].GText}", "TOMS grounds but GroundOn NULL -> black (benchmark p176)");
        T.Eq(DosColors.Green, J[12].MoveFg, "TOMS MoveFGColor green");
        T.Eq(DosColors.Black, J[3].MoveFg, "TOMS normal move black");

        // ground rule needs outstanding status
        var g1 = MJ(1, 10, "g", grounds: 1, groundOn: D("01/01 00:00"), status: "NIS"); var g2 = MJ(2, 10, "g", grounds: 1, groundOn: D("01/01 00:00"), status: "Cmp");
        var g3 = MJ(3, 10, "g", grounds: 1, groundOn: D("01/01 00:00"), status: null, fg: Constants.CC_GREEN);
        TfmsRowRules.Apply(new[] { g1, g2, g3 }, CARD, false, null);
        T.Eq(DosColors.Red, g1.MoveFg, "TOMS ground NIS red"); T.Eq(DosColors.Black, g2.MoveFg, "TOMS ground other status black");
        T.Eq(DosColors.Red, g3.MoveFg, "TOMS ground wins over MoveFGColor (applied after, as SOA_Main)");
        // shadow-link switching green; MoveFGColor overrides it
        var s1 = MJ(1, 10, "s", cat: Constants.MoveCategory_SwitchingItem, shadow: 5); var s2 = MJ(2, 10, "s", cat: Constants.MoveCategory_SwitchingItem, shadow: 5, fg: Constants.CC_RED);
        TfmsRowRules.Apply(new[] { s1, s2 }, CARD, false, null);
        T.Eq(DosColors.Green, s1.MoveFg, "TOMS switching+shadow green"); T.Eq(DosColors.Red, s2.MoveFg, "TOMS MoveFGColor overrides shadow green");
        // severity only for Normal + outstanding
        var v1 = MJ(1, 10, "v", eq: 201, act: "S", status: "Cmp"); var v2 = MJ(2, 10, "v", eq: 201, act: "S", cat: Constants.MoveCategory_SwitchingItem);
        TfmsRowRules.Apply(new[] { v1, v2 }, CARD, false, TomsSeverity());
        T.Eq(W, v1.OriginBg, "TOMS severity ignored when status not outstanding"); T.Eq(W, v2.OriginBg, "TOMS severity ignored for non-Normal category");
        // null severity / unknown severity
        var u1 = MJ(1, 10, "u", eq: 7, act: "S"); var u2 = MJ(2, 10, "u", eq: 8, act: "S");
        TfmsRowRules.Apply(new[] { u1, u2 }, CARD, false, new Dictionary<int, int?> { { 7, null }, { 8, 9 } });
        T.Eq(W + W, u1.OriginBg + u2.OriginBg, "TOMS null/unknown severity -> white");
        // archived: S hidden, no severity, no gray equipment (ControlCard = Card on archive query)
        var a1 = MJ(1, 10, "a", eq: 201, act: "S", control: CARD); var a2 = MJ(2, 10, "a", act: "X");
        TfmsRowRules.Apply(new[] { a1, a2 }, CARD, true, TomsSeverity());
        T.Eq("|" + W + "|" + DosColors.Black, $"{a1.OriginText}|{a1.OriginBg}|{a1.EquipFg}", "TOMS archived S hidden, white");
        T.Eq("X", a2.OriginText, "TOMS archived keeps X");
        // test letter
        var t1 = MJ(1, Constants.JobClass_TestLetter, "tl", toi: D("01/01 01:00"), bg: Constants.CC_PALE_BLUE);
        var t2 = MJ(2, Constants.JobClass_TestLetter, "tl", toi: D("01/01 01:00"), toc: D("01/01 02:00"), bg: Constants.CC_PALE_BLUE);
        TfmsRowRules.Apply(new[] { t1, t2 }, CARD, false, null);
        T.Eq("#FFD700|" + W, $"{t1.MoveBg}|{t2.MoveBg}", "TOMS test letter outstanding gold, done white");
        // category gray only for Normal
        var k1 = MJ(1, 10, "k", control: OTHER, cat: Constants.MoveCategory_InformationItem);
        TfmsRowRules.ApplyRow(k1, CARD, false, null); T.Eq(DosColors.Black, k1.EquipFg, "TOMS info item not grayed");
        // unknown colour codes keep defaults
        var q1 = MJ(1, 10, "q", fg: 99, bg: 98); TfmsRowRules.ApplyRow(q1, CARD, false, null);
        T.Eq(DosColors.Black + "|" + W, $"{q1.MoveFg}|{q1.MoveBg}", "TOMS unknown colour codes ignored");
        // null safety
        var z = new TfmsJob(); TfmsRowRules.ApplyRow(z, CARD, false, null);
        T.Eq("", z.MoveText + z.TypeText + z.EquipText + z.GText + z.OriginText + z.ResponseText, "TOMS nulls become empty");
        // G zero prints blank
        var g0 = MJ(1, 10, "g", grounds: 0); TfmsRowRules.ApplyRow(g0, CARD, false, null); T.Eq("", g0.GText, "TOMS G=0 blank");

        // FirstSeverityPerEquip = ItemCategory_ASE.LoadEquip first row per equip (rows ordered by Equip, Severity)
        var map = TfmsRowRules.FirstSeverityPerEquip(new[] {
            new InfoItemEquipSeverity { Equip = 1, Severity = 1 }, new InfoItemEquipSeverity { Equip = 1, Severity = 3 },
            new InfoItemEquipSeverity { Equip = 2, Severity = 2 }, new InfoItemEquipSeverity { Equip = 3, Severity = null } });
        T.Eq("1|2|", $"{map[1]}|{map[2]}|{map[3]}", "TOMS first severity per equip");

        // DOS palette: every benchmark-measured colour
        T.Eq("#000080|#FF0000|#008000|#808080|#FFB6C1|#87CEFA|#D8BFD8|#DEB887|#FFD700|#FFFF00", string.Join("|", new[] {
            Constants.CC_BLUE, Constants.CC_RED, Constants.CC_GREEN, Constants.CC_LIGHT_GRAY, Constants.CC_PALE_RED, Constants.CC_PALE_BLUE,
            Constants.CC_PALE_PINK, Constants.CC_PALE_BROWN, Constants.CC_PALE_ORANGE, Constants.CC_YELLOW }.Select(DosColors.FromCode)), "DOS palette (measured colours)");
        T.Eq(null, DosColors.FromCode(0), "palette 0 = not set");
    }

    // ------------------------------------------------------------------ permits flattening
    static void PermitTests()
    {
        var p1 = new WorkPermit { Job = 11, StepPair = Constants.StepHeading_WorkPermit, TOIssued = D("06/28 16:28"), RSComplete = D("06/28 20:02"), EquipClassName = "Bkr", EquipName = "2S", TOMove = "21879516-To PST" };
        var p2 = new WorkPermit { Job = 12, StepPair = Constants.StepHeading_WorkPermit, TOIssued = null, RSComplete = EMPTY, EquipClassName = "ACLineSegment", EquipName = "99153", TOMove = "Make the ISP Normal",
            Protections = new List<PermitProtection> { new PermitProtection { CardTypeName = "TFMS", Card = "99153", TOIssued = "06/28 05:44", EquipName = "F7W" }, new PermitProtection { CardTypeName = "TFMS", Card = "99153", EquipName = "F3S" } } };
        var p3 = new WorkPermit { Job = 13, StepPair = Constants.StepHeading_TestPermit, TOIssued = D("06/29 23:23"), RSComplete = D("06/30 21:14"), EquipClassName = "STA-PH", EquipName = "99153", Protections = null };
        var rows = TomsPermitRow.Build(new[] { p1, p2, p3 });
        T.Eq(4, rows.Count, "permit rows: 1 empty + 2 protections + 1 empty");
        T.Eq("1|2|2|3", string.Join("|", rows.Select(r => r.PermitKey)), "permit keys in print order");
        T.Eq("True|False|False|True", string.Join("|", rows.Select(r => r.IsEmpty)), "empty flags");
        T.Eq("Work Permit|Work Permit|Work Permit|Test Permit", string.Join("|", rows.Select(r => r.PermitLabel)), "permit labels");
        T.Eq("06/28 16:28|06/28 20:02", rows[0].PermitIssued + "|" + rows[0].PermitComplete, "permit dates");
        T.Eq("|", rows[1].PermitIssued + "|" + rows[1].PermitComplete, "permit NULL / empty date blank");
        T.Eq("F7W|F3S", rows[1].EquipName + "|" + rows[2].EquipName, "protection order kept");
        T.Eq("", rows[0].EquipName + rows[0].CardTypeName + rows[0].TOMove, "empty row has no protection values");
        T.Eq(0, TomsPermitRow.Build(null).Count, "no permits -> no rows");
    }

    // ------------------------------------------------------------------ headers
    static void HeaderTests()
    {
        var h = new TlsCardHeader { CardType = 0, Feeders = new List<TlsFeeder> { new TlsFeeder { Name = "38M22" }, new TlsFeeder { Name = " 38M23 " }, new TlsFeeder { Name = null } },
            Stations = new List<TlsStation> { new TlsStation { Name = "E29ST" }, new TlsStation { Name = "E36ST" } } };
        T.Eq("TROUBLE", h.CardTypeName, "TLS card type 0"); h.CardType = 1; T.Eq("SCHEDULED", h.CardTypeName, "TLS card type 1");
        T.Eq("38M22, 38M23", h.FeedersText, "TLS feeders text"); T.Eq("E29ST, E36ST", h.StationsText, "TLS stations text");
        T.Eq("3X76|3X79", string.Join("|", TlsCardHeader.SplitNames(" 3X76 ,  3X79,")), "TLS archive split");
        T.Eq("MONTEFIORE HOSP", TlsCardHeader.Squeeze("  MONTEFIORE    HOSP "), "TLS squeeze");
        T.Eq(0, TlsCardHeader.SplitNames(null).Count, "TLS split null");
        T.Eq("", new TlsCardHeader { Feeders = null, Stations = null }.FeedersText, "TLS null feeders");
    }

    // ------------------------------------------------------------------ groupers (real code, stub renderer)
    static Dictionary<string, object> P(int i) { return TelerikReportRenderer.Calls[i].Params; }
    static void GrouperTests()
    {
        // TLS
        var tls = new FakeTls { Header = new TlsCardHeader { Linenumber = "96DHZA425413", LineTypeName = "85 DTT T1 V", RouteName = "# 1", CarrierName = "Verizon", CardType = 0,
            Notes = "T1 CIRCUIT", CardNote = "note", ReasonForFailure = "", Status = 1,
            Feeders = new List<TlsFeeder> { new TlsFeeder { Name = "38M22" } }, Stations = new List<TlsStation> { new TlsStation { Name = "E29ST" }, new TlsStation { Name = "E36ST" } } },
            Jobs = TlsBenchmark() };
        TelerikReportRenderer.Calls.Clear();
        var src = new TLSGrouper(tls, new TelerikReportRenderer(), new TemplatePathResolver()).ComposeCard(1, new ReportRequest { ArchiveFlag = 0, ReportType = 1 });
        T.Eq(1, src.Count, "TLS one source (card only, even ReportType 1)");
        T.Eq("TLS/TLSCard.trdx", TelerikReportRenderer.Calls[0].Template, "TLS template");
        T.True(((List<TlsJob>)TelerikReportRenderer.Calls[0].Data).All(j => j.MoveFg != null && j.TOIssuedBg != null), "TLS rows coloured before rendering");
        T.Eq("96DHZA425413|85 DTT T1 V|# 1|Verizon|TROUBLE|38M22|E29ST, E36ST||" + "|note|T1 CIRCUIT|", string.Join("|", new[] { "Linenumber", "LineTypeName", "RouteName", "CarrierName", "CardTypeName", "FeedersText", "StationsText", "ClosedLabel", "ClosedText", "CardNote", "CircuitNote", "ReasonForFailure" }.Select(k => (string)P(0)[k])), "TLS header parameters");
        T.Eq(1, tls.CoopCalls, "TLS coop lookup once");
        TemplateParamsMatch("TLS/TLSCard.trdx", P(0));
        // TLS closed card label
        tls.Header.Closed = D("02/01 10:00"); TelerikReportRenderer.Calls.Clear();
        new TLSGrouper(tls, new TelerikReportRenderer(), new TemplatePathResolver()).ComposeCard(1, new ReportRequest());
        T.Eq("Card Closed:|02/01/26 10:00", (string)P(0)["ClosedLabel"] + "|" + (string)P(0)["ClosedText"], "TLS closed label/date");
        // TLS missing header
        tls.Header = null; TelerikReportRenderer.Calls.Clear();
        new TLSGrouper(tls, new TelerikReportRenderer(), new TemplatePathResolver()).ComposeCard(1, new ReportRequest());
        T.Eq(0, P(0).Count, "TLS null header -> no parameters, no crash");

        // TOMS active, ReportType 1
        var toms = new FakeTfms { Header = new TfmsCardHeader { Card = CARD, CardClassName = "Auto", FeederNames = "99153", Description = "DUN-S38:(2S,3S)   E179ST38:(7W,6W)",
            CutOut = D("06/27 20:59"), CutIn = null, Note = "", Status = Constants.Card_Active }, Jobs = TomsBenchmark(), Severity = TomsSeverity(),
            Permits = new List<WorkPermit> { new WorkPermit { Job = 1, StepPair = Constants.StepHeading_WorkPermit } },
            Log = new List<SoaCardLogEntry> { new SoaCardLogEntry { Log = "x" } } };
        TelerikReportRenderer.Calls.Clear();
        src = new TFMSGrouper(toms, new TelerikReportRenderer(), new TemplatePathResolver()).ComposeCard(CARD, new ReportRequest { ArchiveFlag = 0, ReportType = 1 });
        T.Eq("TFMS/TFMSCard.trdx|TFMS/TFMSCardLog.trdx|TFMS/TOMSWorkPermit.trdx", string.Join("|", TelerikReportRenderer.Calls.Select(c => c.Template)), "TOMS sources in order");
        T.Eq(3, src.Count, "TOMS three sources");
        T.Eq("372937|Auto|99153|06/27/26 20:59||", (string)P(0)["CardText"] + "|" + (string)P(0)["CardClassName"] + "|" + (string)P(0)["FeederNames"] + "|" + (string)P(0)["CutOutText"] + "|" + (string)P(0)["CutInText"] + "|" + (string)P(0)["ClosedLabel"], "TOMS header parameters");
        T.Eq(1, toms.SeverityCalls, "TOMS severity loaded for active card");
        T.Eq(0, toms.OldPermitCalls, "TOMS no longer calls the StepPair=3 permit query");
        T.True(TelerikReportRenderer.Calls[2].Data is List<TomsPermitRow>, "TOMS permit rows flattened");
        T.Eq("99153", (string)P(1)["FeederNames"], "TOMS log title parameter");
        T.Eq(DosColors.InfoSeverity1, ((List<TfmsJob>)TelerikReportRenderer.Calls[0].Data).First(j => j.Job == 7).OriginBg, "TOMS grouper applied severity");
        TemplateParamsMatch("TFMS/TFMSCard.trdx", P(0)); TemplateParamsMatch("TFMS/TFMSCardLog.trdx", P(1)); TemplateParamsMatch("TFMS/TOMSWorkPermit.trdx", P(2));
        // ReportType 0 -> card only
        TelerikReportRenderer.Calls.Clear();
        new TFMSGrouper(toms, new TelerikReportRenderer(), new TemplatePathResolver()).ComposeCard(CARD, new ReportRequest { ArchiveFlag = 0, ReportType = 0 });
        T.Eq(1, TelerikReportRenderer.Calls.Count, "TOMS ReportType 0 card only");
        // not active -> no severity lookup, no colours
        toms.Header.Status = 0; toms.SeverityCalls = 0; toms.Jobs = TomsBenchmark(); TelerikReportRenderer.Calls.Clear();
        new TFMSGrouper(toms, new TelerikReportRenderer(), new TemplatePathResolver()).ComposeCard(CARD, new ReportRequest { ArchiveFlag = 0, ReportType = 0 });
        T.Eq(0, toms.SeverityCalls, "TOMS severity not loaded for inactive card");
        T.True(((List<TfmsJob>)TelerikReportRenderer.Calls[0].Data).All(j => j.OriginBg == DosColors.White), "TOMS inactive card: no severity colours");
        // archived -> no severity lookup
        toms.Header.Status = Constants.Card_Active; toms.SeverityCalls = 0; TelerikReportRenderer.Calls.Clear();
        new TFMSGrouper(toms, new TelerikReportRenderer(), new TemplatePathResolver()).ComposeCard(CARD, new ReportRequest { ArchiveFlag = 1, ReportType = 0 });
        T.Eq(0, toms.SeverityCalls, "TOMS severity not loaded for archived card");
        // null header
        toms.Header = null; TelerikReportRenderer.Calls.Clear();
        new TFMSGrouper(toms, new TelerikReportRenderer(), new TemplatePathResolver()).ComposeCard(CARD, new ReportRequest { ArchiveFlag = 0, ReportType = 1 });
        T.Eq(0, P(0).Count, "TOMS null header -> no parameters, no crash");
        T.Eq("", (string)P(1)["FeederNames"], "TOMS null header log title empty");
    }

    static string TemplateDir;
    static void TemplateParamsMatch(string rel, Dictionary<string, object> sent)
    {
        var path = Path.Combine(TemplateDir, rel.Replace('/', Path.DirectorySeparatorChar));
        var declared = new HashSet<string>(XDocument.Load(path).Descendants().Where(e => e.Name.LocalName == "ReportParameter").Select(e => (string)e.Attribute("Name")));
        foreach (var k in sent.Keys) T.True(declared.Contains(k), rel + " declares sent parameter " + k + " (renderer silently drops undeclared ones)");
        foreach (var d in declared) T.True(sent.ContainsKey(d), rel + " parameter " + d + " is sent by the grouper");
    }

    // ------------------------------------------------------------------ SQL static checks
    static void SqlTests()
    {
        int Q(string s) { return s.Count(c => c == '?'); }
        T.Eq(1, Q(TLSQueries.LoadFeeders), "SQL LoadFeeders 1 param"); T.Eq(1, Q(TLSQueries.LoadStations), "SQL LoadStations 1 param");
        T.Eq(1, Q(TLSQueries.LoadFeederStationNamesArchive), "SQL archive names 1 param"); T.Eq(1, Q(TLSQueries.FindCoopPending), "SQL coop 1 param");
        T.Eq(1, Q(TFMSQueries.LoadSoaCard), "SQL SOA card 1 param"); T.Eq(1, Q(TFMSQueries.LoadSoaCardArchive), "SQL SOA card archive 1 param");
        T.Eq(1, Q(TFMSQueries.LoadInfoItemEquipSeverity), "SQL severity 1 param"); T.Eq(2, Q(TFMSQueries.LoadPermits), "SQL permits 2 params");
        T.Eq(2, Q(TFMSQueries.LoadPermitsArchive), "SQL permits archive 2 params");
        T.True(TLSQueries.LoadFeeders.Contains("Supertype IN (40, 10136, 10, 15016)"), "SQL feeders supertypes");
        T.True(TLSQueries.LoadStations.Contains("Supertype IN (5, 15017)"), "SQL stations supertypes");
        T.True(TLSQueries.LoadFeeders.Contains("G.Relationship = 52"), "SQL MemberOf 52");
        T.True(TLSQueries.FindCoopPending.Contains("'PENDING'"), "SQL coop PENDING");
        T.True(TFMSQueries.LoadInfoItemEquipSeverity.Contains("J2.MoveCategory = 3") && TFMSQueries.LoadInfoItemEquipSeverity.Contains("J2.SwItemStatus = 20") && TFMSQueries.LoadInfoItemEquipSeverity.Contains("ORDER BY 1, 2"), "SQL severity constants/order");
        T.True(TFMSQueries.LoadPermits.Contains("J.Status IN ('', 'NIS', 'tbl')") && TFMSQueries.LoadPermits.Contains("J.MoveCategory = 0") && TFMSQueries.LoadPermits.Contains("ORDER BY JC.Seq"), "SQL permits filter/order");
        T.True(!TFMSQueries.LoadPermits.Contains("StepPair = 3"), "SQL permits no StepPair=3");
        // positional parameter order: Dapper/Actian binds p1, p2 in order -> Card first, StepPair second
        T.True(TFMSQueries.LoadPermits.IndexOf("JC.Card = ?") < TFMSQueries.LoadPermits.IndexOf("JC.StepPair = ?"), "SQL permits ? order Card, StepPair");
        T.True(TFMSQueries.LoadPermitsArchive.IndexOf("J.Card = ?") < TFMSQueries.LoadPermitsArchive.IndexOf("J.StepPair = ?"), "SQL permits archive ? order");
    }

    // ------------------------------------------------------------------ JSON for the visual pass
    static string BenchmarkJson()
    {
        var tls = TlsBenchmark(); TlsRowRules.Apply(tls, 1, new HashSet<int>());
        var toms = TomsBenchmark(); TfmsRowRules.Apply(toms, CARD, false, TomsSeverity());
        string Esc(string s) { return s == null ? "null" : "\"" + s.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\""; }
        string Obj(object o)
        {
            var props = o.GetType().GetProperties().Where(p => p.PropertyType == typeof(string) || p.PropertyType == typeof(bool) || p.PropertyType == typeof(int));
            return "{" + string.Join(",", props.Select(p => Esc(p.Name) + ":" + (p.PropertyType == typeof(bool) ? ((bool)p.GetValue(o) ? "true" : "false")
                : p.PropertyType == typeof(int) ? ((int)p.GetValue(o)).ToString(CultureInfo.InvariantCulture) : Esc((string)p.GetValue(o))))) + "}";
        }
        var permits = TomsPermitRow.Build(new[] {
            new WorkPermit { Job = 1, StepPair = Constants.StepHeading_WorkPermit, TOIssued = D("06/28 16:28"), RSComplete = D("06/28 20:02"), EquipClassName = "Bkr", EquipName = "2S", TOMove = "21879516-To PST: Check and repair breaker not closing via supervisory - 2S" },
            new WorkPermit { Job = 2, StepPair = Constants.StepHeading_WorkPermit, EquipClassName = "ACLineSegment", EquipName = "99153", TOMove = "(E179ST38 - DUN-S38) - To Tran.Ops.: Make the ISP Normal; ground level work - 99153",
                Protections = new List<PermitProtection> {
                    new PermitProtection { CardTypeName = "TFMS", Card = "99153", TOIssued = "06/28 05:44", TOComplete = "06/28 06:37", Subsordesk = "E179ST38", EquipClassName = "ManDiscFdrS", EquipName = "F7W", TOMove = "(Fdr 99153) - Open, Verify Open & Block Open Fdr Disc Sw All Phases - F7W" },
                    new PermitProtection { CardTypeName = "TFMS", Card = "99153", TOIssued = "06/27 22:51", TOComplete = "06/27 23:21", Subsordesk = "DUN-S38", EquipClassName = "ManDiscTrf", EquipName = "F3S", TOMove = "(Fdr 99153) - Open, Verify Open & Block Open Transf Disc Sw All Phases - F3S" } } },
            new WorkPermit { Job = 3, StepPair = Constants.StepHeading_TestPermit, TOIssued = D("06/29 23:23"), RSComplete = D("06/30 21:14"), EquipClassName = "STA-PH", EquipName = "99153", TOMove = "(Sta DUN-S38) - To FOD: 99153 Perform TDR fault locating, work with S/S operator remove & apply grds",
                Protections = new List<PermitProtection> { new PermitProtection { CardTypeName = "TFMS", Card = "99153", TOIssued = "06/29 11:33", TOComplete = "06/29 11:55", Subsordesk = "E179ST38", EquipClassName = "MOD-Bkr", EquipName = "6W7", TOMove = "(Bkr 6W) - Open, Verify Open & Block Open Bkr Disc All Phases - 6W7", RSIssued = "06/30 21:59", RSComplete = "06/30 23:10" } } } });
        return "{\"tls\":[" + string.Join(",", tls.Select(Obj)) + "],\"toms\":[" + string.Join(",", toms.Select(Obj)) + "],\"permits\":[" + string.Join(",", permits.Select(Obj)) + "]}";
    }

    static Program() { }
    public static void SetTemplateDir(string d) { TemplateDir = d; }
}
