# TLS card — make `tls-rpt.pdf` a replica of `tls-dos.pdf`

**Benchmark:** `tls-dos.pdf` (cards 96DHZA425413, 96PRNA410029, 96PRNA410945)
**Our report:** `tls-rpt.pdf` (cards 96DHZA425414, 96PRNA410944)

> The two PDFs were printed from **different cards**, so cell values can't be compared one to one.
> Everything below compares structure, colour rules and formatting, which are the same for every card.

Delivered in `issues\v2\Fixed\`:

| Folder | What |
|---|---|
| `Templates\TLS\TLSCard.trdx` | New TLS card template (card header + job grid in one report, FeederCard1 layout) |
| `Code\...` | Full replacement C# files, same relative paths as `Telerik-proj` |
| `Tests\` | Build + 940 checks + mutation check + visual emulator (how to run: section 7) |
| `Evidence\` | Benchmark page vs simulated page from the new template |

---

## 1. What was wrong

| # | Benchmark (`tls-dos.pdf`) | Our report (`tls-rpt.pdf`) | Cause |
|---|---|---|---|
| 1 | Landscape. Card header is a box at the top of page 1, then the job grid on the same page | Portrait header page (`TLSCardHeader.trdx`), grid starts on page 2 | Two separate reports in a ReportBook |
| 2 | Header shows Line # / Line type, Route, Carrier, **Type of Work**, **Fdrs / Nwks**, **Stations**, Note, Circuit Note, Reason For Failure | Labels and values don't line up (e.g. "Line Type: 0", "Priority: (blank)"); **Feeders / Stations tables are empty** | Feeders/Stations were never loaded (`LoadCardHeader` didn't query them); "Type of Work" was never derived |
| 3 | Empty date cells that don't apply to the move are **gray** (`#DCDCDC`) and **blank** | Prints **`12/31 23:59`**, white | Ingres "empty date" (`''`) arrives in .NET as a 12/31 23:59 value. Not handled |
| 4 | Op columns (Take Out and Restore) **blank** | Prints operator ids, wrapping (`23423` / `9`) | Template bound `TOOperator` / `RSOperator` |
| 5 | Column headers: Station, Circuit, Move, Results, *(blank)* | Substation, Line, Move, Results, **St** | Template |
| 6 | Status column shows **T** only for transferred moves | Raw status | `TLSJob_ASE.LoadJobs` maps `'Xfr'` → `T`, anything else → blank. Not ported |
| 7 | Step headings (Alarms, Switching Operations…) **navy**, inside the Move cell, other cells empty | Full-width bold row | Template |
| 8 | Page 2+ repeats the line number at the top; "Page *n* of *N*" restarts for each card | "Page 2 of 5" across cards | No continuation header; book-wide numbering |

**Row order is not a bug.** The C# job query is identical to OpenROAD `TLSJob_ASE.LoadJobs` (same table, filters and `ORDER BY steppair, seq, job`). I first suspected the rows that share times (e.g. "Line To SHORT" and "Receiver to TEST", both 12/04 18:45) were a join fan-out; that was wrong — it's the data of card 96PRNA410944.

## 2. The rules now (with sources)

Sources: `openrd\...\cac.dmt` (TLSJob_ASE / TLSCard_ASE), `online\tls\tlscard.js`, `fms-online\database.js` + `fms.css`.

### 2.1 Row colours and text — `TlsRowRules.ApplyRow`

| Cell | Rule | Source |
|---|---|---|
| Heading row (JobClass = 0) | Only the Move cell has text. All other cells empty and white. | tlscard.js `card_IsStepHeading`; every heading in tls-dos.pdf |
| Heading text colour | Navy `#000080` if CircuitClass = -99, else black. Not bold. Leading spaces in `TOMove` are kept (that's how DOS indents it) | cac.dmt 228771; measured: Arial 8, colour 0x000080 |
| TO/RS Issued/Complete text | `MM/dd HH:mm`. NULL and empty date print nothing | — |
| TO/RS Issued/Complete background | **Empty date (`''`) → gray `#DCDCDC`**; NULL → white | cac.dmt 228775-228787; measured fill (220,220,220) |
| Op (both) | Always blank | benchmark; same as FMS Fix 3 |
| Station / Circuit / Results | `SubstationName` / `Linenumber` / `Results` | tlscard.js `card_LoadJob` |
| Status (unlabelled column) | `T` if Status = `Xfr`, else blank | cac.dmt 228559 |
| Move background | Pale red `#FFB6C1` when MoveType = `COOP` **and** `TC_WorkPermit.VendorTicketNumber = 'PENDING'`, else white | cac.dmt 228816-228826 |
| Transferred move on a closed card | NULL dates also gray — ported exactly, see open item 1 | cac.dmt 228792-228810 |

**Deliberately not ported:** OpenROAD dims completed / pending-confirmation moves with light-gray text (cac.dmt 228756). `tls-dos.pdf` has **no gray text at all**, although it has moves completed on both sides (e.g. Check Alarm Status 01/05 10:13 → 01/16 10:15). So the DOS report does not apply it, and neither do we.

### 2.2 Header — `TLSCard_ASE.LoadCard` / `LoadFeedersAndStations`

| Box | Value |
|---|---|
| Top left | `Linenumber` · `LineTypeName` |
| Route / Carrier | `RouteName` / `CarrierName` |
| Type of Work | CardType 0 → `TROUBLE`, otherwise `SCHEDULED` (cac.dmt 227800-227804) |
| Fdrs / Nwks | Active card: `Udb_Object`/`Udb_Grouping` members of the circuit, supertypes Feeder 40, Network 10136, Line 10, DivisionWorkstation 15016, relationship MemberOf 52, names `SQUEEZE`d. Archived card: `TC_ArchiveCard.FeederNames` split on commas. Printed `A, B, C` |
| Stations | Same, supertypes Substation 5, TelCircuitTerminal 15017 / `TC_ArchiveCard.SubstationNames` |
| Card Closed | Label and date only when the card has a Closed date (box is empty otherwise, as in the benchmark) |
| Note | `TC_CardNote.Note` |
| Circuit Note | `TC_Card.Notes` |
| Reason For Failure | `ReasonForFailure` |

Mapping proof: in tls-rpt.pdf page 3 the old template printed "Montefiore contact Vasile…" under *Card Note* and "ONLY 1 LINE OF PROTECTION…" under *Notes*; the benchmark prints the Montefiore text under **Note:** and the circuit text under **Circuit Note:**.

### 2.3 Layout — `TLSCard.trdx` (FeederCard1 format)

- Letter **landscape**, margins L/R 0.15in, T/B 0.5in, width 10.7in (as FeederCard1).
- Report header = the card box; page header (pages 2+) = line number; column header repeats on every page; footer = print time + "Page *n* of *N*".
- `PageNumberingStyle="ResetNumberingAndCount"` → each card starts at Page 1 (as the deployed FeederCard.trdx and the benchmark).
- Grid (inches): Op 0.35 · Issued 0.75 · Complete 0.75 · Station 1.10 · Circuit 1.10 · Move 3.50 · Results 1.10 · status 0.25 · Op 0.35 · Issued 0.72 · Complete 0.72 = 10.69. Row 0.27in, Arial 8 (measured in the benchmark).
- **Every cell in the template has `CanGrow="True"`** (header boxes, column headers and grid cells), so no value is ever cut off.
- Every grid cell also has `Anchoring="Top, Bottom"`: when any one cell wraps to several lines, the whole row grows and all bottom borders stay aligned (same technique as FMSWorkPermit.trdx). Both are enforced by tests.
- The company logo header is still added by `PrependHeader`, unchanged.

All colours and texts are computed in C#; the template only binds `= Fields.X`. Nothing to evaluate in Telerik expressions, so the logic is unit-tested.

## 3. Steps

Apply in this order. Every file is a full replacement in `Fixed\Code\` (same path as in `Telerik-proj`).

> **Replace whole files, do not copy methods.** Every file in `Fixed\Code\` is the complete file: your original plus the change. Copy it over the file with the same path in `Telerik-proj` (or add it, if it's new). This is only safe if your `Telerik-proj` file is still the same as the copy in `issues2\Issues_2\Telerik-proj` (snapshot of 2026-09-30). If someone has edited one of these files since, merge that file by hand instead.

| # | File | Change |
|---|---|---|
| 1 | `Models\Jobs\TlsJob.cs` | + 16 display properties (`IsHeading`, `TOIssuedText`…`RSCompleteBg`, `StationText`, `CircuitText`, `MoveText`, `MoveFg`, `MoveBg`, `ResultsText`, `StatusText`). Existing properties unchanged (TLS Excel unaffected) |
| 2 | `Models\Cards\TlsCardModels.cs` | `TlsCardHeader`: + `FeederNames`, `SubstationNames`, `CardTypeName`, `FeedersText`, `StationsText`, `Squeeze()`, `SplitNames()` |
| 3 | **New** `Models\Jobs\Colors\DosColors.cs` | Colour palette as the DOS PDFs draw it (shared with TOMS) |
| 4 | **New** `Models\Jobs\Colors\TlsRowRules.cs` | Rules of section 2.1 |
| 5 | `Models\FMS_PDFReportService.Models.csproj` | + `<Compile Include>` for the new files (shared with TOMS — the delivered file already has all 4) |
| 6 | `Data\Queries\TLSQueries.cs` | + `LoadFeeders`, `LoadStations`, `LoadFeederStationNamesArchive`, `FindCoopPending` |
| 7 | `Data\Repositories\ITLSCardRepository.cs` | + `HashSet<int> LoadCoopPendingJobs(IEnumerable<TlsJob> jobs)` |
| 8 | `Data\Repositories\TLSCardRepository.cs` | `LoadCardHeader` loads Feeders/Stations (active and archive); new `LoadCoopPendingJobs` |
| 9 | `Engine\Groupers\ReportGroupers.cs` | `TLSGrouper.ComposeCard`: one source `TLS/TLSCard.trdx` with rows coloured by `TlsRowRules` and the header as parameters. Only `TLSGrouper` and `TFMSGrouper` changed |
| 10 | `Engine\Templates\TLS\TLSCard.trdx` | Replace with the delivered file |

`TLSCardHeader.trdx` is no longer used by `TLSGrouper` (the file is left as is). No DI / constructor change.

Core of the grouper:

```csharp
var header = _repo.LoadCardHeader(cardId, request.ArchiveFlag);
var jobs = _repo.LoadJobs(cardId, request.ArchiveFlag).ToList();
TlsRowRules.Apply(jobs, header?.Status ?? 0, _repo.LoadCoopPendingJobs(jobs));
sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TLS/TLSCard.trdx"),
    jobs, BuildHeaderParameters(header)));
```

Deploy the C# and the template **together**: the new template binds fields that only exist after step 1.

## 4. Tests run (three passes)

| Pass | What | Result |
|---|---|---|
| Baseline | Untouched `Models` + `Data` + groupers compiled with Roslyn, using each `.csproj`'s own file list | 0 errors |
| 1 — build + template integrity | Changed code compiles (`Models` 57 files, `Data` 55, groupers vs. Telerik stubs). Every `Fields.X` in the template exists on `TlsJob`; every parameter declared, sent by the grouper and used; grid tiles 0 → 10.69in with no gap/overlap; header boxes line up with grid columns; Op cells blank; landscape / margins / numbering as FeederCard1 | pass |
| 2 — rules | Rows rebuilt from tls-dos.pdf page 1: all 13 data rows × 4 date cells match the benchmark's gray/white pattern; no `12/31 23:59` ever printed; headings navy, empty, white; `Xfr`→T; COOP pending / not pending / other move types; transferred-on-closed branch; null safety; header text (TROUBLE/SCHEDULED, joins, archive split/squeeze, Card Closed label); grouper with fake repository incl. null header | pass |
| 3 — visual | Emulator draws `TLSCard.trdx` with the C#-computed rows → `Evidence\TLS_simulated_card_96DHZA425413.png` next to `TLS_benchmark_p1.png`. Colour inventory: **18 gray cells and 5 navy headings, same positions as the benchmark page** | match |
| Guardrail | Mutation check: 11 deliberate faults injected one at a time (e.g. gray removed, gray on real dates, wrong palette, grid gap, field renamed) | **11/11 caught** |

Total: 940 checks, 0 failures (shared with TOMS).

## 5. What I could NOT verify — be aware

1. **No Telerik runtime on this machine** (no `packages` folder). The template was never rendered by Telerik. It only uses features already working in your deployed templates (Value/Visible/BackgroundColor/Color bindings, CanGrow, `Anchoring="Top, Bottom"`, groups, `PageNumberingStyle`, schema `2026/2.1`), but **render it once before release**.
2. **No database.** The 4 new SQL statements were checked against the OpenROAD source and by static tests (parameter count/order, constants), not executed. `SQUEEZE()` is an Ingres function, as in the OpenROAD query.
3. Leading spaces in headings: the old TOMS output shows Telerik keeps them; not seen with the new template yet.
4. The empty-date test is the existing `FmsColorCalculator.IsBlank` (month 12, day 31, 23:59). A real time of 31-Dec 23:59 would also be treated as "not applicable" — same limitation as the FMS report.

## 6. Open items for the SME

1. **Transferred moves on closed cards.** OpenROAD compares the TC card status (1-4) with `Card$Closed` (= 50), so this branch never fires in production. Ported exactly. If the intent was status 4 (CLOSED), change `Constants.Card_Closed` to `Constants.TC_Card_Closed` in `TlsRowRules` — only after confirming.
2. **Co-Op pending pale red**: from OpenROAD; no Co-Op row in the benchmark to confirm the DOS draws it. Kept because hiding a pending Co-Op test is the riskier choice.
3. Feeders/Stations order: OpenROAD has no `ORDER BY`, so neither do we; the order is whatever Ingres returns.

4. **Where the rules come from.** The DOS report program (the one PrintReport.ps1 calls) is not in the provided files. Rules are taken from OpenROAD `TLSJob_ASE` and the web screen, and checked against the colours measured in tls-dos.pdf. Confirmed by the benchmark: empty-date gray, navy headings, blank Op. Not confirmed (no example in the benchmark): Co-Op pale red, `T` in the status column.

## 7. How to test with real data (UAT)

1. Print **96DHZA425413, 96PRNA410029, 96PRNA410945** (the benchmark cards) and compare page by page with `tls-dos.pdf`:
   - gray cells exactly where the benchmark has them; no `12/31 23:59` anywhere;
   - Op columns blank; status column only `T`;
   - header: Route, Carrier, Type of Work, Fdrs / Nwks (e.g. `38M22, 38M23, 38M24, 38M25, 38M26`), Stations, Note, Circuit Note;
   - page 2 starts with the line number and the column header; each card restarts at Page 1.
2. Print one **archived** card (ARCH=1): Fdrs / Nwks and Stations come from the stored names.
3. Re-run the offline checks: `PROJ=<Telerik-proj> bash Fixed/Tests/runtests.sh` → `PASSED 940 FAILED 0`.
