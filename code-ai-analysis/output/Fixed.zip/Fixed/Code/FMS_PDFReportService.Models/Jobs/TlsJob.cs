using System;

namespace FMS_PDFReportService.Models.Jobs
{
    public class TlsJob
    {
        public int Job { get; set; }
        public int Card { get; set; }
        public string Status { get; set; }
        public int Seq { get; set; }
        public int JobClass { get; set; }
        public int JobClassSeq { get; set; }
        public int Circuit { get; set; }
        public string Linenumber { get; set; }
        public int CircuitClass { get; set; }
        public string CircuitClassName { get; set; }
        public int StepPair { get; set; }
        public string MoveType { get; set; }
        public string TOMoveRules { get; set; }
        public string TOOperator { get; set; }
        public string TOOperatorName { get; set; }
        public DateTime? TOIssued { get; set; }
        public DateTime? TOComplete { get; set; }
        public string TOMove { get; set; }
        public string TOStep { get; set; }
        public string Results { get; set; }
        public int ResultsCode { get; set; }
        public string ResultsCodeName { get; set; }
        public int Substation { get; set; }
        public string SubstationName { get; set; }
        public int Organization { get; set; }
        public string OrganizationName { get; set; }
        public string RSMoveRules { get; set; }
        public string RSOperator { get; set; }
        public string RSOperatorName { get; set; }
        public DateTime? RSIssued { get; set; }
        public DateTime? RSComplete { get; set; }
        public string RSMove { get; set; }
        public string RSStep { get; set; }
        public string InitialSwitchPos { get; set; }
        public string FinalSwitchPos { get; set; }
        public DateTime? InService { get; set; }
        public DateTime? OutService { get; set; }

        // Display values for TLSCard.trdx. Not database columns; set only by TlsRowRules.Apply.
        public bool IsHeading { get; set; }
        public string TOIssuedText { get; set; }
        public string TOCompleteText { get; set; }
        public string RSIssuedText { get; set; }
        public string RSCompleteText { get; set; }
        public string TOIssuedBg { get; set; }
        public string TOCompleteBg { get; set; }
        public string RSIssuedBg { get; set; }
        public string RSCompleteBg { get; set; }
        public string StationText { get; set; }
        public string CircuitText { get; set; }
        public string MoveText { get; set; }
        public string MoveFg { get; set; }
        public string MoveBg { get; set; }
        public string ResultsText { get; set; }
        public string StatusText { get; set; }
    }
}
