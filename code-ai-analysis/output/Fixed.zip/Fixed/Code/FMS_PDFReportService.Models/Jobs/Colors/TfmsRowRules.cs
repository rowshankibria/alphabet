using System;
using System.Collections.Generic;
using System.Globalization;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // One row of ItemCategory_ASE.LoadEquip (cac.dmt): equipment on the card that is linked to an
    // active information item, with the item's severity.
    public class InfoItemEquipSeverity
    {
        public int Equip { get; set; }
        public int? Severity { get; set; }
    }

    // Display values and colours for one TOMS card row (TFMSCard.trdx).
    // Port of soa.dmt SOA_Main  ON USEREVENT 'MoveColors'  (TFMS branch), limited to what the DOS
    // benchmark (toms-dos.pdf) draws. Timestamp text colours (operating-order gray/red) are NOT drawn:
    // toms-dos.pdf has no coloured date text in 180 pages.
    public static class TfmsRowRules
    {
        // ItemCategory_ASE.LoadEquip keeps the FIRST row per equipment of
        // "ORDER BY Equip, Severity"; SOA_Main then uses the first match. Rows must arrive in that order.
        public static Dictionary<int, int?> FirstSeverityPerEquip(IEnumerable<InfoItemEquipSeverity> rows)
        {
            var map = new Dictionary<int, int?>();
            if (rows == null) return map;
            foreach (var r in rows)
                if (!map.ContainsKey(r.Equip))
                    map.Add(r.Equip, r.Severity);
            return map;
        }

        // cardId    : the card being printed (SOA_Main Card.Card)
        // archived  : request.ArchiveFlag == 1
        // equipSeverity: from FirstSeverityPerEquip; must be empty unless the card is active and not archived
        //               (SOA_Main only loads it when ArchiveCard = FALSE AND Card.Status = Card$Active).
        public static void Apply(IEnumerable<TfmsJob> jobs, int cardId, bool archived, IDictionary<int, int?> equipSeverity)
        {
            if (jobs == null) return;
            foreach (var j in jobs)
                ApplyRow(j, cardId, archived, equipSeverity);
        }

        public static void ApplyRow(TfmsJob j, int cardId, bool archived, IDictionary<int, int?> equipSeverity)
        {
            string status = j.Status ?? string.Empty;
            bool outstanding = status == string.Empty || status == Constants.JobStatus_NIS;   // Status = '' OR 'NIS'

            j.MoveText = j.TOMove ?? string.Empty;   // leading spaces kept: the DOS card indents headings with them

            // ---- Move text colour -------------------------------------------------------------
            string moveFg = DosColors.Black;
            // tfmscard.js: switching item with a shadow link is green (web rule; not in SOA_Main).
            if (j.MoveCategory == Constants.MoveCategory_SwitchingItem && j.ShadowLink != 0)
                moveFg = DosColors.Green;
            // "IF J[i].MoveFgColor <> 0 THEN FIELD(J[i].TOMove).FgColor = J[i].MoveFgColor"
            if (j.MoveFGColor != 0)
                moveFg = DosColors.FromCode(j.MoveFGColor) ?? moveFg;
            // "Look for moves that set equipment ground" (applied after MoveFgColor, so it wins)
            bool ground = j.Grounds.HasValue && j.Grounds.Value > 0 && j.GroundOn != null && outstanding;
            if (ground) moveFg = DosColors.Red;
            j.MoveFg = moveFg;

            // ---- Move background ---------------------------------------------------------------
            string moveBg = j.MoveBGColor != 0 ? (DosColors.FromCode(j.MoveBGColor) ?? DosColors.White) : DosColors.White;
            // "Look for outstanding Test Letter moves": issued, not complete -> CC_PALE_ORANGE,
            // otherwise CC_PALE_YELLOW = the card's normal background (white on the DOS card).
            if (j.JobClass == Constants.JobClass_TestLetter)
                moveBg = (j.TOIssued != null && j.TOComplete == null && outstanding)
                    ? DosColors.FromCode(Constants.CC_PALE_ORANGE)
                    : DosColors.White;
            j.MoveBg = moveBg;

            if (j.JobClass == 0)
            {
                // Step / substation / FIELD WORK heading (tfmscard.js card_IsStepHeading).
                // DOS: bold, coloured only in the Move cell, every other cell empty and white.
                j.IsHeading = true;
                j.MoveBold = true;
                j.TOIssuedText = j.TOCompleteText = j.RSIssuedText = j.RSCompleteText = string.Empty;
                j.TOIssuedBg = j.TOCompleteBg = j.RSIssuedBg = j.RSCompleteBg = DosColors.White;
                j.TypeText = j.EquipText = j.GText = j.OriginText = j.ResponseText = string.Empty;
                j.EquipFg = j.GFg = DosColors.Black;
                j.OriginBg = DosColors.White;
                return;
            }

            j.IsHeading = false;
            j.MoveBold = false;

            // ---- Timestamps: "Grey issue/complete times as appropriate" (empty date only) ------
            j.TOIssuedText = DateText(j.TOIssued);
            j.TOCompleteText = DateText(j.TOComplete);
            j.RSIssuedText = DateText(j.RSIssued);
            j.RSCompleteText = DateText(j.RSComplete);
            j.TOIssuedBg = GrayIfBlank(j.TOIssued);
            j.TOCompleteBg = GrayIfBlank(j.TOComplete);
            j.RSIssuedBg = GrayIfBlank(j.RSIssued);
            j.RSCompleteBg = GrayIfBlank(j.RSComplete);

            // ---- Type / Equipment: "If card does not have control of the move, grey out the equipment"
            j.TypeText = j.EquipClassName ?? string.Empty;
            j.EquipText = j.EquipName ?? string.Empty;
            j.EquipFg = (j.ControlCard != cardId && j.MoveCategory == Constants.MoveCategory_Normal)
                ? DosColors.Gray
                : DosColors.Black;

            // ---- G column ---------------------------------------------------------------------
            j.GText = j.Grounds.HasValue && j.Grounds.Value > 0
                ? j.Grounds.Value.ToString(CultureInfo.InvariantCulture)
                : string.Empty;
            j.GFg = ground ? DosColors.Red : DosColors.Black;

            // ---- Origin cell (ActivityIdentifier) -----------------------------------------------
            // Text: S is not printed on a closed (archived) card (tfmscard.js; same rule as FeederCard).
            string act = j.ActivityIdentifier ?? string.Empty;
            j.OriginText = (archived && act.Trim() == "S") ? string.Empty : act;
            // Colour: "Look for equipment moves associated to an info item"
            j.OriginBg = DosColors.White;
            int? sev;
            if (!archived && equipSeverity != null && j.MoveCategory == Constants.MoveCategory_Normal && outstanding
                && equipSeverity.TryGetValue(j.Equip, out sev) && sev.HasValue)
            {
                if (sev.Value == 1) j.OriginBg = DosColors.InfoSeverity1;
                else if (sev.Value == 2) j.OriginBg = DosColors.InfoSeverity2;
                else if (sev.Value == 3) j.OriginBg = DosColors.InfoSeverity3;
            }

            j.ResponseText = j.Response ?? string.Empty;
        }

        private static string GrayIfBlank(DateTime? d)
        {
            return FmsColorCalculator.IsBlank(d) ? DosColors.TomsGrayOut : DosColors.White;
        }

        public static string DateText(DateTime? d)
        {
            if (!FmsColorCalculator.HasValue(d)) return string.Empty;
            return d.Value.ToString("MM/dd HH:mm", CultureInfo.InvariantCulture);
        }
    }
}
