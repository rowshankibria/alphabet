namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // Colours as the DOS (benchmark) PDFs draw them, for the TLS and TOMS card grids.
    // Codes are OpenROAD CC_* values (Constants.cs). The hex values come from fms-online database.js
    // db_GetMappedColor and fms.css, except CC_BLUE (DOS draws step headings Navy, not #0000ff).
    // "Seen" = measured in tls-dos.pdf / toms-dos.pdf. Do NOT use Engine ColorMappingService for these
    // reports: its palette does not match the benchmark (e.g. code 33 there is not Gold).
    public static class DosColors
    {
        public const string White = "#FFFFFF";
        public const string Black = "#000000";
        public const string Navy = "#000080";           // seen: TLS + TOMS step headings
        public const string Red = "#FF0000";            // seen: TOMS ground moves, G column
        public const string Green = "#008000";          // seen: TOMS move text
        public const string Gray = "#808080";           // seen: TOMS Type/Equipment text (CC_LIGHT_GRAY)

        // Ingres empty date ('' = step not used). Both are CC_PALE_GRAY in OpenROAD,
        // but the two DOS reports draw it differently.
        public const string TlsGrayOut = "#DCDCDC";     // seen: tls-dos.pdf (220,220,220)
        public const string TomsGrayOut = "#808080";    // seen: toms-dos.pdf (128,128,128)

        // Origin ("S") cell, information-item severity (fms.css .Info_1/.Info_2/.Info_3)
        public const string InfoSeverity1 = "#FFFF00";  // seen: yellow
        public const string InfoSeverity2 = "#00CED1";  // seen: darkturquoise
        public const string InfoSeverity3 = "#3CB371";  // seen: mediumseagreen

        // Maps an OpenROAD colour code to hex. Returns null for 0 (not set) and for codes
        // with no mapping, so the caller keeps its default.
        public static string FromCode(int code)
        {
            switch (code)
            {
                case Constants.CC_BLACK: return Black;
                case Constants.CC_RED: return Red;
                case Constants.CC_GREEN: return Green;
                case Constants.CC_BLUE: return Navy;
                case Constants.CC_YELLOW: return "#FFFF00";
                case Constants.CC_CYAN: return "#00FFFF";
                case Constants.CC_PINK: return "#FFC0C0";
                case Constants.CC_BROWN: return "#8B4513";
                case Constants.CC_ORANGE: return "#FF8C00";
                case Constants.CC_PURPLE: return "#800080";
                case Constants.CC_GRAY: return "#696969";
                case Constants.CC_LIGHT_RED: return "#FF4500";
                case Constants.CC_LIGHT_GREEN: return "#3CB371";
                case Constants.CC_LIGHT_BLUE: return "#6495ED";
                case Constants.CC_LIGHT_YELLOW: return "#F0E68C";
                case Constants.CC_LIGHT_CYAN: return "#B0E0E6";
                case Constants.CC_LIGHT_PINK: return "#EE82EE";
                case Constants.CC_LIGHT_BROWN: return "#D2B48C";
                case Constants.CC_LIGHT_ORANGE: return "#FFA500";
                case Constants.CC_LIGHT_PURPLE: return "#8A2BE2";
                case Constants.CC_LIGHT_GRAY: return Gray;
                case Constants.CC_PALE_RED: return "#FFB6C1";      // seen: LightPink band
                case Constants.CC_PALE_GREEN: return "#90EE90";
                case Constants.CC_PALE_BLUE: return "#87CEFA";     // seen: LightSkyBlue band
                case Constants.PALE_YELLOW: return "#FAFAD2";
                case Constants.CC_PALE_CYAN: return "#E0FFFF";
                case Constants.CC_PALE_PINK: return "#D8BFD8";     // seen: Thistle band
                case Constants.CC_PALE_BROWN: return "#DEB887";    // seen: BurlyWood band
                case Constants.CC_PALE_ORANGE: return "#FFD700";   // seen: Gold band
                case Constants.CC_PALE_PURPLE: return "#E6E6FA";
                case Constants.CC_PALE_GRAY: return "#A9A9A9";
                default: return null;
            }
        }
    }
}
