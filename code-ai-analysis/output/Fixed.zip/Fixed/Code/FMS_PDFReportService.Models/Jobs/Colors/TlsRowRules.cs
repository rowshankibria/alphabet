using System;
using System.Collections.Generic;
using System.Globalization;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // Display values and colours for one TLS card row (TLSCard.trdx).
    // Port of cac.dmt TLSJob_ASE.LoadJobs (Status -> 'T') and TLSJob_ASE.SetMoveColors,
    // limited to what the DOS benchmark (tls-dos.pdf) draws:
    //   - background colours ARE drawn (empty-date gray, Co-Op pending pale red)
    //   - foreground dimming of completed / pending-confirmation moves (CC_LIGHT_GRAY text) is NOT drawn:
    //     tls-dos.pdf has no gray text at all, although it contains moves completed on both sides.
    public static class TlsRowRules
    {
        public static void Apply(IEnumerable<TlsJob> jobs, int cardStatus, ICollection<int> coopPendingJobs)
        {
            if (jobs == null) return;
            foreach (var j in jobs)
                ApplyRow(j, cardStatus, coopPendingJobs);
        }

        public static void ApplyRow(TlsJob j, int cardStatus, ICollection<int> coopPendingJobs)
        {
            // LoadJobs: 'Xfr' (transferred) prints as T, every other status prints blank.
            j.StatusText = j.Status == "Xfr" ? "T" : string.Empty;
            j.MoveText = j.TOMove ?? string.Empty;   // leading spaces kept: the DOS card indents with them
            j.MoveBg = DosColors.White;

            if (j.JobClass == 0)
            {
                // Step heading / note row (tlscard.js card_IsStepHeading). Only the Move cell has text.
                // SetMoveColors: JobClass 0 AND CircuitClass -99 -> CC_BLUE (DOS draws Navy); other rows black.
                // Every other cell is empty and white (all heading rows in tls-dos.pdf).
                j.IsHeading = true;
                j.MoveFg = j.CircuitClass == -99 ? DosColors.Navy : DosColors.Black;
                j.StationText = j.CircuitText = j.ResultsText = j.StatusText = string.Empty;
                j.TOIssuedText = j.TOCompleteText = j.RSIssuedText = j.RSCompleteText = string.Empty;
                j.TOIssuedBg = j.TOCompleteBg = j.RSIssuedBg = j.RSCompleteBg = DosColors.White;
                return;
            }

            j.IsHeading = false;
            j.MoveFg = DosColors.Black;
            j.StationText = j.SubstationName ?? string.Empty;
            j.CircuitText = j.Linenumber ?? string.Empty;
            j.ResultsText = j.Results ?? string.Empty;

            j.TOIssuedText = DateText(j.TOIssued);
            j.TOCompleteText = DateText(j.TOComplete);
            j.RSIssuedText = DateText(j.RSIssued);
            j.RSCompleteText = DateText(j.RSComplete);

            // "Gray out move performance if not available": Ingres empty date ('') only, never NULL.
            j.TOIssuedBg = GrayIfBlank(j.TOIssued);
            j.TOCompleteBg = GrayIfBlank(j.TOComplete);
            j.RSIssuedBg = GrayIfBlank(j.RSIssued);
            j.RSCompleteBg = GrayIfBlank(j.RSComplete);

            // "Handle Transferred moves for closed cards": NULL dates also gray.
            // Ported exactly: OpenROAD compares the TC card status (1..4) with Card$Closed (50),
            // so in production this branch never fires. See TLS_Fix.md, open item.
            if (j.StatusText == "T" && cardStatus == Constants.Card_Closed)
            {
                if (j.TOIssued == null) j.TOIssuedBg = DosColors.TlsGrayOut;
                if (j.TOComplete == null) j.TOCompleteBg = DosColors.TlsGrayOut;
                if (j.RSIssued == null) j.RSIssuedBg = DosColors.TlsGrayOut;
                if (j.RSComplete == null) j.RSCompleteBg = DosColors.TlsGrayOut;
            }

            // "Highlight move if Co-Op test is PENDING ticketnumber"
            if (string.Equals((j.MoveType ?? string.Empty).Trim(), Constants.MoveType_COOP, StringComparison.Ordinal)
                && coopPendingJobs != null && coopPendingJobs.Contains(j.Job))
            {
                j.MoveBg = DosColors.FromCode(Constants.CC_PALE_RED);
            }
        }

        private static string GrayIfBlank(DateTime? d)
        {
            return FmsColorCalculator.IsBlank(d) ? DosColors.TlsGrayOut : DosColors.White;
        }

        // NULL and the empty-date value both print as nothing; anything else as MM/dd HH:mm.
        public static string DateText(DateTime? d)
        {
            if (!FmsColorCalculator.HasValue(d)) return string.Empty;
            return d.Value.ToString("MM/dd HH:mm", CultureInfo.InvariantCulture);
        }
    }
}
