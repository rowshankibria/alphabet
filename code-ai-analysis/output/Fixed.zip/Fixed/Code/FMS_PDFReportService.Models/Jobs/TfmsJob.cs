using System;

namespace FMS_PDFReportService.Models.Jobs
{
    public class TfmsJob
    {
        public int Job { get; set; }
        public int Card { get; set; }
        public int Seq { get; set; }
        public string Status { get; set; }
        public int JobClass { get; set; }
        public int Equip { get; set; }
        public int EquipClass { get; set; }
        public string EquipClassName { get; set; }
        public string EquipName { get; set; }
        public int StepPair { get; set; }
        public int? Grounds { get; set; }
        public string MoveType { get; set; }
        public string TOMove { get; set; }
        public int TOMoveRules { get; set; }
        public int? TOOperator { get; set; }
        public DateTime? TOIssued { get; set; }
        public DateTime? TOComplete { get; set; }
        public DateTime? GroundOn { get; set; }
        public string RSMove { get; set; }
        public int RSMoveRules { get; set; }
        public int? RSOperator { get; set; }
        public DateTime? RSIssued { get; set; }
        public DateTime? RSComplete { get; set; }
        public string Response { get; set; }
        public string ActivityIdentifier { get; set; }
        public int MoveEquipClass { get; set; }
        public int Substation { get; set; }
        public string SubstationName { get; set; }
        public string PrimaryGroupingName { get; set; }
        public int StructureType { get; set; }
        public int ShadowLink { get; set; }
        public int MoveCategory { get; set; }
        public int StepLevel { get; set; }
        public int ControlCard { get; set; }
        public int MoveFGColor { get; set; }
        public int MoveBGColor { get; set; }
        public string DeskName { get; set; }
        public int SwitchingItem { get; set; }

        // Display values for TFMSCard.trdx. Not database columns; set only by TfmsRowRules.Apply.
        public bool IsHeading { get; set; }
        public string TOIssuedText { get; set; }
        public string TOCompleteText { get; set; }
        public string RSIssuedText { get; set; }
        public string RSCompleteText { get; set; }
        public string TOIssuedBg { get; set; }
        public string TOCompleteBg { get; set; }
        public string RSIssuedBg { get; set; }
        public string RSCompleteBg { get; set; }
        public string TypeText { get; set; }
        public string EquipText { get; set; }
        public string EquipFg { get; set; }
        public string GText { get; set; }
        public string GFg { get; set; }
        public string MoveText { get; set; }
        public string MoveFg { get; set; }
        public string MoveBg { get; set; }
        public bool MoveBold { get; set; }
        public string OriginText { get; set; }
        public string OriginBg { get; set; }
        public string ResponseText { get; set; }
    }
}
