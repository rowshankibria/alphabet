# TOMS (TFMS) card — make `toms-rpt.pdf` a replica of `toms-dos.pdf`

**Benchmark:** `toms-dos.pdf` (180 pages, several cards). Pages **172-180 are card 372937 — the same card as `toms-rpt.pdf`**, so this card was compared row by row.
**Our report:** `toms-rpt.pdf` (card 372937, report type 1: card + log + permits).

Delivered in `issues\v2\Fixed\`:

| Folder | What |
|---|---|
| `Templates\TFMS\TFMSCard.trdx` | New card template: card header + job grid in one report (FeederCard1 layout) |
| `Templates\TFMS\TOMSWorkPermit.trdx` | New "Permits and Protections for …" |
| `Templates\TFMS\TFMSCardLog.trdx` | New "TFMS Card Log for …" |
| `Code\...` | Full replacement C# files, same relative paths as `Telerik-proj` |
| `Tests\`, `Evidence\` | See TLS_Fix.md section 7 / the PNGs |

---

## 1. What was wrong (card 372937, benchmark pages 172-180 vs toms-rpt.pdf)

| # | Benchmark | Our report | Cause |
|---|---|---|---|
| 1 | Landscape card box: **372937 · Auto · 99153 · Note**, Cut Out / Cut In, description `DUN-S38:(2S,3S) E179ST38:(7W,6W)` | Separate portrait page "TOMS Switching Card" with Objects / Prepared By tables; Status 0; Cut Out/In missing | `TFMSCardHeader.trdx`; the header query never read `SOA_Card` (class, cut out/in, note, status) |
| 2 | **ID** column blank | Prints SOA_JobControl Seq (`10102`/`0000` wrapped) | Template bound `Seq` |
| 3 | **Op** columns blank | Prints operator ids (`10007`, `10001`, `23479`/`1`) | Template |
| 4 | Not-applicable dates gray `#808080`, blank | Prints `12/31 23:59` | Ingres empty date not handled |
| 5 | Headings only in the Move cell, **bold**; substation names on a coloured band (BurlyWood, Gold, LightSkyBlue, LightPink, Thistle); "EN - DE - EN" red on light blue | Full-width rows, plain text, no colour | Template; `MoveBGColor`/`MoveFGColor` not mapped |
| 6 | Type + Equipment **gray** when the card doesn't control the move (e.g. `Bkr 2S`, `MOD-Bkr 6W6`) | Black | Rule missing |
| 7 | "S" cell **yellow / turquoise / green** for equipment on an information item | Plain | Rule and its query missing |
| 8 | Hi-Pot rows with G = 3 are **black** (p176); other G = 3 rows red (p13) | All rows with Grounds > 0 red | Old template: `Grounds > 0` only. OpenROAD also needs GroundOn and status |
| 9 | **Permits and Protections** for 99153: 8 Work Permits + 1 Test Permit, each with its protection moves (pp. 178-180) | "TOMS Work Permits" page **empty** | Query used `StepPair = 3`; TOMS permits are StepPair **600** (Work) and **650** (Test) — the rpt's own Seq values (601xx, 651xx) show it |
| 10 | "TFMS Card Log for 99153": Date · Status · Log Entry, landscape | Portrait, extra columns (Entered By, Item) | Template (the data and order were already right) |
| 11 | Each card numbers "Page 1 of N" | Book-wide numbering | `PageNumberingStyle` |

**Row order is already correct:** card 372937 lists the same rows in the same order in both PDFs. The job query equals OpenROAD `Job_ASE.LoadTFMSJobs` (cac.dmt 104781), including its inner join on `Udb_Object` and `ORDER BY StepPair, StepLevel, Seq`.

## 2. The rules now (with sources)

Main source: `openrd\TOMS_soa\soa.dmt`, `SOA_Main ON USEREVENT 'MoveColors'` (line 35926 ff.), the TFMS colour routine. Also `online\toms\tfmscard.js` `card_LoadJob`, `fms-online\database.js` `db_GetMappedColor`, `fms-online\fms.css`.

### 2.1 Row colours and text — `TfmsRowRules.ApplyRow`

| Cell | Rule | Source |
|---|---|---|
| Heading row (JobClass = 0) | Only the Move cell: **bold**, text colour = `MoveFGColor`, background = `MoveBGColor`. All other cells empty and white. Leading spaces kept (DOS indents with them) | tfmscard.js `card_IsStepHeading`; soa.dmt 36117-36144; measured in benchmark |
| Dates | `MM/dd HH:mm`; **empty date → gray `#808080`**, blank; NULL → white, blank | soa.dmt "Grey issue/complete times" (~36079); measured fill (128,128,128) |
| Op, ID | Always blank | benchmark; tfmscard.js "print ID column" = `&nbsp;` |
| Type, Equipment | Gray `#808080` text when `ControlCard ≠ this card` **and** MoveCategory = Normal (0) | soa.dmt 36095-36099 |
| G | `Grounds` when > 0, else blank. Red when the ground rule applies | soa.dmt 36146-36153 |
| Move text colour | Black → green if switching item with a shadow link (web rule) → `MoveFGColor` if ≠ 0 → **red if** Grounds > 0 **and** GroundOn IS NOT NULL **and** Status is '' or NIS (applied last, so it wins) | tfmscard.js; soa.dmt 36140-36153 |
| Move background | `MoveBGColor` if ≠ 0. Test Letter (JobClass 15000): Gold while issued and not complete and Status ''/NIS, otherwise white | soa.dmt 36117, 36155-36165 |
| Origin ("S") text | `ActivityIdentifier`; `S` not printed on an archived card | tfmscard.js; same rule as FeederCard Fix 2 |
| Origin background | Only for an **active, not archived** card, MoveCategory Normal, Status ''/NIS: severity of the equipment's information item **1 → yellow, 2 → darkturquoise, 3 → mediumseagreen**; otherwise white | soa.dmt 36167-36190 + 35936-35962; fms.css `.Info_1/2/3` |
| Response | `Response` | — |

Severity list = `ItemCategory_ASE.LoadEquip` (cac.dmt 102282-102322): equipment on the card linked to an active information item, `ORDER BY Equip, Severity`; OpenROAD keeps the first row per equipment, i.e. the most severe (lowest number). Ported as `TfmsRowRules.FirstSeverityPerEquip`.

**Not ported, with reason:**
- Timestamp text colours (operating-order gray/red, soa.dmt 35990-36077): 180 benchmark pages contain **no coloured date text**.
- Critical-valve red equipment (soa.dmt 36100-36104): the valve list is only loaded for the SDS (steam) application (soa.dmt 29378-29430); for TOMS it is always empty.

### 2.2 Colour palette — `DosColors` (shared with TLS)

Every colour seen in the benchmark is checked by a test:

| OpenROAD code | Hex | Seen in benchmark as |
|---|---|---|
| CC_BLUE 8 | `#000080` Navy | step headings (DOS uses Navy, not the web's #0000FF) |
| CC_RED 6 / CC_GREEN 7 | `#FF0000` / `#008000` | ground moves / move text |
| CC_LIGHT_GRAY 25 | `#808080` | Type/Equipment not controlled |
| CC_PALE_BROWN 32 | `#DEB887` BurlyWood | Dunwoodie, Greenwood, E13ST bands |
| CC_PALE_ORANGE 33 | `#FFD700` Gold | Gownus Gas Turbine band |
| CC_PALE_BLUE 28 | `#87CEFA` LightSkyBlue | GOWN, ASTORIA ANNEX, EN-DE-EN bands |
| CC_PALE_RED 26 | `#FFB6C1` LightPink | East River 69 band |
| CC_PALE_PINK 31 | `#D8BFD8` Thistle | FIELD WORK band |
| severity 1 / 2 / 3 | `#FFFF00` / `#00CED1` / `#3CB371` | S cells |

Other codes use the web map (`database.js`); none of them occurs in the benchmark.

> **Do not use `Engine\Services\ColorMappingService`** for these reports. It is unused today, and its palette contradicts the benchmark (e.g. code 33 = (255,224,192) instead of Gold, code 32 = (224,192,128) instead of BurlyWood). Wiring it in later would silently change the colours.

### 2.3 Header — `CardTFMS.LoadCard` + `CardSOA.LoadCard` (cac.dmt 8950 / 8626)

| Box | Active card | Archived card |
|---|---|---|
| Card · Class · Feeders | `TFMS_Card.Card`, `SOA_Card.CardClassName`, `TFMS_Card.FeederNames` | `TFMS_ArchiveCard` |
| Cut Out / Cut In | `SOA_Card.CutOut` / `CutIn`, `MM/dd/yy HH:mm` | `TFMS_ArchiveCard` |
| Description | `TFMS_Card.Description` | same |
| Note | `SOA_Card.Note` | — (OpenROAD loads no note for archive) |
| Card Closed | only when Closed has a date (tfmscard.js) | |

`SOA_Card` is read in a **separate** query (as OpenROAD does), so a missing `SOA_Card` row blanks those boxes instead of losing the whole header. `Status` now loads, which also drives the severity rule.

### 2.4 Permits and Protections — `WorkPermit_ASE.LoadSOA_WP` (cac.dmt 247825)

- Work Permits: `SOA_JobControl.StepPair = 600`, then Test Permits: `StepPair = 650`; each `ORDER BY Seq`; `Status IN ('', 'NIS', 'tbl')`; `MoveCategory = 0`; inner join `Udb_Object` on Substation. Archive: `SOA_ArchiveJob`, `Status = ''`.
- Protections of each permit: `FMS_WorkPermitProtection` (archive `FMS_ArchiveWPProtection`), `PermitCardType = 0`, by Seq, through the `LoadProtectionMove` cascade. That cascade is already ported, card-type independent, in `FMSCardRepository.LoadProtections` — **reused, not copied**.
- Printed as one group per permit: `Work Permit`/`Test Permit` · Issued · ID · Type · Equipment · Move · Complete, then `Protections:` with system · Card · Issued · Complete · Station · ID · type · Equipment · Move · Issued · Complete, or "No protection moves for this permit". Title "Permits and Protections for *FeederNames*" on every page.
- Technique: C# flattens permits + protections into `TomsPermitRow` rows; the template groups on `PermitKey`. This avoids nested SubReport data binding, which I could not test without Telerik.

### 2.5 Card log

Same query as before (it was right). New layout: "TFMS Card Log for *FeederNames*", Date `MM/dd/yy HH:mm` · Status · Log Entry, landscape, newest first.

### 2.6 Layout — `TFMSCard.trdx` (FeederCard1 format)

- Letter landscape, margins 0.15/0.15/0.5/0.5, width 10.7in; page header (pages 2+) = Card · Class · Feeders; column header on every page; footer print time + "Page *n* of *N*"; `PageNumberingStyle="ResetNumberingAndCount"`.
- Grid **identical to FeederCard1** (and to the toms-dos.pdf grid): Op 0.35 · Issued 0.75 · Complete 0.75 · ID 0.35 · Type 0.85 · Equipment 0.80 · G 0.25 · Move 3.45 · origin 0.25 · Response 1.10 · Op 0.35 · Issued 0.72 · Complete 0.72. Row 0.27in, Arial 8. All cells `Anchoring="Top, Bottom"` so a wrapped Move/Type/Equipment/Response grows the whole row.
- Two Move boxes at the same place (normal / bold), switched by `Visible` — no Telerik font-binding needed.
- **Every cell in all three TOMS templates has `CanGrow="True"`**, and every row cell (card grid, permit line, protection lines, log lines) has `Anchoring="Top, Bottom"`, so a multi-line value grows the whole row and the bottom borders stay aligned. Enforced by tests.
- Work permit fonts: title 10pt bold; permit headers and values 8pt (same as the card grid); protection lines 7–7.5pt. A test fails if any permit font goes above 8pt (title above 10pt).

## 3. Steps

Apply in this order (full replacement files in `Fixed\Code\`).

> **Replace whole files, do not copy methods.** Every file in `Fixed\Code\` is the complete file: your original plus the change. Copy it over the file with the same path in `Telerik-proj` (or add it, if it's new). This is only safe if your `Telerik-proj` file is still the same as the copy in `issues2\Issues_2\Telerik-proj` (snapshot of 2026-09-30). If someone has edited one of these files since, merge that file by hand instead.

| # | File | Change |
|---|---|---|
| 1 | `Models\Jobs\TfmsJob.cs` | + 21 display properties (`IsHeading`, date texts/backgrounds, `TypeText`, `EquipText`, `EquipFg`, `GText`, `GFg`, `MoveText`, `MoveFg`, `MoveBg`, `MoveBold`, `OriginText`, `OriginBg`, `ResponseText`). Existing ones unchanged (TFMS Excel unaffected) |
| 2 | `Models\Cards\TfmsCardModels.cs` | `TfmsCardHeader`: + `CardClassName`, `CutOut`, `CutIn`, `Note` |
| 3 | **New** `Models\Cards\TomsPermitRow.cs` | Flattened permit/protection row + `Build()` |
| 4 | **New** `Models\Jobs\Colors\DosColors.cs` | Palette (shared with TLS) |
| 5 | **New** `Models\Jobs\Colors\TfmsRowRules.cs` | Rules of 2.1 + `InfoItemEquipSeverity` + `FirstSeverityPerEquip` |
| 6 | `Models\FMS_PDFReportService.Models.csproj` | + `<Compile Include>` for `DosColors.cs`, `TlsRowRules.cs`, `TfmsRowRules.cs`, `TomsPermitRow.cs` |
| 7 | `Data\Queries\TFMSQueries.cs` | + `LoadSoaCard`, `LoadSoaCardArchive`, `LoadInfoItemEquipSeverity`, `LoadPermits`, `LoadPermitsArchive`. Old `LoadWorkPermits` kept, marked obsolete |
| 8 | `Data\Repositories\ITFMSCardRepository.cs` | + `LoadPermitsWithProtections`, `LoadInfoItemEquipSeverity` |
| 9 | `Data\Repositories\TFMSCardRepository.cs` | Header merges `SOA_Card`; new methods above |
| 10 | `Engine\Groupers\ReportGroupers.cs` | `TFMSGrouper.ComposeCard` (see below) |
| 11 | `Engine\Templates\TFMS\` | Replace `TFMSCard.trdx`, `TOMSWorkPermit.trdx`, `TFMSCardLog.trdx` with the delivered files |

`TFMSCardHeader.trdx` is no longer used by the grouper (file left as is). No DI / constructor change: `TFMSCardRepository` creates an `FMSCardRepository` from its own connection factory for the protections.

Abridged (copy the delivered file, not this snippet — inside `Engine.Groupers`, `Constants` must be written `FMS_PDFReportService.Models.Constants`):

```csharp
var archived = request.ArchiveFlag == 1;
var header = _repo.LoadCardHeader(cardId, request.ArchiveFlag);
var jobs = _repo.LoadJobs(cardId, request.ArchiveFlag).ToList();
var severity = (!archived && header != null && header.Status == Constants.Card_Active)
    ? _repo.LoadInfoItemEquipSeverity(cardId) : new Dictionary<int, int?>();
TfmsRowRules.Apply(jobs, cardId, archived, severity);
sources.Add(... "TFMS/TFMSCard.trdx", jobs, BuildHeaderParameters(header));
if (request.ReportType == 1)
{
    ... "TFMS/TFMSCardLog.trdx", log, { FeederNames }
    ... "TFMS/TOMSWorkPermit.trdx", TomsPermitRow.Build(_repo.LoadPermitsWithProtections(...)), { FeederNames }
}
```

Deploy the C# and the three templates **together**.

## 4. Tests run (three passes)

| Pass | What | Result |
|---|---|---|
| Baseline | Untouched code compiled first | 0 errors |
| 1 — build + template integrity | `Models`/`Data`/groupers compile; every `Fields.X` exists on `TfmsJob` / `TomsPermitRow` / `SoaCardLogEntry`; parameters declared ⇔ sent ⇔ used; **TFMS grid edges equal FeederCard1's**; header boxes align with columns; Op/ID blank; page settings as FeederCard1 | pass |
| 2 — rules | 20 rows rebuilt from benchmark pp. 172-176 (+ p1/p13/p158 colours): every band colour, navy/red headings, gray equipment (controlled vs not), S severity 1/2/3 incl. turquoise without "S", gray dates (Record/Reset, work permit, Hi-Pot), red ground vs **black G=3 Hi-Pot**, green move; ground needs NIS/'' and wins over MoveFGColor; shadow-link green; test letter; archived card (S hidden, no severity); inactive card (no severity lookup); unknown colour codes; nulls; permit flattening (empty permit, order, Work/Test label, blank dates); grouper source order for report type 0/1, null header; SQL parameter count/order and constants (`StepPair = 3` gone) | pass |
| 3 — visual | Emulator draws the delivered templates with the C# rows: `Evidence\TOMS_simulated_card_372937.png` vs `TOMS_benchmark_p172.png`, `TOMS_simulated_permits_372937.png` vs `TOMS_benchmark_p178.png`. Colour inventory of the simulated card reproduces **every colour class** of the 180-page benchmark (text: navy-bold, green, gray Type/Equip, red G, red, red-bold; fills: 5 band colours, 3 S colours, gray dates) | match |
| Guardrail | 11 deliberate faults (incl. `StepPair = 3` back, naive ground rule back, ColorMappingService Gold, control-card rule inverted, dropped empty permit, parameter not sent) | **11/11 caught** |

## 5. What I could NOT verify — be aware

1. **No Telerik runtime here**: templates were validated by script and an emulator, not rendered by Telerik. Render once before release (features used are the ones already working in your templates).
2. **No database**: new SQL checked against OpenROAD and statically, not executed.
3. The emulator doesn't grow rows, so wrapped text overlaps in the PNGs; Telerik grows them (`CanGrow` + anchoring).

## 6. Open items for the SME

1. **Switching item filter on permits.** OpenROAD filters `JC.SwitchingItem = :SwitchingItem`; the value the TFMS card print passes isn't in the provided source, so the filter is **not** applied (a wrong filter would hide permits). For 372937 this gives exactly the benchmark's 9 permits. Confirm for cards with switching items. The card log query has the same difference (pre-existing).
2. **Protection de-duplication**: reused from FMS (`FMSCardRepository.LoadProtections`, "D6" grouping on equipment + TO times). Benchmark 372937 shows no case where it matters; confirm it is wanted for TOMS too.
3. **Ground rule `GroundOn IS NOT NULL`** is OpenROAD's test, so an empty date (`''`) also counts as "ground on". The web screen doesn't count it.
4. **Green for switching items with a shadow link** comes from the web screen only (not SOA_Main).
5. **"S" hidden on archived cards** follows the web screen and FeederCard Fix 2; no archived TOMS benchmark to confirm.
6. **Permit ID** prints `PrintID` (blank in the benchmark).
7. Bands are drawn only for colour codes stored in `SOA_Job.MoveBGColor`. If some substation heading has 0 there, it prints without a band — that is also what OpenROAD would show.

8. **Two versions of the ground rule in OpenROAD.** Full card load `SOA_Main 'MoveColors'` (soa.dmt 36146): red only if Status is '' or NIS. Single-row refresh `ON DBEVENT 'SOA_ReloadJob'` (soa.dmt 37581): no status check. The report uses the full-load version (a printed card = a full load). The DOS report program itself is not in the provided sources, so which one it follows can only be confirmed by printing a card that has a grounded move with a status other than ''/NIS.
9. **Where the rules come from.** The DOS report program (the one PrintReport.ps1 calls) is not in the provided files. Rules are taken from the OpenROAD and web screens that draw the same job list, and checked against the colours measured in toms-dos.pdf. Rules with no example in the benchmark (test letter gold, shadow-link green, S hidden on archived cards) are therefore not confirmed for the DOS report.

## 7. How to test with real data (UAT)

1. Print **372937** with report type 1 and compare with `toms-dos.pdf` pages 172-180:
   - header box 372937 · Auto · 99153, Cut Out 06/27/26 20:59;
   - every row as in the benchmark: bands, gray `Bkr 2S`, yellow S on `6W6`, turquoise S on `F3S`, gray Record/Reset restore cells, gray work-permit cells, Hi-Pot G=3 black;
   - no `12/31 23:59`, Op and ID blank;
   - log page "TFMS Card Log for 99153" with 3 entries;
   - "Permits and Protections for 99153": 8 Work Permits then 1 Test Permit; e.g. "Make the ISP Normal" with protections F7W and F3S; the Test Permit with 6 protections.
2. Print **369707** (benchmark pp. 1-157) and **370851** (pp. 158-171): Gold / LightPink / LightSkyBlue bands, red ground moves on p7 and p13, green moves on p4.
3. Print one archived card (ARCH=1): no S, no severity colours, nothing gray in Type/Equipment.
4. `PROJ=<Telerik-proj> bash Fixed/Tests/runtests.sh` → `PASSED 940 FAILED 0`.
