# Gateway-to-QrDiode: system architecture

**Current as of 25 Nov 2026.** This is the single system architecture for developers and managers.
It distinguishes what exists today from the connections still to be built.

> **Not ready for real islanding:** the gateways and optical apps exist, but the QR apps do not yet read the
> gateway Outbox or write its Inbox. A complete request and reply has not been demonstrated over the real light link.

## 1. Purpose

When CorpNet and the FMS DMZ are isolated, existing applications must still communicate without a network path
across the gap. A screen and camera form a **one-way optical lane** in each direction:

| Lane | Direction | Screen | Camera |
|---|---|---|---|
| Inbound | Corp → DMZ | Corp | DMZ |
| Outbound | DMZ → Corp | DMZ | Corp |

Corporate callers do not change: in islanding, their load balancer is redirected to the Corp gateway. The DMZ
outbound clients are redirected to the DMZ gateway by configuration. Normal network paths are restored when
islanding ends. ECC/AECC failover behaviour is still an open decision.

## 2. What runs on each side

| Component | Responsibility | Current status |
|---|---|---|
| SOAP Gateway | IIS app: accepts a caller's request, queues it, and delivers messages arriving from the other side to configured real services. | Built and tested between in-memory gateways using a fake light. |
| `qrbridge.db`, table Outbox | Local SQLite queue of Requests, Replies, Receipts and Heartbeats waiting to go to the other side. | Gateway writes and maintains it; the QR Sender is **not connected**. |
| QrDiode Sender | WPF app: encrypts and signs a transfer and shows QR frames on the screen. | Optical application built; currently uses a simulator or file, not the gateway Outbox. |
| QrDiode Receiver | WPF app: reads QR frames, verifies and decrypts a transfer, then stores it locally. | Optical application built; it does **not** write the gateway Inbox. |
| `qrbridge.db`, table Inbox | Local SQLite queue of messages received from the other side, for the gateway to process. | Gateway reads it; the QR Receiver is **not connected**. |

Each side has a Gateway, a Sender and a Receiver: **three separate processes**, not one combined QR app.
The intended local integration uses **one database per machine, `qrbridge.db`** (Outbox and Inbox are tables in it;
until 25 Nov 2026 they were two files, `send.db` and `received.db`) and named Windows events as doorbells, with
polling as a fallback. All three processes write to that one file, so they share its single write lock (short
transactions, `busy_timeout` 5 s; not yet measured with the QR apps). `QrBridge.Shared` owns the shared schema;
`QrDiode.Core` stays independent of the SOAP gateway and SQLite.

## 3. Round trips at a glance

These are **target workflows**, not completed optical workflows. Solid lines show the intended flow; dashed
connections are the missing QR-app-to-database integration. Each optical lane carries messages in only one
direction; a Reply uses the other lane. These examples apply to routes configured as `RoundTrip`.

### Inbound: Corp caller → DMZ service → Corp caller

```mermaid
flowchart TB
    A["Corp caller"] --> B["Corporate load balancer"]
    B --> C["Corp Gateway: hold caller"]
    C --> D[("Corp Outbox: Request")]
    D -.->|planned: read| E["Corp QR Sender: screen"]
    E ==>|inbound light| F["DMZ QR Receiver: camera"]
    F -.->|planned: write| G[("DMZ Inbox: Request")]
    G --> H["DMZ Gateway: call real service"]
    H --> I["DMZ service: answer"]
    I --> J[("DMZ Outbox: correlated Reply")]
    J -.->|planned: read| K["DMZ QR Sender: screen"]
    K ==>|outbound light| L["Corp QR Receiver: camera"]
    L -.->|planned: write| M[("Corp Inbox: Reply")]
    M --> N["Corp Gateway: match Reply to Request"]
    N --> O["Return the answer to the waiting Corp caller"]
```

### Outbound: DMZ caller → Corp service → DMZ caller

```mermaid
flowchart TB
    A["DMZ caller"] --> B["DMZ Gateway: hold caller"]
    B --> C[("DMZ Outbox: Request")]
    C -.->|planned: read| D["DMZ QR Sender: screen"]
    D ==>|outbound light| E["Corp QR Receiver: camera"]
    E -.->|planned: write| F[("Corp Inbox: Request")]
    F --> G["Corp Gateway: call real service"]
    G --> H["Corp service: answer"]
    H --> I[("Corp Outbox: correlated Reply")]
    I -.->|planned: read| J["Corp QR Sender: screen"]
    J ==>|inbound light| K["DMZ QR Receiver: camera"]
    K -.->|planned: write| L[("DMZ Inbox: Reply")]
    L --> M["DMZ Gateway: match Reply to Request"]
    M --> N["Return the answer to the waiting DMZ caller"]
```

If Request **A** produces Reply **B**, B has its own message ID and `CorrelationId = A`. The originating
gateway validates the Reply and updates A's existing Outbox row; it does not create another request for the
caller. The held HTTP connection receives the stored answer. If the answer does not arrive before the hold
expires, the configured timeout response is returned instead. A 1596 response means confirmation is still
pending; it is **not** proof that the real service completed the request.

## 4. Message handling and safety

- **Caller compatibility:** paths, actions, SOAP versions and response shapes must match the existing services.
  The gateway is generic and configuration-driven; it does not use a class per service.
- **Commit before reply:** forwarded calls enter through `OutboxWriter` and the Outbox commit completes before
  the gateway answers or waits for a reply. The original request bytes are preserved.
- **Route behaviours:** feeds configured as `Bridge` receive a local response after queuing; `RoundTrip`
  callers wait for a real answer or their configured timeout response. Some routes are deliberately
  `Unavailable`. Consult [routes.json](../../sourcecode/gateway/src/QrBridge.Gateway/routes.json) for each operation.
- **Receipts and retries:** the gateway can queue and process Receipts and Replies and re-air unconfirmed
  messages. Actual optical carriage of these messages remains unfinished.
- **Security:** QrDiode signs and encrypts the optical session. Gateway message bytes in SQLite are compressed
  and checksummed, **not encrypted at rest**; the checksum alone is not authentication. Restrict folder access
  and use disk encryption. Untrusted XML is handled with safe parser settings.
- **Destinations and audit:** service URLs come from configuration, never a message. Both gateways require
  matching route catalogues. Message rows are not deleted automatically.

## 5. Status, risks and next steps

| Item | Status / next action |
|---|---|
| Gateway request/reply | Built and tested with fake light. Last recorded full test run: 451 Gateway and 75 QrDiode tests passed on 25 Nov 2026 (after the single-database change); this is not a real optical deployment test. |
| Receiver session handling | Fix the partial-session lock before connecting the queues. |
| Queue integration | Add Sender Outbox and Receiver Inbox integration; prevent Sender queue drops and commit anti-replay state only after durable storage. |
| Bundling and ordering | Not approved or implemented. Confirm rules and size limits before implementation, including messages larger than a proposed bundle. |
| Deployment and service coverage | Corp receiver targets are empty, DMZ target is a placeholder, and some service contracts and paths need confirmation. XA/21, BFC and other interfaces need scope decisions. |
| Go-live | Security sign-off, real service and two-lane screen/camera tests, timeout and load validation, failover and islanding drills are still needed. |

## 6. Where to go next

| Need | Document |
|---|---|
| Remaining implementation work and proposed sequence | [Integration plan](integration-plan.md) |
| Detailed developer request/reply steps and queue handling | [Gateway workflow reference](../../sourcecode/gateway/docs/workflows/gateway-qrdiode-workflow.md) |
| Configuration, security and manual deployment | [Technical guide](technical-guide.md) |
| Blocked or unconfirmed services | [Unimplemented work and service coverage](../../sourcecode/gateway/docs/reference/uncovered-services.md) |
| Current decisions, open questions and verification history | [Handoff](../handoff.md) |
| QrDiode operation and WPF concepts | [User guide](../../sourcecode/qrdiode/docs/user-guide.md) · [WPF tutorial](../../sourcecode/qrdiode/docs/wpf-tutorial.md) |
