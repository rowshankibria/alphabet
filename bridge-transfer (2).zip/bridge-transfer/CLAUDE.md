# CLAUDE.md

The agent instructions for this solution are in **[.github/copilot-instructions.md](.github/copilot-instructions.md)**.
That file is the single source of truth for GitHub Copilot (the assistant on the project machine) and for Claude Code.
Next to it:
- path-specific rules in `.github/instructions/`;
- reusable task prompts in `.github/prompts/`;
- custom agents in `.github/agents/`.

Then read:
- [docs/handoff.md](docs/handoff.md): state, decisions, known issues, next steps;
- [docs/gateway-to-qrdiode/integration-plan.md](docs/gateway-to-qrdiode/integration-plan.md): the design of the remaining work.

@.github/copilot-instructions.md
