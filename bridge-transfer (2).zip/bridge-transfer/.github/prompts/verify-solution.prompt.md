---
description: 'Build and test both solutions and explain any failure in plain English'
agent: 'agent'
---

Check that the solution is healthy on this machine and report back.

1. In a terminal at the solution root, run `dotnet --list-sdks` (a 10.0.x SDK must be listed), then
   `dotnet test All.slnx`. Expected: build without errors, `QrBridge.Tests` 451 passed, `QrDiode.Core.Tests` 75 passed (25 Nov 2026). Later steps of the
   [Integration Plan](../../docs/gateway-to-qrdiode/integration-plan.md) add tests; [HANDOFF §5](../../docs/handoff.md) has the
   current counts.
2. If something fails, find the cause before touching code. Check the known environment traps first
   ([HANDOFF §7](../../docs/handoff.md)):

   | Symptom | Cause | Fix |
   |---|---|---|
   | `DllNotFoundException` for ZXing, "filename or extension is too long" (0x800700CE) | the folder path is too deep | move the solution to a short path such as `C:\src\QrDiode_V2` (or map one with `subst`) |
   | `BG1002` / `CS2001` (missing `.baml` / `.g.cs`) right after a `dotnet publish -r win-x64` | WPF incremental-build quirk | build again |
   | SDK error that mentions `global.json` | no .NET 10 SDK installed | install the .NET 10 SDK; don't change `global.json` |

3. Change code only for a real bug: keep the fix minimal, add a test that fails without it, and run step 1 again.
4. Report in plain English: a table (step · result · counts), what you changed and why, and anything still failing
   with the exact error lines. Don't commit.
