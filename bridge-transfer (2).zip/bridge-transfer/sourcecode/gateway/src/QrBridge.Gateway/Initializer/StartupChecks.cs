using Microsoft.Extensions.Options;
using QrBridge.Gateway.Ingress.Validation;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data;

namespace QrBridge.Gateway.Initializer;

/// <summary>
/// Runs once after Build, before the gateway accepts calls: fail loudly instead of accepting messages nobody can
/// deliver, then create or open the database (refused while a former send.db or received.db is in the data folder).
/// </summary>
public static class StartupChecks
{
    public static async Task<WebApplication> RunStartupChecksAsync(this WebApplication app)
    {
        var log = app.Services.GetRequiredService<ILoggerFactory>().CreateLogger("QrBridge.Gateway");
        var bridgeOptions = app.Services.GetRequiredService<IOptions<BridgeOptions>>().Value;
        var gatewayOptions = app.Services.GetRequiredService<IOptions<GatewayOptions>>().Value;

        int longestReceiverSeconds = gatewayOptions.Receiver.Targets.Values
            .Select(t => t.TimeoutSeconds ?? gatewayOptions.Receiver.TimeoutSeconds)
            .DefaultIfEmpty(gatewayOptions.Receiver.TimeoutSeconds)
            .Max();
        if (gatewayOptions.LockTimeoutMinutes * 60 <= Math.Max(longestReceiverSeconds, gatewayOptions.Receiver.TimeoutSeconds) + 30)
            throw new InvalidOperationException(
                "Gateway:LockTimeoutMinutes must be longer than every Receiver delivery timeout (plus 30 s), " +
                "or a slow delivery still running would be marked Unknown.");

        int shortestReceiverSeconds = gatewayOptions.Receiver.Targets.Values
            .Select(t => t.TimeoutSeconds ?? gatewayOptions.Receiver.TimeoutSeconds)
            .Append(gatewayOptions.Receiver.TimeoutSeconds)
            .Min();
        if (gatewayOptions.Receiver.ConnectTimeoutSeconds <= 0 || gatewayOptions.Receiver.ConnectTimeoutSeconds >= shortestReceiverSeconds)
            throw new InvalidOperationException(
                $"Gateway:Receiver:ConnectTimeoutSeconds ({gatewayOptions.Receiver.ConnectTimeoutSeconds}) must be positive and shorter than " +
                $"every Receiver delivery timeout (shortest: {shortestReceiverSeconds} s), or a call that was never sent could not be " +
                "told apart from one that was sent and may have been processed.");

        if (gatewayOptions.ReplayWindowDays <= 0 || gatewayOptions.MaxClockSkewMinutes <= 0)
            throw new InvalidOperationException(
                "Gateway:ReplayWindowDays and Gateway:MaxClockSkewMinutes must be positive, " +
                "or good messages are rejected as replays or as dated in the future (clocks are never exactly equal).");
        if (gatewayOptions.GapGraceMinutes < 0)
            throw new InvalidOperationException("Gateway:GapGraceMinutes must be 0 or more.");
        if (gatewayOptions.RetryWindowMinutes <= 0)
            throw new InvalidOperationException(
                "Gateway:RetryWindowMinutes must be positive, or a caller's retry is never recognised and is delivered twice.");
        if (gatewayOptions.ReceiptTimeoutSeconds <= 0 || gatewayOptions.MaxAirAttempts <= 0)
            throw new InvalidOperationException(
                "Gateway:ReceiptTimeoutSeconds and Gateway:MaxAirAttempts must be positive, or a message is aired again " +
                "before its Receipt could come back, or never aired at all.");
        if (gatewayOptions.HeartbeatMinutes < 0)
            throw new InvalidOperationException("Gateway:HeartbeatMinutes must be 0 (off) or more.");
        if (gatewayOptions.FarSideSilentMinutes <= 0 || gatewayOptions.FarSideSilentMinutes <= gatewayOptions.HeartbeatMinutes)
            throw new InvalidOperationException(
                $"Gateway:FarSideSilentMinutes ({gatewayOptions.FarSideSilentMinutes}) must be positive and longer than " +
                $"Gateway:HeartbeatMinutes ({gatewayOptions.HeartbeatMinutes}), or an idle but healthy far side would look down.");

        // D4 (G-06): a warning, not a refusal: the gateway should run as its own app pool identity (guide §12.4).
        if (AdministratorWarning(Environment.IsPrivilegedProcess, Environment.UserName) is { } adminWarning)
            log.LogWarning("{Warning}", adminWarning);

        CheckReceiverUrls(gatewayOptions.Receiver, allowHttp: gatewayOptions.Receiver.AllowHttp || app.Environment.IsDevelopment());

        var routes = app.Services.GetRequiredService<RouteTable>(); // validates the catalogue
        CheckHold(gatewayOptions.Hold, routes, bridgeOptions.Side);
        CheckExpiry(gatewayOptions.Expiry, gatewayOptions.Hold, routes, bridgeOptions.Side);
        var light = gatewayOptions.Light;
        if (light.BytesPerSecond <= 0 || light.MinAirSeconds < 0 || light.GapSeconds < 0)
            throw new InvalidOperationException("Gateway:Light:BytesPerSecond must be positive, MinAirSeconds and GapSeconds 0 or more.");
        foreach (string warning in AirTimeWarnings(routes, bridgeOptions, gatewayOptions))
            log.LogWarning("{Warning}", warning);
        var contracts = app.Services.GetRequiredService<ContractCatalog>(); // loads the WSDLs and checks them against the catalogue
        foreach (var service in routes.Services.Where(s => s.SenderSide == bridgeOptions.Side && contracts.For(s) is null))
            log.LogWarning("{Service} has no WSDL contract: its requests are not checked against a WSDL", service.Name);

        await DatabaseInitializer.InitializeAsync(app.Services, log);

        log.LogInformation("QrBridge Gateway starting. Side={Side} Data={Data} Services={Services} Contracts={Contracts} AcceptUnlisted={Unlisted} Catalogue={Catalogue}",
            bridgeOptions.Side, bridgeOptions.DataFolder,
            routes.Services.Count(s => s.SenderSide == bridgeOptions.Side), contracts.Count, routes.Options.AcceptUnlisted,
            routes.CatalogFingerprint);
        return app;
    }

    /// <summary>
    /// D4 (G-06): the gateway holds every message in clear (decision 23) and calls the real services; running it as an
    /// administrator gives a bug or an attacker in it the whole machine. It should run as a dedicated app pool identity
    /// with only the data-folder ACL and the network access it needs (guide §12.4). Null when not elevated.
    /// </summary>
    public static string? AdministratorWarning(bool elevated, string account) => elevated
        ? $"The gateway is running as an administrator ({account}). Run it as its own app pool identity with only the " +
          "data-folder ACL and the network access it needs (technical-guide.md §12.4, G-06)."
        : null;

    /// <summary>
    /// D79 (G-10): a held caller whose request may be so large that airing it alone takes longer than its hold would get
    /// the hold-timeout answer even on an idle link. One line per RoundTrip route on this side where the route's size
    /// limit (MaxRequestBytes, else Bridge:MaxPayloadBytes) takes longer to air than its hold. A warning, not a refusal:
    /// real requests are usually far smaller, and Brotli shrinks XML.
    /// </summary>
    public static IEnumerable<string> AirTimeWarnings(RouteTable routes, BridgeOptions bridge, GatewayOptions gateway)
    {
        foreach (var service in routes.Services.Where(s => s.SenderSide == bridge.Side && !s.HttpGet).OrderBy(s => s.Name))
        {
            bool roundTrip = service.Operations.Values.Any(o =>
                o.Mode == OperationMode.RoundTrip || o.Types.Values.Any(t => t.Mode == OperationMode.RoundTrip));
            if (!roundTrip) continue;

            int limit = Math.Min(service.MaxRequestBytes ?? bridge.MaxPayloadBytes, bridge.MaxPayloadBytes);
            double air = gateway.Light.AirSecondsFor(limit);
            int hold = gateway.Hold.SecondsFor(service.Name);
            if (air > hold)
                yield return $"{service.Name}: a request at its size limit ({limit:N0} bytes) takes about {air:N0} s to air, " +
                             $"longer than its {hold} s hold, so its caller would get the hold-timeout answer. " +
                             "Set MaxRequestBytes in routes.json once real sizes are known (G-10).";
        }
    }

    /// <summary>
    /// A hold of 0 or less would answer every RoundTrip caller at once with the hold-timeout answer; an override for a
    /// service this gateway never takes calls for is a typo that would leave the intended service on the default.
    /// </summary>
    private static void CheckHold(HoldOptions hold, RouteTable routes, BridgeSide side)
    {
        if (hold.DefaultSeconds <= 0)
            throw new InvalidOperationException("Gateway:Hold:DefaultSeconds must be positive.");
        foreach (var (name, seconds) in hold.Services)
        {
            string setting = $"Gateway:Hold:Services:{name}";
            if (seconds <= 0)
                throw new InvalidOperationException($"{setting} must be positive.");
            var service = routes.FindByName(name)
                ?? throw new InvalidOperationException($"{setting}: there is no service '{name}' in routes.json.");
            if (service.SenderSide != side)
                throw new InvalidOperationException(
                    $"{setting}: the callers of {name} are on the {service.SenderSide} side, so this {side} gateway never holds them.");
        }
    }

    /// <summary>
    /// D62: an expiry of 0 or less would make every state-changing call undeliverable; one not longer than the hold could
    /// expire a call while its caller is still told "sent, confirmation not yet received"; an override for a service this
    /// gateway never takes calls for is a typo.
    /// </summary>
    private static void CheckExpiry(ExpiryOptions expiry, HoldOptions hold, RouteTable routes, BridgeSide side)
    {
        if (expiry.DefaultSeconds <= 0)
            throw new InvalidOperationException("Gateway:Expiry:DefaultSeconds must be positive.");
        foreach (var (name, seconds) in expiry.Services)
        {
            string setting = $"Gateway:Expiry:Services:{name}";
            if (seconds <= 0)
                throw new InvalidOperationException($"{setting} must be positive.");
            var service = routes.FindByName(name)
                ?? throw new InvalidOperationException($"{setting}: there is no service '{name}' in routes.json.");
            if (service.SenderSide != side)
                throw new InvalidOperationException(
                    $"{setting}: the callers of {name} are on the {service.SenderSide} side, so this {side} gateway never sends them.");
        }
        foreach (var service in routes.Services.Where(s => s.SenderSide == side))
        {
            int expires = expiry.SecondsFor(service.Name), held = hold.SecondsFor(service.Name);
            if (expires <= held)
                throw new InvalidOperationException(
                    $"{(expiry.Services.ContainsKey(service.Name) ? $"Gateway:Expiry:Services:{service.Name}" : "Gateway:Expiry:DefaultSeconds")} " +
                    $"({expires} s) must be longer than the hold of {service.Name} ({held} s): a call could expire while its caller is still held.");
        }
    }

    /// <summary>
    /// Every configured target must be an absolute https:// URL (http:// only on a test bench), so a permit or an
    /// order never leaves the gateway unencrypted, and a typo fails the start instead of every delivery.
    /// </summary>
    private static void CheckReceiverUrls(ReceiverOptions receiver, bool allowHttp)
    {
        var urls = receiver.Targets.Select(t => ($"Gateway:Receiver:Targets:{t.Key}:Url", t.Value.Url))
            .Prepend(("Gateway:Receiver:DefaultBaseUrl", receiver.DefaultBaseUrl ?? ""))
            .Where(u => !string.IsNullOrWhiteSpace(u.Item2));

        foreach (var (setting, url) in urls)
        {
            if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || (uri.Scheme != Uri.UriSchemeHttps && uri.Scheme != Uri.UriSchemeHttp))
                throw new InvalidOperationException($"{setting} '{url}' is not an absolute http(s) URL.");
            if (uri.Scheme == Uri.UriSchemeHttp && !allowHttp)
                throw new InvalidOperationException(
                    $"{setting} '{url}' is plain http://: requests would cross the network unencrypted. Use https://, " +
                    "or set Gateway:Receiver:AllowHttp = true on a test bench.");
        }
    }
}
