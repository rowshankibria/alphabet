namespace QrBridge.Gateway;

public enum SoapVersion { Soap11, Soap12 }

/// <summary>What the gateway does with a call to an operation.</summary>
public enum OperationMode
{
    /// <summary>Store it, reply OK at once, deliver it to the real service on the other side ("queued").</summary>
    Bridge,
    /// <summary>
    /// Send it across, hold the caller and give it the real service's answer when it comes back over the opposite
    /// lane; when the hold runs out, answer per <see cref="HoldTimeoutAnswer"/> (fix plan §4.1, §4.5, decision D50).
    /// </summary>
    RoundTrip,
    /// <summary>Answer locally with the request value (EchoString connectivity checks). Nothing is stored.</summary>
    Echo,
    /// <summary>The caller needs real data back, which cannot cross the air gap: reply "not available".</summary>
    Unavailable,
    /// <summary>Refuse with a SOAP fault.</summary>
    Reject,
}

/// <summary>What a held <see cref="OperationMode.RoundTrip"/> caller gets when the real answer does not come back in time.</summary>
public enum HoldTimeoutAnswer
{
    /// <summary>
    /// The reply profile's Pending value (RETURN_CODE 1596, "sent over the QR bridge, confirmation not yet received",
    /// decision D8): state-changing calls, and calls we cannot classify.
    /// </summary>
    Pending,
    /// <summary>The reply profile's Unavailable value, or a SOAP fault when it has none: read-only queries (D13).</summary>
    Unavailable,
}

/// <summary>How the SOAP body of an operation is shaped (decides the reply's result element).</summary>
public enum MessageStyle
{
    /// <summary>Document/literal wrapped (WCF, ASMX): reply &lt;OpResponse xmlns="ns"&gt;&lt;OpResult&gt;.</summary>
    Document,
    /// <summary>RPC/encoded (SOAP Toolkit, *.WSDL endpoints): reply &lt;m:OpResponse&gt;&lt;Result&gt; (unqualified).</summary>
    Rpc,
}

/// <summary>How to read the real service's reply when the message is delivered.</summary>
public enum ResultKind
{
    /// <summary>Any 2xx reply that is not a SOAP fault counts as delivered.</summary>
    None,
    /// <summary>The result is an FMS &lt;RESPONSE&gt; document: RETURN_CODE 0 = accepted, anything else = refused.</summary>
    FmsResponse,
    /// <summary>The result is a number: 0 = accepted, anything else = refused.</summary>
    ReturnCode,
}

public enum DeliveryVerdict
{
    /// <summary>The real service accepted it.</summary>
    Delivered,
    /// <summary>The real service answered and refused it (RETURN_CODE / return code not 0). Not retried.</summary>
    Refused,
    /// <summary>SOAP fault, or an HTTP answer that means "not processed" (4xx except 408/429, 3xx, 501, 505). Not retried.</summary>
    Permanent,
    /// <summary>
    /// It may have been processed (decision D9): timeout after sending, reset, HTTP 500/502/503/504 or another odd answer,
    /// a 2xx whose result can't be read. Never retried: an operator checks first.
    /// </summary>
    Unknown,
    /// <summary>Surely not sent (DNS, connection refused, connect timeout, TLS failure, HTTP 408/429): retried with backoff.</summary>
    Transient,
}
