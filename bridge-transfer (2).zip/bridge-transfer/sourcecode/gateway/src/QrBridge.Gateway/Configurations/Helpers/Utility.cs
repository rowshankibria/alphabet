using System.Xml;

namespace QrBridge.Gateway;

public static class SoapNamespaces
{
    public const string Soap11 = "http://schemas.xmlsoap.org/soap/envelope/";
    public const string Soap12 = "http://www.w3.org/2003/05/soap-envelope";
    public const string SoapEncoding = "http://schemas.xmlsoap.org/soap/encoding/";
    /// <summary>WS-Addressing 1.0 (WCF WSHttpBinding, Soap12WSAddressing10).</summary>
    public const string Addressing10 = "http://www.w3.org/2005/08/addressing";
    /// <summary>WS-Addressing August 2004 (older WCF/WSE stacks).</summary>
    public const string Addressing200408 = "http://schemas.xmlsoap.org/ws/2004/08/addressing";

    public static string Envelope(SoapVersion version) => version == SoapVersion.Soap12 ? Soap12 : Soap11;

    public static string ContentType(SoapVersion version) =>
        version == SoapVersion.Soap12 ? "application/soap+xml; charset=utf-8" : "text/xml; charset=utf-8";

    public static bool IsAddressing(string ns) => ns is Addressing10 or Addressing200408;
}

/// <summary>The one way this project loads untrusted XML.</summary>
public static class SafeXml
{
    public static XmlReaderSettings Settings(long maxCharacters) => new()
    {
        DtdProcessing = DtdProcessing.Prohibit, // no DOCTYPE at all: blocks XXE and entity expansion
        XmlResolver = null,
        MaxCharactersInDocument = maxCharacters,
        IgnoreComments = true,
        IgnoreProcessingInstructions = true,
    };

    public static XmlDocument Load(byte[] bytes, long maxCharacters, bool preserveWhitespace = false)
    {
        using var reader = XmlReader.Create(new MemoryStream(bytes, writable: false), Settings(maxCharacters));
        return Load(reader, preserveWhitespace);
    }

    public static XmlDocument LoadText(string text, long maxCharacters, bool preserveWhitespace = false)
    {
        using var reader = XmlReader.Create(new StringReader(text), Settings(maxCharacters));
        return Load(reader, preserveWhitespace);
    }

    private static XmlDocument Load(XmlReader reader, bool preserveWhitespace)
    {
        var doc = new XmlDocument { XmlResolver = null, PreserveWhitespace = preserveWhitespace };
        doc.Load(reader);
        return doc;
    }
}

/// <summary>Small XML lookups used when reading SOAP envelopes (requests, payloads and the real services' replies).</summary>
public static class XmlHelpers
{
    /// <summary>The first child element with this local name and namespace, or null.</summary>
    public static XmlElement? ChildElement(XmlElement parent, string localName, string ns)
    {
        foreach (XmlNode node in parent.ChildNodes)
            if (node is XmlElement e && e.LocalName == localName && e.NamespaceURI == ns)
                return e;
        return null;
    }

    /// <summary>The first child element, whatever its name, or null.</summary>
    public static XmlElement? FirstChildElement(XmlElement parent)
    {
        foreach (XmlNode node in parent.ChildNodes)
            if (node is XmlElement e)
                return e;
        return null;
    }
}
