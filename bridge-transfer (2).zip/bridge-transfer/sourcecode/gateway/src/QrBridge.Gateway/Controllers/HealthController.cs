using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Egress.Workers;
using QrBridge.Gateway.Ingress;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data.Repositories;

namespace QrBridge.Gateway.Controllers;

/// <summary>
/// GET /health: queue depths, missing messages, the far side's last signs of life and heartbeats of all components on
/// this machine. Used for monitoring, as the load balancer's health probe, and by IIS Application Initialization
/// (web.config) to start the app at boot. It is the only GET the gateway answers.
/// </summary>
[Route("health")]
public sealed class HealthController(
    OutboxRepository outbox,
    InboxRepository inbox,
    HeartbeatRepository heartbeats,
    SequenceGapMonitor gapMonitor,
    FarSideMonitor farSideMonitor,
    RetryCounters retries,
    RouteTable routes,
    IOptions<BridgeOptions> bridgeOptions) : ControllerBase
{
    private const int MaxGapsShown = 20;

    [HttpGet]
    public async Task<IActionResult> Get(CancellationToken ct)
    {
        var oc = await outbox.GetCountsAsync(ct);
        var ic = await inbox.GetCountsAsync(ct);
        var beats = await heartbeats.GetAllAsync(ct);
        var gaps = gapMonitor.Current; // from the last maintenance run: the gap query is not run per probe
        var now = DateTime.UtcNow;
        var farSide = await farSideMonitor.GetAsync(now, ct);
        var stale = beats.Where(b => now - b.LastSeenUtc > TimeSpan.FromMinutes(2)).Select(b => b.Component).ToList();

        long missingMessages = gaps.Sum(g => g.Count);
        long lightProblems = oc.Light[OutboxLightStatus.Failed] + missingMessages;
        int serviceProblems = MaintenanceWorker.OperatorServiceStatuses.Sum(s => ic.Service[s]);

        return new JsonResult(new
        {
            side = bridgeOptions.Value.Side.ToString(),
            machine = Environment.MachineName,
            utc = now,
            healthy = stale.Count == 0 && lightProblems == 0 && serviceProblems == 0 && !farSide.Silent,
            lightProblems,      // Outbox rows the far side never confirmed + messages that never arrived here
            serviceProblems,    // Inbox rows Unknown / Refused / NotDelivered (the real services on this side)
            farSide,            // last heard (any message, Heartbeats too), last Receipt, silent (D83: unhealthy)
            catalogFingerprint = routes.CatalogFingerprint, // must be the same on both sides (same routes.json)
            missingMessages,
            gaps = gaps.Take(MaxGapsShown),
            gapsCheckedUtc = gapMonitor.CheckedUtc,
            // Callers' retries since start-up (D37): attached = no new row; sameContentQueued = queued again on a route
            // that does not recognise retries (evidence for checking the fingerprint against real retries)
            retries = new { attached = retries.Attached, sameContentQueued = retries.SameContentQueued, sinceUtc = retries.SinceUtc },
            outbox = oc,
            inbox = ic,
            staleComponents = stale,
            heartbeats = beats.Select(b => new { b.Component, b.LastSeenUtc, b.Info }),
        });
    }
}
