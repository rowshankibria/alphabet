using System.Net.Http.Headers;
using System.Xml;

namespace QrBridge.Gateway.Ingress.Soap;

/// <summary>
/// What the gateway needs to know about any SOAP request — SOAP 1.1 or 1.2, document/literal or RPC/encoded,
/// with or without WS-Addressing — without knowing the service's contract.
/// </summary>
public sealed class SoapRequest
{
    public required SoapVersion Version { get; init; }

    /// <summary>Local name of the first element in the Body, e.g. "SendToFMS". Used as the operation name.</summary>
    public required string Operation { get; init; }

    /// <summary>Namespace of that element (the reply wrapper uses the same namespace).</summary>
    public required string OperationNamespace { get; init; }

    /// <summary>True when the operation's parameters are unqualified — the RPC/encoded shape.</summary>
    public required bool ParametersUnqualified { get; init; }

    /// <summary>The first Body element itself, for checking it against the service's WSDL.</summary>
    public XmlElement? OperationElement { get; init; }

    /// <summary>Text of the first parameter (sXML, XMLMsg, sValue...), or null if it has element content.</summary>
    public string? FirstParameterText { get; init; }

    /// <summary>The SOAPAction header exactly as received (quotes included), or null.</summary>
    public string? SoapActionHeader { get; init; }

    /// <summary>The action, unquoted: wsa:Action, else SOAPAction header, else the Content-Type action parameter.</summary>
    public string? Action { get; init; }

    /// <summary>
    /// The action the HTTP request carries, unquoted: the SOAPAction header (SOAP 1.1), else the Content-Type
    /// action parameter (SOAP 1.2); null when there is none. This is what the WSDL's soapAction describes.
    /// </summary>
    public string? HttpAction { get; init; }

    public AddressingInfo? Addressing { get; init; }

    /// <summary>
    /// Parses a request body. Never throws for bad input: returns false with a reason that is safe to show
    /// to the caller. DTDs are prohibited (XXE / entity expansion) and nothing external is resolved.
    /// </summary>
    public static bool TryParse(byte[] body, string? contentType, string? soapActionHeader, long maxCharacters,
                                out SoapRequest? request, out string error)
    {
        request = null;
        XmlDocument doc;
        try
        {
            doc = SafeXml.Load(body, maxCharacters);
        }
        catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
        {
            error = "The request is not well-formed XML: " + ex.Message;
            return false;
        }

        var envelope = doc.DocumentElement;
        if (envelope is null || envelope.LocalName != "Envelope" ||
            envelope.NamespaceURI is not (SoapNamespaces.Soap11 or SoapNamespaces.Soap12))
        {
            error = "The request is not a SOAP 1.1 or SOAP 1.2 envelope.";
            return false;
        }

        var version = envelope.NamespaceURI == SoapNamespaces.Soap12 ? SoapVersion.Soap12 : SoapVersion.Soap11;
        string envNs = envelope.NamespaceURI;

        var header = XmlHelpers.ChildElement(envelope, "Header", envNs);
        var bodyElement = XmlHelpers.ChildElement(envelope, "Body", envNs);
        if (bodyElement is null)
        {
            error = "The SOAP envelope has no Body.";
            return false;
        }

        var operation = XmlHelpers.FirstChildElement(bodyElement);
        if (operation is null)
        {
            error = "The SOAP Body is empty.";
            return false;
        }
        if (operation.LocalName == "Fault" && operation.NamespaceURI == envNs)
        {
            error = "A SOAP Fault is not a request.";
            return false;
        }

        var parameter = XmlHelpers.FirstChildElement(operation);
        string? parameterText = parameter is null ? null
            : HasElementChildren(parameter) ? null
            : parameter.InnerText;

        var addressing = ReadAddressing(header);
        string? httpAction = Unquote(soapActionHeader);
        if (string.IsNullOrEmpty(httpAction)) httpAction = ContentTypeAction(contentType);

        request = new SoapRequest
        {
            Version = version,
            Operation = operation.LocalName,
            OperationNamespace = operation.NamespaceURI,
            ParametersUnqualified = parameter is not null && parameter.NamespaceURI.Length == 0,
            OperationElement = operation,
            FirstParameterText = parameterText,
            SoapActionHeader = soapActionHeader,
            Action = addressing?.Action is { Length: > 0 } wsaAction ? wsaAction : NullIfEmpty(httpAction),
            HttpAction = NullIfEmpty(httpAction),
            Addressing = addressing,
        };
        error = "";
        return true;
    }

    private static AddressingInfo? ReadAddressing(XmlElement? header)
    {
        if (header is null) return null;
        string? ns = null, action = null, messageId = null, to = null;
        foreach (XmlNode node in header.ChildNodes)
        {
            if (node is not XmlElement e || !SoapNamespaces.IsAddressing(e.NamespaceURI)) continue;
            ns = e.NamespaceURI;
            switch (e.LocalName)
            {
                case "Action": action = e.InnerText.Trim(); break;
                case "MessageID": messageId = e.InnerText.Trim(); break;
                case "To": to = e.InnerText.Trim(); break;
            }
        }
        return ns is null ? null : new AddressingInfo(ns, action, messageId, to);
    }

    /// <summary>SOAP 1.2 carries the action as a Content-Type parameter: application/soap+xml; action="...".</summary>
    private static string? ContentTypeAction(string? contentType)
    {
        if (string.IsNullOrWhiteSpace(contentType) || !MediaTypeHeaderValue.TryParse(contentType, out var media))
            return null;
        var action = media.Parameters.FirstOrDefault(p => p.Name.Equals("action", StringComparison.OrdinalIgnoreCase));
        return Unquote(action?.Value);
    }

    private static string? Unquote(string? value)
    {
        if (value is null) return null;
        string v = value.Trim();
        return v.Length >= 2 && v[0] == '"' && v[^1] == '"' ? v[1..^1] : v;
    }

    private static string? NullIfEmpty(string? s) => string.IsNullOrWhiteSpace(s) ? null : s;

    private static bool HasElementChildren(XmlElement element)
    {
        foreach (XmlNode node in element.ChildNodes)
            if (node is XmlElement)
                return true;
        return false;
    }
}

/// <summary>The WS-Addressing headers of a request, needed to correlate the reply.</summary>
public sealed record AddressingInfo(string Namespace, string? Action, string? MessageId, string? To);
