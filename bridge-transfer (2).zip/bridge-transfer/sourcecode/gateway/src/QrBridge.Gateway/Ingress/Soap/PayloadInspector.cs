using System.Xml;

namespace QrBridge.Gateway.Ingress.Soap;

/// <summary>
/// Reads the label of the XML string that FMS-style services carry in their single parameter
/// (sXML / XMLMsg). Only for the allow-list and for operators — the payload itself is never changed.
/// </summary>
public static class PayloadInspector
{
    private const int MaxLabelLength = 128;

    public static BusinessInfo Inspect(string? parameterText, long maxCharacters)
    {
        if (string.IsNullOrWhiteSpace(parameterText)) return BusinessInfo.None;
        string text = parameterText.Trim().TrimStart('﻿');
        if (!text.StartsWith('<')) return BusinessInfo.None; // e.g. an EchoString value

        XmlElement? root;
        try
        {
            root = SafeXml.LoadText(text, maxCharacters).DocumentElement;
        }
        catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
        {
            return new BusinessInfo(null, null, IsXml: true, WellFormed: false);
        }
        if (root is null) return new BusinessInfo(null, null, true, false);

        // ConEd standard envelope: <MESSAGE TYPE="REQUEST_FOR_PERMIT" MSG_ID="679" ...>
        if (root.LocalName == "MESSAGE" && root.NamespaceURI.Length == 0)
            return new BusinessInfo(Label(root.GetAttribute("TYPE")), Label(root.GetAttribute("MSG_ID")), true, true);

        // A SOAP envelope passed as a string (Verizon eBonding): name it after its Body element.
        if (root.LocalName == "Envelope" && root.NamespaceURI is SoapNamespaces.Soap11 or SoapNamespaces.Soap12)
        {
            var body = XmlHelpers.ChildElement(root, "Body", root.NamespaceURI);
            var first = body is null ? null : XmlHelpers.FirstChildElement(body);
            return new BusinessInfo(Label(first?.LocalName ?? root.LocalName), null, true, true);
        }

        // Anything else (e.g. ANSI tML-TA CancelTroubleReportResponse): its root element name.
        return new BusinessInfo(Label(root.LocalName), null, true, true);
    }

    private static string? Label(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        string v = value.Trim();
        return v.Length <= MaxLabelLength ? v : v[..MaxLabelLength];
    }
}

/// <summary>What the business payload inside a SOAP parameter says it is.</summary>
/// <param name="Type">FMS MESSAGE/@TYPE, or the root element name (for a nested SOAP envelope: its Body element).</param>
/// <param name="MsgId">FMS MESSAGE/@MSG_ID (a static template value in many callers — a label, never an identity).</param>
/// <param name="IsXml">The parameter looked like XML.</param>
/// <param name="WellFormed">False when it looked like XML but could not be parsed.</param>
public sealed record BusinessInfo(string? Type, string? MsgId, bool IsXml, bool WellFormed)
{
    public static readonly BusinessInfo None = new(null, null, false, true);
}
