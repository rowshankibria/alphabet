using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Repositories;

/// <summary>
/// Queue operations on the Outbox table of qrbridge.db. Each method uses its own short-lived DbContext.
/// Writing new rows is done by the Gateway's OutboxWriter (it needs the sequence + message bytes in one transaction);
/// claiming and marking rows is done by the QR sender. The light group (LightStatus) moves as the message crosses;
/// the service group (ServiceStatus) moves once, when the far side's Reply arrives (<see cref="MarkAnsweredAsync"/>).
/// </summary>
public sealed class OutboxRepository(IDbContextFactory<BridgeDbContext> factory, IOptions<BridgeOptions> bridgeOptions)
{
    private const int MaxCommentLength = 2000;
    private const int MaxContentTypeLength = 4096;

    private readonly int _maxReplyBytes = bridgeOptions.Value.MaxPayloadBytes;

    /// <summary>
    /// Atomically claims the next row to air (Pending -> Sending): Receipts, Replies and Heartbeats first, then Requests
    /// by class (Priority, decision D73), lowest Sequence first within a class. Returns null if none.
    /// Optimistic claim: the UPDATE only succeeds if the row is still Pending, so two claimers can never get the same row.
    /// </summary>
    public async Task<OutboxMessage?> ClaimNextAsync(CancellationToken ct)
    {
        for (int attempt = 0; attempt < 5; attempt++)
        {
            await using var db = await factory.CreateDbContextAsync(ct);
            var now = DateTime.UtcNow;

            Guid? id = await db.Outbox
                .Where(m => m.LightStatus == OutboxLightStatus.Pending && (m.NextAttemptUtc == null || m.NextAttemptUtc <= now))
                .OrderBy(m => m.Priority).ThenBy(m => m.Sequence)
                .Select(m => (Guid?)m.MessageId)
                .FirstOrDefaultAsync(ct);
            if (id is null) return null;

            int claimed = await db.Outbox
                .Where(m => m.MessageId == id && m.LightStatus == OutboxLightStatus.Pending)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.LightStatus, OutboxLightStatus.Sending)
                    .SetProperty(m => m.LightUpdatedUtc, now)
                    .SetProperty(m => m.LockedUtc, now)
                    .SetProperty(m => m.Attempts, m => m.Attempts + 1), ct);

            if (claimed == 1)
                return await db.Outbox.AsNoTracking().FirstAsync(m => m.MessageId == id, ct);
        }
        return null;
    }

    /// <summary>
    /// The QR sender finished showing these messages (Sending -> Aired). Only rows still Sending change, so a late call
    /// cannot undo a Receipt that already arrived. Integration-Plan §2.2 adds the bundle and QR session ids.
    /// </summary>
    public async Task<int> MarkAiredAsync(IReadOnlyCollection<Guid> messageIds, CancellationToken ct)
    {
        if (messageIds.Count == 0) return 0;
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        int total = 0;
        foreach (Guid id in messageIds.Distinct())
        {
            total += await db.Outbox
                .Where(m => m.MessageId == id && m.LightStatus == OutboxLightStatus.Sending)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.LightStatus, OutboxLightStatus.Aired)
                    .SetProperty(m => m.LightUpdatedUtc, now)
                    .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
        }
        return total;
    }

    /// <summary>The far side confirmed storing these messages (Receipt). Ids that don't exist or are already Received are ignored.</summary>
    public async Task<int> MarkReceivedAsync(IReadOnlyCollection<Guid> messageIds, CancellationToken ct)
    {
        if (messageIds.Count == 0) return 0;
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        int total = 0;
        // One small UPDATE per id (a receipt carries at most a bundle's worth) — simple and index-friendly.
        foreach (Guid id in messageIds.Distinct())
        {
            total += await db.Outbox
                .Where(m => m.MessageId == id && m.LightStatus != OutboxLightStatus.Received)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.LightStatus, OutboxLightStatus.Received)
                    .SetProperty(m => m.LightUpdatedUtc, now)
                    .SetProperty(m => m.LockedUtc, (DateTime?)null)
                    .SetProperty(m => m.LightComment, (string?)null), ct);
        }
        return total;
    }

    /// <summary>
    /// Stores what the far side's real service did with a request, from its Reply: the outcome, HTTP status, a comment,
    /// and the answer itself (Content-Type and body, byte for byte) for the waiting caller or its retry. A Reply implies
    /// a Receipt, so the light group becomes Received too.
    /// Stored when the request is still Waiting, or (decision D59: an operator requeued it on the far side) when the
    /// stored answer is not Answered and came from an older Reply (<paramref name="replyCreatedUtc"/>, the far side's
    /// clock). Returns false when nothing changed: unknown id, not a Request, already Answered, or a re-aired / older Reply.
    /// </summary>
    /// <exception cref="ArgumentException">Status Waiting, a body over Bridge:MaxPayloadBytes, or a Content-Type over 4,096 characters.</exception>
    public async Task<bool> MarkAnsweredAsync(Guid requestId, OutboxServiceStatus status, int? httpStatus, string comment,
                                              string? contentType, byte[]? body, DateTime replyCreatedUtc, CancellationToken ct)
    {
        if (status == OutboxServiceStatus.Waiting)
            throw new ArgumentException("An answer cannot set ServiceStatus back to Waiting.", nameof(status));
        if (body is { Length: var length } && length > _maxReplyBytes)
            throw new ArgumentException($"Reply body {length} bytes exceeds Bridge:MaxPayloadBytes ({_maxReplyBytes}).", nameof(body));
        if (contentType is { Length: > MaxContentTypeLength })
            throw new ArgumentException("Reply Content-Type is too long.", nameof(contentType));

        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        string? message = Truncate(comment, MaxCommentLength);
        int updated = await db.Outbox
            .Where(m => m.MessageId == requestId && m.Kind == MessageKind.Request &&
                        (m.ServiceStatus == OutboxServiceStatus.Waiting ||
                         (m.ServiceStatus != OutboxServiceStatus.Answered && m.ReplyCreatedUtc < replyCreatedUtc)))
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.ServiceStatus, status)
                .SetProperty(m => m.ServiceHttpStatus, httpStatus)
                .SetProperty(m => m.ServiceComment, message)
                .SetProperty(m => m.ServiceUpdatedUtc, now)
                .SetProperty(m => m.ReplyContentType, contentType)
                .SetProperty(m => m.ReplyBody, body)
                .SetProperty(m => m.ReplyCreatedUtc, replyCreatedUtc)
                .SetProperty(m => m.LightUpdatedUtc, m => m.LightStatus == OutboxLightStatus.Received ? m.LightUpdatedUtc : now)
                .SetProperty(m => m.LightStatus, OutboxLightStatus.Received)
                .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
        return updated == 1;
    }

    /// <summary>
    /// Gives a message back to the queue after it was shown for too long without a receipt
    /// (lets other messages through). After maxAttempts it is marked Failed for an operator to look at.
    /// </summary>
    public async Task ReleaseAsync(Guid id, string reason, int maxAttempts, TimeSpan retryDelay, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var row = await db.Outbox.FirstOrDefaultAsync(m => m.MessageId == id, ct);
        if (row is null || row.LightStatus != OutboxLightStatus.Sending) return;

        row.LockedUtc = null;
        row.LightUpdatedUtc = DateTime.UtcNow;
        row.LightComment = Truncate(reason, MaxCommentLength);
        if (row.Attempts >= maxAttempts)
        {
            row.LightStatus = OutboxLightStatus.Failed;
        }
        else
        {
            row.LightStatus = OutboxLightStatus.Pending;
            row.NextAttemptUtc = DateTime.UtcNow + retryDelay;
        }
        await db.SaveChangesAsync(ct);
    }

    /// <summary>
    /// Re-airing (decisions D9, D65–D67): every row Aired longer than <paramref name="receiptTimeout"/> ago with no
    /// Receipt yet goes back to Pending so the QR sender airs it again, which is safe because the far Inbox skips a
    /// MessageId it already has and owes a new Receipt. A row that has been aired <paramref name="maxAirAttempts"/> times,
    /// or is past its ExpiresUtc (never aired again), becomes Failed for an operator instead. Receipt and Heartbeat rows
    /// are never aired again: neither gets a Receipt (a lost Heartbeat is replaced by the next one). Each row changes only
    /// if it is still Aired and not re-aired since it was read, so a Receipt that arrives at the same moment always wins.
    /// </summary>
    public async Task<IReadOnlyList<UnconfirmedMessage>> ReairUnconfirmedAsync(TimeSpan receiptTimeout, int maxAirAttempts, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        var airedBefore = now - receiptTimeout;
        var rows = await db.Outbox.AsNoTracking()
            .Where(m => m.LightStatus == OutboxLightStatus.Aired && m.Kind != MessageKind.Receipt && m.Kind != MessageKind.Heartbeat &&
                        (m.LightUpdatedUtc == null || m.LightUpdatedUtc <= airedBefore))
            .OrderBy(m => m.Sequence)
            .Select(m => new { m.MessageId, m.Kind, m.ServiceName, m.Operation, m.Attempts, m.ExpiresUtc })
            .ToListAsync(ct);

        int seconds = (int)receiptTimeout.TotalSeconds;
        var changed = new List<UnconfirmedMessage>();
        foreach (var row in rows)
        {
            string aired = row.Attempts == 1 ? "Aired once" : $"Aired {row.Attempts} times";
            var (status, reason) = row.ExpiresUtc is { } expires && expires <= now
                ? (OutboxLightStatus.Failed, $"Expired at {expires:u} before the far side confirmed it ({aired.ToLowerInvariant()}): not aired again.")
                : row.Attempts >= maxAirAttempts
                    ? (OutboxLightStatus.Failed, $"{aired}, no receipt after {seconds} s: check the screen, the camera and the far QR Receiver, then requeue.")
                    : (OutboxLightStatus.Pending, $"{aired}, no receipt after {seconds} s: aired again.");

            int updated = await db.Outbox
                .Where(m => m.MessageId == row.MessageId && m.LightStatus == OutboxLightStatus.Aired &&
                            (m.LightUpdatedUtc == null || m.LightUpdatedUtc <= airedBefore))
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.LightStatus, status)
                    .SetProperty(m => m.LightComment, reason)
                    .SetProperty(m => m.LightUpdatedUtc, now)
                    .SetProperty(m => m.NextAttemptUtc, (DateTime?)null), ct);
            if (updated == 1)
                changed.Add(new UnconfirmedMessage(row.MessageId, row.Kind, row.ServiceName, row.Operation, row.Attempts, status, reason));
        }
        return changed;
    }

    /// <summary>Called by the QR sender at startup: anything it was showing when it stopped goes back to Pending.</summary>
    public async Task<int> ResetSendingAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        return await db.Outbox
            .Where(m => m.LightStatus == OutboxLightStatus.Sending)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.LightStatus, OutboxLightStatus.Pending)
                .SetProperty(m => m.LightUpdatedUtc, now)
                .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
    }

    /// <summary>Operator action: put a Failed message back in the queue.</summary>
    public async Task<int> RequeueFailedAsync(Guid? messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        var q = db.Outbox.Where(m => m.LightStatus == OutboxLightStatus.Failed);
        if (messageId is { } id) q = q.Where(m => m.MessageId == id);
        return await q.ExecuteUpdateAsync(s => s
            .SetProperty(m => m.LightStatus, OutboxLightStatus.Pending)
            .SetProperty(m => m.LightUpdatedUtc, now)
            .SetProperty(m => m.Attempts, 0)
            .SetProperty(m => m.NextAttemptUtc, (DateTime?)null), ct);
    }

    public async Task<OutboxMessage?> FindAsync(Guid messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.AsNoTracking().FirstOrDefaultAsync(m => m.MessageId == messageId, ct);
    }

    /// <summary>
    /// The latest Reply this side wrote for <paramref name="requestId"/> (after an operator requeue, the newest outcome), or
    /// null. Crash recovery (D46, D64) and layer 3b (D58) read it.
    /// </summary>
    public async Task<OutboxMessage?> FindLastReplyToAsync(Guid requestId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.AsNoTracking()
            .Where(m => m.Kind == MessageKind.Reply && m.CorrelationId == requestId)
            .OrderByDescending(m => m.CreatedUtc).ThenByDescending(m => m.Sequence)
            .FirstOrDefaultAsync(ct);
    }

    /// <summary>
    /// Where a message stands, and the far side's answer once it is stored, without the message bytes: read by a held
    /// caller every few seconds, and by the Reply reader to check a Reply against its request. Null when unknown.
    /// </summary>
    public async Task<MessageState?> FindStateAsync(Guid messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.AsNoTracking()
            .Where(m => m.MessageId == messageId)
            .Select(m => new MessageState(m.MessageId, m.Kind, m.ServiceName, m.Operation, m.LightStatus, m.ServiceStatus,
                                          m.ServiceHttpStatus, m.ReplyContentType, m.ReplyBody))
            .FirstOrDefaultAsync(ct);
    }

    /// <summary>When this side last queued anything to send (any kind); null when never. For the idle Heartbeat (D81).</summary>
    public async Task<DateTime?> FindLastQueuedUtcAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.OrderByDescending(m => m.CreatedUtc).Select(m => (DateTime?)m.CreatedUtc).FirstOrDefaultAsync(ct);
    }

    /// <summary>A Heartbeat is still waiting to be aired (Pending or Sending): the light is down or busy, so another one adds nothing.</summary>
    public async Task<bool> AnyHeartbeatWaitingAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.AnyAsync(m => m.Kind == MessageKind.Heartbeat &&
                                             (m.LightStatus == OutboxLightStatus.Pending || m.LightStatus == OutboxLightStatus.Sending), ct);
    }

    public async Task<OutboxCounts> GetCountsAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var light = await db.Outbox.GroupBy(m => m.LightStatus)
            .Select(g => new { g.Key, Count = g.Count() })
            .ToListAsync(ct);
        var service = await db.Outbox.GroupBy(m => m.ServiceStatus)
            .Select(g => new { g.Key, Count = g.Count() })
            .ToListAsync(ct);
        // An aired Receipt or Heartbeat is done (neither gets a Receipt), so it is not "unconfirmed".
        DateTime? oldest = await db.Outbox
            .Where(m => m.LightStatus == OutboxLightStatus.Pending || m.LightStatus == OutboxLightStatus.Sending ||
                        (m.LightStatus == OutboxLightStatus.Aired && m.Kind != MessageKind.Receipt && m.Kind != MessageKind.Heartbeat))
            .OrderBy(m => m.Sequence)
            .Select(m => (DateTime?)m.CreatedUtc)
            .FirstOrDefaultAsync(ct);

        return new OutboxCounts(
            StatusCounts.ForAll(light.Select(g => KeyValuePair.Create(g.Key, g.Count))),
            StatusCounts.ForAll(service.Select(g => KeyValuePair.Create(g.Key, g.Count))),
            oldest);
    }

    private static string? Truncate(string? s, int max) => s is null || s.Length <= max ? s : s[..max];
}

/// <param name="Light">Rows per LightStatus (every status listed, 0 when none).</param>
/// <param name="Service">Rows per ServiceStatus (every status listed, 0 when none).</param>
/// <param name="OldestUndeliveredUtc">CreatedUtc of the oldest row the far side has not confirmed yet; null when none.</param>
public sealed record OutboxCounts(
    IReadOnlyDictionary<OutboxLightStatus, int> Light,
    IReadOnlyDictionary<OutboxServiceStatus, int> Service,
    DateTime? OldestUndeliveredUtc);

/// <summary>
/// One row <see cref="OutboxRepository.ReairUnconfirmedAsync"/> changed: back to Pending (aired again) or Failed (out of
/// tries or expired), with the reason it wrote to LightComment. Ids and names only, never the payload.
/// </summary>
public sealed record UnconfirmedMessage(
    Guid MessageId,
    MessageKind Kind,
    string ServiceName,
    string Operation,
    int Airs,
    OutboxLightStatus NewStatus,
    string Reason);

/// <summary>
/// One Outbox row's statuses and stored answer (<see cref="OutboxRepository.FindStateAsync"/>). ReplyBody and
/// ReplyContentType are the real service's answer, null until a Reply carrying one arrived.
/// </summary>
public sealed record MessageState(
    Guid MessageId,
    MessageKind Kind,
    string ServiceName,
    string Operation,
    OutboxLightStatus LightStatus,
    OutboxServiceStatus ServiceStatus,
    int? ServiceHttpStatus,
    string? ReplyContentType,
    byte[]? ReplyBody);
