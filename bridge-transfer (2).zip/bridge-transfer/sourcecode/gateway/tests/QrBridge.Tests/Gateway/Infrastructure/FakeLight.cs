using System.Collections.Concurrent;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>
/// The QR link in both directions, as the QrDiode apps will run it: the "QR sender" claims the next Outbox row
/// (<see cref="OutboxRepository.ClaimNextAsync"/>), marks it Aired, and the "QR receiver" stores it in the other
/// gateway's Inbox (<see cref="InboxRepository.AddMessageAsync"/>) and rings the doorbell. Faults are scripted per aired
/// row with <see cref="Copies"/>: 0 = the session is lost, 1 = it arrives, 2 = it arrives twice (a duplicate session).
/// Each lane can be paused. Every air is recorded in <see cref="Aired"/>.
/// </summary>
public sealed class FakeLight : IAsyncDisposable
{
    private readonly Func<BridgeSide, GatewayHost> _host;
    private readonly CancellationTokenSource _stop = new();
    private readonly Task _loop;

    /// <param name="host">The current gateway of each side (a restarted gateway is picked up).</param>
    public FakeLight(Func<BridgeSide, GatewayHost> host, bool on)
    {
        _host = host;
        CorpToDmzOn = DmzToCorpOn = on;
        _loop = Task.Run(RunAsync);
    }

    public volatile bool CorpToDmzOn;
    public volatile bool DmzToCorpOn;

    /// <summary>How many copies of an aired row reach the other side (default 1). The row is as claimed (Attempts = airs so far).</summary>
    public Func<OutboxMessage, int> Copies { get; set; } = _ => 1;

    /// <summary>Every row put on air, in order, with the number of copies that arrived.</summary>
    public ConcurrentQueue<(OutboxMessage Row, int Copies)> Aired { get; } = new();

    public bool On
    {
        set => CorpToDmzOn = DmzToCorpOn = value;
    }

    /// <summary>Rows of <paramref name="kind"/> aired on the lane from <paramref name="from"/>, optionally about one message.</summary>
    public int AirsOf(BridgeSide from, MessageKind kind, Guid? correlationOrId = null) =>
        Aired.Count(a => a.Row.Direction == (from == BridgeSide.Corp ? Direction.CorpToDmz : Direction.DmzToCorp) &&
                         a.Row.Kind == kind &&
                         (correlationOrId is null || a.Row.MessageId == correlationOrId || a.Row.CorrelationId == correlationOrId));

    private async Task RunAsync()
    {
        while (!_stop.IsCancellationRequested)
        {
            bool busy = false;
            try
            {
                if (CorpToDmzOn) busy |= await AirOneAsync(BridgeSide.Corp, BridgeSide.Dmz);
                if (DmzToCorpOn) busy |= await AirOneAsync(BridgeSide.Dmz, BridgeSide.Corp);
            }
            catch (Exception) when (!_stop.IsCancellationRequested)
            {
                // A gateway is being restarted: its database comes back with the new host.
            }
            if (!busy)
            {
                try { await Task.Delay(50, _stop.Token); }
                catch (OperationCanceledException) { break; }
            }
        }
    }

    private async Task<bool> AirOneAsync(BridgeSide from, BridgeSide to)
    {
        var sender = _host(from).Get<OutboxRepository>();
        var row = await sender.ClaimNextAsync(CancellationToken.None);
        if (row is null) return false;
        await sender.MarkAiredAsync([row.MessageId], CancellationToken.None);

        int copies = Copies(row);
        Aired.Enqueue((row, copies));
        var receiver = _host(to);
        var header = MessageSerializer.PeekHeader(row.MessageBytes);
        for (int i = 0; i < copies; i++)
            await receiver.Get<InboxRepository>().AddMessageAsync(header, row.MessageBytes, CancellationToken.None);
        if (copies > 0) receiver.Get<BridgeSignals>().Inbox.Set();
        return true;
    }

    public async ValueTask DisposeAsync()
    {
        await _stop.CancelAsync();
        try { await _loop; } catch (OperationCanceledException) { }
        _stop.Dispose();
    }
}
