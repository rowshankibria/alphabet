---
description: 'Make the QrDiode Sender air bundles from the Outbox (Integration Plan step 3)'
agent: 'agent'
---

> **Done 27 Nov 2026** (handoff decision 53): `"QrDiode:Mode": "Bridge"`, `Transmit/OutboxSource.cs`,
> `TransmitEngine.ItemFinished`, `QrAppBridge` (in `QrBridge.Shared`) as the composition root, kiosk start-up. Kept as a
> record; do not run it again. New QrDiode work: `sourcecode/qrdiode/docs/qrdiode-pending-work.md`.

Implement [Integration Plan §2.4](../../docs/gateway-to-qrdiode/integration-plan.md). This needs step 2 (bundles and the store
methods `ClaimBundleAsync`, `MarkAiredAsync`, `ReleaseBundleAsync`); the Outbox light status `Aired` itself exists
since 24 Nov 2026 (V6 fix step 5a). Check that `OutboxRepository.ClaimBundleAsync` and `BundleCodec` exist; if they don't,
stop and say so. Rowshan is new to WPF: explain the WPF parts of the change with Angular analogies (see
[the WPF tutorial](../../sourcecode/qrdiode/docs/wpf-tutorial.md)).

Read these first:
- `sourcecode/qrdiode/src/QrDiode.Sender/MainWindow.xaml.cs` (creates `TransmitEngine` and `LiveSource`, handles `SessionEnded`);
- `Transmit/TransmitEngine.cs`;
- `Transmit/QueueItem.cs`;
- `App.xaml.cs`.

## Steps

1. **References and settings.** Reference `sourcecode/gateway/src/QrBridge.Shared` from `QrDiode.Sender.csproj` (not from
   `QrDiode.Core`). Add `appsettings.json` next to the exe (`CopyToOutputDirectory=PreserveNewest`; check it also
   lands next to the single-file exe from `dotnet publish`, guide §12.3) with these keys:
   - `Bridge:Side`;
   - `Bridge:DataFolder`;
   - `Sender:Source`: `Outbox` or `Simulator`, default `Simulator` so demos keep working;
   - `Sender:MaxBundleMessages` (50);
   - `Sender:MaxBundleBytes` (131072).

   Pin any new `Microsoft.Extensions.*` packages to the version `QrBridge.Shared` uses. QrDiode keys and settings
   stay in `%LocalAppData%\QrDiode\` as today.
2. **Composition root** in `App.xaml.cs`: a `ServiceCollection` with configuration, logging, `AddBridgeData()`
   (options bound from `Bridge`) and `BridgeSignals`.
   - Run `DatabaseInitializer.InitializeAsync` at startup **without blocking the UI thread**.
   - If the database can't be opened, show the error and stay in Simulator mode. Don't crash.
3. **`TransmitEngine` changes** (small, in place):
   - Never trim Outbox items. Since 26 Nov `TrimQueue` only skips `QueueItem.Droppable` items (the simulator's):
     enqueue bundles with `droppable: false` (the default). Add `Guid? BundleId` to `QueueItem` to map the item back.
   - The counter comes as a `CounterReservation` (run id + value); pass both to `SendSession.Create` as today.
     The Sender must keep running as the kiosk user (the counter file and the CNG keys are per Windows user).
   - Add an `ItemFinished` event, raised once for **every** item that reaches a final state (Sent, Skipped or
     Failed). Include the encode-failure path and the "stage closed during encode" path. Today `SessionEnded` fires
     only for items that went on air, so a bundle that fails to encode would stay `LightStatus` `Sending` forever.
4. **`OutboxSource`** (new file `Transmit/OutboxSource.cs`), used instead of `LiveSource` when
   `Sender:Source=Outbox`:
   - At start, call `OutboxRepository.ResetSendingAsync`: rows a crash left in `LightStatus` `Sending` go back to `Pending`.
   - Run a background loop with a `CancellationToken`. Each pass waits on the Outbox doorbell
     (`BridgeSignals.Outbox`) or a 2 s timeout.
   - `TransmitEngine` and its queue belong to the UI thread, so check `QueuedCount == 0` there
     (`Dispatcher.InvokeAsync`). Only then call `ClaimBundleAsync(max…)`. At most one bundle waits behind the one on
     air.
   - Build the bytes with `BundleCodec.Build`, and the `PayloadType` the way `EnqueueFile` does
     (`PayloadCatalogue.ForFilename(name, ContentKind.File)`).
   - Enqueue on the UI thread with `TransmitEngine.Enqueue(type, BundleCodec.FileName(first, last), bytes)`, and set
     the item's `BundleId`.
   - On `ItemFinished` (these are `TransmitEngine` item states, not Outbox statuses):
     - `Sent` → `MarkAiredAsync(bundleId, item.SessionId)`;
     - `Skipped` → `ReleaseBundleAsync(bundleId, reason, TimeSpan.Zero)`;
     - `Failed` → `ReleaseBundleAsync(bundleId, item.Error, 30 s)`, and show the error.
   - Every 30 s, call `HeartbeatRepository.BeatAsync(Components.SenderLoop, info)`, where info is the queue depth and the
     last bundle.
   - When the window closes, stop the loop and release any bundle that is still queued (not on air).
5. **UI:** show the source (Outbox or Simulator), the Outbox backlog (`GetCountsAsync`: `Light` counts `Pending` +
   `Sending` + `Aired`) and the current bundle's sequence range. Keep the simulator controls, but disable them in Outbox mode.
6. Never block the UI thread and never use `.Result` / `.Wait()`. Database calls are `async`, and UI objects are
   touched only on the UI thread.

## Check

The Sender has no test project. Keep logic that can be tested without WPF in `QrBridge.Shared`, and test it in
`QrBridge.Tests`. Then check by hand:

1. Start the Corp gateway: `dotnet run --project sourcecode\gateway\src\QrBridge.Gateway --launch-profile "Gateway (Corp)"` (port
   5080, data in `C:\QrBridgeDev\Corp\Data`).
2. Start the Sender with `Bridge:Side=Corp`, `Bridge:DataFolder=C:\QrBridgeDev\Corp\Data` and
   `Sender:Source=Outbox`.
3. POST a sample to `http://localhost:5080` (e.g. `Invoke-WebRequest` with a file from `sourcecode\gateway\tests\QrBridge.Tests\Samples` and its `SOAPAction`). It should appear on the stage
   within about a second, and its Outbox row should end with `LightStatus` `Aired` (`ServiceStatus` stays `Waiting`:
   in this one-lane check nothing carries the DMZ Reply back). Receipt, Reply and Heartbeat rows (kind `Heartbeat`,
   queued by the gateway when this side has sent nothing for `Gateway:HeartbeatMinutes`) are claimed first and must
   air and end `Aired` the same way; don't filter on `Kind`.
4. Kill the Sender while a bundle is on air. After a restart, the same rows go out again.
5. Send 200 calls quickly. They should air as bundles of up to 50, and none may be dropped: the Outbox counts must
   add up.

## Done when

The manual checks pass, `dotnet test All.slnx` passes, and the single-file `dotnet publish` (guide §12.3) still produces a working Sender exe
with its `appsettings.json`. Then run [update-handoff](update-handoff.prompt.md) (known issues 2 and 5, Integration
Plan step 3, HANDOFF verification). Don't commit.
