---
description: 'Make the QrDiode Receiver store arrived bundles in the Inbox (Integration Plan step 4)'
agent: 'agent'
---

> **Done 27 Nov 2026** (handoff decision 53): Bridge mode in the Receiver (`HandleBundleAsync` before the "same content"
> check, `InboxBundleWriter`, replay commit after the Inbox write, no payload kept, heartbeat), SQLite packages aligned.
> Kept as a record; do not run it again. New QrDiode work: `sourcecode/qrdiode/docs/qrdiode-pending-work.md`.

Implement [Integration Plan §2.5](../../docs/gateway-to-qrdiode/integration-plan.md). This needs steps 1–3. Explain the WPF parts
to Rowshan with Angular analogies.

Read these first:
- `sourcecode/qrdiode/src/QrDiode.Receiver/MainWindow.xaml.cs` (`OnQrPayload`, `HandleCompletion`, `HandleRejection`);
- `sourcecode/qrdiode/src/QrDiode.Core/Pipeline/ReceiveEngine.cs` (`FinishTransfer`);
- `sourcecode/qrdiode/src/QrDiode.Receiver/Storage/SqliteJournal.cs`.

## Steps

1. **Packages first** (known issue 4). Reference `sourcecode/gateway/src/QrBridge.Shared` from the Receiver. Only one native SQLite may
   load per process:
   - move `Microsoft.Data.Sqlite` to the version EF Core uses (10.0.15);
   - remove the direct `SQLitePCLRaw.bundle_e_sqlite3` 3.0.5 reference, so EF's SQLitePCLRaw is used.

   `dotnet list sourcecode\qrdiode\src\QrDiode.Receiver package --include-transitive` must show a single SQLitePCLRaw version. Check
   that the Receiver's own journal (`SqliteJournal`) still opens, writes and reads.
2. **Composition root and settings**, the same pattern as the Sender:
   - `appsettings.json` with `Bridge:Side` and `Bridge:DataFolder`;
   - a `ServiceCollection` with `AddBridgeData()` and `BridgeSignals`;
   - `DatabaseInitializer.InitializeAsync`, run asynchronously;
   - a heartbeat `Components.ReceiverLoop` every 30 s.
3. **Anti-replay commit order** — *already built 26 Nov 2026* (`ReceiveEngine.CommitReplay()`,
   `Reset(bool settle = true)`, `ReplayCommitTests`; the file path in `HandleCompletion` stores, then commits, and uses
   `Reset(settle: committed)`). Follow the same order for bundles below.
4. **Bundles in `HandleCompletion`**, when the filename ends with `.qbb` — put this branch **before** the existing
   `IsDuplicateContent` check (pending work B-06: that check drops a payload whose plaintext was ever stored, and a
   re-aired bundle can be byte-identical; it must still reach `AddMessagesAsync` so it is owed a Receipt again).
   For bundles write no payload store, no `.meta.json`, no journal `snippet` and no inbox preview (S-06: gateway
   payloads are never logged). Once bundles are the only traffic, set `"AllowOpaqueFiles": false` in the Receiver's
   `appsettings.json` and let a `File` through only when it is a `.qbb` that `BundleCodec` parses:
   1. Parse with `BundleCodec.Parse(plaintext, …)`. For each envelope, read the header with
      `MessageSerializer.PeekHeader` (no key needed) and require `header.Direction` to be this side's inbound direction
      (`side.ReceiveDirection()`).
   2. If that fails: add a Rejected inbox row and an audit event `receive.bundle_rejected`. Still call
      `CommitReplay()` (the QR session itself was genuine), then `Reset()`.
   3. Otherwise call `InboxRepository.AddMessagesAsync(all, bundleId, manifest.SessionId, engine.K)`: one transaction,
      duplicates skipped.
   4. Then call `BridgeSignals.Inbox.Set()`, write the journal and an audit event `receive.bundle_stored` (first/last
      sequence, added, duplicates), call `engine.CommitReplay()`, and add an inbox row such as
      "bundle 1042–1061 · 20 messages (2 duplicates)".
   - **Don't** write bundles to the payload store (`_store.Save`). The Inbox is the store; keep one copy of each
     payload on disk (envelopes are not encrypted — decision 23).
   - If the Inbox write fails: audit `receive.store_failed` and show it. **Don't** call `CommitReplay()`. Call
     `Reset(settle: false)`, so the same session can still be received while the sender keeps airing it.
   - The database call is async, so don't block the UI thread. The engine stays paused (`Completed` stays set) until
     you call `Reset`.
5. Payloads that are not `.qbb` (files, simulator payloads) keep today's behaviour.

## Check

1. Run `dotnet test All.slnx`.
2. End to end on one PC:
   - Corp side: the Corp gateway and the Sender in Outbox mode, sharing `C:\QrBridgeDev\Corp\Data`.
   - DMZ side: the Receiver with `Bridge:Side=Dmz` and the `Gateway (Dmz)` profile, sharing
     `C:\QrBridgeDev\Dmz\Data`.
   - The DMZ gateway delivers to `http://localhost:5099`. Run a minimal listener there that answers
     `RETURN_CODE 0`, for example a small `HttpListener` script.
   - Point the camera at the stage.

   Expected: a SOAP call to the Corp gateway reaches `Done` in the DMZ Inbox, and the listener receives the
   caller's bytes unchanged. Re-airing the same bundle adds nothing (duplicates). A permit, order or card is a
   `RoundTrip` call: its caller is held and gets `RETURN_CODE 1596` after the hold (270 s) unless the DMZ Reply is also
   aired back to the Corp side — expected in this one-lane check.

## Done when

Both checks pass. Then run [update-handoff](update-handoff.prompt.md) (known issues 3 and 4, Integration Plan
step 4). Don't commit.
