---
description: 'Add the Outbox bundle columns and store methods (using the existing Aired light status), the first EF migrations and the bundle codec (Integration Plan step 2)'
agent: 'agent'
---

> **Done 27 Nov 2026** (handoff decisions 52, 54): bundles of up to 50 messages / 128 KB in strict order, `BundleCodec`
> (with a bundle id in the header), `ClaimBundleAsync` / `MarkAiredAsync(bundle, session)` / `ReleaseBundleAsync` /
> `AddMessagesAsync`, migrations `Initial` + `Bundles`, `SchemaAdoption` for older files. Kept as a record; do not run
> it again. New QrDiode work: `sourcecode/qrdiode/docs/qrdiode-pending-work.md`.

Implement step 2 of the [Integration Plan](../../docs/gateway-to-qrdiode/integration-plan.md): §2.2 (data model) and §2.3
(bundle codec). The code goes in `sourcecode/gateway/src/QrBridge.Shared`, the tests in `sourcecode/gateway/tests/QrBridge.Tests`. Nothing in `QrDiode.*`
changes in this step.

**Before implementing:** ask Rowshan to approve bundling, ordering and limits. The format and sizes below are
proposals, not settled decisions. Resolve how valid envelopes larger than the example bundle limit are carried;
priority order does not imply consecutive or increasing sequence numbers. Reconcile this prompt with the current
code and the integration plan before making changes.

## 1. Baseline migrations first, before changing any entity

Today the schema is created with `EnsureCreated`. Make the current model the first migration, so later changes are
upgrades:

```powershell
dotnet new tool-manifest                      # once; keep .config/dotnet-tools.json in the repo
dotnet tool install dotnet-ef --version 10.0.15
dotnet ef migrations add Initial --project sourcecode\gateway\src\QrBridge.Shared --startup-project sourcecode\gateway\src\QrBridge.Shared --context BridgeDbContext --output-dir Data\Migrations
```

The design-time factory (`BridgeDesignTimeFactory`) is in `Data/Contexts/`. There is one database per machine,
`qrbridge.db` (decision 47 of `docs/handoff.md`). `DatabaseInitializer` already calls `MigrateAsync` once
migrations exist. But a database made by `EnsureCreated` has the tables and no `__EFMigrationsHistory`, so `Initial`
would fail with "table already exists". Design and test a safe upgrade path that verifies the actual existing
schema against the baseline before recording a migration. The presence of `Outbox` or `Inbox` alone is not enough.
Reject incompatible or partial schemas explicitly; never mark them as migrated or delete production data.

From now on every entity or enum change needs `dotnet ef migrations add <Name>`. EF refuses
to migrate when the model has pending changes.

## 2. Data model (§2.2)

- **Don't add a status.** Since 24 Nov 2026 (V6 fix tracker step 5a) each row has two status groups (decision D24):
  Outbox `LightStatus` `Pending`/`Sending`/`Aired`/`Received`/`Failed` + `ServiceStatus`
  `Waiting`/`Answered`/`Unknown`/`Refused`/`Expired`/`NotAvailable`, with `LightComment` and `LightUpdatedUtc`.
  `OutboxLightStatus.Aired` already exists, and so does `OutboxRepository.MarkAiredAsync(IReadOnlyCollection<Guid> messageIds)`
  (V6 fix step 5b, 24 Nov: only rows still `Sending` → `Aired`, sets `LightUpdatedUtc`, clears `LockedUtc`). Keep the
  existing names: they are stored as text and used in CHECK constraints. Don't build the same thing twice.
- `OutboxMessage`: `BundleId` (Guid?), `QrSessionId` (Guid?); add an index on `BundleId`. No `AiredUtc`:
  `LightUpdatedUtc` records when it was aired.
- `InboxMessage`: `BundleId` (Guid?), `QrSessionId` (Guid?).
- Then `dotnet ef migrations add Bundles`. No enum changes, so the CHECK constraints stay the same;
  check that the generated migration keeps all rows and indexes.

## 3. Store methods

`OutboxRepository` (follow `ClaimNextAsync`: a short-lived context and an optimistic claim):

- Proposed `ClaimBundleAsync(int maxMessages, int maxBytes, CancellationToken ct)` returns claimed rows in the
  same priority and sequence order as `ClaimNextAsync`
  plus a new `BundleId`, or null. In one transaction:
  1. pick the oldest due `Pending` rows (`NextAttemptUtc` null or past) whose bundle size fits `maxBytes`, always
     at least one row;
  2. run `UPDATE … SET LightStatus='Sending', LightUpdatedUtc=now, BundleId=@b, LockedUtc=now, Attempts=Attempts+1 WHERE MessageId IN (…) AND LightStatus='Pending'`;
  3. return only the rows that were actually claimed.
- `MarkAiredAsync(Guid bundleId, Guid qrSessionId, CancellationToken ct)`: an overload of the existing
  `MarkAiredAsync(messageIds)` (same rule: only rows still `Sending` → `Aired`; sets `LightUpdatedUtc`, clears
  `LockedUtc`) that also sets `QrSessionId` for every row of the bundle. `ServiceStatus` stays `Waiting`.
- `ReleaseBundleAsync(Guid bundleId, string reason, TimeSpan retryDelay, CancellationToken ct)`: `LightStatus`
  `Sending` → `Pending`, with `NextAttemptUtc = now + retryDelay`. Clear `BundleId` and `LockedUtc`, and set
  `LightComment` and `LightUpdatedUtc`. Not a failure: nothing was aired. The Sender passes zero after a stage close or
  operator skip, and about 30 s after an encode error, so a broken bundle cannot spin.
- `ResetSendingAsync`: also clear `BundleId`.
- `GetCountsAsync` / `OutboxCounts`: nothing to add — `Light` already lists every `OutboxLightStatus`, `Aired`
  included, and `OldestUndeliveredUtc` already covers `Pending`/`Sending`/`Aired`. Keep `/health` and the tests that
  read the counts in step.
- No retention or purge: rows are never deleted automatically (decision D28, 24 Nov). `Aired` rows stay until
  Receipts move them to `Received` (V6 fix tracker steps 10–11); operators archive rows manually.

`InboxRepository.AddMessagesAsync(IReadOnlyList<(MessageHeader Header, byte[] MessageBytes)> messages, Guid bundleId, Guid qrSessionId, CancellationToken ct)`
returns `(int Added, int Duplicates)`. Use **one** transaction. Skip MessageIds that are already present, and also
duplicates inside the batch. Map rows the same way `AddMessageAsync` does.

## 4. Bundle codec (§2.3): `sourcecode/gateway/src/QrBridge.Shared/Bundles/BundleCodec.cs`

Little-endian (`BinaryPrimitives`), in the style of `Serialization/MessageSerializer.cs`:
`"QBB1"` · version (1 byte) · count (uint16) · firstSeq (int64) · lastSeq (int64) · count × { length (int32) · envelope bytes }.

- `byte[] Build(IReadOnlyList<(long Sequence, byte[] Envelope)> items)` and
  `Bundle Parse(ReadOnlySpan<byte> data, int maxMessages, int maxEnvelopeBytes)`.
- The parser is bounded:
  - count is 1..`maxMessages`;
  - each length is 1..`maxEnvelopeBytes` (`BridgeOptions.MaxPayloadBytes` + the 64 KB header limit and framing);
  - the lengths add up exactly to the remaining bytes;
  - `firstSeq ≤ lastSeq`.

  Any problem → `InvalidDataException`; no other exception type may escape.
- `BundleCodec.FileName(firstSeq, lastSeq)` → `bundle-{firstSeq}-{lastSeq}.qbb`.

## Tests

- `RepositoryTests`:
  - the claim respects `maxMessages`, `maxBytes`, order and `NextAttemptUtc`, and a row is never in two bundles;
  - the aired and release transitions;
  - `ResetSendingAsync` clears bundles;
  - the bulk insert is idempotent (on re-insert, and with duplicates within one batch).
- New `BundleCodecTests`:
  - round trip with one message and with many;
  - wrong magic or version, truncated input, extra bytes, a count of 0 or above the limit, and a negative or
    oversized length all throw `InvalidDataException`.
- Migrations:
  - a fresh database ends on the latest migration;
  - a database in the **old EnsureCreated state** also ends on the latest migration, with its data kept. Simulate
    that state by applying only `Initial` (`IMigrator.MigrateAsync("<Initial id>")`), inserting a row, then dropping
    `__EFMigrationsHistory` (and `__EFMigrationsLock` if present). Then run `DatabaseInitializer.InitializeAsync`.

## Done when

`dotnet test All.slnx` passes. Then run [update-handoff](update-handoff.prompt.md) (known issues 5 and 6, test
counts, Integration Plan step 2) and explain to Rowshan what changed in the database. Don't commit.
