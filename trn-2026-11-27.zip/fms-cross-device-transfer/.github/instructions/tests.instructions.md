---
description: 'Test conventions for QrBridge.Tests and QrDiode.Core.Tests'
applyTo: 'sourcecode/gateway/tests/**,sourcecode/qrdiode/tests/**'
---

# Tests

- xUnit 2.9. Run everything with `dotnet test All.slnx`; one project with `dotnet test sourcecode\gateway\tests\QrBridge.Tests`.
  Expected at handoff: QrBridge.Tests 576 passed + 7 skipped (the SQL Server tests), QrDiode.Core.Tests 138 passed
  (27 Nov 2026, after QrDiode certificate mode; `X509HandshakeTests` use the in-memory CA in `TestPki.cs`, never the
  Windows Certificate Store).
- **Read-only UI tests** are in `Ui/`: `Ui/Infrastructure/UiBrowser.cs` signs in through the login form (with its
  antiforgery token) and keeps the cookies; `UiCorpFixture` is a Corp gateway holding one stored feed. Assert what a
  person reads (`UiBrowser.Text` decodes the HTML) and keep `UiReadOnlyTests` green (no row changes while browsing).
  `Ui/Infrastructure/DemoTraffic.cs` plays a busy day on two gateways (every kind and status); `UiDemoDataTests` renders
  every page of both UIs on it, and with `QRBRIDGE_DEMO_ROOT` set it writes the sample databases there for looking at the UI.
- **Gateway integration tests** use `Gateway/Infrastructure/GatewayHost.cs`: the real `Program` (routes.json, EF/SQLite,
  workers) in memory with its data in a temp folder. Two hosts sharing a root = a Corp and a DMZ
  gateway. Override settings through the `settings` dictionary (e.g. `"Routing:AcceptUnlisted" = "true"`). The host runs
  in the side's environment (`Corp`/`Dmz`, as in IIS) unless `environment:` is given, and sets
  `Gateway:Receiver:AllowHttp = true` because its fake services are `http://` (set it to `"false"` to test the https rule).
- **SQL Server tests** (`SqlServerRepositoryTests`, `Gateway/SqlServerGatewayTests`) use `[SqlServerFact]`: they run
  only when `QRBRIDGE_SQLSERVER` holds a connection string to a server where the login may create databases (LocalDB:
  `Server=(localdb)\MSSQLLocalDB;Integrated Security=true;TrustServerCertificate=true`), otherwise they are skipped.
  `Gateway/Infrastructure/SqlServerTestDatabase.cs` gives each gateway its own throw-away database (`Settings()` for a
  `GatewayHost` or `TwoGatewayBench`, `Options()` for repositories) and drops it afterwards. Every other test runs on
  SQLite. Resolve repositories by their interfaces (`host.Get<IOutboxRepository>()`): only those are registered.
- **The real downstream service** is `FakeSoapService` (records requests, answers with `Responder`); pass
  `fake.CreateHandler` as the DMZ host's `receiverHandler`.
- **Real WCF clients** (`Gateway/Infrastructure/Wcf.cs` + the contract interfaces `IFC2FMSInterface.cs`, `IVZ2TLSInterface.cs`, `INewService.cs`) talk to the in-memory gateway through a binding parameter that swaps WCF's
  HTTP handler — use them to prove caller compatibility.
- **Payloads** come from `Samples/` (the fms-interface-simulator's 43 templates). `SenderTests.Cases` maps every
  template to its interface and expected answer, and `Every_simulator_template_is_covered` fails if a template is not
  mapped — add a case for every new sample **and** update the file count it asserts (43).
- The QR link is simulated in `EndToEndTests.CarryAcrossAsync` by copying the envelope from one host's Outbox to
  the other's Inbox — exactly what the QR apps will do. For end-to-end scenarios use
  `Gateway/Infrastructure/TwoGatewayBench.cs` (Corp + DMZ gateways, scripted real service, Corp restart) with
  `FakeLight.cs` (the link running in both directions: claim → Aired → the other Inbox; per row 0 copies = lost
  session, 2 = duplicate; each lane can be paused). Re-air needs `Gateway:ReceiptTimeoutSeconds` 1 and
  `Gateway:MaintenanceIntervalSeconds` 10 (its floor) on the re-airing side.
- **Far side and Heartbeat messages** are tested in `Gateway/HeartbeatTests.cs` (step 17): a `TwoGatewayBench` with the
  light on or off; "time passes" is simulated by moving `ReceivedUtc` back in the Inbox of `qrbridge.db`, and `FarSideMonitor`'s
  methods take the current time as a parameter. Prove that a Heartbeat is heard, never confirmed and never re-aired,
  and that Heartbeats don't pile up while the light is down (4 tests).
- Tests must not depend on the network, a camera or IIS; they need Windows (named events).
- Assert behaviour callers depend on (reply shape and values, bytes passed verbatim), not implementation details.
- **File layout** as in the main code: one test class, fixture, helper or interface per file; a helper's records in its file
  (`CapturedRequest` in `FakeSoapService.cs`, `FmsEndpoint` in `SoapCalls.cs`).
