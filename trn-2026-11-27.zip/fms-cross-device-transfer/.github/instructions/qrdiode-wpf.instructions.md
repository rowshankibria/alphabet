---
description: 'QrDiode optical link: Core protocol library and the WPF Sender/Receiver apps'
applyTo: 'sourcecode/qrdiode/src/QrDiode.Core/**,sourcecode/qrdiode/src/QrDiode.Sender/**,sourcecode/qrdiode/src/QrDiode.Receiver/**,sourcecode/qrdiode/src/QrDiode.KeyCeremony/**,sourcecode/qrdiode/src/Shared/**'
---

# QrDiode (Core, Sender, Receiver, KeyCeremony)

Background: `sourcecode/qrdiode/docs/protocol-development-notes.md` (historical protocol design and as-built notes), `sourcecode/qrdiode/docs/user-guide.md` (operating the apps),
`sourcecode/qrdiode/docs/wpf-tutorial.md` (WPF for an Angular developer). The work to connect these apps to the shared message database (`qrbridge.db`) is
designed in `docs/gateway-to-qrdiode/integration-plan.md` §2.

## Structure rules

- **Keep the project structure** (folders, project names, the linked `sourcecode/qrdiode/src/Shared/PayloadView.cs`). Add features inside
  the existing projects; don't split or rename them. These projects belong to `sourcecode/qrdiode/QrDiode.slnx`; when the
  Sender/Receiver need `QrBridge.Shared`, reference `..\..\..\gateway\src\QrBridge.Shared\QrBridge.Shared.csproj` and
  add that project to `QrDiode.slnx` too (one copy of the code, never a duplicate).
- **`QrDiode.Core` stays independent of the SOAP Gateway and UI-free:** no EF, SQLite, SOAP or WPF references. It may reference only
  the BCL, `System.IO.Hashing` and `ProtectedData`. Gateway and shared data code (repositories, envelope, bundles) lives in `QrBridge.Shared`,
  which the Sender and Receiver may reference.
- Never weaken the receive verification order in `ReceiveEngine`: CRC → manifest signature (low-S only) →
  addressed-to-us → anti-replay → frame MAC on every data frame → LT decode → ciphertext hash → AES-GCM →
  decompression cap (exact size) → content gate. Protocol v2 (26 Nov 2026): the manifest carries no plaintext hash
  (the receiver computes it) and carries the sender's counter run id. Protocol v3 (27 Nov 2026) adds the CertHello
  frame (certificate mode): judged only when `ReceiveOptions.CertHello` is set and no session is in flight; the host,
  not the engine, pins the peer. Any wire change bumps
  `FrameFormat.ProtocolVersion` and needs both apps updated together.
- The replay guard is committed by the **host**, after the payload is stored (`engine.CommitReplay()`), never by the
  engine. After a rejection the host does **not** call `Reset()` (the engine clears itself; a late reset drops the
  next session). After a failed store: `Reset(settle: false)`.
- Keys, trust and pairing go through **`IKeyExchange`** (`KeyExchanges.Load(options)`, chosen by
  `"KeyExchange"` in `C:\ProgramData\QrDiode\keyexchange.json`: `KeyCeremony` by default, or `Certificate`). The Sender, the Receiver, `ReceiveEngine`
  (`ReceiveOptions.Pairing` = an `IPairingVerifier`) and the KeyCeremony CLI (`IKeyExchange.Commands`) never name a
  mechanism; never call `CngEndpointKeys.OpenOrCreate` / `X509EndpointKeys.Open` / `new DirectoryTrustStore` from them.
  A new mechanism = a `KeyExchangeKind` value, an `IKeyExchange` class in `QrDiode.Core/Crypto/Exchange/` and one case in
  `KeyExchanges.Load`. Settings for another mechanism or half a mechanism are refused, never a silent fallback.
  `KeyPolicy` holds the key ceremony's rules (`"Production"`, demo endpoints).

## WPF rules

- Never block the UI thread: database, file and camera work is `async`; never `.Result` / `.Wait()`.
- Only the UI thread touches UI objects: from background loops use `Dispatcher.Invoke`/`BeginInvoke` (an
  `ObservableCollection` changed off the UI thread throws).
- Long-running loops (sender pump, camera) are tasks with a `CancellationToken`, stopped on window close / app exit.
- Follow the existing code-behind style of each window; don't introduce an MVVM framework without asking.

## Known issues to keep in mind

- `TransmitEngine.TrimQueue` skips waiting **droppable** items beyond 14 (only the simulator's) — Outbox items must
  be enqueued with `droppable: false` (the default).
- The Receiver's `IsDuplicateContent` check would swallow a re-aired bundle: keep the Gateway-mode branch (bundles) at
  the top of `HandleCompletion`, before it (pending work B-06, done 27 Nov).
- Pending work, with status: `sourcecode/qrdiode/docs/qrdiode-pending-work.md`.
- The Receiver gets SQLite only through `QrBridge.Shared` (EF Core 10.0.15 → one SQLitePCLRaw 2.1.13). Never add a
  direct `Microsoft.Data.Sqlite` / `SQLitePCLRaw` package to a QrDiode app (one native SQLite per process).
- **Gateway mode** (`"QrDiode:Mode": "Gateway"`, since 27 Nov 2026): the Sender's only source is the gateway's Outbox
  (`Transmit/OutboxSource.cs` → `QrBridge.Shared` `OutboxBundler`); every item outcome is written back through
  `TransmitEngine.ItemFinished` (Sent → Aired, Skipped → released at once, Failed → released after 30 s). The Receiver
  accepts gateway bundles only (`.qbb`, parsed by `InboxBundleWriter` *before* the "same content" check), stores them in
  the Inbox, then calls `CommitReplay()`, and keeps no payload (no file, snippet or preview). Database work runs off the
  UI thread (`Task.Run`: SQLite's async calls are synchronous). Both apps read the gateway's database settings from their `"QRDatabase"` section (the same values as the gateway's `"GatewayDatabase"`); they refuse to start while a former `"Bridge"` section is still there.
- Keys and state are per Windows user (`%LocalAppData%\QrDiode`, CNG user store): run the apps as the kiosk user.
- Native `ZXing.dll` fails to load from very deep folders (MAX_PATH): keep the solution at a short path.

## Tests

`sourcecode/qrdiode/tests/QrDiode.Core.Tests` (138 tests) must stay green; add tests for every protocol change (see
`OpticalLoopbackTests` for a camera-free end-to-end through real QR images).
