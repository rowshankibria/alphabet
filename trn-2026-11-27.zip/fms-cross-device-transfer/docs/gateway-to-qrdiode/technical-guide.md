# Gateway-to-QrDiode — technical guide

This is a developer and operations reference, not a second system architecture. Start with the
[current architecture](architecture.md) for the visual Inbound and Outbound round trips and current status;
use the [workflow](../../sourcecode/gateway/docs/workflows/gateway-qrdiode-workflow.md) for implementation details
and the [integration plan](integration-plan.md) for unfinished work.

How the generic SOAP gateway carries **unchanged WCF/SOAP calls** across a light-only air gap, and how the whole
project fits together: components, message flow, storage, security, configuration, deployment, testing and status.

**Names used in this guide:** **Gateway-to-QrDiode** is the overall system. **SOAP Gateway** is the IIS application
that queues callers' requests and delivers arrived requests to the real services. **QrDiode optical link** is the
Sender screen and Receiver camera that carry messages across the light-only air gap.

Existing technical names remain unchanged: `QrBridge.*`, filenames and quoted responses. The settings the gateway
shares with the QR apps are in its `GatewayDatabase` section (the QR apps' `QRDatabase`; `Bridge` before 27 Nov
2026). The route mode `Bridge` means "queue the request and answer immediately"; it is not the system name.

| | |
|---|---|
| **Status** | 25 Nov 2026. Gateway and shared data layer: built and tested (451 tests), including the round trip between two gateways (tracker steps 10a, 10b), permits, orders and cards held for the real answer (step 10c), re-airing unconfirmed messages (step 11), the Registered Tags GET as a round trip (step 12), end-to-end fault tests with a fake light (step 13), priority classes (step 14), per-target credentials, the caller's address and delivered bodies cleared (step 15), per-service size limits (step 16), heartbeats, "far side last seen" and old messages recognised by their number (step 17), and the operations hardening notes with an administrator warning (step 18, [§12.4](#124-deploy-per-side)); since 25 Nov one database per machine, `qrbridge.db` ([§6.1](#61-one-database-per-machine)). Connecting the QR apps to the database: not built yet ([§14](#14-status-open-decisions-and-next-steps)). |
| **Solutions** | `sourcecode/gateway/QrGateway.slnx` (gateway + Shared), `sourcecode/qrdiode/QrDiode.slnx` (QrDiode); `All.slnx` at the root holds both |
| **Quick reference** | [gateway.md](../../sourcecode/gateway/docs/gateway.md) (one page: how a call is handled, catalogue, Receiver part, limits) |
| **Architecture and plan** | [Current system architecture](architecture.md) · [Integration plan (remaining work)](integration-plan.md) · [QrDiode protocol development notes](../../sourcecode/qrdiode/docs/protocol-development-notes.md) |
| **Payload source** | The separate fms-interface-simulator project; this repository contains gateway contracts and test samples. |
| **Handoff** | [../handoff.md](../handoff.md) — decisions, verification state, known issues and next steps (start here on a new machine) |

Read [§1](#1-the-problem)–[§5](#5-a-messages-journey-step-by-step) for the idea. The rest is reference.

## Contents

1. [The problem](#1-the-problem)
2. [Why WCF calls are hard to carry across an air gap](#2-why-wcf-calls-are-hard-to-carry-across-an-air-gap)
3. [The solution at a glance](#3-the-solution-at-a-glance)
4. [How the generic gateway solves each WCF issue](#4-how-the-generic-gateway-solves-each-wcf-issue)
5. [A message's journey, step by step](#5-a-messages-journey-step-by-step)
6. [Data and storage](#6-data-and-storage)
7. [Security](#7-security)
8. [Reliability and operations](#8-reliability-and-operations)
9. [The QrDiode side (the light link)](#9-the-qrdiode-side-the-light-link)
10. [Solution layout and code map](#10-solution-layout-and-code-map)
11. [Configuration reference](#11-configuration-reference)
12. [Build, test, publish and deploy](#12-build-test-publish-and-deploy)
13. [How to add or change a service](#13-how-to-add-or-change-a-service)
14. [Status, open decisions and next steps](#14-status-open-decisions-and-next-steps)
15. [Glossary](#15-glossary)
- [Appendix A. Wire examples](#appendix-a-wire-examples)
- [Appendix B. Design record decisions and what changed](#appendix-b-design-record-decisions-and-what-changed)

---

## 1. The problem

### 1.1 Islanding mode

The corporate network (**CorpNet**) and the FMS side (**ECC / AECC DMZ**, also called OpNet) are normally connected
through firewalls. In **islanding mode** those firewalls are cut: no copper, no fiber. The only link left is light — a
screen showing QR codes on one side, a camera reading them on the other. There are two one-way optical lanes:

| Lane | Screen | Camera | Carries |
|---|---|---|---|
| 1 (outbound) | DMZ | CorpNet | FMS updates to the corporate systems |
| 2 (inbound) | CorpNet | DMZ | corporate apps' calls to the FMS-side services |

ECC is the primary site (active optical pair); AECC is the standby pair. In normal operation none of the Gateway-to-QrDiode system is in
the path: the corporate load balancer routes straight to the DMZ RR servers.

### 1.2 The rules we work under

| Rule | What it forces |
|---|---|
| The callers cannot change. Rapid Restore, MAXIMO and the other corporate apps are not our project. | The gateway must be indistinguishable from the services they call today. |
| Corporate apps reach the services only through the corporate **load balancer** (e.g. `https://a/...svc` → LB). | In islanding mode the LB is pointed at the Corp gateway. That is the only change on CorpNet. |
| The FMS-side outbound services may be re-pointed **by configuration only**. | The DMZ gateway stands in for the corporate systems they call. |
| No extra Windows service; keep the existing Sender and Receiver project structure. | Each side runs the gateway (IIS) and two separate WPF apps: Sender and Receiver. |
| .NET 10, WPF, SQLite (EF Core). | |

### 1.3 Who calls what

From the fms-interface-simulator (`Configuration.xml`, WSDLs, message templates):

**CorpNet → DMZ** (corporate apps calling FMS-side services — in the gateway catalogue today)

| Caller | Endpoint path | Kind | Fire-and-forget operation | Messages |
|---|---|---|---|---|
| Rapid Restore FCR | `/FMS_FC2FMSInterface/FC2FMSInterface.svc` | WCF | `SendToFMS` | REQUEST_FOR_PERMIT, RFP_FCR_RESPONSE, WP_FCR_RESPONSE, FIELD_GROUNDS_ONLY, FGO_FCR_RESPONSE, RETURN_PERMITS, LIFT_CAUTION, FAULT_RESPONSE, WP_ETC_UPDATE, FEEDER_ETC_UPDATE |
| Rapid Restore FOD | `/FMS_FOD2FMSInterface/FOD2FMSInterface.svc` | WCF | `SendToFMS` | FOD_MOVE_RESPONSE, RETURN_MOVE, RETURN_FAULT, FOD_FAULT_RESPONSE, RETURN_TAGS, FOD_TAG_RESPONSE, CREW_ASSIGNMENT, FOD_CREW_RESPONSE |
| Rapid Restore SSO | `/FMS_SSO2FMSInterface/SSO2FMSInterface.svc` | WCF | `SendToFMS` | SSO_RESPONSE, RETURN_ORDER |
| Rapid Restore SSO | `/FMS_SSO2TOMSInterface/SSO2TOMSInterface.svc` | WCF | `SendToTOMS` | TOMS_SSO_RESPONSE, TOMS_RETURN_ORDER, VOLTAGE_REDUCTION_REQUEST |
| Rapid Restore SSO | `/FMS_SSO2TLSInterface/SSO2TLSInterface.svc` | WCF | `SendToTLS` | TLS_SSO_RESPONSE, TLS_RETURN_ORDER |
| Rapid Restore SSO | `/FMS_SSO2DSOInterface/SSO2DSOInterface.svc` | WCF | `SendToDSO` | DSO_SSO_RESPONSE, DSO_RETURN_ORDER |
| Fault Correlation (FTC) | `/FMS_FTC2FMSInterface/FTC2FMSInterface.svc` | WCF | `SendToFMS` | FAULT_CORRELATION |
| Verizon eBonding | `/VZ2TLSWebService/VZ2TLSInterface.asmx` | ASMX | `SendToTLS` (returns `long`) | createTicketResponse, getTicketResponse |
| DSS / No. 9 | `/FMSInterface/RR_DSSFMSService.wsdl` | SOAP Toolkit (RPC/encoded) | `SendToFMS` (returns `int`) | FOD_MOVE_RESPONSE, NO9_MOVE_RESPONSE, RETURN_MOVE |
| Legacy endpoints of FCR, FOD, SSO→FMS/TOMS/TLS, FTC | `/FMSInterface/RR_*Service.WSDL` | SOAP Toolkit | `SendTo*` | as above |

Plus operations that need a **live answer**, which an instant reply cannot give: `GetFromFMS` / `GetFromTOMS` / `GetFromTLS`
(AUTHORIZE_USERS, GET_FEEDER_INFO, WITHDRAW_RFP, GET_RELAY_TARGET), XA/21 `ProcessMessage`, BFC `ProcessMessage` and the
Registered Tags `GET` report (how each is handled: [§4.7](#47-calls-that-need-a-live-answer)).

**DMZ → CorpNet** (FMS/TOMS/TLS/DSO interface clients calling corporate systems): CARD_CREATE / CARD_ACTIVATION /
CARD_CUTOUT, RFP_DO_RESPONSE, ISSUE_WORK_PERMIT, ISSUE_ORDER, TOMS/TLS/DSO_ISSUE_ORDER, DO_FAULT_RESPONSE,
REPLACE_CERTIFIED_TAG, GET_FAULT_CORRELATION, Verizon ticket requests, and MAXIMO / OSS / NRI. The endpoints those
clients call on the corporate side are **not in the simulator repository**; they are in the catalogue from the DMZ
interface services' client proxies (11 services, see §4.4), but their paths and contracts still need confirming.

---

## 2. Why WCF calls are hard to carry across an air gap

1. **The caller waits for an answer.** Every interface is HTTP request/reply. The caller sends a request and blocks
   until a reply arrives (the simulator waits up to 5 minutes). The light link is one-way per lane and has no
   real-time return path, so the real service's answer cannot come back in time.
2. **The caller reads the answer.** A WCF FMS service returns a string such as
   `<RESPONSE><STATUS><RETURN_CODE>0</RETURN_CODE><ERROR_MESSAGE/></STATUS></RESPONSE>`. A non-zero code means
   "refused" and the operator's form stays open. The ASMX Verizon service returns a `long`; the SOAP Toolkit services
   return an `int`. A reply without the right value is a failure to the caller.
3. **WCF clients are strict about the reply's shape.** A generated WCF proxy only accepts a reply with the exact wrapper
   element, namespace, result element and type it expects, in the same SOAP version, with matching WS-Addressing
   headers where used, and HTTP 202 with no body for one-way operations. "Almost right" is an exception in the caller.
4. **Many service styles behind one load balancer.** WCF `.svc` (document/literal), ASMX `.asmx` (also exposing SOAP
   1.2 bindings), old SOAP Toolkit `*.WSDL` endpoints using RPC/encoded SOAP, and a plain HTTP `GET` report. The five
   legacy FMS endpoints (FCR, FOD, SSO, FTC, DSS) all share the **same** `SOAPAction`
   (`http://tempuri.org/action/FMSInterface.SendToFMS`), so the action alone cannot tell them apart.
5. **The callers cannot be changed.** Same URL, same path, same `SOAPAction`, same reply. The load balancer's health
   probe must keep getting HTTP 200. (The callers, as the fms-interface-simulator shows, use compiled proxies and never
   download a WSDL at runtime.)
6. **Payloads must arrive unchanged.** The business XML travels as a string inside the SOAP body and has quirks:
   `MSG_ID` is a static template value (`"456"`), many headers say `SOURCE_APPLICAION` (a typo the receivers expect),
   Verizon replies are whole SOAP envelopes inside the string, cancellations are ANSI tML-TA documents. Rebuilding the
   XML from objects risks changing any of this.
7. **Some calls are queries.** `GetFromFMS` and friends exist to *read* data. An instant "OK" is not an answer to them.
8. **A per-contract approach doesn't scale.** Hosting each contract with CoreWCF means a hosted contract, a client
   contract and a handler per service — about nine on the Corp side alone, more on the DMZ side, more for every new
   service — plus redeploys. And CoreWCF does not host the RPC/encoded style that DSS and the legacy endpoints use.

---

## 3. The solution at a glance

### 3.1 The picture

The [system architecture](architecture.md) is the authoritative overview, including both vertical round trips.

### 3.2 What runs on each machine

The same software runs on both sides; the setting `GatewayDatabase:Side` (`Corp` or `Dmz`) picks the role.

| Program | Deployed as | Job |
|---|---|---|
| **QrBridge.Gateway** | IIS site | **Sender part** (`Ingress/`): stands in for the services on the other side — reads the call, stores it, replies. **Receiver part** (`Egress/`): replays calls that arrived over the light to the real services on its own side. **Maintenance:** recovery, the lost-message check, heartbeats, `/health`. |
| **QrDiode.Sender** | WPF exe (kiosk user) | Shows queued messages as a QR stream on the screen facing the other side. *(Database connection: planned.)* |
| **QrDiode.Receiver** | WPF exe (kiosk user) | Reads the other side's QR stream with a camera, verifies it, stores the messages for the gateway. *(Database connection: planned.)* |

The programs never call each other. On one machine they meet only at the folder `C:\ProgramData\QrBridge\Data`
(one SQLite database, `qrbridge.db`) and two named Windows events used as doorbells.

### 3.3 Why a generic SOAP gateway

Every forwarded operation has the same shape: **one XML string in, one value out**, over SOAP. So the gateway does not
need to understand any contract. It needs to:

1. **recognise** the call (which service, which operation),
2. **store** it exactly as received,
3. **answer** in the shape the caller expects, and
4. **replay** it, unchanged, on the other side.

| | CoreWCF with typed contracts (original plan) | Generic SOAP gateway (built) |
|---|---|---|
| Code per service | hosted contract, data contracts, client, handler, registration | none — one entry in `routes.json` |
| SOAP 1.1, 1.2, WS-Addressing | per binding configuration | all handled by one parser and reply writer |
| RPC/encoded (DSS, legacy `*.WSDL`) | not supported | handled |
| Payload | rebuilt from objects | the caller's bytes, unchanged |
| New service | code + build + deploy | config + app pool recycle |
| Unknown service | impossible | possible (`Routing:AcceptUnlisted`) |

---

## 4. How the generic gateway solves each WCF issue

### 4.1 Summary

| # | Issue ([§2](#2-why-wcf-calls-are-hard-to-carry-across-an-air-gap)) | How the gateway solves it | Code |
|---|---|---|---|
| 1 | The caller waits | Store the call durably first. Feeds (`Bridge`): reply at once (milliseconds), deliver later. Permits, orders, cards and queries (`RoundTrip`): hold the caller for the far side's real answer, up to `Gateway:Hold`; then a readable "pending" (1596) or "not available" (1599) answer. | `Ingress/SenderEndpoint.cs`, `Ingress/OutboxWriter.cs` |
| 2 | The caller reads the answer | Reply profiles hold the exact success value the real service gives (`RETURN_CODE 0`, `0`). | `routes.json` → `ReplyProfiles` |
| 3 | Strict reply shape | The reply is built from the request: same SOAP version, namespace, wrapper/result naming, WS-Addressing `Action`/`RelatesTo`, 202 for one-way. | `Ingress/Soap/SoapReplyWriter.cs` |
| 4 | Many styles | One parser for SOAP 1.1/1.2, document/literal and RPC/encoded. The service is found by **path**, the operation by the **SOAP body element**. | `Ingress/Soap/SoapRequest.cs`, `Routing/RouteTable.cs` |
| 5 | Callers cannot change | The original paths and actions; `GET /health` (HTTP 200) for the load balancer's probe. No WSDL is served: the callers never download one. | `routes.json`, `Controllers/HealthController.cs` |
| 6 | Payloads unchanged | The request body is stored and replayed byte for byte. The gateway only *reads* labels from it. | `QrBridge.Shared/Serialization/MessageSerializer.cs`, `Egress/SoapForwarderHttpClient.cs` |
| 7 | Queries | An explicit **Unavailable** mode answers with a clean, readable error (`RETURN_CODE 1599`) instead of a hang. | `OperationMode.Unavailable` |
| 8 | Scale | Services are configuration. With `AcceptUnlisted` the gateway forwards calls to any SOAP service it has never seen. | `Routing/RouteTable.cs` |

### 4.2 One endpoint for every service

`Program.cs` calls `MapGatewayEndpoints()` (`Initializer/EndpointRegistration.cs`, i.e. `MapControllers()`); the two thin controllers in `Controllers/` are the only HTTP entry points:

| Route | Controller → handler | Purpose |
|---|---|---|
| `GET /health` | `HealthController` | queue depths and heartbeats (JSON); the load balancer's health probe |
| `POST /{**path}` | `SenderSoapController` → `SenderEndpoint` | every SOAP call, whatever the path |
| `GET /{**path}` | `SenderSoapController` → `SenderEndpoint.HandleGetAsync` | only a route marked `"HttpGet": true` whose callers are on this side: the Registered Tags report on the Corp gateway (step 12, D18) |

Any other GET, and every HEAD, gets HTTP 405 ([§4.9](#49-get-requests-and-health-probes)). The SOAP controller is deliberately not
`[ApiController]` and binds no parameters: the body must stay raw bytes and every error must be a SOAP fault, not JSON.

The path *is* the service. IIS must hand every request to the gateway — including `*.svc`, `*.asmx` and `*.wsdl`. That
needs an app pool with **No Managed Code** and **no WCF HTTP Activation** feature on the server (with it installed,
IIS gives `*.svc` to .NET Framework WCF). Set the first on the app pool and make sure the second is not installed (§12.4).

### 4.3 Reading any SOAP request without its contract

`SoapRequest.TryParse` reads only what the gateway needs, from any SOAP request:

| Read | From | Example |
|---|---|---|
| SOAP version | the Envelope's namespace | 1.1 = `http://schemas.xmlsoap.org/soap/envelope/`, 1.2 = `http://www.w3.org/2003/05/soap-envelope` |
| Operation | local name of the first element in `Body` | `SendToFMS` |
| Operation namespace | that element's namespace | `http://tempuri.org/` (WCF), `http://tempuri.org/message/` (SOAP Toolkit) |
| Style | first parameter has **no** namespace → RPC/encoded | DSS: `<XMLMsg>` is unqualified |
| Parameter value | text of the operation's first child element | the `<MESSAGE TYPE="…">` string in `sXML` / `XMLMsg` |
| Action | `wsa:Action` header, else the `SOAPAction` HTTP header, else the SOAP 1.2 Content-Type `action=` parameter | `http://tempuri.org/IFC2FMSInterface/SendToFMS` |
| WS-Addressing | `Action`, `MessageID`, `To` headers (2005/08 or 2004/08) | from WCF `WSHttpBinding` clients |

All XML is read with DTDs prohibited and no external resolution (no XXE, no entity expansion), and with a size cap.
Anything that is not a SOAP envelope is refused with HTTP 400.

`PayloadInspector` then reads a **label** from the parameter value: the FMS `MESSAGE/@TYPE` and `MSG_ID`; for a SOAP
envelope carried as a string (Verizon), the name of its Body element (`createTicketResponse`); otherwise the root
element name (`CancelTroubleReportResponse`). The label is used for the allow-list, logs and a database column — the
payload itself is never modified.

### 4.4 Deciding what to do: the route catalogue

`routes.json` lists every service the gateway stands in for. A call is resolved like this:

```
path (case-insensitive, normalised)  ──► service entry?        no ──► AcceptUnlisted? no ──► SOAP fault (allow-list)
                                                                                       yes ──► Bridge, automatic reply
                                          │ yes
                                          ▼
service.SenderSide == this side?      no ──► SOAP fault ("delivered here, not accepted here")
                                          │ yes
                                          ▼
body element = listed operation?       no ──► service.OtherOperations (default: Reject)
                                          │ yes
                                          ▼
operation Mode:  Bridge │ RoundTrip │ Echo │ Unavailable │ Reject   (per MESSAGE TYPE when the operation lists "Types")
```

| Mode | What happens | Stored? |
|---|---|---|
| **`Bridge`** | Allow-list check, backlog check, store, then reply OK at once. Used for **feeds** whose caller only needs "received": FMS2FSS, FMS2Dashboard, FMS2SSLog, FMS2VR, FTC2FMS(-Legacy) `SendToFMS`, VZ2TLS | yes |
| **RoundTrip** | Same checks and store as `Bridge`, then hold the caller (`Gateway:Hold`) and give it the real answer from the far side's Reply; when the hold runs out, the route's `OnHoldTimeout` answer ([§4.7](#47-calls-that-need-a-live-answer), built in tracker step 10a). Used for queries (`Unavailable`, 1599) and, since step 10c (D60), for **permits, orders, cards and their responses** (`Pending`, 1596) | yes |
| **Echo** | Reply with the request's value (the `EchoString` connectivity checks) | no |
| **Unavailable** | Reply "not available while islanded" — for operations that need a live answer | no |
| **Reject** | SOAP fault | no |

An operation that carries several kinds of message (`GetFromFMS`, `ProcessMessage`) can set the mode per
`MESSAGE/@TYPE` under `"Types"`; a type not listed follows the operation. The receiving gateway checks the same
per-type mode before it delivers.

The shipped catalogue (18 entries with callers on CorpNet, plus 11 with callers in the DMZ):

| Group | Services | Notes |
|---|---|---|
| WCF `.svc` | FC2FMS, FOD2FMS, SSO2FMS, SSO2TOMS, SSO2TLS, SSO2DSO, FTC2FMS | `SendTo*` RoundTrip (permits, orders, cards: held for the real answer; hold-timeout answer 1596, step 10c), except FTC2FMS `SendToFMS` (`FAULT_CORRELATION` feed: `Bridge`); `GetFrom*` RoundTrip (hold-timeout answer 1596, queries 1599, step 10a); `EchoString` Echo |
| ASMX | VZ2TLS | `SendToTLS` forwarded (`Bridge`) for `createTicketResponse` / `getTicketResponse` only — what the real handler accepts |
| SOAP Toolkit `*.WSDL` | DSS2FMS, FC2FMS-Legacy, FOD2FMS-Legacy, SSO2FMS-Legacy, SSO2TOMS-Legacy, SSO2TLS-Legacy, FTC2FMS-Legacy | RPC style, numeric replies; `SendTo*` RoundTrip (held; 1596, step 10c) except FTC2FMS-Legacy `SendToFMS` (`Bridge`); `GetFrom*` RoundTrip (held; hold-timeout answer 1596, step 10a) |
| Plain HTTP GET | RegisteredTags | `/FMS_ReportService/RegisteredTags.asmx/GetData`, `"HttpGet": true`, one operation `"GET"`: RoundTrip, `OnHoldTimeout: Unavailable`; the real report or HTTP 504 (step 12, [§4.9](#49-get-requests-and-health-probes)) |
| Live answers only | XA2FMS, IR2BFC | `ProcessMessage` per type: all Unavailable (SOAP fault) — the polls for good, the types decided as round trips (`DISPLAY_ERROR`, `DEVICE_STATUS_CHANGE`, `BUS_FAULT_CORRELATION_REQUEST`) until open question D23 (do they cross the gap at all?) is answered (D52) |
| DMZ → Corp, permits/orders/cards | FMS2FC (14 operations), FMS2FOD (8), FMS2SSO (4, incl. `SendPage`), TLS2SSO (6), TOMS2SSO (7), DSO2SSO (5) | RoundTrip, held for the real answer; hold-timeout answer 1596 (step 10c, D60). `FMS2FC.PortalSyncRequest` is a query (`PortalSyncDown`, 1599). `FMS2FC.IssueWorkPermit` too (D61), but pilot-only until open question D12 is answered (§4.7) |
| DMZ → Corp, feeds | FMS2FSS, FMS2Dashboard, FMS2SSLog, FMS2VR | `Bridge`: answered at once (FMS2VR operations are void, no reply profile) |
| DMZ → Corp, live answer | FMS2FTC | `GetFaultCorrelation` RoundTrip with `OnHoldTimeout: Unavailable` |

The Registered Tags report (`RegisteredTags.asmx/GetData`) is a plain HTTP GET, not SOAP. Since 24 Nov 2026 (V6 fix
step 12, D18) it is listed and carried as a round trip; before, it got HTTP 405 while islanded.

Each forwarded operation has an **allow-list** of message types (`AllowedTypes`) mirroring what the real service
accepts, so a payload the real service would refuse is refused at once — while the caller is still on the line — not
an hour later on the other side.

### 4.5 Answering exactly like the real service

The reply is built from the request, following the conventions WCF and ASMX use themselves:

| Caller style | Reply body |
|---|---|
| WCF / ASMX, document/literal | `<{Op}Response xmlns="{ns}"><{Op}Result>{value}</{Op}Result></{Op}Response>` |
| SOAP Toolkit, RPC/encoded | `<m:{Op}Response xmlns:m="{ns}"><Result>{value}</Result></m:{Op}Response>` (part unqualified) |
| SOAP 1.2 | the same body in a SOAP 1.2 envelope, `Content-Type: application/soap+xml; charset=utf-8` |
| WS-Addressing | adds `<a:Action>{request action}Response</a:Action>` and `<a:RelatesTo>{request MessageID}</a:RelatesTo>` |
| One-way (`"OneWay": true`) | HTTP 202, empty body |
| Unknown contract (unlisted) | `<{Op}Response xmlns="{ns}"/>` with no result — WCF reads null (strings), the default (numbers) or a normal completion (void) |
| Refusal | SOAP fault: 1.1 `faultcode`/`faultstring`, 1.2 `Code`/`Reason`; HTTP 500 (503 when busy without a profile) |

The **value** comes from the operation's reply profile in `routes.json`:

| Profile | Ok | Busy | Unavailable | Pending (RoundTrip hold ran out, step 10a) | Rejected |
|---|---|---|---|---|---|
| `FmsResponse` | `<RESPONSE MSG_TYPE="{BusinessType}" MSG_ID="{MsgId}"><STATUS><RETURN_CODE>0</RETURN_CODE><ERROR_MESSAGE></ERROR_MESSAGE></STATUS></RESPONSE>` | same with `1598` + "backlog is full … retry later" | `1599` + "not available while FMS is islanded" | `1596` + "sent over the QR bridge, confirmation not yet received" | `1597` + "Invalid XML MESSAGE TYPE for this interface" |
| `ReturnCode` | `0` | `1598` | `1599` | `1596` | `1597` |
| `PortalSyncDown` (`FMS2FC.PortalSyncRequest`, D19) | — | the same as Unavailable (a full Outbox gives the same "no data" answer, D53) | `1599` **and** an empty `<PORTAL_SYNC_RESPONSE><GMT_TIME_STAMP>`: the portal monitor stops until its next cycle | — | — |

`{BusinessType}`, `{MsgId}` (from the caller's message) and `{MessageId}` (the gateway-assigned id) are filled in and
XML-escaped. **1596–1599 are the SOAP Gateway's own codes**; FMS uses 1500–1999 for its errors and callers show
`ERROR_MESSAGE` to the operator. They are configurable and still need confirming with the Rapid Restore team.

Real WCF client stacks were run against the gateway in the tests ([§12.2](#122-what-the-tests-prove)): BasicHttp
(DataContract), ASMX-style (XmlSerializer, `long` result) and WSHttp (SOAP 1.2 + WS-Addressing). All accept these
replies unchanged.

### 4.6 Storing the call: byte for byte, then reply

For a **`Bridge`** or **RoundTrip** call, in this order (after the WSDL check, §4.9):

1. Allow-list check (`AllowedTypes`). Fail → `Rejected` reply (1597). Nothing stored.
2. **Content fingerprint** (decisions D5, D38): SHA-256 of service, operation, MESSAGE TYPE and the request as
   received, without the fields that change on every send (`FingerprintIgnore`: `MSG_ID`, `GMT_TIME_SENT`, `RRMsgID`)
   and without the SOAP headers. If a message with the same fingerprint was queued within `Gateway:RetryWindowMinutes`
   (30), the call is a **caller's retry**: on a route with `RecogniseRetries` on (by default only RoundTrip routes
   with `OnHoldTimeout: Pending` — permits, orders, cards — D56; a query is never attached) it is
   attached to that message — nothing stored; the retry is held for the same answer (step 10a); on the other routes (the
   `Bridge` feeds, D37) it is stored again and counted on `/health` (`retries.sameContentQueued`). A message the far
   side surely did not carry out (Outbox service status Expired, NotDelivered or Rejected) is not a retry target: the
   call is stored as a **new** message with a fresh expiry (D63).
3. Backlog check: Outbox **Request** rows with light status Pending + Sending + Aired ≥ `Gateway:MaxBacklog`, or
   that service's own Requests ≥ its `MaxBacklog` in `routes.json` (optional; none set today, step 16) → `Busy`
   reply (1598). Nothing stored. The Receipts and Replies this side writes for the other side ([§4.10](#410-delivering-on-the-other-side))
   are not counted and are never refused for a full Outbox (decision D47): answers never make a gateway turn its own
   callers away.
4. Build a `MessageHeader`: service, operation, path, `SOAPAction` header **as received** (quotes included),
   Content-Type **as received**, label and fingerprint; for RoundTrip an `ExpiresUtc` (a query: now + its hold, D54;
   a state-changing call: now + `Gateway:Expiry`, 600 s, D62; `Bridge`: none); the route's **priority class**
   ([§4.10](#410-delivering-on-the-other-side)) and the caller's address (`CallerHost`, below); keep the **exact
   request body** next to it.
5. In one SQLite transaction (with steps 2 and 3, so identical calls at the same moment make one row): take the next per-direction sequence number, turn header + body into bytes ([§7.2](#72-the-envelope-format)), insert the Outbox row, **commit**.
6. Ring the Outbox doorbell (wakes the QR sender).
7. **Only now** answer: `Bridge` → reply OK; RoundTrip → hold the caller for the real answer ([§4.7](#47-calls-that-need-a-live-answer)).
   The reply carries the header `X-QrBridge-MessageId` (the gateway-assigned id for the stored message).

If anything fails before the commit, the caller gets a SOAP fault ("NOT accepted, please retry"): a call is never
half-stored, and never acknowledged without being stored.

**Who called** (built 25 Nov 2026, V6 fix step 15, D76): every queued Request (SOAP and the Registered Tags GET)
carries `CallerHost` (`SenderEndpoint.CallerHostOf`). It is the first `X-Forwarded-For` address when the load balancer
sends one, labelled with the connection's address — `"10.1.2.3 (via 10.0.0.9)"` — else the connection's address.
Only address characters are taken from the header; anything else is ignored, so nothing can be injected into the
logs. The far side's `InboxWorker` logs it when it delivers the message ("… from 10.1.2.3 (via …)"), never the payload.

### 4.7 Calls that need a live answer

`GetFromFMS`, `GetFromTOMS`, `GetFromTLS` (AUTHORIZE_USERS, GET_FEEDER_INFO, WITHDRAW_RFP, GET_RELAY_TARGET), XA/21 and
BFC `ProcessMessage`, the DMZ calls `PortalSyncRequest` and FTC `GetFaultCorrelation`, and the Registered Tags report
return **data**; permits, orders and cards return the real service's verdict (`RETURN_CODE` 0 or an error). No reply the gateway could invent is correct. Most of them are **RoundTrip** routes in `routes.json`
(decisions D13–D19, 24 Nov; per row in [uncovered-services.md](../../sourcecode/gateway/docs/reference/uncovered-services.md); permits, orders and cards
since tracker step 10c, D60). **Built 24 Nov (tracker step
10a, D49–D56):** the call is queued and the caller held for `Gateway:Hold` (Corp 270 s, DMZ 90 s); when the far side's
Reply comes back it gets the real answer byte for byte. When the hold runs out, it gets the route's `OnHoldTimeout`
answer below. **Until the QrDiode apps carry messages (Integration-Plan §5), nothing comes back on real screens, so the
caller always gets this answer after the hold:**

| Interface | When the hold runs out (or nothing could be done) |
|---|---|
| FMS query with a reply profile (`AUTHORIZE_USERS`, `GET_FEEDER_INFO`, `GET_RELAY_TARGET`) | HTTP 200, `RETURN_CODE 1599` + readable message — the caller's normal error path; never delivered later (expires with its hold, D54) |
| `WITHDRAW_RFP`, and `GetFrom…` types nobody listed | HTTP 200, `RETURN_CODE 1596` "sent over the QR bridge, confirmation not yet received" (D8); a retry gets the stored answer; not posted on the far side after `Gateway:Expiry` (600 s, D62) |
| Permits, orders, cards and their responses (`SendTo*` on Corp, the DMZ FMS2FC / FMS2FOD / FMS2SSO / TLS2SSO / TOMS2SSO / DSO2SSO operations; step 10c, D60) | the same: `RETURN_CODE 1596` (`ReturnCode` profile: `1596`); a retry within 30 min attaches to the first message and gets its answer, never a second message (D56). Before step 10c these were `Bridge` and got `RETURN_CODE 0` at once although nothing had reached FMS yet; 1596 replaces that false "0" (accepted by Rowshan) |
| DMZ `PortalSyncRequest` | HTTP 200, `RETURN_CODE 1599` and an empty `GMT_TIME_STAMP` (profile `PortalSyncDown`, D19/D34; also when the Outbox is full, D53) |
| DMZ FTC `GetFaultCorrelation` | SOAP fault "not available while the network is islanded" |
| XA/21, BFC (`ProcessMessage`) | SOAP fault at once, nothing queued: `Unavailable` until HANDOFF §10 Q3 (D23) is answered (D52) |
| Registered Tags (`GET …/GetData`, step 12) | HTTP 504 text/plain "RegisteredTags is not available while the network is islanded: no answer came back over the QR bridge in time." (D69); the same for every far-side outcome without a real answer ([§4.9](#49-get-requests-and-health-probes)) |

What a held caller gets for each outcome of the far side (D50): Done or Refused **with** the real answer → that answer,
byte for byte; Unknown, or no answer carried → the hold-timeout answer above; Expired, NotDelivered, Rejected (surely
not done) → the "not available" answer. A retry of a message that surely was not done is queued as a new message
(D63). The polls `DISPLAY_POLL` and `BUS_FAULT_OUTAGE_REQUEST` stay Unavailable (D15). `FMS2FC.IssueWorkPermit` is
RoundTrip like the other permits (D61); what FMS's `IntMgr.CardCutOut` does after a non-zero answer is open question
D12 of the V6 fix tracker (not the design record's D12), so it stays pilot-only until the FMS team explains it.

### 4.8 Bad, unknown and too many calls

| Situation | HTTP | Reply |
|---|---|---|
| Body over `GatewayDatabase:MaxPayloadBytes` (1 MB), or over the service's `MaxRequestBytes` (step 16; the smaller applies) | 413 | SOAP 1.1 fault; nothing parsed or queued |
| Not XML / not a SOAP envelope / DTD present | 400 | SOAP 1.1 fault |
| Path not in the catalogue (`AcceptUnlisted` off) | 500 | SOAP fault "not a bridged service" |
| Operation not listed for the service | 500 | SOAP fault "not bridged" |
| Service whose callers are on the other side | 500 | SOAP fault |
| `Bridge` or RoundTrip call that does not match the service's WSDL (wrong SOAP version, SOAPAction, Body element, namespace, parameter or extra element) | 500 | SOAP fault "does not match the service's WSDL … NOT accepted" |
| Message type not allowed, or payload not well-formed | 200 | profile `Rejected` (1597), else SOAP fault |
| Backlog full (all Requests, or the service's own `MaxBacklog`) | 200 | profile `Busy` (1598), else SOAP fault with 503 |
| Database error while storing | 500 | SOAP fault "NOT accepted, please retry" |

### 4.9 GET requests and health probes

| Request | Answer |
|---|---|
| `GET /health` | JSON: side, machine, light and service counts per queue, `catalogFingerprint`, missing messages (`missingMessages`, `gaps`), the far side's last signs of life (`farSide`: `lastHeardUtc`, `lastReceiptUtc`, `silent`, step 17), callers' retries since start-up (`retries`: `attached`, `sameContentQueued`), `lightProblems`, `serviceProblems`, heartbeats, overall `healthy` flag (§8.3). **Point the load balancer's health probe here.** |
| `GET /FMS_ReportService/RegisteredTags.asmx/GetData` on the **Corp** gateway | Registered Tags, a round trip (below) |
| The same with a query string | HTTP 400, nothing queued (D71) |
| A SOAP POST to the Registered Tags path | SOAP fault "plain HTTP GET interface", nothing queued |
| `GET /qrbridge-ui/…` (and the login form's POST) | The read-only web UI (decision 48, 25 Nov 2026): this gateway's Outbox and Inbox in plain words, behind a login; [read-only-ui.md](../../sourcecode/gateway/docs/reference/read-only-ui.md). With `Ui:Enabled = false`: HTTP 405 like any other GET. No route may use a path under `/qrbridge-ui` (start-up refuses it) |
| Any other `GET`, and every `HEAD` (`?wsdl`, `?xsd=…`, a plain GET on a service or legacy `*.WSDL` path, `/`, the Registered Tags path on the DMZ gateway) | HTTP 405 Method Not Allowed |

The gateway serves no WSDL, XSD or help pages. The source of truth, the fms-interface-simulator, calls every service
through a compiled WCF proxy (`clsSOAP.vb`: `BasicHttpBinding` + `EndpointAddress`), so its clients never download a
WSDL at runtime. The gateway does keep the services' WSDLs, in `QrBridge.Gateway/Contracts/` (one folder per route,
`"Contract"` in `routes.json`), but only to **check** each `Bridge` or RoundTrip call against them before it is queued
([§4.8](#48-bad-unknown-and-too-many-calls)); a route listing an operation its WSDL lacks stops the gateway from
starting. `FOD2FMS` has no contract yet (its WCF WSDL is not in the simulator); `RegisteredTags` has none (not SOAP).

**Registered Tags, a GET carried as a round trip** (built 24 Nov 2026, V6 fix step 12; D18 partly reverses HANDOFF
decision 21; D69–D72). The Rapid Restore report screen calls
`WebClient.DownloadString(".../FMS_ReportService/RegisteredTags.asmx/GetData")`: a plain GET, no body, no query
string. Its callers are on the Corp side (D72); the report is delivered on the DMZ side.

1. `routes.json` lists it as service `RegisteredTags`: `SenderSide: Corp`, `"HttpGet": true`, one path, one operation
   `"GET"` with `Mode: RoundTrip` and `OnHoldTimeout: Unavailable`. Start-up refuses an `HttpGet` service unless it
   has exactly one path, no `Contract`, `OtherOperations: Reject`, exactly one operation `"GET"` with Mode RoundTrip
   or Unavailable, `OnHoldTimeout: Unavailable`, `RecogniseRetries` off, and no reply profile, `OneWay`,
   `AllowedTypes` or `Types` (`RouteTable.CheckHttpGet`).
2. The Corp gateway queues it as a Request with payload format **`HttpGet`**: empty body, empty Content-Type, no
   SOAPAction. `ExpiresUtc` = now + its hold (the query rule, D54). It is never attached to an earlier call: it has
   no content fingerprint.
3. It holds the caller for `Gateway:Hold` (Corp default 270 s, D70).
4. The DMZ gateway replays it as a GET (no body, no SOAPAction, no Content-Type) to the configured target + path and
   classifies the answer like any other ([§4.10](#410-delivering-on-the-other-side)). A service that surely cannot
   be reached ends `NotDelivered` at once (query fast failure).

| What happened | The caller gets |
|---|---|
| The report service answered (Done or Refused, e.g. HTTP 200 or 404) and the answer came back within the hold | that answer byte for byte: HTTP status, Content-Type and body. No other HTTP header is replayed |
| Anything else: the hold ran out, Unknown, NotDelivered, Expired, Rejected, an answer too large to carry back (over `GatewayDatabase:MaxPayloadBytes`, 1 MB), Outbox full | HTTP 504 `text/plain` "RegisteredTags is not available while the network is islanded: no answer came back over the QR bridge in time." (D69) |

**Risk:** `WebClient`'s default timeout is 100 s, shorter than the Corp hold (270 s), so the caller may give up first.
**Not verified:** the real report service's answer (size, content type), whether the real report host is in the DMZ,
that the real caller never adds a query string, and the timeout Rapid Restore really uses. Proven only by tests with
two in-memory gateways (`RegisteredTagsTests`).

### 4.10 Delivering on the other side

The receiving side's gateway runs `InboxWorker`, inside IIS. Since 25 Nov 2026 (V6 fix step 14, D73, D74) it runs
**one delivery loop per priority class** — High, Normal and Low (`InboxWorker.DeliveryClasses`) — so a slow or stuck
feed never holds back a permit:

| Class | Default for (`RouteTable.SettingsOf`) |
|---|---|
| `Answer` (0) | Receipts and Replies (`OutboxWriter` sets it; never posted to a service, so no delivery loop) |
| `High` (1) | RoundTrip routes with `OnHoldTimeout: Pending` (1596): permits, orders, cards — state-changing |
| `Normal` (2) | RoundTrip queries (`OnHoldTimeout: Unavailable`), including the Registered Tags GET and `PortalSyncRequest` |
| `Low` (3) | `Bridge` feeds |

An optional `"Priority"` (`High`, `Normal` or `Low`) on an operation or a message type in `routes.json` overrides the
default; `Answer` is refused at start-up, and a Request can never be `Answer`. No route in `routes.json` sets it today.
The Inbox doorbell wakes one loop; the others find new work at their next poll (`Gateway:InboxPollSeconds`). There
is no setting for the number of loops: always three. Each loop:

1. **Claims** (`InboxRepository.ClaimNextAsync(priority)`) the next Request **of its class** that arrived intact
   (`LightStatus` Received) and is waiting (`ServiceStatus` Pending, or Retrying with its retry time reached). It
   becomes Delivering. Order inside a class: the runs of the sender's counter in the order they started (their first
   message's `CreatedUtc`), then the sender's `Sequence` — a new run (counter restarted at 1) never jumps ahead of
   older messages. **Strict order per service (D74):** a Request is not claimed while an earlier Request of the
   same service and class is `Retrying`; that service waits until the earlier one is Done or ends (NotDelivered
   after `MaxAttempts`, etc.). Other services and other classes are not blocked.
2. **Open** the envelope: verify its checksum and unpack it. Check that the row's columns match the header, the
   sender ran the same `routes.json` (catalogue fingerprint, §7.3), the direction is right for this side, the payload format is `RawSoap` or `HttpGet`, it is less than 7 days old and not dated more
   than an hour in the future.
3. **Plan**: the service must be in this side's catalogue with its *callers on the other side*, and the operation must
   be a `Bridge` or RoundTrip operation (unlisted services only when `AcceptUnlisted` is on). An `HttpGet` message for a
   route that is not `HttpGet`, or a SOAP message for an `HttpGet` route, is Rejected (light Rejected, never sent).
4. **Target**: `Gateway:Receiver:Targets:{Service}:Url`, else `Gateway:Receiver:DefaultBaseUrl` + the caller's original
   path. **The URL never comes from the message** — a forged or replayed message cannot send the gateway anywhere.
5. **Replay**: POST the stored body unchanged, with the original `SOAPAction` and `Content-Type`. Redirects are not
   followed. Credentials per target (D75, step 15): `Gateway:Receiver:Targets:{Service}:UseDefaultCredentials`
   (true/false) overrides the global `Gateway:Receiver:UseDefaultCredentials`; true = authenticate as the app pool
   identity, false = anonymous. Never a password in configuration. If the request uses
   WS-Addressing, its `wsa:To` is pointed at the real service (otherwise the bytes are not touched). An `HttpGet`
   message (Registered Tags, [§4.9](#49-get-requests-and-health-probes)) is replayed as a GET: no body, no `SOAPAction`,
   no Content-Type.
6. **Classify** the real service's answer and set the row's `ServiceStatus` (the real service's HTTP code goes in
   `ServiceHttpStatus`, the outcome and its probable reason in `ServiceComment`). A final outcome is first sent back
   as a Reply (step 7), then stored on the row. The rule (decision D9): **post
   again only when the call surely did not arrive**; when it may have arrived, Unknown — never posted again on its
   own, because that is how duplicate permits and orders happen. A request past its `ExpiresUtc` is not posted at all
   (**Expired**).

| Real service answers | Verdict | Inbox `ServiceStatus` |
|---|---|---|
| `RETURN_CODE 0` / return code `0` / HTTP 202 / any 2xx for operations without a result kind | Delivered | **Done** (`DownstreamResult` keeps e.g. `RETURN_CODE=0`) |
| `RETURN_CODE ≠ 0` / return code `≠ 0` | Refused | **Refused** with the code and `ERROR_MESSAGE` — never retried automatically |
| SOAP fault | Permanent | **Refused** with the fault reason |
| 400, 401, 403, 404, 405, 415 and other 4xx; 3xx (redirects are not followed); 501, 505 | Permanent | **Refused** — not processed (often a configuration problem) |
| **Nothing was sent:** the name does not resolve, connection refused or unreachable, no connection within `ConnectTimeoutSeconds` (15 s), TLS handshake failed; HTTP 408, 429 | Transient | **Retrying**, posted again with backoff |
| **It may have arrived:** no answer within `TimeoutSeconds` after sending, connection reset or answer ended early, HTTP 500, 502, 503, 504, any other 5xx or odd status | Unknown | **Unknown**, with the probable reason (e.g. "HTTP 502: the load balancer or a proxy lost the service's answer. The service may have processed it: check before resending.") — never posted again |
| 2xx but the expected result can't be read (no `RETURN_CODE`, not a number, not SOAP, empty or too large) | Unknown | **Unknown**, "reply not recognised — may have been processed; check before requeue". Not Done (we can't tell whether it was accepted) and not retried (it may have been processed) |

If no Receiver target is configured for the service, the row ends **NotDelivered** (decision D25): it surely never
reached the service, so an operator may send it again. If the arrival checks in step 2 or 3 fail, the row gets
`LightStatus` **Rejected** instead (reason in `LightComment`); it is never delivered. If the gateway stops (app pool
recycle) while the POST is in flight, the row becomes **Unknown** (decision D41); stopping before the POST puts it
back to Pending. A row found still Delivering after a crash (`MaintenanceWorker`, after `LockTimeoutMinutes`) takes
the outcome of the Reply already written for its **current** attempt (a Reply from before an operator's requeue is
not used: the new POST may have reached the service, D64); without one it becomes **Unknown** and gets an Unknown Reply
(decision D46). It is never posted again on its own.

Retry schedule (defaults, "nothing was sent" failures only): waits of 30 s, 1, 2, 4, 8, 16 and 30 minutes between
attempts — about one hour in total. After the 8th attempt the worker ends the row **NotDelivered**: every attempt
surely failed before anything was sent. Refused, Unknown and NotDelivered are never re-posted automatically; all
three need an operator. While a Request is Retrying, later Requests of the same service and class wait behind it
(strict order, D74, step 1 above).

7. **Answer** over the opposite lane (decisions D43–D46, built 24 Nov 2026, V6 fix step 9b). `AnswerWriter` writes
   two kinds of message into **this side's own Outbox**, through `OutboxWriter`, so they cross back like any other
   message. Nothing posts them to a service.

| Message | Written when | Carries |
|---|---|---|
| **Reply** | **every final outcome** of a Request: Done, Refused, Unknown, Expired, NotDelivered (`Bridge` routes too), and Rejected. Not while the row is still Retrying | `Kind = Reply`, `CorrelationId` = the Request's `MessageId`, `Outcome`, `ServiceHttpStatus`, `ServiceComment` (the reason in plain words, at most 1,024 characters, never the payload). Body = the real service's answer **byte for byte**; header Content-Type = the answer's. An answer larger than `GatewayDatabase:MaxPayloadBytes` is left out and the comment says it was "too large to carry back" |
| **Receipt** | **every message that arrives** (Requests, Replies, Rejected ones too), and again when the same `MessageId` arrives a second time (the sender re-aired it because the first Receipt was lost) | `Kind = Receipt`, `CorrelationId` = the arrived message's `MessageId`, empty body. A Receipt never gets a Receipt |
| **Heartbeat** | by `MaintenanceWorker` when this side has queued nothing for `Gateway:HeartbeatMinutes` (5), and no earlier Heartbeat is still waiting to be aired (so they never pile up while the light is down) — built 25 Nov 2026, step 17, D80, D81 | `Kind = Heartbeat`, service `QrBridge`, operation `Heartbeat`, empty body, names no message. Takes a sequence number, so a lost last message becomes a gap on the far side. Gets no Receipt and is never aired again (the next one replaces a lost one); the far side's `AnswerReader` checks it and ends it Done |

The Reply is written **first**, then the Inbox row is marked (D46): after a crash in between, the row is still
Delivering and its Reply already exists, so recovery settles the row from that Reply instead of guessing. Receipts are
written by `ReceiptWorker`, separately from deliveries (a slow POST must not hold them back): every
`Gateway:InboxPollSeconds` it sends the ones owed (Inbox column `ReceiptDueUtc`), up to 100 per pass. If an operator
requeues a row, its new outcome sends a second Reply; the sending side replaces its stored answer with it unless that
one is `Answered`, and only when the new Reply is newer (decision D59, tracker step 10b).

**Built since tracker steps 10a and 10b:** the sending gateway reads arriving Replies and Receipts (`AnswerReader`:
Outbox light `Received`, service `Answered`/`Refused`/`Unknown`/`Expired`/`NotDelivered`/`Rejected`) and hands the
real answer to the held caller ([§4.7](#47-calls-that-need-a-live-answer)). The receiving gateway accepts RoundTrip
Requests; does **not** post a request whose same content (routes that recognise retries) already arrived within
`Gateway:RetryWindowMinutes` and was `Done` (the earlier answer is reused) or may have been (`Unknown`, still
`Delivering`: it becomes `Unknown`) (D58); and answers a **query** whose service surely cannot be reached with a
`NotDelivered` Reply at once instead of retrying (fast failure). **Not built yet:** nothing carries Replies and Receipts
over the real light (the QrDiode work, [integration-plan.md](integration-plan.md) §2). Today they are proven only by
tests that copy the bytes from one gateway's Outbox into the other's Inbox.

### 4.11 "Any WCF request": what is covered and where it stops

Covered:

- SOAP 1.1 and SOAP 1.2; WS-Addressing 1.0 and August 2004.
- Document/literal (WCF `BasicHttpBinding`, ASMX, `WSHttpBinding` without message security) and RPC/encoded (SOAP Toolkit).
- Services the catalogue has never seen (`Routing:AcceptUnlisted`), with an automatic reply.
- Any payload, byte for byte; any `SOAPAction`, including shared and empty ones.

Not covered — true of any proxy that replies on the real service's behalf:

| Not covered | Why |
|---|---|
| Message-level security (WS-Security signatures/encryption, secure conversation) | a signed request cannot be answered by a third party, or replayed later |
| Reliable sessions, duplex callbacks | they need a live two-way connection |
| The caller's Windows identity reaching the real service | the call is replayed later by the gateway's identity |
| Replies that carry live data | see [§4.7](#47-calls-that-need-a-live-answer) |
| Unlisted operations whose caller reads a result | they get an empty reply; add a catalogue entry with a reply profile |
| Document/literal **bare** (non-wrapped) unlisted operations | the automatic reply assumes the wrapped convention |

None of the FMS services in the simulator use message security, reliable sessions or duplex.

---

## 5. A message's journey, step by step

An SSO operator returns a completed switching order. Steps 6–8 and 13 are the QR apps' part, which is designed but not built
yet ([§9.2](#92-what-changes-to-connect-it-to-the-shared-message-database-planned)); everything else exists today.

| # | Where | What happens | State afterwards |
|---|---|---|---|
| 1 | Rapid Restore SSO (CorpNet) | Calls `SendToFMS(<MESSAGE TYPE="RETURN_ORDER" …>)` on `https://…/FMS_SSO2FMSInterface/SSO2FMSInterface.svc`, unchanged. | |
| 2 | Corporate load balancer | In islanding mode, forwards to the Corp gateway. | |
| 3 | Corp gateway — Sender part | Parses the SOAP call; route SSO2FMS, operation SendToFMS, Mode RoundTrip (`OnHoldTimeout: Pending`); label `RETURN_ORDER` is on the allow-list. | |
| 4 | Corp gateway — store | Packs the exact request into an envelope with `ExpiresUtc` = now + `Gateway:Expiry` (600 s), inserts it, commits, rings the Outbox doorbell. | Corp Outbox: light **Pending**, service **Waiting**, sequence n |
| 5 | Corp gateway — hold | Holds Rapid Restore's call (up to `Gateway:Hold`, 270 s on Corp) for FMS's real answer (step 14). | |
| 6 | Corp QR sender *(planned)* | Wakes on the doorbell, claims waiting rows, bundles them into one QR session (signed and encrypted by QrDiode), shows the QR stream. | Corp Outbox: light **Sending**, then **Aired** |
| 7 | Light, lane 2 | The DMZ camera films the CorpNet screen. | |
| 8 | DMZ QR receiver *(planned)* | Verifies the QR session, unpacks the bundle, inserts each envelope into the Inbox (duplicates ignored by MessageId), rings the Inbox doorbell. | DMZ Inbox: light **Received**, service **Pending** |
| 9 | DMZ gateway — worker | Claims the row; verifies the envelope checksum and unpacks it; checks catalogue fingerprint, direction, age, catalogue, expiry, and that the same content has not already been handled (D58). | DMZ Inbox: service **Delivering** |
| 10 | DMZ gateway — replay | POSTs the identical bytes, same `SOAPAction`, to `DefaultBaseUrl` + `/FMS_SSO2FMSInterface/SSO2FMSInterface.svc` (the DMZ RR server). | |
| 11 | DMZ RR server → Core FMS | Processes it exactly as a direct call; answers `RETURN_CODE 0`. | |
| 12 | DMZ gateway — record and answer | Writes a **Reply** (outcome Done, HTTP status, FMS's answer byte for byte) into the DMZ Outbox, then stores the outcome on the row. Separately, `ReceiptWorker` writes a **Receipt** for the arrived message. Both wait in the DMZ Outbox for lane 1. | DMZ Inbox: service **Done**, `DownstreamResult = RETURN_CODE=0`; DMZ Outbox: a Reply and a Receipt, light **Pending** |
| 13 | Light, lane 1 *(planned)* | The DMZ QR sender airs the Reply and the Receipt; the Corp QR receiver writes them into the Corp Inbox. | Corp Inbox: a Reply and a Receipt, light **Received** |
| 14 | Corp gateway — answer reader | `AnswerReader` checks them, stores the Reply's outcome and FMS's answer on the Outbox row and wakes the held call: Rapid Restore gets FMS's `RETURN_CODE 0` byte for byte and continues as usual. | Corp Outbox: light **Received**, service **Answered** |

If the answer is not back within the hold, Rapid Restore gets `RETURN_CODE 1596` ("sent over the QR bridge,
confirmation not yet received"); a retry with the same content within 30 minutes attaches to the same message and gets
its answer once it is back — never a second order. If the request reaches the DMZ gateway more than 600 s after it was
sent, it is not posted (Inbox **Expired**); when that Reply comes back, a caller still held for it gets "not
available" (1599), and a later retry is sent as a new message with a fresh expiry (D63). **Today, without the QR
apps, every such call waits the full hold and gets 1596.**

If FMS refuses the order (say `RETURN_CODE 1501`), step 12 sets **Refused** with the code and FMS's error message,
and the Reply says Refused and carries FMS's answer: a caller still held gets that answer byte for byte. An operator
also sees it on the DMZ side (`Inbox.ServiceComment`, `Inbox.DownstreamResult`). Steps 12 and 14 are built and
tested with two gateways in one test; nothing carries the Reply across yet (QrDiode work), so on real hardware the
Corp Outbox row stays service **Waiting**.

The **DMZ → CorpNet** direction is the same path mirrored: an FMS interface client calls the DMZ gateway (its URL
re-pointed by configuration), lane 1 carries the envelope, and the Corp gateway replays it to the corporate system.
Its services are in the catalogue (`"SenderSide": "Dmz"`, §4.4), but their paths still need confirming and the Corp
gateway's receiver targets (the corporate hosts) are still empty.

---

## 6. Data and storage

### 6.1 One database per machine

The bridge database is **`qrbridge.db`** in `GatewayDatabase:DataFolder` (default `C:\ProgramData\QrBridge\Data`) on a **local
disk** — never a network share. Each machine (Corp, DMZ) has its own copy; the two copies are never connected: only the
light carries messages between them. The gateway's app pool identity and the kiosk user both need Modify on the
folder (§12.4).

| Table | Written by | Read by | Holds |
|---|---|---|---|
| Outbox | gateway Sender part (`OutboxWriter`: callers' Requests; Receipts, Replies, Heartbeats); status: QR sender, `AnswerReader` | QR sender, gateway | what this side sends |
| SequenceCounter | `OutboxWriter` | `OutboxWriter` | the per-direction running number and its run id (§6.3) |
| Inbox | QR receiver (insert); status: gateway Receiver part (worker), `AnswerReader` | gateway | what arrived from the other side |
| Heartbeat | every component | `/health`, QR apps | "this loop is alive" |
| AcknowledgedGap | operators | `SequenceGapMonitor` | missing numbers written off |
| SequenceWatermark | gateway (maintenance run) | `ArrivalChecks` | how far each run of the other side's counter is complete |
| JournalTransfer | QR receiver (`IReceiveJournalRepository`) | QR receiver | every QR session it accepted (anti-replay) and how it ended |
| JournalWatermark | QR receiver | QR receiver | the highest counter per sender key and counter run (QrDiode anti-replay; security state: never archive or edit) |
| JournalArchive | QR receiver | QR receiver (Archive tab) | every arrival it judged, rejections included |

Since 27 Nov 2026 the QR Receiver's journal is in this same database, in both of its modes (until then its own file,
`%LocalAppData%\QrDiode\journal.db`, which the Receiver copies in once on its first start and renames
`journal.db.imported-…`). So there is **one database per machine** for the gateway and both QR apps.

EF Core is the only way the code touches it (`QrBridge.Shared/Data`): entities, `IEntityTypeConfiguration` classes,
one context (`BridgeDbContext`) created short-lived from an `IDbContextFactory`, and the repositories, used through
their interfaces (`IOutboxRepository`, `IInboxRepository`, `IHeartbeatRepository`). Each repository method commits on
its own; nothing relies on two tables changing in one transaction.

**The database engine is configuration** (since 27 Nov 2026, handoff decision 55): `GatewayDatabase:Provider` =
`Sqlite` (the default, everything in this section) or `SqlServer` (the same tables, columns, constraints and statuses
in a SQL Server database; §8). Everything only one engine uses lives in its own folder, `QrBridge.Shared/Data/Sqlite`
or `Data/SqlServer`, each with `Providers/` (its `IBridgeDatabase`: connection, read-only connection, start-up),
`Contexts/` (its context, which answers how a write transaction takes the one write lock — SQLite `BEGIN IMMEDIATE`,
SQL Server an exclusive `sp_getapplock` held to commit — and how a duplicate key shows), `Initializers/` and
`Migrations/`. The shared folders (entities, configurations, conventions, abstract `BridgeDbContext`,
`IBridgeDatabase`, repositories) do not know the engine. Details and verification:
[database-abstraction-plan.md](../../sourcecode/gateway/docs/reviews/database-abstraction-plan.md). With SQL Server the
doorbells (§6.5) still work only on one machine; the gateway and the QR apps stay on one machine (decision 4).

**Until 25 Nov 2026 there were two files**, `send.db` (Outbox, SequenceCounter) and `received.db` (the other four),
to give each file one main writer. They were merged on request (handoff decision 47). What that changes:

- **One write lock per machine.** SQLite lets one connection write to a file at a time; the gateway, the QR sender and
  the QR receiver now queue for the same lock. Transactions are short and every connection waits up to 5 s
  (`busy_timeout`, §6.4); at the light's few KB/s this is not expected to matter, but it has **not been measured** with
  the QR apps, which are not connected yet.
- **A damaged or locked file stops both directions** on that machine (before, the other file kept working).
- **Backup and restore cover both directions together** (§12.4).
- **Former files block the start.** `DatabaseInitializer` refuses to start while `send.db` or `received.db` is in the
  data folder: they may hold messages that were accepted but never carried or delivered, and starting on a new, empty
  `qrbridge.db` would drop them without a trace. Check them, deal with any such messages, then move the files (with
  their `-wal` and `-shm` files) out of the folder.

### 6.2 Tables

**Outbox** — messages waiting to cross, or crossing: the callers' Requests and, since 24 Nov 2026 (step 9b), the
Receipts and Replies this side sends back for messages that arrived from the other side ([§4.10](#410-delivering-on-the-other-side)).

| Column | Meaning |
|---|---|
| `MessageId` | primary key: the end-to-end id, the same in the other side's Inbox |
| `Direction`, `Sequence`, `SequenceRunId` | `CorpToDmz` (= Inbound) / `DmzToCorp` (= Outbound), the per-direction sequence number (queue order; unique per direction) and the run of the sender's counter it belongs to (§6.3) |
| `Priority` | the priority class (since 25 Nov 2026, step 14, D73): `Answer` 0 (Receipts, Replies), `High` 1, `Normal` 2, `Low` 3 — stored as its **number**, the one enum not stored by name, so it can be ordered; CHECK `CK_Outbox_Priority`. The QR sender's claim takes Answers first, then High, Normal, Low ([§6.3](#63-queue-mechanics)) |
| `ServiceName`, `Operation`, `BusinessType` | route, SOAP operation, label (e.g. `SSO2FMS`, `SendToFMS`, `RETURN_ORDER`) |
| `PayloadFormat`, `PayloadSize` | `RawSoap`, or `HttpGet` for a plain GET request (empty body; since step 12 — the CHECK constraint changed, so delete dev databases), payload size before compression |
| `MessageBytes`, `MessageHash` | the serialized message (header + compressed SOAP body, immutable in the Outbox) and its SHA-256 |
| `LightStatus`, `LightComment`, `LightUpdatedUtc` | the light group: has the message crossed? (reason for operators, when it last changed) |
| `ServiceStatus`, `ServiceHttpStatus`, `ServiceComment`, `ServiceUpdatedUtc` | the service group: what the far side's real service did (`Waiting` until `AnswerReader` reads the far side's Reply, step 10a) |
| `ReplyContentType`, `ReplyBody`, `ReplyCreatedUtc` | the real service's answer, byte for byte, from the far side's Reply (at most `GatewayDatabase:MaxPayloadBytes`); empty until a Reply carrying one arrives (stored by `AnswerReader`, step 10a); when that Reply was written, by the far side's clock (a later Reply after an operator requeue replaces a stored answer that is not `Answered` only when newer, D59, step 10b) |
| `Kind`, `CorrelationId`, `ContentFingerprint`, `ExpiresUtc` | copies of the header fields (Request / Receipt / Reply; the message a Receipt or Reply is about; the content fingerprint for recognising a caller's retry; the expiry), so the round trip can query them |
| `Attempts`, `LockedUtc`, `NextAttemptUtc` | queue state |

**Inbox** — complete messages from the other side. The same identity and label columns as the Outbox, the same
comment, service and header-copy columns (shared base class `BaseMessage`; no reply columns), its own `LightStatus` and
`ServiceStatus`, plus `Verified` (set once every arrival check passed; since step 17 the arrival checks set it, and it
lets the row count toward its run's watermark), `ReceivedUtc`,
**`DownstreamResult`** (what the real service answered) and **`ReceiptDueUtc`** (since 24 Nov 2026, step 9b: a Receipt
is owed to the sender since this time; set when the message arrives and again when the same `MessageId` arrives a
second time, cleared once `ReceiptWorker` has queued the Receipt; never set for a Receipt or a Heartbeat; filtered index
`IX_Inbox_ReceiptDue`). Only **Requests** are ever posted to a real service: Receipts, Replies
and Heartbeats are stored but never claimed for delivery, and a row whose columns disagree with its header is rejected.
The Inbox has the same `Priority` column (CHECK `CK_Inbox_Priority`; each delivery loop claims only its class, §4.10).
When an Inbox row ends **Done**, its `MessageBytes` is cleared (D77, step 15; §7.1); `MessageHash`,
`DownstreamResult` and the header columns stay. Claim indexes: `IX_Outbox_LightStatus (LightStatus, Priority,
Sequence)` and `IX_Inbox_Status (LightStatus, ServiceStatus, Kind, Priority, CreatedUtc)`; `IX_Inbox_Arrived
(Direction, LightStatus, ReceivedUtc)` serves "far side last seen" on `/health` (step 17). The `Priority` columns
(with header version 6, §7.2) changed the schema, and so did step 17 (the `Heartbeat` kind, `SequenceWatermark`, the
new index): delete dev databases (since 25 Nov 2026 that is `qrbridge.db`; move away any former `send.db` /
`received.db`).

**SequenceCounter** (one row per direction: `LastValue` and the run id `RunId`, §6.3), **AcknowledgedGap** (missing
numbers an operator accepted as lost, with who, when and why — kept for audit, §8.2), **SequenceWatermark** (since
25 Nov 2026, step 17, D84: per direction and run of the other side's counter, `ContiguousTo` = every number up to it
has arrived and been checked, or was acknowledged as lost; moved up once a minute, never back; how an old message is
recognised by its number, [§7.3](#73-trust-rules-in-the-code). Tiny: **never archive it**, nor `AcknowledgedGap`),
**Heartbeat** (one row per component: `GatewayApi`, `InboxWorker`, `MaintenanceWorker`, later `SenderLoop`,
`ReceiverLoop` — local liveness, not the `Heartbeat` message kind that crosses the light).

Status lifecycles — **two groups per row** (decision D24, built 24 Nov 2026), so an operator sees at once whether a
problem is on the light (screens, cameras, QR apps) or at the service end (the real service):

```
Outbox light:   Pending ──► Sending ──► Aired ──► Received   (Aired: nothing sets it yet; Received: AnswerReader, from an arriving Receipt or Reply, step 10a)
                                          ├──► Pending (no Receipt after ReceiptTimeoutSeconds, tries left: aired again; MaintenanceWorker, step 11)
                                          └──► Failed  (out of tries, or expired before confirmed: MaintenanceWorker; operator requeues;
                                                        a Receipt that arrives later still moves it to Received)
                (an aired Receipt or Heartbeat row stays Aired: neither gets a Receipt, D44, D80)
Outbox service: Waiting ──► Answered / Unknown / Refused / Expired / NotDelivered / Rejected   (AnswerReader, from an arriving Reply, step 10a)

Inbox light:    Received                 (arrived; Requests are delivered by the worker, Receipts, Replies and Heartbeats read by AnswerReader)
                Rejected                 (failed checksum / direction / catalogue / catalogue fingerprint / payload / replay checks,
                                          or an old or reused sequence number, step 17; never delivered)
Inbox service:  Pending ──► Delivering ──► Done
                               ├──► Retrying ──(backoff)──► Delivering ... ──► NotDelivered (after MaxAttempts;
                               │                   a round-trip query: NotDelivered at once, step 10b)
                               ├──► Refused       (fault, non-zero code, 4xx, 3xx, 501, 505: operator)
                               ├──► Unknown       (may have been processed: timeout after sending, reset, 5xx,
                               │                   unreadable 2xx, a crash or shutdown during the POST: operator;
                               │                   or the same content is already Unknown/Delivering, step 10b)
                               ├──► Done, not posted (the same content is already Done: its answer reused, step 10b)
                               ├──► Expired       (past its ExpiresUtc: not posted)
                               └──► NotDelivered  (no Receiver target: operator may resend)

Every final Inbox outcome (Done, Refused, Unknown, Expired, NotDelivered, and light Rejected) is preceded by a Reply
in this side's Outbox; every arrived row is owed a Receipt (ReceiptDueUtc) until ReceiptWorker queues it.
```

Inbox `Expired` is set when a request is past its `ExpiresUtc`. Only RoundTrip requests have one: a round-trip query
(`OnHoldTimeout: Unavailable`) now + its hold (D54, step 10a); a state-changing call (`Pending`: permits, orders,
cards) now + `Gateway:Expiry`, 600 s (D62, step 10c). `Bridge` feeds never expire. The service group counts only rows whose light status is Received.

Enums are stored as their names (except `Priority`, stored as its number 0–3), Guids as lower-case text, all times in UTC — readable with any SQLite tool.

### 6.3 Queue mechanics

| Mechanism | How |
|---|---|
| Claim | Find the eligible row first in queue order, then `UPDATE … SET ServiceStatus='Delivering' WHERE MessageId=@id AND LightStatus='Received' AND ServiceStatus IN ('Pending','Retrying')` (the Outbox claim does the same on `LightStatus`, `Pending` → `Sending`). One affected row = you own it; two claimers can never get the same row. Queue order (step 14, D73, D74): the Outbox claim (`OutboxRepository.ClaimNextAsync`, the QR sender's) takes Receipts, Replies and Heartbeats first, then High, Normal, Low, lowest `Sequence` within a class; each Inbox delivery loop claims only its own class, by run of the sender's counter (in the order the runs started), then `Sequence`, and skips a service that has an earlier Request of the same class `Retrying` (§4.10). |
| Sequence | `UPDATE SequenceCounter SET LastValue = LastValue + 1, RunId = COALESCE(RunId, @run) WHERE Direction=@d`, then a read of the row, inside the Outbox insert's write transaction (`OutboxRepository.InsertAsync`; the write lock keeps the two statements together on both engines — until 27 Nov one SQLite `UPDATE … RETURNING`). The run id (decision D27) is set when the first number is handed out and never changes; every message carries it (`SequenceRunId`). Why: the receiving gateway finds lost messages by missing numbers. If the DMZ machine is rebuilt after message 40 of run A, the next messages are 1, 2, 3 of run B. Without the run id, "1" would look like a duplicate and 41… like a gap that never fills; with it, run A ends at 40 and run B starts at 1. A new or deleted `qrbridge.db` starts a new run; a restored backup keeps its run (§12.4). |
| Duplicates | `MessageId` is the primary key of both tables; the Inbox insert is idempotent (a duplicate returns "already there"). A duplicate is owed a Receipt again: it was re-aired because the sender never got the first one (D44). |
| Recovery | Inbox rows stuck in Delivering longer than `LockTimeoutMinutes` (5) — a crash or recycle during the POST — are settled by `MaintenanceWorker` (decision D46): from the Reply already written for their current attempt, if there is one (its outcome is copied to the row; a Reply written before an operator's requeue is not used, D64); otherwise they become **Unknown** and get an Unknown Reply (the request may have reached the service). They are never posted again on their own (decision D9). A shutdown during the POST makes the row Unknown at once (D41); a shutdown before the POST puts the row back to Pending without counting the attempt. |
| Lost messages | Once a minute the gateway looks for numbers missing from the other side's sequence, per run (decision D29). A gap counts once the message after it arrived `GapGraceMinutes` (5) ago (bundles may arrive out of order). Every arrived row counts, Rejected ones too. A gap stays until the message arrives, the sender's counter starts a new run, or an operator acknowledges it (§8.2). A lost **last** message has nothing after it, so since step 17 an idle side sends a Heartbeat message every `HeartbeatMinutes` (5): it takes the next number and makes the loss visible (D80). |
| Far side last seen | Built 25 Nov 2026 (step 17, D82, D83): `/health` `farSide` shows when anything from the far side last arrived acceptably (Heartbeats included) and when its last Receipt did. Nothing for longer than `FarSideSilentMinutes` (15; counted from start-up until something is heard) → `silent`, `healthy = false`, and a `Light: nothing heard from the far side since …` warning each maintenance run. |
| Old messages by number | Built 25 Nov 2026 (step 17, D84), on a row's first check: a number of a counter run already held by **another** message that arrived first → Rejected ("already used"); a number at or below the run's `SequenceWatermark` that no other row holds (its message was archived) → Rejected ("an old message shown again"), whatever its date. Lower numbers arriving later stay normal (answers first, re-airs): only the watermark, which moves up through checked rows, decides. |
| Re-air | Built 24 Nov 2026 (V6 fix step 11, D65–D67), on the **sending** side: once a minute `MaintenanceWorker` calls `OutboxRepository.ReairUnconfirmedAsync`. An Outbox row (not a Receipt or a Heartbeat) still light `Aired` `Gateway:ReceiptTimeoutSeconds` (120) after it was aired goes back to **Pending**, so the QR sender airs it again (in claim order: answers first, then by class, lowest `Sequence` first). After `Gateway:MaxAirAttempts` (3) airs in total (the `Attempts` column), or once past its `ExpiresUtc`, it becomes light **Failed** instead. Each change is one conditional UPDATE (only if still Aired and not re-aired since), so a Receipt arriving at the same moment wins. Safe: the far Inbox skips a `MessageId` it already has and sends a new Receipt (D44); a Request is never posted twice. Because the check runs once a minute, the real wait is 120–180 s. Not verified: proven only with in-memory gateways and a fake light; the effect on light capacity under load is not measured; a row put back to Pending that expires before the QR sender claims it is still aired once more (the far side then refuses it as Expired). Not on real hardware yet: nothing sets `Aired` until the QR sender is connected (§9.2). |
| No automatic deletion | Rows are never deleted automatically (decision D28, 24 Nov 2026): an Inbox row is what stops a replayed `MessageId`, and the gap check needs every number. Operators archive rows manually (§12.4). The sending side reads Receipts since step 10a, but until the QR apps carry messages, Outbox rows stay Pending on real hardware. |
| Ordering | Built 25 Nov 2026 (step 14, D74): one delivery loop per class; inside a class, arrival order (run, then `Sequence`), and **strict order per service**: a Request waits while an earlier Request of the same service and class is `Retrying`. Other services and classes go on. A higher class can overtake a lower one on purpose (a permit before a feed). Not built: a per-order key (`OrderingKey`, [integration-plan.md](integration-plan.md) §4) that would let other orders of the same service pass a stuck one. |

### 6.4 SQLite settings

Every connection runs `PRAGMA busy_timeout = 5000; PRAGMA synchronous = FULL;`; `journal_mode = WAL` is set once
(it is stored in the file). WAL lets readers and the single writer work at the same time; `busy_timeout` makes a
writer wait for the lock instead of failing (with one file per machine, the gateway and both QR apps share that one
lock, §6.1); `FULL` (since 24 Nov, V6 review G-14) syncs every commit to disk, so a
call the caller was told "accepted" survives a power cut. At this volume — bounded by a few KB/s of light — SQLite is
nowhere near its limits.

The schema comes from **EF migrations** (since 27 Nov 2026, decision 54: `Initial`, `Bundles` in
`QrBridge.Shared/Data/Sqlite/Migrations`; SQL Server has its own `Initial` in `Data/SqlServer/Migrations`, decision 55), applied at
startup by whichever of the gateway and the QR apps starts first, retrying
because they may start together. A `qrbridge.db` made before migrations existed (by `EnsureCreated`) is compared with
the schema each migration produces — tables, columns, CHECK constraints, indexes — and, on an exact match, recorded as
migrated with all its rows (`SchemaAdoption`); a file that matches none stops the start and is not touched. An entity
or enum change needs a new migration **for each engine** (`dotnet tool run dotnet-ef migrations add <Name> --project
sourcecode\gateway\src\QrBridge.Shared --startup-project sourcecode\gateway\src\QrBridge.Shared --context
SqliteBridgeDbContext --output-dir Data\Sqlite\Migrations`, then the same with `SqlServerBridgeDbContext` and
`Data\SqlServer\Migrations`).

### 6.5 Doorbells

SQLite has no notifications, so each side uses two named Windows events:

| Event | Rung by | Wakes |
|---|---|---|
| `Global\QrBridge.{Side}.Outbox` | gateway, after an Outbox commit | QR sender |
| `Global\QrBridge.{Side}.Inbox` | QR receiver, after an Inbox insert | one gateway delivery loop (the other two find the work at their next poll) |

`Global\` is needed because IIS runs in session 0 and the kiosk app in the user's session. The events are created
with an ACL for Authenticated Users, IIS_IUSRS, SYSTEM and Administrators. They only speed things up: every waiter
also polls (`InboxPollSeconds`, 2 s), so a missed signal delays a message by one poll at most. Why the wide ACL is
acceptable (V6 review G-14, written down in step 18): an event carries no data, so a stranger who rings it only wakes
a poll early, and one who never rings it only delays a message by one poll; the database is always the truth.
Narrow it to the app pool identity and the kiosk user only if the security review asks.

---

## 7. Security

### 7.1 One layer: QrDiode

| Layer | Protects | Keys |
|---|---|---|
| **QrDiode session** (screen to camera) | Each QR session (protocol v2): signed manifest (ECDSA P-256, low-S) checked before any payload byte is used, per-session keys (ECDH P-256 + HKDF: one for AES-256-GCM, one for a MAC on every data frame, so a QR code held up to the camera is dropped), anti-replay (session id, counter watermark per sender key and counter run, time window), strict fail-closed receive order; the replay state is saved only after the payload is stored. | Per-endpoint keys in Windows CNG (TPM-only with `"Production": true`), exchanged in a key ceremony |

The gateway envelope is **not encrypted** (decision of 23 Nov 2026, replacing design decision D13 "double layer"):
QrDiode already encrypts and authenticates everything that crosses the air gap, so the gateways need no keys of their
own. What this means:

- Business payloads are encrypted **on the QR link** only. In `qrbridge.db` (Outbox and Inbox) they are stored
  Brotli-compressed but readable by anyone who can read the data folder. Protect the folder with NTFS permissions
  (§12.4) and, if required, disk encryption (BitLocker).
- **Delivered bodies are cleared** (built 25 Nov 2026, V6 fix step 15, D3, D77): when an Inbox row ends `Done` (a
  delivered Request, or a Reply or Receipt the sending side has used), its `MessageBytes` is emptied. `MessageHash`,
  `DownstreamResult` and the header columns stay, for audit and reconciliation. Refused, Unknown, NotDelivered and
  Expired rows keep their body, because an operator may requeue them. Outbox rows are not cleared.
- The receiving gateway trusts whatever is in its Inbox. Only the QR receiver (which has verified the QrDiode session)
  and administrators may write to the Inbox of `qrbridge.db`. (With one file, file permissions can no longer give the
  QR receiver write access to the Inbox without the Outbox: they share the file. The rule is kept by the code, not the
  file system.)

### 7.2 The envelope format

```
magic        uint32   "BRG7"
headerLen    int32
header       version (7) · Direction · PayloadFormat · Compression · MessageId (16)
             · Sequence (int64) · CreatedUtc (ticks) · ServiceName · Operation · BusinessType
             · Path · SOAPAction header (present flag + text) · Content-Type
             · Kind · CorrelationId · ContentFingerprint · ExpiresUtc · SequenceRunId (16)
             · CatalogFingerprint · CallerHost                       (version 4; optional ones: present flag + value)
             · Outcome · ServiceHttpStatus (int16) · ServiceComment  (version 5; each optional: present flag + value)
             · Priority (byte)                                       (version 6)
checksum     32 bytes  SHA-256( header ‖ body )
bodyLen      int32
body         Brotli( Request: the caller's SOAP body exactly as received
                     Reply:   the real service's answer exactly as received, or empty
                     Receipt, Heartbeat: empty )
```

The header is plain text (the QR receiver reads it to fill the Inbox columns). It holds no business data —
`BusinessType` is a label such as `RETURN_ORDER`; path, SOAPAction and Content-Type are the HTTP details needed to
replay the call. Names are capped at 256 characters, the HTTP fields at 4,096; the body at `GatewayDatabase:MaxPayloadBytes`.
Each version only adds fields at the end, so earlier offsets do not move.

- **Version 4** (24 Nov 2026) added the round-trip fields
  ([V6 fix plan §4](../../sourcecode/gateway/docs/reviews/gateway-review-v6-fix-plan.md#4-the-agreed-design-round-trip-statuses-re-sending)):
  `Kind` is Request, Receipt or Reply; fingerprints are SHA-256; `CallerHost` has no control characters. In use today:
  `Kind` and `CorrelationId` (Receipts and Replies, step 9b), `ContentFingerprint` (set by the Sender part, a caller's
  retry, step 8), `SequenceRunId` (the counter's run, §6.3), `CatalogFingerprint` (§7.3) and `ExpiresUtc` (RoundTrip
  requests: queries since step 10a, permits, orders and cards since step 10c). `CallerHost` is filled on every
  Request since step 15 (§4.6).
  (`SequenceRunId` was called `SequenceEpoch` before; the bytes are the same.)
- **Version 5** (24 Nov 2026, step 9b, decision D43) added what a Reply says the far side did: `Outcome` (Done,
  Refused, Unknown, Expired, NotDelivered, Rejected), `ServiceHttpStatus` (100–599) and `ServiceComment` (at most
  1,024 characters, no control characters, plain words, never the payload).
- **Version 6** (25 Nov 2026, step 14, decision D73) added `Priority` (`MessagePriority`: `Answer` 0, `High` 1,
  `Normal` 2, `Low` 3). A Request is High, Normal or Low, never Answer (the serializer refuses it); `OutboxWriter`
  sets Answer on every Receipt, Reply and Heartbeat.
- **Version 7** (25 Nov 2026, step 17, decision D80) adds no field: `Kind` may now be **Heartbeat** ("this side is
  alive"). Refused as a version-6 message would be by an older reader, so the version moved.
- **Rules between fields**, checked on writing and on reading: a Request carries no `CorrelationId` and no outcome, and
  must have a Path and (unless `HttpGet`) a Content-Type; a Receipt must carry the `CorrelationId` of the message that arrived and no
  `Outcome`, status or comment; a Reply must carry the `CorrelationId` of its Request and an `Outcome`; a Heartbeat
  has an empty body, no `CorrelationId`, `ContentFingerprint`, `ExpiresUtc` or outcome, and priority `Answer`. Path and
  Content-Type may be empty for Receipts, Replies and Heartbeats. `ExpiresUtc` must be after `CreatedUtc`. A Request with payload
  format `HttpGet` (step 12) must have an empty body, an empty Content-Type and no SOAPAction; Receipts, Replies and
  Heartbeats are never `HttpGet`.
- `BRG3` … `BRG6` messages are refused with a clear reason ("previous format … Delete old dev databases").
  Header version 7 changed the bytes and the schema (the `Kind` CHECK constraint, the `SequenceWatermark` table); since
  27 Nov 2026 schema changes are EF migrations (§6.4), so a database is upgraded, never deleted. A new header version
  still makes queued messages of the old format unreadable: drain both queues before deploying one.

The checksum detects corruption: a mismatch makes the worker reject the message. It is **not** a security control —
anyone who can change the bytes can recompute it. Decompression is capped (zip-bomb guard).

### 7.3 Trust rules in the code

- **Destinations come from configuration only.** The replay URL is never read from a message.
- **Direction is checked.** A message packed for Corp → DMZ is rejected if it turns up anywhere else.
- **The catalogue is checked on both sides**: by the Sender part (allow-list) and again by the Receiver part.
- **Both sides run the same `routes.json`** (decision D31): every message carries the sender's catalogue fingerprint
  (SHA-256 of the services and reply profiles; the local test switches `AcceptUnlisted` / `UnlistedOneWay` are left
  out). The receiving gateway rejects a message whose fingerprint differs or is missing: light Rejected, "The route
  catalogue differs from the sender's (routes.json is not the same on both sides)". Compare `catalogFingerprint` in
  `/health`, or `Catalogue=` in the start-up log line, on both sides.
- **Replays are bounded**: messages older than `ReplayWindowDays` (7) or more than `MaxClockSkewMinutes` (60) in the
  future are rejected, and a replayed `MessageId` is caught by the Inbox primary key while its row is there. Since
  step 17 (D84) an old message is also recognised **by its number**, whatever its date: a number of the sender's
  counter run already held by another message → Rejected; a number at or below the run's watermark whose row was
  archived → Rejected (§6.3). QrDiode adds its own stricter anti-replay. **Both networks need a time source (NTP)
  while islanded**: message dates, the replay window, expiry (`ExpiresUtc`) and the hold all use the clocks; the
  number check is what still works when a clock is wrong.
- **Tampering on the QR link is rejected by QrDiode** (signed manifest, AES-GCM). A corrupted envelope fails the
  gateway's checksum and shows as `Rejected` with the reason; it is never delivered.
- **Untrusted XML** is always read with DTDs prohibited, no external resolution and size caps.
- **Payloads are never logged.** Logs contain service, operation, label, ids and sizes.

### 7.4 What the security does not cover

The header label is visible on the QR screen (inside QrDiode's own encryption, so only to whoever can decrypt the QR
session). Payloads are not encrypted at rest in either database (§7.1); an Inbox row's body is cleared once it is
Done, but Outbox rows and Inbox rows that end otherwise keep theirs. Traffic analysis (sizes, timing) is accepted.
The DMZ gateway accepts anonymous calls from anyone on the intranet (D6, [§12.4](#124-deploy-per-side)): who called is
recorded (`CallerHost`), not checked.
The key ceremony is a procedure that must be followed.
**A security sign-off for a two-way optical link is still required before go-live.**

---

## 8. Reliability and operations

### 8.1 Guarantees

| Guarantee | Because |
|---|---|
| An acknowledged call is never lost | The reply is sent only after the Outbox commit. |
| A refused call is never acknowledged | Every failure before the commit returns a SOAP fault. |
| Delivery is at least once; processing is idempotent on our side | Unique MessageId in both tables; replays of the same envelope are deduplicated. Downstream services should tolerate a rare repeat. |
| Nothing refused by the real service is silently retried | Refusals and faults end as Inbox service status Refused, with the service's answer; unclear outcomes end as Unknown. Neither is re-posted automatically. |
| Crashes and recycles do not strand messages | A row found still Delivering after a crash is settled from the Reply written for its current attempt, or ends Unknown with an Unknown Reply (never re-posted); a shutdown before the POST releases the current row. |
| A message lost on the light is noticed | Missing sequence numbers are reported per run of the sender's counter (§6.3) in the log and `/health`, until the message arrives or an operator acknowledges the gap. A lost **last** message too, once the idle side's next Heartbeat arrives (step 17). The sending side re-airs an `Aired` row with no Receipt (§6.3, built in the gateway; works on real hardware once the QR apps carry messages). |
| A dead link or far side is noticed | Each side sends a Heartbeat when idle; nothing heard from the far side for `FarSideSilentMinutes` (15) makes `/health` unhealthy (step 17). |

### 8.2 What operators see

Each row has two status groups: **light** (did it cross the light? screens, cameras, QR apps) and **service** (what did
the real service do?). The reason is in `LightComment` or `ServiceComment`; the real service's HTTP code in
`ServiceHttpStatus`.

| Status | Where | Meaning | Action |
|---|---|---|---|
| Inbox service **Retrying** | receiving side | the real service could not be reached and **nothing was sent** (DNS, refused, connect timeout, TLS, HTTP 408/429); retrying. Later Requests of the same service and class wait behind it (strict order, D74) | watch; fix the network/service if it persists |
| Inbox service **Refused** | receiving side | refused by the real service: SOAP fault, non-zero return code, 4xx, 3xx, 501, 505 (see `ServiceComment`, `DownstreamResult`) | read the reason; fix; requeue |
| Inbox service **Unknown** | receiving side | **it may have reached the service**: no answer after sending, connection reset, HTTP 500/502/503/504, a 2xx whose result can't be read, or the gateway stopped during the POST (probable reason in `ServiceComment`) | check with the service owner whether it was processed; requeue only if it was not |
| Inbox service **Expired** | receiving side | arrived (or was still waiting) after its `ExpiresUtc` (a query: its hold; a permit, order or card: `Gateway:Expiry`, 600 s): not posted, the caller has given up | none; the caller's fallback (e.g. verbal) applies; a retry is sent as a new message (D63) |
| Inbox service **NotDelivered** | receiving side | surely never reached the service and will not be tried again (no receiver target, or out of tries) | fix the configuration or the network; requeue |
| Inbox light **Rejected** | receiving side | failed checksum / direction / catalogue / payload / replay checks, or (step 17) its sequence number is already used by another message or is an old one whose row was archived | investigate (misconfiguration, a restored `qrbridge.db` on the sending side, corruption or a replay); never requeue blindly (`RequeueAsync` won't) |
| **Far side silent** (`/health` `farSide.silent`, log `Light: nothing heard from the far side since …`) | both sides | nothing at all arrived from the far side for `FarSideSilentMinutes` (15), although it sends a Heartbeat every 5 minutes when idle | check the screens, cameras and QR apps of this lane, and the far gateway (`/health` there) |
| Outbox light **Failed** | sending side | set by the gateway's `MaintenanceWorker` (step 11): aired `Gateway:MaxAirAttempts` (3) times with no Receipt, or past its `ExpiresUtc` before the far side confirmed it (reason in `LightComment`). A caller's retry of it gets the hold-timeout answer at once (D55, D68) | check the screen, the camera and the far QR Receiver; then requeue with `OutboxRepository.RequeueFailedAsync` (no UI yet) — only a requeue airs it again |
| **Missing messages** (`/health` `gaps`, log `Light: N message(s) from–to of sender run … never arrived`) | receiving side | numbers of the other side's sequence never arrived (lost on the light) | find out on the sending side what they were (Outbox, by `SequenceRunId` and `Sequence`); the sending side re-airs unconfirmed rows automatically once the QR apps carry them (§6.3), and a row out of tries is Outbox light Failed there; then acknowledge the gap with `InboxRepository.AcknowledgeGapAsync(direction, runId, from, to, who, why)` (no UI yet; stored in `AcknowledgedGap` for audit) |
| Reply 1596 / 1597 / 1598 / 1599 | caller | sent, confirmation not yet received (hold ran out; may still be done — a retry gets the real answer) / not accepted (type) / backlog full / not available (needs a live answer, or surely not done) | caller's normal error handling |

### 8.3 Monitoring

- `GET /health` on each gateway: side, machine, Outbox and Inbox counts (a `light` and a `service` map each, every
  status listed, and `oldestUndeliveredUtc` — aired Receipt and Heartbeat rows are done and not counted), heartbeats, `catalogFingerprint` (must be the same on both sides),
  `missingMessages` (numbers in the current gaps), `gaps` (up to 20: direction, run, from, to, missing since),
  `gapsCheckedUtc`, `farSide` (`lastHeardUtc`, `lastReceiptUtc`, `silent`, `silentAfterMinutes`; step 17),
  `lightProblems` (Outbox light Failed + missing messages), `serviceProblems` (Inbox service
  Unknown + Refused + NotDelivered) and `healthy` (false if any heartbeat is older than 2 minutes, `lightProblems`
  or `serviceProblems` is not 0, or the far side is silent). So a lost message keeps `/health` unhealthy until it arrives or is acknowledged.
  The gaps come from the last maintenance run; the probe does not query for them. `farSide` is read per probe (one
  indexed query).
- Heartbeats: the worker every 30 s, maintenance every minute (with the light and service counts and `missing=`); the QR apps will
  add theirs.
- Logs: the Windows Event Log (warnings and above; `QrBridge` categories at Information). Maintenance logs warnings
  prefixed `Light: …` (Outbox Failed, Inbox Rejected, oldest unconfirmed Outbox row older than 30 minutes — Receipt
  and Heartbeat rows not counted —, each row re-aired or failed by the re-air check — kind, `MessageId`, service.operation, reason —, each new
  sequence gap — once per gap —, nothing heard from the far side for `FarSideSilentMinutes`) and
  `Service: …` (Inbox Unknown, Refused, NotDelivered). At delivery, `InboxWorker` logs who called (`CallerHost`,
  e.g. "… from 10.1.2.3 (via 10.0.0.9)"), never the payload. At start-up, a warning names each RoundTrip route
  whose size limit takes longer to air than its hold (`Gateway:Light`, §10.3), and another one appears when the
  gateway runs as an administrator (step 18, §12.4).
- Each side is monitored on its own network; nothing crosses the gap for monitoring.

### 8.4 Operator SQL

To **look** at the queues, use the read-only web UI first: `https://<gateway>/qrbridge-ui` shows every Outbox and
Inbox row in plain words, with the real service's answer ([read-only-ui.md](../../sourcecode/gateway/docs/reference/read-only-ui.md)).
SQL is for what the UI deliberately cannot do (requeue, acknowledge, archive).

Open the database (`qrbridge.db`) with DB Browser for SQLite or `sqlite3`; prefer read-only queries while the apps run.

```sql
-- Queue depth by status (both tables are in qrbridge.db)
SELECT LightStatus, ServiceStatus, COUNT(*) FROM Inbox  GROUP BY LightStatus, ServiceStatus;
SELECT LightStatus, ServiceStatus, COUNT(*) FROM Outbox GROUP BY LightStatus, ServiceStatus;

-- What needs attention, with the real service's answer
SELECT MessageId, ServiceName, Operation, BusinessType, Attempts, LightStatus, LightComment,
       ServiceStatus, ServiceHttpStatus, ServiceComment, DownstreamResult
FROM Inbox WHERE LightStatus = 'Rejected' OR ServiceStatus IN ('Unknown','Refused','NotDelivered')
ORDER BY Sequence DESC;

-- Transit time across the gap (received - created), last 100
SELECT MessageId, ServiceName, BusinessType,
       ROUND((julianday(ReceivedUtc) - julianday(CreatedUtc)) * 86400, 1) AS Seconds
FROM Inbox ORDER BY ReceivedUtc DESC LIMIT 100;

-- How far each run of the other side's counter is complete (step 17): archive Inbox rows only at or below ContiguousTo
SELECT Direction, SequenceRunId, ContiguousTo, UpdatedUtc FROM SequenceWatermark;

-- Requeue one Refused / Unknown / NotDelivered row after fixing the cause (the worker picks it up within seconds).
-- For Unknown, first check that the service did not process it. Never requeue Rejected rows.
UPDATE Inbox SET ServiceStatus = 'Pending', Attempts = 0, NextAttemptUtc = NULL
WHERE LightStatus = 'Received' AND ServiceStatus IN ('Refused','Unknown','NotDelivered') AND MessageId = '...';

-- Reconciliation: compare both sides by MessageId + MessageHash
SELECT MessageId, MessageHash, LightStatus FROM Outbox WHERE CreatedUtc >= '2026-11-01';                  -- sender
SELECT MessageId, MessageHash, LightStatus, ServiceStatus FROM Inbox WHERE CreatedUtc >= '2026-11-01';   -- receiver
```

### 8.5 Switching into and out of islanding mode

- **In:** point the corporate load balancer at the Corp gateway and the FMS outbound clients at the DMZ gateway. The
  gateways and QR apps are already running (IIS AlwaysRunning, kiosk auto-start), so nothing has to start.
- **Back:** queued messages must not arrive *after* newer ones sent over the restored network:
  1. stop accepting new calls on both gateways;
  2. wait until both sides are drained (no light Pending/Sending/Aired Outbox rows, no service Pending/Delivering/Retrying Inbox rows);
  3. flip the load balancer and the DMZ configuration back;
  4. deal with any Refused/Unknown/NotDelivered/Rejected Inbox rows, Failed Outbox rows and missing messages (`/health` `gaps`) by hand.

  The "stop accepting" switch and a `/status` page with a drained flag are planned.

---

## 9. The QrDiode side (the light link)

### 9.1 What QrDiode V2 already does

| Part | Does |
|---|---|
| `QrDiode.Core` | Wire protocol: LT fountain coding (no acknowledgements needed to survive lost frames), frame format with CRC-32, signed manifest, ECDH/HKDF/AES-GCM per session, anti-replay, content gate. UI-free and unit-tested (116 tests, including optical loopback through real QR images). |
| `QrDiode.Sender` | WPF: queue, resizable QR stage window, frame pump. One payload per QR session, aired for N loops and at least 6 s, then a 1.5 s gap. |
| `QrDiode.Receiver` | WPF: camera capture (FlashCap + ZXingCpp), the verification chain, payload archive, hash-chained audit log; its journal (anti-replay, Archive tab) is in the bridge database since 27 Nov 2026 (`Storage/ReceiveJournal` over `IReceiveJournalRepository`). |
| `QrDiode.KeyCeremony` | Console: generate CNG keys, export/import public bundles, compare fingerprints. |

Today the Sender takes payloads from a simulator or a file and the Receiver writes files. Neither talks to the
shared message database (`qrbridge.db`) yet.

### 9.2 What changes to connect it to the shared message database (planned)

The project structure stays as it is: the features are added inside the existing projects. The detailed design and
the order of work are in [integration-plan.md](integration-plan.md).

| Change | Where | Why |
|---|---|---|
| Fix: a partly received session blocks every later session until restart | `QrDiode.Core` `ReceiveEngine` | Critical bug found in the review: the receiver ignores new manifests while locked on a partial session. |
| Read the Outbox through EF (`OutboxRepository`) instead of the simulator | `QrDiode.Sender` | The Outbox is the queue; claim rows only when the stage has room; never drop (today the queue drops the oldest beyond 14). |
| **Bundles**: many Outbox envelopes per QR session | Sender + `QrBridge.Shared` | One message per session costs ≥ 7.5 s — about 8 messages per minute per lane, too slow for bursts. |
| Mark rows Aired (the light status exists since 24 Nov; nothing sets it yet) / release them on failure; reset Sending at startup | Sender | Crash safety; "sent" means "aired" until Receipts move rows to Received. The gateway puts an `Aired` row with no Receipt back to Pending (step 11), so the Sender just claims it again. |
| Unpack bundles into the Inbox through EF, in one transaction; ring the doorbell | `QrDiode.Receiver` | Delivery to the gateway worker. |
| Save the anti-replay mark only after the Inbox commit | Core + Receiver | Today it is saved first, so a crash in between loses the session silently. |
| Start unattended (keys, stage, camera from configuration); heartbeats | Sender + Receiver | Kiosk operation. |
| Align SQLite packages (Receiver pins SQLitePCLRaw 3.0.5; EF Core 10.0.15 uses 2.1.13) | Receiver | One native SQLite in the process. |
| Carry Receipts and Replies (written by the gateway since step 9b) like any other row: the Sender airs them, the Receiver stores them with `AddMessageAsync` | both | Closes the "aired but never seen" gap and brings the far side's answer back; the two-way link needs security sign-off (D14). |

### 9.3 Capacity

| Figure | Value |
|---|---|
| Typical payload | 0.4–9.3 KB (simulator templates); largest SOAP request per route, as the clients send it, 848 B (IR2BFC) to 12,095 B (SSO2FMS `RETURN_ORDER`) (step 16). Requests up to the route's `MaxRequestBytes` (10 × that, D78) or else 1 MB accepted |
| Optical throughput (QrDiode estimate, one lane, ordinary webcam) | ~25–70 KB/s |
| Without bundling | ~8 messages per minute per lane (≥ 6 s air time + 1.5 s gap each) |
| With bundling (proposed, not approved or measured: example 50 messages / 128 KB per session) | potentially hundreds of messages per minute; depends on payloads, limits and hardware |
| Gateway backlog limit | 5,000 undelivered messages, then callers get "busy" (1598); an optional per-service `MaxBacklog` (none set) |
| Light speed assumed by the start-up air-time warning (`Gateway:Light`, D79) | 6,700 B/s, at least 6 s per session, 1.5 s gap — the V6 review's arithmetic, not measured; 1 MB ≈ 151 s |

---

## 10. Solution layout and code map

### 10.1 Projects

```
QrDiode_V2/
├─ All.slnx                         both solutions in one (`dotnet test All.slnx` checks everything)
├─ global.json                      pins the .NET 10 SDK for everything below
├─ sourcecode/
│  ├─ gateway/
│  │  ├─ QrGateway.slnx
│  │  ├─ src/
│  │  │  ├─ QrBridge.Gateway/       IIS: Sender part, Receiver part, maintenance, read-only UI (Ui/)   (net10.0-windows, ASP.NET Core)
│  │  │  └─ QrBridge.Shared/        EF Core + SQLite, envelope, doorbells, SafeXml  (net10.0-windows library)
│  │  └─ tests/
│  │     └─ QrBridge.Tests/         519 tests (+ Samples/: the simulator's 43 message templates)
│  └─ qrdiode/
│     ├─ QrDiode.slnx
│     ├─ src/
│     │  ├─ QrDiode.Core/           QR wire protocol, crypto, fountain codes     (net10.0 library)
│     │  ├─ QrDiode.Sender/         WPF exe: QR stage                             (net10.0-windows)
│     │  ├─ QrDiode.Receiver/       WPF exe: camera, verification                 (net10.0-windows)
│     │  ├─ QrDiode.KeyCeremony/    console exe: QrDiode keys
│     │  └─ Shared/                 source file linked into both WPF apps (payload colouring)
│     └─ tests/
│        ├─ QrDiode.Core.Tests/     116 tests
│        └─ QrDiode.Bench/          throughput bench
└─ docs/                         system architecture, gateway reference, user guide, design notes
```

### 10.2 Key files

Every class in the gateway solution, with its role and who calls it: [gateway-code-walkthrough.md](../../sourcecode/gateway/docs/reference/gateway-code-walkthrough.md).

| File | What it does |
|---|---|
| `sourcecode/gateway/src/QrBridge.Gateway/Program.cs`, `Initializer/` | Start-up: `Program.cs` calls one `Initializer/` class per step (options, data, route catalogue, endpoints, Sender part, Receiver part, workers, startup checks) |
| `sourcecode/gateway/src/QrBridge.Gateway/Controllers/` | `SenderSoapController` (POST; GET only for an `HttpGet` route), `HealthController` (`GET /health`) — the HTTP entry points |
| `sourcecode/gateway/src/QrBridge.Gateway/routes.json` | The route catalogue and reply profiles (same file on both sides: messages from a sender with another catalogue are rejected) |
| `sourcecode/gateway/src/QrBridge.Gateway/Ingress/SenderEndpoint.cs` | Every SOAP POST: read, parse, resolve, decide, store, reply; `HandleGetAsync`: the Registered Tags GET (store, hold, real answer or 504) |
| `sourcecode/gateway/src/QrBridge.Gateway/Ingress/Soap/SoapRequest.cs` | Reads any SOAP request (it loads XML through `SafeXml`, the one way untrusted XML is loaded, in `QrBridge.Shared/Configurations/Helpers/Utility.cs` since 25 Nov: the UI uses it too) |
| `sourcecode/gateway/src/QrBridge.Gateway/Ui/` | The read-only web UI (decision 48), part of the gateway project: `Pages/`, `Data/ReadOnlyBridgeDb.cs` (read-only connection), `Data/MessageQueries.cs`, `Reading/MessageReader.cs`, `UiGatewayInfo.cs` (its one way to the rest of the gateway); wired in `Initializer/UiRegistration.cs`. [Guide](../../sourcecode/gateway/docs/reference/read-only-ui.md) |
| `sourcecode/gateway/src/QrBridge.Gateway/Ingress/Soap/PayloadInspector.cs` | Reads the message label (`MESSAGE/@TYPE`, root element) |
| `sourcecode/gateway/src/QrBridge.Gateway/Ingress/Soap/SoapReplyWriter.cs` | Builds replies and faults the callers accept |
| `sourcecode/gateway/src/QrBridge.Gateway/Configurations/Options/RoutingOptions.cs`, `Routing/RouteTable.cs` | Catalogue model (the shape of `routes.json`); validation and lookup |
| `sourcecode/gateway/src/QrBridge.Gateway/Ingress/OutboxWriter.cs` | The one place messages enter the Gateway-to-QrDiode system |
| `sourcecode/gateway/src/QrBridge.Gateway/Ingress/Validation/ContractCatalog.cs`, `ServiceContract.cs` | Requests checked against each service's WSDL before they are queued |
| `sourcecode/gateway/src/QrBridge.Gateway/Egress/SoapForwarderHttpClient.cs` | Replay to the real service (POST, or GET for an `HttpGet` message); classify its answer; WS-Addressing `To` rewrite |
| `sourcecode/gateway/src/QrBridge.Gateway/Egress/Workers/InboxWorker.cs`, `MaintenanceWorker.cs` | Delivery loops (one per priority class); recovery of stuck rows, re-air of unconfirmed Outbox rows, gap check, warnings, heartbeats (no deletion) |
| `sourcecode/gateway/src/QrBridge.Gateway/Egress/AnswerWriter.cs`, `Egress/Workers/ReceiptWorker.cs` | Replies (every final outcome, Reply first) and Receipts (every arrived message) into this side's Outbox; settling rows stuck in Delivering |
| `sourcecode/gateway/src/QrBridge.Gateway/Egress/SequenceGapMonitor.cs` | Finds messages that never arrived (missing sequence numbers per run); feeds the log and `/health`; moves the runs' watermarks (step 17) |
| `sourcecode/gateway/src/QrBridge.Gateway/Egress/ArrivalChecks.cs` | The checks every arrived message passes (columns, catalogue, direction, dates, and since step 17 its sequence number); marks it Verified |
| `sourcecode/gateway/src/QrBridge.Gateway/Egress/FarSideMonitor.cs` | Step 17: sends a Heartbeat message when this side is idle; "far side last seen" and silent for `/health` and the log |
| `sourcecode/gateway/src/QrBridge.Shared/Serialization/MessageSerializer.cs`, `MessageHeader.cs` | Header + SOAP body ↔ bytes; the header (incl. path, SOAPAction, Content-Type) |
| `sourcecode/gateway/src/QrBridge.Shared/Data/…` | Entities, EF configurations, the one DbContext (`BridgeDbContext`, `qrbridge.db`), repositories, SQLite setup |
| `sourcecode/gateway/src/QrBridge.Shared/Signals/BridgeSignal.cs` | Named-event doorbells |

### 10.3 Design rules in the code

- `QrDiode.Core` stays independent of the SOAP Gateway: no EF, no SQLite, no knowledge of SOAP. Gateway and shared data code lives in
  `QrBridge.*` and is referenced by the WPF apps.
- One way in (`OutboxWriter`), one way to read untrusted XML (`SafeXml`), one place for routes (`routes.json`).
- Options are read only after the host is built, so environment variables, command-line values and tests always
  override the files.
- The gateway refuses to start rather than accept messages nobody could deliver: an invalid catalogue (including
  round-trip settings that could not give the agreed answer, e.g. `OnHoldTimeout: Pending` without a `Pending`
  value), an `HttpGet` service that breaks the rules in [§4.9](#49-get-requests-and-health-probes), a `"Priority": "Answer"` or a `MaxRequestBytes` / `MaxBacklog` of zero or less in `routes.json`, a lock timeout shorter than the delivery timeout, a replay window or clock-skew limit of zero or less, a
  `GapGraceMinutes` below zero, a `Gateway:ReceiptTimeoutSeconds` or `Gateway:MaxAirAttempts` of zero or less, a `Gateway:HeartbeatMinutes` below zero or a `Gateway:FarSideSilentMinutes` of zero or less or not longer than `HeartbeatMinutes` (step 17), a `Gateway:Hold` of zero or less or for a service with no callers on this side, a `Gateway:Light:BytesPerSecond` of zero or less or a negative `MinAirSeconds` / `GapSeconds`, or a
  Receiver URL that is not absolute or is plain `http://` outside Development without
  `Gateway:Receiver:AllowHttp`. (The check "`RetentionDays` at least `ReplayWindowDays`" went with the setting on
  24 Nov: rows are no longer deleted, so a replayed message is always caught by its `MessageId`.)
- It only **warns** (step 16, D79; `StartupChecks.AirTimeWarnings`) for each RoundTrip route on this side whose size
  limit (`MaxRequestBytes`, else `GatewayDatabase:MaxPayloadBytes`) takes longer to air at `Gateway:Light` speed than its hold.
  At 1 MB that is about 151 s, so on the DMZ side (90 s hold) every DMZ round-trip route warns (none has
  `MaxRequestBytes`), and on any side with a short hold the legacy routes warn too.
- It also only **warns** when it runs as an administrator (step 18, D4; `StartupChecks.AdministratorWarning`): it
  should run as its own app pool identity ([§12.4](#124-deploy-per-side)).

---

## 11. Configuration reference

Configuration is layered: `appsettings.json` → `appsettings.{Corp|Dmz}.json` (chosen by `ASPNETCORE_ENVIRONMENT`, set
in `web.config`) → `routes.json` → environment variables (e.g. `Gateway__Receiver__DefaultBaseUrl`) → command line.

**`GatewayDatabase`** — the database shared with the QR apps on the same machine (their `QRDatabase` section): every
value must match theirs. Renamed from `Bridge` on 27 Nov 2026 (decision 57); the gateway and both QR apps refuse to
start while a former `Bridge` section (or a `Bridge__…` environment variable) is still there.

| Key | Default | Meaning |
|---|---|---|
| `Side` | `Corp` | `Corp` or `Dmz` |
| `DataFolder` | `C:\ProgramData\QrBridge\Data` | where `qrbridge.db` lives (local disk) when the engine is SQLite; the start is refused while a former `send.db` or `received.db` is here |
| `Provider` | `Sqlite` | `Sqlite` (`qrbridge.db` in `DataFolder`) or `SqlServer` (decision 55). The gateway and both QR apps on a machine must use the same values |
| `ConnectionString` | empty | `SqlServer` only: the one connection for the gateway, its read-only UI and both QR apps. Use Integrated Security (app pool identity, kiosk user), never a password; the start is refused when empty |
| `MaxPayloadBytes` | `1000000` | largest request accepted / payload decoded; a real service's answer larger than this is left out of its Reply. A service's `MaxRequestBytes` in `routes.json` can only lower the request limit (the smaller applies) |

**`Gateway`**

| Key | Default | Meaning |
|---|---|---|
| `MaxBacklog` | `5000` | above this many undelivered Outbox **Requests** (light Pending, Sending or Aired), new calls get "busy"; Receipts and Replies are not counted (D47). A per-service limit is `MaxBacklog` in `routes.json` |
| `RetryWindowMinutes` | `30` | a call with the same content fingerprint as one queued less than this long ago is a caller's retry (attached on `RecogniseRetries` routes, counted elsewhere); on the far side, how far back the same-content check looks before a POST (step 10b); must be positive |
| `InboxPollSeconds` | `2` | poll interval of each delivery loop (the doorbell wakes one loop sooner; the other two find new work at their next poll); also how often `ReceiptWorker` sends the Receipts owed and `AnswerReader` reads arrived Receipts and Replies |
| `MaxAttempts`, `BackoffBaseSeconds`, `BackoffMaxMinutes` | `8`, `30`, `30` | retry policy for transient delivery failures |
| `ReplayWindowDays`, `MaxClockSkewMinutes` | `7`, `60` | message age limits (a second check since step 17: an old message is also recognised by its sequence number, §7.3) |
| `MaintenanceIntervalSeconds`, `LockTimeoutMinutes` | `60`, `5` | housekeeping; a row still Delivering after `LockTimeoutMinutes` is settled from the Reply written for its current attempt, or Unknown |
| `GapGraceMinutes` | `5` | a missing sequence number is reported only once the message after it arrived this long ago (bundles may arrive out of order); `0` = at once; must be 0 or more. There is no retention setting: rows are never deleted automatically |
| `ReceiptTimeoutSeconds` | `120` | an Outbox row (not a Receipt or Heartbeat) still light `Aired` this long after it was aired is aired again, or Failed when out of tries or expired (D65, step 11); checked once a minute, so the real wait is 120–180 s; must be positive |
| `MaxAirAttempts` | `3` | airs in total, the first one included (the `Attempts` column), before an unconfirmed row becomes light Failed (D66); must be positive |
| `HeartbeatMinutes` | `5` | when this side has queued nothing for this long (counted from start-up at the latest), it sends an empty Heartbeat message (D80, D81, step 17); checked once a minute; `0` = off; must be 0 or more. Use the same value on both sides |
| `FarSideSilentMinutes` | `15` | nothing heard from the far side for longer than this (counted from start-up until something is heard) → `/health` `farSide.silent`, `healthy = false`, and a `Light:` warning (D82, D83, step 17); must be positive and longer than `HeartbeatMinutes` |
| `Hold:DefaultSeconds`, `Hold:Services:{Service}` | `90`; Corp `270`, Dmz `90` | how long a RoundTrip caller is held for the real answer (D11); must be positive; a per-service override must name a service whose callers are on this side. Used by `SenderEndpoint` since tracker step 10a; a query's `ExpiresUtc` is now + this hold (D54) |
| `Expiry:DefaultSeconds`, `Expiry:Services:{Service}` | `600` (Corp and Dmz `600`) | how long after it was sent a state-changing RoundTrip call (`OnHoldTimeout: Pending`: permits, orders, cards) may still be posted on the far side: `ExpiresUtc` = now + this (D62, step 10c); after it, Inbox Expired and the caller's fallback (e.g. verbal) applies. Must be positive and longer than the service's hold; a per-service override must name a service whose callers are on this side (start-up check). Queries use their hold; `Bridge` calls never expire |
| `Light:BytesPerSecond`, `Light:MinAirSeconds`, `Light:GapSeconds` | `6700`, `6`, `1.5` | the QR link's speed, used **only** for the start-up air-time warning (D79, step 16; §10.3). The V6 review's arithmetic for QrDiode, not measured: update once the real link is measured. Start-up refuses `BytesPerSecond` ≤ 0 or negative seconds |

**`Gateway:Receiver`** — delivery to the real services on this side.

| Key | Default | Meaning |
|---|---|---|
| `DefaultBaseUrl` | empty (Corp); `https://dmz-rr-server` placeholder (Dmz) | the caller's original path is appended. Must be `https://`: start-up refuses `http://` (outside Development) |
| `Targets:{Service}:Url`, `:TimeoutSeconds` | none | per-service override; same `https://` rule |
| `Targets:{Service}:UseDefaultCredentials` | none (follows the global setting) | `true` / `false` for this service only (D75, step 15) |
| `TimeoutSeconds` | `120` | per call; must stay below `LockTimeoutMinutes`. No answer within it **after sending** → Unknown |
| `ConnectTimeoutSeconds` | `15` | time to connect (DNS, TCP, TLS) before anything is sent; past it → nothing sent, posted again. Must be positive and shorter than every `TimeoutSeconds` (start-up check), or "never connected" and "sent, no answer" could not be told apart (D42) |
| `AllowHttp` | `false` | `true` lets a **test bench** use `http://` URLs. Never on a production gateway: permits and orders would cross the network unencrypted |
| `UseDefaultCredentials` | `false` | `true` = authenticate to the real services as the app pool identity, `false` = anonymous. Three named HTTP clients: `receiver` (this setting), `receiver-default-credentials` and `receiver-anonymous`; `SoapForwarderHttpClient.ClientNameFor(service)` picks one per target. Never a password in configuration; no Credential Manager accounts |
| `RewriteAddressingTo` | `true` | point `wsa:To` at the real service |
| `MaxResponseBytes` | `4000000` | largest reply read back |

**`Ui`** — the read-only web UI under `/qrbridge-ui` (decision 48; [read-only-ui.md](../../sourcecode/gateway/docs/reference/read-only-ui.md)).

| Key | Default | Meaning |
|---|---|---|
| `Enabled` | `true` | serve the UI; `false` maps nothing (its paths get 405) |
| `Username`, `Password` | `admin`, `admin` | the one login; set your own per site in `appsettings.{Side}.json` (a start with the default logs a warning; empty values stop the start). Never commit a real password |
| `SessionMinutes` | `480` | how long a login lasts (sliding); must be positive |
| `PageSize` | `50` | rows per list page until the viewer picks 10, 25, 50, 100 or 200; 1–500 |
| `TimeZone` | `Eastern Standard Time` | the zone the pages show times in (EST / EDT); the database keeps UTC. An unknown id stops the start |
| `RefreshSeconds` | `10` | the viewer's optional auto-refresh interval; must be positive |

**`Routing`** (in `routes.json`)

| Key | Meaning |
|---|---|
| `AcceptUnlisted` | accept SOAP calls to services not in the catalogue (test/discovery; `false` in production) |
| `UnlistedOneWay` | for unlisted calls, reply HTTP 202 instead of an empty SOAP reply |
| `ReplyProfiles:{Name}` | `ResultKind` (`FmsResponse`, `ReturnCode`, `None`) and the values `Ok`, `Busy`, `Unavailable`, `Pending`, `Rejected` |
| `FingerprintIgnore[]` | fields that change on every send (`MSG_ID`, `GMT_TIME_SENT`, `RRMsgID`), left out of the content fingerprint that will recognise a caller's retry (D5, tracker step 8) |
| `Services[]` | `Name`, `Description`, `SenderSide`, `Paths[]`, `Style` (`Document`/`Rpc`), `ResultElement`, `OtherOperations`, `Operations`; `HttpGet` (`true` = a plain HTTP GET interface, not SOAP: Registered Tags, step 12; strict shape checked at start-up, [§4.9](#49-get-requests-and-health-probes)); optional `MaxRequestBytes` (bigger calls get HTTP 413 before anything is parsed or queued; the smaller of it and `GatewayDatabase:MaxPayloadBytes` applies) and `MaxBacklog` (most Requests of this service waiting to cross — light Pending, Sending, Aired — before new calls get the route's Busy answer, 1598; counted in the same write transaction) (step 16, D78; start-up refuses values ≤ 0) |
| `Services[].Operations:{Op}` | `Mode` (`Bridge`/`RoundTrip`/`Echo`/`Unavailable`/`Reject`), `Reply` (profile name), `OneWay`, `AllowedTypes[]`, `OnHoldTimeout` (`Pending` = 1596, default, or `Unavailable`), `FingerprintIgnore[]` (added to the catalogue's), `RecogniseRetries` (attach a caller's retry to the first message; unset = on for RoundTrip with `OnHoldTimeout: Pending`, off for queries and `Bridge`, D37, D56; on the far side it also turns on the same-content check before the POST, step 10b), `Priority` (`High`/`Normal`/`Low`; unset = the default class, [§4.10](#410-delivering-on-the-other-side); `Answer` refused at start-up; step 14), `Types:{TYPE}` (per message type: `Mode` — `Bridge`/`RoundTrip`/`Unavailable` —, `OnHoldTimeout`, `FingerprintIgnore[]`, `RecogniseRetries`, `Priority`; unset values follow the operation) |

`routes.json` is read at startup; after changing it, recycle the app pool. A catalogue error stops the start with a
list of the problems.

**Size limits set today (D78, step 16):** `MaxRequestBytes` = 10 × the largest simulator template of the route,
measured as the SOAP request the client really sends:

| Route | Largest template (bytes) | `MaxRequestBytes` |
|---|---|---|
| DSS2FMS | 1,688 | 16,880 |
| FC2FMS | 3,844 (`RETURN_PERMITS`) | 38,440 |
| FOD2FMS | 1,644 | 16,440 |
| FTC2FMS | 2,773 | 27,730 |
| IR2BFC | 848 | 8,480 |
| SSO2DSO | 7,995 | 79,950 |
| SSO2FMS | 12,095 (`RETURN_ORDER`) | 120,950 |
| SSO2TLS | 1,272 | 12,720 |
| SSO2TOMS | 10,270 | 102,700 |
| VZ2TLS | 7,044 | 70,440 |
| XA2FMS | 944 | 9,440 |

Routes without templates (the legacy endpoints except DSS2FMS, every DMZ → Corp route, Registered Tags) stay on the
global 1 MB. No `MaxBacklog` is set. **Not verified:** real messages may be larger than the simulator's templates
(e.g. an order with many switching steps); such a call would get 413 — a false failure, and the caller falls back to
manual work. Check against real sizes (V6 review Q4).

---

## 12. Build, test, publish and deploy

### 12.1 Build and test

```powershell
cd QrDiode_V2
dotnet build All.slnx                      # both solutions, 0 warnings
dotnet test  sourcecode\gateway\tests\QrBridge.Tests          # 519 tests
dotnet test  sourcecode\qrdiode\tests\QrDiode.Core.Tests      # 116 tests
```

Requires a released .NET 10 SDK (developed with 10.0.404) on Windows; the tests use Windows named events.
`dotnet test All.slnx` does all of the above in one go. Keep the solution at a short path (e.g. `C:\src\QrDiode_V2`):
from a very deep folder Windows refuses to load the native `ZXing.dll` ("filename or extension is too long").

### 12.2 What the tests prove

Counts are test cases as `dotnet test` reports them (each case of a theory counted), 25 Nov 2026.

| Test class | Tests | Proves |
|---|---|---|
| `SenderTests` | 100 | **Every one of the simulator's 43 message templates**, sent to its real interface, gets the answer its caller expects (feeds accepted with RETURN_CODE 0 / `0`; permits, orders and cards held and answered 1596 when no answer comes back, since step 10c; Unavailable 1599, Refused 1597, fault, or echo); accepted ones are stored and open back to the **exact request bytes** with the original path and `SOAPAction`. Also: duplicates, wrong message type, malformed payload, legacy RPC endpoint, unknown service/operation, non-SOAP and oversized requests, GETs other than `/health` get 405, backlog full, start-up refusals of inconsistent settings. Since step 16: a call over its route's `MaxRequestBytes` gets 413 before anything else; a route's own `MaxBacklog` refuses only its own calls (1598); the start-up air-time warning names a RoundTrip route whose size limit takes longer to air than its hold. Since step 17: heartbeat and far-side-silent settings that cannot work stop the start; since step 18: a gateway running as an administrator is warned about. |
| `DmzSenderTests` | 9 | The DMZ gateway takes what the DMZ interface services send to the corporate systems (DMZ → Corp): each call must match the corporate service's WSDL and carry a message type that DMZ caller really sends. |
| `WcfClientTests` | 3 | **Real WCF client stacks** accept the gateway as the real service: BasicHttp (FC2FMS `SendToFMS`/`GetFromFMS`/`EchoString`), ASMX-style XmlSerializer (VZ2TLS, `long`), WSHttp SOAP 1.2 + WS-Addressing to a service the catalogue has never seen. |
| `ServiceContractTests` | 3 | The SOAPAction is checked against the WSDL: quoted or not, another operation's action refused, no action not checked (step 3). |
| `EndToEndTests` | 17 | Corp gateway → envelope carried across → DMZ gateway → fake real service: **identical bytes, path, `SOAPAction`**; a refusal ends as service status Refused with the service's reason; a 2xx without a readable result ends Unknown; a message with no receiver target ends NotDelivered; a wrong-direction or corrupted envelope, another route catalogue, a type not forwarded here, a Reply disguised as a Request and a row whose `Priority` column disagrees with its message are Rejected and never delivered; a missing message is reported until acknowledged. Since step 17: a message reusing a number another message already has, and an old message replayed after its row was archived, are Rejected and never posted; a lower number arriving later, or a request re-posted after the watermark moved, is still delivered. |
| `DeliveryOutcomeTests` | 28 | Step 9a, decision D9, one test per row of the fix plan §4.3 table: re-post only when the call surely did not arrive (refused, DNS, connect timeout, TLS, 408, 429), Unknown when it may have (timeout after sending, reset, 500/502/503/504), Refused otherwise; partly on a real socket. |
| `ReplyAndReceiptTests` | 15 | Step 9b and 11: a Receipt for every arrived message (again when it arrives twice), a Reply for every final outcome with the real answer; crash recovery from the Reply; re-air of an unconfirmed row and Failed when out of tries. |
| `SoapParsingTests` | 18 | SOAP 1.1/1.2, WS-Addressing, RPC detection, action sources; DTDs and non-SOAP refused; labels from FMS, Verizon, tML-TA and malformed payloads. |
| `SoapReplyWriterTests` | 6 | Reply shapes: document/literal, RPC, SOAP 1.2 + addressing, faults 1.1/1.2, 202. |
| `RouteTableTests` | 64 | Path normalisation, resolution rules, side check, invalid catalogues fail, and the **shipped `routes.json`** is valid and covers the FMS interfaces, with permits, orders and cards RoundTrip and the feeds `Bridge` (step 10c). Since steps 14 and 16: a route can choose its priority class but never `Answer`; `MaxRequestBytes` and `MaxBacklog` must be positive. |
| `ContentFingerprintTests` | 6 | The content fingerprint (D5, D38) in both directions: a field that changes per send is ignored, a business difference is not. |
| `RetryTests` | 6 | Step 8: a caller's retry is attached to the first message where `RecogniseRetries` is on, and only counted elsewhere. |
| `DeliveryClassificationTests` | 29 | How every kind of real-service answer is classified. |
| `MessageSerializerTests` | 37 | Round trip (header incl. replay details; body byte for byte; null SOAPAction), header peek, bad header refused, checksum catches header and body corruption, truncation, size and zip-bomb limits, compression ratio. Since step 14: the priority travels in the header and a Request is never `Answer`. Since step 17: a Heartbeat names no message, carries nothing and goes first; `BRG3` … `BRG6` messages are refused with a clear reason. |
| `RepositoryTests` | 33 | EF/SQLite mapping, atomic claims under concurrency, idempotent Inbox, refused rows and requeue, backoff, out of retries ends NotDelivered, a row stuck in Delivering ends Unknown, NotDelivered, Rejected rows kept out of service work, impossible HTTP status refused, gaps per counter run and their acknowledgement, heartbeats. Since steps 14 and 15: the light airs answers first, then Requests by class; each delivery loop claims only its own class; a new run of the sender's counter never jumps ahead of older messages; a Done row keeps no body (but its hash), a row for an operator keeps its body. |
| `HoldTests` | 27 | Tracker steps 10a and 10c, two in-memory gateways with the test copying bytes as the light: a held RoundTrip call gets the **real answer byte for byte**; each far-side outcome gives the agreed answer (D50); no answer → 1596 and an expiry after `Gateway:Expiry` (not its hold) for a permit, or 1599 and an expiry after its hold for a query; light Failed → hold-timeout answer at once; a retry waits for the same answer, but a retry of a message that surely was not done is sent as a new message (D63); a caller that hangs up leaves its message queued; queries never attached; a bad Reply is Rejected; Receipts and Replies update the sending side. |
| `FarSideTests` | 13 | Tracker steps 10b and 10c: the same content is posted again only when the earlier one surely was not processed; `Bridge` routes post it twice; an unreachable query ends NotDelivered at once; a Reply after an operator requeue replaces an earlier answer that was not Answered, only when newer (D59); a requeued request found stuck is Unknown, not its previous answer (D64). |
| `RegisteredTagsTests` | 8 | Tracker step 12: the Registered Tags GET crosses and the real answer is replayed byte for byte (status, Content-Type, body, e.g. 200 or 404); no answer in time → HTTP 504 and the request expires with its hold; an unreachable report service → 504 at once; a query string, a SOAP POST or another method is refused and nothing is queued; a GET message is only replayed for the GET route, and a SOAP message never for it. |
| `LightFaultTests` | 5 | Tracker step 13, faults on the light: happy path; a lost request is re-aired; a lost reply is re-aired by the far side; a lost receipt is re-aired but never posted again; a duplicate session is stored and posted once. |
| `CallerFaultTests` | 7 | Tracker step 13, faults at the caller: a retry after 1596 gets the real answer without a second message; a late reply is kept for the next retry; the caller hangs up; a message that expires on the light is not posted and the retry is a new message; Unknown is never re-posted and every retry gets 1596; two identical calls at once make one message; the gateway restarts during a hold. |
| `PriorityTests` | 1 | Tracker step 14 (D73, D74), two in-memory gateways: a permit is delivered while a slow feed is still being posted (one delivery loop per class). |
| `CallerAndCredentialTests` | 8 | Tracker step 15 (D75–D77): `CallerHost` is the first forwarded address labelled with the connection's ("10.1.2.3 (via 10.0.0.9)"), IPv6 too, and anything that is not an address (e.g. a line break) is ignored; the caller's address travels in the message header; the far side's delivered Request and this side's used Reply keep no body, only their hash; a target can be called with or without the app pool identity (the three named HTTP clients). |
| `Ui/*` (read-only UI) | 64 | The login page is only the sign-in panel (no header or footer); Database paging with an always-shown footer (page size, page n of m; search paged too); correlation ids in lists and details, search by a short id; times in Eastern time; Decision 48: a busy islanding day on two gateways (every kind and status) renders on every page of both UIs (`UiDemoDataTests`, also the sample-data generator); no UI class depends on code that writes (the UI shares the gateway project); every page needs the login (admin/admin or the configured one), the login page and assets do not; return URLs only to UI pages; security headers; the UI's connection refuses writes and browsing changes no row; the Outbox list and detail show the path, SOAPAction, Content-Type, the FMS message unescaped and indented and the bytes as stored; markup inside a payload is shown as text; filters and search; a round trip reads on both sides (Corp: the real answer; DMZ: the delivery URL from `Gateway:Receiver` and the answer from its Reply); every other GET still 405; `Ui:Enabled = false`; a route under `/qrbridge-ui` stops the start; `MessageReader` (DTD never expanded, damaged bytes, JSON, plain values). |
| `HeartbeatTests` | 4 | Tracker step 17 (D80–D83), two in-memory gateways: `/health` turns unhealthy when nothing was heard from the far side for 15 minutes and healthy again when something arrives; an idle gateway sends a Heartbeat the far side hears, with no Receipt and never re-aired; while the light is down only one Heartbeat waits (they never pile up ahead of real messages); a Heartbeat after a lost last message makes the loss show as a gap. |

`LightFaultTests` and `CallerFaultTests` run on `Gateway/Infrastructure/TwoGatewayBench.cs` (a Corp and a DMZ gateway,
a scripted real service, a restart of the Corp gateway) and `Gateway/Infrastructure/FakeLight.cs` (the QR link in both
directions, as the QrDiode apps will run it: claims each Outbox row, marks it Aired, stores it in the other gateway's
Inbox; per row, 0 copies = a lost session, 1 = arrives, 2 = a duplicate session; each lane can be paused). They prove
the behaviour **in memory with a fake light only**, not on real screens and cameras.

The other classes' counts are from 23 Nov and have grown since, and newer classes (e.g. `RetryTests`) are not listed;
the full run is `dotnet test All.slnx` (568 gateway + 116 QrDiode tests on 27 Nov 2026, after the UI password became a hash).

The published gateway was also run as a real process: it accepted a real SOAP call, replied `RETURN_CODE 0` with
`MSG_TYPE`/`MSG_ID` and reported healthy.

### 12.3 Publish

```powershell
dotnet publish sourcecode\gateway\src\QrBridge.Gateway -c Release -o publish\gateway
dotnet publish sourcecode\qrdiode\src\QrDiode.Sender -c Release -r win-x64 --self-contained -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish\sender
dotnet publish sourcecode\qrdiode\src\QrDiode.Receiver -c Release -r win-x64 --self-contained -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish\receiver
dotnet publish sourcecode\qrdiode\src\QrDiode.KeyCeremony -c Release -r win-x64 --self-contained -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish\keys
```

| Folder | Contents | Goes to |
|---|---|---|
| `publish\gateway\` | framework-dependent ASP.NET Core app, `web.config`, `routes.json` | the IIS site folder, each side |
| `publish\sender\` | `QrDiode.Sender.exe`, self-contained single file (~134 MB) | kiosk PC |
| `publish\receiver\` | `QrDiode.Receiver.exe`, self-contained single file (~139 MB) | kiosk PC |
| `publish\keys\` | `QrDiode.KeyCeremony.exe`, self-contained single file | kiosk PC, key ceremony |

`QrBridge.Shared` is compiled into the gateway and the WPF apps; it is never deployed on its own. The read-only web
UI is part of the gateway project (folder `Ui/`): `publish\gateway\` is the whole deployment, with no `wwwroot` and no second site.

### 12.4 Deploy, per side

1. Windows: IIS with Application Initialization, and the **.NET 10 Hosting Bundle**. Do **not** install WCF HTTP Activation.
2. Copy `publish\gateway\` to the site folder, then create the IIS site and app pool by hand (app pool: No Managed
   Code, AlwaysRunning, idle time-out 0, no periodic recycle (one scheduled at 03:00, outside busy hours: a recycle
   during a POST leaves that message Unknown, D41, and drops held callers, whose retries get the stored answer), one
   worker process (the held callers wait in memory), generous shutdown time; site preload; `ASPNETCORE_ENVIRONMENT`
   in `web.config`).
3. **App pool identity** (decision D4, V6 review G-06, step 18): one dedicated identity per side. The default
   `ApplicationPoolIdentity` (`IIS APPPOOL\<pool name>`) when the real services take anonymous calls; a dedicated
   domain service account when `UseDefaultCredentials` must authenticate to them (item 6). Never a member of
   Administrators — the gateway logs a start-up warning "The gateway is running as an administrator …" if it is
   elevated (it still starts) — and no interactive logon. It needs only: read on the site folder, Modify on the data
   folder (item 4), and outbound HTTPS to its Receiver targets (allow just those in the server firewall).
4. **Data folder** `C:\ProgramData\QrBridge\Data`: the payloads in it are **not encrypted** (§7.1). Turn off
   inheritance; Modify for the app pool identity and the kiosk user, Full for SYSTEM and Administrators, nobody else.
   For example (use your pool name and kiosk account):
   ```powershell
   icacls C:\ProgramData\QrBridge\Data /inheritance:r /grant:r "SYSTEM:(OI)(CI)F" "Administrators:(OI)(CI)F" "IIS APPPOOL\QrBridge:(OI)(CI)M" "CORP\qr-kiosk:(OI)(CI)M"
   ```
   Turn on **BitLocker** for the disk that holds it (decision D3). Local disk only, never a network share (§6.1).
   The folder holds one database, `qrbridge.db`, created at the first start. On a machine that ran a version from
   before 25 Nov 2026, the gateway **refuses to start** while `send.db` or `received.db` is still there: check them for
   undelivered messages, then move them (with their `-wal` and `-shm` files) out of the folder (§6.1).
5. **IIS request limits** (G-06): set `requestFiltering/requestLimits/@maxAllowedContentLength` on the site to about
   twice `GatewayDatabase:MaxPayloadBytes` (e.g. `2000000`): IIS then cuts off a multi-megabyte flood before the gateway reads
   it, while a body just over the limit still gets the gateway's own SOAP fault (HTTP 413, §4.8). It is **not** set in
   the shipped `web.config` (IIS's default is 30,000,000). Leave URL and query-string limits at their defaults.
6. On the DMZ, `appsettings.Dmz.json`: `Receiver:DefaultBaseUrl` = the RR servers (or per-service `Targets`).
   Credentials to the real services: `Receiver:UseDefaultCredentials` (the app pool identity, or anonymous), per
   service `Receiver:Targets:{Service}:UseDefaultCredentials` (D75). No passwords, no Credential Manager accounts.
7. **Who may call the gateway** (D6, decided by Rowshan, against the V6 review's recommendation): the DMZ
   gateway accepts **anonymous** calls from anyone on the intranet; callers that used Negotiate simply call it
   anonymously. IIS configuration only. **IP restrictions** may be added later with the IIS "IP and Domain
   Restrictions" feature: allow only the load balancer (Corp) or the FMS servers' addresses (DMZ). Who called is
   recorded in each message (`CallerHost`, [§4.6](#46-storing-the-call-byte-for-byte-then-reply)) and logged at
   delivery. Without an `X-Forwarded-For` header it holds the connection's address (behind a load balancer, the load
   balancer's).
8. **Registered Tags** (Corp, D18): IIS must let `GET /FMS_ReportService/RegisteredTags.asmx/GetData` reach the
   gateway — no `.asmx` handler mapping and no request filtering of `.asmx` or of GET on the site. The shipped
   `web.config` sends every path and verb to the gateway (`path="*" verb="*"`); not tried on a real IIS.
9. **A time source on both networks while islanded** (NTP): message dates, the replay window, expiry and the hold use
   the clocks (§7.3).
10. Check `http://<server>/health` (the health probe; the only other GETs the gateway answers are the Registered Tags
    report on Corp and the read-only UI under `/qrbridge-ui`). Compare its `catalogFingerprint` with the other side's: they must be equal (same `routes.json`).
    Within 15 minutes of both sides running, `farSide.lastHeardUtc` must fill in (each side's Heartbeat, step 17).
11. Kiosk PC: QR apps; power plan never sleep, screensaver off. In the `appsettings.json` next to
    `QrDiode.Sender.exe`, `QrDiode.Receiver.exe` and `QrDiode.KeyCeremony.exe`:
    - **`"QrDiode": { "Production": true, "Mode": "Gateway" }`** (decisions 50, 53): Demo setup hidden and refused, demo
      keys and bundles refused, TPM-backed keys only — so run `KeyCeremony init` on the kiosk itself, as the kiosk user,
      after setting it; Gateway mode airs this machine's Outbox and writes its Inbox.
    - **`"QRDatabase"`** in both QR apps = the gateway's own `GatewayDatabase` section on this machine (`Side`, `DataFolder`,
      `MaxPayloadBytes`, `Provider`, `ConnectionString`). The kiosk user needs Modify on the data folder (item 4).
    - **`"Sender": { "AutoStart": true, "Endpoint": "<this machine>", "Receiver": "<far receiver>" }`** and
      **`"Receiver": { "AutoStart": true, "Endpoint": "<this machine>", "Camera": "<part of its name>" }`**. Place the stage
      once by hand in front of the far camera and close it: it reopens there (per user, `sender-stage.json`).
    - Two scheduled tasks for the kiosk user, trigger "At log on", action the exe, "Run only when user is logged on",
      no "Stop the task if it runs longer than"; Windows auto-logon for the kiosk account.
    Sender and Receiver must run the same QrDiode protocol (v2 since 26 Nov 2026, decision 49): deploy both sides' QR
    apps together. `KeyCeremony verify-audit` checks both apps' audit logs. `/health` shows `SenderLoop` and
    `ReceiverLoop` heartbeats every 30 s while they run.
12. **Read-only UI** (decision 48): set `Ui:Username` / `Ui:PasswordHash` in `appsettings.{Side}.json` (not admin/admin;
    the hash comes from `sourcecode\gateway\scripts\new-ui-password-hash.ps1`, a clear password stops the start),
    serve the site over **https** (the pages show payloads in clear), and restrict `/qrbridge-ui` with IIS "IP and
    Domain Restrictions" to the operators' machines; on Corp, keep the load balancer from forwarding `/qrbridge-ui`.
    Or set `Ui:Enabled = false`. Logins survive an app pool recycle only when the pool loads its user profile (ASP.NET
    key ring); otherwise users sign in again. Not tried on a real IIS.
13. Islanding: re-point the load balancer (Corp) and the FMS outbound configuration (DMZ) — [§8.5](#85-switching-into-and-out-of-islanding-mode).

None of items 2–10 and 12 has been tried on a real server: they are the agreed set-up (step 18), not a tested script
(known issue 9: no deployment scripts).

**Running it:**

- **Archive manually; nothing is deleted automatically** (decision D28). The database grows with every message. To
  archive, stop the gateway and both QR apps (they all write `qrbridge.db`), copy the database, then delete rows that are
  finished (Inbox service Done, Outbox light Received) and older than you need for audit. **Never delete rows younger
  than `Gateway:ReplayWindowDays`** (7 days), and in the Inbox only rows whose `Sequence` is at or below their run's
  `ContiguousTo` in `SequenceWatermark` (step 17): those numbers are then remembered without the rows, so a replayed
  old message is still refused. **Never delete `SequenceWatermark` or `AcknowledgedGap` rows.** Deleting Inbox rows can
  make old numbers look missing to the gap check; acknowledge such a gap with the reason "archived".
- **Back up `qrbridge.db`**, with the apps stopped or with `sqlite3 qrbridge.db ".backup <copy>"`. It holds both
  directions: the Outbox and the `SequenceCounter` row with the counter's run id (§6.3), and the Inbox with the
  watermarks and acknowledged gaps.
- **Restoring `qrbridge.db`** (since 25 Nov 2026 a restore brings back **both** directions to the time of the backup):
  - *This side's sending:* a new or deleted `qrbridge.db` starts a new run, which the far side handles cleanly. A
    restored backup **keeps its run**, so its counter may hand out numbers the far side already has from that run.
    Since step 17 the far side **refuses** such a message (Rejected: "Sequence number … is already used by …", or "An
    old message shown again" when that row was archived), so whatever is queued under a reused number is never
    delivered. Only restore a backup whose numbers the far side has not already passed (compare the backup's
    `LastValue` with the highest `Sequence` of that run in the far side's Inbox); otherwise start with a new, empty
    `qrbridge.db`.
  - *This side's receiving:* the Inbox, `SequenceWatermark` and `AcknowledgedGap` go back to the time of the backup.
    Messages that arrived after the backup are gone from this side; the far side will not re-air those it already has
    a Receipt for. They show up as missing numbers (§8.2) once later messages arrive, and an operator must check them.
    The watermark also
    goes back, so the "old message shown again" check (D84) is weaker for numbers above the restored watermark; the
    QrDiode anti-replay check on the light is not affected (it keeps its own state). **Not tested.**
  - Until 25 Nov 2026 the two directions were in separate files and could be restored separately; that is no longer
    possible.

To confirm with the network team: does the load balancer forward the path unchanged, where is TLS terminated, and
how many servers sit behind it (it must send everything to one gateway, with any second one only as standby). Its
health probe must be `GET /health`: every other GET gets HTTP 405, except the Registered Tags report path on Corp.

### 12.5 Try it on one PC

```powershell
dotnet run --project sourcecode\gateway\src\QrBridge.Gateway --launch-profile "Gateway (Corp)"      # http://localhost:5080
```

Then send it the simulator's messages, for example with PowerShell (escape the template into the `sXML` element and
POST it with the `SOAPAction` header), or point the **fms-interface-simulator** at it by editing its
`Configuration.xml`, e.g. `<SSO_FMS_URL>http://localhost:5080/FMS_SSO2FMSInterface/SSO2FMSInterface.svc</SSO_FMS_URL>`.
For `.svc` URLs leave out `?wsdl` — the simulator treats any URL containing `.WSDL` as a legacy SOAP Toolkit endpoint.
(The tests use the simulator's templates and the same WCF client stack; the simulator application itself has not been
run against the gateway yet.)

---

## 13. How to add or change a service

**A new CorpNet → DMZ service** (e.g. MAXIMO calling an FMS-side service):

1. Find the path the caller uses as the load balancer forwards it, and its contract (style, namespaces, operations).
2. Add an entry to `routes.json`: `Name`, `SenderSide: "Corp"`, `Paths`, `Style`, and per operation a `Mode`,
   a reply profile and the `AllowedTypes`. Choose the mode by what the caller does with the answer: **RoundTrip**
   (`OnHoldTimeout: Pending`, 1596) for anything that changes state on the far side — permits, orders, cards and
   their responses — so the caller gets the real answer or an honest "not yet confirmed", never a false "0";
   **RoundTrip** with `OnHoldTimeout: Unavailable` (1599) for a read-only query; **`Bridge`** only for a feed whose
   caller needs nothing but "received". A `Pending` route's calls expire on the far side after `Gateway:Expiry`
   (600 s; a per-service override in `Gateway:Expiry:Services` on the sending side must stay longer than its hold).
   Optional: `"Priority"` (`High`/`Normal`/`Low`) to override the route's default class ([§4.10](#410-delivering-on-the-other-side)),
   and per service `MaxRequestBytes` (10 × the largest sample request is today's rule, D78) and `MaxBacklog`
   ([§11](#11-configuration-reference)).
3. On the delivering side: nothing if the real service lives under `DefaultBaseUrl` with the same path, otherwise
   `Gateway:Receiver:Targets:<Name>:Url` (and `:UseDefaultCredentials` if it needs other credentials than the
   global setting).
4. Test: add a sample message and a case to `SenderTests`, run the tests.
5. Deploy `routes.json` to **both** gateways; recycle the app pools.

**A DMZ → CorpNet service**: the same with `SenderSide: "Dmz"`; its delivery target is configured on the Corp gateway.

**A plain HTTP GET interface** (not SOAP, like Registered Tags): `"HttpGet": true`, with the shape start-up insists on
([§4.9](#49-get-requests-and-health-probes)); a test like `RegisteredTagsTests` instead of a `SenderTests` case.

**Discovering an unknown service**: in a test environment set `Routing:AcceptUnlisted = true`; calls are forwarded with
an automatic empty reply and stored under their path, so you can see exactly what arrives — then write the real entry.

**Changing the SOAP Gateway's reply codes or texts**: edit `ReplyProfiles` in `routes.json`.

---

## 14. Status, open decisions and next steps

### 14.1 Built and verified

- Generic SOAP gateway: Sender part for any SOAP request, route catalogue with allow-lists, reply profiles, `/health`,
  backpressure.
- Delivery worker: replay, answer classification, retries, operator statuses (Refused, Unknown, NotDelivered), recovery, heartbeats, `/health`.
- Receipts and Replies written on the receiving side (V6 fix step 9b, 24 Nov 2026, D43–D47): a Reply for every final
  outcome, with the real answer; a Receipt for every arrived message; header version 5 (`BRG5`). Proven by tests that
  copy the bytes between two in-memory gateways; not yet carried over the light.
- The round trip on the gateways (V6 fix steps 10a and 10b, 24 Nov 2026, D49–D59): RoundTrip calls are checked,
  queued and held (`Gateway:Hold`); `AnswerReader` reads arriving Receipts and Replies on the sending side and gives
  a held caller the real answer, or the hold-timeout answer; the far side delivers RoundTrip Requests, does not post
  the same content twice when the first one may have reached the service, and fails a query fast when nothing was
  sent. Proven by tests between two in-memory gateways (`HoldTests`, `FarSideTests`); on real hardware nothing crosses
  the light yet, so every held call waits the full hold and gets its hold-timeout answer.
- Permits, orders and cards held for the real answer (V6 fix step 10c, 24 Nov 2026, D60–D64): every Corp `SendTo…`
  route except FTC's, and the DMZ FMS2FC, FMS2FOD, FMS2SSO, TLS2SSO, TOMS2SSO and DSO2SSO operations are RoundTrip
  with hold-timeout answer 1596 (feeds stay `Bridge`); they expire on the far side after `Gateway:Expiry` (600 s); a
  retry of a message that surely was not done is sent as a new message; crash recovery adopts only a Reply from the
  row's current attempt. Until the QR apps carry messages, every such call waits the full hold and gets 1596
  (accepted by Rowshan; it replaces the false "0" these calls got before).
- Checks on arrival (24 Nov 2026): the same catalogue on both sides (fingerprint, D31), the counter's run id (D27),
  lost-message detection with operator acknowledgement (D29, D30), no automatic deletion (D28).
- Re-air of unconfirmed messages on the sending gateway (V6 fix step 11, 24 Nov 2026, D65–D68): an `Aired` row with
  no Receipt after `Gateway:ReceiptTimeoutSeconds` goes back to Pending, up to `Gateway:MaxAirAttempts` airs, then
  light Failed; an expired one is Failed at once; Receipt and Heartbeat rows are never re-aired (§6.3). Proven with in-memory
  gateways and a fake light only; nothing sets `Aired` on real hardware yet.
- Registered Tags GET as a round trip (V6 fix step 12, 24 Nov 2026, D18, D69–D72): the Corp gateway carries the
  report's plain GET across (payload format `HttpGet`) and gives the caller the real answer, or HTTP 504 when none
  comes back in time ([§4.9](#49-get-requests-and-health-probes)). Proven with in-memory gateways only; the real
  report service's answer and the caller's timeout are not verified.
- End-to-end fault tests (V6 fix step 13, 24 Nov 2026): lost, re-aired and duplicate sessions, and callers that
  retry, hang up or meet a gateway restart, on two in-memory gateways and a fake light (`LightFaultTests`,
  `CallerFaultTests`, [§12.2](#122-what-the-tests-prove)). Not on real screens and cameras.
- Priority classes (V6 fix step 14, 25 Nov 2026, D73, D74): header version 6 (`BRG6`, now version 7) with `Priority`; the QR
  sender's claim takes Receipts, Replies and Heartbeats first, then High, Normal, Low; the far side runs one delivery loop per
  class and keeps strict order per service and class while a Request is Retrying ([§4.10](#410-delivering-on-the-other-side)).
  Proven with in-memory gateways only; the QR sender does not claim rows yet.
- Credentials, caller and plaintext at rest (V6 fix step 15, 25 Nov 2026, D6, D75–D77): per-target
  `UseDefaultCredentials`; `CallerHost` in every Request, logged at delivery; an Inbox row's body cleared once it is
  Done; the DMZ gateway accepts anonymous intranet callers (D6, IIS configuration).
- Size limits (V6 fix step 16, 25 Nov 2026, D78, D79): per-service `MaxRequestBytes` (set to 10 × the largest
  simulator template on 11 routes) and `MaxBacklog` (none set); a start-up warning when a RoundTrip route's size limit
  takes longer to air than its hold (`Gateway:Light`). Not verified against real message sizes (§14.3).
- Far side and replay (V6 fix step 17, 25 Nov 2026, D80–D84): header version 7 (`BRG7`) with the `Heartbeat` kind;
  an idle side sends a Heartbeat every `Gateway:HeartbeatMinutes` (5), so a lost last message becomes a gap;
  `/health` `farSide` shows when the far side was last heard and turns unhealthy after `Gateway:FarSideSilentMinutes`
  (15) of silence; an old or reused sequence number is Rejected whatever its date (`SequenceWatermark`). Proven with
  two in-memory gateways and a fake light only (`HeartbeatTests`, `EndToEndTests`).
- Operations hardening (V6 fix step 18, 25 Nov 2026, D4): a start-up warning when the gateway runs as an
  administrator; app pool identity, data-folder ACL, BitLocker, IIS request limits, IP restrictions, backups and the
  doorbell ACL written down in [§12.4](#124-deploy-per-side) and §6.5. Not tried on a real IIS server.
- Two status groups per row, light and service (decision D24, 24 Nov 2026), so an operator sees whether a problem is
  on the light or at the service end.
- Shared data layer (EF Core + SQLite), envelope with header label and checksum (not encrypted — §7.1), doorbells.
- Catalogue for all CorpNet → DMZ SOAP interfaces in the simulator, and the 11 DMZ → CorpNet services the DMZ
  interface services call (paths and contracts still to confirm).
- 451 gateway tests + 75 QrDiode tests; publish script; IIS script check for WCF HTTP Activation.

### 14.2 Not built yet

| Item | Notes |
|---|---|
| A run on real screens and cameras of the QrDiode ↔ shared database connection | **built 27 Nov 2026** (`"QrDiode:Mode": "Gateway"`, decisions 52–54: bundles, Sender airs the Outbox and sets `Aired`, Receiver writes the Inbox, deferred anti-replay commit, unattended start, heartbeats, EF migrations) and tested with two in-memory gateways; the physical run is next |
| Islanding operations: stop-accepting switch, `/status` with a drained flag | before go-live |
| Per-order ordering (`OrderingKey`) | strict order per service and class is built (step 14, D74); a per-order key would let other orders of the same service pass a stuck one ([integration-plan.md](integration-plan.md) §4) |
| DMZ → CorpNet receiver targets and confirmed paths | the 11 services are in the catalogue; their paths and contracts need confirming, and `appsettings.Corp.json` `Receiver` (the corporate hosts) is empty |
| Record mode (transparent proxy that captures real requests/replies) | the easiest way to capture the above |
| Dual-site (ECC/AECC) configuration and failover procedure | |
| Delivery receipts (D14) | The gateway writes Receipts as ordinary messages since step 9b, reads them on the sending side since step 10a and re-airs unconfirmed rows since step 11; carrying them needs the QrDiode work. The two-way link still needs security sign-off (§14.3) |
| Re-airing lost messages on real hardware (detection and the gateway's re-air are built, step 11) | needs the QR sender to set `Aired` and claim re-aired rows (§9.2); effect on light capacity under load not measured |
| Operator actions in a UI (requeue, acknowledge a gap, archive) | the methods exist; the read-only web UI (decision 48, built 25 Nov) shows everything but changes nothing — operators use SQL (§8.4) |

### 14.3 Decisions still open

| Question | Current state |
|---|---|
| Queries in islanding mode | RoundTrip: held for the real answer, "Unavailable" (1599) when it does not come back in time; snapshot caching would need its own approval |
| SOAP Gateway reply codes 1596 / 1597 / 1598 / 1599 | configurable; confirm with the Rapid Restore team that they don't clash |
| What FMS (`IntMgr.CardCutOut`) does after a non-zero `IssueWorkPermit` answer (tracker D12) | `FMS2FC.IssueWorkPermit` is RoundTrip like the other permits (D61); pilot-only until the FMS team explains it |
| Do XA/21, BFC and Registered Tags cross the gap at all? | XA/21 and BFC listed as Unavailable; Registered Tags (plain GET) is a round trip since step 12 (real answer or HTTP 504; WebClient's 100 s default timeout is shorter than the 270 s hold — a risk) |
| Load balancer details (path forwarding, TLS, pool size); probe must use `GET /health` | needed from the network team |
| MAXIMO, OSS, NRI, Feeder Status payloads and endpoints | not in the simulator; capture them |
| Dual site: move queued rows on failover? dedupe across sites? AECC warm or cold? | open |
| Security sign-off for a two-way optical link | required before go-live |
| Real message sizes (V6 review Q4) | `MaxRequestBytes` is 10 × the largest simulator template (D78); a real call above it gets 413 (a false failure, manual fallback). Measure real sizes; also the real link speed behind `Gateway:Light` (D79) |
| Anonymous callers on the DMZ gateway (D6) | decided by Rowshan against the review's recommendation; IP restrictions may be added later ([§12.4](#124-deploy-per-side) item 7) |
| Bundling, ordering rule | designed in [integration-plan.md](integration-plan.md) §2.3 and §4; to be confirmed with the QrDiode work |

---

## 15. Glossary

| Term | Meaning |
|---|---|
| **Gateway-to-QrDiode** | The overall system: SOAP gateways, the shared message database (`qrbridge.db`) and the QrDiode optical link on both sides |
| **SOAP Gateway** | The IIS application (`QrBridge.Gateway`) that accepts callers' requests, queues them and delivers arrived requests to real services |
| **QrDiode optical link** | The Sender screen and Receiver camera that transfer messages as QR codes |
| **FMS** | Feeder Management System (outages, work permits, tags, faults) — OpenROAD screens on Ingres, on the DMZ/OpNet side |
| **TOMS** | Transmission Operations Management System |
| **TLS** | Telephone Line System (also Trouble & Telecom Lease System) |
| **DSO** | Dielectric System Operation (also Distribution System Operations) |
| **RR** | Rapid Restore — the corporate application family whose roles call FMS |
| **FCR / FOD / SSO** | Feeder Control Representative / Field Operations Department / Substation Operator — Rapid Restore roles |
| **DSS / No. 9** | the application handling No. 9 orders; uses the legacy SOAP Toolkit endpoint |
| **FTC** | Fault Correlation |
| **BFC / IR2BFC** | Bus Fault Correlation |
| **XA/21** | the EMS (Energy Management System) SCADA platform |
| **VZN** | Verizon trouble reporting (eBonding) |
| **RT** | Registered Tags report |
| **ECC / AECC** | the primary control center site / the backup site |
| **CorpNet / DMZ / OpNet** | the corporate network / the FMS-side network zone |
| **Islanding mode** | the firewalls between CorpNet and the DMZ are cut; only light crosses |
| **Load balancer (LB)** | the corporate entry point the callers use; re-pointed to the gateway in islanding mode |
| **Gateway** | `QrBridge.Gateway`, one per side, in IIS |
| **Sender part / Receiver part** (gateway) | accepting callers' requests into the Outbox (code in `Ingress/`) / delivering requests from the Inbox to the real services (code in `Egress/`) |
| **Outbox / Inbox** | the queue tables in `qrbridge.db` (until 25 Nov 2026: `send.db` / `received.db`) |
| **Envelope** | the packed (header + checksum + Brotli) form of a message, identical in both sides' tables |
| **MessageHeader** | everything about a stored message except its SOAP body, incl. the HTTP details needed to replay it |
| **Label / BusinessType** | `MESSAGE/@TYPE` or the payload's root element name, e.g. `RETURN_ORDER` |
| **Route catalogue** | `routes.json`: which services the gateway stands in for, and how it answers |
| **Reply profile** | the result values a gateway reply carries (Ok, Busy, Unavailable, Pending, Rejected) |
| **Allow-list** | the catalogue (services, operations) and each operation's `AllowedTypes` |
| **Doorbell** | a named Windows event one program sets to wake another |
| **Light status / service status** | the two status groups of each Outbox and Inbox row: did the message cross the light? / what did the real service do? |
| **Priority class** | `Answer` (Receipts, Replies), `High` (permits, orders, cards), `Normal` (queries), `Low` (feeds): the order on the light, and one delivery loop per class on the far side |
| **Refused / Unknown / NotDelivered** | Inbox service statuses that are never re-posted automatically and need an operator: the service said no / it may have reached the service / it surely did not |
| **Receipt / Reply** | messages a receiving gateway sends back on the opposite lane: "this message arrived" / "this is what the real service did with your Request", with its answer (§4.10) |
| **Heartbeat message** | an empty message a gateway sends when it has had nothing to send for `Gateway:HeartbeatMinutes`: "this side is alive" (step 17). Not the same as a component heartbeat (the `Heartbeat` table row each local component updates) |
| **Watermark** | per run of the other side's sequence counter, the number up to which every message has arrived and been checked (`SequenceWatermark`); a message at or below it whose row is gone is an old one shown again (step 17) |
| **Bundle** | (planned) many envelopes in one QR session |
| **SOAP 1.1 / 1.2** | the two SOAP envelope versions (namespaces `…xmlsoap.org/soap/envelope/` / `…w3.org/2003/05/soap-envelope`) |
| **Document/literal (wrapped)** | the WCF/ASMX SOAP style: body element named after the operation, parameters as child elements |
| **RPC/encoded** | the old SOAP Toolkit style: unqualified parts, SOAP encoding |
| **SOAPAction** | the HTTP header (SOAP 1.1) naming the operation; in SOAP 1.2 an `action` Content-Type parameter |
| **WS-Addressing** | SOAP headers (`Action`, `MessageID`, `To`, `RelatesTo`) used by `WSHttpBinding` |
| **WSDL / XSD** | a service's contract description / its schemas |
| **AES-GCM** | authenticated encryption (used by QrDiode): decrypting also proves nothing was changed |
| **LT fountain code** | the coding QrDiode uses so the camera can miss frames without a back-channel |

---

## Appendix A. Wire examples

Formatted for reading; the real bytes have no extra whitespace.

### A.1 WCF caller, accepted (FCR → `FC2FMSInterface.svc`)

```http
POST /FMS_FC2FMSInterface/FC2FMSInterface.svc HTTP/1.1
Content-Type: text/xml; charset=utf-8
SOAPAction: "http://tempuri.org/IFC2FMSInterface/SendToFMS"

<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body>
    <SendToFMS xmlns="http://tempuri.org/">
      <sXML>&lt;MESSAGE TYPE="REQUEST_FOR_PERMIT" MSG_ID="679" GMT_TIME_SENT="08/09/2002 14:00:10"&gt; ... &lt;/MESSAGE&gt;</sXML>
    </SendToFMS>
  </s:Body>
</s:Envelope>
```

```http
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8
X-QrBridge-MessageId: cd3948ab-c001-488a-9913-f320af3e457d

<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body>
    <SendToFMSResponse xmlns="http://tempuri.org/">
      <SendToFMSResult>&lt;RESPONSE MSG_TYPE="REQUEST_FOR_PERMIT" MSG_ID="679"&gt;&lt;STATUS&gt;&lt;RETURN_CODE&gt;0&lt;/RETURN_CODE&gt;&lt;ERROR_MESSAGE&gt;&lt;/ERROR_MESSAGE&gt;&lt;/STATUS&gt;&lt;/RESPONSE&gt;</SendToFMSResult>
    </SendToFMSResponse>
  </s:Body>
</s:Envelope>
```

### A.2 WCF caller, query (Unavailable)

`GetFromFMS(<MESSAGE TYPE="GET_FEEDER_INFO" …>)` → HTTP 200, `GetFromFMSResult` =

```xml
<RESPONSE MSG_TYPE="GET_FEEDER_INFO" MSG_ID="456"><STATUS><RETURN_CODE>1599</RETURN_CODE>
<ERROR_MESSAGE>Not available while FMS is islanded (QR bridge mode): this request needs a live answer.</ERROR_MESSAGE></STATUS></RESPONSE>
```

### A.3 SOAP Toolkit caller, RPC/encoded (DSS → `RR_DSSFMSService.wsdl`)

```http
POST /FMSInterface/RR_DSSFMSService.wsdl HTTP/1.1
Content-Type: text/xml; charset=utf-8
SOAPAction: "http://tempuri.org/action/FMSInterface.SendToFMS"

<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                   SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
  <SOAP-ENV:Body>
    <SOAPSDK4:SendToFMS xmlns:SOAPSDK4="http://tempuri.org/message/">
      <XMLMsg>&lt;MESSAGE TYPE="NO9_MOVE_RESPONSE" MSG_ID="456" ...&gt; ... &lt;/MESSAGE&gt;</XMLMsg>
    </SOAPSDK4:SendToFMS>
  </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
```

```xml
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body>
    <m:SendToFMSResponse xmlns:m="http://tempuri.org/message/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
      <Result>0</Result>
    </m:SendToFMSResponse>
  </s:Body>
</s:Envelope>
```

### A.4 SOAP 1.2 + WS-Addressing caller, unlisted service (`AcceptUnlisted` on)

```http
POST /Test/NewService.svc HTTP/1.1
Content-Type: application/soap+xml; charset=utf-8; action="urn:qrbridge:test/INewService/DoWork"

<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://www.w3.org/2005/08/addressing">
  <s:Header>
    <a:Action s:mustUnderstand="1">urn:qrbridge:test/INewService/DoWork</a:Action>
    <a:MessageID>urn:uuid:7f6c...</a:MessageID>
    <a:To s:mustUnderstand="1">http://lb/Test/NewService.svc</a:To>
  </s:Header>
  <s:Body><DoWork xmlns="urn:qrbridge:test"><input>hello</input></DoWork></s:Body>
</s:Envelope>
```

```xml
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">
  <s:Header>
    <a:Action s:mustUnderstand="1" xmlns:a="http://www.w3.org/2005/08/addressing">urn:qrbridge:test/INewService/DoWorkResponse</a:Action>
    <a:RelatesTo xmlns:a="http://www.w3.org/2005/08/addressing">urn:uuid:7f6c...</a:RelatesTo>
  </s:Header>
  <s:Body><DoWorkResponse xmlns="urn:qrbridge:test" /></s:Body>
</s:Envelope>
```

The WCF client reads the result as `null`. On the delivering side the `wsa:To` header is pointed at the real service
before the replay.

### A.5 Refusals

```xml
<!-- Unknown path (SOAP 1.1), HTTP 500 -->
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body>
    <s:Fault>
      <faultcode>s:Client</faultcode>
      <faultstring xml:lang="en-US">'/Somewhere/Else.svc' is not a bridged service.</faultstring>
    </s:Fault>
  </s:Body>
</s:Envelope>
```

A message type the interface does not take (e.g. `RETURN_ORDER` sent to `FC2FMSInterface.svc`) gets HTTP 200 with
`RETURN_CODE 1597` and "Invalid XML MESSAGE TYPE for this interface (refused by the QR bridge)."

---

## Appendix B. Design record decisions and what changed

Earlier design decisions and their changes (19 Nov 2026 onward); current decisions are in the
[handoff](../handoff.md):

| # | Decision | Status |
|---|---|---|
| D1 | WPF for the desktop app | unchanged |
| D2 | SQLite on a local folder, WAL, busy_timeout, synchronous=NORMAL | implemented; `synchronous=FULL` since 24 Nov (V6 review G-14) |
| D3 | Two DB files per machine (send.db, received.db) | **changed 25 Nov 2026**: one file per machine, `qrbridge.db`, with the same tables (handoff decision 47, §6.1) |
| D4 | Outbox/Inbox tables are the queue; atomic claim; unique MessageId | implemented |
| D5 | Gateway replies only after the Outbox commit | implemented |
| D6 | Only fire-and-forget operations are forwarded | **changed 24 Nov 2026**: only feeds are fire-and-forget (`Bridge`); queries, permits, orders and cards are `RoundTrip`, held for the real answer from the other side (V6 fix steps 10a, 10c); XA/21 and BFC stay `Unavailable` |
| D7 | One common envelope; contracts only in the gateways; registry = allow-list | **changed in form**: no per-service contract classes; WSDLs validate requests, the payload remains the caller's raw SOAP request, and `routes.json` is the allow-list |
| D8 | Authenticated header + Brotli + AES-256-GCM; one key per direction; KeyId; DPAPI | **removed 23 Nov 2026**: header + Brotli + SHA-256 checksum, no gateway keys (see D13) |
| D9 | Named-event doorbells with polling fallback | implemented |
| D10 | No Windows service; workers inside the gateway in IIS | implemented |
| D11 | Heartbeat table; `/health` | implemented (QR apps' heartbeats planned) |
| D12 | QrDiode as the optical transport; retire QrBridge.Station | done: Station, its frame codec and ACK tracker were not carried over |
| D13 | Gateway message envelope inside QrDiode's encryption (double layer) | **dropped 23 Nov 2026**: QrDiode is the only encryption layer; payloads are not encrypted at rest in the database (§7.1) |
| D14 | Delivery receipts over the reverse lane | open — needs security sign-off |

Changed from the record's sections 8, 9 and 11:

- **CoreWCF hosted contracts → one generic SOAP endpoint** driven by `routes.json` (handles every style, including
  RPC/encoded, with no per-service code).
- **Typed downstream clients and handlers → `SoapForwarderHttpClient`**, which replays the exact bytes and classifies the answer
  by the operation's reply profile.
- **`PayloadSerializer`, `FrameCodec`, the `InboundChunk` table → removed**: payloads are not re-serialized, and QrDiode
  reassembles QR sessions itself.
- **Integration plan reordered**: gateway first (done), then the QrDiode connection, then islanding operations and
  hardening — see [integration-plan.md](integration-plan.md).
