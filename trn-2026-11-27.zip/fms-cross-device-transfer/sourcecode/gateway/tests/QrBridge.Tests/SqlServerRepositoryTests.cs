using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests;

/// <summary>
/// The repositories on SQL Server ("GatewayDatabase:Provider" = SqlServer), against a real server: the migrations, the
/// two places where engines differ (the write lock, duplicate keys) and the queries written as plain SQL. Skipped
/// unless QRBRIDGE_SQLSERVER is set (<see cref="SqlServerFactAttribute"/>).
/// </summary>
public sealed class SqlServerRepositoryTests : IAsyncLifetime
{
    private readonly SqlServerTestDatabase _database = SqlServerTestDatabase.New();
    private ServiceProvider? _sp;

    private ServiceProvider Services => _sp ?? throw new InvalidOperationException("Not started.");
    private IOutboxRepository Outbox => Services.GetRequiredService<IOutboxRepository>();
    private IInboxRepository Inbox => Services.GetRequiredService<IInboxRepository>();

    public async Task InitializeAsync()
    {
        if (SqlServerTestDatabase.ServerConnectionString is null) return; // skipped
        var services = new ServiceCollection();
        services.AddBridgeData(_database.Options());
        _sp = services.BuildServiceProvider();
        await DatabaseInitializer.InitializeAsync(_sp, NullLogger.Instance);
    }

    public async Task DisposeAsync()
    {
        if (_sp is null) return;
        await _sp.DisposeAsync();
        await _database.DisposeAsync();
    }

    private static OutboxInsert Request(string? fingerprint = null, bool attach = false, int maxBacklog = 5000) =>
        new(Direction.CorpToDmz, MessageKind.Request, "FC2FMS", fingerprint, DateTime.UtcNow.AddMinutes(-30), attach, maxBacklog, null);

    private static OutboxMessage Row(long sequence, Guid runId, string? fingerprint = null) => new()
    {
        MessageId = Guid.NewGuid(), Direction = Direction.CorpToDmz, ServiceName = "FC2FMS", Operation = "SendToFMS",
        Sequence = sequence, SequenceRunId = runId, PayloadFormat = PayloadFormat.RawSoap, Kind = MessageKind.Request,
        ContentFingerprint = fingerprint, Priority = MessagePriority.High, PayloadSize = 3, MessageBytes = [1, 2, 3],
        MessageHash = Hashing.Sha256Hex([1, 2, 3]), LightStatus = OutboxLightStatus.Pending, ServiceStatus = OutboxServiceStatus.Waiting,
        CreatedUtc = DateTime.UtcNow,
    };

    private static MessageHeader Header(long sequence, Guid runId) => new()
    {
        MessageId = Guid.NewGuid(), Direction = Direction.CorpToDmz, ServiceName = "FC2FMS", Operation = "SendToFMS",
        Sequence = sequence, SequenceRunId = runId, Path = "/FMS_FC2FMSInterface/FC2FMSInterface.svc",
        ContentType = "text/xml; charset=utf-8",
    };

    [SqlServerFact]
    public async Task A_new_database_gets_every_migration_and_the_seeded_counters()
    {
        await using var db = await Services.GetRequiredService<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();

        Assert.IsType<SqlServerBridgeDbContext>(db);
        Assert.Equal(db.Database.GetMigrations(), await db.Database.GetAppliedMigrationsAsync());
        Assert.Equal(2, await db.SequenceCounters.CountAsync());
    }

    [SqlServerFact]
    public async Task Identical_requests_at_the_same_moment_make_one_row()
    {
        // The write lock (sp_getapplock) keeps "same content queued?" and the insert together, as BEGIN IMMEDIATE does on SQLite.
        var results = await Task.WhenAll(Enumerable.Range(0, 20).Select(_ => Task.Run(() =>
            Outbox.InsertAsync(Request(new string('a', 64), attach: true), (sequence, runId) => Row(sequence, runId, new string('a', 64)), CancellationToken.None))));

        Assert.Single(results, r => r.Outcome == OutboxInsertOutcome.Queued);
        Assert.Equal(19, results.Count(r => r.Outcome == OutboxInsertOutcome.Attached));
        Assert.Equal(1, (await Outbox.GetCountsAsync(CancellationToken.None)).Light[OutboxLightStatus.Pending]);
    }

    [SqlServerFact]
    public async Task Simultaneous_requests_get_consecutive_numbers_and_never_overfill_the_backlog()
    {
        var results = await Task.WhenAll(Enumerable.Range(0, 30).Select(_ => Task.Run(() =>
            Outbox.InsertAsync(Request(maxBacklog: 20), (sequence, runId) => Row(sequence, runId), CancellationToken.None))));

        Assert.Equal(20, results.Count(r => r.Outcome == OutboxInsertOutcome.Queued));
        Assert.Equal(10, results.Count(r => r.Outcome == OutboxInsertOutcome.BacklogFull));
        await using var db = await Services.GetRequiredService<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        var rows = await db.Outbox.AsNoTracking().OrderBy(m => m.Sequence).ToListAsync();
        Assert.Equal(Enumerable.Range(1, 20).Select(i => (long)i), rows.Select(m => m.Sequence));
        Assert.Single(rows.Select(m => m.SequenceRunId).Distinct()); // one run, set on first use
    }

    [SqlServerFact]
    public async Task A_message_or_a_gap_stored_twice_is_kept_once()
    {
        var runId = Guid.NewGuid();
        var header = Header(1, runId);
        Assert.True(await Inbox.AddMessageAsync(header, [1], CancellationToken.None));
        Assert.False(await Inbox.AddMessageAsync(header, [1], CancellationToken.None));

        var stored = await Inbox.AddMessagesAsync([(header, [1]), (Header(2, runId), [2]), (Header(2, runId) with { MessageId = header.MessageId }, [1])],
                                                  Guid.NewGuid(), Guid.NewGuid(), CancellationToken.None);
        Assert.Equal(new BundleStoreResult(Added: 1, Duplicates: 2), stored);

        // A duplicate key reported by SQL Server itself (2627), not found by a check first.
        Assert.True(await Inbox.AcknowledgeGapAsync(Direction.CorpToDmz, runId, 5, 6, "operator", "test", CancellationToken.None));
        Assert.False(await Inbox.AcknowledgeGapAsync(Direction.CorpToDmz, runId, 5, 7, "operator", "test", CancellationToken.None));
    }

    [SqlServerFact]
    public async Task Missing_sequence_numbers_are_found_by_the_plain_sql_gap_query()
    {
        var runId = Guid.NewGuid();
        foreach (long sequence in new long[] { 1, 2, 5 })
            await Inbox.AddMessageAsync(Header(sequence, runId), [1], CancellationToken.None);

        var gap = Assert.Single(await Inbox.FindSequenceGapsAsync(Direction.CorpToDmz, DateTime.UtcNow.AddMinutes(1), CancellationToken.None));
        Assert.Equal((runId, 3L, 4L), (gap.SequenceRunId, gap.FromSequence, gap.ToSequence));
    }

    [SqlServerFact]
    public async Task A_bundle_is_claimed_aired_and_confirmed()
    {
        for (int i = 0; i < 3; i++)
            await Outbox.InsertAsync(Request(), (sequence, runId) => Row(sequence, runId), CancellationToken.None);

        var bundle = await Outbox.ClaimBundleAsync(maxMessages: 2, maxBytes: 1_000_000, CancellationToken.None);
        Assert.NotNull(bundle);
        Assert.Equal([1L, 2L], bundle.Messages.Select(m => m.Sequence));
        Assert.Equal(2, await Outbox.MarkAiredAsync(bundle.BundleId, Guid.NewGuid(), CancellationToken.None));
        Assert.Equal(2, await Outbox.MarkReceivedAsync(bundle.Messages.Select(m => m.MessageId).ToList(), CancellationToken.None));

        var counts = await Outbox.GetCountsAsync(CancellationToken.None);
        Assert.Equal((2, 1), (counts.Light[OutboxLightStatus.Received], counts.Light[OutboxLightStatus.Pending]));
    }
}
