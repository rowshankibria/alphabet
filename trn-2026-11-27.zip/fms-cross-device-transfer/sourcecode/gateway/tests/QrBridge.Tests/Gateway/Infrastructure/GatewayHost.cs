using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using QrBridge.Gateway.Egress;
using QrBridge.Shared;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>
/// One real gateway (the actual Program, routes.json, EF/SQLite, workers) running in memory,
/// with its data in a temp folder. Two hosts sharing a root = a Corp and a DMZ gateway.
/// </summary>
public sealed class GatewayHost : IAsyncDisposable
{
    private GatewayHost(WebApplicationFactory<Program> factory, BridgeSide side)
    {
        Factory = factory;
        Side = side;
    }

    public WebApplicationFactory<Program> Factory { get; }
    public BridgeSide Side { get; }

    /// <param name="root">Folder for both sides' data folders, each with its own qrbridge.db (share it between a Corp and a DMZ host).</param>
    /// <param name="settings">Extra configuration, e.g. "Routing:AcceptUnlisted" = "true".</param>
    /// <param name="receiverHandler">Stand-in for the real services this gateway delivers to.</param>
    /// <param name="environment">ASP.NET Core environment; by default the side's name, as in IIS (appsettings.Corp.json / appsettings.Dmz.json).</param>
    public static GatewayHost Start(BridgeSide side, string root, IDictionary<string, string?>? settings = null,
                                    Func<HttpMessageHandler>? receiverHandler = null, string? environment = null)
    {
        var config = new Dictionary<string, string?>
        {
            ["GatewayDatabase:Side"] = side.ToString(),
            ["GatewayDatabase:DataFolder"] = Path.Combine(root, side.ToString(), "Data"),
            ["Gateway:InboxPollSeconds"] = "1",
            ["Gateway:BackoffBaseSeconds"] = "1",
            ["Gateway:MaintenanceIntervalSeconds"] = "3600",
            ["Gateway:Receiver:DefaultBaseUrl"] = "http://real-service.test",
            ["Gateway:Receiver:AllowHttp"] = "true", // an in-memory test bench: nothing leaves the process
            ["Gateway:Receiver:TimeoutSeconds"] = "10",
            ["Gateway:Receiver:ConnectTimeoutSeconds"] = "5", // must be shorter than the delivery timeout
            // A held RoundTrip call with no far side gets its hold-timeout answer after 1 s; tests of the round trip
            // itself set a longer hold.
            ["Gateway:Hold:DefaultSeconds"] = "1",
        };
        foreach (var (key, value) in settings ?? new Dictionary<string, string?>()) config[key] = value;

        var factory = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
        {
            builder.UseEnvironment(environment ?? side.ToString());
            builder.ConfigureAppConfiguration((_, c) => c.AddInMemoryCollection(config));
            if (receiverHandler is not null)
                builder.ConfigureTestServices(services => services
                    .AddHttpClient(SoapForwarderHttpClient.HttpClientName)
                    .ConfigurePrimaryHttpMessageHandler(receiverHandler));
        });

        var host = new GatewayHost(factory, side);
        _ = factory.Server; // start now: runs the startup checks and creates the database
        return host;
    }

    public HttpClient CreateClient() =>
        Factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });

    /// <summary>An HTTP handler that talks to this gateway in memory (for WCF clients).</summary>
    public HttpMessageHandler CreateHandler() => Factory.Server.CreateHandler();

    public T Get<T>() where T : notnull => Factory.Services.GetRequiredService<T>();

    public async ValueTask DisposeAsync()
    {
        await Factory.DisposeAsync();
        SqliteConnection.ClearAllPools();
    }

    public static string NewRoot() => Path.Combine(Path.GetTempPath(), "qrbridge-gw-" + Guid.NewGuid().ToString("N"));

    public static void DeleteRoot(string root)
    {
        SqliteConnection.ClearAllPools();
        try { Directory.Delete(root, recursive: true); } catch { /* best effort: SQLite may still hold a handle */ }
    }
}
