using Microsoft.Data.SqlClient;
using QrBridge.Shared;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>
/// An empty SQL Server database of its own for one test (one per gateway: Corp and DMZ never share a database),
/// created by the first migration and dropped when the test ends.
/// </summary>
public sealed class SqlServerTestDatabase : IAsyncDisposable
{
    public const string EnvironmentVariable = "QRBRIDGE_SQLSERVER";

    public static string? ServerConnectionString =>
        Environment.GetEnvironmentVariable(EnvironmentVariable) is { Length: > 0 } value ? value : null;

    private SqlServerTestDatabase(string name)
    {
        Name = name;
        ConnectionString = new SqlConnectionStringBuilder(ServerConnectionString) { InitialCatalog = name }.ToString();
    }

    public string Name { get; }
    public string ConnectionString { get; }

    /// <summary>A new, not yet created database name; the bridge's migrations create it on first start.</summary>
    public static SqlServerTestDatabase New() => new("QrBridgeTest_" + Guid.NewGuid().ToString("N"));

    /// <summary>GatewayDatabase settings for a GatewayHost on this database.</summary>
    public Dictionary<string, string?> Settings(IDictionary<string, string?>? more = null)
    {
        var settings = new Dictionary<string, string?>
        {
            ["GatewayDatabase:Provider"] = nameof(DatabaseProvider.SqlServer),
            ["GatewayDatabase:ConnectionString"] = ConnectionString,
        };
        foreach (var (key, value) in more ?? new Dictionary<string, string?>()) settings[key] = value;
        return settings;
    }

    /// <summary>The same as <see cref="Settings"/>, as GatewayDatabaseOptions (repository tests without a gateway).</summary>
    public GatewayDatabaseOptions Options(BridgeSide side = BridgeSide.Corp) => new()
    {
        Side = side,
        Provider = DatabaseProvider.SqlServer,
        ConnectionString = ConnectionString,
    };

    public async ValueTask DisposeAsync()
    {
        SqlConnection.ClearAllPools();
        await using var connection = new SqlConnection(ServerConnectionString);
        await connection.OpenAsync();
        await using var command = connection.CreateCommand();
        command.CommandText = $"""
            IF DB_ID(N'{Name}') IS NOT NULL
            BEGIN
                ALTER DATABASE [{Name}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
                DROP DATABASE [{Name}];
            END
            """;
        await command.ExecuteNonQueryAsync();
    }
}
