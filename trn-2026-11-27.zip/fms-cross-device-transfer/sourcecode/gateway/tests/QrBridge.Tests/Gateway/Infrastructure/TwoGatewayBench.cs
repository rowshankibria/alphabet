using Microsoft.EntityFrameworkCore;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>
/// A Corp and a DMZ gateway (the real Program, in memory, sharing one temp root), the real service behind the DMZ
/// gateway (<see cref="Network"/>, scripted per call) and the QR link in both directions (<see cref="Light"/>).
/// Used by the end-to-end fault tests (V6 fix step 13) and the Registered Tags tests (step 12).
/// </summary>
public sealed class TwoGatewayBench : IAsyncDisposable
{
    private readonly string _root;
    private readonly IDictionary<string, string?> _corpSettings;

    private TwoGatewayBench(string root, IDictionary<string, string?> corpSettings, GatewayHost corp, GatewayHost dmz,
                            ScriptedHandler network, bool lightOn)
    {
        _root = root;
        _corpSettings = corpSettings;
        Corp = corp;
        Dmz = dmz;
        Network = network;
        Light = new FakeLight(side => side == BridgeSide.Corp ? Corp : Dmz, lightOn);
    }

    public GatewayHost Corp { get; private set; }
    public GatewayHost Dmz { get; }
    public ScriptedHandler Network { get; }
    public FakeLight Light { get; }

    /// <param name="realService">The real service on the DMZ side: called with the 1-based call number and the request.</param>
    /// <param name="corpSettings">Corp gateway settings (e.g. "Gateway:Hold:DefaultSeconds").</param>
    /// <param name="lightOn">Whether the QR link runs from the start (both lanes).</param>
    public static TwoGatewayBench Start(Func<int, HttpRequestMessage, Task<HttpResponseMessage>> realService,
                                        IDictionary<string, string?>? corpSettings = null,
                                        IDictionary<string, string?>? dmzSettings = null, bool lightOn = true)
    {
        string root = GatewayHost.NewRoot();
        corpSettings ??= new Dictionary<string, string?>();
        var network = new ScriptedHandler((call, request, _) => realService(call, request));
        var corp = GatewayHost.Start(BridgeSide.Corp, root, corpSettings);
        var dmz = GatewayHost.Start(BridgeSide.Dmz, root, dmzSettings, receiverHandler: () => network);
        return new TwoGatewayBench(root, corpSettings, corp, dmz, network, lightOn);
    }

    /// <summary>Stops the Corp gateway (an app pool recycle) and starts a new one on the same database.</summary>
    public async Task RestartCorpAsync()
    {
        var old = Corp;
        await old.DisposeAsync();
        Corp = GatewayHost.Start(BridgeSide.Corp, _root, _corpSettings);
    }

    /// <summary>The real service's answer to a GetFromFMS call: RETURN_CODE 0.</summary>
    public static readonly string RealAnswer = FakeSoapService.FmsReply("GetFromFMS", 0);

    public static Task<HttpResponseMessage> Answer(int status, string body) =>
        Task.FromResult(new HttpResponseMessage((System.Net.HttpStatusCode)status)
        {
            Content = new StringContent(body, System.Text.Encoding.UTF8, "text/xml"),
        });

    /// <summary>
    /// FC2FMS.GetFromFMS WITHDRAW_RFP, a state-changing round trip (1596 when no answer comes back, retries attached).
    /// Each attempt has its own MSG_ID and GMT_TIME_SENT, as a caller's retry does; the business content is the same.
    /// </summary>
    public static byte[] WithdrawRfp(int attempt = 0)
    {
        string payload = SoapCalls.Sample("WITHDRAW_RFP.txt");
        payload = System.Text.RegularExpressions.Regex.Replace(payload, "MSG_ID=\"[^\"]*\"", $"MSG_ID=\"{456 + attempt}\"");
        payload = System.Text.RegularExpressions.Regex.Replace(payload, "GMT_TIME_SENT=\"[^\"]*\"", $"GMT_TIME_SENT=\"02/16/2004 14:0{attempt}:10\"");
        return SoapCalls.Build(FmsEndpoint.FC2FMS, "GetFromFMS", payload);
    }

    /// <summary>One caller's call to the Corp gateway: HTTP status and the reply bytes.</summary>
    public async Task<(int Status, byte[] Body)> CallAsync(byte[] request, CancellationToken ct = default)
    {
        using var client = Corp.CreateClient();
        var (response, body) = await SoapCalls.PostAsync(client, FmsEndpoint.FC2FMS, "GetFromFMS", request, ct);
        return ((int)response.StatusCode, body);
    }

    /// <summary>RETURN_CODE of a reply from the gateway (the bridge's own 1596/1599, or the real service's).</summary>
    public static int Code(byte[] reply) => SoapCalls.ReturnCode(SoapCalls.Result(reply));

    public static async Task<List<OutboxMessage>> OutboxAsync(GatewayHost host, MessageKind? kind = null)
    {
        await using var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        var rows = db.Outbox.AsNoTracking().Where(m => kind == null || m.Kind == kind);
        return await rows.OrderBy(m => m.Sequence).ToListAsync();
    }

    public static async Task WaitUntilAsync(Func<bool> condition, int seconds = 30)
    {
        var deadline = DateTime.UtcNow.AddSeconds(seconds);
        while (!condition())
        {
            if (DateTime.UtcNow > deadline) throw new TimeoutException("The condition never became true.");
            await Task.Delay(100);
        }
    }

    public static async Task<OutboxMessage> WaitForOutboxAsync(GatewayHost host, Guid messageId, Func<OutboxMessage, bool> condition,
                                                               int seconds = 30)
    {
        var deadline = DateTime.UtcNow.AddSeconds(seconds);
        while (true)
        {
            var row = await host.Get<IOutboxRepository>().FindAsync(messageId, CancellationToken.None);
            if (row is not null && condition(row)) return row;
            if (DateTime.UtcNow > deadline)
                throw new TimeoutException($"Outbox row {messageId} never reached the expected state (last: {row?.LightStatus}/{row?.ServiceStatus}).");
            await Task.Delay(100);
        }
    }

    public static async Task<InboxMessage> WaitForInboxAsync(GatewayHost host, Guid messageId, Func<InboxMessage, bool> condition,
                                                             int seconds = 30)
    {
        var deadline = DateTime.UtcNow.AddSeconds(seconds);
        while (true)
        {
            var row = await host.Get<IInboxRepository>().FindAsync(messageId, CancellationToken.None);
            if (row is not null && condition(row)) return row;
            if (DateTime.UtcNow > deadline)
                throw new TimeoutException($"Inbox row {messageId} never reached the expected state (last: {row?.LightStatus}/{row?.ServiceStatus}).");
            await Task.Delay(100);
        }
    }

    public async ValueTask DisposeAsync()
    {
        await Light.DisposeAsync();
        await Corp.DisposeAsync();
        await Dmz.DisposeAsync();
        GatewayHost.DeleteRoot(_root);
    }
}
