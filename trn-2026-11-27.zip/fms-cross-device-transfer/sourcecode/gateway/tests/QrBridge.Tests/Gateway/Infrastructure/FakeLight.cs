using System.Collections.Concurrent;
using Microsoft.EntityFrameworkCore;
using QrBridge.Shared;
using QrBridge.Shared.Bundles;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>
/// The QR link in both directions. By default one row per air: the "QR sender" claims the next Outbox row
/// (<see cref="OutboxRepository.ClaimNextAsync"/>), marks it Aired, and the "QR receiver" stores it in the other
/// gateway's Inbox (<see cref="InboxRepository.AddMessageAsync"/>) and rings the doorbell. With <see cref="Bundles"/> on it
/// runs exactly as the QrDiode apps do (decision 52): <see cref="OutboxBundler"/> claims a bundle (50 messages / 128 KB)
/// and builds its bytes, the far side's <see cref="InboxBundleWriter"/> stores them, and the bundle is marked aired in a
/// QR session. Faults are scripted per air with <see cref="Copies"/> (for a bundle: decided by its first row): 0 = the
/// session is lost, 1 = it arrives, 2 = it arrives twice (a duplicate session). Each lane can be paused. Every aired row
/// is recorded in <see cref="Aired"/>.
/// </summary>
public sealed class FakeLight : IAsyncDisposable
{
    private readonly Func<BridgeSide, GatewayHost> _host;
    private readonly CancellationTokenSource _stop = new();
    private readonly Task _loop;

    /// <param name="host">The current gateway of each side (a restarted gateway is picked up).</param>
    public FakeLight(Func<BridgeSide, GatewayHost> host, bool on)
    {
        _host = host;
        CorpToDmzOn = DmzToCorpOn = on;
        _loop = Task.Run(RunAsync);
    }

    public volatile bool CorpToDmzOn;
    public volatile bool DmzToCorpOn;

    /// <summary>Carry bundles through the QR apps' own code instead of single rows.</summary>
    public volatile bool Bundles;

    /// <summary>Every bundle put on air (bundle mode), in order.</summary>
    public ConcurrentQueue<OutgoingBundle> AiredBundles { get; } = new();

    /// <summary>Held for each pass of the loop, so <see cref="PauseAsync"/> can wait for an air already under way.</summary>
    private readonly SemaphoreSlim _airing = new(1, 1);

    /// <summary>
    /// Turns off the lane from <paramref name="from"/> and returns once an air already under way has finished: a row
    /// queued after this call stays Pending until the lane is on again. (Setting the flag alone can race with a claim
    /// that has just begun, and the row is aired at once.)
    /// </summary>
    public async Task PauseAsync(BridgeSide from)
    {
        if (from == BridgeSide.Corp) CorpToDmzOn = false;
        else DmzToCorpOn = false;
        await _airing.WaitAsync();
        _airing.Release();
    }

    /// <summary>How many copies of an aired row reach the other side (default 1). The row is as claimed (Attempts = airs so far).</summary>
    public Func<OutboxMessage, int> Copies { get; set; } = _ => 1;

    /// <summary>Every row put on air, in order, with the number of copies that arrived.</summary>
    public ConcurrentQueue<(OutboxMessage Row, int Copies)> Aired { get; } = new();

    public bool On
    {
        set => CorpToDmzOn = DmzToCorpOn = value;
    }

    /// <summary>Rows of <paramref name="kind"/> aired on the lane from <paramref name="from"/>, optionally about one message.</summary>
    public int AirsOf(BridgeSide from, MessageKind kind, Guid? correlationOrId = null) =>
        Aired.Count(a => a.Row.Direction == (from == BridgeSide.Corp ? Direction.CorpToDmz : Direction.DmzToCorp) &&
                         a.Row.Kind == kind &&
                         (correlationOrId is null || a.Row.MessageId == correlationOrId || a.Row.CorrelationId == correlationOrId));

    private async Task RunAsync()
    {
        while (!_stop.IsCancellationRequested)
        {
            bool busy = false;
            await _airing.WaitAsync(); // the lanes are checked inside, so a pause that got the lock is never overtaken
            try
            {
                if (CorpToDmzOn) busy |= await AirOneAsync(BridgeSide.Corp, BridgeSide.Dmz);
                if (DmzToCorpOn) busy |= await AirOneAsync(BridgeSide.Dmz, BridgeSide.Corp);
            }
            catch (Exception) when (!_stop.IsCancellationRequested)
            {
                // A gateway is being restarted: its database comes back with the new host.
            }
            finally
            {
                _airing.Release();
            }
            if (!busy)
            {
                try { await Task.Delay(50, _stop.Token); }
                catch (OperationCanceledException) { break; }
            }
        }
    }

    private async Task<bool> AirOneAsync(BridgeSide from, BridgeSide to)
    {
        if (Bundles) return await AirBundleAsync(from, to);

        var sender = _host(from).Get<IOutboxRepository>();
        var row = await sender.ClaimNextAsync(CancellationToken.None);
        if (row is null) return false;
        await sender.MarkAiredAsync([row.MessageId], CancellationToken.None);

        int copies = Copies(row);
        Aired.Enqueue((row, copies));
        var receiver = _host(to);
        var header = MessageSerializer.PeekHeader(row.MessageBytes);
        for (int i = 0; i < copies; i++)
            await receiver.Get<IInboxRepository>().AddMessageAsync(header, row.MessageBytes, CancellationToken.None);
        if (copies > 0) receiver.Get<BridgeSignals>().Inbox.Set();
        return true;
    }

    private async Task<bool> AirBundleAsync(BridgeSide from, BridgeSide to)
    {
        var bundler = _host(from).Get<OutboxBundler>();
        var bundle = await bundler.ClaimAsync(BundleCodec.DefaultMaxMessages, BundleCodec.DefaultMaxBytes, CancellationToken.None);
        if (bundle is null) return false;

        var qrSession = Guid.NewGuid(); // the QrDiode session that carries it
        await bundler.MarkAiredAsync(bundle.BundleId, qrSession, CancellationToken.None);
        AiredBundles.Enqueue(bundle);

        List<OutboxMessage> rows;
        await using (var db = await _host(from).Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync())
            rows = await db.Outbox.AsNoTracking().Where(m => m.BundleId == bundle.BundleId)
                .OrderBy(m => m.Priority).ThenBy(m => m.Sequence).ToListAsync();

        int copies = rows.Count > 0 ? Copies(rows[0]) : 1;
        foreach (var row in rows) Aired.Enqueue((row, copies));
        for (int i = 0; i < copies; i++)
            await _host(to).Get<InboxBundleWriter>().StoreAsync(bundle.Bytes, qrSession, CancellationToken.None); // rings the doorbell
        return true;
    }

    public async ValueTask DisposeAsync()
    {
        await _stop.CancelAsync();
        try { await _loop; } catch (OperationCanceledException) { }
        _stop.Dispose();
        _airing.Dispose();
    }
}
