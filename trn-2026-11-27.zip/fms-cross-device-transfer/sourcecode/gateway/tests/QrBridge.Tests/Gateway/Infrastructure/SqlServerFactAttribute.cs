namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>
/// A test that needs a real SQL Server: it runs when the environment variable QRBRIDGE_SQLSERVER holds a connection
/// string to a server where this login may create databases (e.g. LocalDB:
/// <c>Server=(localdb)\MSSQLLocalDB;Integrated Security=true;TrustServerCertificate=true</c>), and is skipped otherwise,
/// so <c>dotnet test All.slnx</c> stays green on a machine without one.
/// </summary>
public sealed class SqlServerFactAttribute : FactAttribute
{
    public SqlServerFactAttribute()
    {
        if (SqlServerTestDatabase.ServerConnectionString is null)
            Skip = $"Set {SqlServerTestDatabase.EnvironmentVariable} to a SQL Server connection string to run the SQL Server tests.";
    }
}
