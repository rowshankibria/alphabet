using Microsoft.EntityFrameworkCore;
using QrBridge.Gateway.Egress;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;
using QrBridge.Tests.Gateway.Infrastructure;
using static QrBridge.Tests.Gateway.Infrastructure.TwoGatewayBench;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Step 17 (G-16, decisions D80–D83): each side knows when it last heard from the far side, and an idle side sends an
/// empty Heartbeat message so silence means "the link or the far side is down", not "nothing to say".
/// </summary>
public sealed class HeartbeatTests
{
    private static TwoGatewayBench Start(bool lightOn, Dictionary<string, string?>? dmz = null) =>
        TwoGatewayBench.Start((_, _) => Answer(200, RealAnswer), lightOn: lightOn, dmzSettings: dmz);

    /// <summary>What the QR apps do: carry one Corp Outbox row's bytes into the DMZ Inbox.</summary>
    private static async Task CarryAsync(TwoGatewayBench bench, Guid messageId)
    {
        var row = await bench.Corp.Get<IOutboxRepository>().FindAsync(messageId, CancellationToken.None);
        await bench.Dmz.Get<IInboxRepository>().AddMessageAsync(MessageSerializer.PeekHeader(row!.MessageBytes), row.MessageBytes, CancellationToken.None);
        bench.Dmz.Get<BridgeSignals>().Inbox.Set();
    }

    [Fact]
    public async Task Health_turns_unhealthy_when_nothing_was_heard_from_the_far_side_for_too_long()
    {
        await using var bench = Start(lightOn: false);
        using var dmz = bench.Dmz.CreateClient();
        string fresh = await dmz.GetStringAsync("/health");
        Assert.Contains("\"healthy\":true", fresh); // never heard anything, but only just started: not silent yet

        await bench.CallAsync(WithdrawRfp());
        var request = Assert.Single(await OutboxAsync(bench.Corp, MessageKind.Request));
        await CarryAsync(bench, request.MessageId);
        await WaitForInboxAsync(bench.Dmz, request.MessageId, r => r.ServiceStatus == InboxServiceStatus.Done);

        // 20 minutes pass with nothing from the Corp side (D82: silent after 15).
        await using (var db = await bench.Dmz.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync())
            await db.Inbox.ExecuteUpdateAsync(s => s.SetProperty(m => m.ReceivedUtc, m => m.ReceivedUtc.AddMinutes(-20)));
        string silent = await dmz.GetStringAsync("/health");
        Assert.Contains("\"healthy\":false", silent);
        Assert.Contains("\"silent\":true", silent);

        // Any message from the far side clears it.
        byte[] another = SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("LIFT_CAUTION.TXT"));
        using (var corp = bench.Corp.CreateClient())
            await SoapCalls.PostAsync(corp, FmsEndpoint.FC2FMS, "SendToFMS", another);
        var second = Assert.Single(await OutboxAsync(bench.Corp, MessageKind.Request), r => r.MessageId != request.MessageId);
        await CarryAsync(bench, second.MessageId);
        await WaitForInboxAsync(bench.Dmz, second.MessageId, r => r.ServiceStatus == InboxServiceStatus.Done);
        string heard = await dmz.GetStringAsync("/health");
        Assert.Contains("\"silent\":false", heard);
        Assert.Contains("\"healthy\":true", heard);
    }

    [Fact]
    public async Task An_idle_gateway_sends_a_heartbeat_that_the_far_side_hears_and_never_confirms()
    {
        await using var bench = Start(lightOn: true);
        var monitor = bench.Dmz.Get<FarSideMonitor>();
        Assert.False(await monitor.SendHeartbeatIfIdleAsync(DateTime.UtcNow, CancellationToken.None));            // just started
        Assert.True(await monitor.SendHeartbeatIfIdleAsync(DateTime.UtcNow.AddMinutes(6), CancellationToken.None)); // 6 idle minutes (D81: 5)
        Assert.False(await monitor.SendHeartbeatIfIdleAsync(DateTime.UtcNow.AddMinutes(1), CancellationToken.None)); // it just sent one

        var heartbeat = Assert.Single(await OutboxAsync(bench.Dmz, MessageKind.Heartbeat));
        Assert.Equal(MessagePriority.Answer, heartbeat.Priority); // goes first (D80)
        var heard = await WaitForInboxAsync(bench.Corp, heartbeat.MessageId, r => r.ServiceStatus == InboxServiceStatus.Done);
        Assert.Equal(InboxLightStatus.Received, heard.LightStatus); // checked like any message
        Assert.Null(heard.ReceiptDueUtc);                           // no Receipt for a Heartbeat
        var far = await bench.Corp.Get<FarSideMonitor>().GetAsync(DateTime.UtcNow, CancellationToken.None);
        Assert.Equal(heard.ReceivedUtc, far.LastHeardUtc);
        Assert.False(far.Silent);

        // Never aired again and never "unconfirmed": a lost Heartbeat is simply replaced by the next one.
        var sender = bench.Dmz.Get<IOutboxRepository>();
        await WaitForOutboxAsync(bench.Dmz, heartbeat.MessageId, r => r.LightStatus == OutboxLightStatus.Aired);
        Assert.Empty(await sender.ReairUnconfirmedAsync(TimeSpan.Zero, maxAirAttempts: 3, CancellationToken.None));
        Assert.Null((await sender.GetCountsAsync(CancellationToken.None)).OldestUndeliveredUtc);
    }

    [Fact]
    public async Task While_the_light_is_down_heartbeats_do_not_pile_up_ahead_of_real_messages()
    {
        // One Heartbeat waits on the screen side; more would all go first (priority Answer) once the light returns.
        await using var bench = Start(lightOn: false);
        var monitor = bench.Corp.Get<FarSideMonitor>();
        Assert.True(await monitor.SendHeartbeatIfIdleAsync(DateTime.UtcNow.AddMinutes(6), CancellationToken.None));
        Assert.False(await monitor.SendHeartbeatIfIdleAsync(DateTime.UtcNow.AddMinutes(12), CancellationToken.None));
        Assert.False(await monitor.SendHeartbeatIfIdleAsync(DateTime.UtcNow.AddHours(24), CancellationToken.None));
        var waiting = Assert.Single(await OutboxAsync(bench.Corp, MessageKind.Heartbeat));

        bench.Light.On = true; // it crosses; the next idle period gets a new one
        await WaitForInboxAsync(bench.Dmz, waiting.MessageId, r => r.ServiceStatus == InboxServiceStatus.Done);
        await WaitForOutboxAsync(bench.Corp, waiting.MessageId, r => r.LightStatus == OutboxLightStatus.Aired);
        Assert.True(await monitor.SendHeartbeatIfIdleAsync(DateTime.UtcNow.AddMinutes(6), CancellationToken.None));
    }

    [Fact]
    public async Task A_heartbeat_after_a_lost_last_message_shows_it_as_missing()
    {
        // Before step 17 a lost LAST message was never a gap: nothing with a higher number came after it.
        await using var bench = Start(lightOn: true, dmz: new Dictionary<string, string?> { ["Gateway:GapGraceMinutes"] = "0" });
        bench.Light.Copies = r => r.Kind == MessageKind.Request ? 0 : 1; // the request's QR session is lost
        await bench.CallAsync(WithdrawRfp());
        var lost = Assert.Single(await OutboxAsync(bench.Corp, MessageKind.Request));
        await WaitForOutboxAsync(bench.Corp, lost.MessageId, r => r.LightStatus == OutboxLightStatus.Aired);
        Assert.Empty(await bench.Dmz.Get<SequenceGapMonitor>().CheckAsync(CancellationToken.None));

        Assert.True(await bench.Corp.Get<FarSideMonitor>().SendHeartbeatIfIdleAsync(DateTime.UtcNow.AddMinutes(6), CancellationToken.None));
        var heartbeat = Assert.Single(await OutboxAsync(bench.Corp, MessageKind.Heartbeat));
        await WaitForInboxAsync(bench.Dmz, heartbeat.MessageId, r => r.ServiceStatus == InboxServiceStatus.Done);

        var gap = Assert.Single(await bench.Dmz.Get<SequenceGapMonitor>().CheckAsync(CancellationToken.None));
        Assert.Equal((lost.Sequence, lost.Sequence), (gap.FromSequence, gap.ToSequence));
    }
}
