using QrBridge.Gateway;
using QrBridge.Shared;
using QrBridge.Tests.Gateway.Infrastructure;
using QrBridge.Tests.Ui.Infrastructure;
using static QrBridge.Tests.Gateway.Infrastructure.TwoGatewayBench;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Two real gateways, each on its own SQL Server database ("GatewayDatabase:Provider" = SqlServer), with the QR link
/// between them: the round trip and the read-only UI work exactly as on qrbridge.db. Skipped unless QRBRIDGE_SQLSERVER
/// is set (<see cref="SqlServerFactAttribute"/>).
/// </summary>
public sealed class SqlServerGatewayTests
{
    [SqlServerFact]
    public async Task A_round_trip_gives_the_caller_the_real_answer_and_the_ui_shows_it()
    {
        await using var corpDatabase = SqlServerTestDatabase.New();
        await using var dmzDatabase = SqlServerTestDatabase.New();
        await using var bench = Start((_, _) => Answer(200, RealAnswer),
            corpDatabase.Settings(new Dictionary<string, string?> { ["Gateway:Hold:DefaultSeconds"] = "30" }),
            dmzDatabase.Settings());

        var (status, body) = await bench.CallAsync(WithdrawRfp());

        Assert.Equal((200, 0), (status, Code(body)));
        Assert.Equal(1, bench.Network.Calls);
        var request = Assert.Single(await OutboxAsync(bench.Corp, MessageKind.Request));
        Assert.Equal((OutboxLightStatus.Received, OutboxServiceStatus.Answered), (request.LightStatus, request.ServiceStatus));

        // Every page reads through the UI's own connection; the id search is the UI's one piece of plain SQL.
        using var ui = await new UiBrowser(bench.Corp).SignedInAsync();
        await ui.PageAsync(UiPaths.Prefix);
        await ui.PageAsync(UiPaths.Box(MessageBox.Inbox) + "?kind=all");
        Assert.Contains("WITHDRAW_RFP", UiBrowser.Text(await ui.PageAsync(UiPaths.Message(MessageBox.Outbox, request.MessageId))));
        string found = await ui.PageAsync($"{UiPaths.Box(MessageBox.Outbox)}?q={request.MessageId.ToString("D")[..8]}");
        Assert.Contains(UiPaths.Message(MessageBox.Outbox, request.MessageId), found);
    }
}
