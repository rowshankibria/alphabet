using System.Text;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Tests.Gateway.Infrastructure;
using static QrBridge.Tests.Gateway.Infrastructure.TwoGatewayBench;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Step 14 (G-12, decisions D73, D74): a slow or stuck service of one class never holds back another class. The far
/// side runs one delivery loop per class (High = state-changing, Normal = queries, Low = feeds).
/// </summary>
public sealed class PriorityTests
{
    [Fact]
    public async Task A_permit_is_delivered_while_a_slow_feed_is_still_being_posted()
    {
        var feedPosting = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var releaseFeed = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        await using var bench = TwoGatewayBench.Start(async (_, request) =>
        {
            if (request.RequestUri!.AbsolutePath.Contains("FTC2FMS", StringComparison.OrdinalIgnoreCase))
            {
                feedPosting.TrySetResult();
                await releaseFeed.Task; // the feed's service hangs
                return await Answer(200, FakeSoapService.FmsReply("SendToFMS", 0));
            }
            return await Answer(200, RealAnswer);
        }, new Dictionary<string, string?> { ["Gateway:Hold:DefaultSeconds"] = "8" });
        try
        {
            // A Bridge feed (Low): its caller is answered at once; the DMZ side starts posting it and the service hangs.
            using var client = bench.Corp.CreateClient();
            await SoapCalls.PostAsync(client, FmsEndpoint.FTC2FMS, "SendToFMS",
                SoapCalls.Build(FmsEndpoint.FTC2FMS, "SendToFMS", SoapCalls.Sample("FAULT_CORRELATION.txt")));
            await feedPosting.Task.WaitAsync(TimeSpan.FromSeconds(20));

            var (_, body) = await bench.CallAsync(WithdrawRfp()); // a state-changing call (High)

            Assert.Equal(Encoding.UTF8.GetBytes(RealAnswer), body);
            var feed = Assert.Single(await OutboxAsync(bench.Corp, MessageKind.Request), r => r.ServiceName == "FTC2FMS");
            var stillPosting = await bench.Dmz.Get<QrBridge.Shared.Data.Repositories.IInboxRepository>().FindAsync(feed.MessageId, CancellationToken.None);
            Assert.Equal(InboxServiceStatus.Delivering, stillPosting!.ServiceStatus); // the permit did not wait for it
            Assert.Equal(MessagePriority.Low, feed.Priority);
        }
        finally
        {
            releaseFeed.TrySetResult();
        }
    }
}
