using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Step 12 (decision D18, D69–D72): the Registered Tags report, a plain HTTP GET from the Corp side
/// (WebClient.DownloadString), crosses as an empty HttpGet message, is replayed as a GET on the DMZ side and its real
/// answer comes back byte for byte. Anything else is HTTP 504. Every other GET still gets 405.
/// </summary>
public sealed class RegisteredTagsTests
{
    private const string ReportPath = "/FMS_ReportService/RegisteredTags.asmx/GetData";
    private const string Report = "<?xml version=\"1.0\" encoding=\"utf-8\"?><DataSet xmlns=\"http://tempuri.org/\"><TAG ID=\"7\">Ü</TAG></DataSet>";

    private static Dictionary<string, string?> Hold(int seconds) => new() { ["Gateway:Hold:DefaultSeconds"] = seconds.ToString() };

    private static Task<HttpResponseMessage> Answer(int status, string body, string contentType)
    {
        var content = new ByteArrayContent(Encoding.UTF8.GetBytes(body));
        content.Headers.ContentType = MediaTypeHeaderValue.Parse(contentType);
        return Task.FromResult(new HttpResponseMessage((HttpStatusCode)status) { Content = content });
    }

    [Theory]
    [InlineData(200, "text/xml; charset=utf-8", 200)]
    [InlineData(404, "text/html", 404)]   // refused by the real service: passed on as it came (D50)
    [InlineData(500, "text/html", 504)]   // may have been processed (D9): no real answer is passed on
    public async Task The_report_is_fetched_across_and_its_real_answer_replayed_byte_for_byte(int realStatus, string contentType, int expected)
    {
        HttpRequestMessage? seen = null;
        await using var bench = TwoGatewayBench.Start((_, request) => { seen = request; return Answer(realStatus, Report, contentType); }, Hold(20));

        using var response = await bench.Corp.CreateClient().GetAsync(ReportPath);
        byte[] body = await response.Content.ReadAsByteArrayAsync();

        Assert.Equal(expected, (int)response.StatusCode);
        if (expected == realStatus)
        {
            Assert.Equal(Encoding.UTF8.GetBytes(Report), body);
            Assert.Equal(contentType, response.Content.Headers.ContentType!.ToString());
        }
        else
        {
            Assert.Equal("text/plain; charset=utf-8", response.Content.Headers.ContentType!.ToString());
        }

        // The DMZ side replayed a plain GET to the configured target + the path: no body, no SOAPAction.
        Assert.Equal(1, bench.Network.Calls);
        Assert.Equal(HttpMethod.Get, seen!.Method);
        Assert.Equal("http://real-service.test" + ReportPath, seen.RequestUri!.ToString());
        Assert.Null(seen.Content);
        Assert.False(seen.Headers.Contains("SOAPAction"));

        var request = Assert.Single(await TwoGatewayBench.OutboxAsync(bench.Corp, MessageKind.Request));
        Assert.Equal(PayloadFormat.HttpGet, request.PayloadFormat);
        Assert.Equal("RegisteredTags", request.ServiceName);
        Assert.Equal(0, request.PayloadSize);
        Assert.Null(request.ContentFingerprint); // a query is never attached to an earlier call (D56)
    }

    [Fact]
    public async Task No_answer_in_time_is_a_504_and_the_query_expires_with_its_hold()
    {
        await using var bench = TwoGatewayBench.Start((_, _) => Answer(200, Report, "text/xml"), Hold(1), lightOn: false);

        using var response = await bench.Corp.CreateClient().GetAsync(ReportPath);

        Assert.Equal(HttpStatusCode.GatewayTimeout, response.StatusCode);
        Assert.Contains("not available while the network is islanded", await response.Content.ReadAsStringAsync());
        var request = Assert.Single(await TwoGatewayBench.OutboxAsync(bench.Corp, MessageKind.Request));
        Assert.Equal(request.CreatedUtc.AddSeconds(1), request.ExpiresUtc!.Value, TimeSpan.FromMilliseconds(100)); // D54
        Assert.Equal(request.MessageId.ToString("D"), response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());
    }

    [Fact]
    public async Task A_report_service_that_cannot_be_reached_is_a_504_at_once()
    {
        await using var bench = TwoGatewayBench.Start(
            (_, _) => throw new HttpRequestException(HttpRequestError.ConnectionError, "refused"), Hold(25));
        var clock = Stopwatch.StartNew();

        using var response = await bench.Corp.CreateClient().GetAsync(ReportPath);

        Assert.Equal(HttpStatusCode.GatewayTimeout, response.StatusCode);
        Assert.True(clock.Elapsed < TimeSpan.FromSeconds(20), $"took {clock.Elapsed}"); // fast failure, not the full hold
        var request = Assert.Single(await TwoGatewayBench.OutboxAsync(bench.Corp, MessageKind.Request));
        Assert.Equal(OutboxServiceStatus.NotDelivered, request.ServiceStatus);
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task A_query_string_a_soap_post_or_another_method_is_refused_and_nothing_is_queued()
    {
        await using var bench = TwoGatewayBench.Start((_, _) => Answer(200, Report, "text/xml"), Hold(1), lightOn: false);
        using var client = bench.Corp.CreateClient();

        using var query = await client.GetAsync(ReportPath + "?tag=1");
        using var head = await client.SendAsync(new HttpRequestMessage(HttpMethod.Head, ReportPath));
        var (post, fault) = await SoapCalls.PostAsync(client, FmsEndpoint.FC2FMS with { Path = ReportPath }, "GetData",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "GetData", "<x/>"));

        Assert.Equal(HttpStatusCode.BadRequest, query.StatusCode); // D71
        Assert.Equal(HttpStatusCode.MethodNotAllowed, head.StatusCode);
        Assert.Equal(HttpStatusCode.InternalServerError, post.StatusCode);
        Assert.Contains("plain HTTP GET interface", Encoding.UTF8.GetString(fault));
        using var dmzGet = await bench.Dmz.CreateClient().GetAsync(ReportPath); // its callers are on the Corp side (D72)
        Assert.Equal(HttpStatusCode.MethodNotAllowed, dmzGet.StatusCode);
        Assert.Empty(await TwoGatewayBench.OutboxAsync(bench.Corp));
        Assert.Empty(await TwoGatewayBench.OutboxAsync(bench.Dmz));
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task A_get_message_is_only_ever_replayed_for_the_get_route(bool getForASoapService)
    {
        // A message whose format does not match its route (e.g. altered or from another catalogue) is rejected, never sent.
        await using var bench = TwoGatewayBench.Start((_, _) => Answer(200, Report, "text/xml"), Hold(1), lightOn: false);
        var serializer = bench.Corp.Get<MessageSerializer>();
        MessageHeader header;
        if (getForASoapService)
        {
            using var _ = await bench.Corp.CreateClient().GetAsync(ReportPath);
            var get = Assert.Single(await TwoGatewayBench.OutboxAsync(bench.Corp, MessageKind.Request));
            header = serializer.Deserialize(get.MessageBytes).Header with { ServiceName = "FC2FMS", Path = FmsEndpoint.FC2FMS.Path };
        }
        else
        {
            header = new MessageHeader
            {
                MessageId = Guid.NewGuid(), Direction = Direction.CorpToDmz, ServiceName = "RegisteredTags", Operation = "GET",
                Path = ReportPath, ContentType = "text/xml", BusinessType = "", Sequence = 99, SequenceRunId = Guid.NewGuid(),
                CatalogFingerprint = bench.Dmz.Get<QrBridge.Gateway.Routing.RouteTable>().CatalogFingerprint, CreatedUtc = DateTime.UtcNow,
            };
        }
        byte[] bytes = serializer.Serialize(header, getForASoapService ? [] : "<x/>"u8.ToArray());
        await bench.Dmz.Get<IInboxRepository>().AddMessageAsync(header, bytes, CancellationToken.None);
        bench.Dmz.Get<BridgeSignals>().Inbox.Set();

        var row = await TwoGatewayBench.WaitForInboxAsync(bench.Dmz, header.MessageId, r => r.LightStatus == InboxLightStatus.Rejected);
        Assert.Contains(getForASoapService ? "not an HTTP GET interface" : "is an HTTP GET interface", row.LightComment);
        Assert.Equal(0, bench.Network.Calls);
    }
}
