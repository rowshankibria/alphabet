using System.Text;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Tests.Gateway.Infrastructure;
using static QrBridge.Tests.Gateway.Infrastructure.TwoGatewayBench;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Two real gateways joined by the QR apps' own code (decision 52, Integration-Plan §2.2–2.5): the sending side's
/// <c>OutboxBundler</c> claims bundles and the far side's <c>InboxBundleWriter</c> stores them (<see cref="FakeLight.Bundles"/>).
/// Only the screen and the camera are left out. Whatever happens to a bundle on the light, the real service is called
/// once per request and the held caller gets the real answer.
/// </summary>
public sealed class BundleLightTests
{
    private static readonly byte[] RealAnswerBytes = Encoding.UTF8.GetBytes(RealAnswer);

    private static Dictionary<string, string?> Settings(bool reAir = false)
    {
        var settings = new Dictionary<string, string?> { ["Gateway:Hold:DefaultSeconds"] = "30" };
        if (reAir)
        {
            settings["Gateway:ReceiptTimeoutSeconds"] = "1";
            settings["Gateway:MaintenanceIntervalSeconds"] = "10";
        }
        return settings;
    }

    private static TwoGatewayBench Start(Dictionary<string, string?>? corp = null, bool lightOn = true)
    {
        var bench = TwoGatewayBench.Start((_, _) => Answer(200, RealAnswer), corp ?? Settings(), lightOn: lightOn);
        bench.Light.Bundles = true;
        return bench;
    }

    /// <summary>A WITHDRAW_RFP for another RFP: different business content, so it is a new request, not a caller's retry.</summary>
    private static byte[] Withdraw(int rfp) =>
        SoapCalls.Build(FmsEndpoint.FC2FMS, "GetFromFMS", SoapCalls.Sample("WITHDRAW_RFP.txt").Replace(">3005<", $">{rfp}<"));

    [Fact]
    public async Task A_round_trip_through_bundles_gets_the_real_answer_and_both_sides_record_the_bundle()
    {
        await using var bench = Start();

        var (status, body) = await bench.CallAsync(WithdrawRfp());

        Assert.Equal(200, status);
        Assert.Equal(RealAnswerBytes, body);
        var request = Assert.Single(await OutboxAsync(bench.Corp, MessageKind.Request));
        request = await WaitForOutboxAsync(bench.Corp, request.MessageId, r => r.LightStatus == OutboxLightStatus.Received);
        Assert.NotNull(request.BundleId);
        Assert.NotNull(request.QrSessionId);

        var arrived = await WaitForInboxAsync(bench.Dmz, request.MessageId, r => r.ServiceStatus == InboxServiceStatus.Done);
        Assert.Equal((request.BundleId, request.QrSessionId), (arrived.BundleId, arrived.QrSessionId)); // the same bundle and QR session on both sides
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task Messages_waiting_together_cross_in_one_bundle_and_every_caller_gets_its_answer()
    {
        await using var bench = Start(lightOn: false);

        var calls = Enumerable.Range(1, 5).Select(i => bench.CallAsync(Withdraw(4000 + i))).ToList();
        var deadline = DateTime.UtcNow.AddSeconds(30);
        while ((await OutboxAsync(bench.Corp, MessageKind.Request)).Count < 5)
        {
            if (DateTime.UtcNow > deadline) throw new TimeoutException("The five requests were never queued.");
            await Task.Delay(100);
        }
        bench.Light.On = true;
        var results = await Task.WhenAll(calls);

        Assert.All(results, r =>
        {
            Assert.Equal(200, r.Status);
            Assert.Equal(RealAnswerBytes, r.Body);
        });
        var requestBundle = bench.Light.AiredBundles.First(); // the first air on the Corp lane: all five waited together
        Assert.Equal(5, requestBundle.Count);
        Assert.Equal(5, bench.Network.Calls);
    }

    [Fact]
    public async Task A_lost_bundle_is_aired_again_and_the_caller_still_gets_the_real_answer()
    {
        await using var bench = Start(Settings(reAir: true));
        bench.Light.Copies = first => first.Kind == MessageKind.Request && first.Attempts == 1 ? 0 : 1;

        var (status, body) = await bench.CallAsync(WithdrawRfp());

        Assert.Equal(200, status);
        Assert.Equal(RealAnswerBytes, body);
        Assert.Equal(2, bench.Light.AirsOf(BridgeSide.Corp, MessageKind.Request));
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task A_bundle_that_arrives_twice_is_stored_once_and_posted_once()
    {
        await using var bench = Start();
        bench.Light.Copies = first => first.Kind == MessageKind.Request ? 2 : 1;

        var (status, body) = await bench.CallAsync(WithdrawRfp());

        Assert.Equal(200, status);
        Assert.Equal(RealAnswerBytes, body);
        Assert.Equal(1, bench.Network.Calls);
    }
}
