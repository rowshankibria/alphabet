using System.Net;
using System.Text;
using Microsoft.EntityFrameworkCore;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Step 9b: the receiving gateway answers over the opposite lane. A Receipt for every message that arrived ("it crossed
/// the light", D44) and a Reply for every final outcome of a Request, carrying the real answer (D43, D45). Nothing
/// consumes them yet (step 10); here they are read straight from the receiving gateway's Outbox.
/// </summary>
public sealed class ReplyAndReceiptTests
{
    private const string RealAnswerContentType = "text/xml; charset=utf-8";

    private static readonly TimeSpan Settle = TimeSpan.FromSeconds(2.5);

    private sealed class Bench(string root, GatewayHost corp, GatewayHost dmz, ScriptedHandler network) : IAsyncDisposable
    {
        public GatewayHost Corp { get; } = corp;
        public GatewayHost Dmz { get; } = dmz;
        public ScriptedHandler Network { get; } = network;

        public async ValueTask DisposeAsync()
        {
            await Corp.DisposeAsync();
            await Dmz.DisposeAsync();
            GatewayHost.DeleteRoot(root);
        }
    }

    private static Bench Start(Func<int, Task<HttpResponseMessage>> realService, Dictionary<string, string?>? dmzSettings = null)
    {
        string root = GatewayHost.NewRoot();
        var network = new ScriptedHandler((call, _, _) => realService(call));
        var corp = GatewayHost.Start(BridgeSide.Corp, root);
        var dmz = GatewayHost.Start(BridgeSide.Dmz, root, dmzSettings, receiverHandler: () => network);
        return new Bench(root, corp, dmz, network);
    }

    private static Task<HttpResponseMessage> Answer(int status, string body) =>
        Task.FromResult(new HttpResponseMessage((HttpStatusCode)status) { Content = new StringContent(body, Encoding.UTF8, "text/xml") });

    private static async Task<Guid> PermitAsync(GatewayHost corp)
    {
        using var client = corp.CreateClient();
        var (response, _) = await SoapCalls.PostAsync(client, FmsEndpoint.FC2FMS, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("LIFT_CAUTION.TXT")));
        return Guid.Parse(response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());
    }

    private static async Task CarryAsync(GatewayHost from, GatewayHost to, Guid messageId, Func<MessageHeader, MessageHeader>? alter = null)
    {
        var row = await from.Get<IOutboxRepository>().FindAsync(messageId, CancellationToken.None);
        byte[] bytes = row!.MessageBytes;
        var header = MessageSerializer.PeekHeader(bytes);
        if (alter is not null)
        {
            var serializer = from.Get<MessageSerializer>();
            var (original, body) = serializer.Deserialize(bytes);
            header = alter(original);
            bytes = serializer.Serialize(header, body);
        }
        await to.Get<IInboxRepository>().AddMessageAsync(header, bytes, CancellationToken.None);
        to.Get<BridgeSignals>().Inbox.Set();
    }

    private static async Task<List<OutboxMessage>> AnswersAsync(GatewayHost host, MessageKind kind, Guid correlationId)
    {
        await using var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        return await db.Outbox.AsNoTracking().Where(m => m.Kind == kind && m.CorrelationId == correlationId).ToListAsync();
    }

    private static async Task<List<OutboxMessage>> WaitForAnswersAsync(GatewayHost host, MessageKind kind, Guid correlationId, int count = 1)
    {
        var deadline = DateTime.UtcNow.AddSeconds(20);
        while (true)
        {
            var rows = await AnswersAsync(host, kind, correlationId);
            if (rows.Count >= count) return rows;
            if (DateTime.UtcNow > deadline)
                throw new TimeoutException($"Only {rows.Count} {kind} row(s) for {correlationId}, expected {count}.");
            await Task.Delay(100);
        }
    }

    private static async Task<InboxMessage> WaitForInboxAsync(GatewayHost host, Guid messageId, Func<InboxMessage, bool> condition)
    {
        var deadline = DateTime.UtcNow.AddSeconds(20);
        while (true)
        {
            var row = await host.Get<IInboxRepository>().FindAsync(messageId, CancellationToken.None);
            if (row is not null && condition(row)) return row;
            if (DateTime.UtcNow > deadline)
                throw new TimeoutException($"Inbox row never reached the expected state (last: {row?.LightStatus}/{row?.ServiceStatus}).");
            await Task.Delay(100);
        }
    }

    // ---------------------------------------------------------------- Replies

    [Fact]
    public async Task A_delivered_request_is_answered_with_a_reply_carrying_the_real_answer_byte_for_byte()
    {
        string realAnswer = FakeSoapService.FmsReply("SendToFMS", 0);
        await using var bench = Start(_ => Answer(200, realAnswer));
        Guid requestId = await PermitAsync(bench.Corp);
        await CarryAsync(bench.Corp, bench.Dmz, requestId);

        await WaitForInboxAsync(bench.Dmz, requestId, r => r.ServiceStatus == InboxServiceStatus.Done);
        var replies = await AnswersAsync(bench.Dmz, MessageKind.Reply, requestId); // D46: written before the row was marked

        var reply = Assert.Single(replies);
        var (header, body) = bench.Dmz.Get<MessageSerializer>().Deserialize(reply.MessageBytes);
        Assert.Equal(MessageKind.Reply, header.Kind);
        Assert.Equal(requestId, header.CorrelationId);
        Assert.Equal(Direction.DmzToCorp, header.Direction); // the opposite lane
        Assert.Equal(Encoding.UTF8.GetBytes(realAnswer), body);
        Assert.Equal(RealAnswerContentType, header.ContentType);
        Assert.Equal("FC2FMS", header.ServiceName); // for operators
        Assert.Equal(ServiceOutcome.Done, header.Outcome);
        Assert.Equal(200, header.ServiceHttpStatus);
        Assert.Contains("RETURN_CODE=0", header.ServiceComment);
    }

    [Fact]
    public async Task An_answer_too_large_to_carry_back_is_left_out_and_the_reply_says_so()
    {
        string realAnswer = FakeSoapService.FmsReply("SendToFMS", 0, new string('x', 10_000));
        await using var bench = Start(_ => Answer(200, realAnswer), new Dictionary<string, string?> { ["GatewayDatabase:MaxPayloadBytes"] = "6000" });
        Guid requestId = await PermitAsync(bench.Corp);
        await CarryAsync(bench.Corp, bench.Dmz, requestId);

        var reply = Assert.Single(await WaitForAnswersAsync(bench.Dmz, MessageKind.Reply, requestId));
        var (header, body) = bench.Dmz.Get<MessageSerializer>().Deserialize(reply.MessageBytes);
        Assert.Equal(ServiceOutcome.Done, header.Outcome); // the outcome still travels
        Assert.Empty(body);
        Assert.Equal("", header.ContentType);
        Assert.Contains("too large to carry back", header.ServiceComment);
    }

    public static TheoryData<string> FinalOutcomes => ["refused", "unknown", "not delivered", "expired", "rejected"];

    [Theory]
    [MemberData(nameof(FinalOutcomes))]
    public async Task Every_final_outcome_of_a_request_is_answered_with_a_reply(string outcome)
    {
        var dmzSettings = new Dictionary<string, string?>();
        if (outcome == "not delivered") dmzSettings["Gateway:Receiver:DefaultBaseUrl"] = "";            // no target (D25)
        if (outcome == "rejected") dmzSettings["Routing:ReplyProfiles:FmsResponse:Busy"] = "<changed/>"; // other catalogue
        await using var bench = Start(_ => outcome == "unknown"
            ? Answer(502, "<html>Bad Gateway</html>")
            : Answer(200, FakeSoapService.FmsReply("SendToFMS", 1501, "Card is not active")), dmzSettings);
        Guid requestId = await PermitAsync(bench.Corp);
        await CarryAsync(bench.Corp, bench.Dmz, requestId, outcome == "expired"
            ? h => h with { CreatedUtc = DateTime.UtcNow.AddMinutes(-15), ExpiresUtc = DateTime.UtcNow.AddMinutes(-1) }
            : null);

        var reply = Assert.Single(await WaitForAnswersAsync(bench.Dmz, MessageKind.Reply, requestId));
        var (header, _) = bench.Dmz.Get<MessageSerializer>().Deserialize(reply.MessageBytes);
        Assert.Equal(requestId, header.CorrelationId);

        var (expected, httpStatus, comment) = outcome switch
        {
            "refused" => (ServiceOutcome.Refused, (int?)200, "RETURN_CODE=1501"),
            "unknown" => (ServiceOutcome.Unknown, 502, "may have processed"),
            "not delivered" => (ServiceOutcome.NotDelivered, null, "No Receiver target"),
            "expired" => (ServiceOutcome.Expired, null, "expired"),
            _ => (ServiceOutcome.Rejected, null, "route catalogue differs"),
        };
        Assert.Equal(expected, header.Outcome);
        Assert.Equal(httpStatus, header.ServiceHttpStatus);
        Assert.Contains(comment, header.ServiceComment);

        // The receiving side's own row says the same (the Reply was written first, D46).
        var row = await WaitForInboxAsync(bench.Dmz, requestId,
            r => r.LightStatus == InboxLightStatus.Rejected || r.ServiceStatus is not (InboxServiceStatus.Pending or InboxServiceStatus.Delivering));
        Assert.Equal(expected == ServiceOutcome.Rejected ? InboxLightStatus.Rejected : InboxLightStatus.Received, row.LightStatus);
        if (expected != ServiceOutcome.Rejected)
            Assert.Equal(expected.ToString(), row.ServiceStatus.ToString());
    }

    // ---------------------------------------------------------------- crash recovery (D46)

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task A_row_found_delivering_after_a_crash_takes_its_replys_outcome_or_becomes_unknown(bool replyAlreadySent)
    {
        await using var bench = Start(_ => Answer(200, FakeSoapService.FmsReply("SendToFMS", 0)));
        Guid requestId = await PermitAsync(bench.Corp);
        var sent = await bench.Corp.Get<IOutboxRepository>().FindAsync(requestId, CancellationToken.None);
        var request = MessageSerializer.PeekHeader(sent!.MessageBytes);

        // The DMZ gateway died during the POST: the row is still Delivering (inserted that way, so no worker races us).
        await using (var db = await bench.Dmz.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync())
        {
            db.Inbox.Add(new InboxMessage
            {
                MessageId = requestId, Direction = request.Direction, ServiceName = request.ServiceName, Operation = request.Operation,
                BusinessType = request.BusinessType, Sequence = request.Sequence, SequenceRunId = request.SequenceRunId,
                PayloadFormat = request.PayloadFormat, Kind = MessageKind.Request, ContentFingerprint = request.ContentFingerprint,
                MessageBytes = sent.MessageBytes, MessageHash = sent.MessageHash, ServiceStatus = InboxServiceStatus.Delivering,
                LockedUtc = DateTime.UtcNow.AddMinutes(-2), CreatedUtc = request.CreatedUtc, ReceivedUtc = DateTime.UtcNow,
            });
            await db.SaveChangesAsync();
        }
        if (replyAlreadySent) // it crashed after the Reply was written, before the row was marked
            await bench.Dmz.Get<OutboxWriter>().EnqueueAsync(ReplyHeader(requestId) with
            {
                Outcome = ServiceOutcome.Done, ServiceHttpStatus = 200, ServiceComment = "RETURN_CODE=0",
            }, "<answer/>"u8.ToArray());

        // One minute, not the maintenance worker's five: its own start-up pass must not settle the row before we do.
        Assert.Equal(1, await bench.Dmz.Get<AnswerWriter>().RecoverStuckAsync(TimeSpan.FromMinutes(1), CancellationToken.None));

        var row = await bench.Dmz.Get<IInboxRepository>().FindAsync(requestId, CancellationToken.None);
        var replies = await AnswersAsync(bench.Dmz, MessageKind.Reply, requestId);
        var reply = MessageSerializer.PeekHeader(Assert.Single(replies).MessageBytes); // never a second Reply
        Assert.Equal(replyAlreadySent ? InboxServiceStatus.Done : InboxServiceStatus.Unknown, row!.ServiceStatus);
        Assert.Equal(replyAlreadySent ? ServiceOutcome.Done : ServiceOutcome.Unknown, reply.Outcome);
        Assert.Equal(0, bench.Network.Calls); // never posted again
    }

    [Fact]
    public async Task A_request_still_being_retried_has_no_reply_yet()
    {
        // Only a final outcome is answered: a "nothing sent" failure is retried first (D9).
        await using var bench = Start(_ => Answer(429, "<html>Too Many Requests</html>"),
            new Dictionary<string, string?> { ["Gateway:MaxAttempts"] = "50" });
        Guid requestId = await PermitAsync(bench.Corp);
        await CarryAsync(bench.Corp, bench.Dmz, requestId);

        await WaitForInboxAsync(bench.Dmz, requestId, r => r.ServiceStatus == InboxServiceStatus.Retrying);
        await Task.Delay(Settle);

        Assert.Empty(await AnswersAsync(bench.Dmz, MessageKind.Reply, requestId));
    }

    // ---------------------------------------------------------------- Receipts

    [Fact]
    public async Task Every_arrived_message_gets_a_receipt_and_a_re_aired_copy_gets_another()
    {
        await using var bench = Start(_ => Answer(200, FakeSoapService.FmsReply("SendToFMS", 0)));
        Guid requestId = await PermitAsync(bench.Corp);
        await CarryAsync(bench.Corp, bench.Dmz, requestId);

        var receipt = Assert.Single(await WaitForAnswersAsync(bench.Dmz, MessageKind.Receipt, requestId));
        var (header, body) = bench.Dmz.Get<MessageSerializer>().Deserialize(receipt.MessageBytes);
        Assert.Equal(requestId, header.CorrelationId);
        Assert.Equal(Direction.DmzToCorp, header.Direction);
        Assert.Empty(body);

        // The QR session is aired again (its Receipt was lost): the Inbox ignores the copy, but a new Receipt is sent.
        await CarryAsync(bench.Corp, bench.Dmz, requestId);
        Assert.Equal(2, (await WaitForAnswersAsync(bench.Dmz, MessageKind.Receipt, requestId, count: 2)).Count);
    }

    [Fact]
    public async Task A_reply_that_arrives_gets_a_receipt_but_a_receipt_never_does()
    {
        await using var bench = Start(_ => Answer(200, FakeSoapService.FmsReply("SendToFMS", 0)));
        Guid requestId = await PermitAsync(bench.Corp);
        await CarryAsync(bench.Corp, bench.Dmz, requestId);
        var reply = Assert.Single(await WaitForAnswersAsync(bench.Dmz, MessageKind.Reply, requestId));
        var receipt = Assert.Single(await WaitForAnswersAsync(bench.Dmz, MessageKind.Receipt, requestId));

        // Both cross back to the Corp gateway.
        await CarryAsync(bench.Dmz, bench.Corp, reply.MessageId);
        await CarryAsync(bench.Dmz, bench.Corp, receipt.MessageId);

        Assert.Single(await WaitForAnswersAsync(bench.Corp, MessageKind.Receipt, reply.MessageId));
        await Task.Delay(Settle);
        Assert.Empty(await AnswersAsync(bench.Corp, MessageKind.Receipt, receipt.MessageId));
    }

    [Fact]
    public async Task A_message_whose_receipt_is_lost_is_aired_again_and_confirmed_by_the_second_receipt()
    {
        // Step 11 (G-02, D65): the maintenance run re-airs an Aired row that got no Receipt in time.
        string root = GatewayHost.NewRoot();
        var network = new ScriptedHandler((_, _, _) => Answer(200, FakeSoapService.FmsReply("SendToFMS", 0)));
        var corp = GatewayHost.Start(BridgeSide.Corp, root, new Dictionary<string, string?>
        {
            ["Gateway:ReceiptTimeoutSeconds"] = "1",
            ["Gateway:MaintenanceIntervalSeconds"] = "10",
        });
        var dmz = GatewayHost.Start(BridgeSide.Dmz, root, receiverHandler: () => network);
        try
        {
            var outbox = corp.Get<IOutboxRepository>();
            Guid requestId = await PermitAsync(corp);
            await AirAsync(outbox, requestId);
            await CarryAsync(corp, dmz, requestId);
            await WaitForAnswersAsync(dmz, MessageKind.Receipt, requestId); // written, then lost on the light

            var queued = await WaitForOutboxAsync(corp, requestId, r => r.LightStatus == OutboxLightStatus.Pending);
            Assert.Equal(1, queued.Attempts);
            Assert.Contains("no receipt", queued.LightComment, StringComparison.OrdinalIgnoreCase);

            await AirAsync(outbox, requestId); // the QR sender airs it again; the far Inbox skips the copy and owes a new Receipt
            await CarryAsync(corp, dmz, requestId);
            var receipts = await WaitForAnswersAsync(dmz, MessageKind.Receipt, requestId, count: 2);
            await CarryAsync(dmz, corp, receipts.OrderBy(r => r.Sequence).Last().MessageId);

            var confirmed = await WaitForOutboxAsync(corp, requestId, r => r.LightStatus == OutboxLightStatus.Received);
            Assert.Equal(2, confirmed.Attempts);
            Assert.Null(confirmed.LightComment);
            Assert.Equal(1, network.Calls); // re-airing never makes a second POST
        }
        finally
        {
            await corp.DisposeAsync();
            await dmz.DisposeAsync();
            GatewayHost.DeleteRoot(root);
        }
    }

    [Fact]
    public async Task A_message_never_confirmed_after_its_last_air_is_failed_and_raises_the_alarm_until_a_receipt_comes()
    {
        // Step 11 (D66): out of tries → light Failed, /health unhealthy; a Receipt that comes after all still confirms it.
        string root = GatewayHost.NewRoot();
        var network = new ScriptedHandler((_, _, _) => Answer(200, FakeSoapService.FmsReply("SendToFMS", 0)));
        var corp = GatewayHost.Start(BridgeSide.Corp, root, new Dictionary<string, string?>
        {
            ["Gateway:ReceiptTimeoutSeconds"] = "1",
            ["Gateway:MaxAirAttempts"] = "1",
            ["Gateway:MaintenanceIntervalSeconds"] = "10",
        });
        var dmz = GatewayHost.Start(BridgeSide.Dmz, root, receiverHandler: () => network);
        try
        {
            Guid requestId = await PermitAsync(corp);
            await AirAsync(corp.Get<IOutboxRepository>(), requestId);
            await CarryAsync(corp, dmz, requestId);
            var receipt = Assert.Single(await WaitForAnswersAsync(dmz, MessageKind.Receipt, requestId)); // lost for now

            var failed = await WaitForOutboxAsync(corp, requestId, r => r.LightStatus == OutboxLightStatus.Failed);
            Assert.Contains("check the screen, the camera and the far QR Receiver", failed.LightComment);
            using var client = corp.CreateClient();
            string health = await client.GetStringAsync("/health");
            Assert.Contains("\"healthy\":false", health);
            Assert.Contains("\"lightProblems\":1", health);

            await CarryAsync(dmz, corp, receipt.MessageId);
            await WaitForOutboxAsync(corp, requestId, r => r.LightStatus == OutboxLightStatus.Received);
            Assert.Contains("\"lightProblems\":0", await client.GetStringAsync("/health"));
        }
        finally
        {
            await corp.DisposeAsync();
            await dmz.DisposeAsync();
            GatewayHost.DeleteRoot(root);
        }
    }

    private static async Task AirAsync(IOutboxRepository outbox, Guid messageId)
    {
        var claimed = await outbox.ClaimNextAsync(CancellationToken.None);
        Assert.Equal(messageId, claimed?.MessageId);
        await outbox.MarkAiredAsync([messageId], CancellationToken.None);
    }

    private static async Task<OutboxMessage> WaitForOutboxAsync(GatewayHost host, Guid messageId, Func<OutboxMessage, bool> condition)
    {
        var deadline = DateTime.UtcNow.AddSeconds(30);
        while (true)
        {
            var row = await host.Get<IOutboxRepository>().FindAsync(messageId, CancellationToken.None);
            if (row is not null && condition(row)) return row;
            if (DateTime.UtcNow > deadline)
                throw new TimeoutException($"Outbox row never reached the expected state (last: {row?.LightStatus}/{row?.ServiceStatus}).");
            await Task.Delay(200);
        }
    }

    // ---------------------------------------------------------------- backlog (D47)

    private static MessageHeader ReplyHeader(Guid correlationId) => new()
    {
        Kind = MessageKind.Reply,
        CorrelationId = correlationId,
        Outcome = ServiceOutcome.Done,
        ServiceName = "FC2FMS",
        Operation = "SendToFMS",
        Path = "/FMS_FC2FMSInterface/FC2FMSInterface.svc",
        ContentType = RealAnswerContentType,
    };

    [Fact]
    public async Task Answers_never_count_against_the_backlog_and_are_never_refused()
    {
        string root = GatewayHost.NewRoot();
        try
        {
            await using var dmz = GatewayHost.Start(BridgeSide.Dmz, root, new Dictionary<string, string?> { ["Gateway:MaxBacklog"] = "1" });
            var writer = dmz.Get<OutboxWriter>();
            await writer.EnqueueAsync(ReplyHeader(Guid.NewGuid()), "<answer/>"u8.ToArray());

            // A DMZ caller is still accepted: the Reply is not a Request.
            using var client = dmz.CreateClient();
            string payload = "<MESSAGE TYPE=\"CARD_CREATE\" MSG_ID=\"1\"><MSG_HEADER /><MSG_DATA /></MESSAGE>";
            var (response, reply) = await SoapCalls.PostAsync(client, FmsEndpoint.FMS2FC, "CreateCard", SoapCalls.Build(FmsEndpoint.FMS2FC, "CreateCard", payload));
            Assert.Equal(1596, SoapCalls.ReturnCode(SoapCalls.Result(reply))); // queued and held (D60), not 1598 "busy"
            Assert.True(response.Headers.Contains(SenderEndpoint.MessageIdHeader));

            // The Outbox is now full of Requests, and an answer is still written.
            await writer.EnqueueAsync(ReplyHeader(Guid.NewGuid()), "<answer/>"u8.ToArray());
        }
        finally
        {
            GatewayHost.DeleteRoot(root);
        }
    }
}
