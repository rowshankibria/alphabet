using System.Text;
using Microsoft.EntityFrameworkCore;
using QrBridge.Gateway;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Ingress;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Corp gateway -> (the QR link, simulated by copying the message bytes) -> DMZ gateway -> real service.
/// The QR apps move exactly these message bytes; everything else here is the real code.
/// </summary>
public sealed class EndToEndTests : IAsyncLifetime
{
    private readonly string _root = GatewayHost.NewRoot();
    private FakeSoapService _realService = null!;
    private GatewayHost _corp = null!;
    private GatewayHost _dmz = null!;
    private HttpClient _corpClient = null!;

    public async Task InitializeAsync()
    {
        _realService = await FakeSoapService.StartAsync();
        _corp = GatewayHost.Start(BridgeSide.Corp, _root, receiverHandler: _realService.CreateHandler);
        _dmz = GatewayHost.Start(BridgeSide.Dmz, _root, receiverHandler: _realService.CreateHandler);
        _corpClient = _corp.CreateClient();
    }

    public async Task DisposeAsync()
    {
        _corpClient.Dispose();
        await _corp.DisposeAsync();
        await _dmz.DisposeAsync();
        await _realService.DisposeAsync();
        GatewayHost.DeleteRoot(_root);
    }

    private async Task<(Guid MessageId, byte[] Request)> CallCorpAsync(string sample)
    {
        byte[] request = SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample(sample));
        var (response, reply) = await SoapCalls.PostAsync(_corpClient, FmsEndpoint.FC2FMS, "SendToFMS", request);
        // Permits are RoundTrip (D60): held, and with no Reply carried back here the hold (1 s in tests) ends in 1596.
        Assert.Equal(1596, SoapCalls.ReturnCode(SoapCalls.Result(reply)));
        return (Guid.Parse(response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single()), request);
    }

    /// <summary>What the QR sender + receiver do: carry the message bytes, unchanged, into the other side's Inbox.</summary>
    private static async Task CarryAcrossAsync(GatewayHost from, GatewayHost to, Guid messageId)
    {
        var row = await from.Get<IOutboxRepository>().FindAsync(messageId, CancellationToken.None);
        var header = MessageSerializer.PeekHeader(row!.MessageBytes);
        Assert.True(await to.Get<IInboxRepository>().AddMessageAsync(header, row.MessageBytes, CancellationToken.None));
        to.Get<BridgeSignals>().Inbox.Set();
    }

    private static async Task<InboxMessage> WaitForAsync(GatewayHost host, Guid messageId, Func<InboxMessage, bool> condition)
    {
        var inbox = host.Get<IInboxRepository>();
        var deadline = DateTime.UtcNow.AddSeconds(20);
        while (true)
        {
            var row = await inbox.FindAsync(messageId, CancellationToken.None);
            if (row is not null && condition(row)) return row;
            if (DateTime.UtcNow > deadline)
                throw new TimeoutException($"Inbox row {messageId} never reached the expected state " +
                                           $"(last: {row?.LightStatus}/{row?.ServiceStatus} {row?.LightComment} {row?.ServiceComment}).");
            await Task.Delay(100);
        }
    }

    [Fact]
    public async Task A_call_to_the_corp_gateway_reaches_the_real_service_byte_for_byte()
    {
        var (messageId, request) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        await CarryAcrossAsync(_corp, _dmz, messageId);

        var row = await WaitForAsync(_dmz, messageId, r => r.ServiceStatus == InboxServiceStatus.Done);
        Assert.Equal("RETURN_CODE=0", row.DownstreamResult);
        Assert.Equal(200, row.ServiceHttpStatus);
        Assert.Equal("REQUEST_FOR_PERMIT", row.BusinessType);

        var received = Assert.Single(_realService.Requests);
        Assert.Equal(FmsEndpoint.FC2FMS.Path, received.Path);                              // same path as on the load balancer
        Assert.Equal("\"http://tempuri.org/IFC2FMSInterface/SendToFMS\"", received.SoapAction); // same SOAPAction
        Assert.StartsWith("text/xml", received.ContentType);
        Assert.Equal(request, received.Body);                                               // identical bytes
    }

    [Fact]
    public async Task A_refusal_from_the_real_service_is_kept_with_its_reason_and_not_retried()
    {
        _realService.Responder = _ => (200, FakeSoapService.FmsReply("SendToFMS", 1501, "Card 129979 is not active"));
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        await CarryAcrossAsync(_corp, _dmz, messageId);

        var row = await WaitForAsync(_dmz, messageId, r => r.ServiceStatus == InboxServiceStatus.Refused);
        Assert.Contains("1501", row.DownstreamResult);
        Assert.Contains("Card 129979 is not active", row.DownstreamResult);
        Assert.Equal(200, row.ServiceHttpStatus);
        Assert.Single(_realService.Requests); // not retried
    }

    [Fact]
    public async Task A_2xx_reply_without_a_readable_result_is_unknown_and_not_retried()
    {
        // D26 / G-17: the service may have acted on it; an operator checks before anything is sent again.
        _realService.Responder = _ => (200, "<html>Welcome</html>");
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        await CarryAcrossAsync(_corp, _dmz, messageId);

        var row = await WaitForAsync(_dmz, messageId, r => r.ServiceStatus == InboxServiceStatus.Unknown);
        Assert.Equal(200, row.ServiceHttpStatus);
        Assert.Contains("may have been processed", row.ServiceComment);
        Assert.Single(_realService.Requests);
    }

    [Fact]
    public async Task A_message_with_no_receiver_target_is_not_delivered_and_waits_for_an_operator()
    {
        // D25: it surely never reached a service, so an operator may resend it once the target is configured.
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        string otherRoot = GatewayHost.NewRoot();
        await using (var dmzWithoutTarget = GatewayHost.Start(BridgeSide.Dmz, otherRoot,
                         new Dictionary<string, string?> { ["Gateway:Receiver:DefaultBaseUrl"] = "" },
                         receiverHandler: _realService.CreateHandler))
        {
            await CarryAcrossAsync(_corp, dmzWithoutTarget, messageId);

            var row = await WaitForAsync(dmzWithoutTarget, messageId, r => r.ServiceStatus == InboxServiceStatus.NotDelivered);
            Assert.Contains("No Receiver target", row.ServiceComment);
            Assert.Null(row.ServiceHttpStatus);
            Assert.Equal(InboxLightStatus.Received, row.LightStatus); // it crossed the light fine: a service-end problem
        }
        GatewayHost.DeleteRoot(otherRoot);
        Assert.Empty(_realService.Requests);
    }

    [Fact]
    public async Task A_throttled_service_is_retried_until_it_accepts()
    {
        // HTTP 429: not processed (D9), so posting it again is safe.
        int calls = 0;
        _realService.Responder = _ => Interlocked.Increment(ref calls) == 1
            ? (429, "<html>Too Many Requests</html>")
            : (200, FakeSoapService.FmsReply("SendToFMS", 0));

        var (messageId, _) = await CallCorpAsync("LIFT_CAUTION.TXT");
        await CarryAcrossAsync(_corp, _dmz, messageId);

        var row = await WaitForAsync(_dmz, messageId, r => r.ServiceStatus == InboxServiceStatus.Done);
        Assert.Equal(2, row.Attempts);
        Assert.Equal(200, row.ServiceHttpStatus); // the last answer, not the 429 before it
        Assert.Equal(2, _realService.Requests.Count);
    }

    [Fact]
    public async Task A_dmz_call_to_a_corporate_service_reaches_it_byte_for_byte()
    {
        _realService.Responder = _ => (200, FakeSoapService.FmsReply("CreateCard", 0));
        var endpoint = FmsEndpoint.FMS2FC;
        byte[] request = SoapCalls.Build(endpoint, "CreateCard", "<MESSAGE TYPE=\"CARD_CREATE\" MSG_ID=\"1\"><MSG_DATA /></MESSAGE>");
        using var dmzClient = _dmz.CreateClient();
        var (response, reply) = await SoapCalls.PostAsync(dmzClient, endpoint, "CreateCard", request);
        Assert.Equal(1596, SoapCalls.ReturnCode(SoapCalls.Result(reply))); // held (D60); no Reply carried back here
        var messageId = Guid.Parse(response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());

        await CarryAcrossAsync(_dmz, _corp, messageId);

        var row = await WaitForAsync(_corp, messageId, r => r.ServiceStatus == InboxServiceStatus.Done);
        Assert.Equal("RETURN_CODE=0", row.DownstreamResult);
        var received = Assert.Single(_realService.Requests);
        Assert.Equal(endpoint.Path, received.Path);
        Assert.Equal("\"http://tempuri.org/IFMS2RRFCInterface/CreateCard\"", received.SoapAction);
        Assert.Equal(request, received.Body);
    }

    [Fact]
    public async Task A_message_carried_to_the_wrong_side_is_rejected_not_delivered()
    {
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        await CarryAcrossAsync(_corp, _corp, messageId); // Corp -> Corp: wrong direction

        var row = await WaitForAsync(_corp, messageId, r => r.LightStatus == InboxLightStatus.Rejected);
        Assert.Contains("direction", row.LightComment, StringComparison.OrdinalIgnoreCase);
        Assert.Null(row.ServiceComment); // a light problem, not a service one
        Assert.Empty(_realService.Requests);
    }

    [Fact]
    public async Task Every_message_carries_the_sender_catalogue_and_counter_run()
    {
        var (first, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        var (second, _) = await CallCorpAsync("LIFT_CAUTION.TXT");
        var outbox = _corp.Get<IOutboxRepository>();
        var rows = new[] { (await outbox.FindAsync(first, CancellationToken.None))!, (await outbox.FindAsync(second, CancellationToken.None))! };
        var headers = rows.Select(r => MessageSerializer.PeekHeader(r.MessageBytes)).ToArray();

        Assert.All(headers, h => Assert.Equal(_corp.Get<RouteTable>().CatalogFingerprint, h.CatalogFingerprint));
        Assert.Equal(_corp.Get<RouteTable>().CatalogFingerprint, _dmz.Get<RouteTable>().CatalogFingerprint); // same routes.json
        Assert.NotEqual(Guid.Empty, headers[0].SequenceRunId);
        Assert.Equal(headers[0].SequenceRunId, headers[1].SequenceRunId);                     // one run of the counter
        Assert.Equal(new long[] { 1, 2 }, headers.Select(h => h.Sequence));
        Assert.All(rows, r => Assert.Equal(headers[0].SequenceRunId, r.SequenceRunId));
    }

    [Fact]
    public async Task Health_shows_a_message_that_never_arrived_until_an_operator_acknowledges_it()
    {
        var (lost, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");   // sequence 1: never carried across
        var (carried, _) = await CallCorpAsync("LIFT_CAUTION.TXT");      // sequence 2
        string otherRoot = GatewayHost.NewRoot();
        await using (var dmz = GatewayHost.Start(BridgeSide.Dmz, otherRoot,
                         new Dictionary<string, string?> { ["Gateway:GapGraceMinutes"] = "0" }, receiverHandler: _realService.CreateHandler))
        {
            await CarryAcrossAsync(_corp, dmz, carried);
            await WaitForAsync(dmz, carried, r => r.ServiceStatus == InboxServiceStatus.Done);
            using var client = dmz.CreateClient();

            var gap = Assert.Single(await dmz.Get<SequenceGapMonitor>().CheckAsync(CancellationToken.None));
            Assert.Equal((1L, 1L), (gap.FromSequence, gap.ToSequence));
            string health = await client.GetStringAsync("/health");
            Assert.Contains("\"healthy\":false", health);
            Assert.Contains("\"missingMessages\":1", health);
            Assert.Contains($"\"catalogFingerprint\":\"{dmz.Get<RouteTable>().CatalogFingerprint}\"", health);

            var runId = MessageSerializer.PeekHeader((await _corp.Get<IOutboxRepository>().FindAsync(lost, CancellationToken.None))!.MessageBytes).SequenceRunId;
            Assert.True(await dmz.Get<IInboxRepository>().AcknowledgeGapAsync(Direction.CorpToDmz, runId, 1, 1, "operator", "test: written off", CancellationToken.None));
            Assert.Empty(await dmz.Get<SequenceGapMonitor>().CheckAsync(CancellationToken.None));
            Assert.Contains("\"missingMessages\":0", await client.GetStringAsync("/health"));
        }
        GatewayHost.DeleteRoot(otherRoot);
    }

    [Fact]
    public async Task A_message_from_a_gateway_with_another_route_catalogue_is_rejected_not_posted()
    {
        // G-15 / D31: both sides must run the same routes.json. Here the DMZ copy differs in one reply value.
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        string otherRoot = GatewayHost.NewRoot();
        await using (var dmzWithOtherCatalogue = GatewayHost.Start(BridgeSide.Dmz, otherRoot,
                         new Dictionary<string, string?> { ["Routing:ReplyProfiles:FmsResponse:Busy"] = "<RESPONSE>changed</RESPONSE>" },
                         receiverHandler: _realService.CreateHandler))
        {
            await CarryAcrossAsync(_corp, dmzWithOtherCatalogue, messageId);

            var row = await WaitForAsync(dmzWithOtherCatalogue, messageId, r => r.LightStatus == InboxLightStatus.Rejected);
            Assert.Contains("route catalogue differs", row.LightComment);
        }
        GatewayHost.DeleteRoot(otherRoot);
        Assert.Empty(_realService.Requests);
    }

    // ---------------------------------------------------------------- old messages by number (step 17, D84, G-13)

    /// <summary>A copy of a Corp Outbox message with its header changed, as the bytes the QR receiver would store.</summary>
    private (MessageHeader Header, byte[] Bytes) Rewrite(OutboxMessage row, Func<MessageHeader, MessageHeader> change)
    {
        var serializer = _corp.Get<MessageSerializer>();
        var (header, body) = serializer.Deserialize(row.MessageBytes);
        var changed = change(header);
        return (changed, serializer.Serialize(changed, body));
    }

    [Fact]
    public async Task A_message_reusing_a_number_another_message_already_has_is_rejected_not_posted()
    {
        // D84 (1): a restored qrbridge.db, or a forged copy, sends another message under number 1 of the same counter run.
        var (first, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");   // number 1
        var (second, _) = await CallCorpAsync("LIFT_CAUTION.TXT");        // number 2
        await CarryAcrossAsync(_corp, _dmz, first);
        await WaitForAsync(_dmz, first, r => r.ServiceStatus == InboxServiceStatus.Done);

        var row = await _corp.Get<IOutboxRepository>().FindAsync(second, CancellationToken.None);
        var (reused, bytes) = Rewrite(row!, h => h with { Sequence = 1 });
        Assert.True(await _dmz.Get<IInboxRepository>().AddMessageAsync(reused, bytes, CancellationToken.None));
        _dmz.Get<BridgeSignals>().Inbox.Set();

        var rejected = await WaitForAsync(_dmz, second, r => r.LightStatus == InboxLightStatus.Rejected);
        Assert.Contains("already used", rejected.LightComment);
        Assert.Single(_realService.Requests); // only the first one was posted
        Assert.Equal(InboxServiceStatus.Done, (await _dmz.Get<IInboxRepository>().FindAsync(first, CancellationToken.None))!.ServiceStatus);
    }

    [Fact]
    public async Task An_old_message_replayed_after_its_row_was_archived_is_rejected_although_its_date_is_recent()
    {
        // D84 (2): the date window alone lets a replay through for 7 days (and not at all with a wrong clock); once the
        // operator has archived the row, its MessageId no longer stops it either. The counter run's watermark does.
        var (first, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        await CarryAcrossAsync(_corp, _dmz, first);
        await WaitForAsync(_dmz, first, r => r.ServiceStatus == InboxServiceStatus.Done);
        await _dmz.Get<SequenceGapMonitor>().CheckAsync(CancellationToken.None); // the maintenance run: number 1 has arrived

        await using (var db = await _dmz.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync())
            await db.Inbox.Where(m => m.MessageId == first).ExecuteDeleteAsync(); // archived by an operator

        await CarryAcrossAsync(_corp, _dmz, first); // the same QR session shown again
        var rejected = await WaitForAsync(_dmz, first, r => r.LightStatus == InboxLightStatus.Rejected);
        Assert.Contains("old message", rejected.LightComment);
        Assert.Single(_realService.Requests);
    }

    [Fact]
    public async Task Messages_that_arrive_out_of_order_or_are_retried_are_still_delivered()
    {
        // D84 must not refuse what is normal since steps 11 and 14: a lower number arriving later (answers first,
        // re-airs), and a request posted again after a "surely not sent" failure while the watermark moved past it.
        int calls = 0;
        _realService.Responder = _ => Interlocked.Increment(ref calls) == 2
            ? (429, "<html>Too Many Requests</html>")
            : (200, FakeSoapService.FmsReply("SendToFMS", 0));
        var (first, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");   // number 1
        var (second, _) = await CallCorpAsync("LIFT_CAUTION.TXT");        // number 2
        string otherRoot = GatewayHost.NewRoot();
        await using (var dmz = GatewayHost.Start(BridgeSide.Dmz, otherRoot,
                         new Dictionary<string, string?> { ["Gateway:BackoffBaseSeconds"] = "3" }, receiverHandler: _realService.CreateHandler))
        {
            await CarryAcrossAsync(_corp, dmz, second);
            await WaitForAsync(dmz, second, r => r.ServiceStatus == InboxServiceStatus.Done);
            await dmz.Get<SequenceGapMonitor>().CheckAsync(CancellationToken.None);

            await CarryAcrossAsync(_corp, dmz, first); // arrives after number 2; its first POST gets 429 → Retrying
            await WaitForAsync(dmz, first, r => r.ServiceStatus == InboxServiceStatus.Retrying);
            await dmz.Get<SequenceGapMonitor>().CheckAsync(CancellationToken.None); // numbers 1–2 have all arrived now
            Assert.Equal(InboxServiceStatus.Retrying, (await dmz.Get<IInboxRepository>().FindAsync(first, CancellationToken.None))!.ServiceStatus);

            var delivered = await WaitForAsync(dmz, first, r => r.ServiceStatus == InboxServiceStatus.Done || r.LightStatus == InboxLightStatus.Rejected);
            Assert.Equal(InboxLightStatus.Received, delivered.LightStatus);
            Assert.Equal(InboxServiceStatus.Done, delivered.ServiceStatus);
        }
        GatewayHost.DeleteRoot(otherRoot);
        Assert.Equal(3, _realService.Requests.Count);
    }

    [Fact]
    public async Task A_message_type_the_receiving_side_does_not_bridge_is_rejected_not_posted()
    {
        // Step 7: the mode can be set per MESSAGE TYPE inside an operation; the receiving side checks the type's mode,
        // not only the operation's. Here REQUEST_FOR_PERMIT is not bridged on the DMZ side.
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        string otherRoot = GatewayHost.NewRoot();
        await using (var dmz = GatewayHost.Start(BridgeSide.Dmz, otherRoot,
                         new Dictionary<string, string?> { ["Routing:Services:0:Operations:SendToFMS:Types:REQUEST_FOR_PERMIT:Mode"] = "Unavailable" },
                         receiverHandler: _realService.CreateHandler))
        {
            // Same catalogue on both sides, so only the type's mode can stop it.
            var row = await _corp.Get<IOutboxRepository>().FindAsync(messageId, CancellationToken.None);
            var serializer = _corp.Get<MessageSerializer>();
            var (header, body) = serializer.Deserialize(row!.MessageBytes);
            var sameCatalogue = header with { CatalogFingerprint = dmz.Get<RouteTable>().CatalogFingerprint };
            Assert.True(await dmz.Get<IInboxRepository>().AddMessageAsync(sameCatalogue, serializer.Serialize(sameCatalogue, body), CancellationToken.None));
            dmz.Get<BridgeSignals>().Inbox.Set();

            var rejected = await WaitForAsync(dmz, messageId, r => r.LightStatus == InboxLightStatus.Rejected);
            Assert.Contains("not a bridged", rejected.LightComment);
        }
        GatewayHost.DeleteRoot(otherRoot);
        Assert.Empty(_realService.Requests);
    }

    [Fact]
    public async Task A_reply_disguised_as_a_request_row_is_rejected_not_posted()
    {
        // The Inbox columns say Request, the checked message bytes say Reply: never posted to a service.
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        var request = await _corp.Get<IOutboxRepository>().FindAsync(messageId, CancellationToken.None);
        var (header, body) = _corp.Get<MessageSerializer>().Deserialize(request!.MessageBytes);
        var replyHeader = header with { MessageId = Guid.NewGuid(), Kind = MessageKind.Reply, CorrelationId = messageId, Outcome = ServiceOutcome.Done };
        byte[] replyBytes = _corp.Get<MessageSerializer>().Serialize(replyHeader, body);

        await _dmz.Get<IInboxRepository>().AddMessageAsync(replyHeader with { Kind = MessageKind.Request, CorrelationId = null },
                                                          replyBytes, CancellationToken.None);
        _dmz.Get<BridgeSignals>().Inbox.Set();

        var row = await WaitForAsync(_dmz, replyHeader.MessageId, r => r.LightStatus == InboxLightStatus.Rejected);
        Assert.Contains("Kind", row.LightComment);
        Assert.Empty(_realService.Requests);
    }

    [Fact]
    public async Task A_row_whose_priority_column_disagrees_with_its_message_is_rejected_not_posted()
    {
        // Step 14 copies Priority into the Inbox column so each delivery loop claims its own class; a row whose column
        // was changed (e.g. to jump the queue) must not be posted under the wrong class.
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt"); // High: a permit
        var row = await _corp.Get<IOutboxRepository>().FindAsync(messageId, CancellationToken.None);
        var header = MessageSerializer.PeekHeader(row!.MessageBytes);
        Assert.Equal(MessagePriority.High, header.Priority);

        await _dmz.Get<IInboxRepository>().AddMessageAsync(header with { Priority = MessagePriority.Low }, row.MessageBytes, CancellationToken.None);
        _dmz.Get<BridgeSignals>().Inbox.Set();

        var rejected = await WaitForAsync(_dmz, messageId, r => r.LightStatus == InboxLightStatus.Rejected);
        Assert.Contains("do not match the Inbox row", rejected.LightComment);
        Assert.Empty(_realService.Requests);
    }

    [Fact]
    public async Task Corrupted_message_bytes_are_rejected_not_delivered()
    {
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        var row = await _corp.Get<IOutboxRepository>().FindAsync(messageId, CancellationToken.None);
        byte[] corrupted = row!.MessageBytes.ToArray();
        corrupted[^1] ^= 0x01;

        await _dmz.Get<IInboxRepository>().AddMessageAsync(MessageSerializer.PeekHeader(corrupted), corrupted, CancellationToken.None);
        _dmz.Get<BridgeSignals>().Inbox.Set();

        var rejected = await WaitForAsync(_dmz, messageId, r => r.LightStatus == InboxLightStatus.Rejected);
        Assert.Contains("checksum", rejected.LightComment, StringComparison.OrdinalIgnoreCase);
        Assert.Empty(_realService.Requests);
    }
}
