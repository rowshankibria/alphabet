using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;

namespace QrBridge.Tests;

/// <summary>Real SQLite files in a temp folder: exercises EF mapping, CHECK constraints and the queue operations.</summary>
public sealed class RepositoryTests : IAsyncLifetime
{
    private readonly string _folder = Path.Combine(Path.GetTempPath(), "qrbridge-tests-" + Guid.NewGuid().ToString("N"));
    private ServiceProvider _sp = null!;
    private long _nextSequence;

    public async Task InitializeAsync()
    {
        var services = new ServiceCollection();
        services.AddBridgeData(new GatewayDatabaseOptions { DataFolder = _folder });
        _sp = services.BuildServiceProvider();
        await DatabaseInitializer.InitializeAsync(_sp, NullLogger.Instance);
    }

    public async Task DisposeAsync()
    {
        await _sp.DisposeAsync();
        Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
        try { Directory.Delete(_folder, recursive: true); } catch { /* best effort */ }
    }

    private async Task<OutboxMessage> InsertOutboxAsync(Guid? id = null, MessageKind kind = MessageKind.Request, DateTime? expiresUtc = null,
                                                        MessagePriority priority = MessagePriority.Normal)
    {
        var factory = _sp.GetRequiredService<IDbContextFactory<BridgeDbContext>>();
        await using var db = await factory.CreateDbContextAsync();
        var row = new OutboxMessage
        {
            MessageId = id ?? Guid.NewGuid(),
            Direction = Direction.CorpToDmz,
            ServiceName = "FC2FMS",
            Operation = "SendToFMS",
            BusinessType = "RETURN_ORDER",
            Sequence = ++_nextSequence,
            PayloadFormat = PayloadFormat.RawSoap,
            Kind = kind,
            CorrelationId = kind == MessageKind.Request ? null : Guid.NewGuid(),
            ExpiresUtc = expiresUtc,
            Priority = kind == MessageKind.Request ? priority : MessagePriority.Answer,
            PayloadSize = 3,
            MessageBytes = [1, 2, 3],
            MessageHash = Hashing.Sha256Hex([1, 2, 3]),
            LightStatus = OutboxLightStatus.Pending,
            CreatedUtc = DateTime.UtcNow,
        };
        db.Outbox.Add(row);
        await db.SaveChangesAsync();
        return row;
    }

    private static MessageHeader Header(string businessType = "RETURN_ORDER") => new()
    {
        MessageId = Guid.NewGuid(), Direction = Direction.CorpToDmz,
        ServiceName = "SSO2FMS", Operation = "SendToFMS", BusinessType = businessType, Sequence = 7,
        Path = "/FMS_SSO2FMSInterface/SSO2FMSInterface.svc", ContentType = "text/xml; charset=utf-8",
    };

    [Fact]
    public async Task Sequence_counters_are_seeded()
    {
        var factory = _sp.GetRequiredService<IDbContextFactory<BridgeDbContext>>();
        await using var db = await factory.CreateDbContextAsync();
        Assert.Equal(2, await db.SequenceCounters.CountAsync());
    }

    [Fact]
    public async Task Every_connection_is_on_disk_before_a_commit_returns()
    {
        // G-14: synchronous=FULL, so a row the caller was told "accepted" survives a power cut (WAL + NORMAL may lose it).
        await using var db = await _sp.GetRequiredService<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        await db.Database.OpenConnectionAsync();
        await using var cmd = db.Database.GetDbConnection().CreateCommand();
        cmd.CommandText = "PRAGMA synchronous;";
        Assert.Equal(2L, Convert.ToInt64(await cmd.ExecuteScalarAsync())); // 2 = FULL
        cmd.CommandText = "PRAGMA journal_mode;";
        Assert.Equal("wal", Convert.ToString(await cmd.ExecuteScalarAsync()));
    }

    [Fact]
    public async Task One_database_file_holds_every_bridge_table()
    {
        Assert.Equal([GatewayDatabaseOptions.DatabaseFileName], Directory.GetFiles(_folder, "*.db").Select(Path.GetFileName));

        await using var db = await _sp.GetRequiredService<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        var tables = await db.Database.SqlQueryRaw<string>(
            "SELECT name AS Value FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").ToListAsync();
        // The bridge tables and the QR Receiver's journal, plus EF's migration bookkeeping (since 27 Nov 2026 the schema comes from migrations).
        Assert.Equal(["AcknowledgedGap", "Heartbeat", "Inbox", "JournalArchive", "JournalTransfer", "JournalWatermark", "Outbox",
                      "SequenceCounter", "SequenceWatermark", "__EFMigrationsHistory", "__EFMigrationsLock"], tables.Order(StringComparer.Ordinal));
    }

    // A former send.db or received.db may hold accepted messages that were never carried or delivered: never start empty beside it.
    [Theory]
    [InlineData("send.db")]
    [InlineData("received.db")]
    public async Task The_database_is_not_created_while_a_former_database_is_in_the_data_folder(string former)
    {
        string folder = Path.Combine(Path.GetTempPath(), "qrbridge-tests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        await File.WriteAllBytesAsync(Path.Combine(folder, former), [1]);
        var services = new ServiceCollection();
        services.AddBridgeData(new GatewayDatabaseOptions { DataFolder = folder });
        await using var sp = services.BuildServiceProvider();
        try
        {
            var ex = await Assert.ThrowsAsync<InvalidOperationException>(() => DatabaseInitializer.InitializeAsync(sp, NullLogger.Instance));
            Assert.Contains(former, ex.Message);
            Assert.False(File.Exists(Path.Combine(folder, GatewayDatabaseOptions.DatabaseFileName)));
        }
        finally
        {
            Directory.Delete(folder, recursive: true);
        }
    }

    [Fact]
    public async Task Claim_gives_each_row_to_exactly_one_claimer()
    {
        for (int i = 0; i < 20; i++) await InsertOutboxAsync();
        var store = _sp.GetRequiredService<IOutboxRepository>();

        var claims = await Task.WhenAll(Enumerable.Range(0, 40).Select(_ => store.ClaimNextAsync(CancellationToken.None)));
        var ids = claims.Where(c => c is not null).Select(c => c!.MessageId).ToList();

        Assert.Equal(20, ids.Count);
        Assert.Equal(20, ids.Distinct().Count());
        Assert.All(claims.Where(c => c is not null), c => Assert.Equal(OutboxLightStatus.Sending, c!.LightStatus));
    }

    [Fact]
    public async Task A_receipt_marks_the_row_received_and_release_requeues()
    {
        var store = _sp.GetRequiredService<IOutboxRepository>();
        var a = await InsertOutboxAsync();
        await InsertOutboxAsync();
        await store.ClaimNextAsync(CancellationToken.None);
        var cb = await store.ClaimNextAsync(CancellationToken.None);

        Assert.Equal(1, await store.MarkReceivedAsync([a.MessageId], CancellationToken.None));
        await store.ReleaseAsync(cb!.MessageId, "no receipt after 120 s", maxAttempts: 5, TimeSpan.Zero, CancellationToken.None);

        var counts = await store.GetCountsAsync(CancellationToken.None);
        Assert.Equal(1, counts.Light[OutboxLightStatus.Received]);
        Assert.Equal(1, counts.Light[OutboxLightStatus.Pending]);
        Assert.Equal(2, counts.Service[OutboxServiceStatus.Waiting]); // the light moved; the service group did not
        Assert.Equal("no receipt after 120 s", (await store.FindAsync(cb.MessageId, CancellationToken.None))!.LightComment);
        Assert.NotNull((await store.FindAsync(a.MessageId, CancellationToken.None))!.LightUpdatedUtc);
    }

    // ---------------------------------------------------------------- re-airing (step 11, D65–D67)

    private async Task AirAsync(IOutboxRepository store, Guid messageId)
    {
        Assert.Equal(messageId, (await store.ClaimNextAsync(CancellationToken.None))?.MessageId);
        Assert.Equal(1, await store.MarkAiredAsync([messageId], CancellationToken.None));
    }

    [Fact]
    public async Task An_aired_row_without_a_receipt_is_aired_again_until_its_tries_run_out_then_failed()
    {
        var store = _sp.GetRequiredService<IOutboxRepository>();
        var row = await InsertOutboxAsync();

        foreach (string expected in new[] { "Aired once, no receipt after 0 s: aired again.", "Aired 2 times, no receipt after 0 s: aired again." })
        {
            await AirAsync(store, row.MessageId);
            var changed = Assert.Single(await store.ReairUnconfirmedAsync(TimeSpan.Zero, maxAirAttempts: 3, CancellationToken.None));
            Assert.Equal(OutboxLightStatus.Pending, changed.NewStatus);
            var queued = await store.FindAsync(row.MessageId, CancellationToken.None);
            Assert.Equal(OutboxLightStatus.Pending, queued!.LightStatus);
            Assert.Equal(expected, queued.LightComment);
            Assert.Null(queued.NextAttemptUtc); // the QR sender takes it next (lowest Sequence)
        }

        await AirAsync(store, row.MessageId); // the third and last air
        var failed = Assert.Single(await store.ReairUnconfirmedAsync(TimeSpan.Zero, maxAirAttempts: 3, CancellationToken.None));
        Assert.Equal(OutboxLightStatus.Failed, failed.NewStatus);
        Assert.Equal(3, failed.Airs);
        var stored = await store.FindAsync(row.MessageId, CancellationToken.None);
        Assert.Equal(OutboxLightStatus.Failed, stored!.LightStatus);
        Assert.Equal("Aired 3 times, no receipt after 0 s: check the screen, the camera and the far QR Receiver, then requeue.", stored.LightComment);
        Assert.Equal(OutboxServiceStatus.Waiting, stored.ServiceStatus); // a light problem only
        Assert.Empty(await store.ReairUnconfirmedAsync(TimeSpan.Zero, 3, CancellationToken.None)); // Failed stays Failed

        // A Receipt that comes after all still confirms it.
        Assert.Equal(1, await store.MarkReceivedAsync([row.MessageId], CancellationToken.None));
        Assert.Null((await store.FindAsync(row.MessageId, CancellationToken.None))!.LightComment);
    }

    [Fact]
    public async Task Only_rows_aired_longer_than_the_receipt_timeout_ago_and_still_unconfirmed_are_aired_again()
    {
        var store = _sp.GetRequiredService<IOutboxRepository>();
        var received = await InsertOutboxAsync();
        var aired = await InsertOutboxAsync();
        var onScreen = await InsertOutboxAsync();
        var waiting = await InsertOutboxAsync();
        await AirAsync(store, received.MessageId);
        await store.MarkReceivedAsync([received.MessageId], CancellationToken.None);
        await AirAsync(store, aired.MessageId);
        await store.ClaimNextAsync(CancellationToken.None); // onScreen: Sending

        Assert.Empty(await store.ReairUnconfirmedAsync(TimeSpan.FromMinutes(2), 3, CancellationToken.None)); // too early

        var changed = Assert.Single(await store.ReairUnconfirmedAsync(TimeSpan.Zero, 3, CancellationToken.None));
        Assert.Equal(aired.MessageId, changed.MessageId);
        Assert.Equal(OutboxLightStatus.Received, (await store.FindAsync(received.MessageId, CancellationToken.None))!.LightStatus);
        Assert.Equal(OutboxLightStatus.Sending, (await store.FindAsync(onScreen.MessageId, CancellationToken.None))!.LightStatus);
        Assert.Equal(OutboxLightStatus.Pending, (await store.FindAsync(waiting.MessageId, CancellationToken.None))!.LightStatus);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task A_row_past_its_expiry_is_never_aired_again(bool expired)
    {
        var store = _sp.GetRequiredService<IOutboxRepository>();
        var expires = DateTime.UtcNow.AddMinutes(expired ? -1 : 10);
        var row = await InsertOutboxAsync(expiresUtc: expires);
        await AirAsync(store, row.MessageId); // the first air: tries are left

        var changed = Assert.Single(await store.ReairUnconfirmedAsync(TimeSpan.Zero, 3, CancellationToken.None));

        var stored = await store.FindAsync(row.MessageId, CancellationToken.None);
        Assert.Equal(expired ? OutboxLightStatus.Failed : OutboxLightStatus.Pending, stored!.LightStatus);
        Assert.Equal(stored.LightStatus, changed.NewStatus);
        if (expired)
            Assert.Equal(string.Create(System.Globalization.CultureInfo.InvariantCulture,
                $"Expired at {stored.ExpiresUtc:MM/dd/yyyy hh:mm:ss tt} UTC before the far side confirmed it (aired once): not aired again."),
                stored.LightComment); // US format, as the UI shows times
    }

    [Fact]
    public async Task A_receipt_row_is_done_once_aired_but_a_reply_waits_for_its_receipt()
    {
        var store = _sp.GetRequiredService<IOutboxRepository>();
        var receipt = await InsertOutboxAsync(kind: MessageKind.Receipt);
        var reply = await InsertOutboxAsync(kind: MessageKind.Reply);
        await AirAsync(store, receipt.MessageId);
        await AirAsync(store, reply.MessageId);

        var changed = Assert.Single(await store.ReairUnconfirmedAsync(TimeSpan.Zero, 3, CancellationToken.None));

        Assert.Equal(reply.MessageId, changed.MessageId); // a Reply gets a Receipt (D44): aired again
        Assert.Equal(OutboxLightStatus.Aired, (await store.FindAsync(receipt.MessageId, CancellationToken.None))!.LightStatus);
        await store.MarkReceivedAsync([reply.MessageId], CancellationToken.None);
        Assert.Null((await store.GetCountsAsync(CancellationToken.None)).OldestUndeliveredUtc); // the aired Receipt is not "unconfirmed"
    }

    [Fact]
    public async Task Duplicate_message_id_is_rejected_by_primary_key()
    {
        var id = Guid.NewGuid();
        await InsertOutboxAsync(id);
        await Assert.ThrowsAsync<DbUpdateException>(() => InsertOutboxAsync(id));
    }

    [Fact]
    public async Task Aired_is_set_only_for_rows_on_screen_and_never_undoes_a_receipt()
    {
        var store = _sp.GetRequiredService<IOutboxRepository>();
        var received = await InsertOutboxAsync();
        var onScreen = await InsertOutboxAsync();
        var waiting = await InsertOutboxAsync();
        await store.ClaimNextAsync(CancellationToken.None);
        await store.ClaimNextAsync(CancellationToken.None);
        await store.MarkReceivedAsync([received.MessageId], CancellationToken.None); // the receipt overtook the sender

        Assert.Equal(1, await store.MarkAiredAsync([received.MessageId, onScreen.MessageId, waiting.MessageId], CancellationToken.None));

        Assert.Equal(OutboxLightStatus.Received, (await store.FindAsync(received.MessageId, CancellationToken.None))!.LightStatus);
        Assert.Equal(OutboxLightStatus.Aired, (await store.FindAsync(onScreen.MessageId, CancellationToken.None))!.LightStatus);
        Assert.Equal(OutboxLightStatus.Pending, (await store.FindAsync(waiting.MessageId, CancellationToken.None))!.LightStatus);
    }

    [Fact]
    public async Task The_first_answer_is_stored_byte_for_byte_and_implies_a_receipt()
    {
        var store = _sp.GetRequiredService<IOutboxRepository>();
        var request = await InsertOutboxAsync();
        byte[] reply = [0x3C, 0x73, 0x3A, 0xFF, 0x00]; // not reinterpreted: handed to the caller unchanged

        Assert.True(await store.MarkAnsweredAsync(request.MessageId, OutboxServiceStatus.Answered, 200, "RETURN_CODE=0",
            "text/xml; charset=utf-8", reply, DateTime.UtcNow, CancellationToken.None));
        // An Answered request never changes again, even for a newer Reply (D59).
        Assert.False(await store.MarkAnsweredAsync(request.MessageId, OutboxServiceStatus.Refused, 500, "late",
            "text/html", [1], DateTime.UtcNow.AddMinutes(1), CancellationToken.None));

        var row = await store.FindAsync(request.MessageId, CancellationToken.None);
        Assert.Equal(OutboxServiceStatus.Answered, row!.ServiceStatus);
        Assert.Equal(200, row.ServiceHttpStatus);
        Assert.Equal("RETURN_CODE=0", row.ServiceComment);
        Assert.Equal("text/xml; charset=utf-8", row.ReplyContentType);
        Assert.Equal(reply, row.ReplyBody);
        Assert.Equal(OutboxLightStatus.Received, row.LightStatus); // a Reply implies a Receipt
        Assert.NotNull(row.LightUpdatedUtc);
        Assert.NotNull(row.ServiceUpdatedUtc);
    }

    [Fact]
    public async Task An_answer_is_not_stored_for_a_reply_row_or_back_to_waiting_or_over_the_size_cap()
    {
        var store = _sp.GetRequiredService<IOutboxRepository>();
        var replyRow = await InsertOutboxAsync(kind: MessageKind.Reply);
        var request = await InsertOutboxAsync();

        var now = DateTime.UtcNow;
        Assert.False(await store.MarkAnsweredAsync(replyRow.MessageId, OutboxServiceStatus.Answered, 200, "x", null, null, now, CancellationToken.None));
        Assert.False(await store.MarkAnsweredAsync(Guid.NewGuid(), OutboxServiceStatus.Answered, 200, "x", null, null, now, CancellationToken.None));
        await Assert.ThrowsAsync<ArgumentException>(() => store.MarkAnsweredAsync(request.MessageId, OutboxServiceStatus.Waiting,
            null, "x", null, null, now, CancellationToken.None));
        await Assert.ThrowsAsync<ArgumentException>(() => store.MarkAnsweredAsync(request.MessageId, OutboxServiceStatus.Answered,
            200, "x", "text/xml", new byte[new GatewayDatabaseOptions().MaxPayloadBytes + 1], now, CancellationToken.None));

        Assert.Equal(OutboxServiceStatus.Waiting, (await store.FindAsync(request.MessageId, CancellationToken.None))!.ServiceStatus);
    }

    [Fact]
    public async Task Receipts_and_replies_are_stored_with_their_header_fields_but_never_claimed_for_delivery()
    {
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var reply = Header() with { MessageId = Guid.NewGuid(), Kind = MessageKind.Reply, CorrelationId = Guid.NewGuid() };
        var receipt = Header() with { MessageId = Guid.NewGuid(), Kind = MessageKind.Receipt, Sequence = 1 };
        var expires = DateTime.UtcNow.AddMinutes(10);
        var request = Header() with
        {
            MessageId = Guid.NewGuid(), Sequence = 99, ContentFingerprint = new string('a', 64), ExpiresUtc = expires,
        };
        foreach (var h in new[] { reply, receipt, request })
            await inbox.AddMessageAsync(h, [1], CancellationToken.None);

        var stored = await inbox.FindAsync(reply.MessageId, CancellationToken.None);
        Assert.Equal(MessageKind.Reply, stored!.Kind);
        Assert.Equal(reply.CorrelationId, stored.CorrelationId);
        var storedRequest = await inbox.FindAsync(request.MessageId, CancellationToken.None);
        Assert.Equal(new string('a', 64), storedRequest!.ContentFingerprint);
        Assert.Equal(expires, storedRequest.ExpiresUtc);

        // Lower sequences, but not Requests: only the Request is ever claimed for posting.
        Assert.Equal(request.MessageId, (await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None))!.MessageId);
        Assert.Null(await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None));
    }

    [Fact]
    public async Task Inbox_insert_is_idempotent_and_the_worker_can_open_what_the_receiver_stored()
    {
        var serializer = new MessageSerializer();
        var header = Header();
        byte[] messageBytes = serializer.Serialize(header, RandomNumberGenerator.GetBytes(5000));

        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var peeked = MessageSerializer.PeekHeader(messageBytes);
        Assert.True(await inbox.AddMessageAsync(peeked, messageBytes, CancellationToken.None));
        Assert.False(await inbox.AddMessageAsync(peeked, messageBytes, CancellationToken.None)); // duplicate ignored

        var row = await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None);
        Assert.NotNull(row);
        Assert.Equal(InboxLightStatus.Received, row!.LightStatus);
        Assert.Equal(InboxServiceStatus.Delivering, row.ServiceStatus);
        Assert.Equal(messageBytes, row.MessageBytes);
        Assert.Equal(7, row.Sequence);
        Assert.Equal("RETURN_ORDER", row.BusinessType);

        var (opened, _) = serializer.Deserialize(row.MessageBytes);
        Assert.Equal(header.MessageId, opened.MessageId);

        await inbox.MarkDoneAsync(row.MessageId, 200, "RETURN_CODE=0", "RETURN_CODE=0", CancellationToken.None);
        var done = await inbox.FindAsync(header.MessageId, CancellationToken.None);
        Assert.Equal(InboxServiceStatus.Done, done!.ServiceStatus);
        Assert.Equal(200, done.ServiceHttpStatus);
        Assert.Equal("RETURN_CODE=0", done.DownstreamResult);
        Assert.True(done.Verified);
        // Layer 3a (D57): a request the service accepted can never be requeued, so it is never posted a second time.
        Assert.Equal(0, await inbox.RequeueAsync(header.MessageId, CancellationToken.None));
    }

    [Fact]
    public async Task Refused_messages_keep_the_service_answer_and_wait_for_an_operator()
    {
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var header = Header();
        await inbox.AddMessageAsync(header, [1, 2, 3], CancellationToken.None);
        var row = await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None);

        await inbox.MarkRefusedAsync(row!.MessageId, 200, "The service refused the message", "RETURN_CODE=1501; ERROR_MESSAGE=Invalid card", CancellationToken.None);

        var refused = await inbox.FindAsync(header.MessageId, CancellationToken.None);
        Assert.Equal(InboxServiceStatus.Refused, refused!.ServiceStatus);
        Assert.Equal(200, refused.ServiceHttpStatus);
        Assert.Contains("1501", refused.DownstreamResult);
        Assert.Null(await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None)); // never retried on its own

        Assert.Equal(1, await inbox.RequeueAsync(header.MessageId, CancellationToken.None));
        Assert.NotNull(await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None)); // operator requeue works
    }

    [Fact]
    public async Task A_row_found_delivering_after_a_crash_is_reported_as_stuck()
    {
        // D9/D46: the gateway settles it (its Reply's outcome, or Unknown); here only that it is found.
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var header = Header();
        await inbox.AddMessageAsync(header, [1], CancellationToken.None);
        Assert.NotNull(await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None)); // Delivering, then the process died

        Assert.Empty(await inbox.FindStuckAsync(TimeSpan.FromMinutes(5), CancellationToken.None)); // not yet
        var stuck = Assert.Single(await inbox.FindStuckAsync(TimeSpan.Zero, CancellationToken.None));
        Assert.Equal(header.MessageId, stuck.MessageId);
    }

    [Fact]
    public async Task An_arrived_message_is_owed_a_receipt_again_when_it_arrives_twice_but_a_receipt_never_is()
    {
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var request = Header();
        var receipt = Header() with { MessageId = Guid.NewGuid(), Kind = MessageKind.Receipt, CorrelationId = Guid.NewGuid(), Path = "", ContentType = "" };
        Assert.True(await inbox.AddMessageAsync(request, [1], CancellationToken.None));
        Assert.True(await inbox.AddMessageAsync(receipt, [2], CancellationToken.None));

        var due = Assert.Single(await inbox.FindDueReceiptsAsync(10, CancellationToken.None));
        Assert.Equal(request.MessageId, due.MessageId);
        await inbox.ClearReceiptDueAsync(due, CancellationToken.None);
        Assert.Empty(await inbox.FindDueReceiptsAsync(10, CancellationToken.None));

        Assert.False(await inbox.AddMessageAsync(request, [1], CancellationToken.None)); // re-aired: ignored, owed again
        Assert.False(await inbox.AddMessageAsync(receipt, [2], CancellationToken.None));
        Assert.Equal(request.MessageId, Assert.Single(await inbox.FindDueReceiptsAsync(10, CancellationToken.None)).MessageId);

        // Clearing an older due time keeps a newer arrival owed.
        await inbox.ClearReceiptDueAsync(due, CancellationToken.None);
        Assert.Single(await inbox.FindDueReceiptsAsync(10, CancellationToken.None));
    }

    [Fact]
    public async Task Not_delivered_rows_wait_for_an_operator_who_may_resend_them()
    {
        // D25: surely never reached the service (e.g. no target configured).
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var header = Header();
        await inbox.AddMessageAsync(header, [1], CancellationToken.None);
        var row = await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None);

        await inbox.MarkNotDeliveredAsync(row!.MessageId, null, "No Receiver target for SSO2FMS", CancellationToken.None);

        var stored = await inbox.FindAsync(header.MessageId, CancellationToken.None);
        Assert.Equal(InboxServiceStatus.NotDelivered, stored!.ServiceStatus);
        Assert.Null(stored.ServiceHttpStatus);
        Assert.Null(await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None));
        Assert.Equal(1, await inbox.RequeueAsync(header.MessageId, CancellationToken.None));
    }

    [Fact]
    public async Task A_rejected_row_is_a_light_problem_never_delivered_counted_or_requeued_as_service_work()
    {
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var header = Header();
        await inbox.AddMessageAsync(header, [1], CancellationToken.None);
        var row = await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None);

        await inbox.MarkRejectedAsync(row!.MessageId, "InvalidDataException: Message checksum mismatch (corrupted).", CancellationToken.None);

        var rejected = await inbox.FindAsync(header.MessageId, CancellationToken.None);
        Assert.Equal(InboxLightStatus.Rejected, rejected!.LightStatus);
        Assert.Contains("checksum", rejected.LightComment);
        Assert.Null(rejected.ServiceComment);
        Assert.Null(await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None));
        Assert.Equal(0, await inbox.RequeueAsync(header.MessageId, CancellationToken.None));
        Assert.Empty(await inbox.FindStuckAsync(TimeSpan.Zero, CancellationToken.None));

        var counts = await inbox.GetCountsAsync(CancellationToken.None);
        Assert.Equal(1, counts.Light[InboxLightStatus.Rejected]);
        Assert.All(counts.Service.Values, n => Assert.Equal(0, n));
    }

    [Fact]
    public async Task The_database_refuses_an_impossible_http_status()
    {
        var factory = _sp.GetRequiredService<IDbContextFactory<BridgeDbContext>>();
        await using var db = await factory.CreateDbContextAsync();
        var row = await InsertOutboxAsync();
        db.Attach(row).Entity.ServiceHttpStatus = 42;
        await Assert.ThrowsAsync<DbUpdateException>(() => db.SaveChangesAsync());
    }

    [Fact]
    public async Task Inbox_claims_follow_the_sender_sequence_not_arrival_order()
    {
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var later = Header() with { MessageId = Guid.NewGuid(), Sequence = 9 };
        var earlier = Header() with { MessageId = Guid.NewGuid(), Sequence = 3 };
        await inbox.AddMessageAsync(later, [1], CancellationToken.None);
        await inbox.AddMessageAsync(earlier, [2], CancellationToken.None);

        Assert.Equal(earlier.MessageId, (await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None))!.MessageId);
        Assert.Equal(later.MessageId, (await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None))!.MessageId);
    }

    [Fact]
    public async Task Retrying_rows_are_retried_after_backoff()
    {
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        await inbox.AddMessageAsync(Header(), [1, 2, 3], CancellationToken.None);

        var first = await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None);
        await inbox.MarkRetryingAsync(first!.MessageId, 429, "transient", TimeSpan.FromHours(1), CancellationToken.None);
        var waiting = await inbox.FindAsync(first.MessageId, CancellationToken.None);
        Assert.Equal(InboxServiceStatus.Retrying, waiting!.ServiceStatus);
        Assert.Equal(429, waiting.ServiceHttpStatus);
        Assert.Null(await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None)); // still backing off

        await inbox.MarkRetryingAsync(first.MessageId, 429, "transient", TimeSpan.Zero, CancellationToken.None);
        var second = await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None);
        Assert.Equal(2, second!.Attempts);
    }

    // ---------------------------------------------------------------- priorities and order (step 14, D73, D74)

    [Fact]
    public async Task The_light_airs_answers_first_then_requests_by_class()
    {
        var store = _sp.GetRequiredService<IOutboxRepository>();
        var feed = await InsertOutboxAsync(priority: MessagePriority.Low);
        var query = await InsertOutboxAsync(priority: MessagePriority.Normal);
        var permit = await InsertOutboxAsync(priority: MessagePriority.High);
        var reply = await InsertOutboxAsync(kind: MessageKind.Reply);
        var secondPermit = await InsertOutboxAsync(priority: MessagePriority.High);

        var order = new List<Guid>();
        while (await store.ClaimNextAsync(CancellationToken.None) is { } row) order.Add(row.MessageId);

        Assert.Equal([reply.MessageId, permit.MessageId, secondPermit.MessageId, query.MessageId, feed.MessageId], order);
    }

    private MessageHeader Request(MessagePriority priority, long sequence, string service = "SSO2FMS", Guid? run = null, DateTime? created = null) =>
        Header() with
        {
            MessageId = Guid.NewGuid(), Priority = priority, Sequence = sequence, ServiceName = service,
            SequenceRunId = run ?? _run, CreatedUtc = created ?? DateTime.UtcNow,
        };

    private readonly Guid _run = Guid.NewGuid();

    [Fact]
    public async Task Each_delivery_loop_claims_only_its_own_class()
    {
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var feed = Request(MessagePriority.Low, 1);
        var permit = Request(MessagePriority.High, 2);
        await inbox.AddMessageAsync(feed, [1], CancellationToken.None);
        await inbox.AddMessageAsync(permit, [1], CancellationToken.None);

        Assert.Null(await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None));
        Assert.Equal(permit.MessageId, (await inbox.ClaimNextAsync(MessagePriority.High, CancellationToken.None))!.MessageId);
        Assert.Equal(feed.MessageId, (await inbox.ClaimNextAsync(MessagePriority.Low, CancellationToken.None))!.MessageId);
    }

    [Fact]
    public async Task A_new_run_of_the_senders_counter_never_jumps_ahead_of_older_messages()
    {
        // The sender's qrbridge.db was rebuilt: its counter starts again at 1 in a new run, while 40 of the old run still waits.
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var old = Request(MessagePriority.High, 40, run: Guid.NewGuid(), created: DateTime.UtcNow.AddMinutes(-5));
        var restarted = Request(MessagePriority.High, 1, run: Guid.NewGuid(), created: DateTime.UtcNow);
        await inbox.AddMessageAsync(restarted, [1], CancellationToken.None);
        await inbox.AddMessageAsync(old, [1], CancellationToken.None);

        Assert.Equal(old.MessageId, (await inbox.ClaimNextAsync(MessagePriority.High, CancellationToken.None))!.MessageId);
        Assert.Equal(restarted.MessageId, (await inbox.ClaimNextAsync(MessagePriority.High, CancellationToken.None))!.MessageId);
    }

    [Fact]
    public async Task A_request_never_overtakes_an_earlier_one_of_its_service_waiting_to_be_re_posted()
    {
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var first = Request(MessagePriority.High, 1, "FC2FMS");
        var second = Request(MessagePriority.High, 2, "FC2FMS");
        var otherService = Request(MessagePriority.High, 3, "SSO2FMS");
        var otherClass = Request(MessagePriority.Normal, 4, "FC2FMS");
        foreach (var h in new[] { first, second, otherService, otherClass }) await inbox.AddMessageAsync(h, [1], CancellationToken.None);

        Assert.Equal(first.MessageId, (await inbox.ClaimNextAsync(MessagePriority.High, CancellationToken.None))!.MessageId);
        await inbox.MarkRetryingAsync(first.MessageId, 429, "throttled", TimeSpan.FromHours(1), CancellationToken.None);

        // second waits behind first; another service and another class do not.
        Assert.Equal(otherService.MessageId, (await inbox.ClaimNextAsync(MessagePriority.High, CancellationToken.None))!.MessageId);
        Assert.Null(await inbox.ClaimNextAsync(MessagePriority.High, CancellationToken.None));
        Assert.Equal(otherClass.MessageId, (await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None))!.MessageId);

        await inbox.MarkNotDeliveredAsync(first.MessageId, 429, "out of tries", CancellationToken.None); // first is over
        Assert.Equal(second.MessageId, (await inbox.ClaimNextAsync(MessagePriority.High, CancellationToken.None))!.MessageId);
    }

    // ---------------------------------------------------------------- plaintext at rest (step 15, D3, D77)

    [Fact]
    public async Task A_done_row_keeps_no_body_but_its_hash_and_a_row_for_an_operator_keeps_its_body()
    {
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        var delivered = Request(MessagePriority.Normal, 1);
        var refused = Request(MessagePriority.Normal, 2, "FC2FMS");
        await inbox.AddMessageAsync(delivered, [1, 2, 3], CancellationToken.None);
        await inbox.AddMessageAsync(refused, [4, 5, 6], CancellationToken.None);
        await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None);
        await inbox.ClaimNextAsync(MessagePriority.Normal, CancellationToken.None);

        await inbox.MarkDoneAsync(delivered.MessageId, 200, "RETURN_CODE=0", "RETURN_CODE=0", CancellationToken.None);
        await inbox.MarkRefusedAsync(refused.MessageId, 200, "RETURN_CODE=1501", "RETURN_CODE=1501", CancellationToken.None);

        var done = await inbox.FindAsync(delivered.MessageId, CancellationToken.None);
        Assert.Empty(done!.MessageBytes);
        Assert.Equal(Hashing.Sha256Hex([1, 2, 3]), done.MessageHash); // still reconcilable with the sender's row
        Assert.Equal("RETURN_CODE=0", done.DownstreamResult);

        var kept = await inbox.FindAsync(refused.MessageId, CancellationToken.None);
        Assert.Equal([4, 5, 6], kept!.MessageBytes); // an operator may requeue it
        Assert.Equal(1, await inbox.RequeueAsync(refused.MessageId, CancellationToken.None));
    }

    [Fact]
    public async Task Heartbeats_upsert()
    {
        var hb = _sp.GetRequiredService<IHeartbeatRepository>();
        await hb.BeatAsync("X", "one", CancellationToken.None);
        await hb.BeatAsync("X", "two", CancellationToken.None);
        var all = await hb.GetAllAsync(CancellationToken.None);
        Assert.Single(all);
        Assert.Equal("two", all[0].Info);
        Assert.Equal(DateTimeKind.Utc, all[0].LastSeenUtc.Kind);
    }

    // ---------------- sequence gaps (G-02, D29, D30) ----------------

    private async Task<Guid> ArriveAsync(Guid run, long sequence, Direction direction = Direction.CorpToDmz)
    {
        var header = Header() with { MessageId = Guid.NewGuid(), SequenceRunId = run, Sequence = sequence, Direction = direction };
        await _sp.GetRequiredService<IInboxRepository>().AddMessageAsync(header, [1], CancellationToken.None);
        return header.MessageId;
    }

    private Task<IReadOnlyList<SequenceGap>> GapsAsync(DateTime? arrivedBefore = null) =>
        _sp.GetRequiredService<IInboxRepository>()
            .FindSequenceGapsAsync(Direction.CorpToDmz, arrivedBefore ?? DateTime.UtcNow.AddSeconds(5), CancellationToken.None);

    [Fact]
    public async Task Missing_numbers_are_reported_per_counter_run_including_the_first_ones()
    {
        Guid runA = Guid.NewGuid(), runB = Guid.NewGuid();
        foreach (long s in new long[] { 1, 2, 5, 6, 9 }) await ArriveAsync(runA, s);
        foreach (long s in new long[] { 3, 4 }) await ArriveAsync(runB, s); // run B's first two never arrived
        await ArriveAsync(runA, 20, Direction.DmzToCorp); // the other direction is not this side's concern

        var gaps = (await GapsAsync()).Select(g => (g.SequenceRunId, g.FromSequence, g.ToSequence)).OrderBy(g => g.ToString()).ToList();

        Assert.Equal(new[] { (runA, 3L, 4L), (runA, 7L, 8L), (runB, 1L, 2L) }.OrderBy(g => g.ToString()), gaps);
    }

    [Fact]
    public async Task A_counter_that_starts_again_in_a_new_run_is_not_a_gap()
    {
        Guid oldRun = Guid.NewGuid(), newRun = Guid.NewGuid(); // e.g. the sender's qrbridge.db rebuilt after message 3
        foreach (long s in new long[] { 1, 2, 3 }) await ArriveAsync(oldRun, s);
        foreach (long s in new long[] { 1, 2 }) await ArriveAsync(newRun, s);

        Assert.Empty(await GapsAsync());
    }

    [Fact]
    public async Task A_gap_waits_for_the_grace_period_and_a_rejected_row_counts_as_arrived()
    {
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        Guid run = Guid.NewGuid();
        await ArriveAsync(run, 1);
        Guid second = await ArriveAsync(run, 2);
        await ArriveAsync(run, 4);
        await inbox.MarkRejectedAsync(second, "checksum mismatch", CancellationToken.None); // already a light alarm

        Assert.Empty(await GapsAsync(arrivedBefore: DateTime.UtcNow.AddMinutes(-5))); // 4 arrived just now: maybe 3 is still coming
        var gap = Assert.Single(await GapsAsync());
        Assert.Equal((3L, 3L), (gap.FromSequence, gap.ToSequence));
    }

    [Fact]
    public async Task An_acknowledged_gap_is_kept_for_audit_and_no_longer_reported()
    {
        var inbox = _sp.GetRequiredService<IInboxRepository>();
        Guid run = Guid.NewGuid();
        await ArriveAsync(run, 1);
        await ArriveAsync(run, 5); // 2–4 missing

        Assert.True(await inbox.AcknowledgeGapAsync(Direction.CorpToDmz, run, 2, 3, "j.smith", "re-issued verbally, ticket 1234", CancellationToken.None));
        Assert.False(await inbox.AcknowledgeGapAsync(Direction.CorpToDmz, run, 2, 2, "j.smith", "again", CancellationToken.None));
        await Assert.ThrowsAsync<ArgumentException>(() => inbox.AcknowledgeGapAsync(Direction.CorpToDmz, run, 4, 3, "j.smith", "x", CancellationToken.None));
        await Assert.ThrowsAsync<ArgumentException>(() => inbox.AcknowledgeGapAsync(Direction.CorpToDmz, run, 4, 4, " ", "x", CancellationToken.None));
        await Assert.ThrowsAsync<ArgumentException>(() => inbox.AcknowledgeGapAsync(Direction.CorpToDmz, run, 4, 4, "j.smith", "", CancellationToken.None));

        var gap = Assert.Single(await GapsAsync()); // only 4 is still missing
        Assert.Equal((4L, 4L), (gap.FromSequence, gap.ToSequence));

        await using var db = await _sp.GetRequiredService<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        var audit = await db.AcknowledgedGaps.SingleAsync();
        Assert.Equal(("j.smith", "re-issued verbally, ticket 1234", 2L, 3L), (audit.AcknowledgedBy, audit.Reason, audit.FromSequence, audit.ToSequence));
    }
}
