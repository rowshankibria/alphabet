using System.Text.RegularExpressions;

namespace QrBridge.Tests;

/// <summary>
/// The database engine is configuration (GatewayDatabase:Provider), so only the engine folders may name one: everything
/// that belongs to SQLite is under Data/Sqlite, everything SQL Server's under Data/SqlServer (each with its Providers,
/// Contexts, Initializers and Migrations). The shared folders — entities, configurations, conventions, the abstract
/// context, IBridgeDatabase, the repositories — and the gateway use BridgeDbContext and the repository interfaces.
/// This test fails when engine code leaks back into them.
/// </summary>
public sealed partial class DatabaseSeamTests
{
    private static readonly string[] EngineFolders =
    [
        Path.Combine("QrBridge.Shared", "Data", "Sqlite"),
        Path.Combine("QrBridge.Shared", "Data", "SqlServer"),
    ];

    [Fact]
    public void Only_the_engine_classes_name_a_database_engine()
    {
        string src = Path.Combine(RepositoryRoot(), "sourcecode", "gateway", "src");
        var leaks = Directory.EnumerateFiles(src, "*.cs", SearchOption.AllDirectories)
            .Where(f => !f.Contains($"{Path.DirectorySeparatorChar}obj{Path.DirectorySeparatorChar}") &&
                        !f.Contains($"{Path.DirectorySeparatorChar}bin{Path.DirectorySeparatorChar}"))
            .Where(f => !EngineFolders.Any(folder => Path.GetRelativePath(src, f).StartsWith(folder + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)))
            .SelectMany(f => File.ReadLines(f).Select((line, i) => (File: Path.GetRelativePath(src, f), Line: i + 1, Text: line)))
            .Where(l => EngineCode().IsMatch(l.Text))
            .Select(l => $"{l.File}:{l.Line}: {l.Text.Trim()}")
            .ToList();

        Assert.Empty(leaks);
    }

    private static string RepositoryRoot()
    {
        for (var dir = new DirectoryInfo(AppContext.BaseDirectory); dir is not null; dir = dir.Parent)
            if (File.Exists(Path.Combine(dir.FullName, "All.slnx"))) return dir.FullName;
        throw new InvalidOperationException("All.slnx not found above the test folder.");
    }

    [GeneratedRegex(@"Microsoft\.Data\.(Sqlite|SqlClient)|\bUse(Sqlite|SqlServer)\b|\bSql(ite)?(Exception|Connection)\b|PRAGMA|sp_getapplock")]
    private static partial Regex EngineCode();
}
