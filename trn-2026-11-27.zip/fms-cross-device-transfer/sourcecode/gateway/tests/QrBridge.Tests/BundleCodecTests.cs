using System.Buffers.Binary;
using QrBridge.Shared.Bundles;

namespace QrBridge.Tests;

/// <summary>The QR bundle format (decision 52): exact round trip, and a bounded parser that only ever throws InvalidDataException.</summary>
public sealed class BundleCodecTests
{
    private const int MaxEnvelope = 2_000_000;

    [Fact]
    public void One_message_round_trips()
    {
        var id = Guid.NewGuid();
        byte[] bytes = BundleCodec.Build(id, [(7, [1, 2, 3])]);

        var bundle = BundleCodec.Parse(bytes, MaxEnvelope);

        Assert.Equal(id, bundle.BundleId);
        Assert.Equal((7, 7), (bundle.MinSequence, bundle.MaxSequence));
        Assert.Equal([1, 2, 3], Assert.Single(bundle.Envelopes));
        Assert.Equal(BundleCodec.HeaderSize + BundleCodec.EntryOverhead + 3, bytes.Length);
    }

    [Fact]
    public void Many_messages_round_trip_in_order_with_their_sequence_range()
    {
        var items = Enumerable.Range(0, 50).Select(i => ((long)(100 - i), Enumerable.Repeat((byte)i, i + 1).ToArray())).ToList();

        var bundle = BundleCodec.Parse(BundleCodec.Build(Guid.NewGuid(), items), MaxEnvelope);

        Assert.Equal(items.Select(i => i.Item2), bundle.Envelopes);
        Assert.Equal((51, 100), (bundle.MinSequence, bundle.MaxSequence));
    }

    [Fact]
    public void The_file_name_says_it_is_a_bundle()
    {
        Assert.Equal("bundle-1042-1061.qbb", BundleCodec.FileName(1042, 1061));
        Assert.True(BundleCodec.IsBundleFileName("bundle-1-1.QBB"));
        Assert.False(BundleCodec.IsBundleFileName("order.xml"));
    }

    [Fact]
    public void Build_refuses_an_empty_bundle_or_an_empty_message()
    {
        Assert.Throws<ArgumentException>(() => BundleCodec.Build(Guid.NewGuid(), []));
        Assert.Throws<ArgumentException>(() => BundleCodec.Build(Guid.NewGuid(), [(1, [])]));
    }

    public static TheoryData<string, byte[]> Malformed()
    {
        byte[] good = BundleCodec.Build(Guid.NewGuid(), [(1, [9, 9]), (2, [8])]);
        byte[] Changed(Action<byte[]> change) { byte[] b = (byte[])good.Clone(); change(b); return b; }

        return new TheoryData<string, byte[]>
        {
            { "empty", [] },
            { "too short", good[..10] },
            { "wrong magic", Changed(b => b[0] = (byte)'X') },
            { "wrong version", Changed(b => b[4] = 9) },
            { "no id", Changed(b => Array.Clear(b, 5, 16)) },
            { "count 0", Changed(b => BinaryPrimitives.WriteUInt16LittleEndian(b.AsSpan(21), 0)) },
            { "count above the limit", Changed(b => BinaryPrimitives.WriteUInt16LittleEndian(b.AsSpan(21), BundleCodec.MaxMessagesLimit + 1)) },
            { "count larger than what follows", Changed(b => BinaryPrimitives.WriteUInt16LittleEndian(b.AsSpan(21), 3)) },
            { "reversed range", Changed(b => BinaryPrimitives.WriteInt64LittleEndian(b.AsSpan(23), 5)) },
            { "negative length", Changed(b => BinaryPrimitives.WriteInt32LittleEndian(b.AsSpan(BundleCodec.HeaderSize), -1)) },
            { "zero length", Changed(b => BinaryPrimitives.WriteInt32LittleEndian(b.AsSpan(BundleCodec.HeaderSize), 0)) },
            { "length past the end", Changed(b => BinaryPrimitives.WriteInt32LittleEndian(b.AsSpan(BundleCodec.HeaderSize), 1000)) },
            { "truncated", good[..^1] },
            { "extra bytes", [.. good, 0] },
        };
    }

    [Theory]
    [MemberData(nameof(Malformed))]
    public void Malformed_input_is_refused_with_InvalidDataException_only(string why, byte[] data)
    {
        var ex = Record.Exception(() => BundleCodec.Parse(data, MaxEnvelope));
        Assert.True(ex is InvalidDataException, $"{why}: {ex?.GetType().Name ?? "no exception"}");
    }

    [Fact]
    public void A_message_over_the_envelope_limit_is_refused()
    {
        byte[] bytes = BundleCodec.Build(Guid.NewGuid(), [(1, new byte[101])]);
        Assert.Throws<InvalidDataException>(() => BundleCodec.Parse(bytes, maxEnvelopeBytes: 100));
    }

    [Fact]
    public void Random_bytes_never_escape_as_another_exception()
    {
        var rng = new Random(5);
        for (int i = 0; i < 5_000; i++)
        {
            byte[] data = new byte[rng.Next(0, 200)];
            rng.NextBytes(data);
            if (data.Length >= 4 && rng.Next(2) == 0) "QBB1"u8.CopyTo(data);
            var ex = Record.Exception(() => BundleCodec.Parse(data, MaxEnvelope));
            Assert.True(ex is null or InvalidDataException, ex?.GetType().Name);
        }
    }
}
