using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Logging.Abstractions;
using QrBridge.Shared;
using QrBridge.Shared.Bundles;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests;

/// <summary>
/// The QR Receiver's journal in the bridge database (27 Nov 2026; until then its own journal.db): the anti-replay rules,
/// the session records, the archive, and the one-time copy of a former journal.db. Every case runs on SQLite, and on
/// SQL Server too when QRBRIDGE_SQLSERVER is set.
/// </summary>
public sealed class ReceiveJournalRepositoryTests
{
    private const string Key = "AB12CD34";

    public static TheoryData<string> Engines()
    {
        var engines = new TheoryData<string> { nameof(DatabaseProvider.Sqlite) };
        if (SqlServerTestDatabase.ServerConnectionString is not null) engines.Add(nameof(DatabaseProvider.SqlServer));
        return engines;
    }

    [Theory]
    [MemberData(nameof(Engines))]
    public async Task A_session_is_accepted_once_and_its_run_watermark_only_moves_up(string engine)
    {
        await using var bench = await Bench.StartAsync(engine);
        var journal = bench.Journal;
        var run = Guid.NewGuid();
        var now = DateTimeOffset.UtcNow;
        long ts = now.ToUnixTimeMilliseconds();
        var window = TimeSpan.FromHours(48);
        var first = Guid.NewGuid();

        Assert.Equal(JournalReplayCheck.Fresh, journal.CheckReplay(Key, first, run, 5, ts, window, now));
        Assert.True(journal.IsNewRun(Key, run));
        journal.CommitReplay(Key, first, run, 5, now);
        journal.CommitReplay(Key, Guid.NewGuid(), run, 3, now); // a lower counter never moves it down

        Assert.Equal(JournalReplayCheck.KnownSession, journal.CheckReplay(Key, first, run, 9, ts, window, now));
        Assert.Equal(JournalReplayCheck.StaleCounter, journal.CheckReplay(Key, Guid.NewGuid(), run, 5, ts, window, now));
        Assert.Equal(JournalReplayCheck.Fresh, journal.CheckReplay(Key, Guid.NewGuid(), run, 6, ts, window, now));
        Assert.Equal(JournalReplayCheck.Fresh, journal.CheckReplay(Key, Guid.NewGuid(), Guid.NewGuid(), 1, ts, window, now)); // another run
        Assert.Equal(JournalReplayCheck.OutsideWindow,
            journal.CheckReplay(Key, Guid.NewGuid(), run, 6, now.AddHours(-49).ToUnixTimeMilliseconds(), window, now));
        Assert.False(journal.IsNewRun(Key, run));
    }

    [Theory]
    [MemberData(nameof(Engines))]
    public async Task A_recorded_transfer_answers_stored_and_duplicate_content(string engine)
    {
        await using var bench = await Bench.StartAsync(engine);
        var journal = bench.Journal;
        var stored = Guid.NewGuid();
        var verifiedOnly = Guid.NewGuid();
        journal.CommitReplay(Key, stored, Guid.NewGuid(), 1, DateTimeOffset.UtcNow);
        journal.CommitReplay(Key, verifiedOnly, Guid.NewGuid(), 1, DateTimeOffset.UtcNow);

        journal.RecordTransfer(stored, "CAFE", "permit.xml", 120, "stored");

        Assert.True(journal.IsStoredSession(stored));
        Assert.False(journal.IsStoredSession(verifiedOnly)); // committed, but the payload never completed
        Assert.True(journal.IsDuplicateContent(Key, "CAFE"));
        Assert.False(journal.IsDuplicateContent("OTHERKEY", "CAFE"));
    }

    [Theory]
    [MemberData(nameof(Engines))]
    public async Task The_archive_is_searched_filtered_and_totalled(string engine)
    {
        await using var bench = await Bench.StartAsync(engine);
        var journal = bench.Journal;
        var now = DateTime.UtcNow;
        journal.AddArchiveEntry(Entry(now.AddDays(-3), JournalOutcomes.Rejected, "old.xml", 0, "PRM", reason: "signature"));
        journal.AddArchiveEntry(Entry(now.AddMinutes(-3), JournalOutcomes.Verified, "permit_1.xml", 100, "PRM"));
        journal.AddArchiveEntry(Entry(now.AddMinutes(-2), JournalOutcomes.Duplicate, "permit_1.xml", 100, "PRM"));
        journal.AddArchiveEntry(Entry(now.AddMinutes(-1), JournalOutcomes.StoreFailed, "card.xml", 50, "CRD", reason: "disk 100%_full"));

        var all = journal.FindArchiveEntries(new JournalArchiveFilter(), 10);
        Assert.Equal(["card.xml", "permit_1.xml", "permit_1.xml", "old.xml"], all.Select(e => e.Filename)); // newest first
        Assert.Equal(["card.xml", "old.xml"], journal.FindArchiveEntries(new(Outcomes: [.. JournalOutcomes.NotLanded]), 10).Select(e => e.Filename));
        Assert.Equal(["card.xml"], journal.FindArchiveEntries(new(Search: "100%_"), 10).Select(e => e.Filename)); // % and _ match themselves
        Assert.Empty(journal.FindArchiveEntries(new(Search: "100x"), 10));
        Assert.Equal(3, journal.FindArchiveEntries(new(SinceUtc: now.AddDays(-1)), 10).Count);

        var totals = journal.CountArchive(new JournalArchiveFilter());
        Assert.Equal((4, 1, 1, 2, 100L), (totals.Arrivals, totals.Verified, totals.Duplicates, totals.NotLanded, totals.StoredBytes));
        Assert.Equal(now.AddDays(-3), totals.FirstUtc!.Value, TimeSpan.FromMilliseconds(1));
        Assert.Equal(now.AddMinutes(-1), totals.LastUtc!.Value, TimeSpan.FromMilliseconds(1));
        Assert.Equal(new JournalArchiveTotals(0, 0, 0, 0, 0, null, null), journal.CountArchive(new(Search: "nothing-like-this")));

        var tallies = journal.CountArchiveByType(new JournalArchiveFilter());
        Assert.Equal([("PRM", 3, 100L), ("CRD", 1, 0L)], tallies.Select(t => (t.Code, t.Count, t.Bytes)));
    }

    [Theory]
    [MemberData(nameof(Engines))]
    public async Task A_former_journal_db_is_copied_in_once_with_its_anti_replay_state(string engine)
    {
        await using var bench = await Bench.StartAsync(engine);
        var session = Guid.NewGuid();
        var run = Guid.NewGuid();
        string path = OldJournal(bench.Folder, $"""
            INSERT INTO transfers VALUES ('{session:N}', '{Key}', 7, 'BEEF', 'permit.xml', 120, '2026-11-26T10:00:00.0000000+00:00', 'stored');
            INSERT INTO run_watermarks VALUES ('{Key}', '{run:N}', 7, '2026-11-26T10:00:00.0000000+00:00');
            INSERT INTO payload_index (received_utc, outcome, session_guid, sender_key_id, counter, type_code, type_name, content_kind,
                                       filename, size, sha256, receipt, stored_path, reason, seconds)
                VALUES ('2026-11-26T10:00:01.0000000Z', 'verified', '{session:N}', '{Key}', 7, 'PRM', 'permit', 1,
                        'permit.xml', 120, 'BEEF', 'R1', NULL, NULL, 2.5);
            """);

        Assert.Equal(1, bench.Bridge.ImportLegacyJournal(path));

        var journal = bench.Journal;
        var now = DateTimeOffset.UtcNow;
        Assert.Equal(JournalReplayCheck.KnownSession, journal.CheckReplay(Key, session, run, 99, now.ToUnixTimeMilliseconds(), TimeSpan.FromHours(48), now));
        Assert.Equal(JournalReplayCheck.StaleCounter, journal.CheckReplay(Key, Guid.NewGuid(), run, 7, now.ToUnixTimeMilliseconds(), TimeSpan.FromHours(48), now));
        Assert.True(journal.IsDuplicateContent(Key, "BEEF"));
        var entry = Assert.Single(journal.FindArchiveEntries(new JournalArchiveFilter(), 10));
        Assert.Equal(("permit.xml", "", new DateTime(2026, 11, 26, 10, 0, 1, DateTimeKind.Utc)), (entry.Filename, entry.Snippet, entry.ReceivedUtc));

        Assert.False(File.Exists(path));
        Assert.Contains(Directory.GetFiles(bench.Folder, "journal.db.imported-*"), f => !f.EndsWith("-wal", StringComparison.Ordinal) && !f.EndsWith("-shm", StringComparison.Ordinal));
        Assert.Null(bench.Bridge.ImportLegacyJournal(path)); // never twice
    }

    [Fact]
    public async Task A_file_that_is_not_a_former_journal_is_refused_and_left_unchanged()
    {
        await using var bench = await Bench.StartAsync(nameof(DatabaseProvider.Sqlite));
        string path = Path.Combine(bench.Folder, "journal.db");
        await using (var connection = new SqliteConnection($"Data Source={path};Pooling=False"))
        {
            await connection.OpenAsync();
            await using var cmd = connection.CreateCommand();
            cmd.CommandText = "CREATE TABLE transfers (session_guid TEXT PRIMARY KEY, something_else TEXT);";
            await cmd.ExecuteNonQueryAsync();
        }

        Assert.Throws<SchemaMismatchException>(() => bench.Bridge.ImportLegacyJournal(path));

        Assert.True(File.Exists(path));
        Assert.Empty(bench.Journal.FindArchiveEntries(new JournalArchiveFilter(), 10));
    }

    private static JournalArchiveEntry Entry(DateTime receivedUtc, string outcome, string filename, long size, string type, string? reason = null) => new()
    {
        ReceivedUtc = receivedUtc, Outcome = outcome, Filename = filename, Size = size, TypeCode = type, TypeName = type.ToLowerInvariant(),
        SessionId = Guid.NewGuid().ToString("N"), SenderKeyId = Key, Sha256 = "AA", Receipt = "R", Reason = reason, Seconds = 1.5,
    };

    /// <summary>A journal.db exactly as the Receiver made it until 27 Nov 2026 (its CREATE statements, verbatim), with <paramref name="rows"/>.</summary>
    private static string OldJournal(string folder, string rows)
    {
        string path = Path.Combine(folder, "journal.db");
        using var connection = new SqliteConnection($"Data Source={path};Pooling=False");
        connection.Open();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS transfers (
                session_guid     TEXT PRIMARY KEY,
                sender_key_id    TEXT NOT NULL,
                counter          INTEGER NOT NULL,
                plaintext_sha256 TEXT NOT NULL,
                filename         TEXT NOT NULL,
                size             INTEGER NOT NULL,
                received_utc     TEXT NOT NULL,
                status           TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_transfers_hash ON transfers(sender_key_id, plaintext_sha256);
            CREATE TABLE IF NOT EXISTS run_watermarks (
                key_id    TEXT NOT NULL,
                run_id    TEXT NOT NULL,
                counter   INTEGER NOT NULL,
                first_utc TEXT NOT NULL,
                PRIMARY KEY (key_id, run_id)
            );
            CREATE TABLE IF NOT EXISTS payload_index (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                received_utc  TEXT NOT NULL,
                outcome       TEXT NOT NULL,
                session_guid  TEXT NOT NULL,
                sender_key_id TEXT NOT NULL,
                counter       INTEGER NOT NULL,
                type_code     TEXT NOT NULL,
                type_name     TEXT NOT NULL,
                content_kind  INTEGER NOT NULL,
                filename      TEXT NOT NULL,
                size          INTEGER NOT NULL,
                sha256        TEXT NOT NULL,
                receipt       TEXT NOT NULL,
                stored_path   TEXT,
                reason        TEXT,
                seconds       REAL NOT NULL,
                snippet       TEXT NOT NULL DEFAULT ''
            );
            """ + rows;
        cmd.ExecuteNonQuery();
        return path;
    }

    /// <summary>A bridge database on one engine, opened the way the QR Receiver opens it (QrAppBridge), and cleaned up after.</summary>
    private sealed class Bench : IAsyncDisposable
    {
        private SqlServerTestDatabase? _sqlServer;

        public string Folder { get; } = Path.Combine(Path.GetTempPath(), "qrbridge-journal-" + Guid.NewGuid().ToString("N"));
        public QrAppBridge Bridge { get; private set; } = null!;
        public IReceiveJournalRepository Journal => Bridge.Journal;

        public static async Task<Bench> StartAsync(string engine)
        {
            var bench = new Bench();
            Directory.CreateDirectory(bench.Folder);
            var options = new GatewayDatabaseOptions { Side = BridgeSide.Dmz, DataFolder = Path.Combine(bench.Folder, "Data") };
            if (engine == nameof(DatabaseProvider.SqlServer))
            {
                bench._sqlServer = SqlServerTestDatabase.New();
                options = bench._sqlServer.Options(BridgeSide.Dmz);
            }
            bench.Bridge = await QrAppBridge.OpenAsync(options, CancellationToken.None, NullLoggerFactory.Instance);
            return bench;
        }

        public async ValueTask DisposeAsync()
        {
            await Bridge.DisposeAsync();
            if (_sqlServer is not null) await _sqlServer.DisposeAsync();
            SqliteConnection.ClearAllPools();
            try { Directory.Delete(Folder, recursive: true); } catch { /* best effort */ }
        }
    }
}
