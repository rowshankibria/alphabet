using System.Net;
using QrBridge.Shared;
using QrBridge.Tests.Gateway.Infrastructure;
using QrBridge.Tests.Ui.Infrastructure;
using QrBridge.Gateway;
using QrBridge.Gateway.Ui.Security;

namespace QrBridge.Tests.Ui;

/// <summary>
/// Decision 48: every page of the read-only UI needs the one login (Ui:Username / Ui:PasswordHash, admin / admin by
/// default; the password only ever as a salted hash); the login page and its stylesheet and scripts do not. The pages send headers that keep payloads out of
/// caches and frames.
/// </summary>
public sealed class UiLoginTests(UiCorpFixture fixture) : IClassFixture<UiCorpFixture>
{
    [Theory]
    [InlineData("/qrbridge-ui")]
    [InlineData("/qrbridge-ui/outbox")]
    [InlineData("/qrbridge-ui/inbox?kind=all")]
    [InlineData("/qrbridge-ui/outbox/00000000-0000-0000-0000-000000000001")]
    public async Task Every_page_needs_a_login(string path)
    {
        using var client = fixture.Host.CreateClient();
        using var response = await client.GetAsync(path);

        Assert.Equal(HttpStatusCode.Redirect, response.StatusCode);
        Assert.Contains("/qrbridge-ui/login?ReturnUrl=", response.Headers.Location!.ToString());
    }

    [Fact]
    public async Task The_login_page_and_its_assets_need_no_login()
    {
        using var client = fixture.Host.CreateClient();

        Assert.Contains("Sign in", await client.GetStringAsync(UiPaths.Login));
        foreach (var (name, type) in new[] { ("ui.css", "text/css"), ("ui.js", "text/javascript"), ("theme.js", "text/javascript") })
        {
            using var asset = await client.GetAsync($"{UiPaths.Prefix}/assets/{name}");
            Assert.Equal(HttpStatusCode.OK, asset.StatusCode);
            Assert.Equal(type, asset.Content.Headers.ContentType!.MediaType);
        }
        using var missing = await client.GetAsync($"{UiPaths.Prefix}/assets/appsettings.json");
        Assert.Equal(HttpStatusCode.NotFound, missing.StatusCode);
    }

    [Fact]
    public async Task The_login_page_is_only_the_sign_in_panel()
    {
        using var client = fixture.Host.CreateClient();

        string html = await client.GetStringAsync(UiPaths.Login);

        Assert.DoesNotContain("class=\"topbar\"", html);  // no header
        Assert.DoesNotContain("class=\"footer\"", html);  // no footer
        Assert.Contains("<h1>QrNexus</h1>", html);
        Assert.Contains("Read-only view · Corp side</p>", UiBrowser.Text(html));
        Assert.DoesNotContain(Environment.MachineName, html);
    }

    [Fact]
    public async Task Admin_admin_signs_in_and_out()
    {
        using var ui = new UiBrowser(fixture.Host);

        using (var signIn = await ui.SignInAsync())
        {
            Assert.Equal(HttpStatusCode.Redirect, signIn.StatusCode);
            Assert.Equal(UiPaths.Prefix, signIn.Headers.Location!.ToString());
        }
        string overview = await ui.PageAsync(UiPaths.Prefix);
        Assert.Contains("Sign out", overview);

        var form = new Dictionary<string, string> { ["__RequestVerificationToken"] = UiBrowser.Token(overview) };
        using (var signOut = await ui.Client.PostAsync(UiPaths.Logout, new FormUrlEncodedContent(form)))
            Assert.Equal(HttpStatusCode.Redirect, signOut.StatusCode);
        using var after = await ui.Client.GetAsync(UiPaths.Prefix);
        Assert.Equal(HttpStatusCode.Redirect, after.StatusCode);
    }

    [Fact]
    public async Task A_wrong_password_is_refused()
    {
        using var ui = new UiBrowser(fixture.Host);

        using var signIn = await ui.SignInAsync("admin", "not-the-password");

        Assert.Equal(HttpStatusCode.OK, signIn.StatusCode);
        Assert.Contains("Invalid username or password.", await signIn.Content.ReadAsStringAsync());
        using var page = await ui.Client.GetAsync(UiPaths.Prefix);
        Assert.Equal(HttpStatusCode.Redirect, page.StatusCode);
    }

    [Theory]
    [InlineData("/qrbridge-ui/inbox?kind=all", "/qrbridge-ui/inbox?kind=all")]
    [InlineData("https://evil.example/qrbridge-ui", "/qrbridge-ui")] // another site
    [InlineData("//evil.example/qrbridge-ui", "/qrbridge-ui")]       // the same, without a scheme
    [InlineData("/health", "/qrbridge-ui")]                          // another path of the gateway
    public async Task After_the_login_only_a_page_of_the_ui_is_a_return_target(string returnUrl, string expected)
    {
        using var ui = new UiBrowser(fixture.Host);

        using var signIn = await ui.SignInAsync(returnUrl: returnUrl);

        Assert.Equal(HttpStatusCode.Redirect, signIn.StatusCode);
        Assert.Equal(expected, signIn.Headers.Location!.ToString());
    }

    [Fact]
    public async Task Pages_keep_payloads_out_of_caches_frames_and_other_sites()
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        using var response = await ui.Client.GetAsync(UiPaths.Box(MessageBox.Outbox));

        Assert.True(response.Headers.CacheControl!.NoStore); // antiforgery adds no-cache on pages with a form
        Assert.Equal("DENY", response.Headers.GetValues("X-Frame-Options").Single());
        string policy = response.Headers.GetValues("Content-Security-Policy").Single();
        Assert.Contains("default-src 'none'", policy);
        Assert.Contains("script-src 'self'", policy);
    }

    [Fact]
    public async Task The_login_comes_from_the_settings()
    {
        string root = GatewayHost.NewRoot();
        var host = GatewayHost.Start(BridgeSide.Corp, root, new Dictionary<string, string?>
        {
            ["Ui:Username"] = "operator",
            ["Ui:PasswordHash"] = UiAuthentication.HashPassword("Islanding-2026"),
        });
        try
        {
            using var ui = new UiBrowser(host);

            using (var old = await ui.SignInAsync("admin", "admin"))
                Assert.Equal(HttpStatusCode.OK, old.StatusCode); // refused: the form again
            using (var signIn = await ui.SignInAsync("operator", "Islanding-2026"))
                Assert.Equal(HttpStatusCode.Redirect, signIn.StatusCode);
            Assert.Contains("operator", await ui.PageAsync(UiPaths.Prefix));
        }
        finally
        {
            await host.DisposeAsync();
            GatewayHost.DeleteRoot(root);
        }
    }

    [Theory]
    [InlineData("Ui:PasswordHash", "Islanding-2026", "Ui:PasswordHash")] // a clear password where the hash belongs
    [InlineData("Ui:PasswordHash", "", "Ui:PasswordHash")]
    [InlineData("Ui:Password", "admin", "Ui:Password is no longer read")]  // the former clear-text setting
    public void A_password_in_clear_stops_the_start(string key, string value, string expected)
    {
        string root = GatewayHost.NewRoot();
        try
        {
            var ex = Assert.ThrowsAny<Exception>(() => GatewayHost.Start(BridgeSide.Corp, root,
                new Dictionary<string, string?> { [key] = value }));
            Assert.Contains(expected, ex.ToString());
        }
        finally
        {
            GatewayHost.DeleteRoot(root);
        }
    }

    [Fact]
    public void A_stored_hash_shows_nothing_of_the_password_and_differs_each_time()
    {
        string first = UiAuthentication.HashPassword("Islanding-2026");
        string second = UiAuthentication.HashPassword("Islanding-2026");

        Assert.StartsWith(UiAuthentication.HashPrefix + "$", first);
        Assert.DoesNotContain("Islanding", first);
        Assert.NotEqual(first, second); // fresh salt
        Assert.True(UiAuthentication.Verify(second, "Islanding-2026"));
        Assert.False(UiAuthentication.Verify(second, "islanding-2026"));
    }
}
