<#
.SYNOPSIS
    Makes the value for "Ui:PasswordHash" (the read-only UI's login) from a password typed at the prompt.

.DESCRIPTION
    The gateway never stores the UI password in clear: appsettings holds a salted PBKDF2-SHA256 hash in the form
    PBKDF2-SHA256$iterations$salt$hash (the same as UiAuthentication.HashPassword). Run this, type the password twice,
    and paste the printed line into "Ui": { "PasswordHash": "..." } of appsettings.{Side}.json. Works in Windows
    PowerShell 5.1 and PowerShell 7. The password is neither shown nor written anywhere.

.EXAMPLE
    .\new-ui-password-hash.ps1
#>
[CmdletBinding()]
param()

function Read-Password([string] $prompt) {
    $secure = Read-Host -Prompt $prompt -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

$password = Read-Password 'UI password'
if ([string]::IsNullOrEmpty($password)) { Write-Error 'The password is empty.'; exit 1 }
if ($password -cne (Read-Password 'Again')) { Write-Error 'The two passwords differ.'; exit 1 }

$iterations = 100000
$salt = New-Object byte[] 16
$rng = [Security.Cryptography.RandomNumberGenerator]::Create()
try { $rng.GetBytes($salt) } finally { $rng.Dispose() }

$kdf = New-Object Security.Cryptography.Rfc2898DeriveBytes(
    [Text.Encoding]::UTF8.GetBytes($password), $salt, $iterations, [Security.Cryptography.HashAlgorithmName]::SHA256)
try { $hash = $kdf.GetBytes(32) } finally { $kdf.Dispose() }

Write-Host 'Paste this into "Ui": { "PasswordHash": ... } of appsettings.{Side}.json:'
Write-Output ('PBKDF2-SHA256${0}${1}${2}' -f $iterations, [Convert]::ToBase64String($salt), [Convert]::ToBase64String($hash))
