<#
.SYNOPSIS
    Empties the developer databases of the read-only UI: deletes qrbridge.db (and its -wal, -shm) on the Corp and/or
    DMZ side. The gateway creates a new, empty qrbridge.db on its next start.

.DESCRIPTION
    Developer machines only. The folders are those of the launch profiles (Properties/launchSettings.json):
        {Root}\Corp\Data\qrbridge.db   and   {Root}\Dmz\Data\qrbridge.db
    Refuses the production data folder (C:\ProgramData\QrBridge): operators archive production rows by hand.
    Stop any gateway that uses these folders first (a running gateway keeps the file open).

.PARAMETER Root
    The folder holding Corp\Data and Dmz\Data. Default C:\QrBridgeDev.

.PARAMETER Side
    Corp, Dmz or Both (default).

.PARAMETER IncludeBackups
    Also delete the "previous-yyyyMMdd-HHmmss" folders that seed-sample-data.ps1 leaves beside qrbridge.db.

.PARAMETER Force
    Do not ask for confirmation.

.EXAMPLE
    .\clear-sample-data.ps1                         # both sides, asks first
    .\clear-sample-data.ps1 -Side Dmz -Force
    .\clear-sample-data.ps1 -IncludeBackups -Force  # also the previous-… folders
    .\clear-sample-data.ps1 -WhatIf                 # only shows what it would delete
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string] $Root = 'C:\QrBridgeDev',
    [ValidateSet('Corp', 'Dmz', 'Both')]
    [string] $Side = 'Both',
    [switch] $IncludeBackups,
    [switch] $Force
)

$databaseName = 'qrbridge.db'
$fullRoot = [System.IO.Path]::GetFullPath($Root).TrimEnd('\')
$production = [System.IO.Path]::GetFullPath((Join-Path $env:ProgramData 'QrBridge')).TrimEnd('\')
if ($fullRoot.StartsWith($production, [System.StringComparison]::OrdinalIgnoreCase)) {
    Write-Error "Refused: $fullRoot is the production data folder. Archive production rows by hand (never delete them with a script)."
    exit 1
}

$sides = if ($Side -eq 'Both') { @('Corp', 'Dmz') } else { @($Side) }
$targets = @()
foreach ($s in $sides) {
    $folder = Join-Path $fullRoot "$s\Data"
    if (-not (Test-Path -LiteralPath $folder)) { continue }
    foreach ($name in @($databaseName, "$databaseName-wal", "$databaseName-shm")) {
        $file = Join-Path $folder $name
        if (Test-Path -LiteralPath $file) { $targets += $file }
    }
    if ($IncludeBackups) {
        $targets += @(Get-ChildItem -LiteralPath $folder -Directory -Filter 'previous-*' | ForEach-Object { $_.FullName })
    }
}

if ($targets.Count -eq 0) {
    Write-Host "Nothing to delete under $fullRoot ($Side): the databases are already empty or absent."
    exit 0
}

# A running gateway keeps qrbridge.db open: stop before deleting anything rather than leave a database without its -wal.
$inUse = @()
foreach ($file in $targets | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf }) {
    try { [System.IO.File]::Open($file, 'Open', 'ReadWrite', 'None').Dispose() }
    catch { $inUse += $file }
}
if ($inUse.Count -gt 0) {
    Write-Error ("In use: " + ($inUse -join ', ') + ". Stop the gateway (dotnet run / Visual Studio / IIS) that uses this folder, then run the script again.")
    exit 1
}

Write-Host 'To delete:'
$targets | ForEach-Object { Write-Host "  $_" }
# One question for the whole list (ShouldContinue); ShouldProcess below only serves -WhatIf.
if (-not $Force -and -not $WhatIfPreference -and -not $PSCmdlet.ShouldContinue("Delete these $($targets.Count) item(s)?", 'Clear sample data')) {
    Write-Host 'Cancelled.'
    exit 1
}

$failed = $false
foreach ($target in $targets) {
    if (-not $PSCmdlet.ShouldProcess($target, 'Delete')) { continue }
    try {
        Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop
    }
    catch {
        $failed = $true
        Write-Warning "Could not delete $target : $($_.Exception.Message)"
    }
}

if ($failed) {
    Write-Error 'Some files are still in use: stop the gateway (dotnet run / Visual Studio / IIS) that uses this folder, then run the script again.'
    exit 1
}
if (-not $WhatIfPreference) {
    Write-Host "Done. The gateway creates an empty $databaseName at its next start."
}
