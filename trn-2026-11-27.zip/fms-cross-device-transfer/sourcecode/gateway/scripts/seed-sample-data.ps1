<#
.SYNOPSIS
    Fills the Corp and DMZ developer databases with a busy islanding day, to look at the read-only UI.

.DESCRIPTION
    Runs UiDemoDataTests with QRBRIDGE_DEMO_ROOT set (tests/QrBridge.Tests/Ui/Infrastructure/DemoTraffic.cs): both
    real gateways run in memory, exchange real calls over a fake light with fake services behind them, and write every
    row themselves. Result, in the launch profiles' folders:
        {Root}\Corp\Data\qrbridge.db   (Gateway (Corp), http://localhost:5080/qrbridge-ui)
        {Root}\Dmz\Data\qrbridge.db    (Gateway (Dmz),  http://localhost:5090/qrbridge-ui)
    An existing qrbridge.db is moved to a "previous-…" folder beside it (use -Fresh to delete it instead).
    Stop any gateway that uses these folders first. Takes about 20 seconds plus the build.

.PARAMETER Root
    The folder to write Corp\Data and Dmz\Data into. Default C:\QrBridgeDev (as in Properties/launchSettings.json).

.PARAMETER Fresh
    Delete the existing databases and previous-… folders first (clear-sample-data.ps1 -IncludeBackups -Force).

.EXAMPLE
    .\seed-sample-data.ps1
    .\seed-sample-data.ps1 -Fresh
    .\seed-sample-data.ps1 -Root C:\Temp\QrBridgeDemo
#>
[CmdletBinding()]
param(
    [string] $Root = 'C:\QrBridgeDev',
    [switch] $Fresh
)

$fullRoot = [System.IO.Path]::GetFullPath($Root).TrimEnd('\')
$production = [System.IO.Path]::GetFullPath((Join-Path $env:ProgramData 'QrBridge')).TrimEnd('\')
if ($fullRoot.StartsWith($production, [System.StringComparison]::OrdinalIgnoreCase)) {
    Write-Error "Refused: $fullRoot is the production data folder. Sample data is for developer folders only."
    exit 1
}

if ($Fresh) {
    # A child process: the clear script's "exit" would otherwise end this script too.
    & (Get-Process -Id $PID).Path -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'clear-sample-data.ps1') -Root $fullRoot -IncludeBackups -Force
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

$tests = Join-Path $PSScriptRoot '..\tests\QrBridge.Tests'
Write-Host "Writing a busy islanding day into $fullRoot (Corp and Dmz) ..."
$env:QRBRIDGE_DEMO_ROOT = $fullRoot
try {
    # Not under $ErrorActionPreference = 'Stop': dotnet's stderr lines would become terminating errors in PowerShell 5.1.
    & dotnet test $tests --nologo --filter 'FullyQualifiedName~UiDemoDataTests'
    $exitCode = $LASTEXITCODE
}
finally {
    Remove-Item Env:QRBRIDGE_DEMO_ROOT -ErrorAction SilentlyContinue
}

if ($exitCode -ne 0) {
    Write-Error "The sample day failed (dotnet test exit code $exitCode). If it says 'Stop the gateway that uses …', stop it and run again."
    exit $exitCode
}

foreach ($side in @('Corp', 'Dmz')) {
    $database = Join-Path $fullRoot "$side\Data\qrbridge.db"
    $bytes = (Get-ChildItem -Path "$database*" -File | Measure-Object -Property Length -Sum).Sum
    Write-Host ("  {0,-4} {1}  ({2:N0} KB with -wal/-shm)" -f $side, $database, ($bytes / 1KB))
}
Write-Host ''
Write-Host 'Start the gateways (sign in with admin / admin):'
Write-Host '  dotnet run --project sourcecode\gateway\src\QrBridge.Gateway --launch-profile "Gateway (Corp)"   # http://localhost:5080/qrbridge-ui'
Write-Host '  dotnet run --project sourcecode\gateway\src\QrBridge.Gateway --launch-profile "Gateway (Dmz)"    # http://localhost:5090/qrbridge-ui'
Write-Host 'Empty them again with: sourcecode\gateway\scripts\clear-sample-data.ps1'
