# RoundTrip walkthrough: POST and GET, Corp → DMZ and DMZ → Corp

A demo-ready, step-by-step account of what happens to **one caller's call** from the moment it reaches the SOAP
Gateway until the caller gets its answer. For every step: **which class** does it, **which database and table** it
touches, and **what changes**. Then: what happens when no answer comes back, how retries and idempotency work
(`ContentFingerprint`), and how the QrDiode optical link protects the transfer.

What each new class is for, in one paragraph each: [round-trip-files-explained.md](round-trip-files-explained.md).
The QrDiode half (how a bundle crosses the light, step by step):
[light-transfer-walkthrough.md](../../../qrdiode/docs/q_&_a/light-transfer-walkthrough.md).
Full reference: [technical guide](../../../../docs/gateway-to-qrdiode/technical-guide.md) and
[gateway README](../../src/QrBridge.Gateway/README.md).

> **Status legend used on this page**
>
> - ✅ **Built and tested.** Covered by `QrBridge.Tests`, with two real gateways running in memory.
> - 🟡 **Planned.** The **QrDiode Sender and Receiver apps are not connected to the database yet.** In the tests,
>   [FakeLight](../../tests/QrBridge.Tests/Gateway/Infrastructure/FakeLight.cs) plays the light: it calls the same
>   repository methods the QR apps will call (`OutboxRepository.ClaimNextAsync` → `MarkAiredAsync` →
>   `InboxRepository.AddMessageAsync`). The QrDiode encryption itself is built and tested on its own.

**How this page is organised**

| Section | What |
|---|---|
| 1–2 | The short version; programs, the database, its tables and columns |
| **3. Corp → DMZ** | 3.1 POST step by step · 3.2 POST RoundTrip diagram · 3.3 GET step by step · 3.4 GET RoundTrip diagram |
| **4. DMZ → Corp** | 4.1 POST step by step · 4.2 POST RoundTrip diagram · 4.3 GET (not available today) · 4.4 GET diagram |
| 5 | When the answer does not come back |
| 6 | Retries and idempotency, `ContentFingerprint` |
| 7 | How the transfer is protected (QrDiode and the gateway checks) |
| 8–10 | Default numbers, questions the team may ask, what is built |

---

## 1. The 30-second version

```text
Caller ──POST──► Gateway A ──(Outbox)──► QR screen ═══light═══► camera ──(Inbox)──► Gateway B ──POST──► real service
   ▲                │  holds the caller's HTTP request open                              │
   │                │                                                                   ▼
   └──real answer───┘◄──(Inbox)── camera ◄═══light═══ QR screen ◄──(Outbox)── Reply (real answer, byte for byte)

   Outbox and Inbox are tables in qrbridge.db: one file on machine A, another on machine B.
```

1. Gateway A stores the call in its **Outbox** and keeps the caller's HTTP request **open** (the "hold").
2. The QR link carries the message to side B, which stores it in its **Inbox**.
3. Gateway B posts the **same bytes** to the real service, then writes a **Reply** with the real answer into **its**
   Outbox.
4. The QR link carries the Reply back. Gateway A stores it on the original Outbox row and wakes the held caller.
5. The caller gets the **real service's answer**, byte for byte, on the HTTP request it opened in step 1.

The HTTP connection never crosses the light; only messages do. Two **ids** tie the journey together:
`MessageId` (the request) and `CorrelationId` (the Reply and Receipt that answer it).

---

## 2. Who is who

### 2.1 The two directions

|  | **Corp → DMZ** ("Inbound") | **DMZ → Corp** ("Outbound") |
|---|---|---|
| `Direction` value in the data | `CorpToDmz` | `DmzToCorp` |
| Callers | Rapid Restore FCR / FOD / SSO, DSS, FTC, Verizon (on CorpNet) | FMS outbound services (in the DMZ) |
| How callers reach the gateway | Corporate load balancer re-pointed to the **Corp gateway** | FMS interface configuration pointed to the **DMZ gateway** |
| Sender gateway (holds the caller) | **Corp** gateway | **DMZ** gateway |
| Receiver gateway (calls the real service) | **DMZ** gateway → DMZ RR servers (`https://dmz-rr-server` + the caller's path) | **Corp** gateway → corporate systems (*URLs not configured yet*) |
| How long the caller is held | **270 s** (Rapid Restore waits 5 min) | **90 s** (FMS clients time out at 100 s) |
| POST RoundTrip services | `FC2FMS`, `FOD2FMS`, `SSO2FMS`, `SSO2TOMS`, `SSO2TLS`, `SSO2DSO`, `DSS2FMS`, `FTC2FMS.GetFromFMS`, the `*-Legacy` WSDL paths | `FMS2FC`, `FMS2FOD`, `FMS2SSO`, `TLS2SSO`, `TOMS2SSO`, `DSO2SSO`, `FMS2FTC.GetFaultCorrelation` |
| GET RoundTrip services | **`RegisteredTags`** (`/FMS_ReportService/RegisteredTags.asmx/GetData`) | **None.** A GET to the DMZ gateway gets HTTP 405 |
| Which lane carries the Request | Corp screen → DMZ camera | DMZ screen → Corp camera |
| Which lane carries the Reply and Receipt | DMZ screen → Corp camera | Corp screen → DMZ camera |

The code is **identical** on both sides. Only `GatewayDatabase:Side` (`Corp` or `Dmz`) and the hold, expiry and Receiver
settings differ (`appsettings.Corp.json`, `appsettings.Dmz.json`). Which side is the sender for a service is set in
`routes.json` (`SenderSide`). **Both sides must deploy the same `routes.json`**: every message carries its
fingerprint, and a mismatch is Rejected.

### 2.2 Programs on each side

| Program | Runs as | Job in the round trip |
|---|---|---|
| **SOAP Gateway** (`QrBridge.Gateway`) | IIS site | Sender part: accepts and holds callers. Receiver part: calls the real services. ✅ |
| **QrDiode Sender** | WPF exe, kiosk user | Reads the Outbox of `qrbridge.db`, shows messages as QR codes on the screen facing the other side. 🟡 |
| **QrDiode Receiver** | WPF exe, kiosk user | Reads the other side's screen with a camera, writes the Inbox of `qrbridge.db`. 🟡 |

The gateway and the QR apps never call each other. They share only one SQLite file, `qrbridge.db`, in
`C:\ProgramData\QrBridge\Data\` and two named Windows events (the "doorbells": `Global\QrBridge.{Side}.Outbox` and
`Global\QrBridge.{Side}.Inbox`), which only say "look now" and carry no data.

### 2.3 The database and its tables (one `qrbridge.db` on each side)

Each machine has **one** database file, `qrbridge.db`, with six tables. Corp has its own copy and DMZ has its own
copy; the two copies are never connected, only the light carries messages between them. (Until 25 Nov 2026 the same
tables were split over two files, `send.db` and `received.db`. The gateway now refuses to start while either former
file is still in the data folder, because it may hold messages that were accepted but never delivered.)

| Database | Table | Written by | Read by | What it holds |
|---|---|---|---|---|
| `qrbridge.db` | **Outbox** | Gateway (`OutboxWriter` only); status changes by the QR Sender and `AnswerReader` | QR Sender, `SenderEndpoint` (held callers), `AnswerReader` | Everything this side **sends**: Requests from its callers, plus Receipts, Replies and Heartbeats for the other side. Also the **answer** to each Request (`ReplyBody`, `ReplyContentType`, `ServiceHttpStatus`). |
| `qrbridge.db` | **SequenceCounter** | `OutboxWriter` | `OutboxWriter` | The running number per direction (`LastValue`) and its run id (`RunId`). |
| `qrbridge.db` | **Inbox** | QR Receiver (`InboxRepository.AddMessageAsync`); status changes by the gateway | `InboxWorker`, `AnswerReader`, `ReceiptWorker` | Everything that **arrived** from the other side: Requests to deliver here, plus Receipts, Replies and Heartbeats about this side's messages. |
| `qrbridge.db` | **SequenceWatermark** | `SequenceGapMonitor` (via `InboxRepository`) | `ArrivalChecks` | "Every number up to N of that run is settled": old or reused numbers are refused. |
| `qrbridge.db` | **AcknowledgedGap** | Operator (`InboxRepository.AcknowledgeGapAsync`) | `SequenceGapMonitor` | Missing numbers an operator has dealt with. |
| `qrbridge.db` | **Heartbeat** | Gateway workers | `/health` | "Component X is alive" (InboxWorker, MaintenanceWorker). Not the same as a Heartbeat *message*. |

The gateway and both QR apps write to the same file, so they share its one write lock (each write is short; a writer
waits up to 5 s). Every repository method still commits on its own, exactly as before the merge.

Rows are **never deleted automatically** (audit). Operators archive them by hand.

### 2.4 The columns that matter for the round trip

Both tables share these columns ([BaseMessage.cs](../../src/QrBridge.Shared/Data/Entities/BaseMessage.cs)):

| Column | Meaning |
|---|---|
| `MessageId` | The message's id. **Same value** in the sender's Outbox and the receiver's Inbox. |
| `Kind` | `Request`, `Receipt`, `Reply` or `Heartbeat`. Only a `Request` is ever posted to a real service. |
| `CorrelationId` | On a Reply or Receipt: the `MessageId` of the Request it answers. Null on a Request. |
| `ContentFingerprint` | SHA-256 of the business content, ignoring per-send fields. Used to recognise a caller's retry (§6). |
| `Sequence`, `SequenceRunId` | The sender's running number and which run of its counter. Used for ordering, lost-message detection and anti-replay. |
| `ExpiresUtc` | After this time the far side will **not** post it. |
| `Priority` | `Answer` (Receipts, Replies, Heartbeats) first, then `High` (state-changing), `Normal` (queries), `Low` (Bridge feeds). |
| `MessageBytes` | The serialized message: header + SHA-256 checksum + Brotli-compressed body. |
| `LightStatus` | Did it cross the light? |
| `ServiceStatus` | What did the real service do? |

**Outbox status** (sending side):

| `LightStatus` | Meaning | `ServiceStatus` | Meaning |
|---|---|---|---|
| `Pending` | Waiting to be shown | `Waiting` | No Reply yet |
| `Sending` | QR Sender is showing it | `Answered` | Real service accepted it, answer stored |
| `Aired` | Shown, no Receipt yet | `Refused` | Real service refused it (fault, non-zero RETURN_CODE), answer stored |
| `Received` | Far side confirmed it (Receipt or Reply) | `Unknown` | It may have been processed; nobody knows |
| `Failed` | Shown 3 times with no Receipt, or expired: an operator must act | `Expired` / `NotDelivered` / `Rejected` | Surely **not** done on the far side |

**Inbox status** (receiving side): `LightStatus` is `Received` or `Rejected` (failed a check). `ServiceStatus` goes
`Pending` → `Delivering` → `Done`, or `Retrying`, `Refused`, `Unknown`, `Expired`, `NotDelivered`.

---

## 3. Corp → DMZ

The callers are on CorpNet (Rapid Restore FCR / FOD / SSO, DSS, FTC, Verizon). The **Corp gateway** holds them; the
**DMZ gateway** calls the real service. The Request crosses on the **Corp screen → DMZ camera** lane; the Reply and
Receipt come back on the **DMZ screen → Corp camera** lane.

### 3.1 POST: step by step

**Example:** Rapid Restore FCR sends `SendToFMS` with a `REQUEST_FOR_PERMIT` to
`/FMS_FC2FMSInterface/FC2FMSInterface.svc`. In islanding mode the corporate load balancer sends it to the
**Corp gateway**. Route settings: `FC2FMS.SendToFMS` is **RoundTrip**, hold-timeout answer **Pending (1596)**,
`RecogniseRetries` **on**, priority **High**, request limit **38,440 bytes**.

#### Phase A: the Corp gateway accepts the call (Sender part) ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| A1 | [SenderSoapController](../../src/QrBridge.Gateway/Controllers/SenderSoapController.cs) `Post()` | — | Every POST to any path lands here and goes to `SenderEndpoint.HandleAsync`. The body stays raw bytes. |
| A2 | [SenderEndpoint](../../src/QrBridge.Gateway/Ingress/SenderEndpoint.cs) `HandleAsync` | — | Reads the body with a size cap (too big → **HTTP 413**). `SoapRequest.TryParse` reads the envelope through `SafeXml` (no DTDs; not SOAP → **HTTP 400**). `PayloadInspector` reads `MESSAGE/@TYPE` = `REQUEST_FOR_PERMIT`. |
| A3 | `RouteTable.Resolve` | — | Finds path + operation + type in `routes.json`: RoundTrip, 1596 on timeout, retries recognised, High. |
| A4 | `ContractCatalog.Check` | — | The request must match `Contracts/FC2FMS` (the service's WSDL). If not → SOAP fault, **nothing stored**. |
| A5 | `AllowedTypes` check | — | `REQUEST_FOR_PERMIT` must be in the operation's list. If not → reply profile `Rejected` (**1597**). |
| A6 | [ContentFingerprint](../../src/QrBridge.Gateway/Ingress/Soap/ContentFingerprint.cs) `.Compute` | — | Hashes the business content without `MSG_ID`, `GMT_TIME_SENT` and `RRMsgID` (§6). |
| A7 | `SenderEndpoint` builds the `MessageHeader` | — | Service, operation, path, `SOAPAction` and `Content-Type` **exactly as received**, fingerprint, priority, caller's host, and `ExpiresUtc` = now + **600 s** (`Gateway:Expiry`, Corp). |
| A8 | [OutboxWriter](../../src/QrBridge.Gateway/Ingress/OutboxWriter.cs) `.EnqueueAsync` | Corp `qrbridge.db`.**Outbox**, Corp `qrbridge.db`.**SequenceCounter** | **One write transaction:** (1) same fingerprint queued within 30 min? → **attach** to that message and stop (§6.4). (2) Backlog full (5,000 Requests, or the route's own limit)? → **1598 Busy**, nothing stored. (3) Next `Sequence` for `CorpToDmz` from **SequenceCounter**. (4) `MessageSerializer.Serialize`: header + SHA-256 checksum + Brotli body. (5) Insert the **Outbox** row: `Kind=Request`, `Direction=CorpToDmz`, `LightStatus=Pending`, `ServiceStatus=Waiting`. (6) **Commit.** (7) Ring the Corp Outbox doorbell. |
| A9 | `SenderEndpoint` | — | Adds response header `X-QrBridge-MessageId: <MessageId>`, useful when tracing a demo call. |
| A10 | `SenderEndpoint.HoldAsync` + [WaiterRegistry](../../src/QrBridge.Gateway/Ingress/WaiterRegistry.cs) / [Waiter](../../src/QrBridge.Gateway/Ingress/Waiter.cs) | reads Corp `qrbridge.db`.**Outbox** | **The hold (270 s on Corp).** It registers a `Waiter` for the `MessageId`, then loops: read the Outbox row (`FindStateAsync`). Is `ServiceStatus` no longer `Waiting`? → answer the caller. Is the row light `Failed`? → hold-timeout answer at once. Otherwise sleep until woken or for 2 s, then look again, until the hold runs out. |

> **Rule:** the caller is never told "accepted" before the Outbox commit (A8). If the commit fails, the caller gets a
> SOAP fault saying it was **not** accepted.

#### Phase B: the light, Corp → DMZ 🟡

| # | Who | Database.Table | What happens |
|---|---|---|---|
| B1 | Corp QR Sender via `OutboxRepository.ClaimNextAsync` | Corp `qrbridge.db`.**Outbox** | Claims the next row: `Answer` priority first, then `High`, `Normal`, `Low`, lowest `Sequence` first. `Pending` → **`Sending`**, `Attempts + 1`. |
| B2 | QrDiode `SendSession` | — | Encrypts and signs `MessageBytes`, then shows them as a stream of QR codes on the Corp screen (§7). |
| B3 | Corp QR Sender via `OutboxRepository.MarkAiredAsync` | Corp `qrbridge.db`.**Outbox** | `Sending` → **`Aired`**. From now on, "no Receipt within 120 s" means "show it again" (§5.2 #2). |
| B4 | QrDiode `ReceiveEngine` (DMZ camera) | — | Checks frame CRCs, the signature, anti-replay and hashes, then decrypts (§7). |
| B5 | DMZ QR Receiver via `InboxRepository.AddMessageAsync` | DMZ `qrbridge.db`.**Inbox** | Inserts the row: same `MessageId`, `LightStatus=Received`, `ServiceStatus=Pending`, **`ReceiptDueUtc=now`**. If that `MessageId` is already there (a re-air), nothing is inserted; a new Receipt is owed instead. Rings the DMZ Inbox doorbell. |

#### Phase C: the DMZ gateway calls the real service (Receiver part) ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| C1 | DMZ [InboxWorker](../../src/QrBridge.Gateway/Egress/Workers/InboxWorker.cs) (the `High` loop) via `InboxRepository.ClaimNextAsync` | DMZ `qrbridge.db`.**Inbox** | Woken by the doorbell (or polls every 2 s). Claims the next Request of its class in sender order: `Pending` → **`Delivering`**, `LockedUtc=now`, `Attempts + 1`. One loop per priority, so a slow feed never holds back a permit. |
| C2 | `MessageSerializer.Deserialize` | — | Verifies the SHA-256 checksum, then unpacks the body (decompression is size-capped). Corrupt → **Rejected**. |
| C3 | [ArrivalChecks](../../src/QrBridge.Gateway/Egress/ArrivalChecks.cs) `.CheckAsync` | DMZ `qrbridge.db`.**Inbox**, **SequenceWatermark** | Header matches the row, same `routes.json`, direction is `CorpToDmz`, known format, not older than 7 days, not more than 60 min in the future, sequence number not reused. Pass → `Verified=true`. Fail → **Rejected** (§7.4). |
| C4 | `InboxWorker.Plan` | — | Is this a Request? Is `FC2FMS` delivered on *this* side (its `SenderSide` is Corp, so yes on DMZ)? Is the operation bridged? Target URL from DMZ **configuration** only: `Gateway:Receiver:Targets:FC2FMS:Url`, else `https://dmz-rr-server` + the caller's path. No target → **NotDelivered**. |
| C5 | Expiry check | — | `ExpiresUtc` passed → **Expired**, not posted (§5.2 #9). |
| C6 | Same-content check (`InboxRepository.FindSameContentAsync`) | DMZ `qrbridge.db`.**Inbox** | Because `RecogniseRetries` is on: same fingerprint arrived within 30 min and is `Done` → don't post; reuse its answer. `Unknown` or still `Delivering` → don't post; **Unknown** (§6.4). |
| C7 | [SoapForwarderHttpClient](../../src/QrBridge.Gateway/Egress/SoapForwarderHttpClient.cs) `.ForwardAsync` | — | **POSTs the caller's original bytes** with the original `SOAPAction` and `Content-Type`. Only `wsa:To` is re-pointed, for WS-Addressing callers. HTTPS only; 15 s to connect, 120 s for the call; redirects are not followed. |
| C8 | `SoapForwarderHttpClient.Classify` | — | Turns the answer into a verdict: **Delivered** (2xx and `RETURN_CODE 0`), **Refused** (fault, non-zero code, 4xx), **Transient** (surely not sent: DNS, refused, connect timeout, TLS, 408, 429 → retried with backoff), **Unknown** (may have been processed: timeout after sending, reset, 500/502/503/504, unreadable 2xx). Keeps the real **status code, Content-Type and body**. |

#### Phase D: the DMZ gateway sends the answer back ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| D1 | DMZ [AnswerWriter](../../src/QrBridge.Gateway/Egress/AnswerWriter.cs) `.FinishAsync` | DMZ `qrbridge.db`.**Outbox** | **First** writes a **Reply** through `OutboxWriter`: `Kind=Reply`, `Direction=DmzToCorp`, `CorrelationId` = the Request's `MessageId`, `Outcome`, `ServiceHttpStatus`, a plain-words comment, and the **real answer byte for byte** (dropped, with a note, if over 1,000,000 bytes). Priority `Answer`, so it goes on air before any Request. |
| D2 | `AnswerWriter` → `InboxRepository.MarkDoneAsync` (or `Refused`, `Unknown`…) | DMZ `qrbridge.db`.**Inbox** | **Then** marks the Inbox row with the same outcome and saves `DownstreamResult` (e.g. `RETURN_CODE=0`). A `Done` row's `MessageBytes` are emptied: no plaintext kept once finished. |
| D3 | DMZ [ReceiptWorker](../../src/QrBridge.Gateway/Egress/Workers/ReceiptWorker.cs) → `AnswerWriter.SendDueReceiptsAsync` | DMZ `qrbridge.db`.**Inbox** → DMZ `qrbridge.db`.**Outbox** | Every 2 s, for every row with `ReceiptDueUtc`: queues an empty **Receipt** (`CorrelationId` = the arrived message), then clears `ReceiptDueUtc`. Its own loop, so a slow POST never delays Receipts. |
| D4 | DMZ QR Sender → Corp QR Receiver 🟡 | DMZ `qrbridge.db`.**Outbox** → Corp `qrbridge.db`.**Inbox** | Same as Phase B, on the DMZ screen → Corp camera lane. Reply and Receipt are aired before any Request. |

> **Why Reply first, then the Inbox row?** If the gateway crashes in between, the Reply already exists.
> `MaintenanceWorker` → `AnswerWriter.RecoverStuckAsync` finds the row still `Delivering` and settles it from that
> Reply. The other order could lose the answer.

#### Phase E: the Corp gateway gives the caller the answer ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| E1 | Corp [AnswerReader](../../src/QrBridge.Gateway/Ingress/AnswerReader.cs) (polls every 2 s) via `InboxRepository.FindArrivedAnswersAsync` | Corp `qrbridge.db`.**Inbox** | Reads arrived Receipts, Replies and Heartbeats (never posted to any service). |
| E2 | `ArrivalChecks.CheckAsync` | Corp `qrbridge.db`.**Inbox** | The same checks as C3; the direction must be `DmzToCorp`. |
| E3 | `AnswerReader` → `OutboxRepository.FindStateAsync` | Corp `qrbridge.db`.**Outbox** | The `CorrelationId` must name a Request **this side sent**, with the same service and operation. Otherwise → **Rejected**. |
| E4a | **Receipt** → `OutboxRepository.MarkReceivedAsync` | Corp `qrbridge.db`.**Outbox** | `LightStatus` → **`Received`**: it crossed, so stop re-airing it. |
| E4b | **Reply** → `OutboxRepository.MarkAnsweredAsync` | Corp `qrbridge.db`.**Outbox** | Sets `ServiceStatus` (`Answered`, `Refused`, `Unknown`, `Expired`, `NotDelivered`, `Rejected`), `ServiceHttpStatus`, `ReplyContentType`, **`ReplyBody`**, `ReplyCreatedUtc`, and light `Received`. It only writes if the row is still `Waiting`; a later Reply never overwrites an `Answered` one. |
| E5 | `WaiterRegistry.Wake(MessageId)` | — | Wakes every held caller for that message (the original and any attached retries). |
| E6 | `AnswerReader` → `InboxRepository.MarkDoneAsync` | Corp `qrbridge.db`.**Inbox** | The Reply or Receipt row is used: `Done`. |
| E7 | `SenderEndpoint.HoldAsync` → `AnswerFrom` | reads Corp `qrbridge.db`.**Outbox** | The woken caller reads its row. `Answered` or `Refused` with a body → **the real HTTP status, Content-Type and body, byte for byte**. Otherwise **1596** or **1599** (§5.1). |
| E8 | `SenderEndpoint` writes the response | — | The caller's HTTP request, open since A1, completes. |

### 3.2 POST RoundTrip diagram (Corp → DMZ)

```mermaid
sequenceDiagram
    autonumber
    participant C as Caller (Rapid Restore, CorpNet)
    participant GA as Corp gateway
    participant SA as Corp qrbridge.db / Outbox
    participant L1 as QR lane Corp→DMZ
    participant RB as DMZ qrbridge.db / Inbox
    participant GB as DMZ gateway
    participant S as Real service (DMZ RR server)
    participant SB as DMZ qrbridge.db / Outbox
    participant L2 as QR lane DMZ→Corp
    participant RA as Corp qrbridge.db / Inbox

    C->>GA: POST SOAP (HTTP request stays open)
    GA->>GA: parse, route, WSDL + type checks, ContentFingerprint
    GA->>SA: OutboxWriter: Request CorpToDmz (Pending/Waiting), commit
    GA->>GA: HoldAsync: register Waiter, re-read Outbox every 2 s (270 s)
    SA->>L1: Corp QR Sender airs it (Sending → Aired) 🟡
    L1->>RB: DMZ QR Receiver: AddMessageAsync (Received/Pending, Receipt owed) 🟡
    RB->>GB: InboxWorker (High loop) claims it (Delivering)
    GB->>GB: ArrivalChecks, Plan, expiry, same-content check
    GB->>S: SoapForwarderHttpClient: POST same bytes, SOAPAction, Content-Type
    S-->>GB: real answer (HTTP status + body)
    GB->>SB: AnswerWriter: Reply with the real answer FIRST
    GB->>RB: then mark the Inbox row Done
    GB->>SB: ReceiptWorker: Receipt
    SB->>L2: DMZ QR Sender airs Reply + Receipt (Priority Answer: first) 🟡
    L2->>RA: Corp QR Receiver stores them 🟡
    RA->>GA: AnswerReader: ArrivalChecks, then MarkAnsweredAsync on the Outbox row
    GA->>GA: WaiterRegistry.Wake(MessageId)
    alt Reply arrived within 270 s with the real answer
        GA-->>C: the real answer, byte for byte
    else hold ran out, or the far side says Unknown
        GA-->>C: 1596 "sent, confirmation not yet received"
    else surely not done (Expired, NotDelivered, Rejected)
        GA-->>C: 1599 "not available"
    end
```

### 3.3 GET: step by step

**Example:** a Corp client calls `GET /FMS_ReportService/RegisteredTags.asmx/GetData`. This is the **only** GET route
(`"HttpGet": true`, `SenderSide: Corp` in `routes.json`). Route settings: one operation named `GET`, **RoundTrip**,
hold-timeout answer **Unavailable** (it is a read-only query), `RecogniseRetries` **off**, priority **Normal**, no
reply profile, no WSDL.

Phases **B** (light) and **D** (answer back) are the **same classes and tables as the POST** (§3.1); they are repeated
here in short so the GET can be told on its own.

#### Phase A: the Corp gateway accepts the GET ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| A1 | [SenderSoapController](../../src/QrBridge.Gateway/Controllers/SenderSoapController.cs) `Get()` | — | Every GET lands here and goes to **`SenderEndpoint.HandleGetAsync`**. |
| A2 | `HandleGetAsync` → `RouteTable.FindByPath` | — | The path must belong to a route with **`HttpGet: true` whose `SenderSide` is this side** (Corp). Anything else (WSDL, `?wsdl`, help pages, any other path) → **HTTP 405**, nothing stored. |
| A3 | `HandleGetAsync` | — | A **query string** is refused → **HTTP 400** (it is not carried across). |
| A4 | `RouteTable.Resolve(path, "GET")` | — | Mode must be **RoundTrip**. If an operator switched it to `Unavailable` → **HTTP 504** at once, nothing stored. |
| A5 | `HandleGetAsync` builds the `MessageHeader` | — | Service `RegisteredTags`, operation `GET`, the path, **`PayloadFormat=HttpGet`**, empty `Content-Type`, **no `ContentFingerprint`**, priority Normal, caller's host, and **`ExpiresUtc` = now + hold (270 s)**: a GET whose caller has given up is never run later. No body, so no SOAP parse, WSDL or type check. |
| A6 | [OutboxWriter](../../src/QrBridge.Gateway/Ingress/OutboxWriter.cs) `.EnqueueAsync(header, [], attachRetries: false)` | Corp `qrbridge.db`.**Outbox**, Corp `qrbridge.db`.**SequenceCounter** | Same transaction as the POST: backlog check, next `Sequence`, serialize, insert the **Outbox** row (`Kind=Request`, `PayloadFormat=HttpGet`, empty body, `Pending`/`Waiting`), commit, ring the doorbell. **No retry attach.** Backlog full or store failure → **HTTP 504**. |
| A7 | `HandleGetAsync` | — | Adds `X-QrBridge-MessageId`. |
| A8 | `SenderEndpoint.HoldAsync` + `WaiterRegistry` / `Waiter` | reads Corp `qrbridge.db`.**Outbox** | **The same hold as the POST** (270 s, re-read every 2 s, woken by `AnswerReader`). |

#### Phase B: the light, Corp → DMZ 🟡

| # | Who | Database.Table | What happens |
|---|---|---|---|
| B1–B3 | Corp QR Sender (`ClaimNextAsync`, `MarkAiredAsync`) | Corp `qrbridge.db`.**Outbox** | `Pending` → `Sending` → `Aired`. A GET is small (header only), so it airs quickly. |
| B4–B5 | DMZ QR Receiver (`AddMessageAsync`) | DMZ `qrbridge.db`.**Inbox** | Row inserted with `PayloadFormat=HttpGet`, `Received`/`Pending`, Receipt owed. |

#### Phase C: the DMZ gateway calls the real service ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| C1 | DMZ `InboxWorker` (the **`Normal`** loop) via `ClaimNextAsync` | DMZ `qrbridge.db`.**Inbox** | `Pending` → **`Delivering`**. |
| C2 | `MessageSerializer.Deserialize` | — | Checksum verified; the body is empty. |
| C3 | `ArrivalChecks.CheckAsync` | DMZ `qrbridge.db`.**Inbox**, **SequenceWatermark** | Same checks as the POST; `HttpGet` is an accepted payload format. |
| C4 | `InboxWorker.Plan` | — | An `HttpGet` message is only sent to the route marked `HttpGet` (and that route never gets a SOAP message); anything else → **Rejected**. Marked as a **query** (fail fast) with **no retry recognition**. Target URL from DMZ configuration: `Gateway:Receiver:Targets:RegisteredTags:Url`, else `https://dmz-rr-server` + the path. |
| C5 | Expiry check | — | Past `ExpiresUtc` (its caller's hold has ended) → **Expired**, not called. |
| C6 | *(no same-content check)* | — | GET has no fingerprint: it always asks the real service again. |
| C7 | `SoapForwarderHttpClient.ForwardAsync` | — | Sends a **`GET` with no body** to the target URL. HTTPS only, no redirects, same timeouts. |
| C8 | `SoapForwarderHttpClient.Classify` | — | No reply profile, so any **2xx = Delivered**; fault or 4xx = Refused; may-have-arrived = Unknown. **Surely not sent** (DNS, refused, connect timeout…) → **NotDelivered at once, no retry**: the caller is waiting. The real status, Content-Type and body are kept. |

#### Phase D: the DMZ gateway sends the answer back ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| D1 | `AnswerWriter.FinishAsync` | DMZ `qrbridge.db`.**Outbox** | **Reply first**: outcome, HTTP status, and the real answer byte for byte (the report's HTML, XML or text). |
| D2 | `InboxRepository.MarkDoneAsync` (or other outcome) | DMZ `qrbridge.db`.**Inbox** | Then the Inbox row is marked. |
| D3 | `ReceiptWorker` | DMZ `qrbridge.db`.**Inbox** → DMZ `qrbridge.db`.**Outbox** | The Receipt. |
| D4 | DMZ QR Sender → Corp QR Receiver 🟡 | → Corp `qrbridge.db`.**Inbox** | Reply and Receipt cross, first in line. |

#### Phase E: the Corp gateway gives the caller the answer ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| E1–E6 | Corp `AnswerReader`, `ArrivalChecks`, `OutboxRepository.MarkAnsweredAsync`, `WaiterRegistry.Wake` | Corp `qrbridge.db`.**Inbox**, Corp `qrbridge.db`.**Outbox** | **Identical to the POST** (§3.1 Phase E). |
| E7 | `HandleGetAsync` (its own answer rule, not `AnswerFrom`) | reads Corp `qrbridge.db`.**Outbox** | `Answered` or `Refused` **with** a body → **the real status, Content-Type and body, byte for byte**. Anything else (no body, `Unknown`, `Expired`, `NotDelivered`, `Rejected`, light `Failed`, hold ran out) → **HTTP 504** `text/plain`: "RegisteredTags is not available while the network is islanded: no answer came back over the QR bridge in time." |

**POST and GET compared:**

| | POST RoundTrip | GET RoundTrip |
|---|---|---|
| Entry method | `HandleAsync` | `HandleGetAsync` |
| Checks before storing | SOAP parse, WSDL, type allow-list, size | Route must be `HttpGet` on this side; no query string |
| `PayloadFormat`, body | `RawSoap`, the caller's SOAP bytes | `HttpGet`, empty |
| `ContentFingerprint`, retry attach | Yes (state-changing calls) | No |
| `ExpiresUtc` | now + 600 s | now + hold (270 s) |
| Priority | High (state-changing) / Normal (query) | Normal |
| Far side call | POST, same bytes, SOAPAction, Content-Type | GET, no body |
| Not sent at all | Retried with backoff (state-changing) | NotDelivered at once |
| Caller gets when no real answer | 1596 or 1599 (SOAP reply) | HTTP 504 (plain text) |

### 3.4 GET RoundTrip diagram (Corp → DMZ)

```mermaid
sequenceDiagram
    autonumber
    participant C as Corp client
    participant GA as Corp gateway
    participant SA as Corp qrbridge.db / Outbox
    participant L1 as QR lane Corp→DMZ
    participant RB as DMZ qrbridge.db / Inbox
    participant GB as DMZ gateway
    participant S as Registered Tags service (DMZ)
    participant SB as DMZ qrbridge.db / Outbox
    participant L2 as QR lane DMZ→Corp
    participant RA as Corp qrbridge.db / Inbox

    C->>GA: GET /FMS_ReportService/RegisteredTags.asmx/GetData (HTTP request stays open)
    GA->>GA: HandleGetAsync: HttpGet route, SenderSide Corp, no query string, RoundTrip
    GA->>SA: OutboxWriter: Request CorpToDmz, PayloadFormat HttpGet, empty body, ExpiresUtc = now + 270 s
    GA->>GA: HoldAsync: register Waiter, re-read Outbox every 2 s (270 s)
    SA->>L1: Corp QR Sender airs it 🟡
    L1->>RB: DMZ QR Receiver: AddMessageAsync (Receipt owed) 🟡
    RB->>GB: InboxWorker (Normal loop) claims it (Delivering)
    GB->>GB: ArrivalChecks, Plan (HttpGet route only, query), expiry
    GB->>S: SoapForwarderHttpClient: GET, no body
    S-->>GB: real answer (HTTP status + body)
    GB->>SB: AnswerWriter: Reply with the real answer FIRST
    GB->>RB: then mark the Inbox row Done
    GB->>SB: ReceiptWorker: Receipt
    SB->>L2: DMZ QR Sender airs Reply + Receipt (first in line) 🟡
    L2->>RA: Corp QR Receiver stores them 🟡
    RA->>GA: AnswerReader: ArrivalChecks, then MarkAnsweredAsync on the Outbox row
    GA->>GA: WaiterRegistry.Wake(MessageId)
    alt Reply arrived within 270 s with the real answer
        GA-->>C: the real answer, byte for byte
    else no answer in time, or not done
        GA-->>C: HTTP 504 text/plain "not available while the network is islanded"
    end
```

---

## 4. DMZ → Corp

The callers are the FMS outbound services in the DMZ. FMS's interface configuration points them at the **DMZ
gateway**, which holds them; the **Corp gateway** calls the real corporate service. The Request crosses on the
**DMZ screen → Corp camera** lane; the Reply and Receipt come back on the **Corp screen → DMZ camera** lane. The code
is the same as Corp → DMZ; only the side, the hold (90 s) and the Receiver addresses differ.

> **Open item, important for the demo:** the Corp Receiver addresses are still **empty** (`appsettings.Corp.json`:
> `DefaultBaseUrl` and `Targets`), and most DMZ → Corp contracts are derived from client proxies and need
> confirming. Today, a DMZ → Corp Request reaching the Corp gateway ends **NotDelivered** at step C4 ("No Receiver
> target"), and the FMS caller gets **1599 not available**. Everything else below is built and tested.

### 4.1 POST: step by step

**Example:** FMS sends `CreateCard` with `CARD_CREATE` to `/FMSRRFCInterface/FMS2RRFCInterface.svc`, which FMS now
sends to the **DMZ gateway**. Route settings: `FMS2FC.CreateCard` is **RoundTrip**, `SenderSide: Dmz`, hold-timeout
answer **Pending (1596)**, `RecogniseRetries` **on**, priority **High**, WSDL `Contracts/FMS2FC`, request limit
`GatewayDatabase:MaxPayloadBytes` (1,000,000 bytes).

#### Phase A: the DMZ gateway accepts the call (Sender part) ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| A1 | `SenderSoapController.Post()` | — | The FMS POST lands here → `SenderEndpoint.HandleAsync`. |
| A2 | `SenderEndpoint.HandleAsync` | — | Size cap (413), `SafeXml` parse (400), `PayloadInspector` reads the type `CARD_CREATE`. |
| A3 | `RouteTable.Resolve` | — | `FMS2FC.CreateCard`: RoundTrip, 1596 on timeout, retries recognised, High. |
| A4 | `ContractCatalog.Check` | — | Must match `Contracts/FMS2FC`. If not → SOAP fault, nothing stored. |
| A5 | `AllowedTypes` check | — | `CARD_CREATE` must be allowed. If not → **1597**. |
| A6 | `ContentFingerprint.Compute` | — | Business content without `MSG_ID`, `GMT_TIME_SENT`, `RRMsgID`. |
| A7 | `SenderEndpoint` builds the `MessageHeader` | — | As for Corp → DMZ; `ExpiresUtc` = now + **600 s** (`Gateway:Expiry`, DMZ). |
| A8 | `OutboxWriter.EnqueueAsync` | DMZ `qrbridge.db`.**Outbox**, DMZ `qrbridge.db`.**SequenceCounter** | Retry attach (30 min), backlog (1598), next `Sequence` for **`DmzToCorp`**, serialize, insert the Outbox row (`Direction=DmzToCorp`, `Pending`/`Waiting`), commit, ring the **DMZ** Outbox doorbell. |
| A9 | `SenderEndpoint` | — | `X-QrBridge-MessageId` header. |
| A10 | `SenderEndpoint.HoldAsync` + `WaiterRegistry` / `Waiter` | reads DMZ `qrbridge.db`.**Outbox** | **The hold (90 s on DMZ**, because FMS clients time out at 100 s). Same loop: re-read every 2 s, woken by the DMZ `AnswerReader`. |

#### Phase B: the light, DMZ → Corp 🟡

| # | Who | Database.Table | What happens |
|---|---|---|---|
| B1–B3 | DMZ QR Sender (`ClaimNextAsync`, `MarkAiredAsync`) | DMZ `qrbridge.db`.**Outbox** | `Pending` → `Sending` → `Aired`, shown on the **DMZ screen**. |
| B4 | QrDiode `ReceiveEngine` (**Corp camera**) | — | CRC, signature, anti-replay, hashes, decryption (§7). |
| B5 | Corp QR Receiver (`AddMessageAsync`) | Corp `qrbridge.db`.**Inbox** | Row inserted, `Received`/`Pending`, Receipt owed; duplicates only re-receipted. Rings the Corp Inbox doorbell. |

#### Phase C: the Corp gateway calls the real service (Receiver part) ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| C1 | Corp `InboxWorker` (the `High` loop) | Corp `qrbridge.db`.**Inbox** | Claims it: `Pending` → `Delivering`. |
| C2 | `MessageSerializer.Deserialize` | — | Checksum, decompress (capped). Corrupt → Rejected. |
| C3 | `ArrivalChecks.CheckAsync` | Corp `qrbridge.db`.**Inbox**, **SequenceWatermark** | Same checks; the Corp side accepts only **`DmzToCorp`**. |
| C4 | `InboxWorker.Plan` | — | `FMS2FC`'s `SenderSide` is Dmz, so the Corp side delivers it. Target URL from **Corp** configuration: `Gateway:Receiver:Targets:FMS2FC:Url`, else `DefaultBaseUrl` + the path. **Today both are empty → NotDelivered** + Reply (see the open item above). |
| C5 | Expiry check | — | Past `ExpiresUtc` → Expired. |
| C6 | Same-content check | Corp `qrbridge.db`.**Inbox** | As for Corp → DMZ: an earlier `Done` copy → its answer is reused; `Unknown` or `Delivering` → Unknown. |
| C7 | `SoapForwarderHttpClient.ForwardAsync` | — | POSTs the FMS caller's original bytes to the **corporate** service (Rapid Restore FC), same `SOAPAction` and `Content-Type`. |
| C8 | `SoapForwarderHttpClient.Classify` | — | Delivered, Refused, Transient (retried with backoff), or Unknown, exactly as Corp → DMZ. |

#### Phase D: the Corp gateway sends the answer back ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| D1 | Corp `AnswerWriter.FinishAsync` | Corp `qrbridge.db`.**Outbox** | **Reply first** (`Direction=CorpToDmz`, `CorrelationId` = the FMS Request's id, the real answer byte for byte). |
| D2 | `InboxRepository.Mark…Async` | Corp `qrbridge.db`.**Inbox** | Then the Inbox row's outcome; a `Done` row's bytes are emptied. |
| D3 | Corp `ReceiptWorker` | Corp `qrbridge.db`.**Inbox** → Corp `qrbridge.db`.**Outbox** | The Receipt. |
| D4 | Corp QR Sender → DMZ QR Receiver 🟡 | → DMZ `qrbridge.db`.**Inbox** | On the **Corp screen → DMZ camera** lane, first in line. |

#### Phase E: the DMZ gateway gives FMS the answer ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| E1–E3 | DMZ `AnswerReader`, `ArrivalChecks`, `OutboxRepository.FindStateAsync` | DMZ `qrbridge.db`.**Inbox**, DMZ `qrbridge.db`.**Outbox** | Reads the Reply and Receipt; checks them (direction **`CorpToDmz`**); the `CorrelationId` must be an FMS Request this side sent. |
| E4 | `MarkReceivedAsync` / `MarkAnsweredAsync` | DMZ `qrbridge.db`.**Outbox** | Receipt → light `Received`. Reply → service status, real status, Content-Type and body stored. |
| E5–E6 | `WaiterRegistry.Wake`, `InboxRepository.MarkDoneAsync` | DMZ `qrbridge.db`.**Inbox** | Held FMS caller woken; the Reply row is `Done`. |
| E7–E8 | `SenderEndpoint.HoldAsync` → `AnswerFrom` | reads DMZ `qrbridge.db`.**Outbox** | Real answer byte for byte; otherwise **1596** or **1599** (§5.1). |

**DMZ → Corp queries** (`OnHoldTimeout: Unavailable`): `FMS2FC.PortalSyncRequest` and `FMS2FTC.GetFaultCorrelation`.
They follow the same steps but, like the GET, are priority Normal, have no retry attach, expire with the 90 s hold,
are not retried when nothing was sent, and answer **1599** when no real answer comes back.

### 4.2 POST RoundTrip diagram (DMZ → Corp)

```mermaid
sequenceDiagram
    autonumber
    participant F as Caller (FMS, DMZ)
    participant GB as DMZ gateway
    participant SB as DMZ qrbridge.db / Outbox
    participant L2 as QR lane DMZ→Corp
    participant RA as Corp qrbridge.db / Inbox
    participant GA as Corp gateway
    participant S as Real service (corporate, e.g. Rapid Restore FC)
    participant SA as Corp qrbridge.db / Outbox
    participant L1 as QR lane Corp→DMZ
    participant RB as DMZ qrbridge.db / Inbox

    F->>GB: POST SOAP CreateCard (HTTP request stays open)
    GB->>GB: parse, route, WSDL + type checks, ContentFingerprint
    GB->>SB: OutboxWriter: Request DmzToCorp (Pending/Waiting), commit
    GB->>GB: HoldAsync: register Waiter, re-read Outbox every 2 s (90 s)
    SB->>L2: DMZ QR Sender airs it (Sending → Aired) 🟡
    L2->>RA: Corp QR Receiver: AddMessageAsync (Received/Pending, Receipt owed) 🟡
    RA->>GA: InboxWorker (High loop) claims it (Delivering)
    GA->>GA: ArrivalChecks, Plan (Corp Receiver target: not configured yet), expiry, same-content check
    GA->>S: SoapForwarderHttpClient: POST same bytes, SOAPAction, Content-Type
    S-->>GA: real answer (HTTP status + body)
    GA->>SA: AnswerWriter: Reply with the real answer FIRST
    GA->>RA: then mark the Inbox row Done
    GA->>SA: ReceiptWorker: Receipt
    SA->>L1: Corp QR Sender airs Reply + Receipt (first in line) 🟡
    L1->>RB: DMZ QR Receiver stores them 🟡
    RB->>GB: AnswerReader: ArrivalChecks, then MarkAnsweredAsync on the Outbox row
    GB->>GB: WaiterRegistry.Wake(MessageId)
    alt Reply arrived within 90 s with the real answer
        GB-->>F: the real answer, byte for byte
    else hold ran out, or the far side says Unknown
        GB-->>F: 1596 "sent, confirmation not yet received"
    else surely not done (today: no Corp Receiver target → NotDelivered)
        GB-->>F: 1599 "not available"
    end
```

### 4.3 GET: step by step

**There is no GET RoundTrip from DMZ to Corp today.** The only GET route, Registered Tags, has `SenderSide: Corp`.
What happens when anything sends a GET to the DMZ gateway:

| # | Who | Database.Table | What happens |
|---|---|---|---|
| A1 | `SenderSoapController.Get()` → `SenderEndpoint.HandleGetAsync` | — | The GET arrives. |
| A2 | `RouteTable.FindByPath` | — | No route has `HttpGet: true` **and** `SenderSide: Dmz`. Even the Registered Tags path is refused here, because its sender side is Corp. |
| A3 | `HandleGetAsync` | — | **HTTP 405 Method Not Allowed.** Nothing is stored in any table, nothing crosses the light, nothing is called. |

**To add one** (configuration, not code): a `routes.json` service with `"HttpGet": true`, `"SenderSide": "Dmz"`, one
path, one operation `"GET"` in `RoundTrip` mode with `"OnHoldTimeout": "Unavailable"`; a Corp Receiver target for it;
a test; and the **same `routes.json` on both gateways**. The flow would then be §3.3 with the sides swapped: DMZ
gateway holds the caller for 90 s, `DmzToCorp` Request with an empty body, Corp `InboxWorker` sends the GET, the Reply
comes back on the Corp → DMZ lane, and the caller gets the real answer or HTTP 504.

### 4.4 GET RoundTrip diagram (DMZ → Corp)

What happens **today**:

```mermaid
sequenceDiagram
    autonumber
    participant F as Any client (DMZ)
    participant GB as DMZ gateway
    F->>GB: GET (any path, including RegisteredTags)
    GB->>GB: HandleGetAsync: no HttpGet route with SenderSide Dmz
    GB-->>F: HTTP 405 Method Not Allowed
    Note over GB: nothing stored, nothing crosses the light
```

---

## 5. When the answer does not come back

### 5.1 What the held caller gets

| What is in the Outbox row when the caller looks | POST, state-changing (OnHoldTimeout `Pending`) | POST query (OnHoldTimeout `Unavailable`) | GET (Registered Tags) |
|---|---|---|---|
| `Answered` or `Refused` **with** a body | **Real answer** (status, Content-Type, body) | **Real answer** | **Real answer** |
| `Answered`, `Refused` or `Unknown` **without** a body | Hold-timeout answer **1596** | **1599** | **504** |
| `Expired`, `NotDelivered`, `Rejected` (surely not done) | **1599** "not available" | **1599** | **504** |
| Still `Waiting` when the hold runs out | **1596** "sent, confirmation not yet received" | **1599** | **504** |
| Light **`Failed`** (aired 3× with no Receipt, or expired before confirmed) | **1596 at once**, without waiting out the hold | **1599 at once** | **504 at once** |
| Outbox backlog full | **1598** "busy, NOT accepted, retry later" | **1598** | **504** |

`1596`, `1597`, `1598` and `1599` are the bridge's own codes (reply profiles in `routes.json`). They are never
success values. Which operations are queries: `OnHoldTimeout: Unavailable` in `routes.json`, e.g.
`GetFromFMS` with `AUTHORIZE_USERS` or `GET_FEEDER_INFO`, `FTC2FMS` `GET_RELAY_TARGET`, `PortalSyncRequest`,
`FMS2FTC.GetFaultCorrelation`, and the Registered Tags GET.

### 5.2 Scenario by scenario

| # | What went wrong | What the system does | What the caller sees | Who/what acts |
|---|---|---|---|---|
| 1 | **The light is slow**; the answer arrives after the hold | The message keeps going. The far side still delivers it, **until `ExpiresUtc`** (600 s for state-changing calls). The Reply is stored in the Outbox when it arrives. | **1596** now. If it **retries** (same content, within 30 min), the retry is **attached** and gets the **stored real answer** at once. | Automatic |
| 2 | **Request lost on the light** (no Receipt) | `MaintenanceWorker` → `OutboxRepository.ReairUnconfirmedAsync`: `Aired` with no Receipt for 120 s → back to `Pending` → aired again. After **3 airs**, or once past `ExpiresUtc` → light **`Failed`** + a `Light:` warning. | Held caller: still waiting → after `Failed`, the hold-timeout answer at once. | Automatic, then operator |
| 3 | **The same message arrives twice** (re-aired after a lost Receipt) | `InboxRepository.AddMessageAsync` skips the duplicate `MessageId` and owes a **new Receipt**. It is **never** delivered twice. | Nothing | Automatic |
| 4 | **Reply lost on the light** | The far side re-airs the Reply (a Reply gets a Receipt like a Request, so scenario 2 applies to it). | Gets the answer on a later re-air, or 1596. | Automatic |
| 5 | **Receipt lost** | Not re-aired. The original Request is re-aired instead (scenario 2); the far side skips it (scenario 3) and sends a new Receipt. | Nothing | Automatic |
| 6 | **Real service unreachable**: nothing was sent (DNS, refused, connect timeout, TLS, 408, 429) | **State-changing:** `Retrying` with backoff 30 s, 60 s, 120 s… (max 30 min), up to **8 tries**, then **NotDelivered** + Reply. Strict order: later Requests of that service and class wait. **Query or GET:** **NotDelivered at once** + Reply. | State-changing: probably 1596 (the hold ends first), later 1599 on a retry. Query: 1599. GET: 504. | Automatic, then operator |
| 7 | **Service may have processed it** (timeout after sending, reset, 500/502/503/504, unreadable 2xx) | **Unknown.** **Never re-posted automatically**: it could duplicate a permit. Unknown Reply sent back. `Service:` warning. | **1596** (or 1599 for a query) | **Operator** checks, then requeues |
| 8 | **Service refused it** (SOAP fault, `RETURN_CODE` ≠ 0, 4xx) | **Refused**, with the real answer in the Reply. | The **real refusal**, byte for byte | Operator if needed |
| 9 | **It arrives after `ExpiresUtc`** | **Expired**, not posted (a dispatcher may have gone verbal). | 1599, or already 1596 | Automatic |
| 10 | **Far gateway crashed or recycled during the POST** | `MaintenanceWorker` → `AnswerWriter.RecoverStuckAsync` after 5 min: uses the Reply already written for this attempt if there is one, otherwise **Unknown**. Never re-posted. | 1596 | Operator |
| 11 | **Caller hangs up** while held | The message **stays queued** and is still delivered. A retry with the same content gets the stored answer. | — | Automatic |
| 12 | **Sender gateway recycled** while holding callers | The held HTTP requests are lost (the caller sees a dropped connection). The Outbox rows are safe on disk; the answer is stored when it arrives. A retry gets it. | Connection error, then the answer on a retry | Automatic |
| 13 | **Far side completely silent** (light down or far gateway down) | Each side sends a **Heartbeat** after 5 min of nothing to send. Nothing heard for **15 min** → `/health` **unhealthy** + `Light: nothing heard from the far side since…` | Hold-timeout answers | Operator, load balancer |
| 14 | **A message is lost for good** (gap in the numbers) | `SequenceGapMonitor` (every minute): "numbers 41–42 of run X never arrived", after 5 min grace. Shown on `/health`, logged once. | — | Operator acknowledges |
| 15 | **Answer too large** (> 1,000,000 bytes) | The Reply carries the outcome but **not** the body, and its comment says why. | 1596 (or 1599 / 504) | Configuration |

---

## 6. Retries and idempotency, including `ContentFingerprint`

### 6.1 The problem

A caller that times out **retries**. The retry is a **new HTTP call**: new `MSG_ID`, new `GMT_TIME_SENT`, new
`RRMsgID`, and for WCF callers a new WS-Addressing `MessageID`. But it carries **the same permit**. Without
protection, the permit would be processed twice.

We **cannot** use `MSG_ID` to spot retries: some callers always send `MSG_ID="456"`. So the bridge compares the
**content**.

### 6.2 What `ContentFingerprint` is

[ContentFingerprint.Compute](../../src/QrBridge.Gateway/Ingress/Soap/ContentFingerprint.cs) produces a **SHA-256
hash** (64 hex characters) of:

```text
"QrBridge content fingerprint v1" | service | SOAP operation | MESSAGE TYPE | the operation element | the FMS payload
```

- Fields removed before hashing, wherever they appear (element or attribute): **`MSG_ID`, `GMT_TIME_SENT`,
  `RRMsgID`** (global `FingerprintIgnore` in `routes.json`; a route or type can add more).
- **SOAP headers are left out** (the WS-Addressing `MessageID` changes on every call).
- **Whitespace is kept.** A retry that differs only in spaces is **missed** (carried twice, so the service sees a
  duplicate). That is the safer mistake: the other way, two real messages could be merged into one and one lost.
- It works on **its own copy**. The caller's bytes are never changed.
- Unreadable XML → no fingerprint → no retry detection for that call.
- **GET calls have no fingerprint.**

It is stored in **both** tables: **`qrbridge.db`.Outbox.ContentFingerprint** on the sending side, and it travels in the
message header to **`qrbridge.db`.Inbox.ContentFingerprint** on the receiving side (the other machine's file). Both
columns are indexed.

### 6.3 Which calls use it (`RecogniseRetries`)

| Call type | `RecogniseRetries` (default) | Why |
|---|---|---|
| **RoundTrip, state-changing** (hold-timeout **1596**): `SendToFMS`, `CreateCard`, `IssueOrder`, `WITHDRAW_RFP`… | **On** | Running it twice is harmful. |
| **RoundTrip query** (hold-timeout **1599**) | **Off** | A query must ask the real service again, not get an old or expired answer. |
| **Bridge** (one-way feed) | **Off** (only counted on `/health` `retries`) | Its caller already got `RETURN_CODE 0`. |
| **GET** | No fingerprint (and start-up refuses a GET route with `RecogniseRetries` on) | Always asks again. |

A route or a message type can override this in `routes.json`.

### 6.4 The layers of protection, in order

| Layer | Where | Database.Table | Rule |
|---|---|---|---|
| **1. Attach the retry (sending side)** | `OutboxWriter.EnqueueAsync` | `qrbridge.db`.**Outbox** | Same fingerprint, Request, same direction, queued **within 30 min** (`Gateway:RetryWindowMinutes`) → **nothing new is queued**. The retry is held on the **first** message and gets the **same answer**. The check and the insert are one write transaction, so two identical calls at the same moment still make **one** row. **Exception:** if the first one surely did **not** happen (`Expired`, `NotDelivered`, `Rejected`), the retry is queued again with a fresh expiry. |
| **2. Same message twice on the light** | `InboxRepository.AddMessageAsync` | `qrbridge.db`.**Inbox** | Keyed on **`MessageId`** (the primary key): a re-aired copy is never inserted twice, only re-receipted. |
| **3. Same content twice on the far side** (the code calls it "layer 3b") | `InboxWorker` + `InboxRepository.FindSameContentAsync` | `qrbridge.db`.**Inbox** | Before posting: same fingerprint arrived **within 30 min** and is **`Done`** → **not posted**; `AnswerWriter.ReuseDoneAsync` answers with the earlier call's real answer. Same content still **`Delivering`** or **`Unknown`** → **not posted**, marked **Unknown** for an operator. (This catches what layer 1 cannot, for example after the first message expired at the sender and was queued again.) |
| **4. Never re-post when it may have arrived** | `SoapForwarderHttpClient.Classify` | `qrbridge.db`.**Inbox** | Automatic retry **only** when the call surely did not reach the service (DNS, connect refused, connect timeout, TLS, 408, 429). Anything that may have reached it → **Unknown**, never automatically re-posted. |
| **5. Old or replayed numbers** | `ArrivalChecks` + **SequenceWatermark** | `qrbridge.db`.**Inbox**, **SequenceWatermark** | A sequence number already used, or at or below the run's watermark, is **Rejected**, whatever its date. Plus: older than 7 days or more than 60 min in the future → Rejected. |
| **6. One answer per Request** | `OutboxRepository.MarkAnsweredAsync` | `qrbridge.db`.**Outbox** | Stores a Reply only while `Waiting`. A late or re-aired Reply never overwrites an `Answered` row. |

### 6.5 Two demo examples

**Retry after 1596 (state-changing):**

1. 10:00:00. FCR sends permit P (`MSG_ID=456`) → Outbox row **M1**, held 270 s.
2. 10:04:30. Hold ends → FCR gets **1596**. M1 is still on its way.
3. 10:05:10. Reply for M1 arrives → M1 `Answered`, `ReplyBody` stored.
4. 10:06:00. FCR retries P (`MSG_ID=456`, new `GMT_TIME_SENT`) → same fingerprint, within 30 min → **attached to
   M1**, no new row. The caller is held, finds M1 already answered, and gets the **real answer at once**. The permit
   was processed **once**.

**Two genuinely different permits:** different content gives a different fingerprint, so two separate messages.
Only `MSG_ID`, `GMT_TIME_SENT` and `RRMsgID` are ignored.

> **Honest limitation to mention:** if a caller deliberately sends the *same* state-changing content twice within
> 30 minutes, the second is treated as a retry and gets the first one's answer. This is the agreed trade-off
> (decisions D5 and D37). The window and the ignored fields are configuration.

---

## 7. How the transfer is protected

### 7.1 Before anything is stored (gateway, sending side) ✅

| Control | Where |
|---|---|
| **Allow-list:** only services and operations in `routes.json` (`AcceptUnlisted` off in production) | `RouteTable` |
| **WSDL contract check** on every bridged call | `ContractCatalog` |
| **Message-type allow-list** (`AllowedTypes`) | `SenderEndpoint` |
| **Safe XML:** DTDs prohibited, no resolver, size caps | `SafeXml` |
| **Size limits:** request (413), backlog (1598) | `SenderEndpoint`, `OutboxWriter` |
| **Payloads are never logged:** only service, operation, label, ids and sizes | everywhere |

### 7.2 The message itself ✅

`MessageSerializer` produces `BRG7` + header + **SHA-256 checksum** + Brotli body. The checksum detects
**corruption**, not deliberate tampering. **The bridge bytes are not encrypted by the gateway: QrDiode is the
encryption layer.** Decompression has a hard size cap (no "zip bomb").

### 7.3 On the light: QrDiode (built in `QrDiode.Core`; wiring to the database 🟡)

**Sending** ([SendSession](../../../qrdiode/src/QrDiode.Core/Pipeline/SendSession.cs)):

```text
plaintext → SHA-256 → Brotli → ECDH P-256 + HKDF-SHA256 key → AES-256-GCM → signed manifest (ECDSA P-256) → LT fountain code → QR frames
```

**Receiving** ([ReceiveEngine](../../../qrdiode/src/QrDiode.Core/Pipeline/ReceiveEngine.cs)) checks in strict order
and **fails closed** at each step:

```text
frame CRC → manifest signature → addressed to me → anti-replay → LT decode → ciphertext hash → AES-GCM open → decompress cap → plaintext hash → content gate
```

| Threat | Protection |
|---|---|
| Someone reads the screen (camera, photo) | **AES-256-GCM.** The key comes from ECDH between the two sides' keys plus a fresh 32-byte salt per session (HKDF-SHA256). Without the receiver's private key, the QR codes are noise. |
| Someone shows forged QR codes | The manifest is **signed** (ECDSA P-256). The sender's key must be in the receiver's **trust store**, set up in the **key ceremony** (`QrDiode.KeyCeremony`). Unknown key → rejected before any payload byte is touched. |
| Codes meant for another receiver | The manifest names the **receiver's key**. Wrong key → rejected. |
| Someone re-shows an old recording | **Anti-replay:** a per-sender counter and timestamp in the signed manifest. |
| Bits changed in transit | **AES-GCM tag** + ciphertext SHA-256 + plaintext SHA-256 + per-frame CRC. The AAD binds the ciphertext to its signed manifest. |
| Keys stolen from disk | Keys are **non-exportable** keys in the Windows CNG store, **TPM-backed** when the machine has a TPM. |
| Network attack across the gap | **There is no network.** Each lane is one-way light (screen → camera). The two gateways never connect to each other. |

### 7.4 After arrival (gateway, receiving side) ✅

[ArrivalChecks](../../src/QrBridge.Gateway/Egress/ArrivalChecks.cs) runs on **every** arrived message (Request,
Reply, Receipt, Heartbeat) before it is used:

1. Header matches the Inbox columns (id, service, operation, kind, correlation, run, fingerprint, expiry, priority).
2. **Same `routes.json`** on both sides (catalogue fingerprint).
3. Right **direction** for this side.
4. Known payload format (`RawSoap` or `HttpGet`).
5. Not older than **7 days**, not more than **60 min** in the future.
6. Sequence number not reused or below the watermark.

Then, for Requests: the target URL **only** from this side's configuration (never from the message), **HTTPS
only**, no redirects. For Replies and Receipts: they must answer a Request **this side actually sent**, for the same
service and operation.

### 7.5 At rest

- A **`Done`** Inbox row's `MessageBytes` are **emptied**. Only the hash and size are kept for reconciliation. Rows
  waiting for an operator keep their bytes.
- The data folder ACL allows only the app pool identity, the kiosk user, SYSTEM and Administrators (manual set-up,
  guide §12.4).

---

## 8. The numbers (defaults; `appsettings*.json`)

| Setting | Default | Used in |
|---|---|---|
| `Gateway:Hold` (Corp / DMZ) | **270 s / 90 s** | How long a caller is held (A10) |
| `Gateway:Expiry` | **600 s** | State-changing RoundTrip `ExpiresUtc` (queries and GET: = hold) |
| `Gateway:RetryWindowMinutes` | **30 min** | Retry detection (§6) |
| Hold re-read interval | **2 s** | `SenderEndpoint.HoldAsync` |
| `Gateway:InboxPollSeconds` | **2 s** | `InboxWorker`, `AnswerReader`, `ReceiptWorker` |
| `Gateway:ReceiptTimeoutSeconds` / `MaxAirAttempts` | **120 s / 3** | Re-airing (§5.2 #2) |
| `Gateway:Receiver:ConnectTimeoutSeconds` / `TimeoutSeconds` | **15 s / 120 s** | `SoapForwarderHttpClient` |
| `Gateway:MaxAttempts`, backoff | **8**, 30 s doubling, max 30 min | State-changing Requests not sent |
| `Gateway:LockTimeoutMinutes` | **5 min** | Stuck `Delivering` → recovery |
| `Gateway:HeartbeatMinutes` / `FarSideSilentMinutes` | **5 / 15 min** | Far-side monitoring |
| `Gateway:GapGraceMinutes` | **5 min** | Lost-message report |
| `Gateway:ReplayWindowDays` / `MaxClockSkewMinutes` | **7 days / 60 min** | `ArrivalChecks` |
| `Gateway:MaxBacklog` | **5,000** Requests | 1598 Busy |
| `GatewayDatabase:MaxPayloadBytes` | **1,000,000** bytes | Request size and carried answer size |

---

## 9. Questions the team may ask

**Q: Does the caller's HTTP connection go through the QR link?**
No. It stays open between the caller and its local gateway (the "hold"). Messages cross the light. The far gateway
makes its **own** HTTP call to the real service. `MessageId` and `CorrelationId` connect the two halves.

**Q: Does the caller get the real service's answer, or a fake one?**
The real one: same HTTP status, Content-Type and body, byte for byte, **when it comes back within the hold**.
Otherwise it gets a clearly marked bridge code (1596, 1599, 504), never a fake success.

**Q: Is the request changed on the way?**
No. The SOAP body is replayed byte for byte, with the same `SOAPAction` and `Content-Type`. The only exception is
`wsa:To` for WS-Addressing callers (WCF checks it), which is pointed at the real service. Legacy quirks like
`<SOURCE_APPLICAION>` and `MSG_ID="456"` survive.

**Q: Can a permit be processed twice?**
Six layers prevent it (§6.4). The two key rules: a retry with the same content within 30 min is attached to the
first message, and nothing that **may** have reached the service is ever re-posted automatically.

**Q: Why not use `MSG_ID` to spot duplicates?**
Some callers send a static `MSG_ID="456"`, and it changes on every retry for others. We hash the content without the
per-send fields instead.

**Q: What if the answer arrives after the caller was told 1596?**
It is stored in the Outbox row. The caller's retry is attached to the same message and gets it at once.

**Q: What if the far side is down for an hour?**
State-changing calls expire after 10 min and are never delivered late. Callers get 1596 or 1599. `/health` turns
unhealthy after 15 min of silence. Nothing is lost silently: every row stays, with a status and a comment, for an
operator.

**Q: Who can read the QR codes on the screen?**
Nobody without the receiver's private key: AES-256-GCM with a per-session key from ECDH + HKDF. Forged or replayed
codes are refused by signature and anti-replay checks before any payload byte is touched.

**Q: Can a message tell the gateway where to send it?**
No. Target URLs come **only** from that side's configuration. A message can only name a service in the shared
`routes.json`, and only one that is delivered on that side.

**Q: Why does the IIS site need a single worker process?**
`WaiterRegistry` (the list of held callers) lives in memory. In a web garden, the process that stores the Reply might
not be the one holding the caller. The caller would still get the answer at its next 2 s re-read, but only slowly.

**Q: Can a GET be bridged DMZ → Corp?**
Not today. The only GET route is Registered Tags, sent from Corp. Adding one is a `routes.json` change, not code
(`"HttpGet": true`, `SenderSide: "Dmz"`), plus a test.

---

## 10. What is built and what is not

| Part | Status |
|---|---|
| Sender part (accept, check, fingerprint, store, hold, answer) | ✅ built and tested |
| Receiver part (claim, check, deliver, classify, Reply, Receipt) | ✅ built and tested |
| Round trip end to end with two gateways and `FakeLight` | ✅ tested in memory |
| QrDiode encryption, signing, anti-replay, fountain code | ✅ built and tested in `QrDiode.Core` |
| **QR Sender reading the Outbox of `qrbridge.db`** (`ClaimNextAsync`, `MarkAiredAsync`) | 🟡 planned |
| **QR Receiver writing the Inbox of `qrbridge.db`** (`AddMessageAsync`, doorbell) | 🟡 planned |
| Real screens and cameras, measured air time | 🟡 not tried |
| Corp Receiver URLs for DMZ → Corp services | 🟡 not configured |
| IIS, folder ACLs, kiosk set-up on real servers | 🟡 manual, not tried |
