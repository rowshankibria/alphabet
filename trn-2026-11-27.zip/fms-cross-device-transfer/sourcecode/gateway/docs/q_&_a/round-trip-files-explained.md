# The round-trip files, explained simply

Nine files were added to the SOAP Gateway in the V6 fix steps 9–17. Every one of them serves **one idea**:

> Messages no longer go only one way. The far side now **answers back** over the opposite light lane, and each side
> keeps an eye on whether the other side is still there.

This page explains each file in plain words: what it is for, when it runs, and an everyday comparison. For the
step-by-step journey of a POST and a GET call (classes, database tables, failures, retries, security), see
[round-trip-post-and-get-walkthrough.md](round-trip-post-and-get-walkthrough.md). For the full
technical detail see the [gateway README](../../src/QrBridge.Gateway/README.md) and the
[V6 fix tracker](../reviews/gateway-review-v6-fix-tracker.md) (the `Dnn` decision numbers below are listed there).

## First, four words you need

| Word | Meaning | Everyday comparison |
|---|---|---|
| **Request** | The caller's SOAP call, carried to the other side and posted to the real service. | A letter you post. |
| **Receipt** | An empty message back: "your message arrived and is stored here". | The "delivered" tick on a parcel. |
| **Reply** | A message back: what the real service did (outcome, HTTP status, a reason in plain words) and its real answer, byte for byte. | The written answer to your letter. |
| **Heartbeat** | An empty message sent when a side has had nothing to send for a while: "I am still here". | A "still alive?" ping. |

Each side has one database, `qrbridge.db`, with an **Outbox** table (what it sends) and an **Inbox** table (what
arrived). Receipts,
Replies and Heartbeats travel exactly like Requests: into the sender's Outbox, across the light, into the other side's
Inbox.

## The journey, with the new files in it

Corp side = **A**, DMZ side = **B** (it works the same way in the other direction).

```text
 A (Corp gateway)                                    B (DMZ gateway)
 ─────────────────                                   ───────────────
 1. Caller sends a SOAP call
    SenderEndpoint ──► ContentFingerprint  (is this a retry?)
    OutboxWriter stores the Request
    RoundTrip call: the caller is held ──► WaiterRegistry / Waiter
                         ═══════ light ═══════►
                                                     2. InboxWorker picks up the Request
                                                        ArrivalChecks     (is it acceptable?)
                                                        posts it to the real service
                                                        AnswerWriter      (writes the Reply)
                                                        ReceiptWorker ──► AnswerWriter (writes the Receipt)
                         ◄═══════ light ═══════
 3. AnswerReader picks up the Receipt and the Reply
    ArrivalChecks      (is it acceptable?)
    stores them in the Outbox row
    WaiterRegistry.Wake ──► the held caller gets the real answer

 Always running on both sides (every minute, through MaintenanceWorker):
    FarSideMonitor      sends Heartbeats; "have we heard from the far side lately?"
    SequenceGapMonitor  "did a message get lost on the light?"
```

> **Why is `AnswerReader` in `Ingress/` and `AnswerWriter` in `Egress/`?** The folders are named after the gateway's two
> roles, not after the database tables. `Ingress/` = the **Sender part** (it serves the callers on this side), so the class
> that brings answers back *to those callers* lives there. `Egress/` = the **Receiver part** (it calls the real
> services), so the class that writes answers *about those calls* lives there.

---

## 1. `Ingress/Soap/ContentFingerprint.cs` — "Is this the same call again?"

[ContentFingerprint.cs](../../src/QrBridge.Gateway/Ingress/Soap/ContentFingerprint.cs)

**In one sentence:** it turns a SOAP call into a short code (a SHA-256 hash). Two calls with the same business
content get the same code, even when their per-send fields are different.

**The problem it solves:** when a caller times out, it often **retries**. The retry is a new HTTP call with a new
`MSG_ID`, a new `GMT_TIME_SENT`, a new WS-Addressing `MessageID`… but the same permit, order or card. Without a way to
spot this, the bridge would carry the call twice and the real service would process it twice. (We can't compare
`MSG_ID`, because some callers always send `MSG_ID="456"`.)

**How it works:**

1. It reads its **own copy** of the body through `SafeXml`. The caller's bytes are never changed.
2. It takes the SOAP operation element and the FMS payload inside its first parameter.
3. It deletes the fields listed in the route's `FingerprintIgnore` (in `routes.json`), for example `MSG_ID` or
   `GMT_TIME_SENT`. It deletes them wherever they appear, as an element or as an attribute.
4. It hashes: service + operation + message type + what is left.
5. SOAP headers are left out, because WCF changes the `MessageID` on every call.

If the XML can't be read safely, it returns `null`. That message just gets no fingerprint, and no retry detection.

**Design choice:** whitespace is kept. If a retry differs only in spaces, it is **missed** and carried twice (the
service sees a duplicate). That is safer than the opposite mistake: treating two different real messages as one and
silently dropping one.

**Used by:** `SenderEndpoint` (computes it) → `OutboxWriter` (same fingerprint within `Gateway:RetryWindowMinutes`
→ the retry is attached to the first message instead of queued again, D37) → `InboxWorker` on the far side (same
content already `Done` → not posted again, D58).

**Comparison:** a fingerprint of a letter's *content*. The envelope and the date stamp are ignored.

---

## 2. `Ingress/Waiter.cs` — one caller waiting on the phone

[Waiter.cs](../../src/QrBridge.Gateway/Ingress/Waiter.cs)

**In one sentence:** one caller who is **held on the line** until its RoundTrip call has an answer.

**Background:** some operations are `RoundTrip`: permits, orders, cards, queries. For these, the caller must get the
**real** answer from the far side, not an instant "OK". So the gateway keeps the HTTP call open and waits.

**What it does:**

- `WaitAsync(timeout)` — sleep until woken, or until `timeout` passes.
- `Signal()` — wake it. If it is already woken, or the call has just ended, nothing happens and nothing breaks.
- `Dispose()` — the call is over (answered, timed out or the caller hung up): it removes itself from the registry.

Inside, it is just a `SemaphoreSlim` with room for one signal.

**Angular comparison:** a `Promise` that something else resolves later. Or a `Subject` you `await firstValueFrom(...)`
on, with a timeout.

---

## 3. `Ingress/WaiterRegistry.cs` — the list of callers on hold

[WaiterRegistry.cs](../../src/QrBridge.Gateway/Ingress/WaiterRegistry.cs)

**In one sentence:** the list of all `Waiter`s, grouped by the message they are waiting for, so that "an answer for
message X arrived" can wake exactly the right callers.

**What it does:**

- `Register(messageId)` — a caller starts waiting (in `SenderEndpoint.HoldAsync`).
- `Wake(messageId)` — an answer was stored (called by `AnswerReader`), so every caller waiting for that message
  wakes up and reads the Outbox. There can be **several** callers per message: a retry attached by the fingerprint
  waits for the same answer.
- `Count` — how many callers are held right now.

**Important:** it only makes things **faster**. A held caller also re-reads the Outbox every few seconds anyway, so a
missed wake-up only delays the answer; the answer is never lost.

**Deployment trap:** it lives in memory. So IIS must run the gateway in **one worker process** (no "web garden").
Otherwise the answer could wake a list in a different process from the one holding the caller.

**Angular comparison:** a singleton service holding a `Map<id, Subject[]>`. `Wake(id)` calls `.next()` on every
subject for that id.

---

## 4. `Ingress/AnswerReader.cs` — brings answers back to this side

[AnswerReader.cs](../../src/QrBridge.Gateway/Ingress/AnswerReader.cs)

**In one sentence:** a background loop that reads the **Receipts, Replies and Heartbeats** that arrived from the far
side and records them against the message they answer.

**When it runs:** all the time, as a hosted `BackgroundService`. Every `Gateway:InboxPollSeconds` it reads up to 100
arrived answers at a time. It polls instead of waiting on the Inbox doorbell, because `InboxWorker` needs every ring
of that doorbell for Requests.

**What it does with each arrived row:**

1. Unpacks it and runs the [ArrivalChecks](#6-egressarrivalcheckscs--the-security-guard-at-the-door).
2. **Heartbeat** → mark it `Done`. That's all: its arrival time *is* the "far side last seen" time.
3. Checks that the Receipt or Reply really answers a message **this side sent**, with the same service and the same
   operation. If not → `Rejected`.
4. **Receipt** → the Outbox row's light status becomes `Received` (the message got across, so stop re-airing it).
5. **Reply** → stores the outcome and the real answer in the Outbox row, then calls `WaiterRegistry.Wake`, so a
   held caller gets its answer now. If the row already holds an `Answered` reply, it keeps it (D59).
6. The Inbox row ends `Done`, or `Rejected` if something was wrong.

Once a row is started it is never cancelled, so it is never left half-done. **Nothing here ever calls a real service.**

**Angular comparison:** a service with an `interval(...)` that reads a queue and pushes results into the store.
Components (the held callers) then update.

---

## 5. `Egress/AnswerWriter.cs` — writes the answers that go back

[AnswerWriter.cs](../../src/QrBridge.Gateway/Egress/AnswerWriter.cs)

**In one sentence:** the far side's half of the round trip. After a Request has been handled, it writes the
**Reply** (and, through `ReceiptWorker`, the **Receipt**) into this side's Outbox, so the light carries it back.

It is a plain helper class (not a loop). It has four jobs:

| Method | When | What it does |
|---|---|---|
| `FinishAsync` | Every time `InboxWorker` finishes a Request (Done, Refused, Unknown, Expired, NotDelivered, Rejected). | **First** writes the Reply (outcome, HTTP status, a one-line reason, the real answer), **then** marks the Inbox row. If the answer is bigger than `GatewayDatabase:MaxPayloadBytes` it is left out, and the reason says so. |
| `RecoverStuckAsync` | Once a minute, from `MaintenanceWorker`. | Finds Inbox rows still `Delivering` after a crash or restart. If a Reply was already written **for this attempt**, it copies that outcome. Otherwise it marks the row `Unknown` and sends an Unknown Reply. It **never posts again**: the service may already have processed it. |
| `ReuseDoneAsync` | `InboxWorker` sees the same content (same fingerprint) already `Done` within the retry window. | Does not post. Ends `Done` with the **earlier** call's answer (D58). |
| `SendDueReceiptsAsync` | Called by `ReceiptWorker`. | Writes one empty Receipt for each arrived message that is owed one (up to 100 per pass). |

**Why "Reply first, then mark the row"?** (D46) If the gateway crashes between the two steps, the Reply already
exists. `RecoverStuckAsync` then finds it and settles the row from it. The other order could lose the answer.

---

## 6. `Egress/ArrivalChecks.cs` — the security guard at the door

[ArrivalChecks.cs](../../src/QrBridge.Gateway/Egress/ArrivalChecks.cs)

**In one sentence:** the list of checks **every** message from the light must pass before it is used, whatever its
kind (Request, Reply, Receipt, Heartbeat).

**The checks:**

1. The header inside the message matches the columns the QR Receiver wrote in the Inbox row (id, service, operation,
   kind, correlation, run id, fingerprint, expiry, priority). This catches tampering or a wrongly filled row.
2. **Same `routes.json` on both sides** (catalogue fingerprint, D31). Otherwise a message could be judged by rules its
   sender never had.
3. Right **direction**: Corp accepts only DMZ→Corp messages, and DMZ only Corp→DMZ.
4. Known **payload format**: `RawSoap` or `HttpGet`.
5. **Not too old** (`Gateway:ReplayWindowDays`) and **not from the future** (`Gateway:MaxClockSkewMinutes`; check NTP).
6. **Sequence number not already used** (D84, only on the row's first check). This catches an old message shown
   again, or a copied or restored `qrbridge.db` on the sending side, whatever the clocks say.

All passed → the row is marked `Verified`. Any failure → `BridgeRejectException` → the row is `Rejected`.

**Used by:** `InboxWorker` (Requests) and `AnswerReader` (Receipts, Replies, Heartbeats). It was pulled into one
class so both use **exactly the same** rules.

**Angular comparison:** a route guard (`CanActivate`) that every navigation passes through, whatever the route.

---

## 7. `Egress/FarSideMonitor.cs` — "Is the other side still alive?"

[FarSideMonitor.cs](../../src/QrBridge.Gateway/Egress/FarSideMonitor.cs)

**In one sentence:** sends Heartbeats when this side is quiet, and tells `/health` when the far side has been silent
for too long.

**The problem it solves:** if nothing arrives over the light, it could mean "the other side has nothing to say" or
"the camera / screen / far gateway is broken". Heartbeats remove the doubt: each side **always** sends *something*.
So silence now means "something is down".

**Two methods:**

- `SendHeartbeatIfIdleAsync` (once a minute, from `MaintenanceWorker`). If this side has queued nothing for
  `Gateway:HeartbeatMinutes`, it queues an empty Heartbeat. It skips this while an earlier Heartbeat is still waiting
  to be aired, so they don't pile up while the light is down. Heartbeats take a sequence number, so a lost last real
  message still shows up as a gap on the far side.
- `GetAsync` (for `/health` and `MaintenanceWorker`). Returns `FarSideStatus`: when the far side was last heard, when
  its last Receipt arrived, and `Silent` = nothing heard for longer than `Gateway:FarSideSilentMinutes`. While silent,
  `/health` says unhealthy and the log shows a `Light:` warning.

**Comparison:** a walkie-talkie check-in: "Base, all quiet here, over." No check-in for 15 minutes → something is
wrong.

---

## 8. `Egress/SequenceGapMonitor.cs` — "Did a message get lost?"

[SequenceGapMonitor.cs](../../src/QrBridge.Gateway/Egress/SequenceGapMonitor.cs)

**In one sentence:** every message has a running number (1, 2, 3…). This class looks for **missing numbers** in what
arrived from the other side.

**Example:** 41, 42 and 44 arrived, and 44 arrived more than `Gateway:GapGraceMinutes` ago → number 43 is missing →
it was probably lost on the light.

**When it runs:** once a minute, from `MaintenanceWorker` (`CheckAsync`).

- It logs **one** `Light: … never arrived` warning per new gap, with numbers and ids only, never the payload.
- It keeps the result in `Current`, so `/health` can show it without querying the database. (The load balancer probes
  `/health` often, and rows are never deleted, so the query would grow costly.)
- It also moves each run's **watermark** up: "everything up to number N is settled". `ArrivalChecks` uses this to
  refuse old numbers.

A gap goes away when the message finally arrives, when the sender's counter starts a new run, or when an operator
acknowledges it (`InboxRepository.AcknowledgeGapAsync`; no UI yet).

**Comparison:** pages numbered 1, 2, 4. You can see at once that page 3 is missing.

---

## 9. `Egress/Workers/ReceiptWorker.cs` — sends the "it arrived" ticks

[ReceiptWorker.cs](../../src/QrBridge.Gateway/Egress/Workers/ReceiptWorker.cs)

**In one sentence:** a small background loop that, every `Gateway:InboxPollSeconds`, calls
`AnswerWriter.SendDueReceiptsAsync` until no Receipts are owed.

**Why a separate loop?** The other side **re-airs** a message (shows its QR codes again) until it gets a Receipt. If
Receipts were sent by `InboxWorker`, one slow POST to a real service would delay every Receipt. The other side would
then re-air messages that had in fact arrived. Keeping Receipts on their own loop means they always go out promptly.

**Angular comparison:** an `interval(5000)` in a root service whose only job is to flush a "send acknowledgements"
queue.

---

## Where they are registered

| File | Registered in | How |
|---|---|---|
| `WaiterRegistry`, `AnswerReader` | [SenderRegistration.cs](../../src/QrBridge.Gateway/Initializer/SenderRegistration.cs) | singleton (one shared list per process); `AnswerReader` as a hosted service (background loop) |
| `ArrivalChecks`, `AnswerWriter` | [ReceiverRegistration.cs](../../src/QrBridge.Gateway/Initializer/ReceiverRegistration.cs) | singletons |
| `SequenceGapMonitor`, `FarSideMonitor`, `ReceiptWorker` | [WorkerRegistration.cs](../../src/QrBridge.Gateway/Initializer/WorkerRegistration.cs) | singletons; `ReceiptWorker` as a hosted service |
| `Waiter` | — | created by `WaiterRegistry.Register`, not registered |
| `ContentFingerprint` | — | static helper, not registered |

## Status

- **Built and tested:** all nine, with two gateways running in memory and a fake light (`QrBridge.Tests`).
- **Not yet tried:** with the real QR Sender/Receiver and cameras. The QR sender does not yet read the Outbox or set
  `Aired`, so Receipts, re-airing and Heartbeats have not crossed real light (known issue 5 in
  [copilot-instructions.md](../../../../.github/copilot-instructions.md)).
