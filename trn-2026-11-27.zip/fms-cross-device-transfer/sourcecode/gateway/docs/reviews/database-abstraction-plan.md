# Plan and tracker: a database-provider seam for the bridge data layer

Requested by Rowshan, 27 Nov 2026: the **Gateway-to-QrDiode** data layer (`QrBridge.Shared`) must work with any
database engine, chosen by configuration, with repositories behind interfaces. **SQLite** stays the default and
behaves exactly as before; **SQL Server** is the second engine. Read this file first and continue from the first step
that is not ✅.

Legend: ✅ done and verified · 🔄 in progress · ⬜ not started · ⚠️ needs Rowshan

---

## 1. Why

The *callers* of the database were already separated (gateway workers use the repositories, the QR apps use only
`QrAppBridge`), but *which* database it is was hard-wired:

| What depended on SQLite | Where (before) |
|---|---|
| Connection and options (`UseSqlite`, pragmas) | `Data/Initializers/DatabaseSetup.cs`, `Data/SqliteExtensions/SqlitePragmaInterceptor.cs` |
| Start-up (WAL, the former `send.db`/`received.db` check, schema adoption) | `DatabaseInitializer`, `SchemaAdoption` |
| "One writer at a time" (`BEGIN IMMEDIATE`) assumed by the two write transactions | `OutboxWriter.EnqueueAsync`, `InboxRepository.AddMessagesAsync` |
| SQLite SQL: `UPDATE … RETURNING` and `$` parameters for the sequence number | `OutboxWriter.NextSequenceAsync` |
| SQLite error code 19 for a duplicate key | `InboxRepository.AddMessageAsync`, `AcknowledgeGapAsync` |
| A derived table without an alias (SQL Server refuses it) | `InboxRepository.FindSequenceGapsAsync` |
| The gateway opened the database itself | `OutboxWriter` (transaction, retry lookup, backlog, sequence, insert) |
| The read-only UI relied on SQLite `Mode=ReadOnly` | `Ui/Data/ReadOnlyBridgeDb.cs` |
| Migrations generated for SQLite only | `Data/Migrations` |

## 2. Rules for this work

- **Mission-critical system.** With the default settings nothing changes: same tables, columns, indexes,
  transactions, statuses and order of operations. An existing `qrbridge.db` opens unchanged (same migration ids).
- **`OutboxWriter` stays the one way in.** It keeps the rules (routes, retry attach, logging, counters, doorbell);
  only the storage moves into the repository.
- **The UI stays read-only:** it has no action that writes (`UiReadOnlyTests`); SQLite also opens the file
  `Mode=ReadOnly`. SQL Server uses one connection string for everything (Rowshan, 27 Nov: read-only means no action
  buttons, not a separate login).
- **No operations merged into one transaction** (decision S2 of the single-database work).
- Follow `.github/copilot-instructions.md` and `.github/instructions/*.md`; don't commit.

## 3. Design (built)

### 3.1 Where each engine difference lives

**One folder per engine** under `QrBridge.Shared/Data` (Rowshan, 27 Nov): everything only that engine uses is inside
it, in the same subfolders as the shared code; the shared folders stay engine-free. Classes keep the namespace
`QrBridge.Shared.Data`; migrations follow their folder (`QrBridge.Shared.Data.Sqlite.Migrations`,
`QrBridge.Shared.Data.SqlServer.Migrations`).

```text
Data/
  Entities/  Configurations/  Conventions/  Repositories/      shared, engine-free
  Contexts/      BridgeDbContext (abstract), BridgeDbContextFactory
  Providers/     IBridgeDatabase (its Create is the one place that picks an engine)
  Initializers/  DataServiceCollectionExtensions, DatabaseInitializer
  Sqlite/
    Providers/     SqliteBridgeDatabase
    Contexts/      SqliteBridgeDbContext, SqliteDesignTimeFactory
    Initializers/  SchemaAdoption, SqlitePragmaInterceptor
    Exceptions/    SchemaMismatchException (only SQLite's schema adoption throws it)
    Migrations/    20261127010945_Initial, 20261127011156_Bundles, snapshot
  SqlServer/
    Providers/     SqlServerBridgeDatabase
    Contexts/      SqlServerBridgeDbContext, SqlServerDesignTimeFactory
    Migrations/    20261127164918_Initial, snapshot
```

A third engine (e.g. PostgreSQL) is a new `Data/PostgreSql/` folder with the same subfolders, one line in
`IBridgeDatabase.Create`, one value in `DatabaseProvider`, and its first migration.

| Difference | Lives in | SQLite (`Data/Sqlite/`) | SQL Server (`Data/SqlServer/`) |
|---|---|---|---|
| Connection, options, read-only connection | `IBridgeDatabase` | `Providers/SqliteBridgeDatabase`: file in `GatewayDatabase:DataFolder`, pragma interceptor, `Mode=ReadOnly` | `Providers/SqlServerBridgeDatabase`: `GatewayDatabase:ConnectionString` (also the UI's) |
| Start-up | `IBridgeDatabase.InitializeAsync` | former-file check, folder, `Initializers/SchemaAdoption`, migrations, WAL, retries | migrations (EF creates the database when the login may) |
| Write lock for a transaction | `BridgeDbContext.BeginWriteTransactionAsync` | `Contexts/SqliteBridgeDbContext`: `BEGIN IMMEDIATE` (as before) | `Contexts/SqlServerBridgeDbContext`: `sp_getapplock 'QrBridge.Write'`, exclusive, held to commit |
| Duplicate key | `BridgeDbContext.IsDuplicateKey` | error 19 (as before) | errors 2627, 2601 |
| Migrations | one context class per engine | `Migrations/` (ids unchanged) | `Migrations/` |

`BridgeDbContext` is abstract: every context is one engine's. Repositories, `IDbContextFactory<BridgeDbContext>` and
the UI keep using the base type. Conventions (`Data/Conventions/BridgeConventions`: enums as names, Guids as
lower-case text, times UTC) apply to both engines, so the rows, the raw SQL of the UI search and the gap query look
the same everywhere.

### 3.2 Repositories behind interfaces

`IOutboxRepository`, `IInboxRepository`, `IHeartbeatRepository` (`Data/Repositories/`). DI registers the interfaces;
every gateway class, the bundle classes and `QrAppBridge` depend on them. The storage half of `OutboxWriter` is
`IOutboxRepository.InsertAsync`: one write transaction with the retry lookup, the backlog counts, the next sequence
number (portable EF code, safe because the write lock is held) and the insert. The writer decides the rules and builds
the row; the repository says Queued, Attached or BacklogFull.

### 3.3 Settings

```jsonc
"GatewayDatabase": {                                   // the gateway; the QR apps call the same section "QRDatabase"
  "Side": "Corp",
  "DataFolder": "C:\\ProgramData\\QrBridge\\Data",   // SQLite only
  "MaxPayloadBytes": 1000000,
  "Provider": "Sqlite",                                // or "SqlServer"
  "ConnectionString": ""                               // SqlServer: gateway, UI and QR apps; Integrated Security (no passwords in files)
}
```

The gateway and both QR apps on one machine must have the same values. Start-up refuses `SqlServer` without a
connection string, and a former `Bridge` section (renamed 27 Nov, step 12).

### 3.4 Changing an entity or enum from now on

Two migrations, one per engine (`MigrationTests.Every_engines_migrations_match_the_current_model` fails when one is
missing). Neither command connects to a database:

```powershell
dotnet tool run dotnet-ef migrations add <Name> --project sourcecode\gateway\src\QrBridge.Shared --startup-project sourcecode\gateway\src\QrBridge.Shared --context SqliteBridgeDbContext --output-dir Data\Sqlite\Migrations
dotnet tool run dotnet-ef migrations add <Name> --project sourcecode\gateway\src\QrBridge.Shared --startup-project sourcecode\gateway\src\QrBridge.Shared --context SqlServerBridgeDbContext --output-dir Data\SqlServer\Migrations
```

(Don't add `--namespace`: EF derives the right one from the folder, and with it writes the snapshot into a stray
`QrBridge/Shared/...` folder. Tried 27 Nov with a throw-away migration, then `migrations remove`; tried again after the
move to the per-engine folders: it lands in `Data\Sqlite\Migrations` with namespace `QrBridge.Shared.Data.Sqlite.Migrations`.)

### 3.5 Out of scope (separate decisions)

- Deploying the gateway on a server and the QR apps on a workstation (reverses settled decision 4). With a remote SQL
  Server the doorbells (`Global\QrBridge.*`, one machine only) don't reach the other machine; every waiter still polls
  every 2 s.
- Copying rows from an existing `qrbridge.db` into SQL Server.
- An HTTP link between the QR apps and the gateway.

## 4. Decisions

| # | Question | Answer |
|---|---|---|
| A1 | Migrations: one context per engine inside `QrBridge.Shared`, or new projects? | **Inside Shared** (Rowshan, 27 Nov) |
| A2 | Repository interfaces? | **Yes** (Rowshan, 27 Nov) |
| A3 | Scope | **Seam + SQL Server** (Rowshan, 27 Nov) |
| A4 | How SQL Server tests run | When `QRBRIDGE_SQLSERVER` holds a connection string to a server where the test login may create databases (e.g. `Server=(localdb)\MSSQLLocalDB;Integrated Security=true;TrustServerCertificate=true`); skipped otherwise, so `dotnet test All.slnx` stays green everywhere |

## 5. Steps

| Step | Status | Scope | Verification |
|---|---|---|---|
| 0 | ✅ | Baseline | `dotnet test All.slnx`: QrBridge.Tests **568 passed**, QrDiode.Core.Tests **116 passed** |
| 1 | ✅ | Seam + SQLite provider + per-engine contexts + conventions + DI | Builds; every existing test passes unchanged in behaviour (only DI lookups moved to the interfaces) |
| 2 | ✅ | SQLite migrations moved to `Data/Migrations/Sqlite`, same ids | `dotnet ef migrations has-pending-model-changes --context SqliteBridgeDbContext`: "No changes"; ids `20261127010945_Initial`, `20261127011156_Bundles` unchanged; adoption tests in `MigrationTests` pass |
| 3 | ✅ | Repository interfaces; callers use them | Every gateway class, `OutboxBundler`, `InboxBundleWriter`, `QrAppBridge` and the tests resolve `I…Repository` |
| 4 | ✅ | `IOutboxRepository.InsertAsync`; `OutboxWriter` no longer opens the database | `RetryTests.Identical_calls_at_the_same_moment_make_one_row`, `SenderTests.Concurrent_calls_never_queue_more_than_the_backlog_limit` and all end-to-end tests pass |
| 5 | ✅ | Read-only UI through the provider | `UiReadOnlyTests` pass (SQLite still refuses a write, code 8); its writer list now includes the interfaces and `IBridgeDatabase` |
| 6 | ✅ | SQL Server provider, context, migration `20261127164918_Initial`, start-up checks | Migration reviewed: same tables, CHECK constraints, filtered indexes and seed rows as SQLite |
| 7 | ✅ | Tests | See §5.1 |
| 8 | ✅ | Documentation | Living docs updated (§6 log) |
| 9 | ✅ | One folder per engine under `Data/` (§3.1) | Both contexts: no pending model changes; `dotnet test All.slnx` **579 + 116** with LocalDB, **572 + 7 skipped + 116** without; `DatabaseSeamTests` now allows engine code only in `Data/Sqlite` and `Data/SqlServer` |
| 10 | ✅ | One database for all three programs: the QR Receiver's journal in the bridge database (handoff decision 56) | See §6 log |

### 5.1 Verification (27 Nov 2026)

- `dotnet test All.slnx` (no `QRBRIDGE_SQLSERVER`): QrBridge.Tests **572 passed, 7 skipped** (the SQL Server tests),
  QrDiode.Core.Tests **116 passed**, 0 failed.
- With `QRBRIDGE_SQLSERVER=Server=(localdb)\MSSQLLocalDB;Integrated Security=true;TrustServerCertificate=true`:
  QrBridge.Tests **579 passed**, 0 skipped. Every test database was dropped afterwards.
- New tests: `SqlServerRepositoryTests` (6: migrations, identical requests → one row, 30 simultaneous requests →
  numbers 1–20 and 10 refused, duplicate keys incl. error 2627, the plain-SQL gap query, bundle claim/air/confirm),
  `SqlServerGatewayTests` (a round trip through two gateways on two SQL Server databases, then the read-only UI's pages
  and id search), `MigrationTests.Every_engines_migrations_match_the_current_model`,
  `SenderTests.A_sql_server_database_without_its_connection_string_stops_the_start`,
  `DatabaseSeamTests.Only_the_engine_classes_name_a_database_engine`.
- **Mutation check:** with `sp_getapplock` removed, both SQL Server concurrency tests fail (duplicate rows, an
  overfilled backlog); restored, they pass.
- `dotnet publish` of the Receiver (win-x64): succeeds; `Microsoft.Data.SqlClient.SNI.dll` and the client's
  Azure/MSAL dependencies (about 10 MB) are in the output.

### 5.2 Not tried

- A real (non-LocalDB) SQL Server, and the QR apps on SQL Server on real
  screens and cameras.
- A true single-file publish (`PublishSingleFile`) of the QR apps with the SQL Server client.
- Performance under load on SQL Server; string comparisons there follow the server's collation (usually
  case-insensitive), where SQLite compares case-sensitively.

## 6. Log

| Date | Step | What happened |
|---|---|---|
| 27 Nov 2026 | 0 | Plan written; baseline taken. Other uncommitted work in `sourcecode/qrdiode` (crypto folders) is not part of this change. |
| 27 Nov 2026 | 1–6 | Engine differences placed on the context (`BeginWriteTransactionAsync`, `IsDuplicateKey`) rather than on the provider, so the repositories' constructors (and the UI's read-only repositories) did not change. The sequence number is now portable EF code (`ExecuteUpdate` + read) instead of SQLite's `UPDATE … RETURNING`; safe because the write lock is held. Files moved with `git mv` (history kept). This copy of the repository has no `dotnet-tools.json`, so `dotnet-ef` 10.0.15 was installed in a temp folder to check and add migrations. EF wrote the SQL Server snapshot into a stray `QrBridge/` folder (from `--namespace`); moved next to its migration. |
| 27 Nov 2026 | 7 | First full run: one failure, `PriorityTests` resolved the concrete `InboxRepository` by its full name (missed by the first replace); fixed. Then all green (§5.1). |
| 27 Nov 2026 | 7 | Final runs: with LocalDB **579 + 116 passed**; without, once **571 passed, 1 failed, 7 skipped**: `RegisteredTagsTests.No_answer_in_time_is_a_504_and_the_query_expires_with_its_hold` — its check that `ExpiresUtc` is within 100 ms of `CreatedUtc` + hold is timing-sensitive under a loaded machine (`CreatedUtc` is stamped inside the write transaction, as before). It passed 5 of 5 times on its own and in 3 of 4 full runs that day. Not changed: loosening the tolerance is Rowshan's call. |
| 27 Nov 2026 | 8 | Living docs updated: copilot instructions, bridge-gateway / read-only-ui / tests instructions, handoff, technical guide, code walkthrough, gateway README, read-only UI guide, SQLite WAL Q&A, integration plan, workflow, QrDiode pending work. History documents (V6 reviews and trackers, single-database plan, done task prompts) left as they were. |
| 27 Nov 2026 | — | Nothing committed: review the diff and commit when satisfied. |
| 27 Nov 2026 | 10 | **One database for the gateway and both QR apps** (Rowshan; handoff decision 56). First attempt (a second EF data layer inside the Receiver) stopped and removed: it copied what `QrBridge.Shared` already has. Built instead: the Receiver's journal as three tables of `BridgeDbContext` (`JournalTransfer`, `JournalWatermark`, `JournalArchive`), migration `ReceiveJournal` for both engines, `IReceiveJournalRepository` (synchronous; `BridgeDbContext.BeginWriteTransaction` added for it, and `ConfigureAwait(false)` in SQL Server's lock), `LegacyJournalImport` (`Data/Sqlite/Initializers`: copies a former journal.db once, then renames it; a foreign file stops the start, untouched); `SchemaMismatchException` moved to `Data/Sqlite/Exceptions`; shared comments say 'the bridge database'. The Receiver's `Storage/SqliteJournal.cs` became `Storage/ReceiveJournal.cs`, an adapter with no data access; the Receiver opens the bridge database in both modes and exits when it cannot. Tests: `ReceiveJournalRepositoryTests` (5, each on SQLite and on SQL Server); mutation: letting the watermark move down fails the anti-replay test. `dotnet test All.slnx`: without SQL Server **577 + 7 skipped + 116**; with LocalDB **587 + 116**, plus once the `RegisteredTagsTests` 100 ms timing check (passes 3 of 3 on its own). Not tried: the WPF Receiver window itself on the new journal, a real former journal.db from a kiosk. Not updated (someone else's uncommitted edits): `protocol-development-notes.md`, `q_&_a/light-transfer-walkthrough.md`, `q_&_a/qrdiode-project-files.md`, `qrdiode-pending-work.md` still name `SqliteJournal` / `journal.db`. |
| 27 Nov 2026 | 9 | **One folder per engine** (Rowshan): `Data/Sqlite/` and `Data/SqlServer/`, each with `Providers/`, `Contexts/`, `Initializers/` (SQLite only) and `Migrations/`; the shared `Contexts/`, `Providers/`, `Initializers/` keep only the engine-free classes (§3.1). Files moved with `git mv` where tracked; class namespaces unchanged; migration namespaces now `QrBridge.Shared.Data.{Engine}.Migrations` (ids unchanged). `DatabaseSeamTests` now allows engine code only in the two engine folders. `has-pending-model-changes`: "No changes" for both contexts; a throw-away migration landed in the new folder with the right namespace and was removed. Docs updated to the new paths (earlier log rows keep the paths of their day). |
| 27 Nov 2026 | 11 | **One connection string** (Rowshan: the read-only UI means no action buttons, not a separate database login). `Bridge:Database:ReadOnlyConnectionString` removed; with SQL Server the UI uses `ConnectionString` (queries not tracked); SQLite still opens the file `Mode=ReadOnly` (no setting). The start-up check now only needs `ConnectionString`. |
| 27 Nov 2026 | 12 | **No "Bridge" in the settings files** (Rowshan; handoff decision 57). Section `Bridge` → `GatewayDatabase` (gateway) and `QRDatabase` (QR apps), flat (`Provider`, `ConnectionString` directly inside); `BridgeOptions` + `BridgeDatabaseOptions` → one `GatewayDatabaseOptions` (`git mv`); `QrDiodeMode.Bridge` → `Gateway`; operator texts say "Gateway mode". A former `Bridge` section stops all three programs (`GatewayDatabaseOptions.FormerSectionProblem`; QrDiode.Core `AppSettings.HasSection`); test: a gateway with `Bridge:Side` does not start, the QR apps' old mode value is refused. Checked once with the real reader: the shipped Sender/Receiver files read as before, the old nested `Database` block is refused. A one-pair batch replace swapped single letters in five files (PowerShell flattened the pair); repaired from git line by line and by hand, checked for leftovers. Unchanged: the route mode `Bridge`, the `QrBridge.*` names, the data folder, audit event names (`bridge.*`). `dotnet test All.slnx` with LocalDB: **588 + 116 passed**. |
