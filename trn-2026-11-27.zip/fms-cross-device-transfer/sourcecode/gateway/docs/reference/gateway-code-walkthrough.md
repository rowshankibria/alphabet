# Gateway code walkthrough — every class and its role

A guided tour of `sourcecode/gateway`: the three projects, how a call moves through them, and what each class,
record, enum and configuration file is for.

| | |
|---|---|
| **Scope** | `sourcecode/gateway/QrGateway.slnx`: `QrBridge.Gateway`, `QrBridge.Shared`, `QrBridge.Tests` |
| **Written** | 23 Nov 2026, from the code as it is on that date; updated 24 Nov 2026 for V6 review fix steps 9b (Receipts and Replies), 10a (the hold, reading answers on the sending side), 10b (far-side same-content check, query fast failure) and 10c (permits, orders and cards held, `Gateway:Expiry`, crash recovery per attempt), 12 (Registered Tags GET as a round trip) and 13 (end-to-end fault tests with a fake light); updated 25 Nov 2026 for steps 14 (priority classes, one delivery loop per class), 15 (per-target credentials, `CallerHost`, bodies cleared once Done) and 16 (per-service size and backlog limits, air-time warning), 17 (Heartbeat messages, `FarSideMonitor`, old messages recognised by their sequence number, `SequenceWatermark`, header v7) and 18 (start-up warning when running as an administrator) |
| **Read first** | [technical-guide.md](../../../../docs/gateway-to-qrdiode/technical-guide.md) §1–§5 for *why*; this page is *how the code does it* |
| **Quick reference** | [gateway.md](../gateway.md) |
| **Remaining work** | [integration-plan.md](../../../../docs/gateway-to-qrdiode/integration-plan.md) |

Source paths below are written as `code`, relative to the repository root.
"Gateway" means `sourcecode/gateway/src/QrBridge.Gateway`; "Shared" means `sourcecode/gateway/src/QrBridge.Shared`.

## Contents

1. [The gateway in one minute](#1-the-gateway-in-one-minute)
2. [The three projects](#2-the-three-projects)
3. [A call's life through the classes](#3-a-calls-life-through-the-classes)
4. [QrBridge.Gateway, class by class](#4-qrbridgegateway-class-by-class)
5. [QrBridge.Shared, class by class](#5-qrbridgeshared-class-by-class)
6. [Configuration and content files](#6-configuration-and-content-files)
7. [QrBridge.Tests, class by class](#7-qrbridgetests-class-by-class)
8. [Who uses whom](#8-who-uses-whom)
9. [Status of each row: the two state machines](#9-status-of-each-row-the-two-state-machines)
10. [Built, used only by tests, and not built](#10-built-used-only-by-tests-and-not-built)
11. [Where to look when…](#11-where-to-look-when)

---

## 1. The gateway in one minute

In islanding mode the corporate network (Corp) and the DMZ cannot talk over the wire. The only link is light: QR
codes on a screen, read by a camera (QrDiode). The callers — Rapid Restore, FTC, Verizon and so on — still make their
normal WCF/ASMX/SOAP calls. The gateway is an IIS site that **pretends to be every one of those services**.

```
 Caller (unchanged)                         CORP machine                                   DMZ machine
 ─────────────────                ┌──────────────────────────────┐            ┌──────────────────────────────┐
 POST FC2FMSInterface.svc ──────► │ QrBridge.Gateway  (Sender)   │            │ QrBridge.Gateway  (Receiver) │
           ◄──── "real answer" ── │   parse → route → pack       │            │   open → check → replay      │──► real FC2FMS
                                  │   → qrbridge.db (Outbox)     │            │   ◄── qrbridge.db (Inbox)    │    service
                                  └──────────────┬───────────────┘            └──────────────▲───────────────┘
                                                 │  QR sender (screen) ~~~ light ~~~ QR receiver (camera)
                                                 └──────────────────────────────────────────┘
```

- **Sender** (the side the caller is on): accept the request, store its exact bytes (compressed, not encrypted) in
  the Outbox of its `qrbridge.db`, then reply the way the real service would: at once for feeds (`Bridge`), or — for permits, orders,
  cards and queries (`RoundTrip`) — with the real service's answer once it comes back, or a "pending" (1596) /
  "not available" (1599) answer when the hold runs out.
- **Receiver** (the other side): take complete messages from the Inbox of its `qrbridge.db`, check and unpack them, replay the
  original request to the real service, and record what it said. Since step 9b it also sends back, through its own
  Outbox, a **Reply** for every final outcome (with the real answer) and a **Receipt** for every arrived message.
  Since step 10a the sending side reads them back, and a `RoundTrip` caller is **held** until its Reply arrives (its
  real answer) or the hold runs out.
- The **same code and the same `routes.json`** run on both sides. `GatewayDatabase:Side` (`Corp` or `Dmz`) decides which
  role each service plays on this machine.
- The QR apps (in `sourcecode/qrdiode`) move envelopes from one machine's Outbox to the other machine's Inbox. They
  are **not** part of this solution, and they are not connected to the database yet ([§10](#10-built-used-only-by-tests-and-not-built)).

---

### Direction and local roles

**Inbound / Outbound** name the direction of an interface. **Sender / Receiver** name the role a machine plays for
one message. Both machines run the same gateway and have both parts.

| Interface | Sender machine | Receiver machine | WSDL folder | `SenderSide` in `routes.json` |
|---|---|---|---|---|
| Inbound (Corp → DMZ), e.g. Rapid Restore calls FC2FMS | Corp | DMZ | `Contracts/Inbound/` | `Corp` |
| Outbound (DMZ → Corp), e.g. FMS calls FMS2SSO | DMZ | Corp | `Contracts/Outbound/` | `Dmz` |

The gateway Sender part (`Ingress/`) accepts a caller's request and writes it through `OutboxWriter`. For a
RoundTrip it also waits for the returning Reply, read by `AnswerReader`. The Receiver part (`Egress/`) delivers
arrived Requests to local services and queues their Receipts and Replies for the opposite QR lane.

One local file per machine, `qrbridge.db` (until 25 Nov 2026 two files, `send.db` and `received.db`):

| Table in `qrbridge.db` | Holds | Written by | Read by |
|---|---|---|---|
| Outbox | Requests waiting to leave, and locally generated Receipts, Replies and Heartbeats | Gateway code through `OutboxWriter` | QrDiode Sender (connection planned) |
| Inbox | Messages arriving from the other side | QrDiode Receiver (connection planned) | `InboxWorker` for Requests; `AnswerReader` for Receipts, Replies and Heartbeats |

`GatewayDatabaseOptions.SendDirection` / `ReceiveDirection` give the machine's directions. Stored `Direction` values remain
`CorpToDmz` (Inbound) and `DmzToCorp` (Outbound).

## 2. The three projects

| Project | Type | Deployed as | Role |
|---|---|---|---|
| `QrBridge.Gateway` | ASP.NET Core web app, `net10.0-windows`, IIS in-process | IIS site, one per side | Sender endpoints, metadata endpoints, receiver worker, maintenance |
| `QrBridge.Shared` | Class library, `net10.0-windows` | Compiled into the gateway **and** (later) the QrDiode WPF apps | SQLite/EF Core data layer, message envelope, cross-process doorbells |
| `QrBridge.Tests` | xUnit | Not deployed | Unit tests, in-memory gateway tests, real WCF client tests, Corp→DMZ end-to-end tests, light and caller fault tests with a fake light |

Folder map of the gateway project:

| Folder | Theme | Classes |
|---|---|---|
| (root) | Start-up | `Program` (one call per step) |
| `Initializer/` | Start-up steps called by `Program` | `OptionsRegistration`, `DataRegistration`, `RouteCatalogRegistration`, `EndpointRegistration`, `SenderRegistration`, `ReceiverRegistration`, `WorkerRegistration`, `StartupChecks` |
| `Configurations/` | Settings classes, all enums, shared helpers | `Options/GatewayOptions.cs` (`GatewayOptions`, `HoldOptions`, `ExpiryOptions`, `LightOptions`, `ReceiverOptions`, `ReceiverTarget`); `Options/RoutingOptions.cs` (`RoutingOptions`, `ServiceRoute`, `OperationRoute`, `ReplyProfile`); `Enums/Enums.cs` (`SoapVersion`, `OperationMode`, `HoldTimeoutAnswer`, `MessageStyle`, `ResultKind`, `DeliveryVerdict`); `Helpers/Utility.cs` (`SafeXml`, `SoapNamespaces`, `XmlHelpers`) |
| `Controllers/` | HTTP entry points (start here) | `SenderSoapController`, `HealthController` |
| `Ingress/` | A caller's SOAP request: handle it, save it to the Outbox, hold a RoundTrip caller and read the answers that come back | `SenderEndpoint`, `OutboxWriter`, `RetryCounters`, `WaiterRegistry`, `Waiter`, `AnswerReader` |
| `Ingress/Validation/` | Requests checked against each service's WSDL | `ContractCatalog`, `ServiceContract`, `ContractOperation`, `ContractPart` |
| `Ingress/Soap/` | SOAP work only the Sender part needs: read the request and its payload label, build replies | `SoapRequest`, `AddressingInfo`, `PayloadInspector`, `BusinessInfo`, `SoapReplyWriter`, `SoapReply` |
| `Routing/` | The route catalogue | `RouteTable`, `RouteDecision` (the catalogue's classes are in `Configurations/Options/RoutingOptions.cs`) |
| `Contracts/` | Content, not code: one WSDL (+ XSD) folder per route, read at start-up, never served | — |
| `Egress/` | Checks on arrival; HTTP out to the real service; answers back over the opposite lane; lost-message check | `ArrivalChecks`, `SoapForwarderHttpClient`, `DeliveryResult`, `AnswerWriter`, `SequenceGapMonitor`, `FarSideMonitor` (+ `FarSideStatus`) |
| `Egress/Workers/` | Background jobs inside the app pool | `InboxWorker`, `ReceiptWorker`, `MaintenanceWorker` |
| `Exceptions/` | Exceptions that change what happens to a message | `BridgeBacklogFullException`, `BridgeRejectException`, `PermanentFailureException` |

Folder map of the shared library:

| Folder | Theme | Classes |
|---|---|---|
| `Configurations/` | Shared settings, all enums, shared helpers | `Options/GatewayDatabaseOptions.cs`; `Enums/Enums.cs` (`BridgeSide`, `Direction`, `PayloadFormat`, `Compression`, `MessageKind`, `MessagePriority`, `ServiceOutcome`, `OutboxLightStatus`, `OutboxServiceStatus`, `InboxLightStatus`, `InboxServiceStatus`); `Helpers/Utility.cs` (`BridgeSideExtensions`, `Hashing`, `StatusCounts`, `SignalNames`, `Components`) |
| `Data/Providers/` | The engine seam (`GatewayDatabase:Provider`, decision 55) | `IBridgeDatabase` (its `Create` picks the engine) |
| `Data/Contexts/` | The one bridge database, engine-free | `BridgeDbContext` (abstract), `BridgeDbContextFactory` |
| `Data/Sqlite/` | Everything only SQLite uses (the default, `qrbridge.db`) | `Providers/SqliteBridgeDatabase`, `Contexts/SqliteBridgeDbContext`, `Contexts/SqliteDesignTimeFactory`, `Initializers/SchemaAdoption`, `Initializers/SqlitePragmaInterceptor`, `Exceptions/SchemaMismatchException`, `Migrations/` (`Initial`, `Bundles`) |
| `Data/SqlServer/` | Everything only SQL Server uses | `Providers/SqlServerBridgeDatabase`, `Contexts/SqlServerBridgeDbContext`, `Contexts/SqlServerDesignTimeFactory`, `Migrations/` (`Initial`) |
| `Data/Initializers/` | Register and create the database | `DataServiceCollectionExtensions` (`AddBridgeData`), `DatabaseInitializer` |
| `Data/Conventions/` | How our types are stored, on every engine | `BridgeConventions`, `GuidStringConverter`, `UtcDateTimeConverter` |
| `Data/Entities/` | Table rows | `BaseMessage` (abstract: the columns Outbox and Inbox share), `OutboxMessage`, `InboxMessage`, `SequenceCounter`, `Heartbeat`, `AcknowledgedGap`, `SequenceWatermark` |
| `Data/Configurations/` | Table shape (EF Fluent API) | `OutboxMessageConfiguration`, `SequenceCounterConfiguration`, `InboxMessageConfiguration`, `HeartbeatConfiguration`, `AcknowledgedGapConfiguration`, `SequenceWatermarkConfiguration`, `CheckConstraints` |
| `Data/Repositories/` | Queue operations, behind interfaces | `IOutboxRepository`, `OutboxRepository`, `OutboxInsert`, `OutboxInsertResult`, `OutboxCounts`, `MessageState`, `IInboxRepository`, `InboxRepository`, `InboxCounts`, `SequenceGap`, `DueReceipt`, `SameContent`, `IHeartbeatRepository`, `HeartbeatRepository` |
| `Serialization/` | What crosses the gap | `MessageSerializer`, `MessageHeader` (`Hashing` is in `Configurations/Helpers/Utility.cs`) |
| `Signals/` | Cross-process wake-ups | `BridgeSignal`, `BridgeSignals`, `SignalNames` |

---

## 3. A call's life through the classes

### 3.1 Sender — a caller's request on the side where the caller is

Example: Rapid Restore FCR posts `SendToFMS` to `/FMS_FC2FMSInterface/FC2FMSInterface.svc` on the Corp gateway
(a `RoundTrip` operation with `OnHoldTimeout: Pending` since step 10c, so the caller is held at step 12).

| Step | Class · method | What happens | If it goes wrong |
|---|---|---|---|
| 1 | `SenderSoapController.Post` (`[Route("{**path}")] [HttpPost]`) | Every POST, whatever the path, goes to `SenderEndpoint` | — |
| 2 | `SenderEndpoint.ReadBodyAsync` | Reads the body, stops at `GatewayDatabase:MaxPayloadBytes` or the route's smaller `MaxRequestBytes` (step 16, D78), before anything is parsed | SOAP fault, HTTP 413 |
| 3 | `SoapRequest.TryParse` (uses `SafeXml`) | Finds SOAP version, operation (first Body element), first parameter text, SOAPAction, WS-Addressing | SOAP fault, HTTP 400 |
| 4 | `PayloadInspector.Inspect` | Reads the business label, e.g. `MESSAGE/@TYPE="REQUEST_FOR_PERMIT"` and `MSG_ID` → `BusinessInfo` | — |
| 5 | `RouteTable.Resolve(path, operation, type)` | Looks up the service by **path**, the operation by **Body element name** and, when the operation lists `Types`, the settings of that **MESSAGE TYPE** → `RouteDecision` | Unknown service/operation → `Reject` |
| 6 | `SenderEndpoint.DecideAsync` | `Reject` → fault; `Echo` → echo the value; `Unavailable` → profile's "1599" reply (or a fault without a profile), nothing stored; `Bridge` and `RoundTrip` → continue (a `RoundTrip` caller is then held in `HoldAsync` for the far side's Reply, step 10a) | — |
| 7 | `ContractCatalog.Check` (→ `ServiceContract.Check`) | The request must match the service's WSDL: SOAP version, the `SOAPAction` header (SOAP 1.1) or Content-Type `action` (SOAP 1.2) when the caller sends one and the WSDL gives one, Body element name and namespace, XSD (document) or parts (RPC). Skipped when the route has no `Contract` | SOAP fault "does not match the service's WSDL … NOT accepted" |
| 8 | `SenderEndpoint.DecideAsync` (allow-list) | `MESSAGE/@TYPE` must be in the operation's `AllowedTypes` | Profile's `Rejected` reply ("1597") |
| 9 | `MessageHeader` | Service, operation, label + the replay details (path, SOAPAction, Content-Type), content fingerprint, the route's `Priority` (`RouteTable.SettingsOf`, step 14), `CallerHost` (`SenderEndpoint.CallerHostOf`, step 15) and, for `RoundTrip`, `ExpiresUtc` (a query: now + hold, D54; `Pending`: now + `Gateway:Expiry`, D62), next to the **exact** body bytes | — |
| 10 | `OutboxWriter.EnqueueAsync` | Same content in the retry window? (attach on `RecogniseRetries` routes — unless that message's service status is `Expired`, `NotDelivered` or `Rejected`: then a new message, D63 — else count) → backlog check (Requests only; `Gateway:MaxBacklog` and the service's own `MaxBacklog`, step 16) → next sequence → `MessageSerializer.Serialize` (pack) → insert `OutboxMessage` → **commit** → ring `BridgeSignals.Outbox` | Backlog full → profile's `Busy` ("1598"); DB error → fault "NOT accepted" |
| 11 | `SoapReplyWriter.Result` (`Bridge` only) | Builds the reply the caller's proxy expects, filled from the profile's `Ok` value | — |
| 12 | `SenderEndpoint.HoldAsync` (`RoundTrip` only, step 10a) | Registers a `Waiter` in `WaiterRegistry`, then re-reads the Outbox row (`OutboxRepository.FindStateAsync`) every 2 s or when `AnswerReader` wakes it, until the service status leaves `Waiting` or `Gateway:Hold` runs out. Answered/Refused with the real answer → that answer byte for byte; Unknown or no answer carried → the route's `OnHoldTimeout` answer; Expired/NotDelivered/Rejected → "not available" (D50) | Hold runs out, or light `Failed` (D55) → `OnHoldTimeout` answer (`Pending` = 1596, `Unavailable` = "not available"). Caller hangs up → the message stays queued |

The reply is sent only **after** step 10 commits. A caller that hears "OK" (or is held) has a message that survives a crash.

The one plain GET interface, Registered Tags (step 12, D18), takes a shorter path: `SenderSoapController.Get` →
`SenderEndpoint.HandleGetAsync` → `RouteTable.Resolve(path, "GET", null)` → a `MessageHeader` with `PayloadFormat.HttpGet`
and an empty body (no WSDL check, no allow-list, no content fingerprint) → `OutboxWriter.EnqueueAsync` → held like
step 12 → the real answer (status, Content-Type, body) or HTTP 504 text/plain ([§4.3](#43-ingress)).

### 3.2 Receiver — the same message on the other side

The QR link (not this solution) copies the envelope into the Inbox of the other machine's `qrbridge.db`.

| Step | Class · method | What happens | Outcome on failure |
|---|---|---|---|
| 1 | `InboxWorker.ExecuteAsync` | Runs one delivery loop per class (`DeliveryClasses`: High, Normal, Low; step 14, D73). Each waits on `BridgeSignals.Inbox` (it wakes one loop) or polls every `InboxPollSeconds` | — |
| 2 | `InboxRepository.ClaimNextAsync(priority)` | Atomically moves one **Request** row of the loop's class with `LightStatus` `Received` and `ServiceStatus` `Pending` (or due `Retrying`) → `Delivering`: the sender's counter runs in the order they started, then `Sequence`; skipped while an earlier Request of the same service and class is `Retrying` (strict order, D74). Receipts, Replies and Heartbeats are never claimed | — |
| 3 | `MessageSerializer.Deserialize` | Checks the SHA-256 checksum (header + body), decompresses | Reply `Rejected`, then `LightStatus` `Rejected` |
| 4 | `InboxWorker.Validate` → `ArrivalChecks.CheckAsync` | Row columns (incl. `Kind`, `CorrelationId`, `SequenceRunId`, `ContentFingerprint`, `ExpiresUtc`, `Priority`) match the envelope header; the sender's `CatalogFingerprint` equals this side's (same `routes.json`); direction, format, age and clock skew are right; on the row's first check its sequence number is not reused or old (D84, step 17); then the row is marked `Verified` (`ArrivalChecks`, shared with `AnswerReader`); then `Validate` itself: it is a Request (a Receipt, Reply or Heartbeat is never posted) | Reply `Rejected`, then `LightStatus` `Rejected` |
| 5 | `InboxWorker.Plan` | Service must be delivered by **this** side and be in `Bridge` or `RoundTrip` mode (step 10a); an `HttpGet` message only for the `HttpGet` route, and a SOAP message never for it (step 12); target URL from `SoapForwarderHttpClient.ResolveTarget` | Reply + `LightStatus` `Rejected`, or Reply + `ServiceStatus` `NotDelivered` if no target configured |
| 5b | `InboxRepository.FindSameContentAsync` (layer 3b, step 10b; only routes with `RecogniseRetries`) | Same `ContentFingerprint` arrived within `Gateway:RetryWindowMinutes`? Earlier one `Done` → not posted, `AnswerWriter.ReuseDoneAsync` ends this one `Done` with the earlier Reply's answer; earlier one `Unknown` or still `Delivering` → not posted, `Unknown`; `Refused`/`NotDelivered`/`Expired` → posted normally | — |
| 6 | `SoapForwarderHttpClient.ForwardAsync` | POSTs the same bytes with the same SOAPAction and Content-Type (only WS-Addressing `To` may change); an `HttpGet` message is sent as a GET with no body, SOAPAction or Content-Type (step 12). The HTTP client is chosen per service (`ClientNameFor`, D75). `InboxWorker` logs the caller (`CallerHost`), never the payload | — |
| 7 | `SoapForwarderHttpClient.Classify` | Turns the HTTP answer into a `DeliveryVerdict` (+ the HTTP code, Content-Type and body of the answer) | — |
| 8 | `AnswerWriter.FinishAsync` | For a final outcome: **first** a Reply into this side's Outbox (`Kind = Reply`, `CorrelationId` = the Request, `Outcome`, HTTP status, comment, the real answer byte for byte), **then** `InboxRepository.Mark…Async`. `Delivered` → `Done`; `Refused`/`Permanent` → `Refused`; `Unknown` → `Unknown`; `Transient` out of tries → `NotDelivered`. Past `ExpiresUtc` → `Expired` before any POST; a shutdown during the POST → `Unknown`. `Transient` with tries left → `InboxRepository.MarkRetryingAsync` (backoff, no Reply yet); a round-trip query (`OnHoldTimeout: Unavailable`) is not retried: `NotDelivered` at once (step 10b) | — |

Separately, `ReceiptWorker` sends a **Receipt** for every arrived message (Requests, Replies, Rejected rows; never for
a Receipt or a Heartbeat) every `InboxPollSeconds`, from the Inbox column `ReceiptDueUtc`, again when the same `MessageId` arrives a
second time. Meanwhile `MaintenanceWorker` runs every minute: it settles rows still `Delivering` after a crash (from
the Reply written for their current attempt, or `Unknown` with an Unknown Reply), looks for messages that never arrived (`SequenceGapMonitor`),
puts Outbox rows aired with no Receipt back to Pending or Failed (`ReairUnconfirmedAsync`, step 11),
queues a Heartbeat message when this side has sent nothing for a while and warns when the far side is silent
(`FarSideMonitor`, step 17), writes component heartbeats and logs warnings an operator should see. It deletes nothing (decision D28).

Receipts, Replies and Heartbeats wait in this side's Outbox for the QR link like any other row. On the other side `AnswerReader`
reads them (step 10a): a Receipt → Outbox light `Received`; a Reply → the Outbox row's service status and answer, then
the held callers are woken; a Heartbeat → Inbox `Done` (step 17: its arrival is what "far side last heard" reads). But nothing carries them over the real light yet ([§10](#10-built-used-only-by-tests-and-not-built)).

---

## 4. QrBridge.Gateway, class by class

**File layout:** one main type per file, named after it (`RouteTable` is in `RouteTable.cs`); all exception classes in
`Exceptions/` (one file each). Grouped instead: a record that belongs to a class sits in that class's file
(`RouteDecision` in `RouteTable.cs`). Each project has a `Configurations/` folder: `Options/` holds the settings classes,
one file per settings section with all its parts (`RoutingOptions.cs` = the whole `routes.json` shape);
`Enums/Enums.cs` holds **all** the project's enums; `Helpers/Utility.cs` holds the static helpers used across the
project (`SafeXml`, `SoapNamespaces`; in Shared `BridgeSideExtensions`, `Hashing`, `SignalNames`, `Components`).
Everything under `Configurations/` is in the project's root namespace (`QrBridge.Gateway`, `QrBridge.Shared`).
Private nested types stay inside their class.

### 4.1 Root folder

#### `Program` (`Program.cs`)
The gateway's `main`: about 20 lines, one call per start-up step. The work is in `Initializer/` (below).
`public partial class Program {}` at the end lets the tests start the real app with `WebApplicationFactory`.

#### `Initializer/` — one static class per start-up step
Each is an extension method that `Program` calls, in this order:

| Class (file) | Method | What it registers or does |
|---|---|---|
| `OptionsRegistration` | `builder.AddGatewayOptions()` | Adds `routes.json` to configuration; binds `GatewayDatabaseOptions` (`GatewayDatabase`), `GatewayOptions` (`Gateway`), `RoutingOptions` (`Routing`) |
| `DataRegistration` | `AddGatewayData()` | The data layer (`AddBridgeData`: EF Core + SQLite, the stores), `MessageSerializer`, `BridgeSignals` |
| `RouteCatalogRegistration` | `AddRouteCatalog()` | `RouteTable` and `ContractCatalog` (reads `Contracts/` under the content root) |
| `EndpointRegistration` | `AddGatewayEndpoints()` / `app.MapGatewayEndpoints()` | MVC controllers (`AddControllers` / `MapControllers`) — see [§4.2](#42-controllers) |
| `SenderRegistration` | `AddSenderPart()` | `RetryCounters`, `OutboxWriter`, `WaiterRegistry` (held RoundTrip callers), `SenderEndpoint`; hosted `AnswerReader` (Receipts and Replies for this side's messages, step 10a) |
| `ReceiverRegistration` | `AddReceiverPart()` | `SoapForwarderHttpClient` and its three named `HttpClient`s (`"receiver"` with `Gateway:Receiver:UseDefaultCredentials`, `"receiver-default-credentials"`, `"receiver-anonymous"`; D75, step 15): **no redirects**, no client-wide timeout (per call instead); `ArrivalChecks` (every message from the light, whatever its kind); `AnswerWriter` (Receipts and Replies over the opposite lane) |
| `WorkerRegistration` | `AddBackgroundWorkers()` | Hosted `InboxWorker`, `ReceiptWorker` and `MaintenanceWorker` (and the `SequenceGapMonitor` and `FarSideMonitor` singletons); 45 s shutdown; a worker exception is logged and ignored so it cannot take the endpoints down |
| `StartupChecks` | `await app.RunStartupChecksAsync()` | After `Build`, before any call is accepted (see below) |

**Start-up checks** (`StartupChecks`) — the gateway refuses to start when:
- `LockTimeoutMinutes × 60` is not longer than every receiver timeout + 30 s (a slow delivery could be sent twice);
- `ReplayWindowDays`, `MaxClockSkewMinutes` or `RetryWindowMinutes` is zero or less, or `GapGraceMinutes` is below zero. (Until 24 Nov it
  also refused `RetentionDays < ReplayWindowDays`; rows are no longer deleted, so a replayed message is always caught
  by its `MessageId`, the Inbox primary key);
- `ReceiptTimeoutSeconds` or `MaxAirAttempts` is zero or less (step 11);
- `HeartbeatMinutes` is below zero, or `FarSideSilentMinutes` is zero or less or not longer than `HeartbeatMinutes` (an
  idle but healthy far side would look down; D82, step 17);
- `Receiver:ConnectTimeoutSeconds` is zero or less, or not shorter than every receiver timeout (D42);
- `Hold:DefaultSeconds` or a `Hold:Services` override is zero or less, or the override names a service whose callers
  are not on this side;
- `Expiry:DefaultSeconds` or an `Expiry:Services` override is zero or less, names a service whose callers are not on
  this side, or is not longer than that service's hold (D62, step 10c);
- `Light:BytesPerSecond` is zero or less, or `Light:MinAirSeconds` / `Light:GapSeconds` is negative (D79, step 16);
- a Receiver URL (`DefaultBaseUrl` or a `Targets[…].Url`) is not an absolute http(s) URL, or is plain `http://` outside
  the Development environment while `Gateway:Receiver:AllowHttp` is false (V6 review G-09);
- the route catalogue is invalid (`RouteTable` constructor throws — since steps 14 and 16 also for `"Priority": "Answer"`
  or a `MaxRequestBytes` / `MaxBacklog` of zero or less; for an `HttpGet` service see `CheckHttpGet`, [§4.5](#45-routing));
- a route's `Contract` folder is missing or invalid, or lists an operation its WSDL does not have
  (`ContractCatalog` constructor throws). A route on this side with no `Contract` is logged as a warning.

It also logs a **warning** (not a refusal; `AirTimeWarnings`, D79, step 16) for each RoundTrip route on this side whose
size limit (`MaxRequestBytes`, else `GatewayDatabase:MaxPayloadBytes`) takes longer to air at `Gateway:Light` speed than its
hold: at 1 MB about 151 s, so on the DMZ side (90 s hold) every DMZ round-trip route warns, and on any side with a
short hold the legacy routes do. It also **warns** (never refuses) when the gateway process runs elevated, as an
administrator (`AdministratorWarning(Environment.IsPrivilegedProcess, Environment.UserName)`; D4, step 18): use a
dedicated app pool identity per side (guide §12.4).

Then it creates or opens the database `qrbridge.db` (`DatabaseInitializer.InitializeAsync`; refused while a former `send.db` or `received.db` is in the data folder) and logs the start-up line, which includes the catalogue fingerprint (`Catalogue=…`).

#### `GatewayOptions`, `HoldOptions`, `ExpiryOptions`, `LightOptions`, `ReceiverOptions`, `ReceiverTarget` (`Configurations/Options/GatewayOptions.cs`)
Gateway-only settings from the `Gateway` section.

| Group | Settings | Used by |
|---|---|---|
| Back-pressure | `MaxBacklog` (counts Requests only, D47; a service's own `MaxBacklog` is in `routes.json`, step 16) | `OutboxWriter` |
| Retries | `RetryWindowMinutes` | `OutboxWriter` (attach), `InboxWorker` (layer 3b, step 10b) |
| Hold | `Hold` → `HoldOptions` (`DefaultSeconds`, per-service `Services`; Corp 270 s, DMZ 90 s in appsettings) | `SenderEndpoint.HoldAsync`, `StartupChecks` |
| Expiry | `Expiry` → `ExpiryOptions` (`DefaultSeconds`, per-service `Services`; 600 s on both sides): `ExpiresUtc` of a state-changing RoundTrip call (`OnHoldTimeout: Pending`, D62, step 10c) | `SenderEndpoint.DecideAsync`, `StartupChecks` |
| Inbox worker | `InboxPollSeconds`, `MaxAttempts`, `BackoffBaseSeconds`, `BackoffMaxMinutes`, `ReplayWindowDays`, `MaxClockSkewMinutes` | `InboxWorker` (`ReceiptWorker` and `AnswerReader` also use `InboxPollSeconds`; `ArrivalChecks` the replay window and clock skew) |
| Maintenance | `MaintenanceIntervalSeconds`, `LockTimeoutMinutes`, `GapGraceMinutes`, `ReceiptTimeoutSeconds` (120), `MaxAirAttempts` (3) | `MaintenanceWorker` (→ `AnswerWriter.RecoverStuckAsync`, `OutboxRepository.ReairUnconfirmedAsync`), `SequenceGapMonitor`, `StartupChecks` |
| Far side | `HeartbeatMinutes` (5; 0 = off), `FarSideSilentMinutes` (15; must be longer than `HeartbeatMinutes`), same on both sides (D81, D82, step 17) | `FarSideMonitor`, `StartupChecks` |
| Light | `Light` → `LightOptions` (`BytesPerSecond` 6700, `MinAirSeconds` 6, `GapSeconds` 1.5; `AirSecondsFor(bytes)`): the V6 review's arithmetic for QrDiode, not measured (D79) | `StartupChecks.AirTimeWarnings` only |
| Receiver | `Egress` → `ReceiverOptions` | `SoapForwarderHttpClient`, `ReceiverRegistration`, `StartupChecks` |

`ReceiverOptions` says where delivered messages go: `DefaultBaseUrl` (+ the caller's original path), or a
per-service `Targets[name]` (`ReceiverTarget`: `Url`, optional `TimeoutSeconds`, optional `UseDefaultCredentials`
that overrides the global one for that service, D75). Also `TimeoutSeconds`, `AllowHttp`
(test benches only), `UseDefaultCredentials` (app pool identity or anonymous; never a password), `RewriteAddressingTo`, `MaxResponseBytes`. The URL is **never** taken
from the message.

### 4.2 `Controllers/`

**Start here** to see where HTTP requests land. Two small MVC controllers, registered by `Initializer/EndpointRegistration`
(`AddControllers()` / `MapControllers()`). They hold no SOAP logic, like an Angular component that calls a service.

| Controller | Route | Hands to | Purpose |
|---|---|---|---|
| `SenderSoapController` | `[Route("{**path}")]` `[HttpPost]` | `SenderEndpoint.HandleAsync` | Every SOAP call, whatever the path |
| `SenderSoapController` | `[Route("{**path}")]` `[HttpGet]` | `SenderEndpoint.HandleGetAsync` | Only a route marked `"HttpGet": true` on this side answers (Registered Tags on Corp, step 12, D18); any other GET gets 405 |
| `HealthController` | `[Route("health")]` `[HttpGet]` | `OutboxRepository`, `InboxRepository`, `HeartbeatRepository`, `SequenceGapMonitor`, `FarSideMonitor`, `RetryCounters`, `RouteTable` | JSON: side, light and service counts per queue (each with `oldestUndeliveredUtc`), `catalogFingerprint`, `missingMessages`, up to 20 `gaps`, `gapsCheckedUtc`, `retries` (`attached`, `sameContentQueued`, `sinceUtc`), `lightProblems` (Outbox Failed + missing messages), `serviceProblems`, `farSide` (`lastHeardUtc`, `lastReceiptUtc`, `silent`, `silentAfterMinutes`; step 17), heartbeats, stale components, `healthy` flag (false also when the far side is silent, D83). The load balancer's health probe |

- `{**path}` is a catch-all: it matches any path, including `/`.
- **`/health` and the `HttpGet` route are the only GETs.** Any other GET, and every HEAD (`?wsdl`, `?xsd=…`, a plain
  GET on a service path, `/`, the Registered Tags path on the DMZ gateway), gets HTTP 405. The gateway serves no WSDL
  or help pages: the fms-interface-simulator's clients are
  compiled WCF proxies and never download one.
- `SenderSoapController` is **not** `[ApiController]` and takes **no parameters**. That is on purpose: MVC model
  binding would try to parse the body (a `[FromBody] string` with `text/xml` gets HTTP 415, because only JSON is
  registered), and `[ApiController]` would answer errors with JSON. The gateway needs the raw bytes untouched and
  SOAP faults only.

### 4.3 `Ingress/`

#### `SenderEndpoint`
Handles **every SOAP POST** (called by `SenderSoapController`), and the one plain GET interface (`HandleGetAsync`,
step 12). It knows no service's contract itself: for `Bridge`
and RoundTrip operations it asks `ContractCatalog` ([§4.6](#46-ingressvalidation)). It saves accepted calls with `OutboxWriter`
(below). Flow: see [§3.1](#31-sender--a-callers-request-on-the-side-where-the-caller-is).

| Member | Role |
|---|---|
| `HandleAsync(HttpContext)` | Read body → parse → resolve route → inspect payload → decide → write reply. A SOAP POST to an `HttpGet` route's path → SOAP fault "plain HTTP GET interface", nothing queued |
| `HandleGetAsync(HttpContext)` | Step 12 (D18, D69–D72). A GET answers only when the path is a route marked `HttpGet` whose callers are on this side; else 405. A query string → HTTP 400, nothing queued (D71). Otherwise queues a Request with `PayloadFormat.HttpGet` (empty body, empty Content-Type, no SOAPAction, no content fingerprint, so never attached to an earlier call), `ExpiresUtc` = now + hold (D54), and holds the caller for `Gateway:Hold` (Corp 270 s, D70). The caller gets the real answer (HTTP status, Content-Type, body; no other header) when the far side's outcome is Done or Refused with an answer, else HTTP 504 text/plain "RegisteredTags is not available while the network is islanded: …" (D69): hold ran out, Unknown, NotDelivered, Expired, Rejected, answer too large to carry back, Outbox full |
| `DecideAsync(...)` | The `switch` on `OperationMode`, the WSDL check, the allow-list check, `OutboxWriter.EnqueueAsync`, and the choice of reply. For RoundTrip it sets `ExpiresUtc`: a query (`OnHoldTimeout: Unavailable`) now + hold (D54); a state-changing call (`Pending`) now + `Gateway:Expiry` (D62) |
| `HoldAsync(...)` | RoundTrip only (step 10a): holds the caller for `Gateway:Hold` (`HoldFor`: per service, else `DefaultSeconds`), re-reading the Outbox row every 2 s or when woken; light `Failed` → hold-timeout answer at once (D55). A retry attached to the same message waits the same way. Caller hangs up → the message stays queued |
| `AnswerFrom(...)` | The answer for a held caller (D50): Answered/Refused with a real answer → its HTTP status, Content-Type and body byte for byte; Answered/Refused without one, or Unknown → `HoldTimeout`; Expired/NotDelivered/Rejected → `NotAvailable` |
| `HoldTimeout(...)` / `NotAvailable(...)` | `OnHoldTimeout`: `Pending` = the profile's `Pending` value (1596), `Unavailable` = the profile's `Unavailable` value (1599) or a SOAP fault |
| `StyleFor(...)` | Document or RPC reply: from the catalogue, else guessed (unqualified parameters = RPC) |
| `Fill(template, business, messageId)` | Replaces `{BusinessType}`, `{MsgId}`, `{MessageId}` in reply-profile text; values are XML-escaped |
| `ReadBodyAsync(...)` | Reads in 16 KB chunks; returns `null` once over the limit (`GatewayDatabase:MaxPayloadBytes`, or the route's smaller `MaxRequestBytes`, found by path before parsing; step 16) |
| `CallerHostOf(HttpContext)` | Step 15 (D76): the first `X-Forwarded-For` address labelled with the connection's (`"10.1.2.3 (via 10.0.0.9)"`), else the connection's address; only address characters are taken from the header. Set on every queued Request (SOAP and the `HttpGet` route) as `CallerHost` |
| `MessageIdHeader` | `X-QrBridge-MessageId` response header: the Gateway-to-QrDiode system id of an accepted call |

#### `OutboxWriter` and `BridgeBacklogFullException`
**The one place messages enter the Gateway-to-QrDiode system:** callers' Requests (from `SenderEndpoint`) and this side's Receipts and
Replies (from `AnswerWriter`, [§4.7](#47-egress)). `EnqueueAsync(header, body, attachRetries)` → `EnqueueResult(MessageId, Attached)`.
Since 27 Nov (decision 55) `OutboxWriter` decides the rules and builds the row, and the storage steps below run inside
`IOutboxRepository.InsertAsync` (it never opens the database itself); the repository answers Queued, Attached or
BacklogFull and the writer logs, counts, throws or rings the doorbell:

1. Open a write transaction (`BridgeDbContext.BeginWriteTransactionAsync`: SQLite `BEGIN IMMEDIATE`, one writer at a
   time for the whole file; SQL Server an exclusive `sp_getapplock` held to commit).
2. **A caller's retry?** (Requests only.) When the header has a `ContentFingerprint`, look for the first Request in
   this direction with the same fingerprint, created within `Gateway:RetryWindowMinutes` (decision D5), leaving out
   one whose service status is `Expired`, `NotDelivered` or `Rejected` (surely not done: the call is queued as a new
   message with a fresh expiry, D63). If there is one and
   `attachRetries` (the route's `RecogniseRetries`, D37): return it, `Attached = true` — nothing queued, even when
   the backlog is full; counted in `RetryCounters.Attached` and logged (ids only). Otherwise go on, and count it as
   "same content queued again" after the commit. Because this check shares the write transaction with the insert,
   identical calls at the same moment make one row (no unique index: it could not express the time window).
3. **Backlog** (Requests only, decision D47): count Outbox rows with `Kind = Request` and `LightStatus`
   `Pending + Sending + Aired` in that transaction; if `≥ MaxBacklog`, throw `BridgeBacklogFullException`. Then, when
   the service has its own `MaxBacklog` in `routes.json` (step 16, D78; none set today), the same count for that
   service only.
   Counting inside the transaction means simultaneous calls cannot all see room (V6 review G-13). Receipts and Replies
   skip steps 2 and 3: they are never refused for a full Outbox and never count towards it, so answers never make
   this side turn its own callers away.
4. `OutboxRepository.NextSequenceAsync` (inside `IOutboxRepository.InsertAsync`, since 27 Nov) — `UPDATE SequenceCounter
   SET LastValue = LastValue + 1, RunId = COALESCE(RunId, @run) …`, then a read of the row, in the same write
   transaction (per-direction sequence, no gaps from concurrent callers: the write lock keeps the two statements
   together on both engines; until 27 Nov one SQLite `UPDATE … RETURNING`; the
   counter's run id is set on its first use and never changes, decision D27). Every kind shares the one sequence.
5. Complete the `MessageHeader` (new `MessageId`, this side's send direction, business type
   truncated to 256 chars, the Request's payload format (`RawSoap`, or `HttpGet` for the plain GET, step 12; Receipts and Replies always `RawSoap`), `Brotli`, sequence, `SequenceRunId`, `CatalogFingerprint`, time; Receipts and Replies get `Priority` `Answer`, step 14).
6. `MessageSerializer.Serialize(header, body)` — to bytes (Brotli + checksum; no encryption).
7. Insert an `OutboxMessage` (`LightStatus` `Pending`, `ServiceStatus` `Waiting`, the header's `Kind`, `CorrelationId`,
   `ContentFingerprint`, `ExpiresUtc`, `Priority`, `MessageHash` = SHA-256) and **commit**.
8. Ring `BridgeSignals.Outbox` so the QR sender wakes up.
9. Return the new `MessageId`, `Attached = false`.

`SenderEndpoint` computes the fingerprint before the call with `ContentFingerprint.Compute` (`Ingress/Soap/`): SHA-256
of service, operation, MESSAGE TYPE, the operation element as received and its payload, with the route's
`FingerprintIgnore` names removed wherever they appear; whitespace kept, SOAP headers left out; null when the payload
cannot be read safely (decision D38).

`BridgeBacklogFullException` (`Exceptions/BridgeBacklogFullException.cs`): `SenderEndpoint` catches it and gives the caller the
profile's `Busy` reply (or an HTTP 503 fault).

#### `WaiterRegistry` and `Waiter`
The held RoundTrip callers, by the `MessageId` they wait for (several when a retry is attached to the same message).
`Register(messageId)` returns a `Waiter` (dispose it when the call ends); `Wake(messageId)` signals every waiter for
that message; `Count` = callers held now. Only a speed-up: a held caller also re-reads the Outbox every 2 s, so a
missed wake-up delays an answer, never loses it. In memory, so IIS must run **one worker process** for the gateway
(no web garden).

#### `AnswerReader`
Hosted service on the **sending** side (step 10a), polling every `Gateway:InboxPollSeconds` (it does not wait on the
Inbox doorbell: that event wakes one waiter per ring, and `InboxWorker` needs every ring). For each arrived Receipt,
Reply or Heartbeat (`InboxRepository.FindArrivedAnswersAsync`): deserialize, `ArrivalChecks.CheckAsync` ([§4.7](#47-egress)), then the
`CorrelationId` of a Receipt or Reply must name a message this side sent, for the same service and operation (a Reply only a
Request; never a Receipt or a Heartbeat).

| Kind | What it does |
|---|---|
| Receipt | `OutboxRepository.MarkReceivedAsync` → light `Received`; Inbox row `Done` |
| Reply | `OutboxRepository.MarkAnsweredAsync` with the outcome (Done → `Answered`, Refused, Unknown, Expired, NotDelivered, Rejected), the HTTP status, comment, real answer and the Reply's `CreatedUtc` (D59); then `WaiterRegistry.Wake`; Inbox row `Done` (also when the answer was not stored because one already kept stands) |
| Heartbeat (step 17, D80) | Inbox row `Done` ("Heartbeat: the far side is alive."); its arrival is what `FarSideMonitor` reads as "last heard" |
| Failed check, or answers no message of this side (or names a Receipt or Heartbeat) | Inbox row `Rejected` (`MarkRejectedAsync`) |

Nothing here is ever posted to a service.

### 4.4 `Ingress/Soap/` (and the SOAP helpers)

#### `SoapVersion` (enum, `Configurations/Enums/Enums.cs`) and `SoapNamespaces` (static, `Configurations/Helpers/Utility.cs`)
`Soap11` / `Soap12`, the namespace constants (SOAP 1.1, 1.2, SOAP encoding, WS-Addressing 1.0 and 2004/08), and
helpers: `Envelope(version)`, `ContentType(version)`, `IsAddressing(ns)`.

#### `AddressingInfo` (record)
The WS-Addressing headers of a request (`Namespace`, `Action`, `MessageId`, `To`), kept so the reply can carry a
matching `Action` and `RelatesTo`.

#### `SoapRequest`
What the gateway needs to know about **any** SOAP request: SOAP 1.1 or 1.2, document/literal or RPC/encoded, with
or without WS-Addressing.

| Property | Meaning |
|---|---|
| `Version` | SOAP 1.1 or 1.2 |
| `Operation`, `OperationNamespace` | Local name and namespace of the first Body element (e.g. `SendToFMS`, `http://tempuri.org/`) |
| `ParametersUnqualified` | First parameter has no namespace → RPC/encoded shape |
| `OperationElement` | The first Body element itself, for the WSDL check |
| `FirstParameterText` | Text of `sXML` / `XMLMsg` / `sValue`, or null if it has child elements |
| `SoapActionHeader` | The header **exactly** as received, quotes included |
| `Action` | Unquoted action: `wsa:Action`, else SOAPAction, else the Content-Type `action=` parameter (SOAP 1.2) |
| `Addressing` | `AddressingInfo` or null |

`TryParse` never throws on bad input; it returns `false` and a message safe to show the caller. It finds
elements with `XmlHelpers.ChildElement` / `FirstChildElement` (`Configurations/Helpers/Utility.cs`), which
`PayloadInspector` and `SoapForwarderHttpClient` use too.

#### `SafeXml` (static, `Configurations/Helpers/Utility.cs`)
**The one way the project loads untrusted XML.** DTDs prohibited (blocks XXE and entity-expansion bombs), no
resolver, a character cap, comments and processing instructions ignored. `Load(bytes)`, `LoadText(string)`,
`Settings(max)`.

#### `BusinessInfo` (record) and `PayloadInspector` (static) — `Ingress/Soap/`
Reads the **label** of the XML string inside the SOAP parameter. It never changes the payload.

| Payload shape | `BusinessInfo.Type` | `MsgId` |
|---|---|---|
| ConEd `<MESSAGE TYPE="RETURN_ORDER" MSG_ID="456">` | `RETURN_ORDER` | `456` |
| Verizon SOAP envelope passed as a string | Name of its Body element, e.g. `createTicketResponse` | — |
| Anything else that is XML (e.g. ANSI tML-TA) | Root element name | — |
| Not XML (an `EchoString` value) | null (`BusinessInfo.None`) | — |
| Looks like XML but is broken | null, `WellFormed = false` | — |

Used for the allow-list, for the `{BusinessType}`/`{MsgId}` reply placeholders, and as an operator label stored
with the message. `MSG_ID` is often a static template value — it is a label, never an identity.

#### `SoapReply` (record) and `SoapReplyWriter` (static) — `Ingress/Soap/`
`SoapReply` = status code + body bytes + content type. `SoapReplyWriter` builds replies a WCF, ASMX or SOAP Toolkit
client accepts, in the request's SOAP version:

| Method | Produces |
|---|---|
| `Result(request, style, resultElement, value)` | Document: `<OpResponse xmlns="ns"><OpResult>value</OpResult></OpResponse>`. RPC: `<m:OpResponse xmlns:m="ns"><Result>value</Result></m:OpResponse>` |
| `EmptyResponse(request)` | `<OpResponse/>` — WCF reads it as null / default / void. Used when the contract is unknown |
| `Accepted()` | HTTP 202, empty body (one-way operations) |
| `Fault(version, addressing, senderFault, reason, status)` | SOAP 1.1 `faultcode/faultstring` or SOAP 1.2 `Code/Reason` |

When the request used WS-Addressing, the reply carries `Action` = request action + `"Response"` and `RelatesTo` =
the request's `MessageID`. Reply **values** come from `routes.json` reply profiles, never hard-coded here.

### 4.5 `Routing/`

#### `RoutingOptions` and its parts (`Configurations/Options/RoutingOptions.cs`)
The C# model of `routes.json` (`Routing` section), all in one file.

| Class | Holds |
|---|---|
| `RoutingOptions` | `AcceptUnlisted`, `UnlistedOneWay`, `ReplyProfiles` (by name), `Services` (list) |
| `ReplyProfile` | `ResultKind` + the four reply texts `Ok`, `Busy`, `Unavailable`, `Rejected` |
| `ServiceRoute` | `Name`, `Description`, `SenderSide`, `Paths`, `Style`, `Contract` (folder under `Contracts/`), `ResultElement`, `OtherOperations`, `Operations`, `HttpGet` (a plain HTTP GET interface, not SOAP; step 12, D18), `MaxRequestBytes` and `MaxBacklog` (optional per-service limits, step 16, D78) |
| `OperationRoute` | `Mode`, `Reply` (profile name), `OneWay`, `AllowedTypes`, `Priority` (optional class override, step 14; also per message type in `Types`) |

Enums (in `Configurations/Enums/Enums.cs`):

| Enum | Values | Meaning |
|---|---|---|
| `OperationMode` | `Bridge` | Store, reply OK, deliver on the other side |
| | `Echo` | Answer locally with the input (`EchoString`) |
| | `Unavailable` | Needs a live answer that cannot cross the gap: reply "not available" |
| | `Reject` | SOAP fault |
| `MessageStyle` | `Document`, `Rpc` | Shape of the reply's result element |
| `ResultKind` | `None` | Any 2xx without a fault = delivered |
| | `FmsResponse` | Read `RETURN_CODE` in an FMS `<RESPONSE>` document: 0 = accepted |
| | `ReturnCode` | Result is a number: 0 = accepted |

#### `RouteTable` and `RouteDecision`
`RouteTable` is a singleton built once at start-up. Its constructor **validates** the catalogue (names present
and ≤ 64 chars, no duplicate names, every service has paths, no path claimed twice, every `Reply` names an existing
profile; RoundTrip routes can give their `OnHoldTimeout` answer — `Pending` needs a profile `Pending` value — and are
not `OneWay`; `Types` keys are in `AllowedTypes` and their mode is `Bridge`, RoundTrip or Unavailable; no empty
`FingerprintIgnore` name; no `"Priority": "Answer"`; `MaxRequestBytes` and `MaxBacklog`, when set, positive) and throws with a list of problems. `CheckHttpGet` (step 12) adds the rules for an `HttpGet`
service: exactly one path, no `Contract`, `OtherOperations: Reject`, exactly one operation `"GET"`
(`RouteTable.HttpGetOperation`) with Mode RoundTrip or Unavailable, `OnHoldTimeout: Unavailable`, `RecogniseRetries`
off, and no reply profile, `OneWay`, `AllowedTypes` or `Types`.

| Member | Role |
|---|---|
| `NormalizePath(path)` | Removes query/fragment, trailing and doubled slashes; `"/"` for empty. Lookups are case-insensitive |
| `FindByPath`, `FindByName`, `Profile(name)` | Lookups |
| `Resolve(path, operation, type)` | The Sender part's decision → `RouteDecision` (mode, profile, `OnHoldTimeout`, and the `FingerprintIgnore` fields of catalogue + operation + type) |
| `ModeOf(service, operation, type)` | The same mode for a listed service; `InboxWorker.Plan` delivers only `Bridge` |
| `SettingsOf(service, operation, type)` (static) | → `RouteSettings(Mode, OnHoldTimeout, RecogniseRetries, Priority)`, the operation's settings with its message type's on top. Default `Priority` (step 14, D73): `High` for RoundTrip with `OnHoldTimeout: Pending`, `Normal` for RoundTrip queries (incl. the Registered Tags GET, PortalSync), `Low` for `Bridge`; an explicit `Priority` wins |
| `Services`, `Options` | For `/health` logging and `InboxWorker.Plan` |
| `CatalogFingerprint` | Lower-case hex SHA-256 of a canonical JSON (object properties sorted, array order kept) of the services, reply profiles and `FingerprintIgnore` list — not the local test switches `AcceptUnlisted` / `UnlistedOneWay`. Computed once in the constructor (decision D31). `OutboxWriter` puts it in every header, `InboxWorker.Validate` rejects a message whose sender had another one, `/health` and the start-up line show it |

`Resolve` rules, in order:

1. Path not listed → `Reject`, unless `AcceptUnlisted` (then `Bridge` with an automatic empty reply; the stored
   service name is the path).
2. Service's `SenderSide` is not this side → `Reject` (its callers are on the other side).
3. Operation listed → its mode and reply profile (`Reject` → fault).
4. Operation not listed → `OtherOperations` (default `Reject`).

`RouteDecision` (record) = `ServiceName`, `Service`, `Operation`, `Mode`, `Profile`, `OneWay`, `Problem`.

### 4.6 `Ingress/Validation/`

Checks a caller's request against the real service's WSDL **before** it is queued, so a malformed call is refused
while the caller is still on the line instead of failing at the real service hours later. The WSDL and XSD files
live in `Contracts/Inbound/{folder}/` and `Contracts/Outbound/{folder}/` (the direction folder follows the route's `SenderSide`; copied from the fms-interface-simulator's `Service References`; see
`Contracts/README.md`). They are read from disk only — the gateway still serves no WSDL (decision 21).

#### `ContractCatalog` — `ContractCatalog.cs`
Singleton built at start-up from `RouteTable` and the `Contracts` folder. For every route with a `Contract` it loads
the `ServiceContract` and checks that each listed operation (other than `Reject`) exists in the WSDL with the route's
`Style`. Any problem → throws with a list, and the gateway does not start.

| Member | Role |
|---|---|
| `Check(service, request)` | `null` when the request matches (or the route has no contract), else the reason. Called by `SenderEndpoint` for `Bridge` operations |
| `For(service)`, `Count` | Lookups; `StartupChecks` logs routes without a contract |

#### `ServiceContract`, `ContractOperation`, `ContractPart`
A WSDL 1.1 reduced to what a request check needs. `Load(folder, name)` reads `service.wsdl` and every `*.xsd`
beside it with `SafeXml` settings (DTDs off, nothing external resolved: the WCF `schemaLocation` URLs are satisfied by
the local files) and compiles one `XmlSchemaSet`.

| Check (`Check(request)`) | Document/literal (WCF, ASMX) | RPC/encoded (SOAP Toolkit) |
|---|---|---|
| SOAP version | Must have a binding in the WSDL (`basicHttpBinding` = SOAP 1.1 only; ASMX = 1.1 and 1.2) | Same |
| Operation | Must be in the WSDL | Same |
| Body element | Name **and** namespace = the input part's element, e.g. `{http://tempuri.org/}SendToFMS` | Namespace = the `soap:body` namespace, e.g. `http://tempuri.org/message/` |
| Content | Validated against the XSD (e.g. one optional `sXML` string; nothing else) | Children are exactly the parts in `parameterOrder` (`XMLMsg`), unqualified, simple values of the part's type |

The business XML inside `sXML` / `XMLMsg` is `xs:string` in every WSDL, so its content is checked by the route's
`AllowedTypes`, not here. Validation runs under a per-contract lock (`XmlSchemaSet` is not documented as thread-safe).

### 4.7 `Egress/`

#### `ArrivalChecks` (`Egress/ArrivalChecks.cs`)
The checks every message that arrived over the light passes before it is used, whatever its kind (step 10a moved them
out of `InboxWorker.Validate`): used by `InboxWorker` (Requests) and `AnswerReader` (Receipts, Replies and Heartbeats). Singleton,
registered by `ReceiverRegistration`. `CheckAsync(header, row, ct)` (async since step 17; was `Check`): the row columns (filled in by the QR receiver, incl.
`Kind`, `CorrelationId`, `SequenceRunId`, `ContentFingerprint`, `ExpiresUtc`, `Priority`) equal the envelope header; the header's
`CatalogFingerprint` equals this side's (missing or different → "The route catalogue differs from the sender's …");
direction = this side's inbound; payload format `RawSoap` or `HttpGet`; not older than `ReplayWindowDays`; not more than
`MaxClockSkewMinutes` in the future. Then, **on the row's first check only** (`Verified` still false; step 17, D84),
`InboxRepository.FindSequenceConflictAsync`: the row's (direction, `SequenceRunId`, `Sequence`) already held by
**another** message that arrived earlier → "already used … (the sender's qrbridge.db restored from an old backup, or a copy)"; its
number at or below the run's `SequenceWatermark.ContiguousTo` with no other row holding it → "An old message shown
again … (archived)", whatever its date. First check only, because a row re-posted after a "surely not sent" failure,
or requeued by an operator, may itself have moved the watermark. When everything passes it calls
`InboxRepository.MarkVerifiedAsync` (`InboxWorker` no longer does). A failure throws `BridgeRejectException`: the row is
Rejected. (Not used: "lower than the newest Done = old" — answers jump the queue since step 14 and re-airs since
step 11 make lower numbers arriving later normal.)

#### `FarSideMonitor` and `FarSideStatus` (`Egress/FarSideMonitor.cs`)
Is the far side still there? (V6 finding G-16, decisions D80–D83, step 17.) Singleton, registered by
`WorkerRegistration`; used by `MaintenanceWorker` and `HealthController`.

| Member | Role |
|---|---|
| `SendHeartbeatIfIdleAsync(nowUtc, ct)` | When `Gateway:HeartbeatMinutes` > 0 and this side has queued nothing (any kind; `OutboxRepository.FindLastQueuedUtcAsync`) for that long, counted from start-up at the latest, and no earlier Heartbeat is still waiting to be aired (`OutboxRepository.AnyHeartbeatWaitingAsync`: otherwise they would pile up while the light is down and, going first, hold back real messages when it returns): queues a `Heartbeat` message through `OutboxWriter` (service `QrBridge`, operation `Heartbeat`, empty body; `OutboxWriter` gives it priority `Answer` and a sequence number). Returns whether it did |
| `GetAsync(nowUtc, ct)` | `FarSideStatus(LastHeardUtc, LastReceiptUtc, Silent, SilentAfterMinutes)` from `InboxRepository.FindLastArrivalsAsync`: the last acceptable arrival of anything from the far side (Inbox light `Received`, this side's receive direction; Heartbeats included) and the last Receipt; `Silent` = nothing heard for longer than `Gateway:FarSideSilentMinutes`, counted from start-up until something is heard |

The Heartbeat takes a sequence number, so a lost **last** message becomes a gap on the far side once the Heartbeat after
it arrives. It is owed no Receipt, never re-aired and not counted as unconfirmed. Proven only with two in-memory gateways
and a fake light.

#### `SoapForwarderHttpClient`, `DeliveryResult` (same file), `DeliveryVerdict` (`Configurations/Enums/Enums.cs`)
Replays a stored request to the real service on this side.

| Member | Role |
|---|---|
| `ResolveTarget(message)` | `Targets[service].Url`, else `DefaultBaseUrl` + the original path (made relative so it can't replace the host), else null |
| `ClientNameFor(service)` | Step 15 (D75): the named HTTP client for that service — the target's `UseDefaultCredentials` when set and different from the global one (`receiver-default-credentials` or `receiver-anonymous`), else `receiver` |
| `ForwardAsync(message, url, timeout, resultKind, ct)` | POSTs the body with the original Content-Type and SOAPAction; an `HttpGet` message (step 12) is sent as a GET with no body, SOAPAction or Content-Type, and classified the same way (2xx Done, 4xx Refused, 500/502/503/504 Unknown, connect failures → a query's fast failure, `NotDelivered`); per-call timeout; reads at most `MaxResponseBytes` |
| `Classify(status, reply, kind)` | Public and static so tests can call it directly |
| `ReadServiceReply(body)` (private) | Reads the real service's reply: fault + reason, or the result text (first element inside the response wrapper, e.g. `SendToFMSResult`); null when it is not a SOAP envelope |
| `RewriteAddressingTo(body, target)` (private) | WS-Addressing `To` rewrite, below |

`Classify` / `ForwardAsync` decision table (decision D9: re-post only when the call surely did not arrive):

| Real service answer | Verdict | Inbox `ServiceStatus` |
|---|---|---|
| SOAP fault (any HTTP status) | `Permanent` | `Refused` |
| HTTP 202 | `Delivered` | `Done` |
| 2xx, `FmsResponse`, `RETURN_CODE` 0 | `Delivered` | `Done` |
| 2xx, `FmsResponse`/`ReturnCode`, non-zero code | `Refused` | `Refused` (reason kept in `DownstreamResult`) |
| 2xx, `ResultKind.None` | `Delivered` | `Done` |
| 2xx, `FmsResponse`/`ReturnCode`, but the result can't be read | `Unknown` | `Unknown` — it may have been processed: not Done, not retried |
| Nothing sent: DNS (`HttpRequestError.NameResolutionError`), refused/unreachable (`ConnectionError`), connect timeout (`OperationCanceledException` wrapping `TimeoutException`, before the per-call deadline), TLS (`SecureConnectionError`); HTTP 408, 429 | `Transient` | `Retrying` + backoff, `NotDelivered` after `MaxAttempts` (D25); a round-trip query: `NotDelivered` at once (step 10b) |
| May have arrived: timeout after sending, reset or answer ended early (any other `HttpRequestError`, an `IOException` while reading), HTTP 500/502/503/504, any other 5xx, 1xx or odd status (D40) | `Unknown` | `Unknown` — never retried |
| Other 4xx (400, 401, 403, 404, 405, 415…), 3xx (redirects are off), 501, 505 | `Permanent` | `Refused` |

`DeliveryResult` = `Verdict` + one-line `Summary` (the probable reason in plain words, for logs and `ServiceComment`,
never the payload) + `DownstreamResult` (what the service said, for operators) + `HttpStatus` (the real service's
HTTP code, stored as `ServiceHttpStatus`; null when there was no HTTP answer).

#### WS-Addressing `To` rewrite (private `RewriteAddressingTo`)
WCF services using WS-Addressing check that `wsa:To` names them; the caller addressed the load balancer. If the body
contains a WS-Addressing `To` header, it is set to the real target URL. A quick byte search for `"addressing"` means
almost every FMS request is returned **byte-identical**. Turned off by `Receiver:RewriteAddressingTo = false`.

#### `AnswerWriter` (`Egress/AnswerWriter.cs`)
The Receiver part's answers over the opposite lane (V6 fix step 9b, decisions D43–D46). Singleton, registered by
`ReceiverRegistration`. Both kinds of answer go into **this side's Outbox** through `OutboxWriter` and cross back like
any other message; nothing posts them to a service.

| Member | Called by | Does |
|---|---|---|
| `FinishAsync(row, request, outcome, httpStatus, comment, downstreamResult, contentType, answer)` | `InboxWorker` | Ends a Request: **first** writes its Reply (`Kind = Reply`, `CorrelationId` = the Request's `MessageId`, same service/operation/label/path, `Outcome`, `ServiceHttpStatus`, `ServiceComment`; body = the real answer byte for byte, header Content-Type = the answer's), **then** marks the Inbox row with the same outcome (`MarkDoneAsync`, `MarkRefusedAsync`, `MarkUnknownAsync`, `MarkExpiredAsync`, `MarkNotDeliveredAsync` or `MarkRejectedAsync`). Used for every final outcome, Rejected included (`request` is null when the bytes could not be opened). An answer over `GatewayDatabase:MaxPayloadBytes` is left out and the comment says "too large to carry back"; a Content-Type over 4,096 characters is dropped; the comment is made one line (control characters → spaces) and cut to 1,024 characters. If the Reply cannot be written, the error is logged and the row is still marked |
| `RecoverStuckAsync(lockTimeout)` | `MaintenanceWorker` | Rows still `Delivering` after `lockTimeout` (`InboxRepository.FindStuckAsync`): if a Reply was already written **for this attempt** (`OutboxRepository.FindLastReplyToAsync`, adopted only when created after the row's current claim `LockedUtc`, D64: a Reply from before an operator's requeue belongs to an earlier attempt, and the new POST may have reached the service), the row takes its outcome, status and comment ("Settled after a restart from the Reply already sent: …"); otherwise `FinishAsync(… Unknown …)` — an Unknown Reply, then the row Unknown. Never posted again (D46, D9). Returns how many |
| `SendDueReceiptsAsync` | `ReceiptWorker` | Up to 100 messages owed a Receipt (`InboxRepository.FindDueReceiptsAsync`, oldest first): writes each Receipt (`Kind = Receipt`, `CorrelationId` = the arrived message, empty path, Content-Type and body), **then** `ClearReceiptDueAsync`. A crash in between only sends one Receipt twice, which is harmless. Returns how many |

An operator requeue later ends the row again and so sends a second Reply; the sending side replaces its stored answer
with it unless that one is `Answered`, and only when it is newer (`OutboxRepository.MarkAnsweredAsync`, column
`ReplyCreatedUtc`, D59, tracker step 10b). `ReuseDoneAsync` (layer 3b, D58): a request whose same content was already
`Done` here is not posted; it ends `Done` with that earlier request's last Reply (answer and HTTP code) reused.

### 4.8 `Egress/Workers/`

All three are `BackgroundService`s that run inside the IIS app pool (in-process hosting). Each catches and logs its own
errors and keeps going. (The fourth hosted service, `AnswerReader`, is in `Ingress/`: [§4.3](#43-ingress).)

#### `InboxWorker`
The receiver loops: one per priority class (`DeliveryClasses` = High, Normal, Low; step 14, D73), so a slow or stuck
feed never holds back a permit. See [§3.2](#32-receiver--the-same-message-on-the-other-side) for the steps.

| Member | Role |
|---|---|
| `ExecuteAsync` | Starts one loop per class and waits for all three. Each loop: heartbeat every 30 s → claim its class (`ClaimNextAsync(priority)`) → process, or wait on the Inbox doorbell (it wakes one loop) / poll interval. Pauses 5 s after an unexpected error. There is no setting for the number of loops |
| `ProcessAsync(row)` | Deserialize, validate (`ArrivalChecks` marks the row verified), plan, check expiry, layer 3b same-content check (step 10b), forward, then end it through `AnswerWriter.FinishAsync` (Reply first, then the row) — or `MarkRetryingAsync` when nothing was sent and tries are left (never for a round-trip query: `NotDelivered` at once, step 10b). Out of tries (`Attempts ≥ MaxAttempts`) the worker itself ends it `NotDelivered` ("Not delivered after N tries; it surely never reached the service… Last: …", D25) |
| `Validate(header, row)` | `ArrivalChecks.CheckAsync` ([§4.7](#47-egress)), then the header's `Kind` must be `Request` (a Receipt, Reply or Heartbeat is read by `AnswerReader`, never posted) |
| `Plan(message)` | A listed service must have its `SenderSide` on the **other** side and the operation must be `Bridge` or `RoundTrip` (step 10a); an unlisted one needs `AcceptUnlisted`. Gets `ResultKind` from the reply profile, the URL from `SoapForwarderHttpClient`, whether it is a query (`RoundTrip` + `OnHoldTimeout: Unavailable`) and whether the route recognises retries |
| `Backoff(attempts)` | `BackoffBaseSeconds × 2^(attempts−1)`, capped at `BackoffMaxMinutes` |

On shutdown **before** the POST it calls `InboxRepository.ReleaseAsync`, which puts the row back without counting
the attempt. On shutdown **during** the POST it ends the row `Unknown` with an Unknown Reply (D41): the request may
already be at the service.

Two exceptions from `Exceptions/`; `InboxWorker` catches them (`AnswerReader` catches `BridgeRejectException` too):

| Exception | Thrown by | Leads to |
|---|---|---|
| `BridgeRejectException` | `ArrivalChecks.CheckAsync`, `InboxWorker.Validate` / `Plan`, `AnswerReader` | In `InboxWorker`: a `Rejected` Reply, then Inbox `LightStatus` → `Rejected` (reason in `LightComment`), never retried. In `AnswerReader`: the Receipt, Reply or Heartbeat row `Rejected` |
| `PermanentFailureException` | `InboxWorker.Plan` (no receiver target) | A `NotDelivered` Reply, then Inbox `ServiceStatus` → `NotDelivered` (decision D25): never reached the service; an operator may resend it |

#### `ReceiptWorker`
Sends the Receipts this side owes (decision D44), independent of deliveries: a slow POST must not hold back the
Receipts that stop the other side re-airing. Every `InboxPollSeconds` (at least 1 s) it calls
`AnswerWriter.SendDueReceiptsAsync` until a pass finds none (100 per pass). It writes no heartbeat.

#### `MaintenanceWorker`
Housekeeping every `MaintenanceIntervalSeconds` (minimum 10 s):

- `AnswerWriter.RecoverStuckAsync` — `Delivering` rows older than `LockTimeoutMinutes` (crash or recycle during the
  POST) are settled from the Reply already written for their current attempt (D64), or become `Unknown` with an Unknown Reply: the request
  may have reached the service (decisions D9, D46), so they are never posted again on their own.
- `SequenceGapMonitor.CheckAsync` — looks for messages that never arrived and moves the sequence watermarks up (below).
- `OutboxRepository.ReairUnconfirmedAsync(ReceiptTimeoutSeconds, MaxAirAttempts)` (step 11, D65–D67) — Outbox rows
  (not Receipts or Heartbeats) still `Aired` with no Receipt after `Gateway:ReceiptTimeoutSeconds` (120) go back to `Pending`, so
  the QR sender airs them again; after `Gateway:MaxAirAttempts` (3) airs, or once past their `ExpiresUtc`, they become
  light `Failed`. One `Light: …` warning per changed row (kind, `MessageId`, service.operation, reason; never the
  payload). The check runs once a minute, so the real wait is 120–180 s. Re-airing is safe: the far Inbox skips a
  `MessageId` it already has and owes a new Receipt (D44). A caller's retry of a light-`Failed` message still gets
  the hold-timeout answer at once (D55, D68).
- Warnings, prefixed by group: `Light: …` for Outbox `Failed`, Inbox `Rejected` and an unconfirmed Outbox message
  older than 30 minutes (Receipt and Heartbeat rows not counted; a new gap is logged by `SequenceGapMonitor` itself),
  and `Light: nothing heard from the far side since … — is the light or the far gateway down?` while
  `FarSideMonitor.GetAsync` says silent (step 17, D83); `Service: …` for Inbox `Unknown`, `Refused` and `NotDelivered`.
- `FarSideMonitor.SendHeartbeatIfIdleAsync` — a Heartbeat **message** to the far side when this side has queued
  nothing for `Gateway:HeartbeatMinutes` (step 17, D80, D81).
- Component heartbeats (`HeartbeatRepository`) for `MaintenanceWorker` (with the light and service counts and `missing=`) and `GatewayApi`.

Outbox rows stuck in `Sending` are **not** touched here: the QR sender owns them. **Nothing is deleted** (decision D28,
24 Nov): `InboxRepository.PurgeAsync`, `OutboxRepository.PurgeReceivedAsync` and `Gateway:RetentionDays` are gone.
Operators archive rows manually and never delete rows younger than `Gateway:ReplayWindowDays`; they never archive
`SequenceWatermark` or `AcknowledgedGap` (both tiny; without the watermark an archived message shown again is no
longer recognised by its number).

#### `SequenceGapMonitor` (`Egress/SequenceGapMonitor.cs`)
Finds messages that never arrived over the light (V6 finding G-02, decision D29). Singleton.

| Member | Role |
|---|---|
| `CheckAsync` | Calls `InboxRepository.AdvanceSequenceWatermarksAsync` (step 17, D84: moves each run's watermark up, never down), then `InboxRepository.FindSequenceGapsAsync(ReceiveDirection, now − GapGraceMinutes)`; logs one warning per **new** gap ("Light: N message(s) from–to of sender run … never arrived … Acknowledge once handled.", numbers and ids only); keeps the result |
| `Current`, `CheckedUtc` | The last result and when it ran; `/health` reads them, so the gap query never runs per probe |

A gap stays until the missing number arrives, the sender's counter starts a new run, or an operator acknowledges it
(`InboxRepository.AcknowledgeGapAsync`). The sending side re-airs a message with no Receipt (`MaintenanceWorker` →
`OutboxRepository.ReairUnconfirmedAsync`, step 11); on real hardware that starts once the QR apps carry messages.

---

## 5. QrBridge.Shared, class by class

### 5.1 `Configurations/`: settings, enums, helpers

#### `GatewayDatabaseOptions` — `Configurations/Options/GatewayDatabaseOptions.cs`
The `GatewayDatabase` section (the QR apps' `QRDatabase`): the database shared with the QR apps on the same machine (they **must** match). A former `Bridge` section stops the start.
`Side`, `DataFolder` (local disk only), `MaxPayloadBytes`; computed `SendDirection`, `ReceiveDirection`,
`DatabasePath` (`DataFolder\qrbridge.db`; the name is the constant `DatabaseFileName`).

#### Enums (`Configurations/Enums/Enums.cs`)

| Enum | Values | Notes |
|---|---|---|
| `BridgeSide` | `Corp`, `Dmz` | Which network this install is in |
| `Direction` | `CorpToDmz` (= Inbound), `DmzToCorp` (= Outbound) | Stored in the header and rows |
| `PayloadFormat` | `RawSoap`, `HttpGet` (= 2, step 12) | A format marker the worker checks before decoding. `HttpGet`: a plain GET Request with an empty body, empty Content-Type and no SOAPAction; Receipts and Replies are never `HttpGet`. The database CHECK constraint gained `HttpGet`: delete dev databases |
| `Compression` | `None`, `Brotli` | The gateway uses `Brotli` |
| `OutboxLightStatus` | `Pending`, `Sending`, `Aired`, `Received`, `Failed` | See [§9](#9-status-of-each-row-the-two-state-machines) |
| `OutboxServiceStatus` | `Waiting`, `Answered`, `Unknown`, `Refused`, `Expired`, `NotAvailable`, `NotDelivered`, `Rejected` | Requests start `Waiting`; `AnswerReader` sets the far side's outcome from its Reply (step 10a; `NotDelivered` and `Rejected` new, D51). `NotAvailable` is still in the enum but nothing sets it |
| `MessageKind` | `Request`, `Receipt`, `Reply`, `Heartbeat` (= 4, step 17, D80) | In the header and both tables; only Requests are posted to a service. A Heartbeat is the empty "this side is alive" message an idle gateway sends (`FarSideMonitor`); it gets no Receipt and is never re-aired |
| `MessagePriority` | `Answer` (0), `High` (1), `Normal` (2), `Low` (3) | Header version 6 and the `Priority` column of both tables (step 14, D73). Receipts, Replies and Heartbeats are `Answer`; a Request is never `Answer`. Stored as its number, the one enum not stored by name, so the claims can order by it |
| `ServiceOutcome` | `Done`, `Refused`, `Unknown`, `Expired`, `NotDelivered`, `Rejected` | Header version 5: what a Reply says happened to the Request on the far side (D43) |
| `InboxLightStatus` | `Received`, `Rejected` | See [§9](#9-status-of-each-row-the-two-state-machines) |
| `InboxServiceStatus` | `Pending`, `Delivering`, `Done`, `Retrying`, `Unknown`, `Refused`, `Expired`, `NotDelivered` | See [§9](#9-status-of-each-row-the-two-state-machines) |

`BridgeSideExtensions`: `SendDirection()`, `ReceiveDirection()`, `Other()` — e.g. `Corp.SendDirection()` = `CorpToDmz`.

### 5.2 `Data/Providers/`, `Data/Contexts/`, `Data/Initializers/`, `Data/Conventions/`, `Data/Sqlite/`, `Data/SqlServer/` — database set-up

| Class | File | Role |
|---|---|---|
| `DataServiceCollectionExtensions` | `Initializers/DataServiceCollectionExtensions.cs` | `AddBridgeData()` registers the configured engine (`IBridgeDatabase.Create`, `GatewayDatabase:Provider`), `IDbContextFactory<BridgeDbContext>` (`BridgeDbContextFactory`) and the three repositories as singletons **by their interfaces**. An overload takes fixed `GatewayDatabaseOptions` (tests, tools) |
| `DatabaseInitializer` | `Initializers/DatabaseInitializer.cs` | At start-up: `IBridgeDatabase.InitializeAsync` of the configured engine |
| `IBridgeDatabase` | `Providers/IBridgeDatabase.cs` | The engine seam (decision 55): `CreateContext`, `CreateReadOnlyContext` (the UI's), `InitializeAsync`, `Description` (for logs); `Create(options)` picks the engine |
| `SqliteBridgeDatabase` | `Sqlite/Providers/SqliteBridgeDatabase.cs` | Default. Connection string (pooling, 30 s busy timeout) + `SqlitePragmaInterceptor`; the read-only connection (`Mode=ReadOnly`); at start-up: **refuse to start** while a former `send.db` or `received.db` is in the data folder (`FormerDatabaseProblem`: they may hold accepted, undelivered messages); create the folder; `SchemaAdoption`, then migrations (else `EnsureCreated`); set `journal_mode=WAL`; retry up to 5 times (both apps may start at once) |
| `SqlServerBridgeDatabase` | `SqlServer/Providers/SqlServerBridgeDatabase.cs` | `GatewayDatabase:ConnectionString` (also the UI's, queries not tracked); at start-up the SQL Server migrations (EF creates the database when the login may); warns about a password in the connection string |
| `SchemaAdoption` | `Sqlite/Initializers/SchemaAdoption.cs` | SQLite only: adopts a `qrbridge.db` made before migrations, rows kept; refuses one that matches no migration |
| `SqlitePragmaInterceptor` | `Sqlite/Initializers/SqlitePragmaInterceptor.cs` | On every SQLite connection open: `busy_timeout=5000`, `synchronous=FULL` |
| `BridgeDbContext` | `Contexts/BridgeDbContext.cs` | Abstract. `Outbox`, `SequenceCounters` (gateway writes, QR sender airs), `Inbox` (QR receiver writes, gateway reads), `Heartbeats`, `AcknowledgedGaps`, `SequenceWatermarks` (step 17). One context for the whole database (since 25 Nov 2026; before, `SendDbContext` and `ReceivedDbContext`). Declares the two engine questions: `BeginWriteTransactionAsync` (the one write lock) and `IsDuplicateKey` |
| `SqliteBridgeDbContext`, `SqlServerBridgeDbContext` | `Sqlite/Contexts/…`, `SqlServer/Contexts/…` | One per engine, each with its own migrations: BEGIN IMMEDIATE / exclusive `sp_getapplock` `QrBridge.Write`; SQLite error 19 / SQL Server 2627, 2601 |
| `SqliteDesignTimeFactory`, `SqlServerDesignTimeFactory` | `Sqlite/Contexts/…`, `SqlServer/Contexts/…` | Only for `dotnet ef migrations … --context …` (no connection needed to add one) |
| `BridgeDbContextFactory` | `Contexts/BridgeDbContextFactory.cs` | `IDbContextFactory<BridgeDbContext>` → the engine's read-write contexts |
| `BridgeConventions` | `Conventions/BridgeConventions.cs` | For every entity, on every engine: enums as names (the `Priority` columns are set to numbers in `OutboxMessageConfiguration` / `InboxMessageConfiguration`), Guids as lower-case text, DateTimes as UTC |
| `GuidStringConverter`, `UtcDateTimeConverter` | `Conventions/GuidStringConverter.cs`, `Conventions/UtcDateTimeConverter.cs` | The value converters behind those conventions |

### 5.3 `Data/Entities/` — table rows (one file per entity, named after the class)

| Entity | Table · database | Key columns |
|---|---|---|
| `OutboxMessage` | `Outbox` · qrbridge.db | `MessageId` (primary key), `ServiceName`, `Operation`, `BusinessType`, `Sequence`, `SequenceRunId`, `PayloadSize`, `MessageBytes` (the serialized message, immutable), `MessageHash`, `LightStatus`, `LightUpdatedUtc`, `ServiceStatus`, `Attempts`, `LockedUtc`, `NextAttemptUtc`, the reply columns `ReplyContentType`, `ReplyBody` (the real service's answer from the far side's Reply, ≤ `GatewayDatabase:MaxPayloadBytes`), `ReplyCreatedUtc` (the stored Reply's `CreatedUtc`, far side's clock, D59), plus the shared `Kind`, `CorrelationId`, `ContentFingerprint`, `ExpiresUtc`, `Priority` (copies of the header fields), `LightComment`, `ServiceHttpStatus`, `ServiceComment`, `ServiceUpdatedUtc`. Indexes also on `(ContentFingerprint, CreatedUtc)` and `CorrelationId` (round trip) |
| `SequenceCounter` | `SequenceCounter` · qrbridge.db | One row per `Direction`, `LastValue`, `RunId` (decision D27: null until the first number is handed out, then set once; a new or deleted qrbridge.db starts a new run, a restored backup keeps its run). Seeded with 0 |
| `InboxMessage` | `Inbox` · qrbridge.db | Same identity and shared columns as `OutboxMessage` (from the base class `BaseMessage`), its own `LightStatus` and `ServiceStatus`, plus `Verified`, `ReceivedUtc`, `DownstreamResult` (what the real service said) and `ReceiptDueUtc` (a Receipt is owed since then, D44: set on arrival and again when the same `MessageId` arrives a second time; cleared once the Receipt is queued; never set for a Receipt or a Heartbeat). `Verified` is set by `ArrivalChecks` when every check passed (step 17). Its `MessageBytes` is emptied when the row ends `Done` (D77, step 15); `MessageHash` stays |
| `Heartbeat` | `Heartbeat` · qrbridge.db | `Component` (key), `LastSeenUtc`, `Info`. Component liveness on this machine — not the `Heartbeat` message kind |
| `AcknowledgedGap` | `AcknowledgedGap` · qrbridge.db | Audit of missing numbers an operator accepted as lost (decision D30): `Direction`, `SequenceRunId`, `FromSequence`, `ToSequence`, `AcknowledgedUtc`, `AcknowledgedBy` (≤ 256), `Reason` (≤ 2,000). Never archive it |
| `SequenceWatermark` | `SequenceWatermark` · qrbridge.db | Step 17, decision D84: `Direction`, `SequenceRunId` (together the key), `ContiguousTo`, `UpdatedUtc`. Every number 1–`ContiguousTo` of that run arrived and was checked (`Verified` or `Rejected`) or was acknowledged as a gap; moved up by `InboxRepository.AdvanceSequenceWatermarksAsync`, never down. A message numbered at or below it that no row holds is an old message shown again. Tiny: **never archive it** |

### 5.4 `Data/Configurations/` — table shape

| Class | File | Adds |
|---|---|---|
| `OutboxMessageConfiguration` | `OutboxMessageConfiguration.cs` | Table `Outbox`; CHECK constraints generated from the enums (`CK_Outbox_LightStatus`, `CK_Outbox_ServiceStatus`, `CK_Outbox_Kind`), `CK_Outbox_Priority` (0–3) and `CK_Outbox_ServiceHttpStatus` (null or 100–599); primary key `MessageId`; lengths; indexes `IX_Outbox_LightStatus (LightStatus, Priority, Sequence)`, unique `IX_Outbox_Sequence (Direction, Sequence)`, `IX_Outbox_Created`, `IX_Outbox_ContentFingerprint (ContentFingerprint, CreatedUtc)`, `IX_Outbox_CorrelationId` |
| `SequenceCounterConfiguration` | `SequenceCounterConfiguration.cs` | Key = `Direction`; seeds both rows |
| `InboxMessageConfiguration` | `InboxMessageConfiguration.cs` | Table `Inbox`; CHECKs (`CK_Inbox_LightStatus`, `CK_Inbox_ServiceStatus`, `CK_Inbox_Kind`, `CK_Inbox_Priority`, `CK_Inbox_ServiceHttpStatus`); primary key `MessageId` (duplicates refused); indexes `IX_Inbox_Status (LightStatus, ServiceStatus, Kind, Priority, CreatedUtc)`, `IX_Inbox_Sequence (Direction, SequenceRunId, Sequence)` (the gap check, per run), `IX_Inbox_ReceiptDue (ReceiptDueUtc)` filtered on `ReceiptDueUtc IS NOT NULL` (Receipts owed), `IX_Inbox_ContentFingerprint (ContentFingerprint, ReceivedUtc)` filtered on `ContentFingerprint IS NOT NULL` (layer 3b, step 10b), `IX_Inbox_Arrived (Direction, LightStatus, ReceivedUtc)` ("far side last heard", step 17) |
| `HeartbeatConfiguration` | `HeartbeatConfiguration.cs` | Key = `Component` |
| `AcknowledgedGapConfiguration` | `AcknowledgedGapConfiguration.cs` | Key = `(Direction, SequenceRunId, FromSequence)`; CHECKs `CK_AcknowledgedGap_Direction` and `CK_AcknowledgedGap_Range` (`FromSequence ≥ 1 AND ToSequence ≥ FromSequence`) |
| `SequenceWatermarkConfiguration` | `SequenceWatermarkConfiguration.cs` | Table `SequenceWatermark` (step 17); key = `(Direction, SequenceRunId)`; CHECKs `CK_SequenceWatermark_Direction` and `CK_SequenceWatermark_ContiguousTo` (`ContiguousTo ≥ 0`) |
| `CheckConstraints` | `CheckConstraints.cs` | `SqlIn` turns enum names into CHECK constraint SQL; `PriorityRange` limits a `Priority` column to 0–3; `HttpStatusRange` limits `ServiceHttpStatus` |

### 5.5 `Data/Repositories/` — queue operations

Every store method opens its **own short-lived** `DbContext`. Claims are atomic: read the next id, then
`UPDATE … WHERE MessageId = @id AND LightStatus = 'Pending'` (Outbox) or `… AND LightStatus = 'Received' AND
ServiceStatus IN ('Pending', 'Retrying')` (Inbox); only the caller that changed one row wins.

#### `OutboxRepository` (+ `OutboxCounts`)

These methods move the **light** group, except `MarkAnsweredAsync`, which records the far side's Reply in the
**service** group (called by `AnswerReader` since step 10a).

| Method | Called by | Does |
|---|---|---|
| `GetCountsAsync` | `/health`, `MaintenanceWorker` | `OutboxCounts`: `Light` (every `OutboxLightStatus` → count), `Service` (every `OutboxServiceStatus` → count), `OldestUndeliveredUtc` (oldest `Pending`/`Sending`/`Aired`; an aired Receipt or Heartbeat row is done and not counted) |
| `ClaimNextAsync` | QR sender *(planned)* | `Pending` → `Sending`: Receipts, Replies and Heartbeats (`Answer`) first, then `High`, `Normal`, `Low`, lowest `Sequence` within a class (step 14, D73) |
| `MarkAiredAsync(messageIds)` | QR sender *(planned)* | `Sending` → `Aired` (only rows still `Sending`, so it never undoes a Receipt). Integration-Plan §2.2 adds the bundle and session ids |
| `MarkReceivedAsync` | `AnswerReader` (Receipt, step 10a) | → `Received` when the far side's Receipt arrives |
| `MarkAnsweredAsync` | Reply handling (`AnswerReader`, tracker steps 10a, 10b) | `ServiceStatus` `Waiting` → the Reply's outcome, with `ServiceHttpStatus`, `ServiceComment`, `ReplyContentType`, `ReplyBody`, `ReplyCreatedUtc`; also light `Received` (a Reply implies a Receipt). A later Reply (operator requeue on the far side) replaces an answer that is not `Answered`, only when it is newer (D59); otherwise returns false. Requests only; body ≤ `GatewayDatabase:MaxPayloadBytes` |
| `ReleaseAsync` | QR sender *(planned)* | `Sending` → `Pending` with a delay, or `Failed` after max attempts; reason in `LightComment` |
| `ResetSendingAsync` | QR sender start-up *(planned)* | All `Sending` → `Pending` |
| `RequeueFailedAsync` | Operator action *(no UI yet)* | `Failed` → `Pending` |
| `ReairUnconfirmedAsync(receiptTimeout, maxAirAttempts)` | `MaintenanceWorker` (step 11) | Rows light `Aired`, `Kind` not `Receipt` or `Heartbeat`, aired (`LightUpdatedUtc`) at least `receiptTimeout` ago: past `ExpiresUtc` → `Failed` at once (D67); `Attempts` (one per QR sender claim) below `maxAirAttempts` → `Pending`, `NextAttemptUtc` cleared (D65); otherwise → `Failed` (D66). Reason in `LightComment`. Each change is one conditional UPDATE (only if still `Aired` and not re-aired since), so a Receipt arriving at the same moment wins. Returns the rows changed |
| `FindAsync` | Tests, tools | One row by `MessageId` |
| `FindLastReplyToAsync(requestId)` | `AnswerWriter.RecoverStuckAsync`, `AnswerWriter.ReuseDoneAsync` | The latest Reply this side wrote for that Request (after an operator requeue, the newest outcome), or null. Recovery adopts it only when it was written after the row's current claim (D46, D64); layer 3b reuses its answer (step 10b). (`FindReplyToAsync`, the first Reply, was removed in step 10c: after a requeue it could settle a row from the previous attempt's outcome) |
| `FindLastQueuedUtcAsync` | `FarSideMonitor.SendHeartbeatIfIdleAsync` (step 17) | When this side last queued anything to send (any kind), or null: the idle time before a Heartbeat (D81) |
| `AnyHeartbeatWaitingAsync` | `FarSideMonitor.SendHeartbeatIfIdleAsync` (step 17) | Whether a Heartbeat is still waiting to be aired (light `Pending` or `Sending`); if so, no new one is queued |
| `FindStateAsync(messageId)` | `SenderEndpoint.HoldAsync`, `AnswerReader` | → `MessageState` (kind, service, operation, both statuses, HTTP status and the stored answer; not the message bytes), or null. Read by a held caller every 2 s (step 10a) |

New rows are **not** written here — only `OutboxWriter` inserts (callers' Requests, this side's Receipts and
Replies from `AnswerWriter`, and Heartbeats from `FarSideMonitor`; `LightStatus` `Pending`, `ServiceStatus` `Waiting`,
the header's `Kind`, `CorrelationId`, `SequenceRunId`, `ContentFingerprint`, `ExpiresUtc` copied into their columns), because the
sequence and the insert must share one transaction. Nothing calls `MarkAiredAsync` yet.

#### `InboxRepository` (+ `InboxCounts`)

| Method | Called by | Does |
|---|---|---|
| `AddMessageAsync` | QR receiver *(planned)* | Inserts a complete envelope (`LightStatus` `Received`, `ServiceStatus` `Pending`, `Kind`/`CorrelationId`/`SequenceRunId`/`ContentFingerprint`/`ExpiresUtc` copied from the header, `ReceiptDueUtc` = now except for a Receipt or a Heartbeat); idempotent on `MessageId` (returns false for a duplicate). A duplicate (other than a Receipt or a Heartbeat) is owed a Receipt again: its `ReceiptDueUtc` is set to now (D44: it was re-aired because the first Receipt was lost) |
| `FindDueReceiptsAsync(max)` | `AnswerWriter.SendDueReceiptsAsync` | Rows with `ReceiptDueUtc` set, oldest first → `DueReceipt(MessageId, ServiceName, Operation, BusinessType, DueUtc)` |
| `ClearReceiptDueAsync(due)` | `AnswerWriter.SendDueReceiptsAsync` | Clears `ReceiptDueUtc` only if it is not later than the `DueUtc` that was read, so a copy that arrived meanwhile stays owed its own Receipt |
| `ClaimNextAsync(priority)` | `InboxWorker` (one loop per class) | `Received` **Requests** of that class only: `Pending` or due `Retrying` → `Delivering`, `Attempts + 1`. Order: the sender's counter runs in the order they started (their first message's `CreatedUtc`), then `Sequence`, so a new run never jumps ahead of older messages. Not claimed while an earlier Request of the same service and class is `Retrying` (strict order, D74). Receipts, Replies and Heartbeats are never claimed for posting |
| `FindArrivedAnswersAsync(max)` | `AnswerReader` | Receipts, Replies and Heartbeats still `Pending` (not used yet), lowest `Sequence` first; one reader, so no claim (step 10a) |
| `FindSameContentAsync(id, fingerprint, since)` | `InboxWorker` (layer 3b) | Other Requests with the same `ContentFingerprint` since `since` that may have reached the service (`Done`, `Unknown`, `Delivering`), oldest first → `SameContent(MessageId, ServiceStatus, DownstreamResult)` (step 10b, D58) |
| `MarkVerifiedAsync` | `ArrivalChecks` (since step 17; was `InboxWorker`) | `Verified = true` once every arrival check passed; a row checked again later skips the sequence-number rule (D84) |
| `MarkDoneAsync` | `AnswerWriter` (after the Reply); `AnswerReader` (a Receipt, Reply or Heartbeat used) | → `Done` + `ServiceHttpStatus`, `ServiceComment`, `DownstreamResult`; empties `MessageBytes` (D3, D77, step 15: plaintext at rest), `MessageHash` stays |
| `MarkRejectedAsync` | `AnswerWriter` (after the Reply); `AnswerReader` (a Receipt, Reply or Heartbeat that failed a check) | `LightStatus` → `Rejected` + reason in `LightComment` |
| `MarkRefusedAsync` | `AnswerWriter` (after the Reply) | → `Refused` + HTTP code, comment, `DownstreamResult` |
| `MarkUnknownAsync` | `AnswerWriter` (after the Reply) | → `Unknown` + HTTP code, comment, `DownstreamResult` |
| `MarkNotDeliveredAsync(id, httpStatus, comment)` | `AnswerWriter` (after the Reply) | → `NotDelivered` + HTTP code (the last try's, when out of tries) + comment: no Receiver target, or out of tries where nothing was sent (D25) |
| `MarkExpiredAsync` | `AnswerWriter` (after the Reply) | → `Expired` + comment: past its `ExpiresUtc`, not posted |
| `MarkRetryingAsync` | `InboxWorker` | Only for "nothing sent" failures with tries left (D9): → `Retrying` with `NextAttemptUtc`. It no longer decides "out of tries": the worker ends that row `NotDelivered` with a Reply |
| `ReleaseAsync` | `InboxWorker` (shutdown **before** the POST) | `Delivering` → `Pending`, attempt not counted. A shutdown **during** the POST → `Unknown` with a Reply (D41) |
| `FindStuckAsync(lockTimeout)` | `AnswerWriter.RecoverStuckAsync` | Rows still `Delivering` with `LockedUtc` older than the timeout. Changes nothing: `AnswerWriter` settles each one (replaces `ResetStuckAsync`, D46) |
| `FindSequenceGapsAsync` | `SequenceGapMonitor` | Per run of the sender's counter, every number below the highest received that never arrived — first numbers of a run too (a run whose first row is 5 → gap 1–4). One SQL `LAG` window query. A gap counts only once the message after it arrived before the cut-off (`GapGraceMinutes`); every row counts as arrived, `Rejected` rows too; acknowledged numbers are subtracted. Returns `SequenceGap(Direction, SequenceRunId, FromSequence, ToSequence, MissingSinceUtc)` with `Count` |
| `AcknowledgeGapAsync` | Operator action *(no UI yet)* | Stores an `AcknowledgedGap` (who and why required, else `ArgumentException`; so is a bad range); returns false if a range starting at the same number exists. Those numbers are no longer reported |
| `FindSequenceConflictAsync(row)` | `ArrivalChecks` (first check only, step 17, D84) | A reason when the row's number (direction, run, sequence) is already held by **another** message that arrived earlier ("already used … the sender's qrbridge.db restored from an old backup, or a copy"), or is at or below the run's watermark with no other row holding it ("An old message shown again … archived"); else null |
| `AdvanceSequenceWatermarksAsync(direction)` | `SequenceGapMonitor.CheckAsync` (each maintenance run) | Moves each run's `SequenceWatermark.ContiguousTo` up to the highest number up to which every number arrived and was checked (`Verified` or `Rejected`) or was acknowledged as a gap. Never down. Returns how many runs moved |
| `FindLastArrivalsAsync(direction)` | `FarSideMonitor.GetAsync` | (last acceptable arrival of anything from the far side — light `Received`, Heartbeats included —, last Receipt), each null when never (index `IX_Inbox_Arrived`) |
| `RequeueAsync` | Operator action *(no UI yet)* | `Refused` / `Unknown` / `NotDelivered` → `Pending`, attempts reset. Never `Rejected` rows |
| `GetCountsAsync`, `FindAsync` | `/health`, `MaintenanceWorker`, tests | Read-only. `InboxCounts`: `Light` map, `Service` map counted only over `LightStatus` `Received` rows, and `OldestUndeliveredUtc` (oldest Request still `Pending`/`Delivering`/`Retrying`) |

#### `HeartbeatRepository` and `Components`
`BeatAsync(component, info)` upserts a row (update, else insert, tolerating a race). `GetAllAsync` feeds `/health`,
which flags any component silent for more than 2 minutes. `Components` lists the names: `GatewayApi`,
`InboxWorker`, `MaintenanceWorker`, and `SenderLoop`/`ReceiverLoop` for the QR apps.

### 5.6 `Serialization/` — what crosses the gap

#### `MessageHeader` (record) — `MessageHeader.cs`
Everything about a message except its SOAP body: `Version`, `MessageId`, `Direction`, `ServiceName`, `Operation`,
`BusinessType`, the replay details **`Path`, `SoapActionHeader`, `ContentType`** (exactly as the caller sent them),
`PayloadFormat`, `Compression`, `Sequence`, `CreatedUtc`. `SenderEndpoint` fills the service, operation, replay details
and label; `OutboxWriter` adds the id, direction, sequence and time. Version 4 (24 Nov 2026) adds `Kind`
(`MessageKind`: Request / Receipt / Reply), `CorrelationId`, `ContentFingerprint`, `ExpiresUtc`, `SequenceRunId`
(called `SequenceEpoch` until 24 Nov; same bytes), `CatalogFingerprint`, `CallerHost`. Version 5 (24 Nov 2026,
V6 fix step 9b, decision D43) adds what a Reply says the far side did: `Outcome` (`ServiceOutcome`: Done,
Refused, Unknown, Expired, NotDelivered, Rejected), `ServiceHttpStatus` (100–599, null when there was no HTTP answer)
and `ServiceComment` (≤ 1,024 characters, no control characters, plain words, never the payload). Version 6
(25 Nov 2026, step 14, D73) adds `Priority` (`MessagePriority`, one byte; default `Normal`). Version 7
(`CurrentVersion = 7`, 25 Nov 2026, step 17, D80) adds no field: `Kind` may now be `Heartbeat` (constants
`HeartbeatServiceName = "QrBridge"`, `HeartbeatOperation = "Heartbeat"`).

Who sets what today: `OutboxWriter` sets `SequenceRunId`, `CatalogFingerprint` and `Priority` `Answer` for Receipts,
Replies and Heartbeats; `FarSideMonitor` sets `Kind` `Heartbeat` and its service and operation; `SenderEndpoint` sets `ContentFingerprint`, the Request's `Priority` (`RouteTable.SettingsOf`), `CallerHost`
(`CallerHostOf`, step 15, D76) and, for RoundTrip, `ExpiresUtc` (a query, `OnHoldTimeout: Unavailable`: now + hold, D54, step
10a; a state-changing call, `Pending`: now + `Gateway:Expiry`, D62, step 10c); `AnswerWriter` sets `Kind`, `CorrelationId` and, for a Reply, the three version-5 fields.
For a Reply, `ContentType` is the real answer's (empty without an
answer); for a Receipt or a Heartbeat, `Path` and `ContentType` are empty. It is
**not encrypted** (QrDiode encrypts the QR link); the checksum covers it. Never put sensitive data in it.

#### `MessageSerializer` — `MessageSerializer.cs`
Turns header + SOAP body into one byte array and back: body → Brotli → bytes with a SHA-256 checksum. No encryption.

Byte format:

| Field | Size |
|---|---|
| magic `"BRG7"` (`"BRG3"` … `"BRG6"`, before header version 7, are refused with a clear message: "previous format … Delete old dev databases") | 4 bytes |
| header length + header (version 7 adds nothing; version-6 `Priority` after the version-5 fields, which follow the version-4 ones, which follow the version-3 ones: earlier offsets never move) | 4 bytes + up to 64 KB |
| checksum (SHA-256 of header + body) | 32 bytes |
| body length + body (compressed: the caller's SOAP body for a Request, the real answer for a Reply, empty for a Receipt or a Heartbeat) | 4 bytes + data |

| Method | Role |
|---|---|
| `Serialize(header, body)` | Checks the header (id, direction and kind set; names ≤ 256 characters; path, SOAPAction, Content-Type ≤ 4,096; fingerprints lower-case hex SHA-256; `CallerHost` ≤ 256 without control characters; `ServiceComment` ≤ 1,024 (`MaxServiceCommentLength`) without control characters; the rules between fields below), size check, compress, add the checksum → bytes |
| `PeekHeader(bytes)` (static) | Reads only the header — for the QR receiver to fill Inbox columns, and for `AnswerWriter` to read a Reply it already wrote. Field rules are checked, the checksum only on `Deserialize` |
| `Deserialize(bytes)` | Strict parsing (lengths, enums, string limits, timestamps, presence flags, no trailing bytes), the same rules, checksum, decompress with a size cap (stops "zip bombs"). Returns header + body. Throws `InvalidDataException` |

Rules between fields (`CheckConsistency`, on writing **and** reading):

| Kind | Must carry | Must not carry |
|---|---|---|
| Request | a non-empty `Path` and `ContentType` (to replay it); an `HttpGet` Request instead an empty body, empty `ContentType` and no SOAPAction (step 12); `Priority` `High`, `Normal` or `Low` | `CorrelationId`, `Outcome`, `ServiceHttpStatus`, `ServiceComment`; `Priority` `Answer` |
| Receipt | `CorrelationId` = the arrived message's id | `Outcome`, `ServiceHttpStatus`, `ServiceComment` (Path and Content-Type may be empty) |
| Reply | `CorrelationId` = the Request's id, `Outcome` | — (Path and Content-Type may be empty) |
| Heartbeat (step 17) | an empty body, `Priority` `Answer`, `RawSoap` (service / operation `QrBridge` / `Heartbeat` are set by `FarSideMonitor`, not checked here) | `CorrelationId`, `ContentFingerprint`, `ExpiresUtc`, `Outcome`, `ServiceHttpStatus`, `ServiceComment` (Path and Content-Type empty) |

For every kind: `ServiceHttpStatus`, when present, is 100–599 (written as an int16); `ExpiresUtc` is after `CreatedUtc`.
Header version 6 changed the bytes and both schemas (the `Priority` columns); version 7 changes the magic and the
schema again (CHECK on `Kind`, table `SequenceWatermark`, index `IX_Inbox_Arrived`): delete dev databases.

The body of a Request is **never re-serialised**: legacy typos such as `<SOURCE_APPLICAION>`, Verizon envelopes, RPC/encoded
bodies and WS-Addressing headers reach the real service byte for byte; a Reply carries the real answer byte for byte too. The checksum catches corruption, not
deliberate tampering — that protection comes from QrDiode on the QR link.

#### `Hashing` (static, in Shared's `Configurations/Helpers/Utility.cs`)
`Sha256Hex(bytes)` — lower-case hex SHA-256, stored as `MessageHash` on both sides for audit and reconciliation.

### 5.7 `Signals/` — doorbells between processes

| Class | File | Role |
|---|---|---|
| `SignalNames` | `Configurations/Helpers/Utility.cs` | `Global\QrBridge.{Side}.Outbox` and `…Inbox`. `Global\` is needed because IIS (session 0) and the desktop app (session 1+) are in different sessions |
| `BridgeSignal` | `BridgeSignal.cs` | A named auto-reset Windows event with an ACL for Authenticated Users, `IIS_IUSRS`, SYSTEM, Administrators. `Set()` never throws; `WaitAsync(timeout)` returns on signal **or** timeout. If the event can't be created or opened, it falls back to plain waiting |
| `BridgeSignals` | `BridgeSignals.cs` | Singleton holding both: `Outbox` (gateway rings, QR sender waits) and `Inbox` (QR receiver rings, gateway waits) |

Doorbells only make things faster. Every waiter also polls the database, so a missed signal delays a message by at
most one poll interval — it never loses it.

---

## 6. Configuration and content files

| File | Role |
|---|---|
| `QrGateway.slnx` | Solution: Gateway + Shared under `/src/`, Tests under `/tests/` |
| `QrBridge.Gateway.csproj` | Web SDK, `net10.0-windows`, `InProcess` hosting; ships `routes.json` and `Contracts/**/*.wsdl;*.xsd`; `InternalsVisibleTo` the tests |
| `QrBridge.Shared.csproj` | EF Core SQLite, EF Design (design time only), logging and options abstractions |
| `appsettings.json` | Defaults for `Logging` (Event Log: warnings, plus `QrBridge` info), `Bridge`, `Gateway` |
| `appsettings.Corp.json` | `Side=Corp`, `Hold` 270 s, `Expiry` 600 s, Receiver part delivers to the corporate systems (empty until captured) |
| `appsettings.Dmz.json` | `Side=Dmz`, `Hold` 90 s, `Expiry` 600 s, `DefaultBaseUrl=https://dmz-rr-server` (placeholder) |
| `routes.json` | The route catalogue: two reply profiles and the service list. **Same file on both sides** |
| `Contracts/{direction}/{Service}/service.wsdl` (+ `xsd0.xsd`, `xsd1.xsd`) | `{direction}` = `Inbound` (Corp → DMZ) or `Outbound` (DMZ → Corp), from the route's `SenderSide`. The real services' WSDLs, used by `ContractCatalog` to check requests. Never served. `Contracts/README.md` lists the sources |
| `web.config` | Sends **every** path (including `*.svc`, `*.asmx`, `*.wsdl`) to the ASP.NET Core module; in-process; `ASPNETCORE_ENVIRONMENT` picks Corp/Dmz; Application Initialization warms `/health` at boot |
| `Properties/launchSettings.json` | Local runs: Corp on `:5080`, Dmz on `:5090` (Receiver part delivers to `:5099`), data under `C:\QrBridgeDev` |
| `README.md` (gateway project) | Folder-by-folder notes inside the source tree |

Configuration layers (last wins): `appsettings.json` → `appsettings.{Corp|Dmz}.json` → `routes.json` → environment
variables (e.g. `Gateway__Receiver__DefaultBaseUrl`) → command line. Options are read only after the host is built,
so tests and environment variables always override the files.

### 6.1 What `routes.json` holds today

Reply profiles:

| Profile | `ResultKind` | Ok | Busy | Unavailable | Pending | Rejected |
|---|---|---|---|---|---|---|
| `FmsResponse` | `FmsResponse` | `<RESPONSE…><RETURN_CODE>0</RETURN_CODE>…` | `1598` | `1599` | `1596` | `1597` |
| `ReturnCode` | `ReturnCode` | `0` | `1598` | `1599` | `1596` | `1597` |
| `PortalSyncDown` | `None` | — | `1599` + empty `GMT_TIME_STAMP` (same as Unavailable, D53) | `1599` + empty `GMT_TIME_STAMP` | — | — |

Services (all `SenderSide: Corp`):

| Group | Services | `SendTo…` operation and mode | Profile |
|---|---|---|---|
| WCF `.svc` | `FC2FMS`, `FOD2FMS`, `SSO2FMS`, `SSO2TOMS`, `SSO2TLS`, `SSO2DSO`, `FTC2FMS` | `SendToFMS` / `SendToTOMS` / `SendToTLS` / `SendToDSO`: `RoundTrip` (`OnHoldTimeout: Pending`, step 10c, D60), except `FTC2FMS.SendToFMS` (`FAULT_CORRELATION` feed): `Bridge` | `FmsResponse` |
| ASMX | `VZ2TLS` | `SendToTLS` (`createTicketResponse`, `getTicketResponse`): `Bridge` | `ReturnCode` |
| SOAP Toolkit `*.WSDL` (RPC) | `DSS2FMS`, `FC2FMS-Legacy`, `FOD2FMS-Legacy`, `SSO2FMS-Legacy`, `SSO2TOMS-Legacy`, `SSO2TLS-Legacy`, `FTC2FMS-Legacy` | `SendTo…`: `RoundTrip` (`Pending`), except `FTC2FMS-Legacy.SendToFMS`: `Bridge` | `ReturnCode` |
| Live answer needed | `XA2FMS`, `IR2BFC` (`ProcessMessage`) | — (`Unavailable` until open question D23 is answered, D52) | — |
| Plain HTTP GET | `RegisteredTags` (`"HttpGet": true`, `/FMS_ReportService/RegisteredTags.asmx/GetData`) | one operation `"GET"`: `RoundTrip`, `OnHoldTimeout: Unavailable` (step 12, D18) | none: the real answer, or HTTP 504 |

`GetFrom…` operations are `RoundTrip` (held; `OnHoldTimeout: Pending`, queries such as FC2FMS `AUTHORIZE_USERS`
`Unavailable`); `EchoString` is `Echo`. Registered Tags was not listed before step 12 (24 Nov): until then its GET got 405.

DMZ → Corp services (`SenderSide: Dmz`, from workspace-master-v2 `source-code/6-dmz-outbound-interfaces`):

| Group | Services | Profile |
|---|---|---|
| WCF `.svc` (Rapid Restore) | `FMS2FC` (FCR, 15 ops), `FMS2FOD` (8), `FMS2SSO` (4), `TLS2SSO` (6), `TOMS2SSO` (7), `DSO2SSO` (5) | `FmsResponse` (callers read `/RESPONSE/STATUS/RETURN_CODE`). Every operation `RoundTrip` with `OnHoldTimeout: Pending` (permits, orders, cards and their responses, step 10c, D60; `FMS2FC.IssueWorkPermit` too, D61), except `PortalSyncRequest`: `RoundTrip` (`OnHoldTimeout: Unavailable`, profile `PortalSyncDown`) |
| ASMX | `FMS2FSS` (`fms2fss`, `fms2fssHighVoltage`), `FMS2Dashboard`, `FMS2SSLog` | `ReturnCode` (callers accept only `"0"`); `Bridge` (feeds) |
| ASMX, void | `FMS2VR` (`VRRequestAck`, `VRCompletion`) | none: empty `{Op}Response`; `Bridge` |
| Live answer needed | `FMS2FTC` (`GetFaultCorrelation`) | — (`RoundTrip`, `OnHoldTimeout: Unavailable`) |

Every DMZ → Corp operation that carries an FMS message has `AllowedTypes`: the `MESSAGE/@TYPE` values its DMZ caller sends (e.g.
`CreateCard` → `CARD_CREATE`, `TLS2SSO.IssueOrder` → `TLS_ISSUE_ORDER`); the full trace is in `Contracts/README.md`.
Every service has a `Contract` (its folder under `Contracts/`) except `FOD2FMS` and `RegisteredTags` (not SOAP): the WCF WSDL of
`FOD2FMSInterface.svc` is not in the simulator, so its calls are not checked against a WSDL.

---

## 7. QrBridge.Tests, class by class

| Class | File | What it proves |
|---|---|---|
| `MessageSerializerTests` | `MessageSerializerTests.cs` | Serialize/deserialize round trip (header incl. path, SOAPAction, Content-Type; body byte for byte, null SOAPAction stays null); `PeekHeader`; unset id or over-long path refused; corrupted header or body fails the checksum; truncation, oversize and decompression bombs fail; Brotli shrinks SOAP. Version 5: a Reply round-trips every field; a Request without the new fields reads them back as absent; a Receipt and a Reply without an answer need no path or Content-Type; inconsistent v4 and v5 headers refused (e.g. a Reply without `Outcome` or `CorrelationId`, a Request with an outcome or without a path or Content-Type, a Receipt with an HTTP status, a status outside 100–599, a comment too long or with a line break); an unknown kind or bad presence flag refused on peek; a `BRG4` (previous format) message refused with a clear reason. Version 6 (step 14): the priority travels in the header and a Request is never `Answer`; a `BRG5` message is refused. Version 7 (step 17): `A_heartbeat_names_no_message_carries_nothing_and_goes_first`; a `BRG6` message is refused |
| `RepositoryTests` | `RepositoryTests.cs` | Sequence seed; 40 concurrent claimers get each row once; receipt/release; duplicate `MessageId` refused by the primary key; idempotent Inbox insert; Inbox claimed in `Sequence` order; refused + operator requeue; backoff; a row still `Delivering` after the lock timeout is reported by `FindStuckAsync` (and changed by nothing); an arrived message is owed a Receipt again when it arrives twice, a Receipt never is, and a Receipt cleared for an older arrival stays owed for the newer one; `NotDelivered` waits for an operator; a `Rejected` row is never delivered, counted or requeued as service work; an impossible HTTP status is refused by the database; heartbeat upsert; re-air of unconfirmed Outbox rows (step 11); the light airs answers first, then Requests by class; each delivery loop claims only its own class; a new run of the sender's counter never jumps ahead of older messages (step 14); a `Done` row keeps no body but its hash, a row for an operator keeps its body (step 15) |
| `ReplyAndReceiptTests` | `Gateway/ReplyAndReceiptTests.cs` | Step 9b, with a real Corp and DMZ gateway (the test copies bytes between them): a delivered Request is answered with a Reply carrying the real answer byte for byte (Content-Type and HTTP status too); an answer over the size limit is left out and the Reply says so; every final outcome (Done, Refused, Unknown, Expired, NotDelivered, Rejected) gets a Reply; a row found `Delivering` after a crash takes the outcome of its Reply for that attempt, or becomes `Unknown` with an Unknown Reply; a Request still retrying has no Reply yet; every arrived message gets a Receipt and a re-aired copy another; an arriving Reply gets a Receipt, a Receipt never does; Receipts and Replies never count against the backlog and are never refused; a message whose Receipt is lost is aired again and confirmed by the second Receipt (step 11) |
| `RouteTableTests` | `Gateway/RouteTableTests.cs` | Path normalisation; resolve rules; wrong-side refusal; invalid catalogues fail; the shipped `routes.json` is valid, holds permits, orders and cards as `RoundTrip` + `Pending` and keeps the feeds `Bridge` (step 10c); a route can choose its class but never `Answer` (step 14); `MaxRequestBytes` and `MaxBacklog` must be positive (step 16) |
| `SoapParsingTests` | `Gateway/SoapParsingTests.cs` | SOAP 1.1 doc/literal, SOAP 1.2 + WS-Addressing, action from Content-Type, RPC/encoded; `PayloadInspector` shapes |
| `SoapReplyWriterTests` | `Gateway/SoapReplyWriterTests.cs` | Document and RPC results, SOAP 1.2 `RelatesTo`, 1.1 and 1.2 faults, 202 |
| `DeliveryClassificationTests` | `Gateway/DeliveryClassificationTests.cs` | `SoapForwarderHttpClient.Classify` table ([§4.7](#47-egress)) |
| `CorpGatewayFixture`, `SenderTests` | `Gateway/CorpGatewayFixture.cs`, `Gateway/SenderTests.cs` | A real Corp gateway in memory: every simulator template in `Samples/` is accepted (feeds answered `0` at once; permits, orders and cards held and answered `1596` with no far side, step 10c) and stored verbatim; WSDL mismatches (wrong parameter, namespace, extra element, RPC part, SOAP 1.2 to a 1.1 service) refused and not queued; a route whose operations are not in its WSDL stops start-up; allow-list, malformed, legacy RPC, unknown service, not-SOAP/too-large, GETs other than `/health` get 405, full backlog; a call over its route's `MaxRequestBytes` gets 413 first, a route's own `MaxBacklog` refuses only its calls, and the start-up air-time warning (step 16); inconsistent replay or far-side settings stop start-up (incl. `HeartbeatMinutes` < 0 and `FarSideSilentMinutes` not longer than it, step 17); a gateway running as an administrator is warned about but still starts (step 18) |
| `DmzGatewayFixture`, `DmzSenderTests` | `Gateway/DmzGatewayFixture.cs`, `Gateway/DmzSenderTests.cs` | A real DMZ gateway: DMZ → Corp calls get the reply their caller checks (`1596` for held permits, orders and cards with no far side, `"0"`, empty, `1599`); wrong parameter → WSDL fault; a message type of another operation → `1597`; nothing refused is queued |
| `WcfClientTests` | `Gateway/WcfClientTests.cs` | Real WCF clients (BasicHttp, ASMX-style `XmlSerializer` returning `long`, SOAP 1.2 + WS-Addressing to an unlisted service) accept the gateway's replies |
| `EndToEndTests` | `Gateway/EndToEndTests.cs` | Corp gateway → (test copies the envelope, standing in for the QR link) → DMZ gateway → fake real service: byte-for-byte delivery, refusal kept as `Refused`, a throttled (429) call retried until accepted, an unreadable 2xx ends `Unknown`, no receiver target ends `NotDelivered`, wrong side rejected, corrupted envelope rejected; step 17 (D84): a message reusing a number another message already has is rejected and not posted, an old message replayed after its row was archived is rejected although its date is recent, and messages that arrive out of order or are retried are still delivered; step 19: a row whose `Priority` column disagrees with its message is rejected, not posted |
| `HoldTests` | `Gateway/HoldTests.cs` | Steps 10a and 10c, Corp and DMZ gateways with a test "light": a held call gets the real answer byte for byte; no answer → hold-timeout answer (1596, or "not available" and an expiry after the hold for queries); a held permit gets 1596 and expires after `Gateway:Expiry`, not its hold; each Reply outcome gives the agreed answer; a retry waits for the same answer without a second message, but a retry of a message that surely was not done (Expired, NotDelivered, Rejected) is sent as a new message; light `Failed` → hold-timeout answer at once; a caller that hangs up leaves its message queued; queries are never attached; the database is read even when nothing wakes the call; a Reply that fails a check is Rejected; Receipts and Replies update the sending side; a full Outbox gives the portal monitor its "no data" answer |
| `FarSideTests` | `Gateway/FarSideTests.cs` | Steps 10b and 10c: the same content is posted again only if the earlier one surely was not processed; a `Bridge` route posts it twice; an unreachable query ends `NotDelivered` at once; a Reply after an operator requeue replaces an earlier answer that was not `Answered`, only when newer; a requeued request found stuck is `Unknown`, not its previous answer (D64) |
| `RegisteredTagsTests` | `Gateway/RegisteredTagsTests.cs` | Step 12 (8 cases): the report GET crosses and the real answer (e.g. 200 or 404) is replayed byte for byte; no answer in time → 504 and the request expires with its hold; an unreachable report service → 504 at once; a query string, a SOAP POST or another method is refused and nothing is queued; a GET message is replayed only for the GET route, a SOAP message never for it |
| `LightFaultTests` | `Gateway/LightFaultTests.cs` | Step 13 (5), faults on the light through `TwoGatewayBench` and `FakeLight`: happy path; a lost request is re-aired; a lost reply is re-aired by the far side; a lost receipt is re-aired but never posted again; a duplicate session is stored and posted once |
| `CallerFaultTests` | `Gateway/CallerFaultTests.cs` | Step 13 (7), faults at the caller: a retry after 1596 gets the real answer without a second message; a late reply is kept for the next retry; the caller hangs up; a message that expires on the light is not posted and the retry is a new message; `Unknown` is never re-posted and every retry gets 1596; two identical calls at once make one message; the Corp gateway restarts during a hold |
| `HeartbeatTests` | `Gateway/HeartbeatTests.cs` | Step 17 (D80–D83), with `TwoGatewayBench`: `/health` turns unhealthy when nothing was heard from the far side for too long (simulated by moving `ReceivedUtc` back) and healthy again once something arrives; an idle gateway sends a Heartbeat that the far side hears and never confirms (no Receipt owed, never re-aired, not unconfirmed); Heartbeats do not pile up while the light is down (one waits; the next comes only after it was aired); a Heartbeat after a lost last message shows it as missing |
| `PriorityTests` | `Gateway/PriorityTests.cs` | Step 14 (1, D73, D74): a permit is delivered while a slow feed is still being posted (one delivery loop per class) |
| `CallerAndCredentialTests` | `Gateway/CallerAndCredentialTests.cs` | Step 15 (8, D75–D77): `CallerHostOf` takes the first forwarded address labelled with the connection's, IPv6 too, and ignores anything that is not an address; the caller's address travels in the header; the far side's delivered Request and this side's used Reply keep no body, only their hash; `ClientNameFor` picks the client with or without the app pool identity |

Test helpers in `Gateway/Infrastructure/`:

| Class | Role |
|---|---|
| `GatewayHost` | Starts the **real** `Program` with `WebApplicationFactory` and a temp data folder. Two hosts sharing a root = a Corp and a DMZ gateway. Can swap the Receiver part's `HttpClient` handler |
| `FakeSoapService` (+ `CapturedRequest`) | In-memory "real service": records what it receives and replies with a configurable `Responder`; `FmsReply(op, code)` builds an FMS `<RESPONSE>` |
| `FmsEndpoint` (record), `SoapCalls` | The forwarded interfaces as callers see them (path, namespace, action prefix, parameter name, RPC flag) and builders for the exact SOAP 1.1 requests they send |
| `IFC2FMSInterface`, `IVZ2TLSInterface`, `INewService`, `Wcf` | WCF client contracts as the simulator's proxies describe them, and a factory that points WCF at the in-memory gateway |
| `TwoGatewayBench` | Step 13: a Corp and a DMZ gateway, a scripted real service, the `FakeLight` between them, and a restart of the Corp gateway |
| `FakeLight` | Step 13: the QR link in both directions, as the QrDiode apps will run it: claims each Outbox row, marks it Aired, stores it in the other gateway's Inbox. A per-row script says how many copies arrive (0 = a lost session, 1 = arrives, 2 = a duplicate session); each lane can be paused. In memory only: nothing here proves real screens and cameras |

`Samples/` holds the fms-interface-simulator's message templates — the real payload catalogue.

Run all tests from the repository root with `dotnet test All.slnx`, or just these with
`dotnet test sourcecode/gateway/QrGateway.slnx`.

---

## 8. Who uses whom

All services are singletons (registered by the `Initializer/` classes); controllers are created per request. Arrows read "uses".

```
HTTP POST ─► SenderSoapController ─► SenderEndpoint ─┬─► SoapRequest / SafeXml
                                                       ├─► RouteTable ─► RoutingOptions (routes.json)
                                                       ├─► ContractCatalog ─► ServiceContract (Contracts/*.wsdl, *.xsd)
                                                       ├─► PayloadInspector
                                                       ├─► OutboxWriter ─┬─► OutboxRepository ─► BridgeDbContext ─► qrbridge.db (Outbox)
                                                       │                 ├─► MessageSerializer
                                                       │                 └─► BridgeSignals.Outbox  ──► (QR sender, planned)
                                                       ├─► OutboxRepository.FindStateAsync, WaiterRegistry (HoldAsync, RoundTrip)
                                                       └─► SoapReplyWriter

AnswerReader (Receipts, Replies, Heartbeats) ─┬─► InboxRepository.FindArrivedAnswersAsync, MessageSerializer, ArrivalChecks
                                  ├─► OutboxRepository.MarkReceivedAsync / MarkAnsweredAsync
                                  └─► WaiterRegistry.Wake ─► held SenderEndpoint calls

(QR receiver, planned) ─► BridgeSignals.Inbox ─► InboxWorker ─┬─► InboxRepository ─► BridgeDbContext ─► qrbridge.db (Inbox)
                                                              ├─► MessageSerializer (header + body)
                                                              ├─► ArrivalChecks, RouteTable
                                                              ├─► SoapForwarderHttpClient ─► "receiver" / "receiver-default-credentials" / "receiver-anonymous" HttpClient ─► real service
                                                              ├─► AnswerWriter ─┬─► OutboxWriter (Replies, Receipts) ─► qrbridge.db (Outbox)
                                                              │                 ├─► OutboxRepository.FindLastReplyToAsync
                                                              │                 └─► InboxRepository (mark the row, Receipts owed)
                                                              └─► HeartbeatRepository

ReceiptWorker ─► AnswerWriter.SendDueReceiptsAsync
ArrivalChecks ─► RouteTable, InboxRepository (FindSequenceConflictAsync, MarkVerifiedAsync)
MaintenanceWorker ─► AnswerWriter.RecoverStuckAsync, InboxRepository, OutboxRepository, HeartbeatRepository, SequenceGapMonitor ─► InboxRepository
                  └─► FarSideMonitor ─┬─► OutboxWriter (Heartbeat messages), OutboxRepository.FindLastQueuedUtcAsync / AnyHeartbeatWaitingAsync
                                      └─► InboxRepository.FindLastArrivalsAsync
GET /health ─► HealthController ─► OutboxRepository, InboxRepository, HeartbeatRepository, SequenceGapMonitor (cached), FarSideMonitor, RouteTable
HTTP GET (other) ─► SenderSoapController ─► SenderEndpoint.HandleGetAsync ─► RouteTable, OutboxWriter, WaiterRegistry (HttpGet route only; else 405)
```

---

## 9. Status of each row: the two state machines

Each row has **two status groups** (decision D24, built 24 Nov 2026): `LightStatus` says whether the message crossed
the light (screens, cameras, QR apps); `ServiceStatus` says what the real service did. So an operator sees at once
where a problem is. The reasons go in `LightComment` and `ServiceComment`; the real service's HTTP code in
`ServiceHttpStatus`.

### 9.1 Outbox (table in `qrbridge.db`)

`LightStatus`:

| From | To | Who | When |
|---|---|---|---|
| — | `Pending` | `OutboxWriter` | Caller's request accepted, a Receipt / Reply written by `AnswerWriter`, or a Heartbeat from `FarSideMonitor` (`ServiceStatus` `Waiting`) |
| `Pending` | `Sending` | QR sender *(planned)* | Claimed for display |
| `Sending` | `Aired` | QR sender *(planned)* | Shown on screen. The value exists; nothing sets it yet |
| any other | `Received` | `AnswerReader` (step 10a: `MarkReceivedAsync` for a Receipt; `MarkAnsweredAsync` for a Reply, which implies one) | The far side's Receipt or Reply arrived |
| `Sending` | `Pending` | QR sender *(planned)* | Airing failed (`ReleaseAsync`), or sender restarted (`ResetSendingAsync`) |
| `Sending` | `Failed` | QR sender *(planned)* | Out of attempts — operator action |
| `Aired` | `Pending` | `MaintenanceWorker` → `ReairUnconfirmedAsync` (step 11, D65) | No Receipt `Gateway:ReceiptTimeoutSeconds` (120) after it was aired, and tries left: the QR sender airs it again. Not a Receipt or Heartbeat row |
| `Aired` | `Failed` | `MaintenanceWorker` → `ReairUnconfirmedAsync` (step 11, D66, D67) | No Receipt and aired `Gateway:MaxAirAttempts` (3) times, or past its `ExpiresUtc` (never aired again). A Receipt that arrives later still moves it to `Received` |
| `Failed` | `Pending` | Operator (`RequeueFailedAsync`) | After fixing the cause |
| `Received` | — (kept) | — | Rows are never deleted automatically (D28); operators archive them manually |

`ServiceStatus` (`Waiting`, `Answered`, `Unknown`, `Refused`, `Expired`, `NotDelivered`, `Rejected`; `NotAvailable`
exists but is never set): a Request starts `Waiting` and takes the outcome of the far side's Reply when `AnswerReader`
reads it (step 10a; Done → `Answered`). A later Reply after an operator requeue replaces it unless it is `Answered`,
only when newer (D59, step 10b). Receipts, Replies and Heartbeats stay `Waiting`. Since nothing carries messages over the real
light yet, on real hardware every Request stays `Waiting`. A Receipt or a Heartbeat never gets a Receipt, so such a row will never
reach `Received` that way: it stays `Aired` and is done. The re-air rule (step 11) skips Receipt and Heartbeat rows, and they do not
count in `OldestUndeliveredUtc` or the 30-minute warning. Reply rows are re-aired (a Reply gets a Receipt).

### 9.2 Inbox (table in `qrbridge.db`)

`LightStatus`: `Received` when stored; `Rejected` when an arrival check fails (checksum, direction, catalogue,
catalogue fingerprint, payload format, replay window, and since step 17 a sequence number already used by another
message or at or below the run's watermark, D84), reason in `LightComment`. `Rejected` rows are never claimed, requeued or counted in
the service counts (their `ServiceStatus` is set back to `Pending` and ignored).

`ServiceStatus` (only for `LightStatus` `Received` rows):

| From | To | Who | When |
|---|---|---|---|
| — | `Pending` | QR receiver *(planned)* | Complete envelope received (a Receipt is owed: `ReceiptDueUtc`) |
| `Pending` / due `Retrying` | `Delivering` | `InboxWorker` (the loop of the row's class) | Claimed (Requests only; not while an earlier Request of the same service and class is `Retrying`, D74) |
| `Delivering` | `Done` | `InboxWorker` → `AnswerWriter` | Real service accepted; the row's body is emptied (D77) |
| `Delivering` | `Refused` | `InboxWorker` → `AnswerWriter` | SOAP fault, non-zero return code, or an HTTP error not in the retry list (e.g. 404, 401) |
| `Delivering` | `Unknown` | `InboxWorker` → `AnswerWriter` | It may have reached the service: no answer after sending, reset, 5xx, a 2xx whose result can't be read, or a shutdown during the POST |
| `Delivering` | `Unknown` or the outcome of its Reply | `MaintenanceWorker` → `AnswerWriter.RecoverStuckAsync` | Still `Delivering` after `LockTimeoutMinutes` (crash): takes the outcome of a Reply written for its current attempt (after its claim; D64), else `Unknown` with an Unknown Reply (D46) |
| `Delivering` | `NotDelivered` | `InboxWorker` → `AnswerWriter` | No Receiver target configured, or out of tries where nothing was sent (D25), or a round-trip query where nothing was sent (at once, step 10b): surely never reached the service |
| `Delivering` | `Expired` | `InboxWorker` → `AnswerWriter` | Past its `ExpiresUtc`: not posted |
| `Delivering` | `Done` or `Unknown`, not posted | `InboxWorker` → `AnswerWriter` (layer 3b, step 10b) | The same content arrived within the retry window and that one is `Done` (its last Reply's answer is reused: `ReuseDoneAsync`) or `Unknown` / still `Delivering`. Only on routes with `RecogniseRetries` |
| `Delivering` | `Retrying` | `InboxWorker` | Nothing sent and tries left; retried after backoff (no Reply yet) |
| `Delivering` | `Pending` | `InboxWorker` (shutdown before the POST) | Recovery, attempt not counted |
| `Refused` / `Unknown` / `NotDelivered` | `Pending` | Operator (`RequeueAsync`) | After fixing the cause (for `Unknown`: after checking the service did not act on it). Its next final outcome sends a second Reply |
| `Done` | — (kept) | — | Rows are never deleted automatically (D28); operators archive them manually |

Every arrow marked `→ AnswerWriter` writes the Reply into this side's Outbox **first**, then marks the row (D46).
A `Rejected` row also gets a Reply first. `Expired` is set only when a header has an `ExpiresUtc`: a round-trip
query's (now + hold, D54, step 10a) or a state-changing RoundTrip call's (now + `Gateway:Expiry`, D62, step 10c);
`Bridge` calls have none.

Receipts, Replies and Heartbeats are never claimed by `InboxWorker`: `AnswerReader` (steps 10a, 17) ends each one `Done` once used, or
light `Rejected` when it fails a check or answers no message of this side.

---

## 10. Built, used only by tests, and not built

| Item | State |
|---|---|
| Controllers, Sender part, routing, reply building, Outbox writing, envelope, receiver worker, Receipts and Replies (`AnswerWriter`, `ReceiptWorker`, step 9b), the hold and reading Receipts and Replies on the sending side (`SenderEndpoint.HoldAsync`, `WaiterRegistry`, `AnswerReader`, `ArrivalChecks`, step 10a), far-side same-content check and query fast failure (step 10b), permits, orders and cards held with `Gateway:Expiry`, new message for a retry of one surely not done, crash recovery per attempt (step 10c), the Registered Tags GET as a round trip (`SenderEndpoint.HandleGetAsync`, `PayloadFormat.HttpGet`, step 12), priority classes and one delivery loop per class with strict order per service (step 14), per-target credentials, `CallerHost` and Inbox bodies cleared once `Done` (step 15), per-service `MaxRequestBytes` / `MaxBacklog` and the air-time warning (step 16), Heartbeat messages, `FarSideMonitor` and `/health` `farSide`, old messages refused by their sequence number (`SequenceWatermark`, step 17), the administrator start-up warning (step 18), maintenance, `/health` | **Built and covered by tests** (unit, in-memory gateway, real WCF clients, Corp→DMZ end-to-end; light and caller faults with `TwoGatewayBench` and `FakeLight`, step 13 — in memory only, not on real screens and cameras) |
| `OutboxRepository.ClaimNextAsync` / `ReleaseAsync` / `ResetSendingAsync` / `MarkAiredAsync`, `InboxRepository.AddMessageAsync`, `MessageSerializer.PeekHeader` (for the QR apps) | **Built, used only by tests.** The QR sender and receiver do not call them yet — the end-to-end tests copy envelopes directly, Receipts and Replies included. So on real hardware nothing crosses the light: every held call waits the full hold and gets its hold-timeout answer. See [integration-plan.md](../../../../docs/gateway-to-qrdiode/integration-plan.md) §2.2–§2.5 |
| `RequeueFailedAsync`, `RequeueAsync`, `AcknowledgeGapAsync` | Built; no operator UI calls them. Operators use SQL ([technical-guide.md](../../../../docs/gateway-to-qrdiode/technical-guide.md) §8.4) |
| Outbox `LightStatus` `Aired` | **Value exists (24 Nov), nothing sets it yet.** Planned: the QR sender airs rows. Re-air of `Aired` rows with no Receipt is built (`ReairUnconfirmedAsync`, step 11) but proven only with in-memory gateways and a fake light. `Received` and the service outcomes are set by `AnswerReader` (step 10a) |
| Inbox `Expired` | Set by `InboxWorker` when a header has an `ExpiresUtc` in the past; round-trip queries (their hold, D54) and state-changing RoundTrip calls (`Gateway:Expiry`, D62) have one |
| Response messages as a separate `MessageType` | **Removed on purpose** (23 Nov). Answers came back differently: since header version 4/5 (24 Nov) a message's `Kind` (Request / Receipt / Reply; Heartbeat since version 7) and `CorrelationId` say what it is and which message it is about; the body is still raw bytes (`RawSoap`). The only other payload format is `HttpGet` (step 12): a plain GET Request with an empty body |
| DMZ → Corp services (`SenderSide: Dmz`) | **In `routes.json`** (23 Nov), with contracts mostly derived from the DMZ callers' proxies. Paths need confirming on the DMZ load balancer; Corp receiver hosts are not configured yet |
| WSDL / help pages | **Serving removed on purpose** (23 Nov): the simulator's clients never download a WSDL. Any GET except `/health` and the `HttpGet` route gets 405. The WSDLs are back in `Contracts/` (23 Nov), **only** to check requests ([§4.6](#46-ingressvalidation)) |
| Registered Tags GET | **Built 24 Nov (step 12, D18; partly reverses HANDOFF decision 21)**: a round trip; the real answer or HTTP 504. Proven only in memory. Not verified: the real report service's answer (size, content type), whether its host is in the DMZ, that the real caller has no query string, and Rapid Restore's real `WebClient` timeout (its default, 100 s, is shorter than the 270 s Corp hold: a risk) |
| EF migrations | **None yet.** Schema is created with `EnsureCreated`; delete dev databases after changing entities |

---

## 11. Where to look when…

| You want to… | Look at |
|---|---|
| Find where an HTTP request lands | `Controllers/` ([§4.2](#42-controllers)) |
| Add or change a forwarded service or message type | `routes.json` (with its `Contract` folder in `Contracts/`) and a case in `SenderTests.cs`; [technical-guide.md](../../../../docs/gateway-to-qrdiode/technical-guide.md) §13 |
| Change what a caller sees on OK/Busy/Unavailable/Pending/Rejected | Reply profiles in `routes.json` (codes 1596–1599 are visible to callers — agree first) |
| Understand why a call was refused at once | Gateway log (`Refused …`), `RouteTable.Resolve`, `ContractCatalog.Check` ("does not match the service's WSDL"), `SenderEndpoint.DecideAsync` |
| Understand why a delivered message is `Refused` or `Unknown` | `Inbox.ServiceComment`, `Inbox.ServiceHttpStatus` and `Inbox.DownstreamResult`; `SoapForwarderHttpClient.Classify` |
| See what was sent back for a message | This side's Outbox: `Kind = 'Reply'` or `'Receipt'` with `CorrelationId` = the message's id; `AnswerWriter`; Inbox `ReceiptDueUtc` (Receipt still owed) |
| Understand why a message is `Rejected` | `Inbox.LightComment`; `ArrivalChecks.CheckAsync` (incl. "already used" / "an old message shown again", `InboxRepository.FindSequenceConflictAsync`); `InboxWorker.Validate` / `Plan` (Requests) or `AnswerReader` (Receipts, Replies, Heartbeats); `MessageSerializer.Deserialize` |
| Understand what a held RoundTrip caller got | Gateway log (`… answered …`, ids only); the Outbox row's `ServiceStatus`, `ServiceHttpStatus`, `ReplyBody`; `SenderEndpoint.HoldAsync` / `AnswerFrom` |
| Point delivery at another server | `Gateway:Receiver:DefaultBaseUrl` or `Gateway:Receiver:Targets:<Service>:Url` |
| Change retry/backoff/gap grace period, hold or expiry | `Gateway` section ([technical-guide.md](../../../../docs/gateway-to-qrdiode/technical-guide.md) §11) |
| See queue depth, missing messages and component liveness | `GET /health` |
| See whether the far side is alive | `/health` `farSide` (`lastHeardUtc`, `lastReceiptUtc`, `silent`), the `Light: nothing heard from the far side …` warning; `FarSideMonitor` |
| See or acknowledge lost messages | `/health` `gaps`, the `Light: … never arrived` warning; `InboxRepository.AcknowledgeGapAsync` (table `AcknowledgedGap`) |
| Change a table | `Data/Entities/{Entity}.cs` + `Data/Configurations/{Entity}Configuration.cs`; mind the migration note in [integration-plan.md](../../../../docs/gateway-to-qrdiode/integration-plan.md) §2.2 |
