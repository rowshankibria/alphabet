using System.Buffers.Binary;

namespace QrBridge.Shared.Bundles;

/// <summary>One parsed bundle: its id (the same as the Outbox rows' BundleId), its sequence range (for display) and its messages.</summary>
public sealed record Bundle(Guid BundleId, long MinSequence, long MaxSequence, IReadOnlyList<byte[]> Envelopes);

/// <summary>
/// The QR bundle (decision 52): several serialized messages in one QrDiode session, so one trip over the light
/// (at least ~7.5 s) carries up to 50 messages instead of one. QrDiode carries it as an opaque file named
/// <c>bundle-{min}-{max}.qbb</c>; it encrypts and authenticates it, this format only frames the messages.
///
/// Byte format (integers little-endian):
///   magic        4 bytes  "QBB1"
///   version      1 byte   1
///   bundleId    16 bytes  the Outbox rows' BundleId (the Inbox rows get the same)
///   count        uint16   1 .. <see cref="MaxMessagesLimit"/>
///   minSequence  int64    lowest Sequence in the bundle  } for display only: claim order is by priority, so the
///   maxSequence  int64    highest Sequence in the bundle } numbers in between need not all be in this bundle
///   count ×      { length int32 · envelope bytes (MessageSerializer) }
///
/// The parser is bounded and exact: any problem is an <see cref="InvalidDataException"/>, never another exception.
/// </summary>
public static class BundleCodec
{
    /// <summary>Default limits of what one bundle carries (decision 52, Rowshan 27 Nov 2026).</summary>
    public const int DefaultMaxMessages = 50;
    public const int DefaultMaxBytes = 128 * 1024;

    /// <summary>The most messages the format allows, whatever the sender's settings (so a receiver never refuses a sender's choice).</summary>
    public const int MaxMessagesLimit = 1000;

    public const byte Version = 1;
    public const string FileExtension = ".qbb";

    /// <summary>Bytes before the first entry.</summary>
    public const int HeaderSize = 4 + 1 + 16 + 2 + 8 + 8;

    /// <summary>Bytes each message adds besides its envelope (the length prefix).</summary>
    public const int EntryOverhead = 4;

    private static ReadOnlySpan<byte> Magic => "QBB1"u8;

    /// <summary>The largest envelope a message of <paramref name="maxPayloadBytes"/> can serialize to (MessageSerializer framing, header, a little Brotli growth).</summary>
    public static int MaxEnvelopeBytes(int maxPayloadBytes) => maxPayloadBytes + 1024 + 64 * 1024 + 48;

    public static string FileName(long minSequence, long maxSequence) => $"bundle-{minSequence}-{maxSequence}{FileExtension}";

    public static bool IsBundleFileName(string fileName) => fileName.EndsWith(FileExtension, StringComparison.OrdinalIgnoreCase);

    public static byte[] Build(Guid bundleId, IReadOnlyList<(long Sequence, byte[] Envelope)> items)
    {
        if (items.Count is 0 or > MaxMessagesLimit)
            throw new ArgumentException($"A bundle carries 1 to {MaxMessagesLimit} messages, not {items.Count}.", nameof(items));
        if (items.Any(i => i.Envelope.Length == 0))
            throw new ArgumentException("An envelope is empty.", nameof(items));

        long total = HeaderSize + items.Sum(i => (long)EntryOverhead + i.Envelope.Length);
        if (total > int.MaxValue) throw new ArgumentException("The bundle is too large.", nameof(items));

        var bytes = new byte[total];
        var span = bytes.AsSpan();
        Magic.CopyTo(span);
        span[4] = Version;
        bundleId.TryWriteBytes(span.Slice(5, 16));
        BinaryPrimitives.WriteUInt16LittleEndian(span[21..], (ushort)items.Count);
        BinaryPrimitives.WriteInt64LittleEndian(span[23..], items.Min(i => i.Sequence));
        BinaryPrimitives.WriteInt64LittleEndian(span[31..], items.Max(i => i.Sequence));

        int offset = HeaderSize;
        foreach (var (_, envelope) in items)
        {
            BinaryPrimitives.WriteInt32LittleEndian(span[offset..], envelope.Length);
            envelope.CopyTo(span[(offset + EntryOverhead)..]);
            offset += EntryOverhead + envelope.Length;
        }
        return bytes;
    }

    /// <exception cref="InvalidDataException">Not a bundle, an unknown version, a count or length out of range, or the lengths do not add up exactly.</exception>
    public static Bundle Parse(ReadOnlySpan<byte> data, int maxEnvelopeBytes)
    {
        if (data.Length < HeaderSize) throw new InvalidDataException("Too short to be a bundle.");
        if (!data[..4].SequenceEqual(Magic)) throw new InvalidDataException("Not a bundle (wrong magic).");
        if (data[4] != Version) throw new InvalidDataException($"Unsupported bundle version {data[4]}.");

        var bundleId = new Guid(data.Slice(5, 16));
        if (bundleId == Guid.Empty) throw new InvalidDataException("The bundle has no id.");
        int count = BinaryPrimitives.ReadUInt16LittleEndian(data[21..]);
        if (count is 0 or > MaxMessagesLimit) throw new InvalidDataException($"Bundle message count {count} is out of range.");
        long minSequence = BinaryPrimitives.ReadInt64LittleEndian(data[23..]);
        long maxSequence = BinaryPrimitives.ReadInt64LittleEndian(data[31..]);
        if (minSequence > maxSequence) throw new InvalidDataException("Bundle sequence range is reversed.");

        var envelopes = new List<byte[]>(count);
        int offset = HeaderSize;
        for (int i = 0; i < count; i++)
        {
            if (data.Length - offset < EntryOverhead) throw new InvalidDataException("The bundle is truncated.");
            int length = BinaryPrimitives.ReadInt32LittleEndian(data[offset..]);
            offset += EntryOverhead;
            if (length <= 0 || length > maxEnvelopeBytes) throw new InvalidDataException($"Message {i + 1} has an invalid length {length}.");
            if (data.Length - offset < length) throw new InvalidDataException("The bundle is truncated.");
            envelopes.Add(data.Slice(offset, length).ToArray());
            offset += length;
        }
        if (offset != data.Length) throw new InvalidDataException("Unexpected bytes after the last message of the bundle.");
        return new Bundle(bundleId, minSequence, maxSequence, envelopes);
    }
}
