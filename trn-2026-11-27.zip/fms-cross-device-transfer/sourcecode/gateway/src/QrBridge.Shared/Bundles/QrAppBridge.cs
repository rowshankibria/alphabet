using System.Runtime.Versioning;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Signals;

namespace QrBridge.Shared.Bundles;

/// <summary>
/// What a QrDiode app (Sender or Receiver, "QrDiode:Mode" = Gateway) needs of the gateway's database on its machine: one
/// small composition root, so the WPF apps need no generic host. <see cref="OpenAsync"/> creates or upgrades the
/// database exactly as the gateway does (whichever starts first), and opens the doorbells. Both apps and the gateway on
/// one machine must use the same database settings (the gateway's "GatewayDatabase", the QR apps' "QRDatabase").
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class QrAppBridge : IAsyncDisposable
{
    /// <summary>How often each QR app writes its liveness row (Components.SenderLoop / ReceiverLoop), shown on the gateway's /health.</summary>
    public static readonly TimeSpan HeartbeatInterval = TimeSpan.FromSeconds(30);

    private readonly ServiceProvider _services;

    private QrAppBridge(ServiceProvider services, GatewayDatabaseOptions options)
    {
        _services = services;
        Options = options;
    }

    public GatewayDatabaseOptions Options { get; }
    public OutboxBundler Bundler => _services.GetRequiredService<OutboxBundler>();
    public InboxBundleWriter Writer => _services.GetRequiredService<InboxBundleWriter>();
    public IOutboxRepository Outbox => _services.GetRequiredService<IOutboxRepository>();
    public IHeartbeatRepository Heartbeats => _services.GetRequiredService<IHeartbeatRepository>();
    public BridgeSignals Signals => _services.GetRequiredService<BridgeSignals>();

    /// <summary>Where the data is (the qrbridge.db path, or the SQL Server and database), for status lines and the audit log.</summary>
    public string Database => _services.GetRequiredService<IBridgeDatabase>().Description;

    /// <summary>The QR Receiver's journal (accepted sessions, anti-replay watermarks, archive) in this same database.</summary>
    public IReceiveJournalRepository Journal => _services.GetRequiredService<IReceiveJournalRepository>();

    /// <summary>
    /// QR Receiver only: copies its former journal.db at <paramref name="journalPath"/> into this database once and
    /// renames the file (<see cref="LegacyJournalImport"/>). Null when there is no such file; else the sessions copied.
    /// </summary>
    public int? ImportLegacyJournal(string journalPath) =>
        LegacyJournalImport.Import(journalPath, _services.GetRequiredService<IDbContextFactory<BridgeDbContext>>(), DateTimeOffset.UtcNow);

    /// <summary>The same, before (or without) opening: for "cannot open …" messages.</summary>
    public static string Describe(GatewayDatabaseOptions options) => IBridgeDatabase.Create(options).Description;

    /// <exception cref="InvalidOperationException">The database cannot be opened (a former send.db/received.db in the folder, a schema that matches no migration, SQL Server without a connection string…).</exception>
    public static async Task<QrAppBridge> OpenAsync(GatewayDatabaseOptions options, CancellationToken ct, ILoggerFactory? loggerFactory = null)
    {
        var factory = loggerFactory ?? NullLoggerFactory.Instance;
        var services = new ServiceCollection();
        services.AddBridgeData(options);
        services.AddSingleton(factory);
        services.AddSingleton<BridgeSignals>();
        var provider = services.BuildServiceProvider();
        try
        {
            await DatabaseInitializer.InitializeAsync(provider, factory.CreateLogger<QrAppBridge>(), ct);
            _ = provider.GetRequiredService<BridgeSignals>(); // open the doorbells now, not on the first message
            return new QrAppBridge(provider, options);
        }
        catch
        {
            await provider.DisposeAsync();
            throw;
        }
    }

    public ValueTask DisposeAsync() => _services.DisposeAsync();
}
