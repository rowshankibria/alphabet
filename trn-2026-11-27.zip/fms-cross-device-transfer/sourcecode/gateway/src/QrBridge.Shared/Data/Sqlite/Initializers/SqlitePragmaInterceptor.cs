using System.Data.Common;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace QrBridge.Shared.Data;

/// <summary>
/// Runs on every connection open, in both processes:
/// busy_timeout lets a writer wait for the lock instead of failing at once;
/// synchronous=FULL syncs the WAL to disk on every commit, so a message the caller was told "accepted" survives a
/// power cut (NORMAL could lose the last commits). The message rate is low, so the cost does not matter.
/// (journal_mode=WAL is persistent in the file and is set once by <see cref="SqliteBridgeDatabase.InitializeAsync"/>.)
/// </summary>
public sealed class SqlitePragmaInterceptor : DbConnectionInterceptor
{
    private const string Pragmas = "PRAGMA busy_timeout = 5000; PRAGMA synchronous = FULL;";

    public override void ConnectionOpened(DbConnection connection, ConnectionEndEventData eventData)
    {
        using var cmd = connection.CreateCommand();
        cmd.CommandText = Pragmas;
        cmd.ExecuteNonQuery();
    }

    public override async Task ConnectionOpenedAsync(
        DbConnection connection, ConnectionEndEventData eventData, CancellationToken cancellationToken = default)
    {
        await using var cmd = connection.CreateCommand();
        cmd.CommandText = Pragmas;
        await cmd.ExecuteNonQueryAsync(cancellationToken);
    }
}
