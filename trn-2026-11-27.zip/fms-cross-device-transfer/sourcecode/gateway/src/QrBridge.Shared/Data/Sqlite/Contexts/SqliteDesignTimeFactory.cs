using Microsoft.EntityFrameworkCore.Design;

namespace QrBridge.Shared.Data;

/// <summary>Design-time factory: used only by "dotnet ef migrations ... --context SqliteBridgeDbContext".</summary>
public sealed class SqliteDesignTimeFactory : IDesignTimeDbContextFactory<SqliteBridgeDbContext>
{
    public SqliteBridgeDbContext CreateDbContext(string[] args) =>
        SqliteBridgeDatabase.Open(Path.Combine(Path.GetTempPath(), "qrbridge-design.db"));
}