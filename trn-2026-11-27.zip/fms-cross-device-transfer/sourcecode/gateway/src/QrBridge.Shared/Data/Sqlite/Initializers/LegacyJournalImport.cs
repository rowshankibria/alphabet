using System.Globalization;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data;

/// <summary>
/// Until 27 Nov 2026 the QR Receiver kept its journal in its own SQLite file (journal.db in the QrDiode data folder).
/// Its anti-replay watermarks are security state: losing them would let an old QR recording be accepted again. So on its
/// first start with the journal in the bridge database the Receiver copies that file in, once:
/// <list type="bullet">
/// <item>the file must have exactly the tables and columns the old Receiver made (a table it never got is empty);
/// anything else stops the start (<see cref="SchemaMismatchException"/>) and the file is not touched;</item>
/// <item>everything is copied in one write transaction of the bridge database, whichever engine holds it: watermarks
/// (the higher counter wins), sessions not already there, and the archive;</item>
/// <item>only after the commit is the file renamed (with its -wal and -shm files) to
/// <c>journal.db.imported-yyyyMMdd-HHmmss</c>, kept for audit, so the copy is never made twice.</item>
/// </list>
/// </summary>
public static class LegacyJournalImport
{
    /// <summary>The tables of the old journal.db and their columns (a pre-v2 key_watermarks table is ignored).</summary>
    public static readonly IReadOnlyDictionary<string, string[]> Tables = new Dictionary<string, string[]>
    {
        ["transfers"] = ["session_guid", "sender_key_id", "counter", "plaintext_sha256", "filename", "size", "received_utc", "status"],
        ["run_watermarks"] = ["key_id", "run_id", "counter", "first_utc"],
        ["payload_index"] = ["id", "received_utc", "outcome", "session_guid", "sender_key_id", "counter", "type_code", "type_name",
                             "content_kind", "filename", "size", "sha256", "receipt", "stored_path", "reason", "seconds", "snippet"],
    };

    /// <summary>Copies <paramref name="journalPath"/> in and renames it. Null when there is no such file; else how many sessions were copied.</summary>
    /// <exception cref="SchemaMismatchException">The file is not an old Receiver journal; nothing was copied or changed.</exception>
    /// <exception cref="InvalidDataException">A row cannot be read (an id or a time is malformed); nothing was copied or changed.</exception>
    public static int? Import(string journalPath, IDbContextFactory<BridgeDbContext> factory, DateTimeOffset now)
    {
        if (!File.Exists(journalPath)) return null;

        var (transfers, watermarks, archive) = Read(journalPath);

        using (var db = factory.CreateDbContext())
        using (var tx = db.BeginWriteTransaction())
        {
            var marks = db.JournalWatermarks.ToList().ToDictionary(w => (w.SenderKeyId, w.RunId));
            foreach (var w in watermarks)
            {
                if (!marks.TryGetValue((w.SenderKeyId, w.RunId), out var mark))
                {
                    db.JournalWatermarks.Add(w);
                    marks[(w.SenderKeyId, w.RunId)] = w;
                }
                else if (unchecked((ulong)w.Counter) > unchecked((ulong)mark.Counter))
                    mark.Counter = w.Counter;
            }

            var known = db.JournalTransfers.Select(t => t.SessionId).ToHashSet();
            foreach (var t in transfers.Where(t => known.Add(t.SessionId)))
                db.JournalTransfers.Add(t);
            db.JournalArchive.AddRange(archive);

            db.SaveChanges();
            tx.Commit();
        }

        string suffix = ".imported-" + now.UtcDateTime.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture);
        foreach (string extra in new[] { "", "-wal", "-shm" })
            if (File.Exists(journalPath + extra)) File.Move(journalPath + extra, journalPath + suffix + extra);
        return transfers.Count;
    }

    private static (List<JournalTransfer>, List<JournalWatermark>, List<JournalArchiveEntry>) Read(string path)
    {
        var transfers = new List<JournalTransfer>();
        var watermarks = new List<JournalWatermark>();
        var archive = new List<JournalArchiveEntry>();
        var connection = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = path, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
        try
        {
            connection.Open();
            var present = CheckTables(connection, path);
            try
            {
                if (present.Contains("transfers"))
                    foreach (var r in Rows(connection, "SELECT session_guid, sender_key_id, counter, plaintext_sha256, filename, size, received_utc, status FROM transfers"))
                        transfers.Add(new JournalTransfer
                        {
                            SessionId = Guid.ParseExact(r.GetString(0), "N"), SenderKeyId = r.GetString(1), Counter = r.GetInt64(2),
                            PlaintextSha256 = r.GetString(3), Filename = r.GetString(4), Size = r.GetInt64(5),
                            ReceivedUtc = Utc(r.GetString(6)), Status = r.GetString(7),
                        });
                if (present.Contains("run_watermarks"))
                    foreach (var r in Rows(connection, "SELECT key_id, run_id, counter, first_utc FROM run_watermarks"))
                        watermarks.Add(new JournalWatermark
                        {
                            SenderKeyId = r.GetString(0), RunId = Guid.ParseExact(r.GetString(1), "N"), Counter = r.GetInt64(2), FirstUtc = Utc(r.GetString(3)),
                        });
                if (present.Contains("payload_index"))
                    foreach (var r in Rows(connection, "SELECT received_utc, outcome, session_guid, sender_key_id, counter, type_code, type_name, content_kind, " +
                                                       "filename, size, sha256, receipt, stored_path, reason, seconds, snippet FROM payload_index ORDER BY id"))
                        archive.Add(new JournalArchiveEntry
                        {
                            ReceivedUtc = Utc(r.GetString(0)), Outcome = r.GetString(1), SessionId = r.GetString(2), SenderKeyId = r.GetString(3),
                            Counter = r.GetInt64(4), TypeCode = r.GetString(5), TypeName = r.GetString(6), ContentKind = r.GetInt32(7),
                            Filename = r.GetString(8), Size = r.GetInt64(9), Sha256 = r.GetString(10), Receipt = r.GetString(11),
                            StoredPath = r.IsDBNull(12) ? null : r.GetString(12), Reason = r.IsDBNull(13) ? null : r.GetString(13),
                            Seconds = r.GetDouble(14), Snippet = r.IsDBNull(15) ? "" : r.GetString(15),
                        });
            }
            catch (Exception ex) when (ex is FormatException or InvalidCastException)
            {
                throw new InvalidDataException($"{path}: a row of the old journal cannot be read ({ex.Message}). Nothing was copied; the file was not changed.", ex);
            }
        }
        finally
        {
            connection.Dispose();
        }
        return (transfers, watermarks, archive);
    }

    /// <summary>The old tables present; throws when one has other columns than the old Receiver made.</summary>
    private static HashSet<string> CheckTables(SqliteConnection connection, string path)
    {
        var present = new HashSet<string>(StringComparer.Ordinal);
        foreach (var (table, expected) in Tables)
        {
            var columns = Rows(connection, $"SELECT name FROM pragma_table_info('{table}')").Select(r => r.GetString(0)).ToList();
            if (columns.Count == 0) continue;
            if (!columns.Order(StringComparer.Ordinal).SequenceEqual(expected.Order(StringComparer.Ordinal)))
                throw new SchemaMismatchException(
                    $"{path} is not a journal the QR Receiver made: table {table} has the columns {string.Join(", ", columns)}. " +
                    "Nothing was copied and the file was not changed. Move it out of the QrDiode data folder (keep it for audit) and start again.");
            present.Add(table);
        }
        return present;
    }

    private static IEnumerable<SqliteDataReader> Rows(SqliteConnection connection, string sql)
    {
        using var cmd = connection.CreateCommand();
        cmd.CommandText = sql;
        using var reader = cmd.ExecuteReader();
        while (reader.Read()) yield return reader;
    }

    /// <summary>The old journal wrote round-trip ("O") text, with "Z" or "+00:00".</summary>
    private static DateTime Utc(string value) => DateTimeOffset.Parse(value, CultureInfo.InvariantCulture).UtcDateTime;
}
