using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace QrBridge.Shared.Data;

/// <summary>The bridge database in a SQLite file (qrbridge.db). Its migrations are in Data/Sqlite/Migrations.</summary>
public sealed class SqliteBridgeDbContext(DbContextOptions<SqliteBridgeDbContext> options) : BridgeDbContext(options)
{
    private const int SqliteConstraint = 19; // SQLITE_CONSTRAINT

    /// <summary>
    /// Microsoft.Data.Sqlite starts every transaction with BEGIN IMMEDIATE: it takes the file's one write lock at once
    /// (waiting busy_timeout for it), so every writer of every process on this machine takes turns.
    /// </summary>
    public override Task<IDbContextTransaction> BeginWriteTransactionAsync(CancellationToken ct) =>
        Database.BeginTransactionAsync(ct);

    public override IDbContextTransaction BeginWriteTransaction() => Database.BeginTransaction();

    public override bool IsDuplicateKey(DbUpdateException ex) =>
        ex.InnerException is SqliteException { SqliteErrorCode: SqliteConstraint };
}
