namespace QrBridge.Shared;

/// <summary>
/// qrbridge.db has bridge tables that match no known migration (a partial, damaged or unknown copy). Start-up stops
/// with this at once — retrying cannot help, and the file is never marked as migrated (<see cref="Data.SchemaAdoption"/>).
/// </summary>
public sealed class SchemaMismatchException(string message) : InvalidOperationException(message);
