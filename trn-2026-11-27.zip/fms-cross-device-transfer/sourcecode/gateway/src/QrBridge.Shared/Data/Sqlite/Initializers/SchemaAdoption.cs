using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.Logging;

namespace QrBridge.Shared.Data;

/// <summary>
/// SQLite only (<see cref="SqliteBridgeDatabase"/>): brings a qrbridge.db made before EF migrations existed (by
/// EnsureCreated, until 27 Nov 2026) under migration history, without touching its rows. Such a file has the tables but
/// no __EFMigrationsHistory, so MigrateAsync would try to create them again and fail.
///
/// The existing schema is compared with the schema each migration produces (built in a scratch database next to the
/// temp folder): tables, columns, CHECK constraints and indexes. When it matches migration N exactly, migrations 1..N
/// are recorded as applied and MigrateAsync then applies the rest. When it matches none — a partial, damaged or
/// unknown schema — nothing is changed and start-up stops with a message: such a file is never marked as migrated.
/// </summary>
public static class SchemaAdoption
{
    private const string HistoryTable = "__EFMigrationsHistory";

    /// <summary>
    /// Adopts <paramref name="db"/>'s database when it has bridge tables but no migration history. Returns the id of the
    /// migration it was matched to, or null when there was nothing to adopt (new, empty or already migrated).
    /// </summary>
    /// <exception cref="SchemaMismatchException">The tables match no known migration; nothing was changed.</exception>
    public static async Task<string?> AdoptIfNeededAsync(BridgeDbContext db, string databasePath, ILogger logger, CancellationToken ct)
    {
        var connection = (SqliteConnection)db.Database.GetDbConnection();
        await db.Database.OpenConnectionAsync(ct);
        try
        {
            var existing = await ReadSignatureAsync(connection, ct);
            if (existing.Count == 0 || await HasHistoryAsync(connection, ct)) return null;

            var migrations = db.Database.GetMigrations().ToList();
            string? matched = null;
            for (int i = migrations.Count - 1; i >= 0 && matched is null; i--)
            {
                if (SameSchema(existing, await SignatureAfterAsync(migrations[i], ct)))
                    matched = migrations[i];
            }

            if (matched is null)
                throw new SchemaMismatchException(
                    $"{databasePath} has bridge tables but no migration history, and they match no known version of the schema " +
                    "(a partial or changed copy?). It was not changed. Check its rows (Outbox not yet Received or still Waiting, " +
                    "Inbox not yet Done), then move it and its -wal and -shm files out of the data folder; the next start " +
                    "creates a new database.");

            var history = db.GetService<IHistoryRepository>();
            string version = ProductInfo.GetVersion();
            var sql = new StringBuilder(history.GetCreateIfNotExistsScript());
            foreach (string id in migrations.TakeWhile(id => id != matched).Append(matched))
                sql.AppendLine().Append(history.GetInsertScript(new HistoryRow(id, version)));

            await using (var tx = await connection.BeginTransactionAsync(ct))
            {
                await using var cmd = connection.CreateCommand();
                cmd.Transaction = (SqliteTransaction)tx;
                cmd.CommandText = sql.ToString();
                await cmd.ExecuteNonQueryAsync(ct);
                await tx.CommitAsync(ct);
            }

            logger.LogInformation("{Path}: existing schema matches migration {Migration}; recorded as applied, rows kept",
                databasePath, matched);
            return matched;
        }
        finally
        {
            await db.Database.CloseConnectionAsync();
        }
    }

    /// <summary>The schema migration <paramref name="target"/> produces, built in a scratch database that is then deleted.</summary>
    private static async Task<SortedSet<string>> SignatureAfterAsync(string target, CancellationToken ct)
    {
        string path = Path.Combine(Path.GetTempPath(), $"qrbridge-schema-{Guid.NewGuid():N}.db");
        try
        {
            await using (var scratch = SqliteBridgeDatabase.Open(path))
            {
                await scratch.GetService<IMigrator>().MigrateAsync(target, ct);
                var connection = (SqliteConnection)scratch.Database.GetDbConnection();
                await scratch.Database.OpenConnectionAsync(ct);
                try { return await ReadSignatureAsync(connection, ct); }
                finally { await scratch.Database.CloseConnectionAsync(); }
            }
        }
        finally
        {
            SqliteConnection.ClearAllPools();
            foreach (string file in new[] { path, path + "-wal", path + "-shm" })
                try { File.Delete(file); } catch (IOException) { /* temp file: best effort */ }
        }
    }

    public static bool SameSchema(SortedSet<string> a, SortedSet<string> b) => a.SetEquals(b);

    private static async Task<bool> HasHistoryAsync(SqliteConnection connection, CancellationToken ct)
    {
        await using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = $name";
        cmd.Parameters.AddWithValue("$name", HistoryTable);
        return await cmd.ExecuteScalarAsync(ct) is not null;
    }

    /// <summary>
    /// The structure of the bridge tables, one line per fact, independent of column order and of how the SQL was
    /// written (EnsureCreated writes a column inside CREATE TABLE, a migration may add it later with ALTER TABLE):
    /// every column (name, type, not-null, default, key position), every CHECK constraint and every index (columns,
    /// unique, filter). EF's own tables (__EFMigrations*) and SQLite's are left out. Empty for a database with no tables.
    /// </summary>
    public static async Task<SortedSet<string>> ReadSignatureAsync(SqliteConnection connection, CancellationToken ct)
    {
        var facts = new SortedSet<string>(StringComparer.Ordinal);
        var tables = new List<(string Name, string Sql)>();
        await using (var cmd = connection.CreateCommand())
        {
            cmd.CommandText = "SELECT name, sql FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '__EFMigrations%'";
            await using var reader = await cmd.ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct))
                tables.Add((reader.GetString(0), reader.IsDBNull(1) ? "" : reader.GetString(1)));
        }

        foreach (var (table, sql) in tables)
        {
            facts.Add($"table {table}");
            await using (var cmd = connection.CreateCommand())
            {
                cmd.CommandText = $"SELECT name, type, \"notnull\", dflt_value, pk FROM pragma_table_info('{table.Replace("'", "''")}')";
                await using var reader = await cmd.ExecuteReaderAsync(ct);
                while (await reader.ReadAsync(ct))
                    facts.Add($"column {table}.{reader.GetString(0)} {reader.GetString(1).ToUpperInvariant()} " +
                              $"notnull={reader.GetInt64(2)} default={(reader.IsDBNull(3) ? "-" : reader.GetString(3))} pk={reader.GetInt64(4)}");
            }
            foreach (string check in CheckConstraints(sql))
                facts.Add($"check {table} {check}");
        }

        await using (var cmd = connection.CreateCommand())
        {
            cmd.CommandText = "SELECT name, tbl_name, sql FROM sqlite_master WHERE type = 'index' AND sql IS NOT NULL AND tbl_name NOT LIKE '__EFMigrations%'";
            await using var reader = await cmd.ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct))
                facts.Add($"index {reader.GetString(1)} {Normalize(reader.GetString(2))}");
        }
        return facts;
    }

    /// <summary>"CONSTRAINT name CHECK (expression)" clauses of a CREATE TABLE, parentheses balanced, quotes respected.</summary>
    private static IEnumerable<string> CheckConstraints(string createTable)
    {
        foreach (Match m in Regex.Matches(createTable, @"CONSTRAINT\s+""(?<name>[^""]+)""\s+CHECK\s*\(", RegexOptions.IgnoreCase))
        {
            int depth = 1, i = m.Index + m.Length;
            bool quoted = false;
            int start = i;
            for (; i < createTable.Length && depth > 0; i++)
            {
                char c = createTable[i];
                if (c == '\'') quoted = !quoted;
                else if (!quoted && c == '(') depth++;
                else if (!quoted && c == ')') depth--;
            }
            yield return $"{m.Groups["name"].Value} {Normalize(createTable[start..(i - 1)])}";
        }
    }

    private static string Normalize(string sql) => Regex.Replace(sql.Trim(), @"\s+", " ");
}
