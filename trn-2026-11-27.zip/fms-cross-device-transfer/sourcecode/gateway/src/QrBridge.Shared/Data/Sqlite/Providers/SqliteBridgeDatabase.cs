using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace QrBridge.Shared.Data;

/// <summary>
/// The bridge tables in one SQLite file per machine, qrbridge.db in GatewayDatabase:DataFolder (the default engine). Local disk
/// only: WAL needs shared memory, so every program that opens the file must run on this machine.
/// </summary>
public sealed class SqliteBridgeDatabase : IBridgeDatabase
{
    /// <summary>The databases of the former layout (until 25 Nov 2026): one for what is sent, one for what arrived.</summary>
    public static readonly IReadOnlyList<string> FormerDatabaseFileNames = ["send.db", "received.db"];

    private readonly GatewayDatabaseOptions _options;
    private readonly Lazy<DbContextOptions<SqliteBridgeDbContext>> _readWrite;
    private readonly Lazy<DbContextOptions<SqliteBridgeDbContext>> _readOnly;

    public SqliteBridgeDatabase(GatewayDatabaseOptions options, IServiceProvider? applicationServices = null)
    {
        _options = options;
        _readWrite = new(() =>
        {
            var builder = new DbContextOptionsBuilder<SqliteBridgeDbContext>();
            if (applicationServices is not null) builder.UseApplicationServiceProvider(applicationServices);
            Configure(builder, options.DatabasePath);
            return builder.Options;
        });
        _readOnly = new(() => new DbContextOptionsBuilder<SqliteBridgeDbContext>()
            .UseSqlite(ConnectionString(options.DatabasePath, readOnly: true))
            .AddInterceptors(new SqlitePragmaInterceptor()) // busy_timeout: wait for a writer instead of failing at once
            .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
            .Options);
    }

    public DatabaseProvider Provider => DatabaseProvider.Sqlite;

    public string Description => _options.DatabasePath;

    public BridgeDbContext CreateContext() => new SqliteBridgeDbContext(_readWrite.Value);

    public BridgeDbContext CreateReadOnlyContext() => new SqliteBridgeDbContext(_readOnly.Value);

    /// <param name="readOnly">Mode=ReadOnly: never creates or changes the file; SQLite refuses every write.</param>
    public static string ConnectionString(string path, bool readOnly = false) => new SqliteConnectionStringBuilder
    {
        DataSource = path,
        Mode = readOnly ? SqliteOpenMode.ReadOnly : SqliteOpenMode.ReadWriteCreate,
        Cache = SqliteCacheMode.Private,
        Pooling = true,
        DefaultTimeout = 30, // seconds; Microsoft.Data.Sqlite also retries SQLITE_BUSY up to this
    }.ToString();

    /// <summary>The read-write settings for the file at <paramref name="path"/>: also used for scratch and design-time databases.</summary>
    public static void Configure(DbContextOptionsBuilder builder, string path) =>
        builder.UseSqlite(ConnectionString(path))
               .AddInterceptors(new SqlitePragmaInterceptor());

    /// <summary>A read-write context on any SQLite file (schema adoption's scratch databases, tests).</summary>
    public static SqliteBridgeDbContext Open(string path)
    {
        var builder = new DbContextOptionsBuilder<SqliteBridgeDbContext>();
        Configure(builder, path);
        return new SqliteBridgeDbContext(builder.Options);
    }

    /// <summary>
    /// Creates or upgrades qrbridge.db. Safe to call from both apps at startup, in any order.
    ///
    /// - Refuses to start while a database of the former two-file layout (send.db, received.db) is in the data folder.
    /// - Creates the data folder if it does not exist.
    /// - Applies the EF migrations (Data/Sqlite/Migrations, since 27 Nov 2026). A database made earlier by EnsureCreated
    ///   is first matched against the migrations and recorded as migrated, rows kept (<see cref="SchemaAdoption"/>); one
    ///   that matches none stops the start, unchanged.
    /// - (Without migrations in this assembly the schema would be created from the model, EnsureCreated.)
    /// - Turns on WAL mode (persistent in the file).
    /// - Retries, because the Gateway and the QR apps may all try to create the file at the same moment.
    /// </summary>
    public async Task InitializeAsync(ILogger logger, CancellationToken ct)
    {
        // A former file may hold messages a caller was told were accepted but that were never carried or delivered.
        // Starting on a new, empty qrbridge.db would drop them without a trace, so an operator must deal with them first.
        if (FormerDatabaseProblem(_options.DataFolder) is { } problem)
            throw new InvalidOperationException(problem);

        Directory.CreateDirectory(_options.DataFolder);

        for (int attempt = 1; ; attempt++)
        {
            try
            {
                await using var db = CreateContext();

                if (db.Database.GetMigrations().Any())
                {
                    await SchemaAdoption.AdoptIfNeededAsync(db, _options.DatabasePath, logger, ct);
                    await db.Database.MigrateAsync(ct);
                }
                else
                {
                    await db.Database.EnsureCreatedAsync(ct);
                }

                await db.Database.ExecuteSqlRawAsync("PRAGMA journal_mode = WAL;", ct);
                logger.LogInformation("Database {Name} ready", GatewayDatabaseOptions.DatabaseFileName);
                return;
            }
            catch (Exception ex) when (attempt < 5 && ex is not SchemaMismatchException &&
                                       ex is SqliteException or InvalidOperationException or DbUpdateException)
            {
                logger.LogWarning(ex, "Initializing {Name} failed (attempt {Attempt}); retrying", GatewayDatabaseOptions.DatabaseFileName, attempt);
                await Task.Delay(TimeSpan.FromSeconds(attempt), ct);
            }
        }
    }

    /// <summary>Why the start must stop because a former database file is in <paramref name="dataFolder"/>; null when none is.</summary>
    public static string? FormerDatabaseProblem(string dataFolder)
    {
        var found = FormerDatabaseFileNames.Where(name => File.Exists(Path.Combine(dataFolder, name))).ToList();
        if (found.Count == 0) return null;
        return $"{string.Join(" and ", found)} found in {dataFolder}. The bridge now keeps everything in one database, " +
               $"{GatewayDatabaseOptions.DatabaseFileName}, and does not read the former files. They may still hold messages that were " +
               "accepted but not yet carried over the light or delivered. Check them (Outbox rows not yet Received or still " +
               "Waiting for a Reply, Inbox rows not yet Done), deal with those messages, then move the former files (with their -wal and -shm files) out of the data " +
               "folder and start again.";
    }
}