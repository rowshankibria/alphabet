using Microsoft.Extensions.Logging;

namespace QrBridge.Shared.Data;

/// <summary>
/// The database engine behind the bridge tables (Provider in "GatewayDatabase" / "QRDatabase"): the one place that knows how to connect,
/// how to open a read-only connection and how to create or upgrade the schema. Everything above it — repositories,
/// OutboxWriter, the UI — uses <see cref="BridgeDbContext"/> and the repository interfaces and does not know the engine.
/// One per process (a singleton); the gateway and both QR apps on a machine must be configured with the same engine
/// and database.
/// </summary>
public interface IBridgeDatabase
{
    DatabaseProvider Provider { get; }

    /// <summary>Where the data is, for logs and status lines: the file path, or the server and database. Never a password.</summary>
    string Description { get; }

    /// <summary>A new read-write context (short-lived: one per repository method).</summary>
    BridgeDbContext CreateContext();

    /// <summary>
    /// A new context for the read-only UI, with queries not tracked (SQLite also opens the file Mode=ReadOnly; SQL Server
    /// uses the same connection as everything else).
    /// </summary>
    BridgeDbContext CreateReadOnlyContext();

    /// <summary>
    /// Creates or upgrades the schema (EF migrations of this engine). Safe to call from every app at start-up, in any
    /// order. Refuses to start when the existing data cannot be used safely; the reason is in the exception.
    /// </summary>
    Task InitializeAsync(ILogger logger, CancellationToken ct);

    /// <summary>The engine <paramref name="options"/> asks for.</summary>
    /// <param name="applicationServices">The app's services, so EF logs through the app's logging (null: no EF logging).</param>
    static IBridgeDatabase Create(GatewayDatabaseOptions options, IServiceProvider? applicationServices = null) => options.Provider switch
    {
        DatabaseProvider.Sqlite => new SqliteBridgeDatabase(options, applicationServices),
        DatabaseProvider.SqlServer => new SqlServerBridgeDatabase(options, applicationServices),
        var other => throw new InvalidOperationException($"GatewayDatabase/QRDatabase:Provider {other} is not supported: use Sqlite or SqlServer."),
    };
}
