namespace QrBridge.Shared.Data.Entities;

/// <summary>
/// One QR session the QR Receiver accepted (table JournalTransfer of the bridge database; until 27 Nov 2026 the
/// <c>transfers</c> table of its own journal.db). Written as 'verified' when its anti-replay state is committed, then
/// completed with the payload's hash, name, size and final status ('stored', 'duplicate', …). Written only by the QR
/// Receiver.
/// </summary>
public class JournalTransfer
{
    public Guid SessionId { get; set; }
    /// <summary>The sender's signing key id, upper-case hex.</summary>
    public string SenderKeyId { get; set; } = "";
    /// <summary>The sender's counter (an unsigned number, stored unchecked).</summary>
    public long Counter { get; set; }
    /// <summary>Upper-case hex; empty until the payload is recorded.</summary>
    public string PlaintextSha256 { get; set; } = "";
    public string Filename { get; set; } = "";
    public long Size { get; set; }
    public DateTime ReceivedUtc { get; set; }
    /// <summary>Free text from the Receiver: 'verified', 'stored', 'duplicate', 'bundle_rejected', 'not_a_bundle'…</summary>
    public string Status { get; set; } = "";
}
