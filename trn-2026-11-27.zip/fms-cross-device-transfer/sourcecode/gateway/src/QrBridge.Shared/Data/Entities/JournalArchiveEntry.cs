namespace QrBridge.Shared.Data.Entities;

/// <summary>
/// One arrival in the QR Receiver's archive (table JournalArchive of the bridge database): stored, duplicate, rejected
/// or failed. The bytes live in the Receiver's payload store or the Inbox; this row is what makes an arrival findable
/// later. Written only by the QR Receiver.
/// </summary>
public class JournalArchiveEntry
{
    public long Id { get; set; }
    public DateTime ReceivedUtc { get; set; }
    /// <summary>One of <see cref="JournalOutcomes"/>.</summary>
    public string Outcome { get; set; } = "";
    /// <summary>The session id as the Receiver showed it; empty when the session was never established.</summary>
    public string SessionId { get; set; } = "";
    public string SenderKeyId { get; set; } = "";
    /// <summary>The sender's counter (an unsigned number, stored unchecked).</summary>
    public long Counter { get; set; }
    public string TypeCode { get; set; } = "";
    public string TypeName { get; set; } = "";
    /// <summary>QrDiode's ContentKind, as its number.</summary>
    public int ContentKind { get; set; }
    public string Filename { get; set; } = "";
    public long Size { get; set; }
    public string Sha256 { get; set; } = "";
    public string Receipt { get; set; } = "";
    public string? StoredPath { get; set; }
    public string? Reason { get; set; }
    public double Seconds { get; set; }
    /// <summary>One flattened line of the payload, for the archive list.</summary>
    public string Snippet { get; set; } = "";
}
