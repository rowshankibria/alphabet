namespace QrBridge.Shared.Data.Entities;

/// <summary>
/// The QR Receiver's anti-replay high-watermark per sender key and counter run (table JournalWatermark of the bridge
/// database; QrDiode protocol v2): a QR session whose counter is at or below it is refused. Only ever moves up. Written
/// only by the QR Receiver. Security state: never archive or edit it.
/// </summary>
public class JournalWatermark
{
    /// <summary>The sender's signing key id, upper-case hex.</summary>
    public string SenderKeyId { get; set; } = "";
    public Guid RunId { get; set; }
    /// <summary>The highest counter committed (an unsigned number, stored unchecked).</summary>
    public long Counter { get; set; }
    /// <summary>When this run was first seen.</summary>
    public DateTime FirstUtc { get; set; }
}
