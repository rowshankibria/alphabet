namespace QrBridge.Shared.Data.Entities;

/// <summary>
/// An operator's record that a range of sequence numbers will never arrive (decision D30), so the gap stops being
/// reported. Kept for audit: who wrote off which messages, when and why. Table AcknowledgedGap of the bridge database.
/// </summary>
public class AcknowledgedGap
{
    /// <summary>The direction the missing messages were travelling (this side's receive direction).</summary>
    public Direction Direction { get; set; }

    /// <summary>The sender's counter run the numbers belong to (see MessageHeader.SequenceRunId).</summary>
    public Guid SequenceRunId { get; set; }

    /// <summary>First missing number written off (inclusive).</summary>
    public long FromSequence { get; set; }

    /// <summary>Last missing number written off (inclusive).</summary>
    public long ToSequence { get; set; }

    public DateTime AcknowledgedUtc { get; set; }

    /// <summary>Who acknowledged it (operator name or account).</summary>
    public string AcknowledgedBy { get; set; } = "";

    /// <summary>Why, e.g. "permit re-issued verbally, ticket 1234". Never a payload.</summary>
    public string Reason { get; set; } = "";
}
