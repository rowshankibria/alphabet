namespace QrBridge.Shared.Data.Entities;

/// <summary>One row per direction; source of per-direction Sequence numbers. Table SequenceCounter of the bridge database.</summary>
public class SequenceCounter
{
    public Direction Direction { get; set; }
    public long LastValue { get; set; }

    /// <summary>
    /// Identifies this run of the counter; copied into every message header as SequenceRunId. Null until the first
    /// number is handed out, then set once (OutboxWriter, in the same UPDATE). A new bridge database therefore starts a new
    /// run, so the receiving gateway does not mistake the restart at 1 for duplicates or a gap. A restored backup keeps
    /// the run it had, and also brings this side's Inbox and SequenceWatermark back to the time of the backup: restore
    /// only a database whose numbers the far side has not already passed (guide §12.4).
    /// </summary>
    public Guid? RunId { get; set; }
}
