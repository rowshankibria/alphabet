namespace QrBridge.Shared.Data.Entities;

/// <summary>
/// How far each run of the other side's sequence counter is complete (decision D84): every number 1–ContiguousTo has
/// arrived and been checked (or was written off as an acknowledged gap). A message numbered at or below it that no other
/// row holds is an old message shown again (its row was archived), whatever its date, and is Rejected. Advanced by the
/// maintenance run; never goes back. Table SequenceWatermark of the bridge database. Tiny: never archive it.
/// </summary>
public class SequenceWatermark
{
    /// <summary>The direction the messages travel (this side's receive direction).</summary>
    public Direction Direction { get; set; }

    /// <summary>The sender's counter run (see MessageHeader.SequenceRunId).</summary>
    public Guid SequenceRunId { get; set; }

    /// <summary>Every number from 1 up to this one has arrived and been checked.</summary>
    public long ContiguousTo { get; set; }

    public DateTime UpdatedUtc { get; set; }
}
