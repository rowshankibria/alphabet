using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace QrBridge.Shared.Data;

/// <summary>
/// Creates or upgrades the bridge database at start-up, whichever engine holds it (<see cref="IBridgeDatabase"/>: SQLite's
/// former-file guard, schema adoption and WAL, or SQL Server's migrations). Safe to call from the gateway and both QR
/// apps, in any order.
/// </summary>
public static class DatabaseInitializer
{
    public static Task InitializeAsync(IServiceProvider services, ILogger logger, CancellationToken ct = default) =>
        services.GetRequiredService<IBridgeDatabase>().InitializeAsync(logger, ct);
}