using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using QrBridge.Shared.Data.Repositories;

namespace QrBridge.Shared.Data;

public static class DataServiceCollectionExtensions
{
    /// <summary>
    /// Registers the configured database engine (<see cref="IBridgeDatabase"/>, GatewayDatabase:Provider), the context
    /// factory and the repositories (by their interfaces). Call from both apps.
    /// The settings are read from <see cref="IOptions{GatewayDatabaseOptions}"/> when the engine is first resolved, so configure
    /// <see cref="GatewayDatabaseOptions"/> (e.g. BindConfiguration("GatewayDatabase")) before resolving.
    /// </summary>
    public static IServiceCollection AddBridgeData(this IServiceCollection services)
    {
        services.AddSingleton(sp => IBridgeDatabase.Create(sp.GetRequiredService<IOptions<GatewayDatabaseOptions>>().Value, sp));
        services.AddSingleton<IDbContextFactory<BridgeDbContext>, BridgeDbContextFactory>();

        services.AddSingleton<IOutboxRepository, OutboxRepository>();
        services.AddSingleton<IInboxRepository, InboxRepository>();
        services.AddSingleton<IHeartbeatRepository, HeartbeatRepository>();
        services.AddSingleton<IReceiveJournalRepository, ReceiveJournalRepository>(); // the QR Receiver's journal
        // The QR apps' two ends of the light (the receiver's also needs BridgeSignals, which each app registers).
        services.AddSingleton<Bundles.OutboxBundler>();
        services.AddSingleton<Bundles.InboxBundleWriter>();
        return services;
    }

    /// <summary>Same as <see cref="AddBridgeData(IServiceCollection)"/> with fixed options (tests, tools).</summary>
    public static IServiceCollection AddBridgeData(this IServiceCollection services, GatewayDatabaseOptions options)
    {
        services.AddSingleton(Options.Create(options));
        return services.AddBridgeData();
    }
}
