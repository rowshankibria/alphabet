using Microsoft.EntityFrameworkCore;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Repositories;

/// <summary>
/// The QR Receiver's journal tables of the bridge database (JournalTransfer, JournalWatermark, JournalArchive). Each
/// method uses its own short-lived DbContext. Until 27 Nov 2026 this was the Receiver's own SQLite file, journal.db
/// (<c>SqliteJournal</c>); the rules are the same, and an old journal.db is copied in once (<see cref="LegacyJournalImport"/>).
/// </summary>
public sealed class ReceiveJournalRepository(IDbContextFactory<BridgeDbContext> factory) : IReceiveJournalRepository
{
    private const string Verified = "verified";
    private const int MaxArchiveRows = 20_000;

    public JournalReplayCheck CheckReplay(string senderKeyId, Guid sessionId, Guid runId, ulong counter, long timestampUnixMs,
                                          TimeSpan window, DateTimeOffset now)
    {
        using var db = factory.CreateDbContext();
        if (db.JournalTransfers.Any(t => t.SessionId == sessionId)) return JournalReplayCheck.KnownSession;

        long? mark = db.JournalWatermarks.Where(w => w.SenderKeyId == senderKeyId && w.RunId == runId)
            .Select(w => (long?)w.Counter).FirstOrDefault();
        if (mark is { } stored && counter <= unchecked((ulong)stored)) return JournalReplayCheck.StaleCounter;

        if (Math.Abs(now.ToUnixTimeMilliseconds() - timestampUnixMs) > window.TotalMilliseconds) return JournalReplayCheck.OutsideWindow;
        return JournalReplayCheck.Fresh;
    }

    /// <summary>
    /// Called by the Receiver (through QrDiode's ReceiveEngine.CommitReplay) only once the payload is stored. The watermark
    /// only moves up; a session already recorded is left as it is. The row is completed by <see cref="RecordTransfer"/>.
    /// </summary>
    public void CommitReplay(string senderKeyId, Guid sessionId, Guid runId, ulong counter, DateTimeOffset now)
    {
        using var db = factory.CreateDbContext();
        using var tx = db.BeginWriteTransaction();
        var mark = db.JournalWatermarks.FirstOrDefault(w => w.SenderKeyId == senderKeyId && w.RunId == runId);
        if (mark is null)
            db.JournalWatermarks.Add(new JournalWatermark { SenderKeyId = senderKeyId, RunId = runId, Counter = unchecked((long)counter), FirstUtc = now.UtcDateTime });
        else if (counter > unchecked((ulong)mark.Counter))
            mark.Counter = unchecked((long)counter);

        if (!db.JournalTransfers.Any(t => t.SessionId == sessionId))
            db.JournalTransfers.Add(new JournalTransfer
            {
                SessionId = sessionId,
                SenderKeyId = senderKeyId,
                Counter = unchecked((long)counter),
                ReceivedUtc = now.UtcDateTime,
                Status = Verified,
            });
        db.SaveChanges();
        tx.Commit();
    }

    public bool IsNewRun(string senderKeyId, Guid runId)
    {
        using var db = factory.CreateDbContext();
        return !db.JournalWatermarks.Any(w => w.SenderKeyId == senderKeyId && w.RunId == runId);
    }

    public bool IsStoredSession(Guid sessionId)
    {
        using var db = factory.CreateDbContext();
        return db.JournalTransfers.Any(t => t.SessionId == sessionId && (t.Status == "stored" || t.Status == "duplicate"));
    }

    public bool IsDuplicateContent(string senderKeyId, string plaintextSha256)
    {
        using var db = factory.CreateDbContext();
        return db.JournalTransfers.Any(t => t.SenderKeyId == senderKeyId && t.PlaintextSha256 == plaintextSha256 && t.Status == "stored");
    }

    public void RecordTransfer(Guid sessionId, string plaintextSha256, string filename, long size, string status)
    {
        using var db = factory.CreateDbContext();
        string name = Truncate(filename, 1024);
        string state = Truncate(status, 32);
        db.JournalTransfers.Where(t => t.SessionId == sessionId).ExecuteUpdate(s => s
            .SetProperty(t => t.PlaintextSha256, plaintextSha256)
            .SetProperty(t => t.Filename, name)
            .SetProperty(t => t.Size, size)
            .SetProperty(t => t.Status, state));
    }

    public long AddArchiveEntry(JournalArchiveEntry entry)
    {
        using var db = factory.CreateDbContext();
        db.JournalArchive.Add(Fitted(entry));
        db.SaveChanges();
        return entry.Id;
    }

    public IReadOnlyList<JournalArchiveEntry> FindArchiveEntries(JournalArchiveFilter filter, int limit)
    {
        using var db = factory.CreateDbContext();
        return Filtered(db.JournalArchive.AsNoTracking(), filter)
            .OrderByDescending(a => a.ReceivedUtc).ThenByDescending(a => a.Id)
            .Take(Math.Clamp(limit, 1, MaxArchiveRows))
            .ToList();
    }

    public JournalArchiveTotals CountArchive(JournalArchiveFilter filter)
    {
        using var db = factory.CreateDbContext();
        var q = Filtered(db.JournalArchive, filter);
        var row = q.GroupBy(_ => 1).Select(g => new
        {
            Arrivals = g.Count(),
            Verified = g.Count(a => a.Outcome == JournalOutcomes.Verified),
            Duplicates = g.Count(a => a.Outcome == JournalOutcomes.Duplicate),
            NotLanded = g.Count(a => a.Outcome == JournalOutcomes.Rejected || a.Outcome == JournalOutcomes.StoreFailed ||
                                     a.Outcome == JournalOutcomes.Incomplete),
            StoredBytes = g.Sum(a => a.Outcome == JournalOutcomes.Verified ? a.Size : 0L),
        }).FirstOrDefault();
        if (row is null) return new JournalArchiveTotals(0, 0, 0, 0, 0, null, null);

        DateTime? first = q.OrderBy(a => a.ReceivedUtc).Select(a => (DateTime?)a.ReceivedUtc).FirstOrDefault();
        DateTime? last = q.OrderByDescending(a => a.ReceivedUtc).Select(a => (DateTime?)a.ReceivedUtc).FirstOrDefault();
        return new JournalArchiveTotals(row.Arrivals, row.Verified, row.Duplicates, row.NotLanded, row.StoredBytes, first, last);
    }

    public IReadOnlyList<JournalTypeTally> CountArchiveByType(JournalArchiveFilter filter)
    {
        using var db = factory.CreateDbContext();
        return Filtered(db.JournalArchive, filter)
            .GroupBy(a => new { a.TypeCode, a.TypeName })
            .Select(g => new
            {
                g.Key.TypeCode,
                g.Key.TypeName,
                Count = g.Count(),
                Bytes = g.Sum(a => a.Outcome == JournalOutcomes.Verified ? a.Size : 0L),
            })
            .OrderByDescending(t => t.Count).ThenBy(t => t.TypeCode)
            .Take(16)
            .AsEnumerable()
            .Select(t => new JournalTypeTally(t.TypeCode, t.TypeName, t.Count, t.Bytes))
            .ToList();
    }

    private static IQueryable<JournalArchiveEntry> Filtered(IQueryable<JournalArchiveEntry> q, JournalArchiveFilter filter)
    {
        if (filter.SinceUtc is { } since) q = q.Where(a => a.ReceivedUtc >= since);
        if (filter.Outcomes is { Length: > 0 } outcomes) q = q.Where(a => outcomes.Contains(a.Outcome));
        if (filter.Search is { Length: > 0 } search)
        {
            // A search box is free text: % and _ must match themselves, not act as wildcards.
            string p = "%" + search.Replace("\\", "\\\\").Replace("%", "\\%").Replace("_", "\\_") + "%";
            q = q.Where(a => EF.Functions.Like(a.Filename, p, "\\") || EF.Functions.Like(a.TypeName, p, "\\") ||
                             EF.Functions.Like(a.TypeCode, p, "\\") || EF.Functions.Like(a.SessionId, p, "\\") ||
                             EF.Functions.Like(a.Receipt, p, "\\") || EF.Functions.Like(a.SenderKeyId, p, "\\") ||
                             EF.Functions.Like(a.Snippet, p, "\\") || EF.Functions.Like(a.Reason ?? "", p, "\\"));
        }
        return q;
    }

    /// <summary>The entry with every text cut to its column's length (a long exception message must not lose the row).</summary>
    private static JournalArchiveEntry Fitted(JournalArchiveEntry e)
    {
        e.Outcome = Truncate(e.Outcome, 32);
        e.SessionId = Truncate(e.SessionId, 64);
        e.SenderKeyId = Truncate(e.SenderKeyId, 256);
        e.TypeCode = Truncate(e.TypeCode, 64);
        e.TypeName = Truncate(e.TypeName, 256);
        e.Filename = Truncate(e.Filename, 1024);
        e.Sha256 = Truncate(e.Sha256, 128);
        e.Receipt = Truncate(e.Receipt, 256);
        e.StoredPath = e.StoredPath is null ? null : Truncate(e.StoredPath, 1024);
        e.Reason = e.Reason is null ? null : Truncate(e.Reason, 2000);
        e.Snippet = Truncate(e.Snippet, 2000);
        return e;
    }

    private static string Truncate(string s, int max) => s.Length <= max ? s : s[..max];
}

/// <summary>What the Receiver's archive tab asks for: free-text search, any of these outcomes, arrived since.</summary>
public sealed record JournalArchiveFilter(string Search = "", string[]? Outcomes = null, DateTime? SinceUtc = null);

/// <summary>Headline numbers for the archive (<see cref="ReceiveJournalRepository.CountArchive"/>).</summary>
public sealed record JournalArchiveTotals(int Arrivals, int Verified, int Duplicates, int NotLanded, long StoredBytes,
                                          DateTime? FirstUtc, DateTime? LastUtc);

/// <summary>One payload type and how much of it arrived (<see cref="ReceiveJournalRepository.CountArchiveByType"/>).</summary>
public sealed record JournalTypeTally(string Code, string Name, int Count, long Bytes);
