using System.Globalization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Repositories;

/// <summary>
/// Queue operations on the Outbox table of the bridge database. Each method uses its own short-lived DbContext.
/// New rows come only through <see cref="InsertAsync"/>, called only by the Gateway's OutboxWriter (it decides the rules;
/// the sequence number and the insert share one write transaction here); claiming and marking rows is done by the QR
/// sender. The light group (LightStatus) moves as the message crosses; the service group (ServiceStatus) moves once,
/// when the far side's Reply arrives (<see cref="MarkAnsweredAsync"/>).
/// </summary>
public sealed class OutboxRepository(IDbContextFactory<BridgeDbContext> factory, IOptions<GatewayDatabaseOptions> bridgeOptions) : IOutboxRepository
{
    private const int MaxCommentLength = 2000;
    private const int MaxContentTypeLength = 4096;

    private readonly int _maxReplyBytes = bridgeOptions.Value.MaxPayloadBytes;

    /// <summary>
    /// Queues one row, in one transaction holding the bridge's write lock (<see cref="BridgeDbContext.BeginWriteTransactionAsync"/>),
    /// so identical calls at the same moment make one row and simultaneous calls cannot all see room in the backlog:
    /// (1) a Request with a fingerprint: the first Request of the same direction with the same content created since
    /// <see cref="OutboxInsert.RetryWindowStartUtc"/> that the far side did not surely refuse (Expired, NotDelivered,
    /// Rejected: decision D63) — when <see cref="OutboxInsert.AttachRetries"/>, nothing is stored (Attached);
    /// (2) a Request: the backlog of Requests not yet confirmed (Pending, Sending, Aired), overall and for its service
    /// (BacklogFull, decisions D47, D78); (3) the direction's next sequence number and its counter run;
    /// (4) <paramref name="buildRow"/> makes the row from them; it is inserted and committed (Queued).
    /// </summary>
    public async Task<OutboxInsertResult> InsertAsync(OutboxInsert insert, Func<long, Guid, OutboxMessage> buildRow, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        await using var tx = await db.BeginWriteTransactionAsync(ct);
        bool request = insert.Kind == MessageKind.Request;

        Guid? sameContent = null;
        if (request && insert.ContentFingerprint is { } fingerprint)
        {
            sameContent = (await db.Outbox
                .Where(m => m.ContentFingerprint == fingerprint && m.Kind == MessageKind.Request &&
                            m.Direction == insert.Direction && m.CreatedUtc >= insert.RetryWindowStartUtc &&
                            m.ServiceStatus != OutboxServiceStatus.Expired && m.ServiceStatus != OutboxServiceStatus.NotDelivered &&
                            m.ServiceStatus != OutboxServiceStatus.Rejected)
                .OrderBy(m => m.CreatedUtc).ThenBy(m => m.Sequence)
                .Select(m => new { m.MessageId })
                .FirstOrDefaultAsync(ct))?.MessageId;

            // Before the backlog check: a retry of a message already queued adds nothing to the backlog.
            if (sameContent is { } firstId && insert.AttachRetries)
                return new OutboxInsertResult(OutboxInsertOutcome.Attached, firstId);
        }

        // Only Requests count, and only Requests are refused: a Receipt or a Reply is never lost to a full Outbox.
        if (request)
        {
            int backlog = await db.Outbox.CountAsync(m => m.Kind == MessageKind.Request &&
                                                          (m.LightStatus == OutboxLightStatus.Pending ||
                                                           m.LightStatus == OutboxLightStatus.Sending ||
                                                           m.LightStatus == OutboxLightStatus.Aired), ct);
            if (backlog >= insert.MaxBacklog)
                return new OutboxInsertResult(OutboxInsertOutcome.BacklogFull, null, backlog, insert.MaxBacklog);

            if (insert.ServiceMaxBacklog is { } serviceMax)
            {
                int serviceBacklog = await db.Outbox.CountAsync(m => m.Kind == MessageKind.Request && m.ServiceName == insert.ServiceName &&
                                                                     (m.LightStatus == OutboxLightStatus.Pending ||
                                                                      m.LightStatus == OutboxLightStatus.Sending ||
                                                                      m.LightStatus == OutboxLightStatus.Aired), ct);
                if (serviceBacklog >= serviceMax)
                    return new OutboxInsertResult(OutboxInsertOutcome.BacklogFull, null, serviceBacklog, serviceMax);
            }
        }

        var (sequence, runId) = await NextSequenceAsync(db, insert.Direction, ct);
        db.Outbox.Add(buildRow(sequence, runId));
        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
        return new OutboxInsertResult(OutboxInsertOutcome.Queued, sameContent);
    }

    /// <summary>
    /// The direction's next number, inside the caller's write transaction. The counter's run id is set on its first use
    /// and then never changes (see <see cref="SequenceCounter.RunId"/>). Increment and read are two statements; the
    /// write lock the transaction holds keeps them together on every engine.
    /// </summary>
    private static async Task<(long Sequence, Guid RunId)> NextSequenceAsync(BridgeDbContext db, Direction direction, CancellationToken ct)
    {
        Guid newRunId = Guid.NewGuid();
        int updated = await db.SequenceCounters
            .Where(c => c.Direction == direction)
            .ExecuteUpdateAsync(s => s
                .SetProperty(c => c.LastValue, c => c.LastValue + 1)
                .SetProperty(c => c.RunId, c => c.RunId ?? newRunId), ct);
        if (updated == 1)
        {
            var counter = await db.SequenceCounters.AsNoTracking().Where(c => c.Direction == direction)
                .Select(c => new { c.LastValue, c.RunId })
                .FirstAsync(ct);
            return (counter.LastValue, counter.RunId!.Value);
        }

        // Row missing (shouldn't happen: it is seeded) — create it, starting a new run.
        db.SequenceCounters.Add(new SequenceCounter { Direction = direction, LastValue = 1, RunId = newRunId });
        await db.SaveChangesAsync(ct);
        return (1, newRunId);
    }

    /// <summary>
    /// Atomically claims the next row to air (Pending -> Sending): Receipts, Replies and Heartbeats first, then Requests
    /// by class (Priority, decision D73), lowest Sequence first within a class. Returns null if none.
    /// Optimistic claim: the UPDATE only succeeds if the row is still Pending, so two claimers can never get the same row.
    /// </summary>
    public async Task<OutboxMessage?> ClaimNextAsync(CancellationToken ct)
    {
        for (int attempt = 0; attempt < 5; attempt++)
        {
            await using var db = await factory.CreateDbContextAsync(ct);
            var now = DateTime.UtcNow;

            Guid? id = await db.Outbox
                .Where(m => m.LightStatus == OutboxLightStatus.Pending && (m.NextAttemptUtc == null || m.NextAttemptUtc <= now))
                .OrderBy(m => m.Priority).ThenBy(m => m.Sequence)
                .Select(m => (Guid?)m.MessageId)
                .FirstOrDefaultAsync(ct);
            if (id is null) return null;

            int claimed = await db.Outbox
                .Where(m => m.MessageId == id && m.LightStatus == OutboxLightStatus.Pending)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.LightStatus, OutboxLightStatus.Sending)
                    .SetProperty(m => m.LightUpdatedUtc, now)
                    .SetProperty(m => m.LockedUtc, now)
                    .SetProperty(m => m.Attempts, m => m.Attempts + 1), ct);

            if (claimed == 1)
                return await db.Outbox.AsNoTracking().FirstAsync(m => m.MessageId == id, ct);
        }
        return null;
    }

    /// <summary>
    /// Atomically claims the next bundle to air (Pending -> Sending), for the QR sender: due rows in the order of
    /// <see cref="ClaimNextAsync"/>, at most <paramref name="maxMessages"/>, while the bundle stays within
    /// <paramref name="maxBytes"/> (<see cref="Bundles.BundleCodec"/> sizes). Strict order (decision 52): it stops at the
    /// first row that would not fit — never skips ahead to a smaller one — and the first row always goes, alone when it
    /// is bigger than the limit by itself. Every claimed row gets the new BundleId; Attempts counts the claim, as
    /// ClaimNextAsync does. Returns null when nothing is due.
    /// </summary>
    public async Task<ClaimedBundle?> ClaimBundleAsync(int maxMessages, int maxBytes, CancellationToken ct)
    {
        ArgumentOutOfRangeException.ThrowIfLessThan(maxMessages, 1);
        for (int attempt = 0; attempt < 5; attempt++)
        {
            await using var db = await factory.CreateDbContextAsync(ct);
            var now = DateTime.UtcNow;

            var candidates = await db.Outbox
                .Where(m => m.LightStatus == OutboxLightStatus.Pending && (m.NextAttemptUtc == null || m.NextAttemptUtc <= now))
                .OrderBy(m => m.Priority).ThenBy(m => m.Sequence)
                .Select(m => new { m.MessageId, Size = m.MessageBytes.Length })
                .Take(maxMessages)
                .ToListAsync(ct);
            if (candidates.Count == 0) return null;

            var ids = new List<Guid>();
            long size = Bundles.BundleCodec.HeaderSize;
            foreach (var candidate in candidates)
            {
                long withIt = size + Bundles.BundleCodec.EntryOverhead + candidate.Size;
                if (ids.Count > 0 && withIt > maxBytes) break;
                ids.Add(candidate.MessageId);
                size = withIt;
            }

            Guid bundleId = Guid.NewGuid();
            int claimed = await db.Outbox
                .Where(m => ids.Contains(m.MessageId) && m.LightStatus == OutboxLightStatus.Pending)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.LightStatus, OutboxLightStatus.Sending)
                    .SetProperty(m => m.LightUpdatedUtc, now)
                    .SetProperty(m => m.LockedUtc, now)
                    .SetProperty(m => m.BundleId, bundleId)
                    .SetProperty(m => m.Attempts, m => m.Attempts + 1), ct);
            if (claimed == 0) continue; // taken meanwhile: look again

            var rows = await db.Outbox.AsNoTracking()
                .Where(m => m.BundleId == bundleId && m.LightStatus == OutboxLightStatus.Sending)
                .OrderBy(m => m.Priority).ThenBy(m => m.Sequence)
                .ToListAsync(ct);
            return new ClaimedBundle(bundleId, rows);
        }
        return null;
    }

    /// <summary>
    /// The QR sender finished showing this bundle in QR session <paramref name="qrSessionId"/> (Sending -> Aired). Only
    /// rows still Sending change, so a late call cannot undo a Receipt that already arrived. ServiceStatus stays as it is.
    /// </summary>
    public async Task<int> MarkAiredAsync(Guid bundleId, Guid qrSessionId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        return await db.Outbox
            .Where(m => m.BundleId == bundleId && m.LightStatus == OutboxLightStatus.Sending)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.LightStatus, OutboxLightStatus.Aired)
                .SetProperty(m => m.QrSessionId, qrSessionId)
                .SetProperty(m => m.LightUpdatedUtc, now)
                .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
    }

    /// <summary>
    /// The QR sender could not air this bundle (stage closed, operator skip, encode error): its rows go back to Pending,
    /// due again after <paramref name="retryDelay"/>, the reason in LightComment. Not a failure — nothing crossed. The
    /// Sender passes zero after a stage close or a skip, and about 30 s after an encode error, so a broken bundle cannot spin.
    /// </summary>
    public async Task<int> ReleaseBundleAsync(Guid bundleId, string reason, TimeSpan retryDelay, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        string? comment = Truncate(reason, MaxCommentLength);
        return await db.Outbox
            .Where(m => m.BundleId == bundleId && m.LightStatus == OutboxLightStatus.Sending)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.LightStatus, OutboxLightStatus.Pending)
                .SetProperty(m => m.NextAttemptUtc, now + retryDelay)
                .SetProperty(m => m.BundleId, (Guid?)null)
                .SetProperty(m => m.LockedUtc, (DateTime?)null)
                .SetProperty(m => m.LightComment, comment)
                .SetProperty(m => m.LightUpdatedUtc, now), ct);
    }

    /// <summary>
    /// The QR sender finished showing these messages (Sending -> Aired). Only rows still Sending change, so a late call
    /// cannot undo a Receipt that already arrived. The QR sender uses the bundle overload; this one is for single rows.
    /// </summary>
    public async Task<int> MarkAiredAsync(IReadOnlyCollection<Guid> messageIds, CancellationToken ct)
    {
        if (messageIds.Count == 0) return 0;
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        int total = 0;
        foreach (Guid id in messageIds.Distinct())
        {
            total += await db.Outbox
                .Where(m => m.MessageId == id && m.LightStatus == OutboxLightStatus.Sending)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.LightStatus, OutboxLightStatus.Aired)
                    .SetProperty(m => m.LightUpdatedUtc, now)
                    .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
        }
        return total;
    }

    /// <summary>The far side confirmed storing these messages (Receipt). Ids that don't exist or are already Received are ignored.</summary>
    public async Task<int> MarkReceivedAsync(IReadOnlyCollection<Guid> messageIds, CancellationToken ct)
    {
        if (messageIds.Count == 0) return 0;
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        int total = 0;
        // One small UPDATE per id (a receipt carries at most a bundle's worth) — simple and index-friendly.
        foreach (Guid id in messageIds.Distinct())
        {
            total += await db.Outbox
                .Where(m => m.MessageId == id && m.LightStatus != OutboxLightStatus.Received)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.LightStatus, OutboxLightStatus.Received)
                    .SetProperty(m => m.LightUpdatedUtc, now)
                    .SetProperty(m => m.LockedUtc, (DateTime?)null)
                    .SetProperty(m => m.LightComment, (string?)null), ct);
        }
        return total;
    }

    /// <summary>
    /// Stores what the far side's real service did with a request, from its Reply: the outcome, HTTP status, a comment,
    /// and the answer itself (Content-Type and body, byte for byte) for the waiting caller or its retry. A Reply implies
    /// a Receipt, so the light group becomes Received too.
    /// Stored when the request is still Waiting, or (decision D59: an operator requeued it on the far side) when the
    /// stored answer is not Answered and came from an older Reply (<paramref name="replyCreatedUtc"/>, the far side's
    /// clock). Returns false when nothing changed: unknown id, not a Request, already Answered, or a re-aired / older Reply.
    /// </summary>
    /// <exception cref="ArgumentException">Status Waiting, a body over GatewayDatabase:MaxPayloadBytes, or a Content-Type over 4,096 characters.</exception>
    public async Task<bool> MarkAnsweredAsync(Guid requestId, OutboxServiceStatus status, int? httpStatus, string comment,
                                              string? contentType, byte[]? body, DateTime replyCreatedUtc, CancellationToken ct)
    {
        if (status == OutboxServiceStatus.Waiting)
            throw new ArgumentException("An answer cannot set ServiceStatus back to Waiting.", nameof(status));
        if (body is { Length: var length } && length > _maxReplyBytes)
            throw new ArgumentException($"Reply body {length} bytes exceeds GatewayDatabase:MaxPayloadBytes ({_maxReplyBytes}).", nameof(body));
        if (contentType is { Length: > MaxContentTypeLength })
            throw new ArgumentException("Reply Content-Type is too long.", nameof(contentType));

        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        string? message = Truncate(comment, MaxCommentLength);
        int updated = await db.Outbox
            .Where(m => m.MessageId == requestId && m.Kind == MessageKind.Request &&
                        (m.ServiceStatus == OutboxServiceStatus.Waiting ||
                         (m.ServiceStatus != OutboxServiceStatus.Answered && m.ReplyCreatedUtc < replyCreatedUtc)))
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.ServiceStatus, status)
                .SetProperty(m => m.ServiceHttpStatus, httpStatus)
                .SetProperty(m => m.ServiceComment, message)
                .SetProperty(m => m.ServiceUpdatedUtc, now)
                .SetProperty(m => m.ReplyContentType, contentType)
                .SetProperty(m => m.ReplyBody, body)
                .SetProperty(m => m.ReplyCreatedUtc, replyCreatedUtc)
                .SetProperty(m => m.LightUpdatedUtc, m => m.LightStatus == OutboxLightStatus.Received ? m.LightUpdatedUtc : now)
                .SetProperty(m => m.LightStatus, OutboxLightStatus.Received)
                .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
        return updated == 1;
    }

    /// <summary>
    /// Gives a message back to the queue after it was shown for too long without a receipt
    /// (lets other messages through). After maxAttempts it is marked Failed for an operator to look at.
    /// </summary>
    public async Task ReleaseAsync(Guid id, string reason, int maxAttempts, TimeSpan retryDelay, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var row = await db.Outbox.FirstOrDefaultAsync(m => m.MessageId == id, ct);
        if (row is null || row.LightStatus != OutboxLightStatus.Sending) return;

        row.LockedUtc = null;
        row.LightUpdatedUtc = DateTime.UtcNow;
        row.LightComment = Truncate(reason, MaxCommentLength);
        if (row.Attempts >= maxAttempts)
        {
            row.LightStatus = OutboxLightStatus.Failed;
        }
        else
        {
            row.LightStatus = OutboxLightStatus.Pending;
            row.NextAttemptUtc = DateTime.UtcNow + retryDelay;
        }
        await db.SaveChangesAsync(ct);
    }

    /// <summary>
    /// Re-airing (decisions D9, D65–D67): every row Aired longer than <paramref name="receiptTimeout"/> ago with no
    /// Receipt yet goes back to Pending so the QR sender airs it again, which is safe because the far Inbox skips a
    /// MessageId it already has and owes a new Receipt. A row that has been aired <paramref name="maxAirAttempts"/> times,
    /// or is past its ExpiresUtc (never aired again), becomes Failed for an operator instead. Receipt and Heartbeat rows
    /// are never aired again: neither gets a Receipt (a lost Heartbeat is replaced by the next one). Each row changes only
    /// if it is still Aired and not re-aired since it was read, so a Receipt that arrives at the same moment always wins.
    /// </summary>
    public async Task<IReadOnlyList<UnconfirmedMessage>> ReairUnconfirmedAsync(TimeSpan receiptTimeout, int maxAirAttempts, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        var airedBefore = now - receiptTimeout;
        var rows = await db.Outbox.AsNoTracking()
            .Where(m => m.LightStatus == OutboxLightStatus.Aired && m.Kind != MessageKind.Receipt && m.Kind != MessageKind.Heartbeat &&
                        (m.LightUpdatedUtc == null || m.LightUpdatedUtc <= airedBefore))
            .OrderBy(m => m.Sequence)
            .Select(m => new { m.MessageId, m.Kind, m.ServiceName, m.Operation, m.Attempts, m.ExpiresUtc })
            .ToListAsync(ct);

        int seconds = (int)receiptTimeout.TotalSeconds;
        var changed = new List<UnconfirmedMessage>();
        foreach (var row in rows)
        {
            string aired = row.Attempts == 1 ? "Aired once" : $"Aired {row.Attempts} times";
            var (status, reason) = row.ExpiresUtc is { } expires && expires <= now
                ? (OutboxLightStatus.Failed, string.Create(CultureInfo.InvariantCulture, // US format, as the UI shows times
                    $"Expired at {expires:MM/dd/yyyy hh:mm:ss tt} UTC before the far side confirmed it ({aired.ToLowerInvariant()}): not aired again."))
                : row.Attempts >= maxAirAttempts
                    ? (OutboxLightStatus.Failed, $"{aired}, no receipt after {seconds} s: check the screen, the camera and the far QR Receiver, then requeue.")
                    : (OutboxLightStatus.Pending, $"{aired}, no receipt after {seconds} s: aired again.");

            int updated = await db.Outbox
                .Where(m => m.MessageId == row.MessageId && m.LightStatus == OutboxLightStatus.Aired &&
                            (m.LightUpdatedUtc == null || m.LightUpdatedUtc <= airedBefore))
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.LightStatus, status)
                    .SetProperty(m => m.LightComment, reason)
                    .SetProperty(m => m.LightUpdatedUtc, now)
                    .SetProperty(m => m.NextAttemptUtc, (DateTime?)null), ct);
            if (updated == 1)
                changed.Add(new UnconfirmedMessage(row.MessageId, row.Kind, row.ServiceName, row.Operation, row.Attempts, status, reason));
        }
        return changed;
    }

    /// <summary>
    /// Called by the QR sender at startup: anything it was showing when it stopped goes back to Pending, out of its
    /// bundle (the next claim makes a new one).
    /// </summary>
    public async Task<int> ResetSendingAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        return await db.Outbox
            .Where(m => m.LightStatus == OutboxLightStatus.Sending)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.LightStatus, OutboxLightStatus.Pending)
                .SetProperty(m => m.LightUpdatedUtc, now)
                .SetProperty(m => m.BundleId, (Guid?)null)
                .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
    }

    /// <summary>Operator action: put a Failed message back in the queue.</summary>
    public async Task<int> RequeueFailedAsync(Guid? messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        var q = db.Outbox.Where(m => m.LightStatus == OutboxLightStatus.Failed);
        if (messageId is { } id) q = q.Where(m => m.MessageId == id);
        return await q.ExecuteUpdateAsync(s => s
            .SetProperty(m => m.LightStatus, OutboxLightStatus.Pending)
            .SetProperty(m => m.LightUpdatedUtc, now)
            .SetProperty(m => m.Attempts, 0)
            .SetProperty(m => m.NextAttemptUtc, (DateTime?)null), ct);
    }

    public async Task<OutboxMessage?> FindAsync(Guid messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.AsNoTracking().FirstOrDefaultAsync(m => m.MessageId == messageId, ct);
    }

    /// <summary>
    /// The latest Reply this side wrote for <paramref name="requestId"/> (after an operator requeue, the newest outcome), or
    /// null. Crash recovery (D46, D64) and layer 3b (D58) read it.
    /// </summary>
    public async Task<OutboxMessage?> FindLastReplyToAsync(Guid requestId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.AsNoTracking()
            .Where(m => m.Kind == MessageKind.Reply && m.CorrelationId == requestId)
            .OrderByDescending(m => m.CreatedUtc).ThenByDescending(m => m.Sequence)
            .FirstOrDefaultAsync(ct);
    }

    /// <summary>
    /// Where a message stands, and the far side's answer once it is stored, without the message bytes: read by a held
    /// caller every few seconds, and by the Reply reader to check a Reply against its request. Null when unknown.
    /// </summary>
    public async Task<MessageState?> FindStateAsync(Guid messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.AsNoTracking()
            .Where(m => m.MessageId == messageId)
            .Select(m => new MessageState(m.MessageId, m.Kind, m.ServiceName, m.Operation, m.LightStatus, m.ServiceStatus,
                                          m.ServiceHttpStatus, m.ReplyContentType, m.ReplyBody))
            .FirstOrDefaultAsync(ct);
    }

    /// <summary>When this side last queued anything to send (any kind); null when never. For the idle Heartbeat (D81).</summary>
    public async Task<DateTime?> FindLastQueuedUtcAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.OrderByDescending(m => m.CreatedUtc).Select(m => (DateTime?)m.CreatedUtc).FirstOrDefaultAsync(ct);
    }

    /// <summary>A Heartbeat is still waiting to be aired (Pending or Sending): the light is down or busy, so another one adds nothing.</summary>
    public async Task<bool> AnyHeartbeatWaitingAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.AnyAsync(m => m.Kind == MessageKind.Heartbeat &&
                                             (m.LightStatus == OutboxLightStatus.Pending || m.LightStatus == OutboxLightStatus.Sending), ct);
    }

    public async Task<OutboxCounts> GetCountsAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var light = await db.Outbox.GroupBy(m => m.LightStatus)
            .Select(g => new { g.Key, Count = g.Count() })
            .ToListAsync(ct);
        var service = await db.Outbox.GroupBy(m => m.ServiceStatus)
            .Select(g => new { g.Key, Count = g.Count() })
            .ToListAsync(ct);
        // An aired Receipt or Heartbeat is done (neither gets a Receipt), so it is not "unconfirmed".
        DateTime? oldest = await db.Outbox
            .Where(m => m.LightStatus == OutboxLightStatus.Pending || m.LightStatus == OutboxLightStatus.Sending ||
                        (m.LightStatus == OutboxLightStatus.Aired && m.Kind != MessageKind.Receipt && m.Kind != MessageKind.Heartbeat))
            .OrderBy(m => m.Sequence)
            .Select(m => (DateTime?)m.CreatedUtc)
            .FirstOrDefaultAsync(ct);

        return new OutboxCounts(
            StatusCounts.ForAll(light.Select(g => KeyValuePair.Create(g.Key, g.Count))),
            StatusCounts.ForAll(service.Select(g => KeyValuePair.Create(g.Key, g.Count))),
            oldest);
    }

    private static string? Truncate(string? s, int max) => s is null || s.Length <= max ? s : s[..max];
}

/// <summary>One bundle <see cref="OutboxRepository.ClaimBundleAsync"/> claimed: its id and its rows, in claim order.</summary>
public sealed record ClaimedBundle(Guid BundleId, IReadOnlyList<OutboxMessage> Messages);

/// <summary>What OutboxWriter asks <see cref="OutboxRepository.InsertAsync"/> to check before it stores a row.</summary>
/// <param name="ContentFingerprint">A Request's content fingerprint (decision D37); null: never compared.</param>
/// <param name="RetryWindowStartUtc">Same content created at or after this time counts as the same call.</param>
/// <param name="AttachRetries">Same content found: store nothing (Attached) instead of queuing it again.</param>
/// <param name="MaxBacklog">Requests not yet confirmed (Pending, Sending, Aired) allowed in the Outbox (Gateway:MaxBacklog).</param>
/// <param name="ServiceMaxBacklog">The same for <paramref name="ServiceName"/> alone (its route's MaxBacklog), or null.</param>
public sealed record OutboxInsert(
    Direction Direction,
    MessageKind Kind,
    string ServiceName,
    string? ContentFingerprint,
    DateTime RetryWindowStartUtc,
    bool AttachRetries,
    int MaxBacklog,
    int? ServiceMaxBacklog);

/// <summary>What <see cref="OutboxRepository.InsertAsync"/> did.</summary>
/// <param name="SameContentId">
/// Attached: the message the call now belongs to. Queued: an earlier message with the same content that was queued
/// again anyway (its route does not recognise retries), or null.
/// </param>
/// <param name="Backlog">BacklogFull: the Requests counted.</param>
/// <param name="BacklogLimit">BacklogFull: the limit that was reached.</param>
public sealed record OutboxInsertResult(OutboxInsertOutcome Outcome, Guid? SameContentId, int Backlog = 0, int BacklogLimit = 0);

/// <param name="Light">Rows per LightStatus (every status listed, 0 when none).</param>
/// <param name="Service">Rows per ServiceStatus (every status listed, 0 when none).</param>
/// <param name="OldestUndeliveredUtc">CreatedUtc of the oldest row the far side has not confirmed yet; null when none.</param>
public sealed record OutboxCounts(
    IReadOnlyDictionary<OutboxLightStatus, int> Light,
    IReadOnlyDictionary<OutboxServiceStatus, int> Service,
    DateTime? OldestUndeliveredUtc);

/// <summary>
/// One row <see cref="OutboxRepository.ReairUnconfirmedAsync"/> changed: back to Pending (aired again) or Failed (out of
/// tries or expired), with the reason it wrote to LightComment. Ids and names only, never the payload.
/// </summary>
public sealed record UnconfirmedMessage(
    Guid MessageId,
    MessageKind Kind,
    string ServiceName,
    string Operation,
    int Airs,
    OutboxLightStatus NewStatus,
    string Reason);

/// <summary>
/// One Outbox row's statuses and stored answer (<see cref="OutboxRepository.FindStateAsync"/>). ReplyBody and
/// ReplyContentType are the real service's answer, null until a Reply carrying one arrived.
/// </summary>
public sealed record MessageState(
    Guid MessageId,
    MessageKind Kind,
    string ServiceName,
    string Operation,
    OutboxLightStatus LightStatus,
    OutboxServiceStatus ServiceStatus,
    int? ServiceHttpStatus,
    string? ReplyContentType,
    byte[]? ReplyBody);
