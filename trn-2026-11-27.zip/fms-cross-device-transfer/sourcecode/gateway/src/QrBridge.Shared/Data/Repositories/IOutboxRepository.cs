using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Repositories;

/// <summary>
/// The Outbox: what this side sends. Written only through <see cref="InsertAsync"/> (by the gateway's OutboxWriter),
/// aired by the QR sender (claim, mark aired, release), confirmed by the far side's Receipts and Replies. Details of
/// every rule are on <see cref="OutboxRepository"/>.
/// </summary>
public interface IOutboxRepository
{
    /// <summary>Queues one row in one write transaction: retry lookup, backlog checks, next sequence number, insert.</summary>
    Task<OutboxInsertResult> InsertAsync(OutboxInsert insert, Func<long, Guid, OutboxMessage> buildRow, CancellationToken ct);

    /// <summary>Claims the next row to air (Pending -> Sending), or null.</summary>
    Task<OutboxMessage?> ClaimNextAsync(CancellationToken ct);

    /// <summary>Claims the next bundle to air (Pending -> Sending), strict order, or null.</summary>
    Task<ClaimedBundle?> ClaimBundleAsync(int maxMessages, int maxBytes, CancellationToken ct);

    /// <summary>The bundle was shown in QR session <paramref name="qrSessionId"/> (Sending -> Aired).</summary>
    Task<int> MarkAiredAsync(Guid bundleId, Guid qrSessionId, CancellationToken ct);

    /// <summary>The bundle could not be aired: its rows go back to Pending after <paramref name="retryDelay"/>.</summary>
    Task<int> ReleaseBundleAsync(Guid bundleId, string reason, TimeSpan retryDelay, CancellationToken ct);

    /// <summary>These rows were shown (Sending -> Aired).</summary>
    Task<int> MarkAiredAsync(IReadOnlyCollection<Guid> messageIds, CancellationToken ct);

    /// <summary>The far side confirmed storing these rows (a Receipt).</summary>
    Task<int> MarkReceivedAsync(IReadOnlyCollection<Guid> messageIds, CancellationToken ct);

    /// <summary>Stores the far side's answer to a Request (from its Reply); false when nothing changed.</summary>
    Task<bool> MarkAnsweredAsync(Guid requestId, OutboxServiceStatus status, int? httpStatus, string comment,
                                 string? contentType, byte[]? body, DateTime replyCreatedUtc, CancellationToken ct);

    /// <summary>Gives a row being shown back to the queue, or Failed after <paramref name="maxAttempts"/>.</summary>
    Task ReleaseAsync(Guid id, string reason, int maxAttempts, TimeSpan retryDelay, CancellationToken ct);

    /// <summary>Re-airing: rows Aired with no Receipt go back to Pending, or Failed when out of tries or expired.</summary>
    Task<IReadOnlyList<UnconfirmedMessage>> ReairUnconfirmedAsync(TimeSpan receiptTimeout, int maxAirAttempts, CancellationToken ct);

    /// <summary>QR sender start-up: anything still Sending goes back to Pending.</summary>
    Task<int> ResetSendingAsync(CancellationToken ct);

    /// <summary>Operator action: Failed rows back to Pending.</summary>
    Task<int> RequeueFailedAsync(Guid? messageId, CancellationToken ct);

    Task<OutboxMessage?> FindAsync(Guid messageId, CancellationToken ct);

    /// <summary>The latest Reply this side wrote for <paramref name="requestId"/>, or null.</summary>
    Task<OutboxMessage?> FindLastReplyToAsync(Guid requestId, CancellationToken ct);

    /// <summary>A row's statuses and stored answer, without the message bytes, or null.</summary>
    Task<MessageState?> FindStateAsync(Guid messageId, CancellationToken ct);

    /// <summary>When this side last queued anything; null when never.</summary>
    Task<DateTime?> FindLastQueuedUtcAsync(CancellationToken ct);

    /// <summary>A Heartbeat is still waiting to be aired (Pending or Sending).</summary>
    Task<bool> AnyHeartbeatWaitingAsync(CancellationToken ct);

    Task<OutboxCounts> GetCountsAsync(CancellationToken ct);
}
