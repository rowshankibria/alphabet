using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Repositories;

/// <summary>
/// The QR Receiver's journal in the bridge database: the QR sessions it accepted, its anti-replay watermarks (QrDiode
/// protocol v2) and its archive. Used only by the QR Receiver, in both of its modes. Synchronous, because QrDiode's
/// anti-replay check is. Details of every rule are on <see cref="ReceiveJournalRepository"/>.
/// </summary>
public interface IReceiveJournalRepository
{
    /// <summary>May this QR session be accepted? Unseen session, counter above its run's watermark, timestamp within the window.</summary>
    JournalReplayCheck CheckReplay(string senderKeyId, Guid sessionId, Guid runId, ulong counter, long timestampUnixMs,
                                   TimeSpan window, DateTimeOffset now);

    /// <summary>Records an accepted session ('verified') and moves its run's watermark up, in one write transaction.</summary>
    void CommitReplay(string senderKeyId, Guid sessionId, Guid runId, ulong counter, DateTimeOffset now);

    /// <summary>True when this sender key has never committed a session in this counter run.</summary>
    bool IsNewRun(string senderKeyId, Guid runId);

    /// <summary>True when this session was already received and stored (or recorded as a duplicate).</summary>
    bool IsStoredSession(Guid sessionId);

    /// <summary>True when this sender already delivered a payload with this plaintext hash.</summary>
    bool IsDuplicateContent(string senderKeyId, string plaintextSha256);

    /// <summary>Completes an accepted session's row with its payload's hash, name, size and final status.</summary>
    void RecordTransfer(Guid sessionId, string plaintextSha256, string filename, long size, string status);

    /// <summary>Adds one arrival to the archive; returns its id.</summary>
    long AddArchiveEntry(JournalArchiveEntry entry);

    /// <summary>The archive, newest first, at most <paramref name="limit"/> rows (1–20,000).</summary>
    IReadOnlyList<JournalArchiveEntry> FindArchiveEntries(JournalArchiveFilter filter, int limit);

    /// <summary>Totals over everything the filter matches, not just a page.</summary>
    JournalArchiveTotals CountArchive(JournalArchiveFilter filter);

    /// <summary>The 16 most frequent payload types the filter matches.</summary>
    IReadOnlyList<JournalTypeTally> CountArchiveByType(JournalArchiveFilter filter);
}
