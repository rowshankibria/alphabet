using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Repositories;

/// <summary>Liveness rows ("component X is alive"), written by every component and shown on /health.</summary>
public interface IHeartbeatRepository
{
    Task BeatAsync(string component, string? info, CancellationToken ct);

    Task<IReadOnlyList<Heartbeat>> GetAllAsync(CancellationToken ct);
}
