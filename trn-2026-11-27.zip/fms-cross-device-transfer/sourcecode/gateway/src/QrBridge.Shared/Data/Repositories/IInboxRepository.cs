using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Serialization;

namespace QrBridge.Shared.Data.Repositories;

/// <summary>
/// The Inbox: what arrived from the other side (stored by the QR receiver, delivered or used by the gateway), with its
/// SequenceWatermark and AcknowledgedGap bookkeeping. Details of every rule are on <see cref="InboxRepository"/>.
/// </summary>
public interface IInboxRepository
{
    // QR receiver side

    /// <summary>Stores one arrived message; false when its MessageId was already there (owed a Receipt again).</summary>
    Task<bool> AddMessageAsync(MessageHeader header, byte[] messageBytes, CancellationToken ct);

    /// <summary>Stores every message of one QR bundle in one write transaction; duplicates are skipped and owed a Receipt again.</summary>
    Task<BundleStoreResult> AddMessagesAsync(IReadOnlyList<(MessageHeader Header, byte[] MessageBytes)> messages,
                                             Guid bundleId, Guid qrSessionId, CancellationToken ct);

    // Gateway side: Receipts and answers

    /// <summary>Messages owed a Receipt, oldest first.</summary>
    Task<IReadOnlyList<DueReceipt>> FindDueReceiptsAsync(int max, CancellationToken ct);

    /// <summary>The Receipt for <paramref name="due"/> is queued.</summary>
    Task ClearReceiptDueAsync(DueReceipt due, CancellationToken ct);

    /// <summary>Receipts, Replies and Heartbeats that arrived and were not used yet.</summary>
    Task<IReadOnlyList<InboxMessage>> FindArrivedAnswersAsync(int max, CancellationToken ct);

    // Gateway side: delivery

    /// <summary>Claims the next Request of class <paramref name="priority"/> ready to deliver (-> Delivering), or null.</summary>
    Task<InboxMessage?> ClaimNextAsync(MessagePriority priority, CancellationToken ct);

    Task MarkDoneAsync(Guid id, int? httpStatus, string comment, string? downstreamResult, CancellationToken ct);
    Task MarkRefusedAsync(Guid id, int? httpStatus, string comment, string? downstreamResult, CancellationToken ct);
    Task MarkUnknownAsync(Guid id, int? httpStatus, string comment, string? downstreamResult, CancellationToken ct);
    Task MarkNotDeliveredAsync(Guid id, int? httpStatus, string comment, CancellationToken ct);
    Task MarkExpiredAsync(Guid id, string comment, CancellationToken ct);
    Task MarkVerifiedAsync(Guid id, CancellationToken ct);
    Task MarkRejectedAsync(Guid id, string reason, CancellationToken ct);
    Task MarkRetryingAsync(Guid id, int? httpStatus, string comment, TimeSpan backoff, CancellationToken ct);

    /// <summary>Shutdown before the POST started: back to Pending without counting the attempt.</summary>
    Task ReleaseAsync(Guid id, CancellationToken ct);

    /// <summary>Rows still Delivering after <paramref name="lockTimeout"/> (crash recovery).</summary>
    Task<IReadOnlyList<InboxMessage>> FindStuckAsync(TimeSpan lockTimeout, CancellationToken ct);

    /// <summary>Other Requests with the same content since <paramref name="sinceUtc"/> that may have reached the service.</summary>
    Task<IReadOnlyList<SameContent>> FindSameContentAsync(Guid messageId, string fingerprint, DateTime sinceUtc, CancellationToken ct);

    /// <summary>Operator action: Refused, Unknown or NotDelivered rows back to Pending.</summary>
    Task<int> RequeueAsync(Guid? messageId, CancellationToken ct);

    Task<InboxMessage?> FindAsync(Guid messageId, CancellationToken ct);
    Task<InboxCounts> GetCountsAsync(CancellationToken ct);

    // Sequence numbers and the far side

    /// <summary>Numbers missing from the sender's sequence, per run of its counter, not acknowledged.</summary>
    Task<IReadOnlyList<SequenceGap>> FindSequenceGapsAsync(Direction direction, DateTime arrivedBeforeUtc, CancellationToken ct);

    /// <summary>Operator action: a range of numbers will never arrive; false when already acknowledged.</summary>
    Task<bool> AcknowledgeGapAsync(Direction direction, Guid sequenceRunId, long fromSequence, long toSequence,
                                   string acknowledgedBy, string reason, CancellationToken ct);

    /// <summary>Why <paramref name="row"/> must be refused for its sequence number, or null.</summary>
    Task<string?> FindSequenceConflictAsync(InboxMessage row, CancellationToken ct);

    /// <summary>Moves each run's watermark up through checked numbers and acknowledged gaps; how many runs moved.</summary>
    Task<int> AdvanceSequenceWatermarksAsync(Direction direction, CancellationToken ct);

    /// <summary>When anything, and when a Receipt, last arrived from the far side; null when never.</summary>
    Task<(DateTime? LastHeardUtc, DateTime? LastReceiptUtc)> FindLastArrivalsAsync(Direction direction, CancellationToken ct);
}
