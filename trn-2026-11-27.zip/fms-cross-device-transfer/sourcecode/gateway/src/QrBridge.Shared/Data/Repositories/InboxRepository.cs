using Microsoft.EntityFrameworkCore;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Serialization;

namespace QrBridge.Shared.Data.Repositories;

/// <summary>
/// Queue operations on the Inbox table of the bridge database (and its SequenceWatermark and AcknowledgedGap tables).
/// Each method uses its own short-lived DbContext.
/// The light group (LightStatus) says whether a message arrived acceptably; the service group (ServiceStatus) tracks
/// its delivery to the real service. Only rows whose LightStatus is Received are delivered, counted as service work
/// or requeued.
/// </summary>
public sealed class InboxRepository(IDbContextFactory<BridgeDbContext> factory) : IInboxRepository
{
    private const int MaxCommentLength = 2000;
    private const int MaxResultLength = 4000;

    // =================== QR receiver side ===================

    /// <summary>
    /// Inserts a complete message (header peeked, not yet checked). Idempotent on MessageId: returns false if the
    /// message was already in the Inbox. The duplicate is ignored, but it is owed a new Receipt (decision D44): it was
    /// aired again because the sender never got the first one.
    /// </summary>
    public async Task<bool> AddMessageAsync(MessageHeader header, byte[] messageBytes, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        if (await db.Inbox.AnyAsync(m => m.MessageId == header.MessageId, ct))
        {
            await OweReceiptAgainAsync(db, header.MessageId, now, ct);
            return false;
        }

        db.Inbox.Add(NewRow(header, messageBytes, now, bundleId: null, qrSessionId: null));

        try
        {
            await db.SaveChangesAsync(ct);
            return true;
        }
        catch (DbUpdateException ex) when (db.IsDuplicateKey(ex))
        {
            // inserted by someone else between the check and the insert
            db.ChangeTracker.Clear();
            await OweReceiptAgainAsync(db, header.MessageId, now, ct);
            return false;
        }
    }

    private static Task OweReceiptAgainAsync(BridgeDbContext db, Guid messageId, DateTime now, CancellationToken ct) =>
        db.Inbox.Where(m => m.MessageId == messageId && m.Kind != MessageKind.Receipt && m.Kind != MessageKind.Heartbeat)
            .ExecuteUpdateAsync(s => s.SetProperty(m => m.ReceiptDueUtc, now), ct);

    /// <summary>
    /// Stores every message of one QR bundle in <b>one</b> transaction, holding the bridge's write lock
    /// (<see cref="BridgeDbContext.BeginWriteTransactionAsync"/>), for the QR receiver. Idempotent
    /// on MessageId, like <see cref="AddMessageAsync"/>: a message already in the Inbox is skipped and owed a Receipt
    /// again (the bundle was aired again because a Receipt was lost), and takes this bundle's ids (the latest crossing);
    /// a MessageId twice in the same bundle is stored once. Either everything is stored or nothing is.
    /// </summary>
    public async Task<BundleStoreResult> AddMessagesAsync(IReadOnlyList<(MessageHeader Header, byte[] MessageBytes)> messages,
                                                         Guid bundleId, Guid qrSessionId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        await using var tx = await db.BeginWriteTransactionAsync(ct); // one writer at a time: the check and the insert cannot race
        var now = DateTime.UtcNow;

        var ids = messages.Select(m => m.Header.MessageId).Distinct().ToList();
        var existing = (await db.Inbox.Where(m => ids.Contains(m.MessageId)).Select(m => m.MessageId).ToListAsync(ct)).ToHashSet();

        var seen = new HashSet<Guid>(existing);
        int added = 0;
        foreach (var (header, bytes) in messages)
        {
            if (!seen.Add(header.MessageId)) continue;
            db.Inbox.Add(NewRow(header, bytes, now, bundleId, qrSessionId));
            added++;
        }
        await db.SaveChangesAsync(ct);

        if (existing.Count > 0)
        {
            var again = existing.ToList();
            await db.Inbox.Where(m => again.Contains(m.MessageId))
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.BundleId, bundleId)
                    .SetProperty(m => m.QrSessionId, qrSessionId), ct);
            await db.Inbox.Where(m => again.Contains(m.MessageId) && m.Kind != MessageKind.Receipt && m.Kind != MessageKind.Heartbeat)
                .ExecuteUpdateAsync(s => s.SetProperty(m => m.ReceiptDueUtc, now), ct);
        }

        await tx.CommitAsync(ct);
        return new BundleStoreResult(added, messages.Count - added);
    }

    /// <summary>A new Inbox row from a peeked header: Received, Pending delivery, owed a Receipt unless it is a Receipt or Heartbeat.</summary>
    private static InboxMessage NewRow(MessageHeader header, byte[] messageBytes, DateTime now, Guid? bundleId, Guid? qrSessionId) => new()
    {
        MessageId = header.MessageId,
        Direction = header.Direction,
        ServiceName = header.ServiceName,
        Operation = header.Operation,
        BusinessType = string.IsNullOrEmpty(header.BusinessType) ? null : header.BusinessType,
        Sequence = header.Sequence,
        SequenceRunId = header.SequenceRunId,
        PayloadFormat = header.PayloadFormat,
        Kind = header.Kind,
        CorrelationId = header.CorrelationId,
        ContentFingerprint = header.ContentFingerprint,
        ExpiresUtc = header.ExpiresUtc,
        Priority = header.Priority,
        BundleId = bundleId,
        QrSessionId = qrSessionId,
        MessageBytes = messageBytes,
        MessageHash = Hashing.Sha256Hex(messageBytes),
        LightStatus = InboxLightStatus.Received,
        ServiceStatus = InboxServiceStatus.Pending,
        ServiceUpdatedUtc = now,
        CreatedUtc = header.CreatedUtc,
        ReceivedUtc = now,
        ReceiptDueUtc = header.Kind is MessageKind.Receipt or MessageKind.Heartbeat ? null : now, // never a Receipt for these
    };

    // =================== Gateway side (receipts) ===================

    /// <summary>Messages owed a Receipt, oldest first (decision D44).</summary>
    public async Task<IReadOnlyList<DueReceipt>> FindDueReceiptsAsync(int max, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Inbox.AsNoTracking()
            .Where(m => m.ReceiptDueUtc != null)
            .OrderBy(m => m.ReceiptDueUtc)
            .Take(max)
            .Select(m => new DueReceipt(m.MessageId, m.ServiceName, m.Operation, m.BusinessType, m.ReceiptDueUtc!.Value))
            .ToListAsync(ct);
    }

    /// <summary>
    /// The Receipt for <paramref name="due"/> is queued. Not cleared when the message arrived again meanwhile
    /// (a later ReceiptDueUtc): that copy is owed its own Receipt.
    /// </summary>
    public async Task ClearReceiptDueAsync(DueReceipt due, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        await db.Inbox.Where(m => m.MessageId == due.MessageId && m.ReceiptDueUtc <= due.DueUtc)
            .ExecuteUpdateAsync(s => s.SetProperty(m => m.ReceiptDueUtc, (DateTime?)null), ct);
    }

    // =================== Gateway side (answers to this side's requests) ===================

    /// <summary>
    /// Receipts, Replies and Heartbeats that arrived and were not used yet, lowest Sequence first. They are read by the
    /// gateway on this side (round trip, step 10a; heartbeats, step 17) and never posted to a service; one reader, so no
    /// claim is needed.
    /// </summary>
    public async Task<IReadOnlyList<InboxMessage>> FindArrivedAnswersAsync(int max, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Inbox.AsNoTracking()
            .Where(m => m.LightStatus == InboxLightStatus.Received && m.Kind != MessageKind.Request &&
                        m.ServiceStatus == InboxServiceStatus.Pending)
            .OrderBy(m => m.Sequence)
            .Take(max)
            .ToListAsync(ct);
    }

    // =================== Gateway side (worker) ===================

    /// <summary>
    /// Atomically claims the next request of class <paramref name="priority"/> ready to deliver (-> Delivering): Pending,
    /// or Retrying whose backoff has expired. Order: the runs of the sender's counter in the order they started, then
    /// the sender's Sequence, so a new run (which starts again at 1) never jumps ahead of older messages. Strict order
    /// (decision D74): a request is not claimed while an earlier request of the same service and class waits to be
    /// re-posted. Rejected rows are never claimed, and neither are Receipts or Replies: they are consumed by the gateway
    /// that sent the request (round trip), never posted to a real service.
    /// </summary>
    public async Task<InboxMessage?> ClaimNextAsync(MessagePriority priority, CancellationToken ct)
    {
        for (int attempt = 0; attempt < 5; attempt++)
        {
            await using var db = await factory.CreateDbContextAsync(ct);
            var now = DateTime.UtcNow;

            Guid? id = await db.Inbox
                .Where(m => m.LightStatus == InboxLightStatus.Received && m.Kind == MessageKind.Request && m.Priority == priority &&
                            (m.ServiceStatus == InboxServiceStatus.Pending ||
                             (m.ServiceStatus == InboxServiceStatus.Retrying && m.NextAttemptUtc != null && m.NextAttemptUtc <= now)) &&
                            !db.Inbox.Any(e => e.ServiceName == m.ServiceName && e.Direction == m.Direction && e.Priority == m.Priority &&
                                               e.Kind == MessageKind.Request && e.LightStatus == InboxLightStatus.Received &&
                                               e.ServiceStatus == InboxServiceStatus.Retrying && e.MessageId != m.MessageId &&
                                               (e.SequenceRunId == m.SequenceRunId ? e.Sequence < m.Sequence : e.CreatedUtc < m.CreatedUtc)))
                // Runs in the order they started (their first message), then the sender's sequence within a run.
                .OrderBy(m => db.Inbox.Where(r => r.Direction == m.Direction && r.SequenceRunId == m.SequenceRunId)
                                      .OrderBy(r => r.Sequence).Select(r => r.CreatedUtc).FirstOrDefault())
                .ThenBy(m => m.Sequence)
                .Select(m => (Guid?)m.MessageId)
                .FirstOrDefaultAsync(ct);
            if (id is null) return null;

            int claimed = await db.Inbox
                .Where(m => m.MessageId == id && m.LightStatus == InboxLightStatus.Received && m.Kind == MessageKind.Request &&
                            (m.ServiceStatus == InboxServiceStatus.Pending || m.ServiceStatus == InboxServiceStatus.Retrying))
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.ServiceStatus, InboxServiceStatus.Delivering)
                    .SetProperty(m => m.ServiceUpdatedUtc, now)
                    .SetProperty(m => m.LockedUtc, now)
                    .SetProperty(m => m.Attempts, m => m.Attempts + 1), ct);

            if (claimed == 1)
                return await db.Inbox.AsNoTracking().FirstAsync(m => m.MessageId == id, ct);
        }
        return null;
    }

    /// <summary>The real service accepted it.</summary>
    public Task MarkDoneAsync(Guid id, int? httpStatus, string comment, string? downstreamResult, CancellationToken ct) =>
        FinishAsync(id, InboxServiceStatus.Done, httpStatus, comment, downstreamResult, verified: true, ct);

    /// <summary>The real service refused it (SOAP fault, non-zero code, 4xx). Never retried on its own; an operator decides.</summary>
    public Task MarkRefusedAsync(Guid id, int? httpStatus, string comment, string? downstreamResult, CancellationToken ct) =>
        FinishAsync(id, InboxServiceStatus.Refused, httpStatus, comment, downstreamResult, verified: false, ct);

    /// <summary>It may have reached the service, but the outcome is not known. Never re-posted on its own: an operator checks first.</summary>
    public Task MarkUnknownAsync(Guid id, int? httpStatus, string comment, string? downstreamResult, CancellationToken ct) =>
        FinishAsync(id, InboxServiceStatus.Unknown, httpStatus, comment, downstreamResult, verified: false, ct);

    /// <summary>It surely never reached the service and will not be tried again (no target, or out of tries where nothing was sent). An operator may resend it.</summary>
    public Task MarkNotDeliveredAsync(Guid id, int? httpStatus, string comment, CancellationToken ct) =>
        FinishAsync(id, InboxServiceStatus.NotDelivered, httpStatus, comment, null, verified: false, ct);

    /// <summary>It arrived (or was still waiting) after its ExpiresUtc: not posted, because the caller has given up.</summary>
    public Task MarkExpiredAsync(Guid id, string comment, CancellationToken ct) =>
        FinishAsync(id, InboxServiceStatus.Expired, null, comment, null, verified: false, ct);

    /// <summary>Every arrival check passed (<c>ArrivalChecks</c>); from now on the row counts toward its run's watermark (D84).</summary>
    public async Task MarkVerifiedAsync(Guid id, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        await db.Inbox.Where(m => m.MessageId == id).ExecuteUpdateAsync(s => s.SetProperty(m => m.Verified, true), ct);
    }

    /// <summary>
    /// Failed an arrival check (checksum, direction, catalogue, payload, replay window): a light problem, never retried
    /// and never delivered. The service group goes back to Pending; it is ignored for rejected rows.
    /// </summary>
    public async Task MarkRejectedAsync(Guid id, string reason, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        string comment = Truncate(reason, MaxCommentLength)!;
        await db.Inbox.Where(m => m.MessageId == id).ExecuteUpdateAsync(s => s
            .SetProperty(m => m.LightStatus, InboxLightStatus.Rejected)
            .SetProperty(m => m.LightComment, comment)
            .SetProperty(m => m.ServiceStatus, InboxServiceStatus.Pending)
            .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
    }

    /// <summary>
    /// A failure where the call surely did not arrive (decision D9: DNS, refused, connect timeout, TLS, HTTP 408/429):
    /// retry after <paramref name="backoff"/>. When the tries are used up, the worker ends it NotDelivered with a Reply
    /// (D25, D45).
    /// </summary>
    public async Task MarkRetryingAsync(Guid id, int? httpStatus, string comment, TimeSpan backoff, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        string message = Truncate(comment, MaxCommentLength)!;
        await db.Inbox.Where(m => m.MessageId == id).ExecuteUpdateAsync(s => s
            .SetProperty(m => m.ServiceStatus, InboxServiceStatus.Retrying)
            .SetProperty(m => m.ServiceHttpStatus, httpStatus)
            .SetProperty(m => m.ServiceComment, message)
            .SetProperty(m => m.ServiceUpdatedUtc, now)
            .SetProperty(m => m.NextAttemptUtc, now + backoff)
            .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
    }

    /// <summary>Shutdown before the POST started: put it back without counting the attempt (nothing was sent).</summary>
    public async Task ReleaseAsync(Guid id, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        await db.Inbox.Where(m => m.MessageId == id && m.ServiceStatus == InboxServiceStatus.Delivering).ExecuteUpdateAsync(s => s
            .SetProperty(m => m.ServiceStatus, InboxServiceStatus.Pending)
            .SetProperty(m => m.ServiceUpdatedUtc, now)
            .SetProperty(m => m.Attempts, m => m.Attempts > 0 ? m.Attempts - 1 : 0)
            .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
    }

    /// <summary>
    /// Rows still Delivering after <paramref name="lockTimeout"/>: the worker crashed or the app pool recycled during
    /// the POST. The gateway settles each one (decision D46): the outcome of its Reply if one was already written,
    /// otherwise Unknown — never posted again on its own (decision D9).
    /// </summary>
    public async Task<IReadOnlyList<InboxMessage>> FindStuckAsync(TimeSpan lockTimeout, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var cutoff = DateTime.UtcNow - lockTimeout;
        return await db.Inbox.AsNoTracking()
            .Where(m => m.ServiceStatus == InboxServiceStatus.Delivering && m.LockedUtc < cutoff)
            .ToListAsync(ct);
    }

    /// <summary>
    /// Other Requests with the same content fingerprint that arrived on this side since <paramref name="sinceUtc"/> and
    /// may have reached the real service (Done, Unknown, or still Delivering): layer 3b of the round trip (decision D58).
    /// Rows that surely were not processed (Refused, NotDelivered, Expired, waiting) are left out: posting again cannot
    /// duplicate them.
    /// </summary>
    public async Task<IReadOnlyList<SameContent>> FindSameContentAsync(Guid messageId, string fingerprint, DateTime sinceUtc,
                                                                       CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Inbox.AsNoTracking()
            .Where(m => m.ContentFingerprint == fingerprint && m.ReceivedUtc >= sinceUtc && m.MessageId != messageId &&
                        m.Kind == MessageKind.Request && m.LightStatus == InboxLightStatus.Received &&
                        (m.ServiceStatus == InboxServiceStatus.Done || m.ServiceStatus == InboxServiceStatus.Unknown ||
                         m.ServiceStatus == InboxServiceStatus.Delivering))
            .OrderBy(m => m.ReceivedUtc)
            .Select(m => new SameContent(m.MessageId, m.ServiceStatus, m.DownstreamResult))
            .ToListAsync(ct);
    }

    /// <summary>Operator action: give a Refused, Unknown or NotDelivered message another try. Rejected rows are never requeued.</summary>
    public async Task<int> RequeueAsync(Guid? messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        var q = db.Inbox.Where(m => m.LightStatus == InboxLightStatus.Received &&
                                    (m.ServiceStatus == InboxServiceStatus.Refused ||
                                     m.ServiceStatus == InboxServiceStatus.Unknown ||
                                     m.ServiceStatus == InboxServiceStatus.NotDelivered));
        if (messageId is { } id) q = q.Where(m => m.MessageId == id);
        return await q.ExecuteUpdateAsync(s => s
            .SetProperty(m => m.ServiceStatus, InboxServiceStatus.Pending)
            .SetProperty(m => m.ServiceUpdatedUtc, now)
            .SetProperty(m => m.Attempts, 0)
            .SetProperty(m => m.NextAttemptUtc, (DateTime?)null), ct);
    }

    public async Task<InboxMessage?> FindAsync(Guid messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Inbox.AsNoTracking().FirstOrDefaultAsync(m => m.MessageId == messageId, ct);
    }

    public async Task<InboxCounts> GetCountsAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var light = await db.Inbox.GroupBy(m => m.LightStatus)
            .Select(g => new { g.Key, Count = g.Count() })
            .ToListAsync(ct);
        var service = await db.Inbox.Where(m => m.LightStatus == InboxLightStatus.Received)
            .GroupBy(m => m.ServiceStatus)
            .Select(g => new { g.Key, Count = g.Count() })
            .ToListAsync(ct);
        DateTime? oldest = await db.Inbox
            .Where(m => m.LightStatus == InboxLightStatus.Received && m.Kind == MessageKind.Request &&
                        (m.ServiceStatus == InboxServiceStatus.Pending || m.ServiceStatus == InboxServiceStatus.Delivering ||
                         m.ServiceStatus == InboxServiceStatus.Retrying))
            .OrderBy(m => m.ReceivedUtc)
            .Select(m => (DateTime?)m.ReceivedUtc)
            .FirstOrDefaultAsync(ct);

        return new InboxCounts(
            StatusCounts.ForAll(light.Select(g => KeyValuePair.Create(g.Key, g.Count))),
            StatusCounts.ForAll(service.Select(g => KeyValuePair.Create(g.Key, g.Count))),
            oldest);
    }

    /// <summary>
    /// Numbers missing from the sender's sequence, per run of its counter (D29): for each run, every number below
    /// the highest one received that never arrived, including the first numbers of a run. A gap is reported only once
    /// the message after it arrived at or before <paramref name="arrivedBeforeUtc"/> (a grace period for bundles that
    /// arrive out of order), and not where an operator acknowledged it (<see cref="AcknowledgeGapAsync"/>).
    /// Every row counts as arrived, Rejected rows too: they are reported as light problems already.
    /// </summary>
    public async Task<IReadOnlyList<SequenceGap>> FindSequenceGapsAsync(Direction direction, DateTime arrivedBeforeUtc, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        string dir = direction.ToString();
        // LAG over each run (index IX_Inbox_Sequence); the default 0 makes "the run started at 5" a gap 1–4.
        // Plain SQL both engines accept (the derived table needs its alias on SQL Server).
        var candidates = await db.Database.SqlQuery<GapRow>($"""
            SELECT SequenceRunId AS RunId, PreviousSequence, Sequence, ReceivedUtc FROM (
                SELECT SequenceRunId, Sequence, ReceivedUtc,
                       LAG(Sequence, 1, 0) OVER (PARTITION BY SequenceRunId ORDER BY Sequence) AS PreviousSequence
                FROM Inbox WHERE Direction = {dir}) AS Runs
            WHERE Sequence > PreviousSequence + 1
            """).ToListAsync(ct);

        var acknowledged = await db.AcknowledgedGaps.AsNoTracking().Where(a => a.Direction == direction).ToListAsync(ct);

        var gaps = new List<SequenceGap>();
        foreach (var c in candidates)
        {
            var since = DateTime.SpecifyKind(c.ReceivedUtc, DateTimeKind.Utc);
            if (since > arrivedBeforeUtc) continue;
            var runId = Guid.Parse(c.RunId);
            var acks = acknowledged.Where(a => a.SequenceRunId == runId).Select(a => (a.FromSequence, a.ToSequence));
            foreach (var (from, to) in Subtract(c.PreviousSequence + 1, c.Sequence - 1, acks))
                gaps.Add(new SequenceGap(direction, runId, from, to, since));
        }
        return gaps.OrderBy(g => g.MissingSinceUtc).ThenBy(g => g.FromSequence).ToList();
    }

    /// <summary>
    /// Operator action (D29, D30): numbers <paramref name="fromSequence"/>–<paramref name="toSequence"/> of a run will
    /// never arrive; stop reporting them. Stored for audit with who and why. Returns false if a range starting at the
    /// same number was already acknowledged.
    /// </summary>
    public async Task<bool> AcknowledgeGapAsync(Direction direction, Guid sequenceRunId, long fromSequence, long toSequence,
                                                string acknowledgedBy, string reason, CancellationToken ct)
    {
        if (fromSequence < 1 || toSequence < fromSequence)
            throw new ArgumentException("The range must be 1 ≤ from ≤ to.", nameof(fromSequence));
        if (string.IsNullOrWhiteSpace(acknowledgedBy) || acknowledgedBy.Length > 256)
            throw new ArgumentException("Say who acknowledges the gap (at most 256 characters).", nameof(acknowledgedBy));
        if (string.IsNullOrWhiteSpace(reason) || reason.Length > MaxCommentLength)
            throw new ArgumentException($"Say why (at most {MaxCommentLength} characters).", nameof(reason));

        await using var db = await factory.CreateDbContextAsync(ct);
        db.AcknowledgedGaps.Add(new AcknowledgedGap
        {
            Direction = direction,
            SequenceRunId = sequenceRunId,
            FromSequence = fromSequence,
            ToSequence = toSequence,
            AcknowledgedUtc = DateTime.UtcNow,
            AcknowledgedBy = acknowledgedBy.Trim(),
            Reason = reason.Trim(),
        });
        try
        {
            await db.SaveChangesAsync(ct);
            return true;
        }
        catch (DbUpdateException ex) when (db.IsDuplicateKey(ex))
        {
            return false;
        }
    }

    /// <summary>
    /// Decision D84: why <paramref name="row"/> must be refused for its number, or null. (1) Another message already has
    /// this number of this counter run and arrived first: a reused number (the sender's bridge database restored from a backup)
    /// or a copy. (2) The number is
    /// at or below the run's watermark and no other row holds it: the message that had it was archived, so this is an old
    /// message shown again, whatever its date. Asked once per row, before it is first Verified: a row checked before (a
    /// re-post, an operator requeue) may itself have moved the watermark.
    /// </summary>
    public async Task<string?> FindSequenceConflictAsync(InboxMessage row, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var others = await db.Inbox.AsNoTracking()
            .Where(m => m.Direction == row.Direction && m.SequenceRunId == row.SequenceRunId && m.Sequence == row.Sequence &&
                        m.MessageId != row.MessageId)
            .Select(m => new { m.MessageId, m.ReceivedUtc })
            .ToListAsync(ct);

        // The first to arrive keeps the number (the same instant: the lower id, so both rows agree on who was first).
        var first = others
            .Where(o => o.ReceivedUtc < row.ReceivedUtc ||
                        (o.ReceivedUtc == row.ReceivedUtc && string.CompareOrdinal(o.MessageId.ToString(), row.MessageId.ToString()) < 0))
            .OrderBy(o => o.ReceivedUtc)
            .FirstOrDefault();
        if (first is not null)
            return $"Sequence number {row.Sequence} of sender run {row.SequenceRunId} is already used by {first.MessageId}, which arrived first " +
                   "(the sender's bridge database restored from an old backup, or a copy of another message).";
        if (others.Count > 0) return null;

        long contiguousTo = await db.SequenceWatermarks.AsNoTracking()
            .Where(w => w.Direction == row.Direction && w.SequenceRunId == row.SequenceRunId)
            .Select(w => w.ContiguousTo)
            .FirstOrDefaultAsync(ct);
        return row.Sequence <= contiguousTo
            ? $"An old message shown again: every number up to {contiguousTo} of sender run {row.SequenceRunId} has already arrived, " +
              $"and the message that had number {row.Sequence} is no longer in the Inbox (archived)."
            : null;
    }

    /// <summary>
    /// Decision D84: moves each run's watermark up through the numbers that arrived and were checked (Verified, or
    /// Rejected) and through acknowledged gaps. A row not checked yet holds it back, so a copy can never raise the
    /// watermark over its own number before its check. Never goes back. Returns how many runs moved.
    /// </summary>
    public async Task<int> AdvanceSequenceWatermarksAsync(Direction direction, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        var marks = await db.SequenceWatermarks.Where(w => w.Direction == direction).ToDictionaryAsync(w => w.SequenceRunId, ct);
        var runs = await db.Inbox.Where(m => m.Direction == direction).Select(m => m.SequenceRunId).Distinct().ToListAsync(ct);
        var acknowledged = await db.AcknowledgedGaps.AsNoTracking().Where(a => a.Direction == direction).ToListAsync(ct);

        int moved = 0;
        foreach (var run in runs)
        {
            marks.TryGetValue(run, out var mark);
            long from = mark?.ContiguousTo ?? 0;
            var arrived = (await db.Inbox.AsNoTracking()
                    .Where(m => m.Direction == direction && m.SequenceRunId == run && m.Sequence > from &&
                                (m.Verified || m.LightStatus == InboxLightStatus.Rejected))
                    .Select(m => m.Sequence)
                    .ToListAsync(ct))
                .ToHashSet();
            var acks = acknowledged.Where(a => a.SequenceRunId == run).ToList();

            long next = from + 1;
            while (true)
            {
                if (arrived.Contains(next)) { next++; continue; }
                var ack = acks.FirstOrDefault(a => a.FromSequence <= next && next <= a.ToSequence);
                if (ack is null) break;
                next = ack.ToSequence + 1;
            }
            if (next - 1 <= from) continue;

            if (mark is null)
                db.SequenceWatermarks.Add(new SequenceWatermark { Direction = direction, SequenceRunId = run, ContiguousTo = next - 1, UpdatedUtc = now });
            else
            {
                mark.ContiguousTo = next - 1;
                mark.UpdatedUtc = now;
            }
            moved++;
        }
        await db.SaveChangesAsync(ct);
        return moved;
    }

    /// <summary>
    /// When anything from the far side last arrived here acceptably (any kind, Heartbeats included), and when its last
    /// Receipt did ("it got ours"). Null when never. For "far side last seen" (decisions D82, D83).
    /// </summary>
    public async Task<(DateTime? LastHeardUtc, DateTime? LastReceiptUtc)> FindLastArrivalsAsync(Direction direction, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var accepted = db.Inbox.Where(m => m.Direction == direction && m.LightStatus == InboxLightStatus.Received);
        DateTime? heard = await accepted.OrderByDescending(m => m.ReceivedUtc).Select(m => (DateTime?)m.ReceivedUtc).FirstOrDefaultAsync(ct);
        DateTime? receipt = await accepted.Where(m => m.Kind == MessageKind.Receipt)
            .OrderByDescending(m => m.ReceivedUtc).Select(m => (DateTime?)m.ReceivedUtc).FirstOrDefaultAsync(ct);
        return (heard, receipt);
    }

    /// <summary>The parts of from–to not covered by any of <paramref name="covered"/>.</summary>
    private static IEnumerable<(long From, long To)> Subtract(long from, long to, IEnumerable<(long From, long To)> covered)
    {
        long next = from;
        foreach (var (f, t) in covered.Where(c => c.To >= from && c.From <= to).OrderBy(c => c.From))
        {
            if (f > next) yield return (next, f - 1);
            next = Math.Max(next, t + 1);
            if (next > to) yield break;
        }
        if (next <= to) yield return (next, to);
    }

    /// <summary>One row of the gap query: Sequence arrived, the numbers after PreviousSequence before it did not.</summary>
    private sealed class GapRow
    {
        public string RunId { get; set; } = "";
        public long PreviousSequence { get; set; }
        public long Sequence { get; set; }
        public DateTime ReceivedUtc { get; set; }
    }

    /// <summary>A final service outcome: no more automatic attempts.</summary>
    private async Task FinishAsync(Guid id, InboxServiceStatus status, int? httpStatus, string comment, string? downstreamResult,
                                   bool verified, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        string? message = Truncate(comment, MaxCommentLength);
        string? result = Truncate(downstreamResult, MaxResultLength);
        await db.Inbox.Where(m => m.MessageId == id).ExecuteUpdateAsync(s => s
            .SetProperty(m => m.ServiceStatus, status)
            .SetProperty(m => m.ServiceHttpStatus, httpStatus)
            .SetProperty(m => m.ServiceComment, message)
            .SetProperty(m => m.ServiceUpdatedUtc, now)
            .SetProperty(m => m.Verified, m => verified || m.Verified)
            .SetProperty(m => m.LockedUtc, (DateTime?)null)
            .SetProperty(m => m.NextAttemptUtc, (DateTime?)null)
            .SetProperty(m => m.DownstreamResult, result)
            // D3, D77: a Done message is never posted or used again, so its body is not kept (plaintext at rest, G-05).
            // MessageHash and PayloadSize stay for reconciliation; a row waiting for an operator keeps its body.
            .SetProperty(m => m.MessageBytes, m => status == InboxServiceStatus.Done ? Array.Empty<byte>() : m.MessageBytes), ct);
    }

    private static string? Truncate(string? s, int max) => s is null || s.Length <= max ? s : s[..max];
}

/// <param name="Light">Rows per LightStatus (every status listed, 0 when none).</param>
/// <param name="Service">Rows per ServiceStatus among the rows that arrived acceptably (LightStatus Received).</param>
/// <param name="OldestUndeliveredUtc">When the oldest request still waiting for delivery (Pending, Delivering, Retrying) arrived; null when none.</param>
public sealed record InboxCounts(
    IReadOnlyDictionary<InboxLightStatus, int> Light,
    IReadOnlyDictionary<InboxServiceStatus, int> Service,
    DateTime? OldestUndeliveredUtc);

/// <summary>Sequence numbers FromSequence–ToSequence of one run never arrived; MissingSinceUtc = when the message after them arrived.</summary>
public sealed record SequenceGap(Direction Direction, Guid SequenceRunId, long FromSequence, long ToSequence, DateTime MissingSinceUtc)
{
    public long Count => ToSequence - FromSequence + 1;
}

/// <summary>A message owed a Receipt since <paramref name="DueUtc"/>; service, operation and label are for operators.</summary>
public sealed record DueReceipt(Guid MessageId, string ServiceName, string Operation, string? BusinessType, DateTime DueUtc);

/// <summary>
/// What <see cref="InboxRepository.AddMessagesAsync"/> did with one bundle: new rows stored, and messages skipped
/// because they were already there (owed a Receipt again) or twice in the bundle.
/// </summary>
public sealed record BundleStoreResult(int Added, int Duplicates);

/// <summary>An earlier Request with the same content that may have reached the service (<see cref="InboxRepository.FindSameContentAsync"/>).</summary>
public sealed record SameContent(Guid MessageId, InboxServiceStatus ServiceStatus, string? DownstreamResult);
