using Microsoft.EntityFrameworkCore;

namespace QrBridge.Shared.Data;

/// <summary>
/// Storage rules applied to every entity in the bridge database, on every engine (SQLite, SQL Server), so the rows,
/// the raw SQL that reads them and the tools look the same everywhere:
/// - enums stored as their names (readable, matches the CHECK constraints)
/// - Guids stored as lower-case "D" text (readable, stable for raw SQL and tooling)
/// - DateTimes always UTC (neither column type keeps a time zone; this restores Kind=Utc on read)
/// </summary>
public static class BridgeConventions
{
    public static void Apply(ModelConfigurationBuilder b)
    {
        b.Properties<Enum>().HaveConversion<string>().HaveMaxLength(32);
        b.Properties<Guid>().HaveConversion<GuidStringConverter>().HaveMaxLength(36);
        b.Properties<Guid?>().HaveConversion<GuidStringConverter>().HaveMaxLength(36);
        b.Properties<DateTime>().HaveConversion<UtcDateTimeConverter>();
        b.Properties<DateTime?>().HaveConversion<UtcDateTimeConverter>();
    }
}
