using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Configurations;

public sealed class JournalArchiveEntryConfiguration : IEntityTypeConfiguration<JournalArchiveEntry>
{
    public void Configure(EntityTypeBuilder<JournalArchiveEntry> b)
    {
        b.ToTable("JournalArchive");
        b.HasKey(x => x.Id);
        b.Property(x => x.Id).ValueGeneratedOnAdd();
        b.Property(x => x.Outcome).IsRequired().HasMaxLength(32);
        b.Property(x => x.SessionId).IsRequired().HasMaxLength(64);
        b.Property(x => x.SenderKeyId).IsRequired().HasMaxLength(256);
        b.Property(x => x.TypeCode).IsRequired().HasMaxLength(64);
        b.Property(x => x.TypeName).IsRequired().HasMaxLength(256);
        b.Property(x => x.Filename).IsRequired().HasMaxLength(1024);
        b.Property(x => x.Sha256).IsRequired().HasMaxLength(128);
        b.Property(x => x.Receipt).IsRequired().HasMaxLength(256);
        b.Property(x => x.StoredPath).HasMaxLength(1024);
        b.Property(x => x.Reason).HasMaxLength(2000);
        b.Property(x => x.Snippet).IsRequired().HasMaxLength(2000);
        b.HasIndex(x => x.ReceivedUtc).IsDescending().HasDatabaseName("IX_JournalArchive_Received");
        b.HasIndex(x => new { x.Outcome, x.ReceivedUtc }).IsDescending(false, true).HasDatabaseName("IX_JournalArchive_Outcome");
    }
}
