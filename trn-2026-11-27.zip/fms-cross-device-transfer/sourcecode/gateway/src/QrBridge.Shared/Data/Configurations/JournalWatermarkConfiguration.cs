using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Configurations;

public sealed class JournalWatermarkConfiguration : IEntityTypeConfiguration<JournalWatermark>
{
    public void Configure(EntityTypeBuilder<JournalWatermark> b)
    {
        b.ToTable("JournalWatermark");
        b.HasKey(x => new { x.SenderKeyId, x.RunId });
        b.Property(x => x.SenderKeyId).HasMaxLength(256);
    }
}
