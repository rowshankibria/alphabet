using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Configurations;

public sealed class JournalTransferConfiguration : IEntityTypeConfiguration<JournalTransfer>
{
    public void Configure(EntityTypeBuilder<JournalTransfer> b)
    {
        b.ToTable("JournalTransfer");
        b.HasKey(x => x.SessionId);
        b.Property(x => x.SenderKeyId).IsRequired().HasMaxLength(256);
        b.Property(x => x.PlaintextSha256).IsRequired().HasMaxLength(128);
        b.Property(x => x.Filename).IsRequired().HasMaxLength(1024);
        b.Property(x => x.Status).IsRequired().HasMaxLength(32);
        b.HasIndex(x => new { x.SenderKeyId, x.PlaintextSha256 }).HasDatabaseName("IX_JournalTransfer_Content");
    }
}
