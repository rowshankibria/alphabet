using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace QrBridge.Shared.Data;

/// <summary>The bridge database on SQL Server. Its migrations are in Data/SqlServer/Migrations.</summary>
public sealed class SqlServerBridgeDbContext(DbContextOptions<SqlServerBridgeDbContext> options) : BridgeDbContext(options)
{
    /// <summary>The application lock every write transaction takes: the bridge's one write lock on this database.</summary>
    public const string WriteLockName = "QrBridge.Write";

    // Waits as long as a SQLite writer may (DefaultTimeout 30 s); not granted -> error 50000, nothing written.
    private const string AcquireWriteLock = $"""
        DECLARE @result int;
        EXEC @result = sp_getapplock @Resource = N'{WriteLockName}', @LockMode = N'Exclusive', @LockOwner = N'Transaction', @LockTimeout = 30000;
        IF @result < 0 THROW 50000, N'The bridge write lock ({WriteLockName}) was not granted within 30 s.', 1;
        """;

    /// <summary>
    /// SQL Server lets transactions overlap, unlike SQLite: an exclusive application lock owned by the transaction
    /// gives the same "one writer at a time" for every bridge write transaction, in every process on every machine
    /// using this database. Released by the commit or rollback.
    /// </summary>
    public override async Task<IDbContextTransaction> BeginWriteTransactionAsync(CancellationToken ct)
    {
        var tx = await Database.BeginTransactionAsync(ct).ConfigureAwait(false);
        try
        {
            await Database.ExecuteSqlRawAsync(AcquireWriteLock, ct).ConfigureAwait(false);
            return tx;
        }
        catch
        {
            await tx.DisposeAsync().ConfigureAwait(false);
            throw;
        }
    }

    public override IDbContextTransaction BeginWriteTransaction()
    {
        var tx = Database.BeginTransaction();
        try
        {
            Database.ExecuteSqlRaw(AcquireWriteLock);
            return tx;
        }
        catch
        {
            tx.Dispose();
            throw;
        }
    }

    /// <summary>2627: primary key or unique constraint; 2601: unique index.</summary>
    public override bool IsDuplicateKey(DbUpdateException ex) =>
        ex.InnerException is SqlException { Number: 2627 or 2601 };
}
