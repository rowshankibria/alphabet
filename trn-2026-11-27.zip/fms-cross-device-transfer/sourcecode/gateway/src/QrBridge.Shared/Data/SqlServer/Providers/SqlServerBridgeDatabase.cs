using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace QrBridge.Shared.Data;

/// <summary>
/// The bridge tables in a SQL Server database (Provider = SqlServer in "GatewayDatabase" / "QRDatabase"). The same tables, columns,
/// conventions and statuses as qrbridge.db; the schema comes from Data/SqlServer/Migrations. Unlike the SQLite file, it
/// can be reached from another machine; the doorbells (named events) cannot, so a program on another machine finds new
/// work by polling (every 2 s) instead of being woken.
/// </summary>
public sealed class SqlServerBridgeDatabase : IBridgeDatabase
{
    private readonly GatewayDatabaseOptions _options;
    private readonly Lazy<DbContextOptions<SqlServerBridgeDbContext>> _readWrite;
    private readonly Lazy<DbContextOptions<SqlServerBridgeDbContext>> _readOnly;

    public SqlServerBridgeDatabase(GatewayDatabaseOptions options, IServiceProvider? applicationServices = null)
    {
        _options = options;
        _readWrite = new(() =>
        {
            var builder = new DbContextOptionsBuilder<SqlServerBridgeDbContext>();
            if (applicationServices is not null) builder.UseApplicationServiceProvider(applicationServices);
            Configure(builder, Required(_options.ConnectionString, "ConnectionString"));
            return builder.Options;
        });
        // The UI's queries: the same connection, not tracked. The UI is read-only because it has no action that writes.
        _readOnly = new(() =>
        {
            var builder = new DbContextOptionsBuilder<SqlServerBridgeDbContext>();
            Configure(builder, Required(_options.ConnectionString, "ConnectionString"));
            return builder.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking).Options;
        });
    }

    public DatabaseProvider Provider => DatabaseProvider.SqlServer;

    public string Description => Describe(_options.ConnectionString);

    public BridgeDbContext CreateContext() => new SqlServerBridgeDbContext(_readWrite.Value);

    public BridgeDbContext CreateReadOnlyContext() => new SqlServerBridgeDbContext(_readOnly.Value);

    public static void Configure(DbContextOptionsBuilder builder, string connectionString) =>
        builder.UseSqlServer(connectionString);

    /// <summary>
    /// Applies the SQL Server migrations; EF creates the database first when it does not exist and the login may create
    /// one (otherwise a DBA creates it empty). EF holds its own migration lock, so the gateway and the QR apps may start
    /// together.
    /// </summary>
    public async Task InitializeAsync(ILogger logger, CancellationToken ct)
    {
        string connectionString = Required(_options.ConnectionString, "ConnectionString");
        if (!string.IsNullOrEmpty(new SqlConnectionStringBuilder(connectionString).Password))
            logger.LogWarning("GatewayDatabase/QRDatabase:ConnectionString contains a password: use Integrated Security (the app pool identity, the kiosk user) instead");

        await using var db = CreateContext();
        await db.Database.MigrateAsync(ct);
        logger.LogInformation("Database {Database} ready (SQL Server)", Description);
    }

    /// <summary>"server / database" of a connection string, without credentials.</summary>
    public static string Describe(string connectionString)
    {
        if (string.IsNullOrWhiteSpace(connectionString)) return "SQL Server (GatewayDatabase/QRDatabase:ConnectionString not set)";
        try
        {
            var parts = new SqlConnectionStringBuilder(connectionString);
            return $"SQL Server {parts.DataSource} / {parts.InitialCatalog}";
        }
        catch (ArgumentException)
        {
            return "SQL Server (GatewayDatabase/QRDatabase:ConnectionString is not a valid connection string)";
        }
    }

    private static string Required(string value, string setting) => string.IsNullOrWhiteSpace(value)
        ? throw new InvalidOperationException($"GatewayDatabase/QRDatabase:{setting} must be set when Provider is SqlServer.")
        : value;
}
