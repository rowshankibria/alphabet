﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace QrBridge.Shared.Data.SqlServer.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AcknowledgedGap",
                columns: table => new
                {
                    Direction = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    SequenceRunId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: false),
                    FromSequence = table.Column<long>(type: "bigint", nullable: false),
                    ToSequence = table.Column<long>(type: "bigint", nullable: false),
                    AcknowledgedUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AcknowledgedBy = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Reason = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AcknowledgedGap", x => new { x.Direction, x.SequenceRunId, x.FromSequence });
                    table.CheckConstraint("CK_AcknowledgedGap_Direction", "Direction IN ('CorpToDmz','DmzToCorp')");
                    table.CheckConstraint("CK_AcknowledgedGap_Range", "FromSequence >= 1 AND ToSequence >= FromSequence");
                });

            migrationBuilder.CreateTable(
                name: "Heartbeat",
                columns: table => new
                {
                    Component = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    LastSeenUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Info = table.Column<string>(type: "nvarchar(1024)", maxLength: 1024, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Heartbeat", x => x.Component);
                });

            migrationBuilder.CreateTable(
                name: "Inbox",
                columns: table => new
                {
                    MessageId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: false),
                    LightStatus = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    ServiceStatus = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    Verified = table.Column<bool>(type: "bit", nullable: false),
                    ReceivedUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ReceiptDueUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DownstreamResult = table.Column<string>(type: "nvarchar(4000)", maxLength: 4000, nullable: true),
                    Direction = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    ServiceName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Operation = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    BusinessType = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    Sequence = table.Column<long>(type: "bigint", nullable: false),
                    SequenceRunId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: false),
                    PayloadFormat = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    Kind = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    CorrelationId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: true),
                    ContentFingerprint = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: true),
                    ExpiresUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Priority = table.Column<byte>(type: "tinyint", maxLength: 32, nullable: false),
                    BundleId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: true),
                    QrSessionId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: true),
                    MessageBytes = table.Column<byte[]>(type: "varbinary(max)", nullable: false),
                    MessageHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    Attempts = table.Column<int>(type: "int", nullable: false),
                    CreatedUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LockedUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    NextAttemptUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LightComment = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: true),
                    ServiceHttpStatus = table.Column<int>(type: "int", nullable: true),
                    ServiceComment = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: true),
                    ServiceUpdatedUtc = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Inbox", x => x.MessageId);
                    table.CheckConstraint("CK_Inbox_Direction", "Direction IN ('CorpToDmz','DmzToCorp')");
                    table.CheckConstraint("CK_Inbox_Kind", "Kind IN ('Request','Receipt','Reply','Heartbeat')");
                    table.CheckConstraint("CK_Inbox_LightStatus", "LightStatus IN ('Received','Rejected')");
                    table.CheckConstraint("CK_Inbox_PayloadFormat", "PayloadFormat IN ('RawSoap','HttpGet')");
                    table.CheckConstraint("CK_Inbox_Priority", "Priority BETWEEN 0 AND 3");
                    table.CheckConstraint("CK_Inbox_ServiceHttpStatus", "ServiceHttpStatus IS NULL OR ServiceHttpStatus BETWEEN 100 AND 599");
                    table.CheckConstraint("CK_Inbox_ServiceStatus", "ServiceStatus IN ('Pending','Delivering','Done','Retrying','Unknown','Refused','Expired','NotDelivered')");
                });

            migrationBuilder.CreateTable(
                name: "Outbox",
                columns: table => new
                {
                    MessageId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: false),
                    LightStatus = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    LightUpdatedUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ServiceStatus = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    PayloadSize = table.Column<int>(type: "int", nullable: false),
                    ReplyContentType = table.Column<string>(type: "nvarchar(max)", maxLength: 4096, nullable: true),
                    ReplyBody = table.Column<byte[]>(type: "varbinary(max)", nullable: true),
                    ReplyCreatedUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Direction = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    ServiceName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Operation = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    BusinessType = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    Sequence = table.Column<long>(type: "bigint", nullable: false),
                    SequenceRunId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: false),
                    PayloadFormat = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    Kind = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    CorrelationId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: true),
                    ContentFingerprint = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: true),
                    ExpiresUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Priority = table.Column<byte>(type: "tinyint", maxLength: 32, nullable: false),
                    BundleId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: true),
                    QrSessionId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: true),
                    MessageBytes = table.Column<byte[]>(type: "varbinary(max)", nullable: false),
                    MessageHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    Attempts = table.Column<int>(type: "int", nullable: false),
                    CreatedUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LockedUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    NextAttemptUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LightComment = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: true),
                    ServiceHttpStatus = table.Column<int>(type: "int", nullable: true),
                    ServiceComment = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: true),
                    ServiceUpdatedUtc = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Outbox", x => x.MessageId);
                    table.CheckConstraint("CK_Outbox_Direction", "Direction IN ('CorpToDmz','DmzToCorp')");
                    table.CheckConstraint("CK_Outbox_Kind", "Kind IN ('Request','Receipt','Reply','Heartbeat')");
                    table.CheckConstraint("CK_Outbox_LightStatus", "LightStatus IN ('Pending','Sending','Aired','Received','Failed')");
                    table.CheckConstraint("CK_Outbox_PayloadFormat", "PayloadFormat IN ('RawSoap','HttpGet')");
                    table.CheckConstraint("CK_Outbox_Priority", "Priority BETWEEN 0 AND 3");
                    table.CheckConstraint("CK_Outbox_ServiceHttpStatus", "ServiceHttpStatus IS NULL OR ServiceHttpStatus BETWEEN 100 AND 599");
                    table.CheckConstraint("CK_Outbox_ServiceStatus", "ServiceStatus IN ('Waiting','Answered','Unknown','Refused','Expired','NotAvailable','NotDelivered','Rejected')");
                });

            migrationBuilder.CreateTable(
                name: "SequenceCounter",
                columns: table => new
                {
                    Direction = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    LastValue = table.Column<long>(type: "bigint", nullable: false),
                    RunId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SequenceCounter", x => x.Direction);
                    table.CheckConstraint("CK_SequenceCounter_Direction", "Direction IN ('CorpToDmz','DmzToCorp')");
                });

            migrationBuilder.CreateTable(
                name: "SequenceWatermark",
                columns: table => new
                {
                    Direction = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    SequenceRunId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: false),
                    ContiguousTo = table.Column<long>(type: "bigint", nullable: false),
                    UpdatedUtc = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SequenceWatermark", x => new { x.Direction, x.SequenceRunId });
                    table.CheckConstraint("CK_SequenceWatermark_ContiguousTo", "ContiguousTo >= 0");
                    table.CheckConstraint("CK_SequenceWatermark_Direction", "Direction IN ('CorpToDmz','DmzToCorp')");
                });

            migrationBuilder.InsertData(
                table: "SequenceCounter",
                columns: new[] { "Direction", "LastValue", "RunId" },
                values: new object[,]
                {
                    { "CorpToDmz", 0L, null },
                    { "DmzToCorp", 0L, null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Inbox_Arrived",
                table: "Inbox",
                columns: new[] { "Direction", "LightStatus", "ReceivedUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_Inbox_ContentFingerprint",
                table: "Inbox",
                columns: new[] { "ContentFingerprint", "ReceivedUtc" },
                filter: "ContentFingerprint IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Inbox_ReceiptDue",
                table: "Inbox",
                column: "ReceiptDueUtc",
                filter: "ReceiptDueUtc IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Inbox_Sequence",
                table: "Inbox",
                columns: new[] { "Direction", "SequenceRunId", "Sequence" });

            migrationBuilder.CreateIndex(
                name: "IX_Inbox_Status",
                table: "Inbox",
                columns: new[] { "LightStatus", "ServiceStatus", "Kind", "Priority", "CreatedUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_Outbox_Bundle",
                table: "Outbox",
                column: "BundleId",
                filter: "BundleId IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Outbox_ContentFingerprint",
                table: "Outbox",
                columns: new[] { "ContentFingerprint", "CreatedUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_Outbox_CorrelationId",
                table: "Outbox",
                column: "CorrelationId");

            migrationBuilder.CreateIndex(
                name: "IX_Outbox_Created",
                table: "Outbox",
                column: "CreatedUtc");

            migrationBuilder.CreateIndex(
                name: "IX_Outbox_LightStatus",
                table: "Outbox",
                columns: new[] { "LightStatus", "Priority", "Sequence" });

            migrationBuilder.CreateIndex(
                name: "IX_Outbox_Sequence",
                table: "Outbox",
                columns: new[] { "Direction", "Sequence" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AcknowledgedGap");

            migrationBuilder.DropTable(
                name: "Heartbeat");

            migrationBuilder.DropTable(
                name: "Inbox");

            migrationBuilder.DropTable(
                name: "Outbox");

            migrationBuilder.DropTable(
                name: "SequenceCounter");

            migrationBuilder.DropTable(
                name: "SequenceWatermark");
        }
    }
}
