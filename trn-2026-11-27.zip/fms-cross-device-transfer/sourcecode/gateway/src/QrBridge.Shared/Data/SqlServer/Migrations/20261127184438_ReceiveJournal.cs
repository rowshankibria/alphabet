﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace QrBridge.Shared.Data.SqlServer.Migrations
{
    /// <inheritdoc />
    public partial class ReceiveJournal : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "JournalArchive",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReceivedUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Outcome = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    SessionId = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    SenderKeyId = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Counter = table.Column<long>(type: "bigint", nullable: false),
                    TypeCode = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    TypeName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    ContentKind = table.Column<int>(type: "int", nullable: false),
                    Filename = table.Column<string>(type: "nvarchar(1024)", maxLength: 1024, nullable: false),
                    Size = table.Column<long>(type: "bigint", nullable: false),
                    Sha256 = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Receipt = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    StoredPath = table.Column<string>(type: "nvarchar(1024)", maxLength: 1024, nullable: true),
                    Reason = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: true),
                    Seconds = table.Column<double>(type: "float", nullable: false),
                    Snippet = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JournalArchive", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "JournalTransfer",
                columns: table => new
                {
                    SessionId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: false),
                    SenderKeyId = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Counter = table.Column<long>(type: "bigint", nullable: false),
                    PlaintextSha256 = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Filename = table.Column<string>(type: "nvarchar(1024)", maxLength: 1024, nullable: false),
                    Size = table.Column<long>(type: "bigint", nullable: false),
                    ReceivedUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JournalTransfer", x => x.SessionId);
                });

            migrationBuilder.CreateTable(
                name: "JournalWatermark",
                columns: table => new
                {
                    SenderKeyId = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    RunId = table.Column<string>(type: "nvarchar(36)", maxLength: 36, nullable: false),
                    Counter = table.Column<long>(type: "bigint", nullable: false),
                    FirstUtc = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JournalWatermark", x => new { x.SenderKeyId, x.RunId });
                });

            migrationBuilder.CreateIndex(
                name: "IX_JournalArchive_Outcome",
                table: "JournalArchive",
                columns: new[] { "Outcome", "ReceivedUtc" },
                descending: new[] { false, true });

            migrationBuilder.CreateIndex(
                name: "IX_JournalArchive_Received",
                table: "JournalArchive",
                column: "ReceivedUtc",
                descending: new bool[0]);

            migrationBuilder.CreateIndex(
                name: "IX_JournalTransfer_Content",
                table: "JournalTransfer",
                columns: new[] { "SenderKeyId", "PlaintextSha256" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "JournalArchive");

            migrationBuilder.DropTable(
                name: "JournalTransfer");

            migrationBuilder.DropTable(
                name: "JournalWatermark");
        }
    }
}
