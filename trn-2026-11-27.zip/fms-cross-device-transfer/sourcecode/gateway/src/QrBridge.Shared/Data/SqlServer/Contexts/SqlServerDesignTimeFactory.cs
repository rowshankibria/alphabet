using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace QrBridge.Shared.Data;

/// <summary>
/// Design-time factory: used only by "dotnet ef migrations ... --context SqlServerBridgeDbContext". Adding a migration
/// does not connect; the connection string only names a placeholder database.
/// </summary>
public sealed class SqlServerDesignTimeFactory : IDesignTimeDbContextFactory<SqlServerBridgeDbContext>
{
    public SqlServerBridgeDbContext CreateDbContext(string[] args)
    {
        var builder = new DbContextOptionsBuilder<SqlServerBridgeDbContext>();
        SqlServerBridgeDatabase.Configure(builder, @"Server=(localdb)\MSSQLLocalDB;Database=QrBridgeDesign;Integrated Security=true");
        return new SqlServerBridgeDbContext(builder.Options);
    }
}