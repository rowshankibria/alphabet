using Microsoft.EntityFrameworkCore;

namespace QrBridge.Shared.Data;

/// <summary>
/// IDbContextFactory&lt;BridgeDbContext&gt; for the repositories: read-write contexts of whichever engine is configured
/// (<see cref="IBridgeDatabase.CreateContext"/>).
/// </summary>
public sealed class BridgeDbContextFactory(IBridgeDatabase database) : IDbContextFactory<BridgeDbContext>
{
    public BridgeDbContext CreateDbContext() => database.CreateContext();

    public Task<BridgeDbContext> CreateDbContextAsync(CancellationToken ct = default) => Task.FromResult(database.CreateContext());
}
