using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using QrBridge.Shared.Data.Configurations;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data;

/// <summary>
/// The one bridge database on each machine, shared by the Gateway and both QR apps. Outbox and SequenceCounter: what
/// this side sends (the Gateway writes, the QR sender airs). Inbox: what arrived from the other side (the QR receiver
/// writes, the Gateway delivers or uses it). Heartbeat, AcknowledgedGap and SequenceWatermark: liveness, gaps an operator
/// has dealt with, and how far each run of the other side's counter is complete. JournalTransfer, JournalWatermark and
/// JournalArchive: the QR Receiver's accepted sessions, its anti-replay watermarks and its archive (written by it only).
///
/// Abstract: every context belongs to one engine (<see cref="SqliteBridgeDbContext"/>, <see cref="SqlServerBridgeDbContext"/>),
/// which has its own migrations and answers the two questions where engines differ: how a write transaction takes the
/// bridge's one write lock, and how a duplicate key shows. Everything else (tables, conventions, queries) is shared.
/// Contexts come from <see cref="IBridgeDatabase"/> (through IDbContextFactory&lt;BridgeDbContext&gt;).
/// </summary>
public abstract class BridgeDbContext(DbContextOptions options) : DbContext(options)
{
    public DbSet<OutboxMessage> Outbox => Set<OutboxMessage>();
    public DbSet<SequenceCounter> SequenceCounters => Set<SequenceCounter>();
    public DbSet<InboxMessage> Inbox => Set<InboxMessage>();
    public DbSet<Heartbeat> Heartbeats => Set<Heartbeat>();
    public DbSet<AcknowledgedGap> AcknowledgedGaps => Set<AcknowledgedGap>();
    public DbSet<SequenceWatermark> SequenceWatermarks => Set<SequenceWatermark>();
    public DbSet<JournalTransfer> JournalTransfers => Set<JournalTransfer>();
    public DbSet<JournalWatermark> JournalWatermarks => Set<JournalWatermark>();
    public DbSet<JournalArchiveEntry> JournalArchive => Set<JournalArchiveEntry>();

    /// <summary>
    /// A transaction that holds the bridge's one write lock from its start until commit or rollback, so a check and the
    /// insert that depends on it (same content queued? room in the backlog? message already in the Inbox?) cannot race
    /// another writer, in this process or another one.
    /// </summary>
    public abstract Task<IDbContextTransaction> BeginWriteTransactionAsync(CancellationToken ct);

    /// <summary>The same, for synchronous callers (the QR Receiver's anti-replay check is synchronous).</summary>
    public abstract IDbContextTransaction BeginWriteTransaction();

    /// <summary>True when a save failed because the row's key (or a unique index) already exists.</summary>
    public abstract bool IsDuplicateKey(DbUpdateException ex);

    protected override void ConfigureConventions(ModelConfigurationBuilder builder) =>
        BridgeConventions.Apply(builder);

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfiguration(new OutboxMessageConfiguration());
        modelBuilder.ApplyConfiguration(new SequenceCounterConfiguration());
        modelBuilder.ApplyConfiguration(new InboxMessageConfiguration());
        modelBuilder.ApplyConfiguration(new HeartbeatConfiguration());
        modelBuilder.ApplyConfiguration(new AcknowledgedGapConfiguration());
        modelBuilder.ApplyConfiguration(new SequenceWatermarkConfiguration());
        modelBuilder.ApplyConfiguration(new JournalTransferConfiguration());
        modelBuilder.ApplyConfiguration(new JournalWatermarkConfiguration());
        modelBuilder.ApplyConfiguration(new JournalArchiveEntryConfiguration());
    }
}