namespace QrBridge.Shared;

/// <summary>
/// The database the gateway and the QR apps on one machine share, and the values that go with it. The gateway reads it
/// from the "GatewayDatabase" section of its appsettings.json, the QR Sender and Receiver from their "QRDatabase"
/// section: the gateway and both QR apps on a machine MUST use the same values.
/// </summary>
public sealed class GatewayDatabaseOptions
{
    /// <summary>The section in the gateway's appsettings.json.</summary>
    public const string GatewaySectionName = "GatewayDatabase";

    /// <summary>The section in the QR Sender's and Receiver's appsettings.json.</summary>
    public const string QrDiodeSectionName = "QRDatabase";

    /// <summary>
    /// The former name of both sections. A settings file that still has it was not updated: its values (Side!) would be
    /// silently replaced by the defaults, so every app refuses to start while it is there.
    /// </summary>
    public const string FormerSectionName = "Bridge";

    /// <summary>Why an app with a former "Bridge" section does not start.</summary>
    public static string FormerSectionProblem(string sectionName) =>
        $"The \"{FormerSectionName}\" settings section was renamed \"{sectionName}\", with Provider and ConnectionString directly " +
        $"inside it (no \"Database\" block): rename it in appsettings*.json (and any {FormerSectionName}__… environment variables).";

    /// <summary>Corp or Dmz.</summary>
    public BridgeSide Side { get; set; } = BridgeSide.Corp;

    /// <summary>
    /// Folder holding the database file (qrbridge.db) when <see cref="Provider"/> is Sqlite. Local disk only — never a
    /// network share.
    /// </summary>
    public string DataFolder { get; set; } = @"C:\ProgramData\QrBridge\Data";

    /// <summary>
    /// Largest message payload (before compression) accepted or decoded. For the gateway this bounds the caller's SOAP
    /// request: anything bigger is refused before it is queued.
    /// </summary>
    public int MaxPayloadBytes { get; set; } = 1_000_000; // 1 MB (1,000,000 bytes, not 1 MiB = 1,048,576)

    /// <summary>The database engine: Sqlite (default: qrbridge.db in DataFolder) or SqlServer.</summary>
    public DatabaseProvider Provider { get; set; } = DatabaseProvider.Sqlite;

    /// <summary>
    /// SqlServer: the one connection to the database (gateway, its UI and the QR apps). Ignored for Sqlite. Never put a
    /// password here: use Integrated Security (the app pool identity, the kiosk user).
    /// </summary>
    public string ConnectionString { get; set; } = "";

    public Direction SendDirection => Side.SendDirection();
    public Direction ReceiveDirection => Side.ReceiveDirection();

    /// <summary>The one database file on this machine (SQLite): Outbox, Inbox, the Receiver's journal and their bookkeeping tables.</summary>
    public const string DatabaseFileName = "qrbridge.db";

    /// <summary>The SQLite file; not used when the provider is SqlServer.</summary>
    public string DatabasePath => Path.Combine(DataFolder, DatabaseFileName);
}