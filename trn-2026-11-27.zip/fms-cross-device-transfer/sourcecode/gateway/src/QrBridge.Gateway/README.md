# QrBridge.Gateway — what every folder and file is for

`QrBridge.Gateway` is the IIS web app that **stands in for the real SOAP/WCF services** while the network is
islanded. One copy runs on each side of the air gap (Corp and DMZ) with the same code and the same `routes.json`;
only `appsettings.{Side}.json` differs.

It has two parts. For every message there is a **Sender** machine (where the caller is) and a **Receiver** machine
(where the real service is). The gateway's **Sender part** lives in `Ingress/`, its **Receiver part** in `Egress/`.

```
SENDER machine                                                         RECEIVER machine
Caller ─► Sender part ─► qrbridge.db Outbox ─► QR Sender ~~~► QR Receiver ─► qrbridge.db Inbox ─► Receiver part ─► real service
          (Ingress/)                                                                            (Egress/)
```

| Part | Data flow | Where in the code |
|---|---|---|
| **Sender part**: accept a caller's SOAP call, save it, reply like the real service (at once, or after holding the caller for the far side's answer) | caller → Outbox → QR Sender; the far side's Receipts and Replies → Inbox → held caller | `Controllers/`, `Ingress/` (+ `Ingress/Validation/`, `Ingress/Soap/`), `Routing/` |
| **Receiver part**: replay calls that arrived over the QR link to the real service on this machine, then send back a Reply (every final outcome) and a Receipt (every arrived message) through this machine's Outbox | QR Receiver → Inbox → real service; Replies and Receipts → Outbox → back over the opposite lane | `Egress/` (+ `Egress/Workers/`) |

Which gateway is the Sender depends on the interface: for **Inbound** (Corp → DMZ) the Corp gateway is the Sender
and the DMZ gateway the Receiver; for **Outbound** (DMZ → Corp) it is the other way round. `SenderSide` in
`routes.json` names the Sender machine of each service. Details: [direction and local roles](../../docs/reference/gateway-code-walkthrough.md#direction-and-local-roles).

The QR apps (`QrDiode.Sender` / `QrDiode.Receiver`) move messages over the light, from one machine's Outbox to the
other machine's Inbox. The gateway never talks to them directly: they share only one SQLite file in `GatewayDatabase:DataFolder`
(default `C:\ProgramData\QrBridge\Data\qrbridge.db`, tables Outbox and Inbox among others) and two named "doorbell"
events. Each machine has its own `qrbridge.db`.

> **Angular comparison:** `Program.cs` is like `main.ts` + `app.config.ts` (providers = dependency injection).
> `Controllers/` holds two thin controllers — one wildcard route `**` for every SOAP POST, and `/health` —
> like a router config whose component immediately calls a service (`SenderEndpoint`).
> `routes.json` decides per service what the wildcard route does, without writing a controller per service.

---

## The life of one call

```
Load balancer ──POST /FMS_FC2FMSInterface/FC2FMSInterface.svc──▶ IIS (web.config) ──▶ Controllers/SenderSoapController  [Route("{**path}")] [HttpPost]
   ▶ Ingress/SenderEndpoint.HandleAsync
       1. read the body (size cap)                          GatewayDatabase:MaxPayloadBytes, or the route's smaller MaxRequestBytes → 413
       2. parse the SOAP envelope                           Ingress/Soap/SoapRequest.TryParse (via SafeXml)
       3. look up service + operation                       Routing/RouteTable.Resolve  (routes.json)
       4. read MESSAGE TYPE for the allow-list              Ingress/Soap/PayloadInspector
       5. Bridge/RoundTrip → check against the WSDL         Ingress/Validation/ContractCatalog.Check  (Contracts/)
       6. Bridge/RoundTrip → pack + INSERT + commit         Ingress/OutboxWriter.EnqueueAsync → Outbox  (a RoundTrip retry is attached instead)
       7. Bridge → reply like the real service at once      Ingress/Soap/SoapReplyWriter (+ ReplyProfile from routes.json)
          RoundTrip → HOLD the caller (Gateway:Hold)        SenderEndpoint.HoldAsync + Ingress/WaiterRegistry: the far side's real
                                                            answer, or on time-out 1596 "pending" (permits, orders, cards) / "not available" (queries)

Load balancer ──GET /FMS_ReportService/RegisteredTags.asmx/GetData──▶ SenderSoapController [HttpGet] ▶ SenderEndpoint.HandleGetAsync
       only a route marked "HttpGet": true on this side (Registered Tags, Corp; step 12, D18) — any other GET or HEAD: 405
       query string → 400; else an empty PayloadFormat.HttpGet Request → OutboxWriter → HOLD → the real answer
       (status, Content-Type, body) or HTTP 504 text/plain

... QR Sender airs it ... QR Receiver on the other side writes it into the Inbox of that side's qrbridge.db ...

Other side's gateway:
   Egress/Workers/InboxWorker  one delivery loop per class (High, Normal, Low): claim a row of its class →
                        checksum + unpack + verify → Egress/SoapForwarderHttpClient.ForwardAsync → real service
                        → Egress/AnswerWriter: Reply into this side's Outbox FIRST, then the row:
                          service Done / Refused / Unknown / Expired / NotDelivered, or light Rejected (Retrying: no Reply yet)
   Egress/Workers/ReceiptWorker  a Receipt into this side's Outbox for every arrived message
   (both go back over the opposite lane like any Outbox row)

First side's gateway again:
   Ingress/AnswerReader  reads arrived Receipts and Replies (Egress/ArrivalChecks first) → the Outbox row's light / service
                         status and the real answer → wakes the held caller (WaiterRegistry)

Both sides, when idle:
   Egress/FarSideMonitor  (called by MaintenanceWorker) an empty Heartbeat message after Gateway:HeartbeatMinutes with
                          nothing queued; "far side silent" after Gateway:FarSideSilentMinutes with nothing heard
```

Built and tested with two gateways in one test (the bytes copied between them, or carried by a fake light in the step 13
fault tests). Not yet over real light: the QR apps
do not read the Outbox or write the Inbox yet, so on real hardware every RoundTrip caller waits the full hold and gets
the hold-timeout answer.

---

## Files in the project root

| File | Purpose |
|---|---|
| `Program.cs` | Start-up, about 20 lines: one call per step (settings, data, route catalogue, endpoints, Sender part, Receiver part, workers, startup checks, map endpoints). The steps are in `Initializer/`. |
| `routes.json` | **The route catalogue**: the services this gateway stands in for. Per service: `Name`, `SenderSide` (which gateway receives the callers), `Paths` (as sent by the load balancer), `Style` (Document or Rpc), `Contract` (WSDL folder under `Contracts/`), and per operation a `Mode` (`Bridge`, `RoundTrip`, `Echo`, `Unavailable`, `Reject`), `Reply` profile, `AllowedTypes`, `OnHoldTimeout` (`Pending` 1596 / `Unavailable`), `FingerprintIgnore` and `Types` (the same settings per MESSAGE TYPE). `RoundTrip` holds the caller for the far side's real answer (`Gateway:Hold`): permits, orders, cards and their responses use it with `OnHoldTimeout: Pending` (1596 "sent, confirmation not yet received", D60), queries with `Unavailable`; feeds (FMS2FSS, FMS2Dashboard, FMS2SSLog, FMS2VR, FTC2FMS(-Legacy) `SendToFMS`, VZ2TLS) stay `Bridge` (answered at once). A RoundTrip + Pending route recognises a caller's retry by default (attached to the first message, D56). `ReplyProfiles` holds the reply texts (Ok, Busy 1598, Unavailable 1599, Pending 1596, Rejected 1597; `PortalSyncDown` for `PortalSyncRequest`); `FingerprintIgnore` the fields left out of the content fingerprint (step 8). The same file must be deployed on both sides: every message carries its fingerprint, and the receiving gateway rejects a message from a sender with a different one. A service with `"HttpGet": true` is a plain HTTP GET interface, not SOAP (`RegisteredTags`, step 12, D18): one path, no `Contract`, one operation `"GET"` (RoundTrip or Unavailable, `OnHoldTimeout: Unavailable`), no reply profile; start-up checks the shape (`RouteTable.CheckHttpGet`). Optional since 25 Nov 2026: `Priority` (`High`/`Normal`/`Low`) on an operation or a type, to override the route's default class (step 14; `Answer` refused; none set today), and per service `MaxRequestBytes` (bigger calls get 413) and `MaxBacklog` (that service's Requests waiting to cross before 1598) (step 16; values ≤ 0 refused). `MaxRequestBytes` is set to 10 × the largest simulator template on 11 routes (D78; not verified against real sizes); no `MaxBacklog` is set. New or changed services are configuration here, not code. |
| `appsettings.json` | Base settings for both sides: logging, `Bridge` (Side, **`DataFolder` = where the SQLite files live**, `MaxPayloadBytes`) and `Gateway` (backlog, retry window, worker timings, `Hold` = how long a RoundTrip caller is held, `Expiry` = how long a state-changing RoundTrip call may still be posted (600 s, D62), `ReceiptTimeoutSeconds` (120) and `MaxAirAttempts` (3) = re-air of unconfirmed Outbox rows, `Light` = the QR link's assumed speed for the start-up air-time warning (6,700 bytes/s, 6 s, 1.5 s; D79, not measured), `HeartbeatMinutes` (5) and `FarSideSilentMinutes` (15) = idle Heartbeat messages and when the far side counts as silent (D81, D82; same on both sides), `Receiver` = where the Receiver part delivers, with `UseDefaultCredentials` globally and per target). |
| `appsettings.Corp.json` | Overrides for the CorpNet gateway: `Side = Corp`, `Hold` 270 s, `Expiry` 600 s, Receiver part delivers to the corporate systems (still empty: see "Known gaps"). |
| `appsettings.Dmz.json` | Overrides for the ECC/AECC DMZ gateway: `Side = Dmz`, `Hold` 90 s, `Expiry` 600 s, `Receiver:DefaultBaseUrl` = the DMZ Rapid Restore servers. |
| `web.config` | IIS hosting: sends **every** path (including `*.svc`, `*.asmx`, `*.wsdl`) to ASP.NET Core in-process, sets `ASPNETCORE_ENVIRONMENT` (`Corp` or `Dmz`, which picks the appsettings file), gives workers 60 s to finish on recycle, and warms the app at boot through `/health` (Application Initialization). |
| `QrBridge.Gateway.csproj` | Project file: `net10.0-windows`, IIS in-process hosting, references `QrBridge.Shared`, copies `routes.json` and `Contracts/` (WSDL/XSD) to the output and publish folders, and exposes internals to `QrBridge.Tests`. |
| `Contracts/` | The real services' WSDLs (+ XSDs), one folder per route under `Inbound/` (Corp → DMZ, callers on CorpNet) or `Outbound/` (DMZ → Corp, callers in the DMZ). Read at startup to check each `Bridge` call before it is queued; **never served**. Sources in `Contracts/README.md`. |
| `README.md` | This file. |

## `Initializer/` — start-up, one step per file

`Program.cs` only calls these, in order. Each is a static class with one extension method.

| File | Purpose |
|---|---|
| `OptionsRegistration.cs` | `AddGatewayOptions()`: loads `routes.json`, binds the `Bridge`, `Gateway` and `Routing` settings. |
| `DataRegistration.cs` | `AddGatewayData()`: EF Core on the configured engine (`AddBridgeData`: `IBridgeDatabase`, the repositories by their interfaces), the message serializer, the doorbells (`BridgeSignals`). |
| `RouteCatalogRegistration.cs` | `AddRouteCatalog()`: `RouteTable` and `ContractCatalog` (the WSDLs in `Contracts/`). |
| `EndpointRegistration.cs` | `AddGatewayEndpoints()` / `MapGatewayEndpoints()`: the controllers (`POST {**path}`, `GET {**path}` for an `HttpGet` route only, `GET /health`). |
| `SenderRegistration.cs` | `AddSenderPart()`: `RetryCounters`, `OutboxWriter`, `WaiterRegistry` (held callers), `SenderEndpoint`, and the hosted `AnswerReader` (Receipts and Replies for this side's messages, and the far side's Heartbeats). |
| `ReceiverRegistration.cs` | `AddReceiverPart()`: `SoapForwarderHttpClient` and its three named HttpClients (`receiver` = `Gateway:Receiver:UseDefaultCredentials`, `receiver-default-credentials`, `receiver-anonymous`; D75), each a `SocketsHttpHandler` with `ConnectTimeout` = `Gateway:Receiver:ConnectTimeoutSeconds` and no redirects, `ArrivalChecks` (checks every message from the light, whatever its kind) and `AnswerWriter` (Receipts and Replies over the opposite lane). |
| `WorkerRegistration.cs` | `AddBackgroundWorkers()`: `SequenceGapMonitor`, `FarSideMonitor`, and the hosted `InboxWorker`, `ReceiptWorker` and `MaintenanceWorker`; shutdown timeout; worker errors never stop the endpoints. |
| `StartupChecks.cs` | `RunStartupChecksAsync()`: **refuses to start** when `LockTimeoutMinutes` is not longer than every receiver timeout, `Receiver:ConnectTimeoutSeconds` is zero or less or not shorter than every receiver timeout, `ReplayWindowDays`, `MaxClockSkewMinutes` or `RetryWindowMinutes` is zero or less, `GapGraceMinutes` is below zero, `ReceiptTimeoutSeconds` or `MaxAirAttempts` is zero or less, `Hold:DefaultSeconds` or a `Hold:Services` override is not positive or names a service with no callers on this side, `Expiry:DefaultSeconds` or an `Expiry:Services` override is not positive, names a service with no callers on this side, or is not longer than that service's hold (D62), a Receiver URL is not an absolute http(s) URL or is plain `http://` outside Development without `Receiver:AllowHttp`, `Light:BytesPerSecond` is zero or less or `Light:MinAirSeconds` / `GapSeconds` negative, `HeartbeatMinutes` is below zero, `FarSideSilentMinutes` is zero or less or not longer than `HeartbeatMinutes`, the route catalogue is invalid (including `"Priority": "Answer"` or a `MaxRequestBytes` / `MaxBacklog` ≤ 0), or a WSDL contract is missing or lacks an operation; warns about routes without a contract, and (`AirTimeWarnings`, D79) about each RoundTrip route on this side whose size limit takes longer to air than its hold, and (`AdministratorWarning`, D4, step 18) when the gateway process runs as an administrator (it still starts: use a dedicated app pool identity); creates or opens the bridge database (`DatabaseProblem` first: with `GatewayDatabase:Provider` = SqlServer it **refuses to start** without `ConnectionString`; then `DatabaseInitializer` through the configured engine — SQLite **refuses to start** while a former `send.db` or `received.db` is in the data folder: they may hold undelivered messages); logs the start-up line with where the data is (`Database=…`) and the catalogue fingerprint (`Catalogue=…`). |

## `Configurations/` — settings classes, enums and shared helpers

Everything here is in the project's root namespace `QrBridge.Gateway`, so the rest of the code uses it without an extra `using`.

| File | Purpose |
|---|---|
| `Options/GatewayOptions.cs` | **The `Gateway` settings section, in one file:** `GatewayOptions` (`MaxBacklog`, `RetryWindowMinutes` (30: same content within it = a caller's retry), Inbox worker retry/backoff, replay window, maintenance, `GapGraceMinutes` for the lost-message check, `ReceiptTimeoutSeconds` (120) and `MaxAirAttempts` (3) for re-airing unconfirmed Outbox rows, `HeartbeatMinutes` (5; 0 = off) and `FarSideSilentMinutes` (15) for the far-side check; no retention: rows are never deleted automatically), `HoldOptions` (`Gateway:Hold`: how long a RoundTrip caller is held, D11 — Corp 270 s, DMZ 90 s), `ExpiryOptions` (`Gateway:Expiry`: how long after it was sent a state-changing RoundTrip call may still be posted, D62 — 600 s on both sides; queries expire with their hold, `Bridge` calls never), `LightOptions` (`Gateway:Light`: the QR link's assumed speed, only for the start-up air-time warning, D79), `ReceiverOptions` (`Gateway:Receiver`: where the Receiver part delivers arriving messages — `DefaultBaseUrl` + the caller's path, or `Targets[service].Url` — `AllowHttp` for test benches, timeouts, credentials (`UseDefaultCredentials`: app pool identity or anonymous; never a password), response size cap) and `ReceiverTarget` (one per-service target; its optional `UseDefaultCredentials` overrides the global one, D75). |
| `Options/RoutingOptions.cs` | **The shape of `routes.json`, in one file:** `RoutingOptions` (the catalogue), `ServiceRoute` (one service; optional `MaxRequestBytes`, `MaxBacklog`), `OperationRoute` (one operation; optional `Priority`), `ReplyProfile` (one set of reply texts). Properties only; `Routing/RouteTable.cs` does the work. |
| `Enums/Enums.cs` | **All the gateway's enums**: `SoapVersion` (Soap11/Soap12), `OperationMode` (Bridge/RoundTrip/Echo/Unavailable/Reject), `HoldTimeoutAnswer` (Pending/Unavailable), `MessageStyle` (Document/Rpc), `ResultKind` (None/FmsResponse/ReturnCode), `DeliveryVerdict` (Delivered/Refused/Permanent/Unknown/Transient). |
| `Helpers/Utility.cs` | Static helpers used across the gateway: **`SafeXml`** (the only way untrusted XML is loaded: DTDs prohibited, no resolver, size caps) `SoapNamespaces` (SOAP 1.1/1.2 and WS-Addressing namespace URIs, content types) and `XmlHelpers` (`ChildElement`, `FirstChildElement`: find a child element, used when reading requests, payloads and the real services' replies). |

## `Properties/`

| File | Purpose |
|---|---|
| `launchSettings.json` | Local development profiles only (not deployed). **Gateway (Corp)** on `http://localhost:5080` and **Gateway (Dmz)** on `http://localhost:5090`, each with its own dev data folder (`C:\QrBridgeDev\{Corp,Dmz}\Data`). The DMZ profile delivers to `http://localhost:5099`. |

## `Exceptions/` — exceptions that mean something to the Gateway-to-QrDiode system

| File | Purpose |
|---|---|
| `BridgeBacklogFullException.cs` | Thrown by `OutboxWriter` when the Outbox is full; `SenderEndpoint` then gives the caller the Busy reply. |
| `BridgeRejectException.cs` | Thrown in `InboxWorker` (validate/plan): the Inbox row gets the light status **Rejected** (reason in `LightComment`) and is never retried. |
| `PermanentFailureException.cs` | Thrown in `InboxWorker` when a message can never be delivered as configured (e.g. no receiver target): straight to service status **NotDelivered** (it never reached the service; an operator may resend it). |

## `Controllers/` — the HTTP entry points (start here)

| File | Purpose |
|---|---|
| `SenderSoapController.cs` | `[Route("{**path}")] [HttpPost]`: **every SOAP call**, whatever the path. One line: hands the request to `SenderEndpoint.HandleAsync`. `[HttpGet]` (step 12): hands a GET to `SenderEndpoint.HandleGetAsync`, which answers only for a route marked `HttpGet` on this side (Registered Tags on Corp) and gives every other GET 405. |
| `HealthController.cs` | `GET /health`: the light and service counts of both queues (each with its oldest undelivered row), `catalogFingerprint` (compare both sides), `missingMessages` and up to 20 `gaps` (cached by `SequenceGapMonitor`, not queried per probe), `retries` (attached / same content queued again, since start-up), `lightProblems` (Outbox Failed + missing messages), `serviceProblems` (Inbox Unknown + Refused + NotDelivered), `farSide` (`lastHeardUtc`, `lastReceiptUtc`, `silent`, `silentAfterMinutes`; from `FarSideMonitor`), component heartbeats and a `healthy` flag as JSON (false also when the far side is silent, D83). The gateway's health probe: point the load balancer's health probe here. The only other GET answered is an `HttpGet` route on its own side (Registered Tags on Corp, via `SenderSoapController`); any other GET, and every HEAD, gets HTTP 405 — the gateway serves no WSDL or help pages, because the callers (as the fms-interface-simulator shows) use compiled proxies and never download them. |

The SOAP controller is deliberately **thin and not `[ApiController]`**: no parameters are bound, so MVC never
parses the body (it must stay raw bytes for the byte-for-byte replay) and never answers with a JSON error (callers
expect SOAP faults). Put SOAP logic in `Ingress/`, not here.

## `Ingress/` — the Sender part: calls coming in from the load balancer

| File | Purpose |
|---|---|
| `SenderEndpoint.cs` | **Handles every SOAP POST** (called by `SenderSoapController`). Reads the body with a size cap (`GatewayDatabase:MaxPayloadBytes`, or the route's smaller `MaxRequestBytes`: HTTP 413 before anything is parsed), parses it, resolves the route, then by mode: `Reject` → SOAP fault; `Echo` → returns the input (EchoString checks); `Unavailable` → "not available while islanded" reply; `Bridge` and `RoundTrip` → checks the request against the service's WSDL (`ContractCatalog`, SOAP fault if it does not match), checks `AllowedTypes`, builds a `MessageHeader` (service, operation, path, SOAPAction, Content-Type, label, content fingerprint, the route's `Priority` class, `CallerHost` = `CallerHostOf`: the first `X-Forwarded-For` address labelled with the connection's, else the connection's, D76; for RoundTrip an `ExpiresUtc`: the hold for a query (D54), `Gateway:Expiry` for a state-changing call (D62)), calls `OutboxWriter.EnqueueAsync(header, unchanged body, RecogniseRetries)`, and **only after the commit** answers. `Bridge`: Ok at once (or HTTP 202 for one-way). `RoundTrip`: **holds** the caller (`HoldAsync`, `Gateway:Hold`) until the far side's Reply is stored — Answered/Refused → the real answer byte for byte; Unknown → the hold-timeout answer; Expired/NotDelivered/Rejected → "not available" — or the hold runs out (`OnHoldTimeout`: `Pending` = 1596, `Unavailable` = "not available"); a message whose light status is `Failed` gets the hold-timeout answer at once. An attached retry waits for the same message and gets the same answer. Adds the `X-QrBridge-MessageId` header. If the save fails, the caller is told the call was not accepted; if the caller hangs up while held, the message stays queued. A SOAP POST to an `HttpGet` route's path gets a SOAP fault ("plain HTTP GET interface"), nothing queued. **`HandleGetAsync`** (step 12, D18, D69–D72): the plain GET of Registered Tags. A query string → HTTP 400, nothing queued (D71). Otherwise it queues a Request with `PayloadFormat.HttpGet` (empty body, empty Content-Type, no SOAPAction, no content fingerprint, so never attached to an earlier call; `ExpiresUtc` = now + hold, D54), holds the caller for `Gateway:Hold` (Corp 270 s, D70), and returns the real answer (HTTP status, Content-Type, body; no other header) when the far side's service answered (Done or Refused) in time; otherwise HTTP 504 text/plain "RegisteredTags is not available while the network is islanded: …" (D69) — hold ran out, Unknown, NotDelivered, Expired, Rejected, answer too large to carry back, Outbox full. |
| `OutboxWriter.cs` | **Queues a message — the one way into the Gateway-to-QrDiode system**: callers' Requests (from `SenderEndpoint`) and this side's Receipts and Replies (from `Egress/AnswerWriter`). It decides the rules and builds the row; the storage is `IOutboxRepository.InsertAsync`, one write transaction holding the bridge's write lock (SQLite: one writer at a time for the whole file; SQL Server: an exclusive application lock, decision 55). It never opens the database itself. For a **Request** only: first looks for a Request with the same **content fingerprint** created within `Gateway:RetryWindowMinutes` (decision D5), leaving out one the far side surely did not carry out (service status `Expired`, `NotDelivered` or `Rejected`, D63: that call is queued again as a new message with a fresh expiry): on a route that recognises retries (`RecogniseRetries`, D37; RoundTrip + Pending by default, D56) the call is **attached** to that message — nothing is queued, `EnqueueResult.Attached` — even when the backlog is full; on other routes it is queued again and counted (`RetryCounters`). Then checks the backlog (`MaxBacklog`: `Kind = Request` rows with light `Pending` + `Sending` + `Aired`, decision D47; then the service's own `MaxBacklog` from `routes.json` when set, step 16) inside the same transaction so simultaneous calls can't overfill the queue. Receipts and Replies skip both checks: never refused for a full Outbox, never counted; they get the priority class `Answer`, so the QR Sender airs them first. For every kind it then takes the next sequence number and the counter's run id (`SequenceCounter`), adds them and the catalogue fingerprint to the header, packs the message (Brotli + checksum; not encrypted — QrDiode encrypts the QR link), inserts an `OutboxMessage` row with light status `Pending` and service status `Waiting`, commits, then signals the Outbox doorbell so the QR Sender wakes up. Nothing else may write to the Outbox. `EnqueueResult` (the message id, attached or not) is in the same file. |
| `RetryCounters.cs` | Since start-up: retries **attached** (no new row) and calls with the same content **queued again** on a route that does not recognise retries. Shown on `/health` (`retries`); an attach leaves no row, so this and the log line are its only trace. |
| `AnswerReader.cs` | **The Sender part's end of the round trip** (V6 fix step 10a), a hosted service polling the Inbox every `Gateway:InboxPollSeconds`. Reads the **Receipts** and **Replies** the far side sent back for this side's messages, after the same checks as any arrived message (`Egress/ArrivalChecks`), and checks that each answers a message this side sent (same service and operation). Receipt → the Outbox row's light status `Received`. Reply → its service status (Answered, Refused, Unknown, Expired, NotDelivered, Rejected), comment and the real answer (`OutboxRepository.MarkAnsweredAsync`; a later Reply after an operator requeue replaces the stored one unless that is `Answered`, by `ReplyCreatedUtc`, D59), then wakes the callers held for it. A **Heartbeat** from the far side (step 17) → Inbox `Done` ("the far side is alive"); a Receipt or Reply naming a Heartbeat is `Rejected`. The Inbox row ends `Done`, or `Rejected` when a check fails. Nothing here is posted to a service. |
| `WaiterRegistry.cs` | The held RoundTrip callers, by the MessageId they wait for (several when retries are attached). `AnswerReader` calls `Wake` after storing a Reply. Only a speed-up: a held caller also re-reads its Outbox row every 2 s. In memory, so the IIS app pool must run **one** worker process (no web garden). |
| `Waiter.cs` | One held caller in the `WaiterRegistry`; disposed when the call ends, however it ends. |
| `Soap/ContentFingerprint.cs` | The **content fingerprint** of a call (D5, D38): SHA-256 of service, operation, MESSAGE TYPE, the SOAP operation element as received and its payload, with the route's `FingerprintIgnore` names (`MSG_ID`, `GMT_TIME_SENT`, `RRMsgID`) removed wherever they are an attribute or element. Whitespace kept, SOAP headers left out. Parses its own copy with `SafeXml` (never changes the body); null when the payload cannot be read safely (such a call is never attached). |

### `Ingress/Validation/` — requests checked against the real WSDL

| File | Purpose |
|---|---|
| `ContractCatalog.cs` | Built at startup: loads `Contracts/{direction}/{Contract}/` (direction from the route's `SenderSide`) for every route that names one and refuses to start if a contract is missing, invalid, or lacks an operation the route lists. `Check(service, request)` is called by `SenderEndpoint` for `Bridge` and RoundTrip calls. |
| `ServiceContract.cs` | One WSDL 1.1 (+ its XSDs) reduced to what a check needs. Document/literal: Body element name and namespace, then XSD validation (e.g. `SendToFMS` with one optional `sXML` string). RPC/encoded: operation namespace and exactly the WSDL parts (`XMLMsg`), unqualified. Also the SOAP version (`basicHttpBinding` = 1.1 only). Nothing external is resolved. The file also holds its records `ContractOperation` (one operation's request shape) and `ContractPart` (one RPC part). |

### `Ingress/Soap/` — SOAP work only the Sender part needs

Only the Sender part reads SOAP requests and writes replies (namespace `QrBridge.Gateway.Ingress.Soap`).

| File | Purpose |
|---|---|
| `SoapRequest.cs` | Parses **any** SOAP request (1.1/1.2, document or RPC, with or without WS-Addressing) into what the gateway needs: version, operation name (first element in the Body), its namespace, first parameter text, SOAPAction, addressing headers (its record `AddressingInfo`, same file). `SafeXml` and `SoapNamespaces` are in `Configurations/Helpers/Utility.cs`. |
| `PayloadInspector.cs` | Looks inside the single string parameter (e.g. `sXML`) and reads its label: FMS `<MESSAGE TYPE="…" MSG_ID="…">`, a nested SOAP envelope's Body element, or the root element name. Used for the `AllowedTypes` allow-list, the `{BusinessType}`/`{MsgId}` reply placeholders and logs. The payload itself is never changed. Returns its record `BusinessInfo` (same file). |
| `SoapReplyWriter.cs` | Builds the replies WCF/ASMX/SOAP Toolkit clients accept: `<OpResponse><OpResult>value</OpResult>` (document) or `<m:OpResponse><Result>` (RPC), an empty response, HTTP 202, or a SOAP fault, in the request's SOAP version and with WS-Addressing `RelatesTo` when needed. Returns its record `SoapReply` (status code, content type, body; same file). |

## `Routing/` — the route catalogue in code

| File | Purpose |
|---|---|
| `RouteTable.cs` | Validates and indexes the catalogue once at startup: the app refuses to start on duplicate names or paths, or unknown reply profiles. `NormalizePath` makes paths case-insensitive and drops queries and extra slashes. `Resolve(path, operation, type)` returns a `RouteDecision`: which service, which mode (the operation's, or its MESSAGE TYPE's under `Types`), which reply profile, one-way or not, `OnHoldTimeout`, the `FingerprintIgnore` fields, and why the call is refused; `ModeOf` gives the receiving side the same mode. It also refuses calls arriving at the wrong side's gateway. It also refuses to start on round-trip settings that could not give their answer (`Pending` without a profile value, `OneWay`, type modes other than Bridge/RoundTrip/Unavailable, `Types` outside `AllowedTypes`), and on an `HttpGet` service that breaks its rules (`CheckHttpGet`: exactly one path, no `Contract`, `OtherOperations` Reject, exactly one operation `"GET"` with Mode RoundTrip or Unavailable, `OnHoldTimeout` Unavailable, `RecogniseRetries` off, no reply profile, `OneWay`, `AllowedTypes` or `Types`). `CatalogFingerprint`: SHA-256 of the services, reply profiles and `FingerprintIgnore` list (not `AcceptUnlisted`/`UnlistedOneWay`), computed once; it goes in every message header. `SettingsOf` (step 14, D73) gives an operation's settings with its message type's on top, including its priority class: `High` for RoundTrip with `OnHoldTimeout: Pending`, `Normal` for RoundTrip queries, `Low` for `Bridge`, unless `routes.json` sets `Priority`; start-up refuses `Priority: Answer` and a `MaxRequestBytes` / `MaxBacklog` ≤ 0. `RouteDecision`, the record it returns, is in the same file. |

## `Egress/` — the Receiver part: delivering arrived calls to the real service

| File | Purpose |
|---|---|
| `AnswerWriter.cs` | **The Receiver part's answers over the opposite lane** (V6 fix step 9b, decisions D43–D46). Writes into **this side's** Outbox through `OutboxWriter`; nothing posts them to a service. `FinishAsync` ends a Request: **first** a **Reply** (`Kind = Reply`, `CorrelationId` = the Request's id, `Outcome`, `ServiceHttpStatus`, `ServiceComment` in plain words, the real service's answer byte for byte with its Content-Type — left out, and the comment says so, when over `GatewayDatabase:MaxPayloadBytes`), **then** the Inbox row is marked with the same outcome. Used for every final outcome: Done, Refused, Unknown, Expired, NotDelivered and Rejected. `RecoverStuckAsync` (called by `MaintenanceWorker`) settles rows still `Delivering` after a crash: the outcome of the Reply already written **for this attempt** (`OutboxRepository.FindLastReplyToAsync`, only when written after the row's current claim, D64: a Reply from before an operator's requeue is not adopted), or `Unknown` with an Unknown Reply; never posted again. `ReuseDoneAsync` (layer 3b, D58, step 10b): a Request whose same content was already `Done` on this side within the retry window is not posted; it ends `Done` with that earlier request's last Reply, answer included. `SendDueReceiptsAsync` (called by `ReceiptWorker`) writes a **Receipt** (`Kind = Receipt`, `CorrelationId` = the arrived message, empty body) for up to 100 rows owed one (`ReceiptDueUtc`), then clears their due time. |
| `ArrivalChecks.cs` | The checks **every** message from the light passes before it is used, whatever its kind (step 10a): header matches the Inbox row (MessageId, service, operation, kind, correlation, run id, fingerprint, expiry, priority), same catalogue fingerprint, direction, payload format (`RawSoap` or `HttpGet`), replay window, clock skew; on the row's **first** check only (step 17, D84), its sequence number is not already held by another message that arrived earlier (a restored or copied `qrbridge.db` on the sending side) and not at or below the run's `SequenceWatermark` with no row holding it (an archived message shown again), whatever its date. All passed → the row is marked `Verified`. `CheckAsync` (async since step 17). Used by `InboxWorker` (Requests) and `Ingress/AnswerReader` (Receipts, Replies, Heartbeats). A failure throws `BridgeRejectException`: the row is `Rejected`. |
| `FarSideMonitor.cs` | **Is the far side still there?** (G-16, decisions D80–D83, step 17.) `SendHeartbeatIfIdleAsync` queues an empty **Heartbeat** message through `OutboxWriter` when this side has queued nothing for `Gateway:HeartbeatMinutes` (counted from start-up at the latest), but not while an earlier one is still waiting to be aired (`OutboxRepository.AnyHeartbeatWaitingAsync`), so they never pile up while the light is down; it takes a sequence number, so a lost last message becomes a gap on the far side, gets no Receipt and is never re-aired. `GetAsync` returns `FarSideStatus` (record, same file): when anything from the far side last arrived acceptably (Heartbeats included), its last Receipt, and `Silent` (nothing heard for longer than `Gateway:FarSideSilentMinutes`, counted from start-up until something is heard). Used by `MaintenanceWorker` and `/health`. Proven only with in-memory gateways and a fake light. |
| `SoapForwarderHttpClient.cs` | Replays the original request **byte for byte** with the same SOAPAction and Content-Type; an `HttpGet` message (step 12) is replayed as a GET with no body, SOAPAction or Content-Type, and classified the same way. Only the URL changes, and it always comes from configuration (`Targets[service]` or `DefaultBaseUrl` + the original path), never from the message. Applies the connect timeout (handler) and the per-call timeout, and the response size cap. Credentials per service (`ClientNameFor`, D75): the target's `UseDefaultCredentials` when set and different from the global one picks `receiver-default-credentials` or `receiver-anonymous`, else `receiver`; never a password. **Decision D9: re-post only when the call surely did not arrive.** `ForwardAsync` and `Classify` turn the outcome into a verdict: `Delivered`, `Refused` (RETURN_CODE ≠ 0), `Permanent` (fault, 4xx except 408/429, 3xx, 501, 505), `Unknown` (it may have been processed: timeout after sending, reset or answer ended early, HTTP 500/502/503/504 or another odd status, a 2xx whose expected result can't be read) or `Transient` (nothing was sent: DNS failure, connection refused, connect timeout, TLS failure, HTTP 408/429 → retry), returned as its record `DeliveryResult` (same file, with the real service's `HttpStatus` and the probable reason in plain words; the `DeliveryVerdict` enum is in `Configurations/Enums/Enums.cs`). Its private `ReadServiceReply` reads the real service's reply (fault and reason, or result text); its private `RewriteAddressingTo` changes only `wsa:To` for WS-Addressing requests, so WCF services see their own address; other bodies stay byte-identical. |
| `SequenceGapMonitor.cs` | Finds **messages that never arrived** (decision D29): numbers missing from the other side's sequence, per run of its counter (`InboxRepository.FindSequenceGapsAsync`), once the message after them arrived `GapGraceMinutes` ago. `MaintenanceWorker` calls `CheckAsync` once a minute; it logs one `Light: …` warning per new gap (numbers and ids only) and keeps the result in `Current` for `/health`. A gap stays until the message arrives, the sender's counter starts a new run, or an operator acknowledges it (`InboxRepository.AcknowledgeGapAsync`; no UI yet). The sending side re-airs a message with no Receipt (`MaintenanceWorker`, step 11). |

### `Egress/Workers/` — background jobs inside the IIS app pool

| File | Purpose |
|---|---|
| `InboxWorker.cs` | Loops over the Inbox: **one delivery loop per priority class** (`DeliveryClasses` = High, Normal, Low; step 14, D73), so a slow feed never holds back a permit. Each loop claims the next Request of its class (`InboxRepository.ClaimNextAsync(priority)`: by run of the sender's counter, then sequence; not while an earlier Request of the same service and class is `Retrying`, D74), checks and unpacks it (checksum, then `ArrivalChecks`; a Receipt or Reply is never posted), checks the route catalogue and plans the target (`Bridge` and RoundTrip operations; an `HttpGet` message only for an `HttpGet` route and a SOAP message never for one, else light **Rejected**, step 12), then calls `SoapForwarderHttpClient`. Before posting, on a route that recognises retries (layer 3b, D58, step 10b) it looks for the **same content** arrived within `RetryWindowMinutes`: already `Done` → not posted, its answer is reused (`AnswerWriter.ReuseDoneAsync`); `Unknown` or still `Delivering` → not posted, `Unknown`. Result, in the row's service status: **Done**, **Retrying** (only when nothing was sent; exponential backoff; after `MaxAttempts` it ends **NotDelivered**; a round-trip **query** is not retried but ends **NotDelivered** at once — fast failure, its caller is waiting), **Refused** (fault, non-zero code, 4xx, 3xx, 501, 505), **Unknown** (it may have been processed: timeout after sending, reset, 5xx, an unreadable 2xx, or the gateway stopped during the POST), **Expired** (past its `ExpiresUtc`: not posted; queries and state-changing RoundTrip calls have one) or **NotDelivered** (no receiver target, or out of tries); or the light status **Rejected** (corrupted or misconfigured). Every final outcome goes through `AnswerWriter.FinishAsync`, which writes the Reply **before** marking the row (D46); `Retrying` gets no Reply yet. Out of tries, the worker itself decides `NotDelivered` (`InboxRepository.MarkRetryingAsync` only sets `Retrying`). Refused, Unknown and NotDelivered wait for an operator. A Done row's body is cleared by the repository (D77). It logs who called (`CallerHost`) at delivery, never the payload. Each loop sleeps on the Inbox doorbell between messages (one ring wakes one loop; the others poll every `InboxPollSeconds`) and writes a heartbeat every 30 s. |
| `ReceiptWorker.cs` | Sends the **Receipts** this side owes (decision D44), separately from deliveries so a slow POST cannot hold them back: every `Gateway:InboxPollSeconds` it calls `AnswerWriter.SendDueReceiptsAsync` until none are left. Every arrived message is owed one (set by `InboxRepository.AddMessageAsync`, again when the same `MessageId` arrives a second time); a Receipt never gets a Receipt. |
| `MaintenanceWorker.cs` | Runs once a minute. It settles Inbox rows still `Delivering` after `LockTimeoutMinutes` (crash or recycle during the POST) through `AnswerWriter.RecoverStuckAsync`: the outcome of the Reply already written for this attempt, or `Unknown` with an Unknown Reply, because the request may have reached the service (decisions D9, D46; never posted again on its own). It checks for lost messages and moves the sequence watermarks up (`SequenceGapMonitor.CheckAsync`), sends an idle Heartbeat message (`FarSideMonitor`, step 17), re-airs unconfirmed Outbox rows (`OutboxRepository.ReairUnconfirmedAsync`, step 11, D65–D67: a row — not a Receipt or Heartbeat — still light `Aired` `ReceiptTimeoutSeconds` (120) after it was aired goes back to `Pending` for the QR sender; after `MaxAirAttempts` (3) airs, or once past its `ExpiresUtc`, it becomes light `Failed`; one `Light: …` warning per changed row, never the payload; nothing sets `Aired` on real hardware yet), logs warnings that need an operator — `Light: …` (Outbox Failed, Inbox Rejected, Outbox not confirmed for 30 min — Receipt and Heartbeat rows not counted —, a new sequence gap, "nothing heard from the far side since …" when it is silent) and `Service: …` (Inbox Unknown, Refused, NotDelivered) — and writes component heartbeats shown by `/health`. It deletes nothing (decision D28): operators archive rows manually, and never archive `SequenceWatermark` or `AcknowledgedGap`. |

---

## Code that lives elsewhere (`..\QrBridge.Shared\`)

The gateway uses these shared pieces, which are also compiled into the QR apps:

| Shared folder | Used for |
|---|---|
| `Configurations/Enums/Enums.cs`, `Configurations/Helpers/Utility.cs` | All Shared enums (`BridgeSide`, `Direction`, `PayloadFormat` — `RawSoap`, or `HttpGet` for the plain GET Request since step 12; the database CHECK constraint changed, so delete dev databases —, `Compression`, `MessageKind` — Request, Receipt, Reply, Heartbeat (step 17) —, `MessagePriority` — `Answer`/`High`/`Normal`/`Low`, stored as its number 0–3 in the `Priority` columns (step 14; schema change: delete dev databases) —, and the two status groups per table: `OutboxLightStatus`, `OutboxServiceStatus`, `InboxLightStatus`, `InboxServiceStatus`) and the static helpers `BridgeSideExtensions`, `Hashing`, `StatusCounts`, `SignalNames`, `Components` |
| `Configurations/Options/GatewayDatabaseOptions.cs` | The `GatewayDatabase` section (the QR apps read the same class from their `QRDatabase` section): `Side`, `DataFolder`, `MaxPayloadBytes`, `Provider` (Sqlite/SqlServer, decision 55), `ConnectionString`, the SQLite path `DatabasePath` (`DataFolder\qrbridge.db`, `DatabaseFileName`) |
| `Data/` | Shared, engine-free: `Contexts/` (abstract `BridgeDbContext` — the two engine questions: how a write transaction takes the one write lock, how a duplicate key shows —, `BridgeDbContextFactory`), `Providers/` (`IBridgeDatabase`, the engine seam, `GatewayDatabase:Provider`, decision 55; its `Create` picks the engine), `Entities/` (table rows), `Configurations/` (table shapes), `Conventions/` (how Guids, enums and times are stored, on every engine), `Repositories/` (queue operations behind `IOutboxRepository`, `IInboxRepository`, `IHeartbeatRepository`: `OutboxRepository` — `InsertAsync`, the one way a row is stored (called only by `OutboxWriter`); its `ClaimNextAsync`, for the QR Sender, takes Receipts, Replies and Heartbeats first, then High, Normal, Low —, `InboxRepository` — `ClaimNextAsync(priority)` per delivery loop; a row ending Done loses its body, D77; the sequence-number checks and watermarks, D84 —, `HeartbeatRepository`), `Initializers/` (`AddBridgeData`, `DatabaseInitializer`). One folder per engine with everything only it uses: `Sqlite/` (`Providers/SqliteBridgeDatabase` — default: `qrbridge.db`, connection string, WAL, refuses to start beside a former `send.db` / `received.db` —, `Contexts/` (`SqliteBridgeDbContext`, design-time factory), `Initializers/` (`SchemaAdoption`, `SqlitePragmaInterceptor`), `Exceptions/` (`SchemaMismatchException`), `Migrations/`) and `SqlServer/` (`Providers/SqlServerBridgeDatabase`, `Contexts/`, `Migrations/`) |
| `Serialization/` | `MessageHeader` (service, operation, ids + the replay details path, SOAPAction, Content-Type; version 5: `Kind`, `CorrelationId`, and for a Reply `Outcome`, `ServiceHttpStatus`, `ServiceComment`; version 6: `Priority`; version 7: the kind `Heartbeat`, no new field) and `MessageSerializer` (header + body ↔ bytes, magic `BRG7`, Brotli + checksum; `BRG3`…`BRG6` refused with a clear reason) |
| `Signals/` | `BridgeSignals`: the named events (Outbox and Inbox doorbells) shared with the QR apps |

## Known gaps that touch this project

- `routes.json` lists the DMZ → Corp services the DMZ interface services call (from
  `workspace-master-v2/source-code/6-dmz-outbound-interfaces`), but their paths come from the proxies' default URLs
  and must be confirmed against the DMZ load balancer, most of their contracts are derived from the proxies (see
  `Contracts/README.md`), and `appsettings.Corp.json` `Receiver` (the corporate hosts) is still empty.
- Outbox rows stay light status `Pending` until the QR Sender reads the Outbox (not built yet). `Aired` is set by
  nothing yet; `Received` and the service status are set by `AnswerReader` when a Receipt or Reply arrives — proven
  only by tests that copy the bytes between two gateways. Until the QR apps carry messages, every RoundTrip caller
  (permits, orders, cards, queries) waits the full hold and gets the hold-timeout answer (1596 or "not available").
  For the same reason each gateway reports the far side **silent** (`/health` unhealthy) once
  `Gateway:FarSideSilentMinutes` pass: Heartbeat messages are queued but nothing carries them yet.
- `FMS2FC.IssueWorkPermit` is RoundTrip like the other permits (D61), but what FMS does after a non-zero answer
  (`IntMgr.CardCutOut`, open question D12) is not known: pilot-only until the FMS team explains it.
- `MaxRequestBytes` (D78) comes from the simulator's templates, not real traffic: a real message larger than 10 × the
  largest template (e.g. an order with many switching steps) gets 413 — a false failure, the caller falls back to
  manual work. Check against real sizes (review Q4). `Gateway:Light` (D79) is arithmetic, not a measurement.
