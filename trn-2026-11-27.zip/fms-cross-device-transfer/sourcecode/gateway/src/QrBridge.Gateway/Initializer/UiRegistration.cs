using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Ui;
using QrBridge.Gateway.Ui.Data;
using QrBridge.Gateway.Ui.Reading;
using QrBridge.Gateway.Ui.Security;

namespace QrBridge.Gateway.Initializer;

/// <summary>
/// The read-only web UI (Ui/), in this same site under /qrbridge-ui behind a login (handoff decision 48). It opens
/// qrbridge.db read-only (<see cref="ReadOnlyBridgeDb"/>) and learns about the rest of the gateway only through
/// <see cref="UiGatewayInfo"/>. With Ui:Enabled = false nothing is mapped and its paths get 405 like any other GET.
/// </summary>
public static class UiRegistration
{
    public static IServiceCollection AddGatewayUi(this IServiceCollection services)
    {
        services.AddOptions<UiOptions>().BindConfiguration(UiOptions.SectionName);
        services.AddSingleton<ReadOnlyBridgeDb>();
        services.AddSingleton<MessageReader>();
        services.AddSingleton<MessageQueries>();
        services.AddSingleton<UiGatewayInfo>();
        services.AddSingleton<UiTime>();

        // The pages live in Ui/Pages and all need the login, except the login page and the stylesheet/scripts it uses.
        // The policy names its own scheme: no default scheme and no fallback policy, so the SOAP endpoints and /health
        // neither need nor read the cookie.
        services.AddRazorPages(o =>
        {
            o.RootDirectory = "/Ui/Pages";
            o.Conventions.AuthorizeFolder("/", UiAuthentication.Policy);
            o.Conventions.AllowAnonymousToPage("/Login");
            o.Conventions.AllowAnonymousToPage("/Assets");
        });
        services.AddAuthentication().AddCookie(UiAuthentication.Scheme, o =>
        {
            o.LoginPath = UiPaths.Login;
            o.LogoutPath = UiPaths.Logout;
            o.AccessDeniedPath = UiPaths.Login;
            o.SlidingExpiration = true;
            o.Cookie.Name = UiAuthentication.CookieName;
            o.Cookie.Path = UiPaths.Prefix;
            o.Cookie.HttpOnly = true;
            o.Cookie.SameSite = SameSiteMode.Strict;
            o.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest; // Secure behind https (IIS), plain on a dev bench
        });
        services.AddOptions<CookieAuthenticationOptions>(UiAuthentication.Scheme)
            .Configure<IOptions<UiOptions>>((o, ui) => o.ExpireTimeSpan = TimeSpan.FromMinutes(Math.Max(1, ui.Value.SessionMinutes)));
        services.AddAuthorization(o => o.AddPolicy(UiAuthentication.Policy, p => p
            .AddAuthenticationSchemes(UiAuthentication.Scheme)
            .RequireAuthenticatedUser()));
        services.AddAntiforgery(o =>
        {
            o.Cookie.Name = UiAuthentication.CookieName + ".Antiforgery";
            o.Cookie.Path = UiPaths.Prefix;
        });
        return services;
    }

    /// <summary>
    /// Maps the pages when Ui:Enabled (read here, after Build). Off: nothing is added, and the UI's paths answer like any
    /// other unknown path of the gateway (GET 405).
    /// </summary>
    public static WebApplication MapGatewayUi(this WebApplication app)
    {
        var ui = app.Services.GetRequiredService<IOptions<UiOptions>>().Value;
        var log = app.Services.GetRequiredService<ILoggerFactory>().CreateLogger("QrBridge.Ui");
        if (!ui.Enabled)
        {
            log.LogInformation("Read-only UI off (Ui:Enabled = false)");
            return app;
        }

        // A clear password left in the settings (the former Ui:Password, or pasted into Ui:PasswordHash) stops the start
        // rather than being silently ignored or compared.
        if (!string.IsNullOrEmpty(app.Configuration[$"{UiOptions.SectionName}:Password"]))
            throw new InvalidOperationException(
                "Ui:Password is no longer read: remove it and set Ui:PasswordHash (scripts/new-ui-password-hash.ps1).");
        if (string.IsNullOrWhiteSpace(ui.Username) || !UiAuthentication.IsHash(ui.PasswordHash))
            throw new InvalidOperationException(
                $"Ui:Username and Ui:PasswordHash (a {UiAuthentication.HashPrefix} hash from scripts/new-ui-password-hash.ps1) must be set while Ui:Enabled is true.");
        if (ui.SessionMinutes <= 0 || ui.PageSize is <= 0 or > 500 || ui.RefreshSeconds <= 0)
            throw new InvalidOperationException("Ui:SessionMinutes and Ui:RefreshSeconds must be positive, Ui:PageSize 1–500.");
        _ = app.Services.GetRequiredService<UiTime>(); // an unknown Ui:TimeZone stops the start here, not on the first page
        if (UiAuthentication.Matches(ui, "admin", "admin"))
            log.LogWarning("The read-only UI ({Prefix}) uses the default login admin/admin. Set Ui:Username and Ui:PasswordHash for this site.",
                UiPaths.Prefix);

        app.UseWhen(c => UiPaths.IsUiPath(c.Request.Path.Value), branch => branch.Use(async (context, next) =>
        {
            UiSecurityHeaders.Apply(context.Response);
            await next(context);
        }));
        app.UseAuthentication();
        app.UseAuthorization();
        app.MapRazorPages();

        log.LogInformation("Read-only UI on at {Prefix}", UiPaths.Prefix);
        return app;
    }
}
