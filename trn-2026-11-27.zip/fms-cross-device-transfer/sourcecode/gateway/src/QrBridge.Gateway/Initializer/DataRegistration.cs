using Microsoft.Extensions.Options;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;

namespace QrBridge.Gateway.Initializer;

/// <summary>What the gateway shares with the QR apps: the gateway's database (GatewayDatabase: qrbridge.db or SQL Server), the message serializer and the doorbells.</summary>
public static class DataRegistration
{
    public static IServiceCollection AddGatewayData(this IServiceCollection services)
    {
        // EF Core on the configured engine (IBridgeDatabase) and the repositories, by their interfaces.
        services.AddBridgeData();

        // The message bytes are not encrypted here: QrDiode encrypts it on the QR link.
        services.AddSingleton(sp => new MessageSerializer(
            sp.GetRequiredService<IOptions<GatewayDatabaseOptions>>().Value.MaxPayloadBytes));

        services.AddSingleton<BridgeSignals>();
        return services;
    }
}
