using Microsoft.Extensions.Options;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Exceptions;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;

namespace QrBridge.Gateway.Ingress;

/// <summary>
/// The Sender part's end of the round trip (fix plan §4.1): reads the Receipts and Replies the far side sent back for
/// this side's messages, after the same arrival checks as any message (<see cref="ArrivalChecks"/>), and stores what
/// they say in the Outbox row they answer:
///   Receipt — the far side stored the message: light Received (stops re-airing, step 11).
///   Reply   — what the far side's real service did: the service group and the real answer (the first answer, or a
///             newer one after an operator requeue unless the stored one is Answered, decision D59), then wakes the
///             callers held for it (<see cref="WaiterRegistry"/>).
/// It also takes the far side's Heartbeats (decision D80): checked like any message, then Done; their arrival is what
/// "far side last seen" reads (<see cref="Egress.FarSideMonitor"/>).
/// Each Inbox row then ends Done ("used"), or Rejected when it failed a check or answers no message of this side.
/// Nothing here is ever posted to a service.
/// </summary>
public sealed class AnswerReader(
    IInboxRepository inbox,
    IOutboxRepository outbox,
    MessageSerializer serializer,
    ArrivalChecks arrival,
    WaiterRegistry waiters,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<AnswerReader> logger) : BackgroundService
{
    private const int MaxPerPass = 100;

    // Polls instead of waiting on the Inbox doorbell: that event wakes one waiter per ring, and InboxWorker needs every
    // ring for the Requests. A Reply waits at most one poll interval, small next to a crossing of the light.
    private readonly TimeSpan _interval = TimeSpan.FromSeconds(Math.Max(1, gatewayOptions.Value.InboxPollSeconds));

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await Task.Yield(); // don't block host startup
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                IReadOnlyList<InboxMessage> arrived;
                do
                {
                    arrived = await inbox.FindArrivedAnswersAsync(MaxPerPass, stoppingToken);
                    foreach (var row in arrived) await UseAsync(row);
                }
                while (arrived.Count == MaxPerPass && !stoppingToken.IsCancellationRequested);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Answer reader error");
            }

            try { await Task.Delay(_interval, stoppingToken); }
            catch (OperationCanceledException) { break; }
        }
    }

    /// <summary>Not cancellable: once started, a row is always settled, so it is never used twice or left half-done.</summary>
    private async Task UseAsync(InboxMessage row)
    {
        var ct = CancellationToken.None;
        try
        {
            var (header, body) = serializer.Deserialize(row.MessageBytes);
            await arrival.CheckAsync(header, row, ct);

            if (header.Kind == MessageKind.Heartbeat)
            {
                // D80: "the far side is alive". Its arrival time is what /health reads; nothing else to do.
                await inbox.MarkDoneAsync(row.MessageId, null, "Heartbeat: the far side is alive.", null, ct);
                logger.LogDebug("Heartbeat {MessageId} seq {Sequence} from the far side", row.MessageId, header.Sequence);
                return;
            }

            // The serializer guarantees a CorrelationId on every Receipt and Reply.
            Guid answered = header.CorrelationId ?? throw new BridgeRejectException($"A {header.Kind} without a CorrelationId.");

            var target = await outbox.FindStateAsync(answered, ct);
            if (target is null || target.Kind is MessageKind.Receipt or MessageKind.Heartbeat || (header.Kind == MessageKind.Reply && target.Kind != MessageKind.Request))
                throw new BridgeRejectException($"It answers {answered}, which is not a {(header.Kind == MessageKind.Reply ? "Request" : "message")} this side sent.");
            if (target.ServiceName != header.ServiceName || target.Operation != header.Operation)
                throw new BridgeRejectException(
                    $"It is for {header.ServiceName}.{header.Operation}, but {answered} is {target.ServiceName}.{target.Operation}.");

            if (header.Kind == MessageKind.Receipt)
            {
                await outbox.MarkReceivedAsync([answered], ct);
                await inbox.MarkDoneAsync(row.MessageId, null, $"Receipt: the far side stored {answered}.", null, ct);
                logger.LogInformation("Receipt {ReceiptId}: the far side stored {MessageId}", row.MessageId, answered);
                return;
            }

            var outcome = header.Outcome ?? throw new BridgeRejectException("A Reply without an Outcome.");
            var status = StatusOf(outcome);
            bool stored = await outbox.MarkAnsweredAsync(answered, status, header.ServiceHttpStatus, header.ServiceComment ?? "",
                body.Length > 0 && header.ContentType.Length > 0 ? header.ContentType : null,
                body.Length > 0 ? body : null, header.CreatedUtc, ct);
            waiters.Wake(answered); // after the store: a woken caller reads the answer from the Outbox
            await inbox.MarkDoneAsync(row.MessageId, null, stored
                ? $"Reply: {answered} {status}."
                : $"Reply for {answered} ({outcome}) not stored: it is already Answered, or a newer Reply's answer is kept (D59).", null, ct);
            logger.LogInformation("Reply {ReplyId} for {Service}.{Operation} {MessageId}: {Outcome} (HTTP {Status}, {Bytes} bytes){Kept}",
                row.MessageId, header.ServiceName, header.Operation, answered, outcome, header.ServiceHttpStatus, body.Length,
                stored ? "" : "; not stored, the answer already kept stands");
        }
        catch (Exception ex) when (ex is InvalidDataException or BridgeRejectException or ArgumentException)
        {
            logger.LogWarning("Rejected {MessageId} ({Kind}): {Reason}", row.MessageId, row.Kind, ex.Message);
            await inbox.MarkRejectedAsync(row.MessageId, $"{ex.GetType().Name}: {ex.Message}", ct);
        }
    }

    /// <summary>The far side's outcome in the Outbox's words (decisions D24, D51).</summary>
    private static OutboxServiceStatus StatusOf(ServiceOutcome outcome) => outcome switch
    {
        ServiceOutcome.Done => OutboxServiceStatus.Answered,
        ServiceOutcome.Refused => OutboxServiceStatus.Refused,
        ServiceOutcome.Expired => OutboxServiceStatus.Expired,
        ServiceOutcome.NotDelivered => OutboxServiceStatus.NotDelivered,
        ServiceOutcome.Rejected => OutboxServiceStatus.Rejected,
        _ => OutboxServiceStatus.Unknown,
    };
}
