using System.Security;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Exceptions;
using QrBridge.Gateway.Ingress.Soap;
using QrBridge.Gateway.Ingress.Validation;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;

namespace QrBridge.Gateway.Ingress;

/// <summary>
/// The Sender part of the gateway. Receives every SOAP POST, whatever the service: the load balancer sends the
/// callers' unchanged requests here instead of to the real service.
///
///   read body (size-capped) -> parse the SOAP envelope (any version/style) -> look up the route
///   -> Bridge: check the WSDL contract and the allow-list, store the exact bytes in the Outbox, THEN reply like the real service
///   -> RoundTrip: the same checks and store, then HOLD the caller until the far side's Reply comes back (its real
///      answer, decision D50) or the hold runs out (the route's OnHoldTimeout answer) (fix plan §4.1, §4.5)
///   -> Echo / Unavailable / Reject: answer locally, store nothing
/// </summary>
public sealed class SenderEndpoint(
    RouteTable routes,
    ContractCatalog contracts,
    OutboxWriter outbox,
    IOutboxRepository stored,
    WaiterRegistry waiters,
    IOptions<GatewayDatabaseOptions> bridgeOptions,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<SenderEndpoint> logger)
{
    public const string MessageIdHeader = "X-QrBridge-MessageId";

    /// <summary>How often a held caller re-reads its Outbox row when nothing wakes it (the database is the truth).</summary>
    private static readonly TimeSpan HoldPollInterval = TimeSpan.FromSeconds(2);

    private readonly int _maxBodyBytes = bridgeOptions.Value.MaxPayloadBytes;
    private readonly HoldOptions _hold = gatewayOptions.Value.Hold;
    private readonly ExpiryOptions _expiry = gatewayOptions.Value.Expiry;

    public async Task HandleAsync(HttpContext context)
    {
        var ct = context.RequestAborted;
        string path = RouteTable.NormalizePath(context.Request.Path.Value);

        try
        {
            // D78: a route may set a smaller limit than GatewayDatabase:MaxPayloadBytes; the smaller of the two applies.
            int maxBody = Math.Min(routes.FindByPath(path)?.MaxRequestBytes ?? _maxBodyBytes, _maxBodyBytes);
            byte[]? body = await ReadBodyAsync(context.Request, maxBody, ct);
            if (body is null)
            {
                logger.LogWarning("Refused {Path}: request larger than {Max} bytes", path, maxBody);
                await WriteAsync(context, SoapReplyWriter.Fault(SoapVersion.Soap11, null, senderFault: true,
                    $"The request is larger than the bridge limit of {maxBody} bytes.", statusCode: 413));
                return;
            }

            string contentType = context.Request.ContentType ?? "";
            string? soapActionHeader = context.Request.Headers.TryGetValue("SOAPAction", out var h) ? h.ToString() : null;

            if (!SoapRequest.TryParse(body, contentType, soapActionHeader, (long)_maxBodyBytes * 2, out var request, out string parseError))
            {
                logger.LogWarning("Refused {Path}: {Error}", path, parseError);
                await WriteAsync(context, SoapReplyWriter.Fault(SoapVersion.Soap11, null, senderFault: true, parseError, statusCode: 400));
                return;
            }

            var business = PayloadInspector.Inspect(request!.FirstParameterText, (long)_maxBodyBytes * 2);
            var decision = routes.Resolve(path, request.Operation, business.Type);
            var reply = await DecideAsync(context, path, request, decision, business, body, contentType, ct);
            await WriteAsync(context, reply);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            // The caller hung up: nobody to answer. Anything already queued stays queued (see HoldAsync).
        }
    }

    private async Task<SoapReply> DecideAsync(HttpContext context, string path, SoapRequest request, RouteDecision decision,
                                              BusinessInfo business, byte[] body, string contentType, CancellationToken ct)
    {
        string label = $"{decision.ServiceName}.{request.Operation}";
        var style = StyleFor(decision, request);
        string? resultElement = decision.Service?.ResultElement;

        if (decision.Service is { HttpGet: true })
        {
            logger.LogWarning("Refused a SOAP POST to {Service}: it is a plain HTTP GET interface", decision.ServiceName);
            return SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: true,
                $"{decision.ServiceName} is a plain HTTP GET interface, not a SOAP service.");
        }

        switch (decision.Mode)
        {
            case OperationMode.Reject:
                logger.LogWarning("Refused {Label} on {Path}: {Problem}", label, path, decision.Problem);
                return SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: true, decision.Problem ?? "Not bridged.");

            case OperationMode.Echo:
                return SoapReplyWriter.Result(request, style, resultElement, request.FirstParameterText ?? "");

            case OperationMode.Unavailable:
                logger.LogInformation("Answered {Label} ({Type}) as unavailable (it needs data from the other side)", label, business.Type);
                return NotAvailable(request, decision, business, style, resultElement, label);
        }

        // ---- Bridge and RoundTrip ----
        if (contracts.Check(decision.Service, request) is { } mismatch)
        {
            string reason = $"{label}: the request does not match the service's WSDL ({mismatch}). It was NOT accepted.";
            logger.LogWarning("Refused {Reason}", reason);
            return SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: true, reason);
        }

        var allowed = decision.Operation?.AllowedTypes;
        if (allowed is { Count: > 0 } && (business.Type is null || !allowed.Contains(business.Type, StringComparer.Ordinal)))
        {
            string reason = !business.WellFormed
                ? $"{label}: the XML payload is not well-formed."
                : $"{label}: message type '{business.Type ?? "(none)"}' is not accepted by this interface.";
            logger.LogWarning("Refused {Reason}", reason);
            return decision.Profile?.Rejected is { } rejected
                ? SoapReplyWriter.Result(request, style, resultElement, Fill(rejected, business, null))
                : SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: true, reason);
        }

        TimeSpan? hold = decision.Mode == OperationMode.RoundTrip ? HoldFor(decision.ServiceName) : null;
        var header = new MessageHeader
        {
            ServiceName = decision.ServiceName,
            Operation = request.Operation,
            Path = path,
            SoapActionHeader = request.SoapActionHeader,
            ContentType = contentType.Length > 0 ? contentType : SoapNamespaces.ContentType(request.Version),
            BusinessType = business.Type ?? "",
            ContentFingerprint = ContentFingerprint.Compute(decision.ServiceName, business.Type, body,
                                                            decision.FingerprintIgnore, (long)_maxBodyBytes * 2),
            // D54: a caller told "not available" when its hold runs out never has the call run later behind its back.
            // D62: a state-changing call is not delivered after Gateway:Expiry (a dispatcher may have gone verbal).
            ExpiresUtc = hold is { } h
                ? DateTime.UtcNow + (decision.OnHoldTimeout == HoldTimeoutAnswer.Unavailable
                    ? h : TimeSpan.FromSeconds(_expiry.SecondsFor(decision.ServiceName)))
                : null,
            Priority = decision.Priority,
            CallerHost = CallerHostOf(context),
        };

        Guid messageId;
        try
        {
            messageId = (await outbox.EnqueueAsync(header, body, decision.RecogniseRetries, ct)).MessageId;
        }
        catch (BridgeBacklogFullException ex)
        {
            logger.LogWarning("Refused {Label}: {Reason}", label, ex.Message);
            return decision.Profile?.Busy is { } busy
                ? SoapReplyWriter.Result(request, style, resultElement, Fill(busy, business, null))
                : SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: false, ex.Message, statusCode: 503);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            // Nothing was committed, so the caller must know the call was NOT accepted.
            logger.LogError(ex, "Could not store {Label}", label);
            return SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: false,
                "The bridge could not store the message; it was NOT accepted. Please retry.");
        }

        context.Response.Headers[MessageIdHeader] = messageId.ToString("D");

        if (hold is { } holdFor)
            return await HoldAsync(label, messageId, holdFor,
                state => AnswerFrom(state, request, decision, business, style, resultElement, label),
                () => HoldTimeout(request, decision, business, style, resultElement, label, messageId),
                decision.OnHoldTimeout, ct);

        if (decision.OneWay) return SoapReplyWriter.Accepted();
        return decision.Profile?.Ok is { } ok
            ? SoapReplyWriter.Result(request, style, resultElement, Fill(ok, business, messageId))
            : SoapReplyWriter.EmptyResponse(request);
    }

    /// <summary>
    /// Holds a RoundTrip caller until its message has an answer (decision D50, <paramref name="answer"/>) or the hold
    /// runs out (<paramref name="timeout"/>). Registered before the first read, so an answer stored after that read
    /// wakes it; one stored before is read. A retry attached to the same message waits here too and gets the same
    /// answer. If the caller hangs up, the message stays queued: it is still delivered, and a retry gets the stored answer.
    /// </summary>
    private async Task<SoapReply> HoldAsync(string label, Guid messageId, TimeSpan hold, Func<MessageState, SoapReply> answer,
                                            Func<SoapReply> timeout, HoldTimeoutAnswer onTimeout, CancellationToken ct)
    {
        using var waiter = waiters.Register(messageId);
        var deadline = DateTime.UtcNow + hold;
        try
        {
            while (true)
            {
                var state = await stored.FindStateAsync(messageId, ct);
                if (state is not null && state.ServiceStatus != OutboxServiceStatus.Waiting)
                    return answer(state);

                // D55: out of re-air tries, nothing can come back without an operator.
                if (state is null || state.LightStatus == OutboxLightStatus.Failed)
                {
                    logger.LogWarning("{Label} {MessageId}: the message cannot cross the light (light {Light}); hold-timeout answer at once",
                        label, messageId, state?.LightStatus.ToString() ?? "row missing");
                    return timeout();
                }

                var left = deadline - DateTime.UtcNow;
                if (left <= TimeSpan.Zero)
                {
                    logger.LogInformation("{Label} {MessageId}: no answer within the {Hold} s hold; answered {Answer}",
                        label, messageId, (int)hold.TotalSeconds, onTimeout);
                    return timeout();
                }
                await waiter.WaitAsync(left < HoldPollInterval ? left : HoldPollInterval, ct);
            }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            logger.LogInformation("{Label} {MessageId}: the caller hung up while held; the message stays queued and a retry gets its answer",
                label, messageId);
            throw;
        }
    }

    /// <summary>
    /// A plain HTTP GET (decision D18; Registered Tags): only a service marked HttpGet answers, every other GET gets 405
    /// as before (the gateway serves no WSDL or help pages). The call crosses as an empty HttpGet message and its caller
    /// is held for the real answer, replayed byte for byte; anything else is HTTP 504 (D69). A query string is refused (D71).
    /// </summary>
    public async Task HandleGetAsync(HttpContext context)
    {
        var ct = context.RequestAborted;
        string path = RouteTable.NormalizePath(context.Request.Path.Value);
        var service = routes.FindByPath(path);
        if (service is not { HttpGet: true } || service.SenderSide != bridgeOptions.Value.Side)
        {
            context.Response.StatusCode = StatusCodes.Status405MethodNotAllowed;
            return;
        }

        string label = $"{service.Name}.{RouteTable.HttpGetOperation}";
        try
        {
            if (context.Request.QueryString.HasValue)
            {
                logger.LogWarning("Refused {Label}: a query string is not carried across", label);
                await WriteAsync(context, PlainText(400, $"{service.Name}: a query string is not accepted by the QR bridge."));
                return;
            }

            var decision = routes.Resolve(path, RouteTable.HttpGetOperation, null);
            if (decision.Mode != OperationMode.RoundTrip)
            {
                logger.LogInformation("Answered {Label} as unavailable", label);
                await WriteAsync(context, GetNotAvailable(service.Name));
                return;
            }

            var hold = HoldFor(service.Name);
            var header = new MessageHeader
            {
                ServiceName = service.Name,
                Operation = RouteTable.HttpGetOperation,
                Path = path,
                ContentType = "",
                BusinessType = "",
                PayloadFormat = PayloadFormat.HttpGet,
                ExpiresUtc = DateTime.UtcNow + hold, // D54: a query told "not available" never runs later
                Priority = decision.Priority,
                CallerHost = CallerHostOf(context),
            };

            Guid messageId;
            try
            {
                messageId = (await outbox.EnqueueAsync(header, [], attachRetries: false, ct)).MessageId;
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogWarning("Refused {Label}: {Reason}", label, ex is BridgeBacklogFullException ? ex.Message : "could not store it");
                if (ex is not BridgeBacklogFullException) logger.LogError(ex, "Could not store {Label}", label);
                await WriteAsync(context, GetNotAvailable(service.Name));
                return;
            }

            context.Response.Headers[MessageIdHeader] = messageId.ToString("D");
            var reply = await HoldAsync(label, messageId, hold,
                state => state.ServiceStatus is OutboxServiceStatus.Answered or OutboxServiceStatus.Refused &&
                         state.ReplyBody is { Length: > 0 } answer && state.ServiceHttpStatus is { } status
                    ? new SoapReply(status, answer, string.IsNullOrEmpty(state.ReplyContentType) ? null : state.ReplyContentType)
                    : GetNotAvailable(service.Name),
                () => GetNotAvailable(service.Name), HoldTimeoutAnswer.Unavailable, ct);
            await WriteAsync(context, reply);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            // The caller hung up; the message stays queued.
        }
    }

    /// <summary>D69: what a GET caller gets when no real answer comes back in time (or it was not sent at all).</summary>
    private static SoapReply GetNotAvailable(string serviceName) =>
        PlainText(StatusCodes.Status504GatewayTimeout,
            $"{serviceName} is not available while the network is islanded: no answer came back over the QR bridge in time.");

    private static SoapReply PlainText(int status, string text) =>
        new(status, System.Text.Encoding.UTF8.GetBytes(text), "text/plain; charset=utf-8");

    /// <summary>
    /// Decision D50: the real answer byte for byte when the service accepted or refused it and its answer came back;
    /// the hold-timeout answer when it may have been processed or no answer came back; "not available" when it surely
    /// was not done (expired, not delivered, rejected).
    /// </summary>
    private SoapReply AnswerFrom(MessageState state, SoapRequest request, RouteDecision decision, BusinessInfo business,
                                 MessageStyle style, string? resultElement, string label)
    {
        switch (state.ServiceStatus)
        {
            case OutboxServiceStatus.Answered or OutboxServiceStatus.Refused
                when state.ReplyBody is { Length: > 0 } answer && state.ServiceHttpStatus is { } status:
                logger.LogInformation("{Label} {MessageId}: {Outcome}; the caller gets the real answer (HTTP {Status}, {Bytes} bytes)",
                    label, state.MessageId, state.ServiceStatus, status, answer.Length);
                return new SoapReply(status, answer, string.IsNullOrEmpty(state.ReplyContentType) ? null : state.ReplyContentType);

            case OutboxServiceStatus.Answered or OutboxServiceStatus.Refused or OutboxServiceStatus.Unknown:
                logger.LogWarning("{Label} {MessageId}: {Outcome} without a real answer to pass on; hold-timeout answer",
                    label, state.MessageId, state.ServiceStatus);
                return HoldTimeout(request, decision, business, style, resultElement, label, state.MessageId);

            default:
                logger.LogWarning("{Label} {MessageId}: {Outcome}, it was not done; answered not available",
                    label, state.MessageId, state.ServiceStatus);
                return NotAvailable(request, decision, business, style, resultElement, label);
        }
    }

    /// <summary>OnHoldTimeout: Pending = the profile's Pending value (1596, decision D8); Unavailable = "not available".</summary>
    private static SoapReply HoldTimeout(SoapRequest request, RouteDecision decision, BusinessInfo business, MessageStyle style,
                                         string? resultElement, string label, Guid messageId)
    {
        if (decision.OnHoldTimeout == HoldTimeoutAnswer.Unavailable)
            return NotAvailable(request, decision, business, style, resultElement, label);
        // RouteTable refuses to start without a Pending value; the fault is only a never-"done" fallback.
        return decision.Profile?.Pending is { } pending
            ? SoapReplyWriter.Result(request, style, resultElement, Fill(pending, business, messageId))
            : SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: false,
                $"{label} was sent over the QR bridge; confirmation not yet received.");
    }

    private static SoapReply NotAvailable(SoapRequest request, RouteDecision decision, BusinessInfo business, MessageStyle style,
                                          string? resultElement, string label) =>
        decision.Profile?.Unavailable is { } unavailable
            ? SoapReplyWriter.Result(request, style, resultElement, Fill(unavailable, business, null))
            : SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: false,
                $"{label} is not available while the network is islanded: it needs a live answer from the other side.");

    /// <summary>Gateway:Hold:Services[service] or Gateway:Hold:DefaultSeconds (decision D11).</summary>
    private TimeSpan HoldFor(string serviceName) => TimeSpan.FromSeconds(_hold.SecondsFor(serviceName));

    /// <summary>
    /// Decision D76: who called, for operators (logged at delivery). The first X-Forwarded-For address when the load
    /// balancer sends one, labelled with the connection's own address because that header can be forged; else the
    /// connection's address. Only address characters are taken from the header, so nothing else can reach the logs.
    /// </summary>
    public static string? CallerHostOf(HttpContext context)
    {
        string? remote = context.Connection.RemoteIpAddress?.ToString();
        string forwarded = context.Request.Headers["X-Forwarded-For"].ToString().Split(',')[0].Trim();
        bool usable = forwarded.Length is > 0 and <= 64 &&
                      forwarded.All(c => char.IsAsciiHexDigit(c) || c is '.' or ':' or '[' or ']' or '%');
        if (!usable) return remote;
        return remote is null ? forwarded : $"{forwarded} (via {remote})";
    }

    /// <summary>Catalogue style when listed; otherwise inferred from the request (unqualified parameters = RPC).</summary>
    private static MessageStyle StyleFor(RouteDecision decision, SoapRequest request) =>
        decision.Service?.Style ?? (request.ParametersUnqualified ? MessageStyle.Rpc : MessageStyle.Document);

    /// <summary>Fills the reply placeholders. Values come from the request, so they are XML-escaped.</summary>
    internal static string Fill(string template, BusinessInfo business, Guid? messageId) =>
        template
            .Replace("{BusinessType}", Escape(business.Type), StringComparison.Ordinal)
            .Replace("{MsgId}", Escape(business.MsgId), StringComparison.Ordinal)
            .Replace("{MessageId}", messageId?.ToString("D") ?? "", StringComparison.Ordinal);

    private static string Escape(string? value) => SecurityElement.Escape(value ?? "");

    /// <summary>Reads the body, or returns null if it is larger than <paramref name="max"/>.</summary>
    private static async Task<byte[]?> ReadBodyAsync(HttpRequest request, int max, CancellationToken ct)
    {
        if (request.ContentLength > max) return null;

        using var buffer = new MemoryStream(request.ContentLength is > 0 and var len ? (int)len : 4096);
        var chunk = new byte[16 * 1024];
        int read;
        while ((read = await request.Body.ReadAsync(chunk, ct)) > 0)
        {
            if (buffer.Length + read > max) return null;
            buffer.Write(chunk, 0, read);
        }
        return buffer.ToArray();
    }

    private static async Task WriteAsync(HttpContext context, SoapReply reply)
    {
        context.Response.StatusCode = reply.StatusCode;
        if (reply.ContentType is not null) context.Response.ContentType = reply.ContentType;
        if (reply.Body.Length > 0) await context.Response.Body.WriteAsync(reply.Body, context.RequestAborted);
    }
}
