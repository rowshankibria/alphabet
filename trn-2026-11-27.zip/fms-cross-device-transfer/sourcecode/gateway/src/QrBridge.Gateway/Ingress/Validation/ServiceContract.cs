using System.Xml;
using System.Xml.Schema;
using QrBridge.Gateway.Ingress.Soap;
using QrBridge.Shared;

namespace QrBridge.Gateway.Ingress.Validation;

/// <summary>
/// A service's WSDL 1.1 (plus the XSD files next to it), reduced to what is needed to check a request:
/// supported SOAP versions, and per operation the expected Body element (document) or parts (RPC).
/// </summary>
public sealed class ServiceContract
{
    private const string WsdlNs = "http://schemas.xmlsoap.org/wsdl/";
    private const string Soap11BindingNs = "http://schemas.xmlsoap.org/wsdl/soap/";
    private const string Soap12BindingNs = "http://schemas.xmlsoap.org/wsdl/soap12/";
    private const string XsdNs = "http://www.w3.org/2001/XMLSchema";
    private const string XmlnsNs = "http://www.w3.org/2000/xmlns/";
    private const int MaxFileCharacters = 4_000_000; // 4 million characters: about 4 MB of WSDL/XSD text
    private const int MaxDetailLength = 300;

    private readonly XmlSchemaSet _schemas;
    private readonly Lock _validationLock = new();

    private ServiceContract(string name, IReadOnlyDictionary<string, ContractOperation> operations,
                            IReadOnlySet<SoapVersion> versions, XmlSchemaSet schemas)
    {
        Name = name;
        Operations = operations;
        Versions = versions;
        _schemas = schemas;
    }

    /// <summary>Folder name under Contracts/.</summary>
    public string Name { get; }

    /// <summary>By operation name, case-sensitive (XML names are).</summary>
    public IReadOnlyDictionary<string, ContractOperation> Operations { get; }

    public IReadOnlySet<SoapVersion> Versions { get; }

    /// <summary>
    /// Loads {folder}/service.wsdl and every *.xsd beside it. Nothing external is resolved: the WCF
    /// schemaLocation URLs are satisfied by the local *.xsd files. Throws <see cref="InvalidDataException"/>.
    /// </summary>
    public static ServiceContract Load(string folder, string name)
    {
        string wsdlPath = Path.Combine(folder, "service.wsdl");
        if (!File.Exists(wsdlPath))
            throw new InvalidDataException($"Contract '{name}': {wsdlPath} not found.");

        XmlDocument wsdl;
        try
        {
            wsdl = SafeXml.Load(File.ReadAllBytes(wsdlPath), MaxFileCharacters);
        }
        catch (XmlException ex)
        {
            throw new InvalidDataException($"Contract '{name}': service.wsdl is not well-formed: {ex.Message}");
        }

        var root = wsdl.DocumentElement;
        if (root is null || root.LocalName != "definitions" || root.NamespaceURI != WsdlNs)
            throw new InvalidDataException($"Contract '{name}': service.wsdl is not a WSDL 1.1 document.");

        var schemas = LoadSchemas(folder, name, root);
        var messages = ReadMessages(root);
        var portOperations = ReadPortTypeOperations(root);
        var (operations, versions) = ReadBindings(name, root, messages, portOperations);

        if (operations.Count == 0)
            throw new InvalidDataException($"Contract '{name}': no SOAP binding operations found.");

        foreach (var op in operations.Values)
            if (op.Element is { } element && !schemas.GlobalElements.Contains(element))
                throw new InvalidDataException($"Contract '{name}': operation {op.Name} uses element {element} that no schema declares.");

        return new ServiceContract(name, operations, versions, schemas);
    }

    /// <summary>Checks a request against the contract. Returns null when it matches, else a reason safe to show the caller.</summary>
    public string? Check(SoapRequest request)
    {
        if (!Versions.Contains(request.Version))
            return $"the service takes {string.Join(" and ", Versions.Order().Select(Describe))} only, not {Describe(request.Version)}";

        if (!Operations.TryGetValue(request.Operation, out var op))
            return $"the WSDL has no operation '{request.Operation}'";

        // Only when both sides name one: the real WCF/ASMX service dispatches on it, so a different action would
        // fail there too. A caller that sends none, or a WSDL that gives none, is not checked.
        if (request.HttpAction is { } sent && op.SoapActions.TryGetValue(request.Version, out var expected) &&
            expected.Length > 0 && !string.Equals(sent, expected, StringComparison.Ordinal))
            return $"SOAPAction '{Truncate(sent)}' is not the WSDL's '{expected}' for {op.Name}";

        var element = request.OperationElement;
        if (element is null) return "the SOAP Body has no operation element";

        return op.Style == MessageStyle.Document ? CheckDocument(op, element) : CheckRpc(op, element);
    }

    private string? CheckDocument(ContractOperation op, XmlElement element)
    {
        if (element.LocalName != op.Element!.Name || element.NamespaceURI != op.Element.Namespace)
            return $"expected element {{{op.Element.Namespace}}}{op.Element.Name}, got {{{element.NamespaceURI}}}{element.LocalName}";

        string? problem = null;
        var settings = new XmlReaderSettings { ValidationType = ValidationType.Schema, Schemas = _schemas, XmlResolver = null };
        settings.ValidationEventHandler += (sender, e) =>
        {
            if (e.Severity != XmlSeverityType.Error || problem is not null) return;
            string at = sender is XmlReader r && r.LocalName.Length > 0 ? $" (at '{r.LocalName}')" : "";
            problem = Truncate(e.Message) + at;
        };

        lock (_validationLock) // XmlSchemaSet is not documented as thread-safe
        {
            using var reader = XmlReader.Create(new XmlNodeReader(element), settings);
            try
            {
                while (problem is null && reader.Read()) { }
            }
            catch (XmlException ex)
            {
                problem ??= Truncate(ex.Message);
            }
        }
        return problem;
    }

    private static string? CheckRpc(ContractOperation op, XmlElement element)
    {
        if (op.RpcNamespace is { Length: > 0 } ns && element.NamespaceURI != ns)
            return $"operation element {element.LocalName} must be in namespace '{ns}', not '{element.NamespaceURI}'";

        var children = element.ChildNodes.OfType<XmlElement>().ToList();
        var expected = op.RpcParts.Select(p => p.Name).ToList();
        var actual = children.Select(c => c.LocalName).ToList();
        if (!expected.SequenceEqual(actual, StringComparer.Ordinal))
            return $"expected parameter(s) [{string.Join(", ", expected)}], got [{string.Join(", ", actual)}]";

        for (int i = 0; i < children.Count; i++)
        {
            var child = children[i];
            var part = op.RpcParts[i];
            if (child.NamespaceURI.Length != 0)
                return $"parameter '{part.Name}' must be unqualified (no namespace)";
            if (child.ChildNodes.OfType<XmlElement>().Any())
                return $"parameter '{part.Name}' must be a simple value, not XML elements";

            var type = XmlSchemaType.GetBuiltInSimpleType(part.Type);
            if (type?.Datatype is null || child.GetAttribute("nil", XmlSchema.InstanceNamespace) is "true" or "1") continue;
            try
            {
                type.Datatype.ParseValue(child.InnerText, new NameTable(), null);
            }
            catch (Exception ex) when (ex is XmlSchemaException or FormatException or OverflowException)
            {
                return $"parameter '{part.Name}' is not a valid {part.Type.Name}";
            }
        }
        return null;
    }

    // ---------------- WSDL reading ----------------

    private sealed record Part(string Name, XmlQualifiedName? Element, XmlQualifiedName? Type);

    private sealed record PortOperation(XmlQualifiedName? Input, IReadOnlyList<string>? ParameterOrder);

    private static XmlSchemaSet LoadSchemas(string folder, string name, XmlElement root)
    {
        var set = new XmlSchemaSet { XmlResolver = null };
        void OnEvent(object? _, ValidationEventArgs e)
        {
            if (e.Severity == XmlSeverityType.Error)
                throw new InvalidDataException($"Contract '{name}': schema error: {e.Message}");
        }
        set.ValidationEventHandler += OnEvent;

        var types = Child(root, "types");
        if (types is not null)
        {
            foreach (var schemaElement in types.ChildNodes.OfType<XmlElement>()
                         .Where(e => e.LocalName == "schema" && e.NamespaceURI == XsdNs))
            {
                // A copy that carries every in-scope prefix: QName values (type="s:string") need them.
                var copy = (XmlElement)schemaElement.CloneNode(deep: true);
                for (var n = schemaElement.ParentNode; n is XmlElement ancestor; n = ancestor.ParentNode)
                    foreach (XmlAttribute a in ancestor.Attributes)
                        if (a.NamespaceURI == XmlnsNs && copy.GetAttributeNode(a.Name) is null)
                            copy.SetAttribute(a.Name, a.Value);

                set.Add(XmlSchema.Read(new XmlNodeReader(copy), OnEvent)!);
            }
        }

        foreach (string file in Directory.GetFiles(folder, "*.xsd").Order(StringComparer.OrdinalIgnoreCase))
        {
            try
            {
                using var reader = XmlReader.Create(file, SafeXml.Settings(MaxFileCharacters));
                set.Add(XmlSchema.Read(reader, OnEvent)!);
            }
            catch (XmlException ex)
            {
                throw new InvalidDataException($"Contract '{name}': {Path.GetFileName(file)} is not well-formed: {ex.Message}");
            }
        }

        try
        {
            set.Compile();
        }
        catch (XmlSchemaException ex)
        {
            throw new InvalidDataException($"Contract '{name}': schemas do not compile: {ex.Message}");
        }
        return set;
    }

    private static Dictionary<string, List<Part>> ReadMessages(XmlElement root)
    {
        var messages = new Dictionary<string, List<Part>>(StringComparer.Ordinal);
        foreach (var m in Children(root, "message"))
            messages[m.GetAttribute("name")] = Children(m, "part")
                .Select(p => new Part(p.GetAttribute("name"), QName(p, "element"), QName(p, "type")))
                .ToList();
        return messages;
    }

    private static Dictionary<string, PortOperation> ReadPortTypeOperations(XmlElement root)
    {
        var operations = new Dictionary<string, PortOperation>(StringComparer.Ordinal);
        foreach (var portType in Children(root, "portType"))
        foreach (var op in Children(portType, "operation"))
        {
            var input = Child(op, "input");
            string order = op.GetAttribute("parameterOrder");
            operations.TryAdd(op.GetAttribute("name"), new PortOperation(
                input is null ? null : QName(input, "message"),
                order.Length == 0 ? null : order.Split(' ', StringSplitOptions.RemoveEmptyEntries)));
        }
        return operations;
    }

    private static (Dictionary<string, ContractOperation>, HashSet<SoapVersion>) ReadBindings(
        string name, XmlElement root, Dictionary<string, List<Part>> messages, Dictionary<string, PortOperation> portOperations)
    {
        var operations = new Dictionary<string, ContractOperation>(StringComparer.Ordinal);
        var versions = new HashSet<SoapVersion>();
        var soapActions = new Dictionary<string, Dictionary<SoapVersion, string>>(StringComparer.Ordinal);

        foreach (var binding in Children(root, "binding"))
        {
            var soapBinding = binding.ChildNodes.OfType<XmlElement>()
                .FirstOrDefault(e => e.LocalName == "binding" && e.NamespaceURI is Soap11BindingNs or Soap12BindingNs);
            if (soapBinding is null) continue; // e.g. an HTTP GET/POST binding

            string soapNs = soapBinding.NamespaceURI;
            versions.Add(soapNs == Soap12BindingNs ? SoapVersion.Soap12 : SoapVersion.Soap11);
            string defaultStyle = soapBinding.GetAttribute("style") is { Length: > 0 } s ? s : "document";

            foreach (var op in Children(binding, "operation"))
            {
                string opName = op.GetAttribute("name");
                var soapOperation = op.ChildNodes.OfType<XmlElement>()
                    .FirstOrDefault(e => e.LocalName == "operation" && e.NamespaceURI == soapNs);

                // Every binding contributes its soapAction (a WCF/ASMX WSDL has one SOAP 1.1 and one SOAP 1.2 binding).
                if (!soapActions.TryGetValue(opName, out var actions))
                    soapActions[opName] = actions = new Dictionary<SoapVersion, string>();
                actions.TryAdd(soapNs == Soap12BindingNs ? SoapVersion.Soap12 : SoapVersion.Soap11,
                               soapOperation?.GetAttribute("soapAction") ?? "");

                if (operations.ContainsKey(opName)) continue;

                string style = soapOperation?.GetAttribute("style") is { Length: > 0 } os ? os : defaultStyle;
                var body = Child(op, "input")?.ChildNodes.OfType<XmlElement>()
                    .FirstOrDefault(e => e.LocalName == "body" && e.NamespaceURI == soapNs);

                if (!portOperations.TryGetValue(opName, out var portOp) || portOp.Input is null ||
                    !messages.TryGetValue(portOp.Input.Name, out var parts))
                    throw new InvalidDataException($"Contract '{name}': operation {opName} has no input message.");

                if (style == "rpc")
                {
                    var byName = parts.ToDictionary(p => p.Name, StringComparer.Ordinal);
                    var rpcParts = new List<ContractPart>();
                    foreach (string partName in portOp.ParameterOrder ?? parts.Select(p => p.Name).ToList())
                    {
                        if (!byName.TryGetValue(partName, out var part) || part.Type is null)
                            throw new InvalidDataException($"Contract '{name}': RPC part {opName}.{partName} has no type.");
                        rpcParts.Add(new ContractPart(partName, part.Type));
                    }
                    operations[opName] = new ContractOperation(opName, MessageStyle.Rpc, null,
                        body?.GetAttribute("namespace") ?? "", rpcParts, actions);
                }
                else
                {
                    if (parts.Count != 1 || parts[0].Element is null)
                        throw new InvalidDataException($"Contract '{name}': document operation {opName} must have one element part.");
                    operations[opName] = new ContractOperation(opName, MessageStyle.Document, parts[0].Element, null, [], actions);
                }
            }
        }
        return (operations, versions);
    }

    private static XmlQualifiedName? QName(XmlElement element, string attribute)
    {
        string value = element.GetAttribute(attribute);
        if (value.Length == 0) return null;
        int colon = value.IndexOf(':');
        string prefix = colon < 0 ? "" : value[..colon];
        string local = colon < 0 ? value : value[(colon + 1)..];
        return new XmlQualifiedName(local, element.GetNamespaceOfPrefix(prefix));
    }

    private static XmlElement? Child(XmlElement parent, string localName) => Children(parent, localName).FirstOrDefault();

    private static IEnumerable<XmlElement> Children(XmlElement parent, string localName) =>
        parent.ChildNodes.OfType<XmlElement>().Where(e => e.LocalName == localName && e.NamespaceURI == WsdlNs);

    private static string Describe(SoapVersion v) => v == SoapVersion.Soap12 ? "SOAP 1.2" : "SOAP 1.1";

    private static string Truncate(string s) => s.Length <= MaxDetailLength ? s : s[..MaxDetailLength];
}

/// <summary>One operation's request shape, as its WSDL binding describes it.</summary>
/// <param name="Element">Document style: the input part's global element (the SOAP Body element).</param>
/// <param name="RpcNamespace">RPC style: the soap:body namespace of the operation element ("" when not given).</param>
/// <param name="RpcParts">RPC style: the input parts, in order.</param>
/// <param name="SoapActions">The binding's soapAction per SOAP version ("" when the WSDL gives none).</param>
public sealed record ContractOperation(
    string Name,
    MessageStyle Style,
    XmlQualifiedName? Element,
    string? RpcNamespace,
    IReadOnlyList<ContractPart> RpcParts,
    IReadOnlyDictionary<SoapVersion, string> SoapActions);

/// <summary>An RPC part: unqualified child element of the operation element, with a built-in simple type.</summary>
public sealed record ContractPart(string Name, XmlQualifiedName Type);
