using Microsoft.Extensions.Options;
using QrBridge.Gateway.Exceptions;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;

namespace QrBridge.Gateway.Ingress;

/// <summary>
/// The ONE place where messages enter the bridge: callers' Requests (SenderEndpoint) and this side's Receipts and
/// Replies (AnswerWriter).
///
/// Request: same content in the retry window? (attach, or count) -> backlog check. Then, for every kind: next sequence
/// -> serialize the message -> insert into Outbox -> commit -> ring the Outbox doorbell (all but the doorbell in one
/// write transaction, <see cref="IOutboxRepository.InsertAsync"/>). The caller only gets its reply after the commit, so
/// an accepted call is never lost. This class decides the rules and builds the row; it never opens the database itself.
/// </summary>
public sealed class OutboxWriter(
    IOutboxRepository outbox,
    MessageSerializer serializer,
    RouteTable routes,
    BridgeSignals signals,
    RetryCounters retries,
    IOptions<GatewayDatabaseOptions> bridgeOptions,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<OutboxWriter> logger)
{
    private const int MaxBusinessTypeLength = 256;

    private readonly GatewayDatabaseOptions _bridge = bridgeOptions.Value;
    private readonly GatewayOptions _gw = gatewayOptions.Value;

    /// <summary>
    /// Queues one caller request: <paramref name="header"/> describes it (service, operation, path, SOAPAction,
    /// Content-Type, label, content fingerprint) and <paramref name="body"/> is the SOAP body exactly as received. The
    /// id, direction, sequence and time are set here. Throws <see cref="BridgeBacklogFullException"/> when the Outbox
    /// is full.
    /// </summary>
    /// <param name="attachRetries">
    /// When a Request with the same <see cref="MessageHeader.ContentFingerprint"/> was queued within
    /// Gateway:RetryWindowMinutes, return that message instead of queuing a second one (decision D37). The check and the
    /// insert share one write transaction (one writer at a time, on every database engine), so identical calls at the
    /// same moment make one row.
    /// </param>
    public async Task<EnqueueResult> EnqueueAsync(MessageHeader header, byte[] body, bool attachRetries = false,
                                                  CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(header);
        ArgumentNullException.ThrowIfNull(body);

        var messageId = Guid.NewGuid();
        var direction = _bridge.SendDirection;
        string businessType = header.BusinessType.Length > MaxBusinessTypeLength
            ? header.BusinessType[..MaxBusinessTypeLength]
            : header.BusinessType;
        bool request = header.Kind == MessageKind.Request;

        // D63: a message the far side surely did not carry out (Expired, NotDelivered, Rejected) is not a retry target
        // (the repository leaves those out): the caller still wants it, so it is queued again with a fresh expiry.
        // D47: only Requests count toward the backlog, and only Requests are refused, so answers never make this side
        // refuse its callers. D78: a route may also have its own, smaller backlog.
        var insert = new OutboxInsert(
            direction, header.Kind, header.ServiceName, request ? header.ContentFingerprint : null,
            DateTime.UtcNow.AddMinutes(-_gw.RetryWindowMinutes), attachRetries, _gw.MaxBacklog,
            routes.FindByName(header.ServiceName)?.MaxBacklog);

        long sequence = 0;
        int packedBytes = 0;
        var result = await outbox.InsertAsync(insert, (nextSequence, runId) =>
        {
            sequence = nextSequence;
            var stored = header with
            {
                MessageId = messageId,
                Direction = direction,
                BusinessType = businessType,
                PayloadFormat = request ? header.PayloadFormat : PayloadFormat.RawSoap,
                // D73: answers always go on the light first; a Request keeps its route's class.
                Priority = request ? header.Priority : MessagePriority.Answer,
                Compression = Compression.Brotli,
                Sequence = nextSequence,
                SequenceRunId = runId,
                CatalogFingerprint = routes.CatalogFingerprint,
                CreatedUtc = DateTime.UtcNow,
            };

            byte[] messageBytes = serializer.Serialize(stored, body);
            packedBytes = messageBytes.Length;
            return new OutboxMessage
            {
                MessageId = messageId,
                Direction = direction,
                ServiceName = stored.ServiceName,
                Operation = stored.Operation,
                BusinessType = businessType.Length == 0 ? null : businessType,
                Sequence = nextSequence,
                SequenceRunId = runId,
                PayloadFormat = stored.PayloadFormat,
                Priority = stored.Priority,
                Kind = stored.Kind,
                CorrelationId = stored.CorrelationId,
                ContentFingerprint = stored.ContentFingerprint,
                ExpiresUtc = stored.ExpiresUtc,
                PayloadSize = body.Length,
                MessageBytes = messageBytes,
                MessageHash = Hashing.Sha256Hex(messageBytes),
                LightStatus = OutboxLightStatus.Pending,
                LightUpdatedUtc = stored.CreatedUtc,
                ServiceStatus = OutboxServiceStatus.Waiting,
                ServiceUpdatedUtc = stored.CreatedUtc,
                CreatedUtc = stored.CreatedUtc,
            };
        }, ct);

        switch (result.Outcome)
        {
            case OutboxInsertOutcome.Attached:
                retries.CountAttached();
                logger.LogInformation("Attached a retry of {Service}.{Operation} {BusinessType} to {MessageId} (same content within {Window} min)",
                    header.ServiceName, header.Operation, businessType, result.SameContentId, _gw.RetryWindowMinutes);
                return new EnqueueResult(result.SameContentId!.Value, Attached: true);
            case OutboxInsertOutcome.BacklogFull:
                throw new BridgeBacklogFullException(result.Backlog, result.BacklogLimit);
        }

        signals.Outbox.Set();
        logger.LogInformation("Queued {Kind} {Service}.{Operation} {BusinessType} as {MessageId} seq {Sequence} ({Bytes} bytes packed)",
            header.Kind, header.ServiceName, header.Operation, businessType, messageId, sequence, packedBytes);
        if (result.SameContentId is { } earlier)
        {
            retries.CountSameContentQueued();
            logger.LogInformation("{MessageId} has the same content as {Earlier} (within {Window} min); queued again because {Service}.{Operation} does not recognise retries",
                messageId, earlier, _gw.RetryWindowMinutes, header.ServiceName, header.Operation);
        }
        return new EnqueueResult(messageId, Attached: false);
    }
}
/// <summary>The message a call is now part of.</summary>
/// <param name="MessageId">The new message, or the first message with the same content when <paramref name="Attached"/>.</param>
/// <param name="Attached">A caller's retry: nothing was queued, the call belongs to an existing message.</param>
public sealed record EnqueueResult(Guid MessageId, bool Attached);
