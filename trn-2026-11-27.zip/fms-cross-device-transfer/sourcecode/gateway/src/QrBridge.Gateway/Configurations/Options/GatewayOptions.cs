namespace QrBridge.Gateway;

/// <summary>Gateway-only settings. Bound from the "Gateway" section of appsettings.</summary>
public sealed class GatewayOptions
{
    public const string SectionName = "Gateway";

    /// <summary>
    /// Above this many Pending+Sending Outbox rows, new calls are refused with the route's "Busy" reply
    /// instead of being queued — the caller sees it at once and can retry, rather than a silent pile-up.
    /// </summary>
    public int MaxBacklog { get; set; } = 5000;

    /// <summary>
    /// A call with the same content fingerprint as one queued less than this long ago is a caller's retry (decision
    /// D5). On routes that recognise retries it is attached to the first message; elsewhere it is only counted.
    /// </summary>
    public int RetryWindowMinutes { get; set; } = 30;

    // ----- Inbox worker -----
    public int InboxPollSeconds { get; set; } = 2;
    public int MaxAttempts { get; set; } = 8;
    public int BackoffBaseSeconds { get; set; } = 30;
    public int BackoffMaxMinutes { get; set; } = 30;
    /// <summary>Messages older than this (by sender's CreatedUtc) are rejected as possible replays. A second check since
    /// step 17: an old message is also recognised by its sequence number, whatever its date (decision D84).</summary>
    public int ReplayWindowDays { get; set; } = 7;
    /// <summary>Messages dated further than this in the future are rejected (clock skew guard).</summary>
    public int MaxClockSkewMinutes { get; set; } = 60;

    // ----- Maintenance -----
    public int MaintenanceIntervalSeconds { get; set; } = 60;
    /// <summary>
    /// Inbox rows in Delivering longer than this are assumed abandoned (crash, recycle) and become Unknown (decision D9).
    /// Must be longer than any Receiver delivery timeout, or a slow delivery still running would be marked Unknown.
    /// </summary>
    public int LockTimeoutMinutes { get; set; } = 5;

    /// <summary>
    /// A missing sequence number is reported only when the message after it arrived at least this long ago: bundles may
    /// arrive out of order. 0 = report at once. Rows are never deleted automatically (decision D28): archive manually.
    /// </summary>
    public int GapGraceMinutes { get; set; } = 5;

    /// <summary>
    /// An Outbox row aired this long ago with no Receipt from the far side is aired again (decisions D9, D65). Checked
    /// every maintenance run, so the real wait is up to one MaintenanceIntervalSeconds longer.
    /// </summary>
    public int ReceiptTimeoutSeconds { get; set; } = 120;

    /// <summary>
    /// Airs in total, the first one included (the row's Attempts: one per QR sender claim), before a row with no Receipt
    /// becomes light Failed and waits for an operator (decision D66).
    /// </summary>
    public int MaxAirAttempts { get; set; } = 3;

    /// <summary>
    /// When this side has queued nothing for this many minutes, it sends an empty Heartbeat message (decisions D80, D81),
    /// so the far side keeps hearing from it while idle and a lost last message shows there as a gap. 0 = off. Checked
    /// every maintenance run, so it may go up to one MaintenanceIntervalSeconds later.
    /// </summary>
    public int HeartbeatMinutes { get; set; } = 5;

    /// <summary>
    /// Nothing heard from the far side for longer than this (any message, its Heartbeats included; counted from start-up
    /// until something is heard) = the light or the far gateway is down: /health unhealthy and a "Light:" warning
    /// (decisions D82, D83). Must be longer than the far side's HeartbeatMinutes.
    /// </summary>
    public int FarSideSilentMinutes { get; set; } = 15;

    /// <summary>The Receiver part: where requests that arrive over the QR link are delivered on this side.</summary>
    public ReceiverOptions Receiver { get; set; } = new();

    /// <summary>How long a RoundTrip caller on this side is held for the real answer (decision D11).</summary>
    public HoldOptions Hold { get; set; } = new();

    /// <summary>
    /// How long a state-changing RoundTrip call (hold-timeout answer 1596) stays deliverable (decision D62): the far side
    /// does not post it after that (Expired), so a permit never arrives after the dispatcher has gone verbal.
    /// </summary>
    public ExpiryOptions Expiry { get; set; } = new();

    /// <summary>How fast the QR link carries a message, for the start-up air-time warning (decision D79).</summary>
    public LightOptions Light { get; set; } = new();
}

/// <summary>
/// The QR link's speed, from the V6 review's figures for QrDiode (1,350-byte symbols at 15 fps, each sent about three
/// times): used only to warn at start-up when a RoundTrip route's size limit would take longer to air than its hold
/// (decision D79). Arithmetic, not a measurement: update it once the real link is measured.
/// </summary>
public sealed class LightOptions
{
    /// <summary>Effective goodput in bytes per second, before compression (Brotli makes XML smaller, so this errs long).</summary>
    public int BytesPerSecond { get; set; } = 6700;

    /// <summary>Shortest time on air for one QR session, however small.</summary>
    public double MinAirSeconds { get; set; } = 6;

    /// <summary>Pause between two QR sessions.</summary>
    public double GapSeconds { get; set; } = 1.5;

    /// <summary>Seconds to air one message of <paramref name="bytes"/> on an idle link.</summary>
    public double AirSecondsFor(long bytes) => Math.Max(MinAirSeconds, (double)bytes / BytesPerSecond) + GapSeconds;
}

/// <summary>
/// Expiry of state-changing RoundTrip calls (fix plan §4.4, decision D62), in seconds after the call arrived (the sending
/// side's clock; checked with the far side's). Must be longer than the service's hold, or a call could expire while its
/// caller is still told "sent, confirmation not yet received". Queries expire with their hold (D54); Bridge calls never.
/// </summary>
public sealed class ExpiryOptions
{
    public int DefaultSeconds { get; set; } = 600;

    /// <summary>Per-service overrides in seconds, keyed by route service name (a service whose callers are on this side).</summary>
    public Dictionary<string, int> Services { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>The override for <paramref name="serviceName"/>, else the default.</summary>
    public int SecondsFor(string serviceName) => Services.TryGetValue(serviceName, out int seconds) ? seconds : DefaultSeconds;
}

/// <summary>
/// The hold of RoundTrip calls (fix plan §4.5). It must be shorter than the caller's own timeout, or the caller gives
/// up before it gets the hold-timeout answer: Corp 270 s (Rapid Restore waits 5 min), DMZ 90 s (the FMS clients keep
/// the .NET default of 100 s). A query (hold-timeout answer "not available") also expires after its hold (D54).
/// </summary>
public sealed class HoldOptions
{
    public int DefaultSeconds { get; set; } = 90;

    /// <summary>Per-service overrides in seconds, keyed by route service name (a service whose callers are on this side).</summary>
    public Dictionary<string, int> Services { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>The override for <paramref name="serviceName"/>, else the default.</summary>
    public int SecondsFor(string serviceName) => Services.TryGetValue(serviceName, out int seconds) ? seconds : DefaultSeconds;
}

/// <summary>
/// Delivery to the real services on this side. The target for a message is, in order:
/// <c>Targets[service].Url</c>, else <c>DefaultBaseUrl</c> + the path the original caller used.
/// The URL is never taken from the message itself.
/// </summary>
public sealed class ReceiverOptions
{
    /// <summary>
    /// e.g. "https://dmz-rr-server". The caller's original path is appended, so services hosted under the same
    /// paths as on the load balancer need no per-service entry.
    /// </summary>
    public string? DefaultBaseUrl { get; set; }

    /// <summary>Per-call timeout. Must stay below Gateway:LockTimeoutMinutes.</summary>
    public int TimeoutSeconds { get; set; } = 120;

    /// <summary>
    /// Time allowed to connect (DNS, TCP and TLS) before anything is sent (decision D42). Must be shorter than every
    /// delivery timeout, so that "could not connect: nothing sent, safe to re-post" is told apart from "sent, no answer:
    /// may have been processed" (decision D9).
    /// </summary>
    public int ConnectTimeoutSeconds { get; set; } = 15;

    /// <summary>
    /// Allow plain http:// target URLs outside the Development environment (test benches only). By default the
    /// gateway refuses to start with one: requests would cross the network unencrypted.
    /// </summary>
    public bool AllowHttp { get; set; }

    /// <summary>Authenticate to the real services as the app pool identity (Windows/NTLM/Kerberos).</summary>
    public bool UseDefaultCredentials { get; set; }

    /// <summary>For WS-Addressing requests: point the wsa:To header at the real service instead of the gateway.</summary>
    public bool RewriteAddressingTo { get; set; } = true;

    /// <summary>
    /// Largest answer read back from a real service, in bytes: a memory guard. A bigger answer is not read at all
    /// (status kept, body dropped). What can cross back is the smaller GatewayDatabase:MaxPayloadBytes (1 MB): an answer
    /// between the two is read, then left out of the Reply as "too large to carry back".
    /// </summary>
    public int MaxResponseBytes { get; set; } = 4_000_000; // 4 MB (4,000,000 bytes)

    /// <summary>Per-service overrides, keyed by route service name (e.g. "FC2FMS").</summary>
    public Dictionary<string, ReceiverTarget> Targets { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class ReceiverTarget
{
    public string Url { get; set; } = "";
    public int? TimeoutSeconds { get; set; }

    /// <summary>
    /// Overrides Gateway:Receiver:UseDefaultCredentials for this service only (decision D75): call it as the app pool
    /// identity, or anonymously. Null: the global setting. Never a password in configuration.
    /// </summary>
    public bool? UseDefaultCredentials { get; set; }
}
