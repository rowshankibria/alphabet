using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using QrBridge.Shared;
using QrBridge.Shared.Data;

namespace QrBridge.Gateway.Ui.Data;

/// <summary>
/// The UI's only way into the bridge database: queries are not tracked, and SQLite opens qrbridge.db with
/// Mode=ReadOnly (SQL Server uses the one GatewayDatabase:ConnectionString). It builds its own engine object for those
/// connections and never takes the gateway's
/// read-write one (<see cref="IBridgeDatabase"/>, IDbContextFactory&lt;BridgeDbContext&gt;); this class is deliberately not
/// registered as a context factory.
/// </summary>
public sealed class ReadOnlyBridgeDb(IOptions<GatewayDatabaseOptions> bridgeOptions) : IDbContextFactory<BridgeDbContext>
{
    private readonly IBridgeDatabase _database = IBridgeDatabase.Create(bridgeOptions.Value);

    public BridgeDbContext CreateDbContext() => _database.CreateReadOnlyContext();

    public Task<BridgeDbContext> CreateDbContextAsync(CancellationToken ct = default) => Task.FromResult(CreateDbContext());
}