using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace QrBridge.Gateway.Ui.Security;

/// <summary>
/// The UI's login: one username and a password hash from configuration (Ui:Username / Ui:PasswordHash, admin / admin by
/// default, handoff decision 48) and a cookie limited to /qrbridge-ui. Its own scheme and policy, and no default scheme,
/// so the gateway's SOAP endpoints and /health are not touched by it. The password itself is never stored: the settings
/// hold a salted PBKDF2-SHA256 hash ("PBKDF2-SHA256$iterations$salt$hash", made by scripts/new-ui-password-hash.ps1).
/// </summary>
public static class UiAuthentication
{
    public const string Scheme = "QrBridge.Ui";
    public const string Policy = "QrBridge.Ui";
    public const string CookieName = "QrBridge.Ui";

    public const string HashPrefix = "PBKDF2-SHA256";
    private const int Iterations = 100_000;
    private const int SaltBytes = 16;
    private const int HashBytes = 32;

    /// <summary>
    /// Both must match. The username is compared in constant time (hashed first, so the lengths do not show) and the
    /// password is always hashed, even for a wrong username, so the answer time does not tell which one was wrong.
    /// </summary>
    public static bool Matches(UiOptions ui, string? username, string? password) =>
        Same(username, ui.Username) & Verify(ui.PasswordHash, password);

    public static ClaimsPrincipal Principal(string username) =>
        new(new ClaimsIdentity([new Claim(ClaimTypes.Name, username)], Scheme));

    /// <summary>A new hash for Ui:PasswordHash (fresh salt each time). Same format as the script's.</summary>
    public static string HashPassword(string password)
    {
        byte[] salt = RandomNumberGenerator.GetBytes(SaltBytes);
        byte[] hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, HashBytes);
        return $"{HashPrefix}${Iterations}${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
    }

    /// <summary>True when the setting has the hash's shape (checked at start-up, so a clear password there stops it).</summary>
    public static bool IsHash(string? stored) => TryParse(stored, out _, out _, out _);

    public static bool Verify(string? stored, string? password)
    {
        if (!TryParse(stored, out int iterations, out byte[] salt, out byte[] expected))
            return false;
        byte[] actual = Rfc2898DeriveBytes.Pbkdf2(password ?? "", salt, iterations, HashAlgorithmName.SHA256, expected.Length);
        return CryptographicOperations.FixedTimeEquals(actual, expected);
    }

    private static bool TryParse(string? stored, out int iterations, out byte[] salt, out byte[] hash)
    {
        iterations = 0;
        salt = hash = [];
        string[] parts = (stored ?? "").Split('$');
        if (parts.Length != 4 || parts[0] != HashPrefix || !int.TryParse(parts[1], out iterations) || iterations < 1)
            return false;
        try
        {
            salt = Convert.FromBase64String(parts[2]);
            hash = Convert.FromBase64String(parts[3]);
        }
        catch (FormatException)
        {
            return false;
        }
        return salt.Length >= SaltBytes && hash.Length == HashBytes;
    }

    private static bool Same(string? given, string expected) =>
        CryptographicOperations.FixedTimeEquals(
            SHA256.HashData(Encoding.UTF8.GetBytes(given ?? "")),
            SHA256.HashData(Encoding.UTF8.GetBytes(expected)));
}
