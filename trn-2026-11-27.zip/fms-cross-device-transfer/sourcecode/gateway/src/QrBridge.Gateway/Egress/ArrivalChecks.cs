using Microsoft.Extensions.Options;
using QrBridge.Gateway.Exceptions;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;

namespace QrBridge.Gateway.Egress;

/// <summary>
/// The checks every message that arrived over the light passes before it is used, whatever its kind: posted to a
/// service (a Request, <see cref="Workers.InboxWorker"/>) or used by this gateway (a Reply, Receipt or Heartbeat,
/// <see cref="Ingress.AnswerReader"/>). A failure is a <see cref="BridgeRejectException"/>: the row is Rejected.
/// When every check passes the row is marked Verified, which lets it count toward its run's watermark (decision D84).
/// </summary>
public sealed class ArrivalChecks(
    RouteTable routes,
    IInboxRepository inbox,
    IOptions<GatewayDatabaseOptions> bridgeOptions,
    IOptions<GatewayOptions> gatewayOptions)
{
    private readonly GatewayDatabaseOptions _bridge = bridgeOptions.Value;
    private readonly GatewayOptions _gw = gatewayOptions.Value;

    /// <summary>The columns the QR receiver filled in match the header, and the header is acceptable on this side.</summary>
    public async Task CheckAsync(MessageHeader header, InboxMessage row, CancellationToken ct)
    {
        if (header.MessageId != row.MessageId)
            throw new BridgeRejectException("MessageId in the message header does not match the Inbox row.");
        if (header.ServiceName != row.ServiceName || header.Operation != row.Operation)
            throw new BridgeRejectException("Service/operation in the message header does not match the Inbox row.");
        if (header.Kind != row.Kind || header.CorrelationId != row.CorrelationId || header.SequenceRunId != row.SequenceRunId ||
            header.ContentFingerprint != row.ContentFingerprint || header.ExpiresUtc != row.ExpiresUtc || header.Priority != row.Priority)
            throw new BridgeRejectException("Kind/CorrelationId/SequenceRunId/ContentFingerprint/ExpiresUtc/Priority in the message header do not match the Inbox row.");
        // D31: both gateways must run the same routes.json, or a message could be judged by rules its sender never had.
        if (header.CatalogFingerprint != routes.CatalogFingerprint)
            throw new BridgeRejectException("The route catalogue differs from the sender's (routes.json is not the same on both sides). " +
                                            $"Sender {header.CatalogFingerprint ?? "(none)"}, here {routes.CatalogFingerprint}.");
        if (header.Direction != _bridge.ReceiveDirection)
            throw new BridgeRejectException($"Wrong direction {header.Direction}; this side accepts {_bridge.ReceiveDirection}.");
        if (header.PayloadFormat is not (PayloadFormat.RawSoap or PayloadFormat.HttpGet))
            throw new BridgeRejectException($"Unsupported payload format {header.PayloadFormat}.");

        var now = DateTime.UtcNow;
        if (header.CreatedUtc < now - TimeSpan.FromDays(_gw.ReplayWindowDays))
            throw new BridgeRejectException($"Message is older than the {_gw.ReplayWindowDays}-day replay window.");
        if (header.CreatedUtc > now + TimeSpan.FromMinutes(_gw.MaxClockSkewMinutes))
            throw new BridgeRejectException("Message is dated in the future (check NTP on both sides).");

        // D84 (G-13): an old or reused number is refused whatever the clocks say. Only on a row's first check: a row
        // checked before (posted again after a "surely not sent" failure, or requeued) may itself have moved the watermark.
        if (!row.Verified && await inbox.FindSequenceConflictAsync(row, ct) is { } reason)
            throw new BridgeRejectException(reason);
        await inbox.MarkVerifiedAsync(row.MessageId, CancellationToken.None);
    }
}
