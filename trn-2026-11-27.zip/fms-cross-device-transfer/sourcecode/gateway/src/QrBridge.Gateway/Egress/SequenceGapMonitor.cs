using Microsoft.Extensions.Options;
using QrBridge.Shared;
using QrBridge.Shared.Data.Repositories;

namespace QrBridge.Gateway.Egress;

/// <summary>
/// Finds messages that never arrived over the light (G-02, decision D29): missing numbers in the other side's
/// sequence, per run of its counter. MaintenanceWorker checks once a minute; /health shows the latest
/// result without running the query itself (the load balancer probes it often, and rows are never deleted).
/// A gap stays until the message arrives, the sender's counter starts a new run, or an operator acknowledges it.
/// Each check also moves the runs' watermarks (decision D84: how an old message is recognised by its number).
/// </summary>
public sealed class SequenceGapMonitor(
    IInboxRepository inbox,
    IOptions<GatewayDatabaseOptions> bridgeOptions,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<SequenceGapMonitor> logger)
{
    private readonly Direction _direction = bridgeOptions.Value.ReceiveDirection;
    private readonly TimeSpan _grace = TimeSpan.FromMinutes(gatewayOptions.Value.GapGraceMinutes);
    private readonly Lock _lock = new();
    private HashSet<SequenceGap> _logged = [];

    /// <summary>The gaps found by the last check (empty before the first one).</summary>
    public IReadOnlyList<SequenceGap> Current { get; private set; } = [];

    /// <summary>When the last check ran (UTC); null before the first one.</summary>
    public DateTime? CheckedUtc { get; private set; }

    public async Task<IReadOnlyList<SequenceGap>> CheckAsync(CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        await inbox.AdvanceSequenceWatermarksAsync(_direction, ct);
        var gaps = await inbox.FindSequenceGapsAsync(_direction, now - _grace, ct);

        lock (_lock)
        {
            // Warn once per gap (ids and numbers only, never payloads), not on every run.
            foreach (var gap in gaps.Where(g => !_logged.Contains(g)))
                logger.LogWarning(
                    "Light: {Count} message(s) {From}–{To} of sender run {RunId} ({Direction}) never arrived (missing since {Since:u}). " +
                    "Lost on the light? Acknowledge once handled.",
                    gap.Count, gap.FromSequence, gap.ToSequence, gap.SequenceRunId, gap.Direction, gap.MissingSinceUtc);
            _logged = [.. gaps];
            Current = gaps;
            CheckedUtc = now;
        }
        return gaps;
    }
}
