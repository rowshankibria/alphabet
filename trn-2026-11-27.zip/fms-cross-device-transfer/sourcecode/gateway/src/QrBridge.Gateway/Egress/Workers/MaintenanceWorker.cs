using Microsoft.Extensions.Options;
using QrBridge.Shared;
using QrBridge.Shared.Data.Repositories;

namespace QrBridge.Gateway.Egress.Workers;

/// <summary>
/// Housekeeping, once a minute:
///   - Inbox rows stuck in Delivering (worker crashed / app pool recycled mid-POST) are settled from the Reply already
///     sent, or become Unknown with an Unknown Reply: never posted again on their own (decisions D9, D46)
///   - Outbox rows aired with no Receipt after Gateway:ReceiptTimeoutSeconds are aired again, or become Failed when out
///     of tries or expired (decisions D9, D65–D67)
///   - look for messages that never arrived (sequence gaps, <see cref="SequenceGapMonitor"/>)
///   - a Heartbeat message when this side has sent nothing for a while, and a warning when the far side is silent
///     (<see cref="FarSideMonitor"/>, decisions D80–D83)
///   - heartbeat + warnings when something needs an operator, light and service problems separately
/// Rows are never deleted (decision D28): operators archive them manually.
/// Outbox rows stuck in Sending are the QR sender's responsibility (it owns them).
/// </summary>
public sealed class MaintenanceWorker(
    IInboxRepository inbox,
    IOutboxRepository outbox,
    IHeartbeatRepository heartbeats,
    SequenceGapMonitor gaps,
    FarSideMonitor farSide,
    AnswerWriter answers,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<MaintenanceWorker> logger) : BackgroundService
{
    private readonly GatewayOptions _gw = gatewayOptions.Value;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await Task.Yield();
        var interval = TimeSpan.FromSeconds(Math.Max(10, _gw.MaintenanceIntervalSeconds));

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await RunOnceAsync(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Maintenance run failed");
            }

            try { await Task.Delay(interval, stoppingToken); }
            catch (OperationCanceledException) { break; }
        }
    }

    private async Task RunOnceAsync(CancellationToken ct)
    {
        int stuck = await answers.RecoverStuckAsync(TimeSpan.FromMinutes(_gw.LockTimeoutMinutes), ct);
        if (stuck > 0)
            logger.LogWarning("Service: {Count} Inbox message(s) found still Delivering after a crash or restart: settled from their Reply, or Unknown (may have reached the service)", stuck);

        var unconfirmed = await outbox.ReairUnconfirmedAsync(TimeSpan.FromSeconds(_gw.ReceiptTimeoutSeconds), _gw.MaxAirAttempts, ct);
        foreach (var m in unconfirmed)
            logger.LogWarning("Light: {Kind} {MessageId} {Service}.{Operation} {Status}: {Reason}",
                m.Kind, m.MessageId, m.ServiceName, m.Operation, m.NewStatus == OutboxLightStatus.Failed ? "Failed, operator action needed" : "queued to air again", m.Reason);

        var missing = await gaps.CheckAsync(ct); // logs each new gap itself
        await farSide.SendHeartbeatIfIdleAsync(DateTime.UtcNow, ct);
        var far = await farSide.GetAsync(DateTime.UtcNow, ct);
        var oc = await outbox.GetCountsAsync(ct);
        var ic = await inbox.GetCountsAsync(ct);

        // Light problems (screens, cameras, QR apps, damaged or foreign messages)
        if (far.Silent)
            logger.LogWarning("Light: nothing heard from the far side since {Since} (over {Minutes} min) — is the light or the far gateway down?",
                far.LastHeardUtc?.ToString("u") ?? "this gateway started", far.SilentAfterMinutes);
        if (oc.Light[OutboxLightStatus.Failed] > 0)
            logger.LogWarning("Light: {Count} Outbox message(s) Failed (never confirmed by the far side) — operator action needed", oc.Light[OutboxLightStatus.Failed]);
        if (ic.Light[InboxLightStatus.Rejected] > 0)
            logger.LogWarning("Light: {Count} Inbox message(s) Rejected — check for tampering or misconfiguration", ic.Light[InboxLightStatus.Rejected]);
        if (oc.OldestUndeliveredUtc is { } oldest && DateTime.UtcNow - oldest > TimeSpan.FromMinutes(30))
            logger.LogWarning("Light: oldest unconfirmed Outbox message is from {Oldest:u} — is the link down?", oldest);

        // Service problems (the real services on this side)
        foreach (var status in OperatorServiceStatuses.Where(s => ic.Service[s] > 0))
            logger.LogWarning("Service: {Count} Inbox message(s) {Status} — operator action needed", ic.Service[status], status);

        await heartbeats.BeatAsync(Components.MaintenanceWorker,
            $"outbox light p={oc.Light[OutboxLightStatus.Pending]} s={oc.Light[OutboxLightStatus.Sending]} a={oc.Light[OutboxLightStatus.Aired]} f={oc.Light[OutboxLightStatus.Failed]}; " +
            $"inbox light rej={ic.Light[InboxLightStatus.Rejected]} missing={missing.Sum(g => g.Count)}; inbox service p={ic.Service[InboxServiceStatus.Pending]} " +
            $"r={ic.Service[InboxServiceStatus.Retrying]} unk={ic.Service[InboxServiceStatus.Unknown]} " +
            $"ref={ic.Service[InboxServiceStatus.Refused]} nd={ic.Service[InboxServiceStatus.NotDelivered]}", ct);
        await heartbeats.BeatAsync(Components.GatewayApi, Environment.MachineName, ct);
    }

    /// <summary>Inbox service outcomes that wait for an operator (none is re-posted on its own).</summary>
    public static readonly IReadOnlyList<InboxServiceStatus> OperatorServiceStatuses =
        [InboxServiceStatus.Unknown, InboxServiceStatus.Refused, InboxServiceStatus.NotDelivered];
}
