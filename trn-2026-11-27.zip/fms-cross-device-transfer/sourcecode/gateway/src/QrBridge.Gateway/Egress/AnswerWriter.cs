using Microsoft.Extensions.Options;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;

namespace QrBridge.Gateway.Egress;

/// <summary>
/// The Receiver part's answers over the opposite lane (fix plan §4.1). Both go into this side's Outbox through
/// <see cref="OutboxWriter"/> and are carried back like any message; nothing posts them to a service.
///   Receipt — "this message crossed the light" (decision D44): one per arrived message, again when it arrives twice.
///   Reply   — what happened to a Request (D43, D45): its final outcome, HTTP status, a plain-words reason and the
///             real answer byte for byte. Written BEFORE the Inbox row is marked (D46), so a crash in between leaves a
///             row still Delivering whose Reply already exists; <see cref="RecoverStuckAsync"/> settles it from that Reply.
/// </summary>
public sealed class AnswerWriter(
    OutboxWriter writer,
    IOutboxRepository outbox,
    IInboxRepository inbox,
    MessageSerializer serializer,
    IOptions<GatewayDatabaseOptions> bridgeOptions,
    ILogger<AnswerWriter> logger)
{
    private const int MaxReceiptsPerPass = 100;
    private const int MaxContentTypeLength = 4096;

    private const string StuckComment =
        "Found still delivering after a crash or restart: the POST may have reached the service, which may have processed it. Check before resending.";

    private readonly int _maxAnswerBytes = bridgeOptions.Value.MaxPayloadBytes;

    /// <summary>
    /// Ends a Request: sends its Reply, then marks its Inbox row with the same outcome. <paramref name="request"/> is
    /// null when the message could not be opened (it is then Rejected).
    /// </summary>
    public async Task FinishAsync(InboxMessage row, MessageHeader? request, ServiceOutcome outcome, int? httpStatus, string comment,
                                  string? downstreamResult = null, string? contentType = null, byte[]? answer = null)
    {
        string note = "";
        if (answer is { Length: var size } && size > _maxAnswerBytes)
        {
            note = $" The answer ({size} bytes) was too large to carry back (limit {_maxAnswerBytes}).";
            answer = null;
        }
        if (contentType is { Length: > MaxContentTypeLength }) contentType = null;

        var reply = new MessageHeader
        {
            Kind = MessageKind.Reply,
            CorrelationId = row.MessageId,
            ServiceName = row.ServiceName,
            Operation = row.Operation,
            BusinessType = row.BusinessType ?? "",
            Path = request?.Path ?? "",
            ContentType = answer is null ? "" : contentType ?? "",
            Outcome = outcome,
            ServiceHttpStatus = httpStatus,
            ServiceComment = ForHeader(comment, note),
        };

        try
        {
            await writer.EnqueueAsync(reply, answer ?? [], ct: CancellationToken.None);
        }
        catch (Exception ex) when (ex is InvalidDataException or ArgumentException)
        {
            // Cannot happen with the values above; if it does, the row must still be settled for an operator.
            logger.LogError(ex, "Could not write the Reply for {MessageId} ({Outcome})", row.MessageId, outcome);
        }

        await MarkAsync(row.MessageId, outcome, httpStatus, comment, downstreamResult);
    }

    /// <summary>
    /// Rows still Delivering after <paramref name="lockTimeout"/> (crash or recycle during the POST, decision D46): the
    /// outcome of the Reply already sent for <b>this</b> attempt, if there is one; otherwise Unknown with an Unknown Reply.
    /// A Reply written before the row's current claim belongs to an earlier attempt (an operator requeued it, D64): the
    /// new POST may have reached the service, so it is not adopted. Never posted again.
    /// </summary>
    public async Task<int> RecoverStuckAsync(TimeSpan lockTimeout, CancellationToken ct)
    {
        var stuck = await inbox.FindStuckAsync(lockTimeout, ct);
        foreach (var row in stuck)
        {
            var sent = await outbox.FindLastReplyToAsync(row.MessageId, ct);
            if (sent is not null && row.LockedUtc is { } claimed && sent.CreatedUtc < claimed) sent = null;
            MessageHeader? reply = null;
            try { reply = sent is null ? null : MessageSerializer.PeekHeader(sent.MessageBytes); }
            catch (InvalidDataException) { /* unreadable: settle it as Unknown below */ }

            if (reply?.Outcome is { } outcome)
            {
                logger.LogWarning("{MessageId} found still Delivering; its Reply was already sent: {Outcome}", row.MessageId, outcome);
                await MarkAsync(row.MessageId, outcome, reply.ServiceHttpStatus,
                    $"Settled after a restart from the Reply already sent: {reply.ServiceComment}", null);
            }
            else
            {
                logger.LogWarning("{MessageId} found still Delivering after a crash or restart: Unknown", row.MessageId);
                await FinishAsync(row, null, ServiceOutcome.Unknown, null, StuckComment);
            }
        }
        return stuck.Count;
    }

    /// <summary>
    /// Layer 3b (decision D58): <paramref name="row"/> has the same content as <paramref name="earlier"/>, which the real
    /// service already accepted within the retry window. It is not posted; it ends Done with the earlier Reply's answer.
    /// </summary>
    public async Task ReuseDoneAsync(InboxMessage row, MessageHeader request, SameContent earlier)
    {
        var sent = await outbox.FindLastReplyToAsync(earlier.MessageId, CancellationToken.None);
        MessageHeader? reply = null;
        byte[]? answer = null;
        try { if (sent is not null) (reply, answer) = serializer.Deserialize(sent.MessageBytes); }
        catch (InvalidDataException) { /* unreadable: Done without the answer; the caller then gets the hold-timeout answer */ }

        logger.LogWarning("{MessageId} not posted: the same content arrived as {Earlier}, already done; its answer is reused",
            row.MessageId, earlier.MessageId);
        await FinishAsync(row, request, ServiceOutcome.Done, reply?.ServiceHttpStatus,
            $"Not posted: the same content arrived as {earlier.MessageId} within the retry window and the service already accepted it; its answer is reused.",
            earlier.DownstreamResult, reply?.ContentType, answer is { Length: > 0 } ? answer : null);
    }

    /// <summary>Queues the Receipts owed (decision D44); returns how many.</summary>
    public async Task<int> SendDueReceiptsAsync(CancellationToken ct)
    {
        var due = await inbox.FindDueReceiptsAsync(MaxReceiptsPerPass, ct);
        foreach (var arrived in due)
        {
            await writer.EnqueueAsync(new MessageHeader
            {
                Kind = MessageKind.Receipt,
                CorrelationId = arrived.MessageId,
                ServiceName = arrived.ServiceName,
                Operation = arrived.Operation,
                BusinessType = arrived.BusinessType ?? "",
                Path = "",
                ContentType = "",
            }, [], ct: ct);
            // After the Receipt is committed: a crash in between only sends one Receipt twice, which is harmless.
            await inbox.ClearReceiptDueAsync(arrived, ct);
        }
        return due.Count;
    }

    private Task MarkAsync(Guid id, ServiceOutcome outcome, int? httpStatus, string comment, string? downstreamResult) => outcome switch
    {
        ServiceOutcome.Done => inbox.MarkDoneAsync(id, httpStatus, comment, downstreamResult, CancellationToken.None),
        ServiceOutcome.Refused => inbox.MarkRefusedAsync(id, httpStatus, comment, downstreamResult, CancellationToken.None),
        ServiceOutcome.Expired => inbox.MarkExpiredAsync(id, comment, CancellationToken.None),
        ServiceOutcome.NotDelivered => inbox.MarkNotDeliveredAsync(id, httpStatus, comment, CancellationToken.None),
        ServiceOutcome.Rejected => inbox.MarkRejectedAsync(id, comment, CancellationToken.None),
        _ => inbox.MarkUnknownAsync(id, httpStatus, comment, downstreamResult, CancellationToken.None),
    };

    /// <summary>One line, no control characters, within the header's limit; <paramref name="note"/> is always kept whole.</summary>
    private static string ForHeader(string comment, string note = "")
    {
        int room = MessageSerializer.MaxServiceCommentLength - note.Length;
        string clean = new(comment.Select(c => char.IsControl(c) ? ' ' : c).ToArray());
        return (clean.Length <= room ? clean : clean[..room]) + note;
    }
}
