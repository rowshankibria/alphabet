using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using QrDiode.Core.Crypto;

namespace QrDiode.Core.Tests;

/// <summary>
/// An in-memory company PKI for certificate mode tests: a self-signed Root CA that issues ECDSA P-256 machine
/// certificates (and, when asked, an Issuing CA under it). Nothing touches the Windows Certificate Store.
/// </summary>
public sealed class TestPki : IDisposable
{
    public X509Certificate2 Root { get; }

    public TestPki(string name = "QrDiode Test Root CA")
    {
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var request = new CertificateRequest($"CN={name}", key, HashAlgorithmName.SHA256);
        request.CertificateExtensions.Add(new X509BasicConstraintsExtension(true, false, 0, true));
        request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.KeyCertSign | X509KeyUsageFlags.CrlSign, true));
        request.CertificateExtensions.Add(new X509SubjectKeyIdentifierExtension(request.PublicKey, false));
        Root = request.CreateSelfSigned(DateTimeOffset.UtcNow.AddYears(-5), DateTimeOffset.UtcNow.AddYears(10));
    }

    /// <summary>The Root's public certificate, a fresh instance (a validator takes ownership of its CA).</summary>
    public X509Certificate2 PublicRoot() => X509CertificateLoader.LoadCertificate(Root.RawData);

    /// <summary>A machine certificate (with its private key) for <paramref name="name"/>, issued by the Root or by <paramref name="issuer"/>.</summary>
    public X509Certificate2 IssueMachine(string name, X509Certificate2? issuer = null,
        DateTimeOffset? notBefore = null, DateTimeOffset? notAfter = null)
    {
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var request = new CertificateRequest($"CN={name}, O=QrDiode Tests", key, HashAlgorithmName.SHA256);
        request.CertificateExtensions.Add(new X509BasicConstraintsExtension(false, false, 0, true));
        request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature, true));
        var san = new SubjectAlternativeNameBuilder();
        san.AddDnsName(name);
        request.CertificateExtensions.Add(san.Build());
        using var certificate = request.Create(issuer ?? Root,
            notBefore ?? DateTimeOffset.UtcNow.AddHours(-1), notAfter ?? DateTimeOffset.UtcNow.AddYears(1),
            RandomNumberGenerator.GetBytes(16));
        return certificate.CopyWithPrivateKey(key);
    }

    /// <summary>An Issuing CA (with its private key) under the Root.</summary>
    public X509Certificate2 IssueIssuingCa(string name = "QrDiode Test Issuing CA")
    {
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var request = new CertificateRequest($"CN={name}", key, HashAlgorithmName.SHA256);
        request.CertificateExtensions.Add(new X509BasicConstraintsExtension(true, true, 0, true));
        request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.KeyCertSign | X509KeyUsageFlags.CrlSign, true));
        request.CertificateExtensions.Add(new X509SubjectKeyIdentifierExtension(request.PublicKey, false));
        using var certificate = request.Create(Root, DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddYears(5),
            RandomNumberGenerator.GetBytes(16));
        return certificate.CopyWithPrivateKey(key);
    }

    /// <summary>Certificate mode keys for a machine named <paramref name="name"/>: its certificate and a fresh ECDH key.</summary>
    public X509EndpointKeys Endpoint(string name, X509Certificate2? issuer = null) =>
        X509EndpointKeys.FromCertificate(IssueMachine(name, issuer), ECDiffieHellman.Create(ECCurve.NamedCurves.nistP256));

    /// <summary>A validator anchored at this Root that pairs only with <paramref name="expectedPeer"/>.</summary>
    public CertHelloValidator Validator(string expectedPeer, TimeProvider? clock = null) =>
        new(PublicRoot(), expectedPeer, clock: clock);

    public void Dispose() => Root.Dispose();
}
