using System.Numerics;
using System.Security.Cryptography;
using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using Xunit;

namespace QrDiode.Core.Tests;

public class ManifestAndAuditTests
{
    // v2 body offsets (see the layout comment in TransferManifest).
    private const int OriginalSizeOffset = 124;

    private static TransferManifest MakeManifest(EphemeralEndpointKeys sender, EphemeralEndpointKeys receiver,
        ushort symbolSize = 1350, long originalSize = 20_000, long compressedSize = 10_000,
        CompressionAlg compression = CompressionAlg.Brotli) => new()
    {
        SessionId = Guid.NewGuid(),
        TimestampUnixMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
        Counter = 42,
        CounterRunId = Guid.NewGuid(),
        SenderSigningKeyId = sender.SigningKeyId,
        ReceiverAgreementKeyId = receiver.AgreementKeyId,
        Salt = new byte[32],
        Nonce = new byte[12],
        SymbolSize = symbolSize,
        SourceSymbolCount = (uint)((compressedSize + Envelope.TagSize + symbolSize - 1) / symbolSize),
        LtSeed = 999,
        RedundancyHint = 3,
        OriginalSize = originalSize,
        CompressedSize = compressedSize,
        CiphertextSize = compressedSize + Envelope.TagSize,
        Compression = compression,
        CiphertextSha256 = new byte[32],
        ContentType = ContentKind.Xml,
        Filename = "batch-042.xml",
    };

    [Fact]
    public void Manifest_SerializeParse_RoundTrips()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        var manifest = MakeManifest(sender, receiver);

        byte[] body = manifest.Serialize();
        Assert.True(TransferManifest.TryParse(body, out var parsed, out var error), error);

        Assert.Equal(manifest.SessionId, parsed!.SessionId);
        Assert.Equal(manifest.Counter, parsed.Counter);
        Assert.Equal(manifest.CounterRunId, parsed.CounterRunId);
        Assert.Equal(manifest.Filename, parsed.Filename);
        Assert.Equal(manifest.SymbolSize, parsed.SymbolSize);
        Assert.Equal(manifest.SourceSymbolCount, parsed.SourceSymbolCount);
        Assert.Equal(manifest.Compression, parsed.Compression);
        Assert.Equal(manifest.ContentType, parsed.ContentType);
        Assert.Equal(manifest.CiphertextSize, parsed.CiphertextSize);
        Assert.Equal(manifest.OriginalSize, parsed.OriginalSize);
    }

    [Fact]
    public void Manifest_SignVerify_DetectsTamper()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        var manifest = MakeManifest(sender, receiver);

        byte[] body = manifest.Serialize();
        byte[] sig = manifest.Sign(sender.SigningKey, body);
        Assert.Equal(64, sig.Length);
        Assert.True(TransferManifest.VerifySignature(sender.SigningKey, body, sig));

        byte[] tampered = (byte[])body.Clone();
        tampered[24] ^= 0x01; // counter field
        Assert.False(TransferManifest.VerifySignature(sender.SigningKey, tampered, sig));

        using var otherKey = new EphemeralEndpointKeys();
        Assert.False(TransferManifest.VerifySignature(otherKey.SigningKey, body, sig));
    }

    [Fact]
    public void Signature_IsAlwaysLowS_AndTheFlippedFormIsRefused()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        var manifest = MakeManifest(sender, receiver);
        byte[] body = manifest.Serialize();
        var n = new BigInteger(Convert.FromHexString("FFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551"),
            isUnsigned: true, isBigEndian: true);

        // About half of raw ECDSA signatures are high-S; 32 tries make it all but certain both kinds appear.
        for (int i = 0; i < 32; i++)
        {
            byte[] sig = manifest.Sign(sender.SigningKey, body);
            var s = new BigInteger(sig.AsSpan(32, 32), isUnsigned: true, isBigEndian: true);
            Assert.True(s <= n >> 1, "Sign must always produce the low-S form.");
            Assert.True(TransferManifest.VerifySignature(sender.SigningKey, body, sig));

            // (r, n − s) is the same signature in its other form: plain ECDSA accepts it, we do not.
            byte[] flipped = (byte[])sig.Clone();
            byte[] high = (n - s).ToByteArray(isUnsigned: true, isBigEndian: true);
            Array.Clear(flipped, 32, 32);
            high.CopyTo(flipped, 64 - high.Length);
            Assert.True(sender.SigningKey.VerifyData(body, flipped, HashAlgorithmName.SHA256));
            Assert.False(TransferManifest.VerifySignature(sender.SigningKey, body, flipped));
        }
    }

    [Theory]
    [InlineData(OriginalSizeOffset, 0L)]                                   // original size = 0
    [InlineData(OriginalSizeOffset, -5L)]                                  // negative size
    [InlineData(OriginalSizeOffset, TransferManifest.MaxPayloadBytes + 1)] // beyond the 64 MB envelope
    public void Manifest_InsaneSizes_AreRejected(int offset, long value)
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        byte[] body = MakeManifest(sender, receiver).Serialize();
        System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian(body.AsSpan(offset), value);

        Assert.False(TransferManifest.TryParse(body, out _, out _));
    }

    [Fact]
    public void Manifest_TinySymbols_AreRejected_UnlessOneSymbolHoldsEverything()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();

        // 10 KB in 100-byte symbols: K = 101. A manifest like this asks for huge tables at symbol size 1.
        var tiny = MakeManifest(sender, receiver, symbolSize: 100);
        Assert.False(TransferManifest.TryParse(tiny.Serialize(), out _, out string error));
        Assert.Contains("too small", error);

        // A small payload that fits one symbol (K = 1) is fine at any size.
        var single = MakeManifest(sender, receiver, symbolSize: 100, originalSize: 84, compressedSize: 84,
            compression: CompressionAlg.None);
        Assert.True(TransferManifest.TryParse(single.Serialize(), out var parsed, out error), error);
        Assert.Equal(1u, parsed!.SourceSymbolCount);
    }

    [Fact]
    public void Manifest_TooManySymbols_OrOversizedSymbol_AreRejected()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();

        var many = MakeManifest(sender, receiver, symbolSize: 256,
            originalSize: TransferManifest.MaxPayloadBytes, compressedSize: TransferManifest.MaxPayloadBytes,
            compression: CompressionAlg.None);
        Assert.False(TransferManifest.TryParse(many.Serialize(), out _, out string error));
        Assert.Contains("Too many", error);

        var huge = MakeManifest(sender, receiver, symbolSize: Framing.FrameFormat.MaxSymbolSize + 1);
        Assert.False(TransferManifest.TryParse(huge.Serialize(), out _, out error));
        Assert.Contains("Symbol size", error);
    }

    [Fact]
    public void Manifest_TruncatedOrPadded_IsRejected()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        byte[] body = MakeManifest(sender, receiver).Serialize();

        Assert.False(TransferManifest.TryParse(body.AsSpan(0, body.Length - 1), out _, out _));
        Assert.False(TransferManifest.TryParse(body.Concat(new byte[1]).ToArray(), out _, out _));
        Assert.False(TransferManifest.TryParse(ReadOnlySpan<byte>.Empty, out _, out _));
    }

    [Fact]
    public void ReplayGuard_TimestampWindow_Enforced()
    {
        var clock = new FakeTimeProvider(DateTimeOffset.UtcNow);
        var guard = new InMemoryReplayGuard(clock);
        byte[] keyId = new byte[8];
        var run = Guid.NewGuid();

        long fresh = clock.GetUtcNow().ToUnixTimeMilliseconds();
        Assert.Equal(ReplayVerdict.Fresh, guard.Check(keyId, Guid.NewGuid(), run, 1, fresh));

        long stale = clock.GetUtcNow().AddDays(-3).ToUnixTimeMilliseconds();
        Assert.Equal(ReplayVerdict.TimestampOutOfWindow, guard.Check(keyId, Guid.NewGuid(), run, 1, stale));

        long future = clock.GetUtcNow().AddDays(3).ToUnixTimeMilliseconds();
        Assert.Equal(ReplayVerdict.TimestampOutOfWindow, guard.Check(keyId, Guid.NewGuid(), run, 1, future));
    }

    [Fact]
    public void ReplayGuard_Watermark_IsPerCounterRun()
    {
        var guard = new InMemoryReplayGuard();
        byte[] keyId = new byte[8];
        long now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        var oldRun = Guid.NewGuid();
        var newRun = Guid.NewGuid();

        guard.Commit(keyId, Guid.NewGuid(), oldRun, 812);

        // The old run's recordings stay stale…
        Assert.Equal(ReplayVerdict.StaleCounter, guard.Check(keyId, Guid.NewGuid(), oldRun, 811, now));
        // …while a sender whose counter file was lost starts a new run at 1 and is accepted.
        Assert.Equal(ReplayVerdict.Fresh, guard.Check(keyId, Guid.NewGuid(), newRun, 1, now));
    }

    [Fact]
    public void AuditLog_ChainVerifies_AndDetectsTamper()
    {
        using var folder = new TempFolder();
        string path = folder.File("audit.jsonl");

        var log = new AuditLog(path);
        log.Append("transfer.completed", new Dictionary<string, string> { ["session"] = "abc", ["file"] = "x.xml" });
        log.Append("transfer.rejected", new Dictionary<string, string> { ["reason"] = "replay" });
        log.Append("transfer.completed", new Dictionary<string, string> { ["session"] = "def" });

        Assert.Equal(-1, AuditLog.Verify(path)); // intact

        // Tamper with the middle record.
        var lines = File.ReadAllLines(path);
        lines[1] = lines[1].Replace("replay", "REPLAY");
        File.WriteAllLines(path, lines);

        Assert.Equal(1, AuditLog.Verify(path)); // chain broken at record 1
    }

    [Fact]
    public void AuditLog_SurvivesReopen_ChainContinues()
    {
        using var folder = new TempFolder();
        string path = folder.File("audit.jsonl");

        new AuditLog(path).Append("a", new Dictionary<string, string>());
        new AuditLog(path).Append("b", new Dictionary<string, string>()); // reopened process
        Assert.Equal(-1, AuditLog.Verify(path));
    }

    [Fact]
    public void AuditLog_RollsOver_AndTheChainRunsAcrossFilesAndRestarts()
    {
        using var folder = new TempFolder();
        string path = folder.File("receiver-audit.jsonl");

        var log = new AuditLog(path, maxFileBytes: 600);
        for (int i = 0; i < 20; i++)
            log.Append("receive.completed", new Dictionary<string, string> { ["session"] = $"s{i}" });
        new AuditLog(path, maxFileBytes: 600).Append("receive.started", new Dictionary<string, string>()); // restart

        var result = AuditLog.VerifyChain(path);
        Assert.True(result.Intact, result.Problem);
        Assert.Equal(21, result.Records);
        Assert.True(result.Files > 2, $"Expected several files, got {result.Files}.");
    }

    [Fact]
    public void AuditLog_TamperInAnArchivedFile_IsFound()
    {
        using var folder = new TempFolder();
        string path = folder.File("sender-audit.jsonl");

        var log = new AuditLog(path, maxFileBytes: 600);
        for (int i = 0; i < 12; i++)
            log.Append("send.started", new Dictionary<string, string> { ["file"] = $"f{i}.xml" });

        string archive = Directory.GetFiles(folder.Path, "sender-audit.*.jsonl").Order().First();
        var lines = File.ReadAllLines(archive);
        lines[0] = lines[0].Replace("f0.xml", "fX.xml");
        File.WriteAllLines(archive, lines);

        var result = AuditLog.VerifyChain(path);
        Assert.False(result.Intact);
        Assert.Equal(0, result.FirstBrokenIndex);
        Assert.Equal(archive, result.BrokenFile);
    }

    [Fact]
    public void AuditLog_TornLine_IsReported_NotThrown_AndAppendContinues()
    {
        using var folder = new TempFolder();
        string path = folder.File("audit.jsonl");

        new AuditLog(path).Append("a", new Dictionary<string, string>());
        File.AppendAllText(path, "{\"ts\":\"2026-11-26T10:00:00Z\",\"ev"); // a crash mid-write
        new AuditLog(path).Append("b", new Dictionary<string, string>());  // continues from record a

        var result = AuditLog.VerifyChain(path);
        Assert.False(result.Intact);
        Assert.Equal(1, result.FirstBrokenIndex);
        Assert.Contains("torn", result.Problem);
    }

    private sealed class FakeTimeProvider(DateTimeOffset now) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => now;
    }
}
