using System.Buffers.Binary;
using System.IO.Hashing;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Net.Codecrete.QrCodeGenerator;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;

namespace QrDiode.Core.Tests;

/// <summary>
/// Certificate mode (docs/x509-certificate-handshake-plan.md): the two sides pair over the cameras with CertHello frames,
/// only the expected peer of the pinned company CA is accepted, and the machine's keyexchange.json picks the mechanism behind
/// <see cref="IKeyExchange"/> (the key ceremony by default, unchanged).
/// </summary>
public class X509HandshakeTests
{
    private const string Corp = "qrbridge-corp.test";
    private const string Dmz = "qrbridge-dmz.test";
    private const string Thumbprint = "0123456789ABCDEF0123456789ABCDEF01234567";

    // ═══════════════════ choosing the key exchange (C:\ProgramData\QrDiode\keyexchange.json) ═══════════════════

    private const string SettingsFile = "keyexchange.json";

    [Fact]
    public void Without_a_key_exchange_file_the_key_ceremony_is_used_as_before()
    {
        using var folder = new TempFolder(); // no keyexchange.json at all
        var exchange = KeyExchanges.Load(new QrDiodeOptions(), folder.File(SettingsFile));
        using var keys = new EphemeralEndpointKeys();

        Assert.IsType<KeyCeremonyExchange>(exchange);
        Assert.True(exchange.UsesEndpointName);
        Assert.True(exchange.AllowsDemo);
        Assert.False(exchange.PairsOverTheLight);
        Assert.Null(exchange.BuildPairingFrame(keys));
        Assert.Equal(["init", "export", "import", "demo", "demo-clean"], exchange.Commands.Select(c => c.Name));
    }

    [Fact]
    public void KeyExchange_Certificate_pairs_over_the_light_with_the_expected_peer()
    {
        using var folder = new TempFolder();
        File.WriteAllText(folder.File(SettingsFile), $$"""
            { // set once per machine for the Sender, the Receiver and the KeyCeremony tool
              "KeyExchange": "Certificate",
              "Certificate": { "Location": "Cert:\\CurrentUser\\My", "OwnSubject": "{{Corp}}",
                               "TrustedCaThumbprint": "{{Thumbprint}}", "ExpectedPeerSubject": "{{Dmz}}" } }
            """);
        var exchange = KeyExchanges.Load(new QrDiodeOptions(), folder.File(SettingsFile));
        using var pki = new TestPki();
        using var corp = pki.Endpoint(Corp);

        Assert.IsType<CertificateKeyExchange>(exchange);
        Assert.False(exchange.UsesEndpointName);
        Assert.Equal(Corp, exchange.Identity);
        Assert.False(exchange.AllowsDemo);
        Assert.True(exchange.PairsOverTheLight);
        Assert.Equal(Dmz, exchange.ExpectedPeer);
        Assert.True(CertHello.TryRead(exchange.BuildPairingFrame(corp)!, out _));
        Assert.Equal(["check-cert", "export-hello", "import-hello"], exchange.Commands.Select(c => c.Name));
    }

    [Theory]
    [InlineData("""{ "Certificate": { "Location": "Cert:\\LocalMachine\\My" } }""")] // filled in, but KeyCeremony (the default)
    [InlineData("""{ "KeyExchange": "Certificate" }""")]
    [InlineData("""{ "KeyExchange": "Certificate", "Certificate": { "Location": "Cert:\\LocalMachine\\Root", "OwnSubject": "a", "TrustedCaThumbprint": "0123456789ABCDEF0123456789ABCDEF01234567", "ExpectedPeerSubject": "b" } }""")]
    [InlineData("""{ "KeyExchange": "Certificate", "Certificate": { "Location": "Cert:\\LocalMachine\\My", "OwnSubject": "a", "TrustedCaThumbprint": "0123456789ABCDEF0123456789ABCDEF01234567" } }""")]
    [InlineData("""{ "KeyExchange": "Certificate", "Certificate": { "Location": "Cert:\\LocalMachine\\My", "OwnSubject": "a", "TrustedCaThumbprint": "12AB", "ExpectedPeerSubject": "b" } }""")]
    [InlineData("""{ "KeyExchange": "Magic" }""")]
    [InlineData("""{ "KeyExchange": "KeyCeremony", "Kex": 1 }""")] // a misspelt setting is not ignored
    public void Settings_for_the_wrong_or_half_a_key_exchange_are_refused(string json)
    {
        // A kiosk meant for one mechanism must never quietly run another.
        using var folder = new TempFolder();
        File.WriteAllText(folder.File(SettingsFile), json);
        var error = Assert.Throws<InvalidDataException>(() => KeyExchanges.Load(new QrDiodeOptions(), folder.File(SettingsFile)));
        Assert.Contains(SettingsFile, error.Message); // the operator is told which file to fix
    }

    [Fact]
    public void A_kiosk_refuses_a_key_exchange_file_its_user_can_change()
    {
        // C:\ProgramData lets ordinary users write unless an administrator locks the folder; a temp folder is writable.
        using var folder = new TempFolder();
        File.WriteAllText(folder.File(SettingsFile), """{ "KeyExchange": "KeyCeremony" }""");

        Assert.IsType<KeyCeremonyExchange>(KeyExchanges.Load(new QrDiodeOptions(), folder.File(SettingsFile)));
        var error = Assert.Throws<InvalidDataException>(() =>
            KeyExchanges.Load(new QrDiodeOptions { Production = true }, folder.File(SettingsFile)));
        Assert.Contains("can be changed by this Windows user", error.Message);
    }

    [Fact]
    public void Key_ceremony_mode_ignores_CertHello_frames()
    {
        using var pki = new TestPki();
        using var corp = pki.Endpoint(Corp);
        using var receiver = new EphemeralEndpointKeys();
        var engine = new ReceiveEngine(new InMemoryTrustStore(), new InMemoryReplayGuard(), receiver);

        Assert.Equal(FeedResult.Ignored, engine.Feed(CertHello.Build(corp)));
        Assert.Null(engine.LastPairedPeer);
    }

    // ═══════════════════ pairing ═══════════════════

    [Fact]
    public void Paired_machines_carry_a_transfer_after_exchanging_CertHellos_through_real_QR_codes()
    {
        using var pki = new TestPki();
        using var corp = pki.Endpoint(Corp);
        using var dmz = pki.Endpoint(Dmz);
        using var dmzValidator = pki.Validator(Corp);
        using var corpValidator = pki.Validator(Dmz);
        using var trustFolder = new TempFolder();

        // The DMZ camera reads the Corp screen's CertHello.
        var trust = new ReloadableTrustStore(new InMemoryTrustStore());
        var engine = new ReceiveEngine(trust, new InMemoryReplayGuard(), dmz, new ReceiveOptions { Pairing = dmzValidator });
        byte[] corpHello = OpticalLoopbackTests.RenderAndDecode(QrCode.EncodeBinary(CertHello.Build(corp), QrCode.Ecc.Low));
        Assert.Equal(FeedResult.PeerAccepted, engine.Feed(corpHello));
        Assert.Equal(FeedResult.Ignored, engine.Feed(corpHello)); // the camera reads it again and again: judged once
        var hello = engine.LastPairedPeer!;
        Assert.Equal(corp.SigningKeyId, hello.SigningKeyId);
        Assert.Equal(corp.AgreementKeyId, hello.AgreementKeyId);

        // The DMZ Receiver pins Corp and swaps the trust store under the running engine.
        Assert.Equal(PinOutcome.Pinned, CertificatePins.Save(trustFolder.Path, hello));
        using var pinned = new DirectoryTrustStore(trustFolder.Path, dmzValidator);
        Assert.Equal(Corp, Assert.Single(pinned.Peers).Name);
        trust.Replace(pinned);

        // The Corp camera reads the DMZ CertHello: the Corp Sender now knows whom to encrypt for.
        Assert.True(corpValidator.TryVerify(CertHello.Build(dmz), out var dmzHello, out string reason), reason);
        using var dmzPeer = dmzHello!.ToPeerKeys();

        byte[] payload = RandomNumberGenerator.GetBytes(20_000);
        var session = SendSession.Create(payload, "bundle.qbb", ContentKind.File, corp, dmzPeer, 1, Guid.NewGuid());
        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(session, engine));
        Assert.Equal(payload, engine.Completed!.Plaintext);
    }

    [Fact]
    public void A_CertHello_during_a_transfer_is_ignored_and_the_transfer_completes()
    {
        using var pki = new TestPki();
        using var corp = pki.Endpoint(Corp);
        using var validator = pki.Validator(Corp);
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        var trust = new InMemoryTrustStore();
        trust.Add(PublicKeyBundle.FromKeys("ot", sender).ToPeerKeys());
        using var receiverPeer = PublicKeyBundle.FromKeys("it", receiver).ToPeerKeys();
        var engine = new ReceiveEngine(trust, new InMemoryReplayGuard(), receiver, new ReceiveOptions { Pairing = validator });

        var session = SendSession.Create(RandomNumberGenerator.GetBytes(5_000), "a.bin", ContentKind.File, sender, receiverPeer, 1, Guid.NewGuid());
        Assert.Equal(FeedResult.ManifestAccepted, engine.Feed(session.ManifestFrame));
        Assert.Equal(FeedResult.Ignored, engine.Feed(CertHello.Build(corp)));
        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(session, engine));
    }

    // ═══════════════════ who is refused ═══════════════════

    [Fact]
    public void Another_machine_with_a_certificate_from_the_same_CA_is_refused()
    {
        using var pki = new TestPki();
        using var laptop = pki.Endpoint("laptop-123.test");
        using var validator = pki.Validator(Corp);

        Assert.Contains("is not the expected peer", Refused(validator, CertHello.Build(laptop)));
    }

    [Fact]
    public void The_expected_name_from_another_CA_is_refused()
    {
        using var pki = new TestPki();
        using var rogue = new TestPki("Rogue Root CA");
        using var impostor = rogue.Endpoint(Corp);
        using var validator = pki.Validator(Corp);

        Assert.Contains("does not chain to the trusted CA", Refused(validator, CertHello.Build(impostor)));
    }

    [Fact]
    public void An_expired_certificate_is_refused()
    {
        using var pki = new TestPki();
        using var expired = X509EndpointKeys.FromCertificate(
            pki.IssueMachine(Corp, notBefore: DateTimeOffset.UtcNow.AddYears(-2), notAfter: DateTimeOffset.UtcNow.AddYears(-1)),
            ECDiffieHellman.Create(ECCurve.NamedCurves.nistP256));
        using var validator = pki.Validator(Corp);

        Assert.Contains("NotTimeValid", Refused(validator, CertHello.Build(expired)));
    }

    [Fact]
    public void A_swapped_encryption_key_is_refused()
    {
        using var pki = new TestPki();
        using var corp = pki.Endpoint(Corp);
        using var validator = pki.Validator(Corp);

        // Someone in the middle swaps a byte of the ECDH key and fixes the CRC: the certificate's signature no longer holds.
        byte[] frame = CertHello.Build(corp);
        frame[frame.Length - 4 - 64 - 10] ^= 0x01;
        BinaryPrimitives.WriteUInt32LittleEndian(frame.AsSpan(frame.Length - 4), Crc32.HashToUInt32(frame.AsSpan(0, frame.Length - 4)));

        Assert.Contains("does not verify", Refused(validator, frame));
    }

    [Fact]
    public void A_stale_CertHello_is_refused()
    {
        using var pki = new TestPki();
        using var corp = pki.Endpoint(Corp);
        using var validator = pki.Validator(Corp);

        byte[] recording = CertHello.Build(corp, new FixedClock(DateTimeOffset.UtcNow.AddDays(-3)));
        Assert.Contains("stale", Refused(validator, recording));
    }

    // ═══════════════════ the pinned trust store ═══════════════════

    [Fact]
    public void Certificate_mode_trusts_only_pins_that_still_verify()
    {
        using var pki = new TestPki();
        using var corp = pki.Endpoint(Corp);
        using var dmz = pki.Endpoint(Dmz);
        using var validator = pki.Validator(Corp);
        using var ceremonyKeys = new EphemeralEndpointKeys();
        using var folder = new TempFolder();

        Assert.True(validator.TryVerify(CertHello.Build(corp), out var hello, out _));
        CertificatePins.Save(folder.Path, hello!);
        File.WriteAllText(folder.File("ot-line-1.json"), PublicKeyBundle.FromKeys("ot-line-1", ceremonyKeys).ToJson());
        var edited = PublicKeyBundle.FromPeer(hello!);
        edited.AgreementPublicKeySpki = Convert.ToBase64String(ceremonyKeys.AgreementKey.ExportSubjectPublicKeyInfo());
        File.WriteAllText(folder.File("edited.json"), edited.ToJson());
        using (var dmzValidator = pki.Validator(Dmz))
        {
            Assert.True(dmzValidator.TryVerify(CertHello.Build(dmz), out var dmzHello, out _));
            File.WriteAllText(folder.File("other-peer.json"), PublicKeyBundle.FromPeer(dmzHello!).ToJson());
        }

        using var store = new DirectoryTrustStore(folder.Path, validator);
        Assert.Equal(corp.SigningKeyId, Assert.Single(store.Peers).SigningKeyId);
        Assert.Equal(3, store.Problems.Count);
        Assert.Contains(store.Problems, p => p.Contains("key ceremony bundle"));
        Assert.Contains(store.Problems, p => p.Contains("do not match"));
        Assert.Contains(store.Problems, p => p.Contains("is not the expected peer"));
    }

    [Fact]
    public void An_older_CertHello_never_replaces_a_newer_pin()
    {
        using var pki = new TestPki();
        using var current = pki.Endpoint(Corp);
        using var renewed = pki.Endpoint(Corp); // the same machine after a certificate renewal: new keys
        using var validator = pki.Validator(Corp);
        using var folder = new TempFolder();
        var now = DateTimeOffset.UtcNow;

        VerifiedPeer Verify(X509EndpointKeys keys, DateTimeOffset at)
        {
            Assert.True(validator.TryVerify(CertHello.Build(keys, new FixedClock(at)), out var hello, out string reason), reason);
            return hello!;
        }

        Assert.Equal(PinOutcome.Pinned, CertificatePins.Save(folder.Path, Verify(current, now)));
        Assert.Equal(PinOutcome.Unchanged, CertificatePins.Save(folder.Path, Verify(current, now.AddMinutes(1))));
        Assert.Equal(PinOutcome.Older, CertificatePins.Save(folder.Path, Verify(renewed, now.AddHours(-1))));
        Assert.Equal(PinOutcome.Replaced, CertificatePins.Save(folder.Path, Verify(renewed, now.AddMinutes(2))));

        using var store = new DirectoryTrustStore(folder.Path, validator);
        Assert.Equal(renewed.SigningKeyId, Assert.Single(store.Peers).SigningKeyId);
        Assert.Equal(1, CertificatePins.Forget(folder.Path));
    }

    [Fact]
    public void An_issuing_CA_can_be_the_pinned_anchor()
    {
        using var pki = new TestPki();
        using var issuing = pki.IssueIssuingCa();
        using var corp = pki.Endpoint(Corp, issuing);
        byte[] hello = CertHello.Build(corp);

        using (var pinIssuing = new CertHelloValidator(X509CertificateLoader.LoadCertificate(issuing.RawData), Corp))
            Assert.True(pinIssuing.TryVerify(hello, out _, out string reason), reason);
        using (var pinRoot = new CertHelloValidator(pki.PublicRoot(), Corp, intermediates: [X509CertificateLoader.LoadCertificate(issuing.RawData)]))
            Assert.True(pinRoot.TryVerify(hello, out _, out string reason), reason);
        using (var rootWithoutIssuing = pki.Validator(Corp))
            Assert.False(rootWithoutIssuing.TryVerify(hello, out _, out _));
    }

    // ═══════════════════ helpers ═══════════════════

    /// <summary>Feeds the frame to a certificate mode engine that knows no one, expects a refusal and returns its reason.</summary>
    private static string Refused(CertHelloValidator validator, byte[] frame)
    {
        using var keys = new EphemeralEndpointKeys();
        var engine = new ReceiveEngine(new InMemoryTrustStore(), new InMemoryReplayGuard(), keys, new ReceiveOptions { Pairing = validator });
        Assert.Equal(FeedResult.Rejected, engine.Feed(frame));
        Assert.Null(engine.LastPairedPeer);
        return engine.LastRejection;
    }

    private static FeedResult FeedUntilVerdict(SendSession session, ReceiveEngine engine)
    {
        int fed = 0;
        foreach (var frame in session.Carousel())
        {
            if (fed++ > 5_000) break;
            var result = engine.Feed(frame);
            if (result is FeedResult.Completed or FeedResult.Rejected) return result;
        }
        return FeedResult.Ignored;
    }

    private sealed class FixedClock(DateTimeOffset now) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => now;
    }
}
