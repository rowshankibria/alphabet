using System.Security.Cryptography;
using QrDiode.Core.Crypto;
using QrDiode.Core.Framing;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using Xunit;

namespace QrDiode.Core.Tests;

/// <summary>
/// B-03 / S-01 (review Q-02, Q-03, Q-10): data frames are authenticated, so a QR code someone holds
/// up to the camera — even with the right session tag, which is on the screen for anyone — never
/// reaches the decoder.
/// </summary>
public class FrameAuthenticationTests : IDisposable
{
    private static readonly Guid Run = Guid.NewGuid();
    private readonly EphemeralEndpointKeys _sender = new();
    private readonly EphemeralEndpointKeys _receiver = new();
    private readonly InMemoryTrustStore _trust = new();
    private readonly PeerPublicKeys _receiverPeer;

    public FrameAuthenticationTests()
    {
        _trust.Add(PublicKeyBundle.FromKeys("ot", _sender).ToPeerKeys());
        _receiverPeer = PublicKeyBundle.FromKeys("it", _receiver).ToPeerKeys();
    }

    public void Dispose()
    {
        _sender.Dispose();
        _receiver.Dispose();
        _receiverPeer.Dispose();
    }

    [Fact]
    public void AForgedDataFrame_WithTheRightSessionTag_IsIgnored_AndTheSessionCompletes()
    {
        byte[] payload = RandomNumberGenerator.GetBytes(20_000);
        var session = SendSession.Create(payload, "a.bin", ContentKind.File, _sender, _receiverPeer, counter: 1, Run);
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);

        Assert.Equal(FeedResult.ManifestAccepted, engine.Feed(session.ManifestFrame));

        // Symbol 0 with random bytes, a guessed key and a valid CRC: before v2 this poisoned the session.
        byte[] forged = FrameWriter.WriteDataFrame(session.Manifest.SessionTag, 0,
            RandomNumberGenerator.GetBytes(session.Manifest.SymbolSize), RandomNumberGenerator.GetBytes(32));
        Assert.Equal(FeedResult.Ignored, engine.Feed(forged));
        Assert.Equal(1, engine.FramesFailedAuthentication);

        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(session, engine));
        Assert.Equal(payload, engine.Completed!.Plaintext);
    }

    [Fact]
    public void AForgeryForEverySymbol_ShownFirst_CannotStopTheSession()
    {
        byte[] payload = RandomNumberGenerator.GetBytes(30_000);
        var session = SendSession.Create(payload, "b.bin", ContentKind.File, _sender, _receiverPeer, counter: 1, Run);
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        engine.Feed(session.ManifestFrame);

        byte[] fakeKey = RandomNumberGenerator.GetBytes(32);
        for (uint id = 0; id < session.K * 3; id++)
            engine.Feed(FrameWriter.WriteDataFrame(session.Manifest.SessionTag, id,
                RandomNumberGenerator.GetBytes(session.Manifest.SymbolSize), fakeKey));

        Assert.Equal(session.K * 3, engine.FramesFailedAuthentication);
        Assert.Equal(0, engine.UniqueSymbolsReceived); // nothing reached the decoder

        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(session, engine));
        Assert.Equal(payload, engine.Completed!.Plaintext);
    }

    [Fact]
    public void AnotherSessionsFrame_WithTheTagCopiedOver_IsIgnored()
    {
        var a = SendSession.Create(RandomNumberGenerator.GetBytes(20_000), "a.bin", ContentKind.File, _sender, _receiverPeer, counter: 1, Run);
        var b = SendSession.Create(RandomNumberGenerator.GetBytes(20_000), "b.bin", ContentKind.File, _sender, _receiverPeer, counter: 2, Run);
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        engine.Feed(a.ManifestFrame);

        // A genuine frame of B (a real MAC, under B's key) relabelled as A's.
        byte[] frame = b.GetDataFrame(0);
        a.Manifest.SessionTag.CopyTo(frame, FrameFormat.SessionTagOffset);
        uint crc = System.IO.Hashing.Crc32.HashToUInt32(frame.AsSpan(0, frame.Length - 4));
        System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian(frame.AsSpan(frame.Length - 4), crc);

        Assert.Equal(FeedResult.Ignored, engine.Feed(frame));
        Assert.Equal(1, engine.FramesFailedAuthentication);
    }

    private static FeedResult FeedUntilVerdict(SendSession session, ReceiveEngine engine)
    {
        foreach (var frame in session.Carousel().Take(20_000))
        {
            var result = engine.Feed(frame);
            if (result is FeedResult.Completed or FeedResult.Rejected) return result;
        }
        return FeedResult.Ignored;
    }
}
