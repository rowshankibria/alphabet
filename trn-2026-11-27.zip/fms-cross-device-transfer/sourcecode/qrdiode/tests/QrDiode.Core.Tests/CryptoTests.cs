using System.Security.Cryptography;
using QrDiode.Core.Crypto;
using Xunit;

namespace QrDiode.Core.Tests;

public class CryptoTests
{
    [Fact]
    public void Envelope_SealOpen_RoundTrips()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();

        byte[] plaintext = new byte[10_000];
        new Random(1).NextBytes(plaintext);
        var sessionId = Guid.NewGuid();
        byte[] salt = RandomNumberGenerator.GetBytes(Envelope.SaltSize);
        byte[] nonce = RandomNumberGenerator.GetBytes(Envelope.NonceSize);
        byte[] aad = Envelope.BuildAad(sessionId, salt, 1, Guid.NewGuid(), sender.SigningKeyId, receiver.AgreementKeyId);

        var sendKeys = Envelope.DeriveSessionKeys(sender.AgreementKey, receiver.AgreementKey.PublicKey, salt, sessionId);
        byte[] ciphertext = Envelope.Seal(plaintext, sendKeys.PayloadKey, nonce, aad);
        Assert.Equal(plaintext.Length + Envelope.TagSize, ciphertext.Length);

        // Receiver derives the same keys from the mirrored ECDH.
        var recvKeys = Envelope.DeriveSessionKeys(receiver.AgreementKey, sender.AgreementKey.PublicKey, salt, sessionId);
        Assert.Equal(sendKeys.PayloadKey, recvKeys.PayloadKey);
        Assert.Equal(sendKeys.FrameKey, recvKeys.FrameKey);

        byte[] opened = Envelope.Open(ciphertext, recvKeys.PayloadKey, nonce, aad);
        Assert.Equal(plaintext, opened);
    }

    [Fact]
    public void SessionKeys_PayloadAndFrameKeysAreIndependent_AndPerSession()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        byte[] salt = RandomNumberGenerator.GetBytes(Envelope.SaltSize);

        var a = Envelope.DeriveSessionKeys(sender.AgreementKey, receiver.AgreementKey.PublicKey, salt, Guid.NewGuid());
        var b = Envelope.DeriveSessionKeys(sender.AgreementKey, receiver.AgreementKey.PublicKey, salt, Guid.NewGuid());

        Assert.NotEqual(a.PayloadKey, a.FrameKey); // one key never doubles as the other
        Assert.NotEqual(a.FrameKey, b.FrameKey);   // another session, another frame key

        a.Clear();
        Assert.All(a.PayloadKey, x => Assert.Equal(0, x));
        Assert.All(a.FrameKey, x => Assert.Equal(0, x));
    }

    [Fact]
    public void Envelope_TamperedCiphertext_Fails()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        var (key, nonce, aad, ciphertext) = SealSample(sender, receiver, out _);

        foreach (int idx in new[] { 0, ciphertext.Length / 2, ciphertext.Length - 1 })
        {
            byte[] tampered = (byte[])ciphertext.Clone();
            tampered[idx] ^= 0x01;
            Assert.ThrowsAny<CryptographicException>(() => Envelope.Open(tampered, key, nonce, aad));
        }
    }

    [Fact]
    public void Envelope_WrongAad_Fails()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        var (key, nonce, aad, ciphertext) = SealSample(sender, receiver, out var sessionId);

        // Same everything, different counter in the AAD → mix-and-match must fail.
        byte[] otherAad = (byte[])aad.Clone();
        otherAad[16 + Envelope.SaltSize] ^= 0x01;
        Assert.ThrowsAny<CryptographicException>(() => Envelope.Open(ciphertext, key, nonce, otherAad));
    }

    [Fact]
    public void Envelope_WrongRecipientKey_CannotDecrypt()
    {
        using var sender = new EphemeralEndpointKeys();
        using var receiver = new EphemeralEndpointKeys();
        using var eavesdropper = new EphemeralEndpointKeys();
        var (_, nonce, aad, ciphertext) = SealSample(sender, receiver, out var sessionId);

        byte[] salt = aad.AsSpan(16, Envelope.SaltSize).ToArray();
        var wrongKeys = Envelope.DeriveSessionKeys(eavesdropper.AgreementKey, sender.AgreementKey.PublicKey, salt, sessionId);
        Assert.ThrowsAny<CryptographicException>(() => Envelope.Open(ciphertext, wrongKeys.PayloadKey, nonce, aad));
    }

    [Fact]
    public void PublicKeyBundle_RoundTrips_AndFingerprintIsStable()
    {
        using var keys = new EphemeralEndpointKeys();
        var bundle = PublicKeyBundle.FromKeys("ot-line-1", keys);
        string json = bundle.ToJson();

        var parsed = PublicKeyBundle.Parse(json);
        Assert.Equal(bundle.Fingerprint(), parsed.Fingerprint());

        using var peer = parsed.ToPeerKeys();
        Assert.Equal(keys.SigningKeyId, peer.SigningKeyId);
        Assert.Equal(keys.AgreementKeyId, peer.AgreementKeyId);
    }

    [Fact]
    public void PublicKeyBundle_UnknownMembers_AreRejected()
    {
        using var keys = new EphemeralEndpointKeys();
        string json = PublicKeyBundle.FromKeys("x", keys).ToJson();
        string tampered = json.Replace("\"format\"", "\"injected\": true, \"format\"");
        Assert.ThrowsAny<Exception>(() => PublicKeyBundle.Parse(tampered));
    }

    private static (byte[] Key, byte[] Nonce, byte[] Aad, byte[] Ciphertext) SealSample(
        EphemeralEndpointKeys sender, EphemeralEndpointKeys receiver, out Guid sessionId)
    {
        sessionId = Guid.NewGuid();
        byte[] salt = RandomNumberGenerator.GetBytes(Envelope.SaltSize);
        byte[] nonce = RandomNumberGenerator.GetBytes(Envelope.NonceSize);
        byte[] aad = Envelope.BuildAad(sessionId, salt, 1, Guid.NewGuid(), sender.SigningKeyId, receiver.AgreementKeyId);
        byte[] key = Envelope.DeriveSessionKeys(sender.AgreementKey, receiver.AgreementKey.PublicKey, salt, sessionId).PayloadKey;
        byte[] plaintext = new byte[512];
        new Random(7).NextBytes(plaintext);
        return (key, nonce, aad, Envelope.Seal(plaintext, key, nonce, aad));
    }
}
