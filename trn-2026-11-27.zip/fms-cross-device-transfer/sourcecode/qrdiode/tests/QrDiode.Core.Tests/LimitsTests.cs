using System.Text;
using QrDiode.Core.Crypto;
using QrDiode.Core.Fountain;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using Xunit;

namespace QrDiode.Core.Tests;

/// <summary>
/// H-02 to H-05: size limits on what a sender may ask for, bounded decoder and engine memory, and
/// the switch that turns opaque files off.
/// </summary>
public class LimitsTests : IDisposable
{
    private static readonly Guid Run = Guid.NewGuid();
    private readonly EphemeralEndpointKeys _sender = new();
    private readonly EphemeralEndpointKeys _receiver = new();
    private readonly InMemoryTrustStore _trust = new();
    private readonly PeerPublicKeys _receiverPeer;

    public LimitsTests()
    {
        _trust.Add(PublicKeyBundle.FromKeys("ot", _sender).ToPeerKeys());
        _receiverPeer = PublicKeyBundle.FromKeys("it", _receiver).ToPeerKeys();
    }

    public void Dispose()
    {
        _sender.Dispose();
        _receiver.Dispose();
        _receiverPeer.Dispose();
    }

    [Fact]
    public void SendSession_RefusesPayloadsAboveTheLimit()
    {
        byte[] tooBig = new byte[TransferManifest.MaxPayloadBytes + 1];
        Assert.Throws<ArgumentException>(() =>
            SendSession.Create(tooBig, "big.bin", ContentKind.File, _sender, _receiverPeer, 1, Run));
    }

    [Theory]
    [InlineData(TransferManifest.MinSymbolSize - 1)]
    [InlineData(Framing.FrameFormat.MaxSymbolSize + 1)]
    public void SendSession_RefusesSymbolSizesOutsideTheLimits(int maxSymbolSize)
    {
        Assert.Throws<ArgumentOutOfRangeException>(() =>
            SendSession.Create(new byte[10_000], "x.bin", ContentKind.File, _sender, _receiverPeer, 1, Run,
                new SendOptions { MaxSymbolSize = maxSymbolSize }));
    }

    [Fact]
    public void Decoder_KeepsAtMostItsCapOfWaitingSymbols_EvictingTheOldest()
    {
        const int symbolSize = 64;
        const ulong seed = 7;
        var decoder = new LtDecoder(symbolSize * 300L, symbolSize, seed); // K = 300 → cap Clamp(1200, 1024, 65536)
        Assert.Equal(1200, decoder.MaxBufferedSymbols);
        var soliton = new RobustSoliton(decoder.K);

        // Only coded symbols of degree ≥ 2 and no source block ever: every one has to wait.
        int added = 0;
        for (uint id = (uint)decoder.K; added < 3 * decoder.MaxBufferedSymbols; id++)
        {
            if (LtCode.GetNeighbors(seed, id, soliton).Length < 2) continue;
            Assert.True(decoder.AddSymbol(id, new byte[symbolSize]));
            added++;
        }

        Assert.Equal(decoder.MaxBufferedSymbols, decoder.BufferedSymbols);
        Assert.Equal(added - decoder.MaxBufferedSymbols, decoder.EvictedSymbols);
        Assert.Equal(0, decoder.DecodedSourceCount);
    }

    [Fact]
    public void Decoder_RemembersABoundedNumberOfSymbolIds()
    {
        var decoder = new LtDecoder(640, 64, 9); // K = 10 → remembers Clamp(160, 4096, …) = 4096 ids
        var soliton = new RobustSoliton(decoder.K);

        int added = 0;
        for (uint id = 10; added < 10_000; id++)
        {
            if (LtCode.GetNeighbors(9, id, soliton).Length < 2) continue;
            decoder.AddSymbol(id, new byte[64]);
            added++;
        }

        Assert.Equal(decoder.MaxTrackedSymbolIds, decoder.TrackedSymbolIds);
        Assert.Equal(10_000, decoder.UniqueSymbolsReceived);
        Assert.True(decoder.BufferedSymbols <= decoder.MaxBufferedSymbols);
    }

    [Fact]
    public void Decoder_StillCompletesUnderHeavyLoss_WithItsCaps()
    {
        byte[] payload = new byte[300_000];
        new Random(3).NextBytes(payload);
        var encoder = new LtEncoder(payload, 1350, 11);
        var decoder = new LtDecoder(payload.Length, 1350, 11);
        var rng = new Random(4);
        var buffer = new byte[1350];

        for (uint id = 0; !decoder.IsComplete && id < 40 * encoder.K; id++)
        {
            if (rng.NextDouble() < 0.6) continue; // 60 % of frames lost
            encoder.GenerateSymbol(id, buffer);
            decoder.AddSymbol(id, buffer);
        }

        Assert.True(decoder.IsComplete);
        Assert.Equal(payload, decoder.Assemble());
    }

    [Fact]
    public void Engine_RemembersABoundedNumberOfSettledSessions()
    {
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver, new ReceiveOptions { MaxSettledSessions = 3 });
        var sessions = Enumerable.Range(1, 5)
            .Select(i => SendSession.Create(Encoding.UTF8.GetBytes($"<n>{i}</n>"), $"{i}.xml", ContentKind.Xml,
                _sender, _receiverPeer, (ulong)i, Run))
            .ToList();

        foreach (var session in sessions)
        {
            Assert.Equal(FeedResult.Completed, FeedUntilVerdict(session, engine));
            engine.Reset(); // settled, not committed: only the engine's own memory stops a repeat
        }

        // The oldest was forgotten by the engine (once committed, the replay guard still stops it)…
        Assert.Equal(FeedResult.ManifestAccepted, engine.Feed(sessions[0].ManifestFrame));
        engine.Reset();
        // …the newest is still remembered.
        Assert.Equal(FeedResult.Ignored, engine.Feed(sessions[4].ManifestFrame));
    }

    [Fact]
    public void OpaqueFiles_CanBeTurnedOff_XmlStillPasses()
    {
        var options = new ReceiveOptions { AllowOpaqueFiles = false };

        var file = SendSession.Create(new byte[500], "blob.bin", ContentKind.File, _sender, _receiverPeer, 1, Run);
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver, options);
        Assert.Equal(FeedResult.Rejected, FeedUntilVerdict(file, engine));
        Assert.StartsWith("Content gate", engine.LastRejection);

        var xml = SendSession.Create(Encoding.UTF8.GetBytes("<ok/>"), "ok.xml", ContentKind.Xml, _sender, _receiverPeer, 2, Run);
        var engine2 = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver, options);
        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(xml, engine2));
    }

    [Fact]
    public void With_opaque_files_off_only_the_allowed_suffixes_pass()
    {
        // Bridge mode: gateway bundles (".qbb") are files the host parses itself; any other file is refused.
        var options = new ReceiveOptions { AllowOpaqueFiles = false, AllowedFileSuffixes = [".qbb"] };

        var bundle = SendSession.Create(new byte[500], "bundle-1-3.QBB", ContentKind.File, _sender, _receiverPeer, 1, Run);
        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(bundle, new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver, options)));

        var other = SendSession.Create(new byte[500], "blob.bin", ContentKind.File, _sender, _receiverPeer, 2, Run);
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver, options);
        Assert.Equal(FeedResult.Rejected, FeedUntilVerdict(other, engine));
        Assert.StartsWith("Content gate", engine.LastRejection);
    }

    private static FeedResult FeedUntilVerdict(SendSession session, ReceiveEngine engine)
    {
        foreach (var frame in session.Carousel().Take(20_000))
        {
            var result = engine.Feed(frame);
            if (result is FeedResult.Completed or FeedResult.Rejected) return result;
        }
        return FeedResult.Ignored;
    }
}
