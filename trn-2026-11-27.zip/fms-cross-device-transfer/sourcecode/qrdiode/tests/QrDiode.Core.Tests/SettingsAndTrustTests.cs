using QrDiode.Core.Crypto;
using Xunit;

namespace QrDiode.Core.Tests;

/// <summary>S-02: the "Production" setting, and trust bundles that are skipped are always reported.</summary>
public class SettingsAndTrustTests
{
    [Fact]
    public void Options_NoFile_GivesTheDevelopmentDefaults()
    {
        using var folder = new TempFolder();
        var options = QrDiodeOptions.Load(folder.Path);

        Assert.False(options.Production);
        Assert.True(options.AllowOpaqueFiles);
        Assert.Equal(QrDiodeMode.Standalone, options.Mode);
    }

    [Fact]
    public void Any_section_can_be_read_with_enums_by_name()
    {
        using var folder = new TempFolder();
        File.WriteAllText(folder.File(AppSettings.FileName), """
            { "QrDiode": { "Mode": "Gateway" }, "Kiosk": { "Name": "it-recv-1", "Count": 3 } }
            """);

        Assert.Equal(QrDiodeMode.Gateway, QrDiodeOptions.Load(folder.Path).Mode);
        var kiosk = AppSettings.ReadSection<KioskSection>("kiosk", folder.Path);
        Assert.Equal(("it-recv-1", 3), (kiosk.Name, kiosk.Count));
        Assert.Equal(0, AppSettings.ReadSection<KioskSection>("Missing", folder.Path).Count); // no section: defaults
        Assert.True(AppSettings.HasSection("KIOSK", folder.Path));
        Assert.False(AppSettings.HasSection("Bridge", folder.Path)); // the QR apps refuse to start while the former section is there
    }

    [Fact]
    public void An_unknown_mode_is_refused()
    {
        using var folder = new TempFolder();
        File.WriteAllText(folder.File(AppSettings.FileName), """{ "QrDiode": { "Mode": "Bridge" } }"""); // the former name

        Assert.Throws<InvalidDataException>(() => QrDiodeOptions.Load(folder.Path));
    }

    private sealed class KioskSection
    {
        public string Name { get; set; } = "";
        public int Count { get; set; }
    }

    [Fact]
    public void Options_ReadTheSection_WithCommentsAndAnyCase()
    {
        using var folder = new TempFolder();
        File.WriteAllText(folder.File(QrDiodeOptions.FileName), """
            {
              // the kiosk
              "QRDatabase": { "Side": "Corp" },
              "qrdiode": { "production": true, "AllowOpaqueFiles": false, },
            }
            """);

        var options = QrDiodeOptions.Load(folder.Path);

        Assert.True(options.Production);
        Assert.False(options.AllowOpaqueFiles);
    }

    [Theory]
    [InlineData("""{ "QrDiode": { "Prodution": true } }""")]   // a typo must not leave a kiosk in development mode
    [InlineData("""{ "QrDiode": { "Production": "yes" } }""")] // wrong type
    [InlineData("""{ "QrDiode": { "Production": true """)]     // cut off
    public void Options_ThatCannotBeRead_AreRefused(string json)
    {
        using var folder = new TempFolder();
        File.WriteAllText(folder.File(QrDiodeOptions.FileName), json);

        Assert.Throws<InvalidDataException>(() => QrDiodeOptions.Load(folder.Path));
    }

    [Fact]
    public void Demo_IsRefusedInProduction_AndRecognisedByName()
    {
        Assert.Throws<InvalidOperationException>(() => KeyPolicy.EnsureDemoAllowed(new QrDiodeOptions { Production = true }));
        KeyPolicy.EnsureDemoAllowed(new QrDiodeOptions()); // development: allowed

        Assert.True(KeyPolicy.IsDemoEndpoint("demo-ot"));
        Assert.True(KeyPolicy.IsDemoEndpoint("Demo-IT"));
        Assert.False(KeyPolicy.IsDemoEndpoint("ot-line-1"));
    }

    [Fact]
    public void TrustStore_ReportsUnreadableBundles_AndRefusesDemoBundlesInProduction()
    {
        using var folder = new TempFolder();
        using var real = new EphemeralEndpointKeys();
        using var demo = new EphemeralEndpointKeys();
        File.WriteAllText(folder.File("ot-line-1.json"), PublicKeyBundle.FromKeys("ot-line-1", real).ToJson());
        File.WriteAllText(folder.File("demo-ot.json"), PublicKeyBundle.FromKeys(KeyPolicy.DemoOtEndpoint, demo).ToJson());
        File.WriteAllText(folder.File("broken.json"), "{ not a bundle");

        using (var development = new DirectoryTrustStore(folder.Path))
        {
            Assert.Equal(2, development.Peers.Count);
            Assert.Contains(development.Problems, p => p.StartsWith("broken.json"));
        }

        using (var production = new DirectoryTrustStore(folder.Path, refuseDemoBundles: true))
        {
            Assert.Equal("ot-line-1", Assert.Single(production.Peers).Name);
            Assert.Equal(2, production.Problems.Count);
            Assert.Contains(production.Problems, p => p.StartsWith("demo-ot.json"));
        }
    }
}
