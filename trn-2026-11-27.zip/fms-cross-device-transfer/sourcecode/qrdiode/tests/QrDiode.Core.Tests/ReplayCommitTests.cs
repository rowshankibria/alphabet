using System.Text;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using Xunit;

namespace QrDiode.Core.Tests;

/// <summary>
/// B-04 (known issue 3, review Q-07): the replay guard is updated only when the host has stored the
/// payload, so a crash in between never loses a session. H-07: a sender whose counter file is lost
/// starts a new run and is accepted; an old run's recordings stay refused.
/// </summary>
public class ReplayCommitTests : IDisposable
{
    private static readonly Guid Run = Guid.NewGuid();
    private readonly EphemeralEndpointKeys _sender = new();
    private readonly EphemeralEndpointKeys _receiver = new();
    private readonly InMemoryTrustStore _trust = new();
    private readonly PeerPublicKeys _receiverPeer;

    public ReplayCommitTests()
    {
        _trust.Add(PublicKeyBundle.FromKeys("ot", _sender).ToPeerKeys());
        _receiverPeer = PublicKeyBundle.FromKeys("it", _receiver).ToPeerKeys();
    }

    public void Dispose()
    {
        _sender.Dispose();
        _receiver.Dispose();
        _receiverPeer.Dispose();
    }

    [Fact]
    public void Completion_DoesNotCommit_UntilTheHostHasStoredThePayload()
    {
        var guard = new InMemoryReplayGuard();
        var session = Session("<order id=\"1\"/>", counter: 1, Run);

        // The receiver completes, then crashes before storing: nothing was committed…
        var crashed = new ReceiveEngine(_trust, guard, _receiver);
        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(session, crashed));

        // …so after the restart the carousel still on air delivers it again.
        var restarted = new ReceiveEngine(_trust, guard, _receiver);
        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(session, restarted));
        restarted.CommitReplay(); // stored this time

        var later = new ReceiveEngine(_trust, guard, _receiver);
        Assert.Equal(FeedResult.Rejected, FeedUntilVerdict(session, later));
        Assert.Contains("DuplicateSession", later.LastRejection);
    }

    [Fact]
    public void ResetWithoutSettling_LetsTheCarouselDeliverTheSessionAgain()
    {
        var session = Session("<order id=\"2\"/>", counter: 1, Run);
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);

        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(session, engine));
        engine.Reset(settle: false); // the store failed: keep the session receivable
        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(session, engine));

        engine.CommitReplay();
        engine.Reset(); // stored: settle it
        Assert.Equal(FeedResult.Ignored, engine.Feed(session.ManifestFrame));
    }

    [Fact]
    public void CommitReplay_WithoutACompletedTransfer_Throws()
    {
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        Assert.Throws<InvalidOperationException>(engine.CommitReplay);
    }

    [Fact]
    public void ANewCounterRun_IsAccepted_WhileTheOldRunsRecordingsStayRefused()
    {
        var guard = new InMemoryReplayGuard();
        var oldRun = Guid.NewGuid();
        var newRun = Guid.NewGuid();

        var last = Session("<n>812</n>", counter: 812, oldRun);
        var e1 = new ReceiveEngine(_trust, guard, _receiver);
        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(last, e1));
        e1.CommitReplay();

        // The kiosk profile was rebuilt: the counter file is gone, a new run starts at 1.
        var fresh = Session("<n>1</n>", counter: 1, newRun);
        var e2 = new ReceiveEngine(_trust, guard, _receiver);
        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(fresh, e2));
        e2.CommitReplay();

        // A recording of the old run is still stale.
        var stale = Session("<n>800</n>", counter: 800, oldRun);
        var e3 = new ReceiveEngine(_trust, guard, _receiver);
        Assert.Equal(FeedResult.Rejected, FeedUntilVerdict(stale, e3));
        Assert.Contains("StaleCounter", e3.LastRejection);
    }

    [Fact]
    public void CounterStore_StartsANewRun_WhenItsFileIsLostOrUnreadable()
    {
        if (!OperatingSystem.IsWindows()) return; // DPAPI

        using var folder = new TempFolder();
        string path = folder.File("sender-counter.bin");
        var store = new CounterStore(path);

        var first = store.Next();
        Assert.True(first.StartedNewRun);
        Assert.Equal(1ul, first.Counter);

        var second = store.Next();
        Assert.False(second.StartedNewRun);
        Assert.Equal(first.RunId, second.RunId);
        Assert.Equal(2ul, second.Counter);

        File.Delete(path); // lost
        var afterLoss = store.Next();
        Assert.True(afterLoss.StartedNewRun);
        Assert.NotEqual(first.RunId, afterLoss.RunId);
        Assert.Equal(1ul, afterLoss.Counter);

        File.WriteAllBytes(path, [1, 2, 3]); // corrupt
        var afterCorruption = store.Next();
        Assert.True(afterCorruption.StartedNewRun);
        Assert.Equal(afterCorruption.RunId, store.Peek().RunId);
        Assert.Equal(1ul, store.Peek().Counter);
    }

    private SendSession Session(string xml, ulong counter, Guid run) =>
        SendSession.Create(Encoding.UTF8.GetBytes(xml), "order.xml", ContentKind.Xml, _sender, _receiverPeer, counter, run);

    private static FeedResult FeedUntilVerdict(SendSession session, ReceiveEngine engine)
    {
        foreach (var frame in session.Carousel().Take(20_000))
        {
            var result = engine.Feed(frame);
            if (result is FeedResult.Completed or FeedResult.Rejected) return result;
        }
        return FeedResult.Ignored;
    }
}
