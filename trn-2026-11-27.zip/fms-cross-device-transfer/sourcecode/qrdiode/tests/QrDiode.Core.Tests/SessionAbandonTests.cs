using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using Xunit;

namespace QrDiode.Core.Tests;

/// <summary>
/// Known issue 1 (B-01): a partly received session must not silence the receiver, and nothing an
/// unverified or replayed manifest says may disturb the session in progress. B-02: after a rejection
/// the engine needs no reset — the Receiver's old late reset threw the next genuine session away.
/// </summary>
public class SessionAbandonTests : IDisposable
{
    private static readonly Guid Run = Guid.NewGuid();
    private readonly EphemeralEndpointKeys _sender = new();
    private readonly EphemeralEndpointKeys _receiver = new();
    private readonly InMemoryTrustStore _trust = new();
    private readonly PeerPublicKeys _receiverPeer;

    public SessionAbandonTests()
    {
        _trust.Add(PublicKeyBundle.FromKeys("ot-line-1", _sender).ToPeerKeys());
        _receiverPeer = PublicKeyBundle.FromKeys("it-recv-1", _receiver).ToPeerKeys();
    }

    public void Dispose()
    {
        _sender.Dispose();
        _receiver.Dispose();
        _receiverPeer.Dispose();
    }

    [Fact]
    public void PartialSession_ThenANewOne_TheNewOneCompletes_AndTheOldOneIsReportedOnce()
    {
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        var abandoned = new List<AbandonedSession>();
        engine.SessionAbandoned += abandoned.Add;

        var a = Session("a.bin", counter: 1);
        var b = Session("b.bin", counter: 2);

        FeedFirst(a, engine, frames: 10); // the camera caught only the start of A
        Assert.Equal(a.Manifest.SessionId, engine.ActiveManifest!.SessionId);
        Assert.Null(engine.Completed);

        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(b, engine));
        Assert.Equal(b.Manifest.SessionId, engine.Completed!.Manifest.SessionId);

        var lost = Assert.Single(abandoned);
        Assert.Equal(a.Manifest.SessionId, lost.SessionId);
        Assert.Equal("a.bin", lost.Filename);
        Assert.InRange(lost.DecodedSourceCount, 1, lost.K - 1);

        engine.CommitReplay();
        engine.Reset();

        // The rest of A's carousel is silence now: A was settled when it was given up.
        foreach (var frame in a.Carousel().Take(200))
            Assert.Equal(FeedResult.Ignored, engine.Feed(frame));
        Assert.Single(abandoned);
    }

    [Fact]
    public void WhileLocked_AnUntrustedManifest_IsIgnored_AndTheSessionStillCompletes()
    {
        using var rogue = new EphemeralEndpointKeys(); // not in the trust store
        var untrusted = SendSession.Create(new byte[2000], "x.bin", ContentKind.File, rogue, _receiverPeer, counter: 1, Run);
        var a = Session("a.bin", counter: 1);

        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        var abandoned = new List<AbandonedSession>();
        engine.SessionAbandoned += abandoned.Add;

        FeedFirst(a, engine, frames: 10);
        Assert.Equal(FeedResult.Ignored, engine.Feed(untrusted.ManifestFrame)); // not Rejected: A is not touched

        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(a, engine));
        Assert.Empty(abandoned);
    }

    [Fact]
    public void WhileLocked_AReplayedManifest_IsIgnored_AndTheSessionStillCompletes()
    {
        var guard = new InMemoryReplayGuard();
        var old = Session("old.bin", counter: 1);
        var earlier = new ReceiveEngine(_trust, guard, _receiver);
        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(old, earlier));
        earlier.CommitReplay();

        var a = Session("a.bin", counter: 2);
        var engine = new ReceiveEngine(_trust, guard, _receiver);
        var abandoned = new List<AbandonedSession>();
        engine.SessionAbandoned += abandoned.Add;

        FeedFirst(a, engine, frames: 10);
        Assert.Equal(FeedResult.Ignored, engine.Feed(old.ManifestFrame)); // a recording of OLD held up to the camera

        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(a, engine));
        Assert.Empty(abandoned);
    }

    [Fact]
    public void RepeatsOfTheCurrentManifest_AreIgnored()
    {
        var a = Session("a.bin", counter: 1);
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);

        Assert.Equal(FeedResult.ManifestAccepted, engine.Feed(a.ManifestFrame));
        for (int i = 0; i < 5; i++)
            Assert.Equal(FeedResult.Ignored, engine.Feed(a.ManifestFrame));
    }

    [Fact]
    public void ARejection_NeedsNoReset_TheNextGenuineSessionCompletes()
    {
        using var rogue = new EphemeralEndpointKeys();
        var untrusted = SendSession.Create(new byte[2000], "x.bin", ContentKind.File, rogue, _receiverPeer, counter: 1, Run);
        var genuine = Session("g.bin", counter: 1);

        // What the Receiver does now: show the rejection, leave the engine alone.
        var engine = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        Assert.Equal(FeedResult.Rejected, engine.Feed(untrusted.ManifestFrame));
        Assert.Equal(FeedResult.Completed, FeedUntilVerdict(genuine, engine));

        // What it used to do (B-02): reset a moment later, after the genuine manifest was accepted.
        var old = new ReceiveEngine(_trust, new InMemoryReplayGuard(), _receiver);
        Assert.Equal(FeedResult.Rejected, old.Feed(untrusted.ManifestFrame));
        Assert.Equal(FeedResult.ManifestAccepted, old.Feed(genuine.ManifestFrame));
        old.Reset();
        foreach (var frame in genuine.Carousel().Take(300))
            old.Feed(frame);
        Assert.Null(old.Completed); // the genuine session was thrown away — the bug this proves gone
    }

    private SendSession Session(string name, ulong counter)
    {
        byte[] payload = new byte[30_000]; // incompressible: K ≈ 23, so ten frames are never enough
        new Random(name.GetHashCode()).NextBytes(payload);
        return SendSession.Create(payload, name, ContentKind.File, _sender, _receiverPeer, counter, Run);
    }

    private static void FeedFirst(SendSession session, ReceiveEngine engine, int frames)
    {
        foreach (var frame in session.Carousel().Take(frames))
            engine.Feed(frame);
    }

    private static FeedResult FeedUntilVerdict(SendSession session, ReceiveEngine engine)
    {
        foreach (var frame in session.Carousel().Take(20_000))
        {
            var result = engine.Feed(frame);
            if (result is FeedResult.Completed or FeedResult.Rejected) return result;
        }
        return FeedResult.Ignored;
    }
}
