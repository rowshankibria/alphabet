# Light transfer walkthrough: one message across the QrDiode optical link, both lanes

A demo-ready, step-by-step account of what happens to **messages waiting in the SOAP Gateway's Outbox** from the
moment the QR Sender picks them up until they sit in the other side's Inbox. For every step: **which class** does it,
**which database, table or file** it touches, and **what changes**. Then: Standalone mode (demos and files), what
happens when the light fails, how replays and duplicates are stopped, and how the light is protected.

This page is the QrDiode half of the journey. The gateway half (callers, the hold, delivery to the real service,
Replies and Receipts) is in [round-trip-post-and-get-walkthrough.md](../../../gateway/docs/q_&_a/round-trip-post-and-get-walkthrough.md).
Full reference: [technical guide](../../../../docs/gateway-to-qrdiode/technical-guide.md),
[user guide](../user-guide.md), [protocol design notes](../protocol-development-notes.md) and the
[status page](../qrdiode-pending-work.md).

> **Status legend used on this page**
>
> - ✅ **Built and tested.** The protocol is covered by `QrDiode.Core.Tests` (116 tests: crypto, frames, fountain code,
>   replay, session abandon). The bundle path is covered by `QrBridge.Tests`, with two real gateways in memory joined by
>   the QR apps' own bundle code ([BundleLightTests](../../../gateway/tests/QrBridge.Tests/Gateway/BundleLightTests.cs):
>   round trip, five calls in one bundle, a lost bundle re-aired, a bundle arriving twice).
> - 🟡 **Built, not tried for real.** The WPF windows in Bridge mode, a real screen and a real camera have **not been
>   tried yet** ([pending work P-1 … P-4](../qrdiode-pending-work.md#1-pending)). In the tests, only the screen and the
>   camera are left out.

**How this page is organised**

| Section | What |
|---|---|
| 1–2 | The short version; programs, where things are stored, the ids that tie a transfer together |
| **3. Bridge mode, Corp → DMZ lane** | 3.1 step by step · 3.2 diagram |
| **4. Bridge mode, DMZ → Corp lane** | 4.1 what differs · 4.2 both lanes in one round trip |
| **5. Standalone mode** | 5.1 step by step (simulator and files) · 5.2 diagram |
| 6 | When something goes wrong on the light |
| 7 | Replays, duplicates and order |
| 8 | How the light is protected (keys, key ceremony, threats) |
| 9–11 | Default numbers, questions the team may ask, what is built |

---

## 1. The 30-second version

```text
Gateway A ──(Outbox rows)──► QR Sender: bundle ─► encrypt + sign ─► fountain code ─► QR codes on the screen
                                                                                        ║
                                                                                      light (one way)
                                                                                        ▼
Gateway B ◄──(Inbox rows)─── QR Receiver: bundle ◄─ verify + decrypt ◄─ fountain decode ◄─ camera

   Outbox and Inbox are tables in qrbridge.db: one file on machine A, another on machine B.
```

1. The **QR Sender** claims the next rows from the gateway's **Outbox** (up to 50 messages / 128 KB) and packs them
   into one **bundle** file, `bundle-41-45.qbb`.
2. QrDiode **compresses, encrypts and signs** the bundle, cuts it into **fountain-coded** pieces and shows them as a
   stream of QR codes, over and over, for a fixed air time.
3. The **QR Receiver** on the other side reads the screen with a camera. It checks every frame, rebuilds the bundle
   from **any** enough pieces, then verifies and decrypts it.
4. It stores every message of the bundle in **its** gateway's **Inbox** in one transaction and rings the gateway's
   doorbell. Its gateway takes over from there.
5. The Sender marks the rows **`Aired`**. It never learns whether they arrived: the light is one way. The proof comes
   later, as a **Receipt** carried back on the **other** lane by the gateways.

The light carries **no connection** and **no acknowledgement**. Three ids tie the journey together: `MessageId`
(each message, the same on both sides), `BundleId` (the bundle, the same on both sides) and the QR **session id** (one
airing of one bundle, stored as `QrSessionId`).

---

## 2. Who is who

### 2.1 The two lanes

|  | **Corp → DMZ lane** | **DMZ → Corp lane** |
|---|---|---|
| Screen (QR Sender) | Corp kiosk PC, `"Bridge": { "Side": "Corp" }` | DMZ kiosk PC, `"Bridge": { "Side": "Dmz" }` |
| Camera (QR Receiver) | DMZ kiosk PC, `"Bridge": { "Side": "Dmz" }` | Corp kiosk PC, `"Bridge": { "Side": "Corp" }` |
| `Direction` of the messages | `CorpToDmz` | `DmzToCorp` |
| Reads from | Corp `qrbridge.db`.**Outbox** | DMZ `qrbridge.db`.**Outbox** |
| Writes to | DMZ `qrbridge.db`.**Inbox** | Corp `qrbridge.db`.**Inbox** |
| Typically carries | Corp callers' Requests (Rapid Restore, DSS, FTC…); Replies and Receipts for FMS's calls; Heartbeats | FMS's Requests; Replies and Receipts for the Corp callers' calls; Heartbeats |
| Sender's doorbell | `Global\QrBridge.Corp.Outbox` | `Global\QrBridge.Dmz.Outbox` |
| Receiver's doorbell | `Global\QrBridge.Dmz.Inbox` | `Global\QrBridge.Corp.Inbox` |

The code is **identical** on both lanes and on both PCs. Only the `"Bridge"` section of each app's `appsettings.json`
differs, and it **must equal** the gateway's own `"Bridge"` section on the same machine (`Side`, `DataFolder`).

So each side runs **one Sender and one Receiver**: the Corp PC's screen faces the DMZ camera, and the DMZ PC's
screen faces the Corp camera.

### 2.2 Programs

| Program | Runs as | Job |
|---|---|---|
| **QrDiode Sender** (`QrDiode.Sender.exe`) | WPF exe, kiosk user | Reads this side's **Outbox**, airs it as QR codes on the screen facing the other side. 🟡 |
| **QrDiode Receiver** (`QrDiode.Receiver.exe`) | WPF exe, kiosk user | Reads the other side's screen with a camera, writes this side's **Inbox**. 🟡 |
| **QrDiode KeyCeremony** (`QrDiode.KeyCeremony.exe`) | Console, kiosk user, by hand | Creates this PC's keys, exports its public keys, imports the other side's (§8.3). ✅ |
| **SOAP Gateway** (`QrBridge.Gateway`) | IIS site | Fills the Outbox, empties the Inbox. Never talks to the QR apps directly. ✅ |

The QR apps and the gateway share only **`qrbridge.db`** (the QR apps reach it through
[QrAppBridge](../../../gateway/src/QrBridge.Shared/Bundles/QrAppBridge.cs), a small composition root in
`QrBridge.Shared`) and two named Windows events, the **doorbells**, which only say "look now" and carry no data.

`"QrDiode": { "Mode": "Bridge" }` in each app's `appsettings.json` switches this on. `"Mode": "Standalone"` (the
default) is the demo mode: simulator payloads and files, nothing to do with the gateway (§5).

### 2.3 Where things are stored

| Store | Where | Written by | What it holds |
|---|---|---|---|
| `qrbridge.db`.**Outbox** | `Bridge:DataFolder` (`C:\ProgramData\QrBridge\Data`) | Gateway (`OutboxWriter`); light status by the QR Sender | The messages this side sends. The QR Sender changes only `LightStatus`, `LightUpdatedUtc`, `LightComment`, `BundleId`, `QrSessionId`, `Attempts`, `NextAttemptUtc`, `LockedUtc`. |
| `qrbridge.db`.**Inbox** | same file | QR Receiver (`InboxRepository.AddMessagesAsync`); the rest by the gateway | The messages that arrived from the other side. |
| `qrbridge.db`.**Heartbeat** | same file | Gateway workers and both QR apps (every 30 s) | "Component X is alive", shown on the gateway's `/health` (`SenderLoop`, `ReceiverLoop`). |
| **Keys** | Windows CNG key store, per Windows user: `QrDiode.{endpoint}.sign` and `.kex` | KeyCeremony, or the app on first use | This PC's private signing key (ECDSA P-256) and agreement key (ECDH P-256). Non-exportable; TPM-backed when possible. |
| **Trust store** | `%LocalAppData%\QrDiode\trust\*.json` | KeyCeremony `import` | The other side's public keys, one JSON bundle per trusted peer. |
| **Sender counter** | `%LocalAppData%\QrDiode\sender-counter.bin` | QR Sender (`CounterStore`) | The anti-replay counter and its run id, DPAPI-protected (current user). |
| **Receiver journal** | `%LocalAppData%\QrDiode\journal.db` (SQLite) | QR Receiver (`SqliteJournal`) | `transfers` (every session received), `run_watermarks` (highest counter per sender key and run), `payload_index` (the archive tab: every judged arrival, rejections included). |
| **Audit logs** | `%LocalAppData%\QrDiode\audit\sender-audit.jsonl`, `receiver-audit.jsonl` | Both apps (`AuditLog`) | Append-only, hash-chained events: ids, counts and sizes, never a gateway payload. |
| **Payload store** | `%LocalAppData%\QrDiode\quarantine\` by default (Standalone only) | QR Receiver (`PayloadStore`) | Received files, optionally with a `.meta.json`. **Bridge mode writes no files.** |
| **Settings** | `appsettings.json` next to each exe | Operator | `QrDiode` (Production, Mode), `Bridge` (Side, DataFolder, MaxPayloadBytes), `Sender` / `Receiver`. |

Everything under `%LocalAppData%` and the CNG store is **per Windows user**: run the apps and KeyCeremony as the same
kiosk user, or they will not find their keys.

### 2.4 The ids and columns that matter

| Id or column | Where | Meaning |
|---|---|---|
| `MessageId` | Outbox and Inbox | The message's id, set by the gateway. **Same value** on both sides. The Inbox's primary key: a message is never stored twice. |
| `Sequence`, `SequenceRunId` | Outbox and Inbox | The sending gateway's running number. Sets the claim order; the gateway uses it for ordering and lost-message detection. |
| `BundleId` | Outbox and Inbox | Set when the QR Sender claims rows into one bundle. Travels in the bundle, so the Inbox rows get the same value. |
| `QrSessionId` | Outbox and Inbox | The QrDiode session (`TransferManifest.SessionId`) that carried the bundle. A new value on every airing. |
| `LightStatus` (Outbox) | Outbox | `Pending` → `Sending` (claimed into a bundle) → `Aired` (shown for its full air time) → `Received` (a Receipt or Reply came back) or `Failed` (aired 3 times with no Receipt, or expired: an operator must act). |
| `LightStatus` (Inbox) | Inbox | `Received` on arrival; `Rejected` if a gateway check fails later. |
| `ReceiptDueUtc` | Inbox | Set on arrival (and again when a message arrives twice): the gateway owes the other side a Receipt. |
| Session id, session tag | Manifest, every frame | `SessionId` is a new GUID per airing; the **session tag** is its first 8 bytes, printed in every frame so the camera can tell sessions apart. |
| `Counter`, `CounterRunId` | Signed manifest | The Sender's anti-replay number and the run of its counter file (§7). |
| **Receipt hash** | Both screens | SHA-256 of the signed manifest (body + signature), first 8 bytes in hex. The same value on both screens means the same signed session. |

---

## 3. Bridge mode, Corp → DMZ lane

The gateways sit at both ends. The **Corp QR Sender** reads the Corp `qrbridge.db`; the **DMZ QR Receiver** writes
the DMZ `qrbridge.db`.

### 3.1 Step by step

**Example:** Rapid Restore FCR has just sent a permit (`FC2FMS.SendToFMS`, `Sequence` 41) and DSS a call to
`DSS2FMS` (`Sequence` 42). The Corp gateway has stored both in the Corp Outbox (`LightStatus=Pending`) and rung the
Corp Outbox doorbell. The FCR caller is being held (see the gateway walkthrough, Phase A).

#### Phase A: the Corp QR Sender claims a bundle ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| A1 | [OutboxSource](../../src/QrDiode.Sender/Transmit/OutboxSource.cs) `.RunAsync`, once at start | Corp `qrbridge.db`.**Outbox** | `OutboxRepository.ResetSendingAsync`: rows a crash left `Sending` go back to `Pending`, out of their bundle. Then every 30 s a liveness row (`HeartbeatRepository.BeatAsync`, `SenderLoop`). |
| A2 | `OutboxSource.RunAsync` loop | — | Wakes on the Outbox doorbell `Global\QrBridge.Corp.Outbox`, when an item ends, or every 2 s. Claims only when there is **room**: keys and a receiver chosen (`CanTransmit`), the stage open, and **nothing waiting** in the queue. So at most one bundle waits behind the one on air. |
| A3 | [OutboxBundler](../../../gateway/src/QrBridge.Shared/Bundles/OutboxBundler.cs) `.ClaimAsync` → [OutboxRepository](../../../gateway/src/QrBridge.Shared/Data/Repositories/OutboxRepository.cs) `.ClaimBundleAsync` | Corp `qrbridge.db`.**Outbox** | Reads rows `Pending` and due (`NextAttemptUtc` empty or past), **`Priority` first, then `Sequence`**, at most 50. Adds them while the bundle stays within 128 KB, and **stops at the first one that does not fit**: never skips ahead to a smaller one. The first row always goes, alone if it is bigger than 128 KB. One update: `Pending` → **`Sending`**, `BundleId` = a new GUID, `LockedUtc`, `Attempts + 1`; only rows still `Pending` change. If every row was taken meanwhile, it looks again (up to 5 times). |
| A4 | [BundleCodec](../../../gateway/src/QrBridge.Shared/Bundles/BundleCodec.cs) `.Build` | — | Packs the rows' `MessageBytes` **unchanged** (the gateway's serialized messages: header, SHA-256 checksum, Brotli body) into `QBB1` ‖ version ‖ `BundleId` ‖ count ‖ lowest and highest `Sequence` ‖ for each message: length + bytes. File name `bundle-41-42.qbb`. |
| A5 | [TransmitEngine](../../src/QrDiode.Sender/Transmit/TransmitEngine.cs) `.Enqueue` | — | Queues it as a **"gateway bundle"** item, **never droppable** (only simulator payloads may be dropped when the queue is full). The item remembers its `BundleId`. Audit `bridge.bundle_queued` (bundle id, count, sequences, size). |

#### Phase B: the Sender turns the bundle into a QR session ✅

| # | Who | Store | What happens |
|---|---|---|---|
| B1 | `TransmitEngine.TryStartNext` (on the stage's next tick while `Idle`) | — | Takes the oldest queued item. State `Encoding`. |
| B2 | [CounterStore](../../src/QrDiode.Core/Crypto/AntiReplay/CounterStore.cs) `.Next` | `sender-counter.bin` | Reserves the next counter value and **writes it to disk first** (temp file, flush, rename), so a crash can never give two sessions the same number. A missing or unreadable file starts a **new run** at 1 (audit `counter.new_run`). |
| B3 | [SendSession](../../src/QrDiode.Core/Pipeline/SendSession.cs) `.Create` (thread pool) | — | Brotli-compresses the bundle and keeps whichever is smaller (the messages are already compressed, so it gains little). Picks the symbol size (1,350 bytes, or the whole thing if smaller) and **K**, the number of source pieces. New session id, a random 32-byte salt and 12-byte nonce, a random fountain seed. |
| B4 | [Envelope](../../src/QrDiode.Core/Crypto/Encryption/Envelope.cs) `.DeriveSessionKeys`, `.Seal` | CNG keys, trust store | **ECDH P-256** between this PC's agreement key and the DMZ receiver's public key → **HKDF-SHA256** with the salt → two keys: the **payload key** and the **frame key**. **AES-256-GCM** seals the bundle; the AAD binds it to the session id, salt, counter, run id and both key ids. The payload key is wiped at once. |
| B5 | [TransferManifest](../../src/QrDiode.Core/Manifest/TransferManifest.cs) `.Serialize`, `.Sign` | — | The **manifest**: session id, time, counter and run id, both key ids, salt, nonce, symbol size, K, seed, sizes, the ciphertext's SHA-256, content kind `File`, file name. **Signed with ECDSA P-256** (always the low-S form, so there is exactly one valid signature). The receipt hash is computed from it. |
| B6 | `TransmitEngine.EncodeAndAirAsync` | `sender-audit.jsonl` | A [CarouselPump](../../src/QrDiode.Sender/Rendering/CarouselPump.cs) starts rendering frames in the background. The item gets its session id, K and receipt hash. State **`OnAir`**. Audit `send.started`. |

#### Phase C: on the screen 🟡

| # | Who | Store | What happens |
|---|---|---|---|
| C1 | `SendSession.Carousel` | — | An endless stream: the **manifest frame first**, again every 20 frames. Each loop = the K source pieces, then 2 × K new **coded** pieces (fountain code, [LtEncoder](../../src/QrDiode.Core/Fountain/LtEncoder.cs)); coded ids keep increasing, so every loop adds new information. |
| C2 | [FrameWriter](../../src/QrDiode.Core/Framing/FrameWriter.cs) | — | One frame per QR code: `OD` ‖ version `0x02` ‖ type ‖ session tag (8) ‖ piece id (4) ‖ piece ‖ **MAC** (16 bytes, HMAC-SHA256 under the frame key) ‖ **CRC-32**. A manifest frame carries the manifest and its 64-byte signature instead of an id and a MAC. |
| C3 | `CarouselPump` + [QrFrameRenderer](../../src/QrDiode.Sender/Rendering/QrFrameRenderer.cs) | — | Renders each frame to black-and-white pixels: **one QR version for the whole session** (version 27, error correction L, for the usual 1,386-byte frame), 8-module quiet zone, 16 frames buffered ahead. |
| C4 | `StageWindow` + `TransmitEngine.PumpFrame` | — | The stage window shows the next frame at the chosen rate (**15 fps** by default, slider 5–30). |
| C5 | `TransmitEngine.PumpFrame` → `EndSession(Sent)` | `sender-audit.jsonl` | The session ends when **3 loops** are shown (about **9 × K** frames) **and** at least **6 s** have passed. Then a **1.5 s gap** (a blank stage) so the receiver can finish. Audit `send.stopped`. **Nothing tells the Sender whether the camera saw it.** |
| C6 | `OutboxSource.OnItemFinished` → `SettleAsync` → `OutboxBundler.MarkAiredAsync` | Corp `qrbridge.db`.**Outbox** | **Sent:** the bundle's rows that are still `Sending` → **`Aired`**, `QrSessionId` = this session, `LockedUtc` cleared. A Receipt that already arrived is never undone. **Skipped** (stage closed, operator skip) → `ReleaseBundleAsync`: back to `Pending` at once, out of the bundle. **Failed** (encode error) → back to `Pending`, due again after 30 s. Tried 3 times; if the database stays busy, the rows stay `Sending` until the Sender's next start (A1). |

From now on the Corp gateway waits for a Receipt. No Receipt within 120 s → it sets the rows back to `Pending` and
the Sender airs them again in a new bundle (§6, scenario 2).

#### Phase D: on the camera (DMZ QR Receiver) 🟡 camera · ✅ engine

| # | Who | Store | What happens |
|---|---|---|---|
| D1 | [QrDecodePipeline](../../src/QrDiode.Receiver/Capture/QrDecodePipeline.cs) `.OnPixelBuffer` | — | Each camera image (FlashCap; uncompressed or MJPEG) → grey levels → **ZXingCpp** finds up to 2 QR codes. A new image that arrives while one is still being decoded is **dropped**: the carousel shows everything again, so drops only cost time. Each QR code's bytes go to `OnQrPayload`. |
| D2 | [ReceiveEngine](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs) `.Feed` → [FrameParser](../../src/QrDiode.Core/Framing/FrameParser.cs) `.TryParse` | — | Size 17–4,096 bytes, magic `OD`, **version `0x02`** (v1 frames are refused), known type, **CRC-32**. Any failure → **Ignored**, silently (noise, a misread, someone else's code). |
| D3 | `ReceiveEngine.FeedManifest` | trust store, `journal.db` | For a manifest frame, in this order: structure and limits (≤ 64 MB, K ≤ 65,536…) → sender's key **in the trust store** → **signature** over the exact bytes → addressed to **this** receiver's key → session not already settled → **replay check** (`SqliteJournal.Check`: unseen session id, counter above the watermark of that sender key and run, timestamp within 48 h, or 15 min in strict mode) → derive the payload and frame keys. Pass → the engine **locks onto the session** and creates an [LtDecoder](../../src/QrDiode.Core/Fountain/LtDecoder.cs). Fail → a **Rejected** row on the Receiver window (or Ignored while locked on another session). |
| D4 | `ReceiveEngine.FeedManifest` (while locked) | — | A **different, fully verified** manifest while locked means the Sender moved on: the partial session is **abandoned** (`SessionAbandoned` → an "⚠ Incomplete — must be re-sent" row) and the engine locks onto the new one. Unverified or replayed manifests never disturb the session in progress. |
| D5 | `ReceiveEngine.FeedSymbol` | — | For a data frame: a verified manifest exists, same session tag, right piece size, and the **MAC verifies** (constant-time). A wrong MAC → Ignored and counted (`FramesFailedAuthentication`), so a QR code held up to the camera can never reach the decoder. Then `LtDecoder.AddSymbol`: duplicates skipped, pieces "peeled" until all K source pieces are known. |
| D6 | `ReceiveEngine.FinishTransfer` | — | When all K are known: the ciphertext's **SHA-256** must match the signed manifest → **AES-GCM open** with the AAD rebuilt from the manifest → Brotli decompress **capped at the declared size** → exact size → **content gate**: in Bridge mode only a `File` whose name ends with **`.qbb`** passes (`AllowOpaqueFiles` off). Any failure → Rejected, the session is settled and dropped. The session keys are wiped. Result: **Completed**. |

#### Phase E: the DMZ Receiver stores the bundle in the Inbox ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| E1 | Receiver [MainWindow](../../src/QrDiode.Receiver/MainWindow.xaml.cs) `.HandleCompletion` (UI thread) | — | Bridge mode and a `.qbb` file → **`HandleBundleAsync`**. Anything else → `HandleNotABundle`: refused, nothing written. |
| E2 | [InboxBundleWriter](../../../gateway/src/QrBridge.Shared/Bundles/InboxBundleWriter.cs) `.StoreAsync` → `BundleCodec.Parse` | — | Parses the bundle (bounded and exact: every length checked, no stray bytes; each message at most `Bridge:MaxPayloadBytes` plus framing). Reads **only each message's header** (`MessageSerializer.PeekHeader`); the gateway checks the rest later. Every message must go **`CorpToDmz`** (this side's receive direction), or the **whole** bundle is refused. |
| E3 | [InboxRepository](../../../gateway/src/QrBridge.Shared/Data/Repositories/InboxRepository.cs) `.AddMessagesAsync` | DMZ `qrbridge.db`.**Inbox** | **One transaction for the whole bundle.** A new `MessageId` → a new row: same `MessageId`, `Sequence`, `Kind`, `CorrelationId`…, `BundleId`, `QrSessionId`, `MessageBytes`, `LightStatus=Received`, `ServiceStatus=Pending`, **`ReceiptDueUtc=now`** (not for Receipts and Heartbeats). A `MessageId` already there → **skipped**, takes this bundle's ids and is **owed a Receipt again**. All or nothing. |
| E4 | `InboxBundleWriter` | — | Rings the DMZ Inbox doorbell `Global\QrBridge.Dmz.Inbox`. |
| E5 | `HandleBundleAsync` → `ReceiveEngine.CommitReplay` → `SqliteJournal.Commit` | `journal.db` | **Only now**, with the messages safely in the Inbox: the watermark of that sender key and run rises to this counter, and the session id is recorded. A crash before this line loses nothing: the session is still receivable (§7.2). |
| E6 | `HandleBundleAsync` | `journal.db`, `receiver-audit.jsonl` | `RecordTransfer` "stored"; audit `receive.bundle_stored` (bundle id, count, added, duplicates, sequences, receipt hash); a Receiver window row "bundle 41–42 · 2 messages" and its archive row (`payload_index`). **No payload, preview or snippet is kept** (gateway payloads are never logged). |
| E7 | `ReceiveEngine.Reset(settle: true)` | — | Ready for the next manifest; the rest of this session's carousel is ignored. |

If the Inbox cannot be written (database locked for more than 5 s, disk error), nothing is committed:
`Reset(settle: false)` forgets the session, so the frames still on air deliver it again (§6, scenario 5).

#### Phase F: the gateways take over ✅

| # | Who | Database.Table | What happens |
|---|---|---|---|
| F1 | DMZ gateway `InboxWorker` | DMZ `qrbridge.db`.**Inbox** | Woken by the doorbell: opens each message, runs `ArrivalChecks`, posts Requests to the real service (gateway walkthrough, Phase C). |
| F2 | DMZ gateway `ReceiptWorker` | DMZ **Inbox** → DMZ **Outbox** | Queues a **Receipt** for each arrived message. It crosses on the **DMZ → Corp lane** (§4), with the Reply. |
| F3 | Corp gateway `AnswerReader` | Corp **Outbox** | The Receipt arrives: the Corp rows 41 and 42 → `LightStatus` **`Received`**. They will not be aired again. |

### 3.2 Corp → DMZ lane diagram

```mermaid
sequenceDiagram
    autonumber
    participant GA as Corp gateway
    participant OA as Corp qrbridge.db / Outbox
    participant QS as Corp QR Sender
    participant SC as Corp screen
    participant CA as DMZ camera
    participant QR as DMZ QR Receiver
    participant IB as DMZ qrbridge.db / Inbox
    participant GB as DMZ gateway

    GA->>OA: OutboxWriter: rows 41, 42 (Pending), ring Outbox doorbell
    QS->>OA: OutboxBundler.ClaimAsync: Pending → Sending, new BundleId
    QS->>QS: BundleCodec.Build: bundle-41-42.qbb
    QS->>QS: CounterStore.Next (flushed first), SendSession.Create
    Note over QS: Brotli → ECDH + HKDF → AES-256-GCM → signed manifest → LT fountain code
    loop 3 loops (~9 × K frames) and at least 6 s
        QS->>SC: manifest every 20 frames, data frames with MAC + CRC
        SC-->>CA: light only, one way
    end
    QS->>OA: MarkAiredAsync: Sending → Aired, QrSessionId
    CA->>QR: QrDecodePipeline: ZXingCpp decodes QR codes
    QR->>QR: ReceiveEngine: CRC → signature → addressed to me → replay → MAC → LT decode → hash → AES-GCM → content gate
    QR->>IB: InboxBundleWriter: all messages in one transaction (Received, Receipt owed)
    QR->>GB: ring Inbox doorbell
    QR->>QR: CommitReplay (only after the store)
    GB->>IB: InboxWorker delivers, ReceiptWorker queues Receipts
    Note over GA,GB: The Receipt crosses back on the DMZ → Corp lane, then Corp rows 41, 42 become Received
```

---

## 4. Bridge mode, DMZ → Corp lane

### 4.1 What differs

The **same classes, in the same order**: Phases A to F of §3.1 apply word for word, with the sides swapped.

| | Corp → DMZ lane | DMZ → Corp lane |
|---|---|---|
| QR Sender runs on, reads | Corp PC, Corp **Outbox** | DMZ PC, DMZ **Outbox** |
| QR Receiver runs on, writes | DMZ PC, DMZ **Inbox** | Corp PC, Corp **Inbox** |
| Direction each message must have (E2) | `CorpToDmz` | `DmzToCorp` |
| Sender's encryption target | the DMZ Receiver's public key | the Corp Receiver's public key |
| What usually goes first | Corp callers' Requests (priority `High`, `Normal`, `Low`) | **Replies and Receipts** (priority `Answer`) before any FMS Request |
| Who is waiting for it | The DMZ gateway (to call the real service); held FMS callers (90 s) for their Replies | Held Corp callers (270 s) for their Replies; the Corp gateway for FMS's Requests |

Two things follow from the claim order (`Priority`, then `Sequence`):

- On the way back, **answers overtake new Requests**: a Reply or Receipt is claimed before any Request waiting on that
  side, so a held caller is not kept waiting behind FMS's own traffic.
- The Receipt is owed as soon as the Request **arrives**, the Reply only once the real service has answered. So the
  Receipt often crosses first, in an earlier bundle; when the service is quick, both may share one.

### 4.2 Both lanes in one round trip

```mermaid
sequenceDiagram
    autonumber
    participant C as Caller (CorpNet)
    participant GA as Corp gateway + qrbridge.db
    participant L1 as Corp QR Sender → DMZ QR Receiver
    participant GB as DMZ gateway + qrbridge.db
    participant S as Real service (DMZ)
    participant L2 as DMZ QR Sender → Corp QR Receiver

    C->>GA: SOAP call (held up to 270 s)
    GA->>GA: Outbox: Request (Pending)
    L1->>GA: claim bundle (Sending)
    L1->>GB: QR session: bundle → Inbox (Received, Receipt owed)
    L1->>GA: Aired
    GB->>S: POST the same bytes
    S-->>GB: real answer
    GB->>GB: Outbox: Receipt (on arrival), Reply (after the service), both priority Answer
    L2->>GB: claim bundle(s): Receipt, Reply
    L2->>GA: QR session: bundle → Corp Inbox
    L2->>GB: Aired
    GA->>GA: AnswerReader: Request → Received + Answered, wake the caller
    GA-->>C: the real answer, byte for byte
    Note over GA,GB: Later the Corp side sends a Receipt for the Reply, so the DMZ side stops re-airing it
```

Each lane needs **at least about 7.5 s** per QR session (6 s minimum air time + 1.5 s gap), so a round trip needs at
least about **15 s of air time** plus the encode, decode and delivery time. The real figure has not been measured yet
([P-4](../qrdiode-pending-work.md#1-pending)).

---

## 5. Standalone mode

`"QrDiode": { "Mode": "Standalone" }`: no gateway, no `qrbridge.db`. Used for demos, the 5-minute set-up on one machine
([user guide Part A](../user-guide.md#part-a--5-minute-demo-one-machine-full-security)) and plain file transfer. **The
security is identical**: real keys, signatures, encryption and anti-replay.

### 5.1 Step by step

| # | Who | Store | What happens |
|---|---|---|---|
| S1 | Sender: [LiveSource](../../src/QrDiode.Sender/Transmit/LiveSource.cs) (simulator) or **Browse** (`TransmitEngine.EnqueueFile`) | — | The simulator ([PayloadSimulator](../../src/QrDiode.Core/Simulation/PayloadSimulator.cs)) emits realistic XML/JSON plant events on a bursty schedule; Browse adds a file (`.xml` → Xml, `.json` → Json, anything else → File). |
| S2 | `TransmitEngine.Enqueue` | — | Simulator payloads are **droppable**: when more than **14** are waiting, the oldest are skipped ("the source outran the stage"). Files are never dropped. |
| S3 | Phases **B, C, D** of §3.1 | `sender-counter.bin`, `journal.db` | Exactly the same. The content gate (D6) also checks XML (no DTDs, depth ≤ 64) and JSON (depth ≤ 64) structure. Files are accepted when `"AllowOpaqueFiles": true` (Receiver `appsettings.json`). |
| S4 | Receiver `HandleCompletion`: `SqliteJournal.IsDuplicateContent` | `journal.db` | **Same sender and same plaintext SHA-256 already stored?** → a **◎ Duplicate** row, nothing written. |
| S5 | [PayloadStore](../../src/QrDiode.Receiver/Storage/PayloadStore.cs) `.Save` | payload store folder | Writes to a staging file, flushes it to disk, then **renames** it into place (optionally by date, optionally with a `.meta.json`). Atomic: a file is either there whole or not at all. |
| S6 | `CommitReplay`, `RecordTransfer`, archive index | `journal.db`, `receiver-audit.jsonl` | Then the replay state, the journal row, the archive row and audit `receive.completed`. A **✔ Verified** row with a preview. |
| S7 | Operator | — | Compares the **receipt hash** on both screens. |

### 5.2 Standalone diagram

```mermaid
sequenceDiagram
    autonumber
    participant SRC as Simulator / Browse
    participant TE as Sender TransmitEngine
    participant SC as Screen
    participant CA as Camera
    participant RE as Receiver ReceiveEngine
    participant ST as Payload store + journal.db

    SRC->>TE: Enqueue (simulator: droppable beyond 14)
    TE->>TE: CounterStore.Next, SendSession.Create
    TE->>SC: carousel frames (3 loops, ≥ 6 s)
    SC-->>CA: light
    CA->>RE: Feed: verify, decode, decrypt, content gate
    alt same content from this sender already stored
        RE->>ST: Duplicate row, nothing written
    else new
        RE->>ST: PayloadStore.Save (staging, fsync, rename), then CommitReplay
    end
    Note over TE,RE: Receipt hash shown on both screens for the operator to compare
```

---

## 6. When something goes wrong on the light

| # | What went wrong | What the system does | Who/what acts |
|---|---|---|---|
| 1 | **The camera misses frames** (glare, focus, a hand in front) | Nothing to do. The fountain code needs **any** slightly more than K distinct pieces, in any order; the carousel shows 3 loops. | Automatic |
| 2 | **The camera misses a whole session** (or too much of it) | Bridge: the rows are `Aired` but no Receipt comes. After **120 s** the gateway sets them back to `Pending` (`MaintenanceWorker` → `ReairUnconfirmedAsync`) and the Sender airs them in a **new** bundle and session. After **3 airs**, or once past `ExpiresUtc` → light **`Failed`** + a `Light:` warning. If the Receiver had locked onto it, it shows "⚠ Incomplete — must be re-sent" when the next session starts. Standalone: send it again. | Automatic, then operator |
| 3 | **A bundle arrives twice** (re-aired because its Receipt was lost) | It is a new session (new id and counter), so it passes the replay check. `AddMessagesAsync` skips every `MessageId` already in the Inbox and owes it a **new Receipt**. A message is **never delivered twice**. | Automatic |
| 4 | **The Receiver restarts while the Sender still shows a session it already stored** | The journal knows the session id: `DuplicateSession`, shown as "◎ already received", not as a red rejection. Nothing written. | Automatic |
| 5 | **The Inbox cannot be written** (database locked for more than 5 s, disk error) | Nothing committed; `Reset(settle: false)` forgets the session. The frames still on air deliver it again; if the session ends first, scenario 2 applies. One "store failed" row counts the attempts. | Automatic |
| 6 | **The bundle is malformed, or its messages go the wrong way** (a Sender with the wrong `Bridge:Side`) | The whole bundle is refused, **nothing stored**, and the session is settled (the same bytes would fail again). On the sending side the rows stay `Aired` → re-aired → `Failed`. | **Operator** fixes the settings |
| 7 | **The stage is closed, or the operator skips the session** | The item ends `Skipped`; its rows go back to `Pending` **at once**, out of the bundle. | Automatic |
| 8 | **Encoding fails** (or the frame producer stops) | The item ends `Failed`; its rows go back to `Pending`, due again after **30 s**, so a broken bundle cannot spin. | Automatic |
| 9 | **The Sender crashes while a bundle is on air**, or cannot record the outcome | The rows stay `Sending`. At its next start, `ResetSendingAsync` puts them back to `Pending`; they are aired again. | Automatic at restart |
| 10 | **Someone holds up a QR code** | Wrong format or CRC → ignored. Right session tag but wrong MAC → ignored and counted. A forged manifest → unknown key or bad signature → **Rejected** before any payload byte is touched (or Ignored if a genuine session is in progress). The genuine session completes. | Automatic |
| 11 | **Someone replays an old recording** | `DuplicateSession`, `StaleCounter` or `TimestampOutOfWindow` → **Rejected** ("Replay check failed"). | Automatic |
| 12 | **The Sender's counter file is lost** (kiosk profile rebuilt, another Windows user) | A **new counter run** starts at 1; the Receiver keeps one watermark per sender key **and run**, so it accepts the new run. Both apps write it to the audit log. | Automatic; operator may check why |
| 13 | **The two PCs' clocks are more than 48 h apart** (15 min in strict mode) | `TimestampOutOfWindow` → every session Rejected. A time source while islanded is still open ([P-7](../qrdiode-pending-work.md#1-pending)). | **Operator** |
| 14 | **A Bridge-mode Receiver sees an XML, JSON or other non-bundle session** | Refused by the content gate (or `HandleNotABundle`), nothing written. | Automatic |
| 15 | **`qrbridge.db` cannot be opened at start** (wrong `DataFolder`, a former `send.db` in the folder, no Modify right for the kiosk user) | "Bridge mode: the gateway's database … cannot be opened": nothing is aired or received. | **Operator** |
| 16 | **One message is bigger than 128 KB** | It goes **alone** in its own bundle (up to `Bridge:MaxPayloadBytes`, 1 MB). Its air time grows with its size (§9.2). | Configuration |
| 17 | **A v1 app meets a v2 app** | v1 frames fail `BadVersion`: nothing crosses. Update both sides together. | Deployment |

---

## 7. Replays, duplicates and order

### 7.1 The problem

The light is **one way**. The Sender cannot hear "got it", so it shows everything many times, and the gateway airs a
whole bundle again when no Receipt comes back. A camera, or someone with a phone, can also record the screen and show
it again later. So the Receiver sees the **same frames many times**, the **same messages in several sessions**, and
possibly **old sessions** on purpose. None of that may turn into a message delivered twice.

### 7.2 The layers, in order

| Layer | Where | Store | Rule |
|---|---|---|---|
| **1. Misreads** | `FrameParser` | — | CRC-32, magic, version, type and lengths. Anything else is dropped. |
| **2. Foreign frames** | `ReceiveEngine.FeedSymbol`, `FrameMac` | — | Every data frame carries a MAC under the session's frame key. Only the two endpoints can compute it. |
| **3. The same frame again** | `LtDecoder` | memory | Piece ids already seen are skipped (capped memory: oldest forgotten first). |
| **4. The same session again (its carousel tail)** | `ReceiveEngine` settled list | memory (4,096 sessions) | Once a session is judged, its remaining frames are ignored. Only verified manifests enter the list, so a forgery cannot block a real session. |
| **5. Old or replayed sessions** | `SqliteJournal` (`IReplayGuard`) | `journal.db`: `transfers`, `run_watermarks` | Session id never seen; counter **above** the watermark of that sender key and run; timestamp within 48 h (15 min strict). **Committed only after the payload is stored** (`CommitReplay`): a crash in between leaves the session receivable, at worst arriving again as a duplicate, never lost. |
| **6. The same message in another bundle** | `InboxRepository.AddMessagesAsync` | `qrbridge.db`.**Inbox** | `MessageId` is the primary key: already there → skipped and re-receipted, in the same transaction. |
| **7. Gateway checks** | `ArrivalChecks` and the rest of the gateway | `qrbridge.db`.**Inbox**, **SequenceWatermark** | Sequence numbers not reused, same `routes.json`, right direction, age limits, retry recognition, never re-posting what may have arrived ([gateway walkthrough §6](../../../gateway/docs/q_&_a/round-trip-post-and-get-walkthrough.md#6-retries-and-idempotency-including-contentfingerprint)). |
| *(Standalone only)* **Same content** | `SqliteJournal.IsDuplicateContent` | `journal.db` | Same sender and same plaintext SHA-256 → not written again. **Skipped in Bridge mode on purpose**: a re-aired bundle can be byte-identical and must still reach the Inbox so its messages are owed a new Receipt. |

### 7.3 Order

- The Sender claims rows in **`Priority` order, then `Sequence`**, and stops at the first row that does not fit:
  it never skips ahead. Bundles are aired one at a time, in the order claimed.
- So messages cross in the order the gateway wants them. The receiving gateway still delivers in the **sender's
  order** per priority class. A lost bundle that is re-aired arrives **after** later ones; the gateway's sequence
  checks and gap monitor deal with that, not QrDiode.
- The lowest and highest `Sequence` in the bundle header (and its file name) are **for display only**: with
  priorities, the numbers in between need not all be in that bundle.

### 7.4 A demo example: a lost Receipt

1. 10:00:00. Corp rows 41–42 → bundle B1, session S1 (counter 812). Rows `Aired`.
2. 10:00:08. The DMZ Receiver stores both in the DMZ Inbox, owes two Receipts, commits counter 812.
3. 10:00:20. The DMZ side's bundle with the two Receipts is **not seen** by the Corp camera (the services are still
   working, so no Reply has been written yet).
4. 10:02:00. No Receipt for 120 s → Corp rows 41–42 back to `Pending` → bundle B2, session **S2** (counter **813**).
5. 10:02:08. S2 is fresh (new id, 813 > 812), so it passes the replay check. The Inbox already has both `MessageId`s:
   **0 added, 2 duplicates**, two Receipts owed again. The real service was called **once**.
6. 10:02:20. The new Receipts arrive at Corp → rows 41–42 `Received`.

---

## 8. How the light is protected

### 8.1 Sending pipeline ([SendSession](../../src/QrDiode.Core/Pipeline/SendSession.cs))

```text
bundle → Brotli (keep the smaller) → ECDH P-256 + HKDF-SHA256 (payload key, frame key) → AES-256-GCM
       → signed manifest (ECDSA P-256, low-S) → LT fountain code → frames (MAC + CRC) → QR codes
```

### 8.2 Receiving order ([ReceiveEngine](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs)), failing closed at each step

```text
frame CRC → manifest signature (sender in the trust store) → addressed to me → anti-replay → frame MAC (every data frame)
          → LT decode → ciphertext SHA-256 → AES-GCM open → decompression cap → content gate → store → commit replay
```

### 8.3 Keys and the key ceremony ✅

- Each PC has **two private keys** in the Windows CNG store, under the kiosk user: `QrDiode.{endpoint}.sign`
  (ECDSA P-256) and `QrDiode.{endpoint}.kex` (ECDH P-256). **Non-exportable**; **TPM-backed** when the machine has a
  TPM, and **required** to be with `"Production": true`.
- The other side's **public** keys come in a small JSON bundle, carried on removable media and imported into
  `%LocalAppData%\QrDiode\trust\`. Both sides compare the bundle **fingerprint** by phone or in person.
- [QrDiode.KeyCeremony](../../src/QrDiode.KeyCeremony/Program.cs): `init <name>` · `export <name> <file>` ·
  `import <file>` · `fingerprint <file>` · `list` · `delete <name> --yes` · `verify-audit [file]` · `demo` /
  `demo-clean` (refused in production). Steps: [user guide Part B](../user-guide.md).
- With `"Production": true` ([KeyPolicy](../../src/QrDiode.Core/Crypto/Provisioning/KeyPolicy.cs)): no "⚡ Demo setup" button,
  demo keys and demo trust bundles refused, software keys refused.

### 8.4 Threats

| Threat | Protection |
|---|---|
| Someone reads the screen (camera, photo) | **AES-256-GCM** with a per-session key from ECDH between the two PCs' keys + a fresh 32-byte salt (HKDF-SHA256). Without the receiver's private key, the data frames are noise. |
| Someone shows forged QR codes | The manifest is **signed**; the sender's key must be in the receiver's trust store. Every data frame has a **MAC**. Forged frames are dropped before they touch the decoder. |
| Codes meant for another receiver | The manifest names the receiver's key. Wrong key → rejected. |
| Someone re-shows an old recording | Session id, counter per sender key and run, and timestamp, all in the signed manifest and the AAD (§7.2, layer 5). |
| Bits changed on the way | Per-frame CRC and MAC, ciphertext SHA-256 in the signed manifest, the GCM tag, the exact decompressed size; then the gateway's own SHA-256 checksum per message. |
| A crafted manifest asks for huge memory | Limits checked **before** anything is allocated: payload ≤ 64 MB, K ≤ 65,536, symbol 256–4,060 bytes; decoder memory capped; decompression capped at the declared size. |
| Keys stolen from disk | Non-exportable CNG keys, TPM-backed in production; the counter file is DPAPI-protected. |
| Network attack across the gap | **There is no network.** Each lane is light, one way. The two sides never connect. |

### 8.5 What QrDiode does not hide or does not do (yet)

- **The manifest is readable on the screen**: file name (`bundle-41-42.qbb`, so the sequence numbers), sizes, time,
  counter and key ids. Not the content: since protocol v2 not even a hash of it.
- **No forward secrecy**: someone who records the screen **and** later steals the receiver's private key can decrypt
  the recording ([P-10, S-03](../qrdiode-pending-work.md#1-pending), deferred to the security sign-off).
- **The QR decoder runs inside the Receiver process** ([P-9, S-04](../qrdiode-pending-work.md#1-pending), deferred).
- **Anyone who can write into the trust folder becomes a trusted sender**: the folder ACLs are part of the kiosk
  set-up ([P-6](../qrdiode-pending-work.md#1-pending)).
- **The audit chain has no key**: it shows edits, but cannot stop someone who rewrites the whole file. Protect the
  folder.
- **At rest**, `qrbridge.db` holds the messages unencrypted: protected by the data folder ACL (app pool identity,
  kiosk user, SYSTEM, Administrators). In Bridge mode the Receiver keeps no copy of any payload.

---

## 9. The numbers (defaults)

### 9.1 Settings and constants

| Setting | Default | Where | Used in |
|---|---|---|---|
| `Sender:BundleMaxMessages` / `BundleMaxBytes` | **50 / 128 KB** (131,072 bytes) | Sender `appsettings.json` | Bundle size (A3); the format allows up to 1,000 |
| `Bridge:MaxPayloadBytes` | **1,000,000** bytes (1 MB) | both apps + gateway | Largest message; bundle parse limit |
| Symbol size | **1,350** bytes | `SendOptions.MaxSymbolSize` | Frame = 1,386 bytes → QR **version 27**, error correction **L** |
| Redundancy, loops | **3**, **3** | `SendOptions.Redundancy`, `TransmitEngine.LoopTarget` | 3 × K frames per loop, 3 loops: about **9 × K** frames per session |
| Manifest repeat | every **20** frames | `SendOptions.ManifestInterval` | A late camera syncs quickly |
| Frame rate | **15 fps** (slider 5–30) | Sender window | C4 |
| Minimum air time / gap | **6 s / 1.5 s** | `TransmitEngine` | C5 |
| Waiting simulator payloads | **14** | `TransmitEngine.MaxQueueDepth` | Standalone only |
| Doorbell poll | **2 s** | `OutboxSource` | A2 |
| Retry after an encode error | **30 s** | `OutboxSource` | C6 |
| Heartbeat row | every **30 s** | `QrAppBridge.HeartbeatInterval` | Gateway `/health` |
| Replay window | **48 h**, **15 min** in strict mode (`"StrictMode": true`, the Receiver default) | `SqliteJournal.ReplayWindow` | D3 |
| Settled sessions remembered | **4,096** | `ReceiveOptions.MaxSettledSessions` | §7.2 layer 4 |
| Largest QrDiode payload, most pieces | **64 MB**, **65,536** | `TransferManifest` | D3 |
| Audit file roll-over | **32 MB** | `AuditLog` | Both apps |
| Gateway re-air | **120 s**, **3** airs | gateway `Gateway:ReceiptTimeoutSeconds`, `MaxAirAttempts` | §6 scenario 2 |

### 9.2 Air time per session (arithmetic, not measured)

```text
K        = ceil((bundle bytes + 16) / 1,350)        (the messages are already compressed, so assume no gain)
air time = max(9 × K / fps, 6 s) + 1.5 s gap
```

| Bundle | K | Frames (≈ 9 × K) | Air time at 15 fps |
|---|---|---|---|
| 1 small message, 3 KB | 3 | 27 | **7.5 s** (6 s minimum + gap) |
| Full bundle, 128 KB | 98 | 882 | **about 60 s** |
| One large message, 500 KB | 380 | 3,420 | **about 230 s** |

> **To check during [P-4](../qrdiode-pending-work.md#1-pending):** the gateway's start-up air-time warning
> (`Gateway:Light`, 6,700 bytes/s) assumes each piece is shown **about 3 times**. With the Sender's defaults (3 loops ×
> redundancy 3) each piece's worth is shown **about 9 times**, which is about 2,250 bytes/s at 15 fps. A full 128 KB
> bundle then takes about a minute, a large share of a 90 s DMZ hold. Measure on real screens and cameras first, then
> align `LoopTarget`, `Redundancy`, `BundleMaxBytes` and `Gateway:Light`.

---

## 10. Questions the team may ask

**Q: Does the Sender know the message arrived?**
No. The light is one way. The Sender only knows it **showed** the bundle for its full air time (`Aired`). The proof
is a **Receipt** that the other side's gateway sends back on the other lane. No Receipt within 120 s → it is aired
again.

**Q: Why bundles instead of one message per QR session?**
Every session costs at least about 7.5 s on air, however small. A bundle carries up to 50 messages in that time, so a
burst of calls does not queue up behind each other (decision 52).

**Q: Does QrDiode read the SOAP messages?**
No. To QrDiode a bundle is an opaque `.qbb` file. The Receiver only peeks at each message's header to check its
direction; the gateway opens and checks the rest.

**Q: Why does the screen show the same codes again and again?**
With no "got it" coming back, repetition is the only way to beat missed frames. The fountain code makes the repeats
useful: **any** slightly more than K distinct pieces rebuild the bundle, whichever ones the camera happened to catch.

**Q: Can the camera be confused by another screen or a QR code held up to it?**
It decodes up to 2 codes per image. Frames of another session are ignored by their session tag; frames with a copied
tag fail the MAC; a forged manifest fails the signature. The genuine session completes.

**Q: Who can read the QR codes on the screen?**
Nobody without the receiver's private key: AES-256-GCM with a per-session key. The manifest itself is readable (file
name, sizes, time, key ids), but not the content.

**Q: What if the Receiver crashes just after decrypting a bundle?**
Nothing is lost. The replay state is committed only **after** the messages are in the Inbox. The session is still
receivable from the frames on air, or arrives again when the gateway re-airs it; the Inbox skips what it already has.

**Q: Can a message be delivered twice because a bundle arrived twice?**
No. The Inbox is keyed on `MessageId`: a message already there is skipped and only re-receipted (§7.2, layer 6).

**Q: Why must the apps run as the kiosk user?**
The keys, the trust store, the counter and the journal are **per Windows user**. Started as someone else, the apps
find no keys, or start a new counter run.

**Q: Can a v1 Sender talk to a v2 Receiver?**
No. Protocol v2 (26 Nov 2026) added the frame MAC; v1 frames are refused. Update both sides together.

**Q: What does the receipt hash on both screens prove?**
That both apps handled the **same signed session**. It is for an operator to compare, not a security check: the
security checks run inside the Receiver whether anyone looks or not.

**Q: Do the two sides' clocks have to match?**
Within 48 h, or 15 min in strict mode, or every session is refused as too old or from the future. A time source while
islanded is still an open item (P-7).

---

## 11. What is built and what is not

| Part | Status |
|---|---|
| QrDiode protocol v2: frames, MAC, fountain code, encryption, signatures, anti-replay, session abandon, limits | ✅ built and tested (`QrDiode.Core.Tests`) |
| Bundle format, claiming bundles from the Outbox, storing them in the Inbox in one transaction | ✅ built and tested (`QrBridge.Tests`) |
| Two gateways joined by the QR apps' bundle code (round trip, five calls in one bundle, lost bundle, bundle twice) | ✅ tested in memory (`BundleLightTests`) |
| Sender airs the Outbox, Receiver writes the Inbox (`"Mode": "Bridge"`, 27 Nov 2026) | ✅ built · 🟡 the WPF windows in Bridge mode not tried |
| Kiosk start-up (`"AutoStart"`, the stage reopens where it was, Esc asks first) | ✅ built · 🟡 not tried on a kiosk |
| A run on a real screen and camera, Standalone and Bridge ([P-1, P-2](../qrdiode-pending-work.md#1-pending)) | 🟡 not tried |
| Single-file publish with the gateway connection ([P-3](../qrdiode-pending-work.md#1-pending)) | 🟡 not tried |
| Measured air time and round-trip time, both directions ([P-4](../qrdiode-pending-work.md#1-pending)) | 🟡 not measured |
| Kiosk set-up and soak, trust-folder ACLs, time source, key rotation runbook ([P-5 … P-8](../qrdiode-pending-work.md#1-pending)) | 🟡 open |
| Decoder in its own process, forward secrecy, security sign-off ([P-9 … P-11](../qrdiode-pending-work.md#1-pending)) | 🟡 deferred / open |
