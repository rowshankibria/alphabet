# QrDiode project files: what each file is for

**Question (27 Nov 2026):** before refactoring the QrDiode projects, what is the purpose of each file in
`QrDiode.Core`, `QrDiode.KeyCeremony`, `QrDiode.Receiver` and `QrDiode.Sender`?

**Answer:** this page goes through each project, then each folder, then each file. For each file it lists the types it
contains and what they do. The last section lists what a refactor should know: the rules it must keep and the parts
of the code that do not follow the project's file-layout rules yet.

This page describes the code as it is on 27 Nov 2026 (QrDiode protocol v2, Bridge mode built). It explains the code; it
does not change it. To follow one message through these classes, read
[light-transfer-walkthrough.md](light-transfer-walkthrough.md). For the protocol design, read
[protocol-development-notes.md](../protocol-development-notes.md). For WPF basics, read [wpf-tutorial.md](../wpf-tutorial.md).

| Section | What |
|---|---|
| 1 | How the four projects fit together |
| 2 | `QrDiode.Core`: the protocol library |
| 3 | `QrDiode.KeyCeremony`: the key tool |
| 4 | `QrDiode.Receiver`: the camera app |
| 5 | `QrDiode.Sender`: the screen app |
| 6 | `src/Shared/PayloadView.cs`: shared source file |
| 7 | Notes for the refactor |

---

## 1. How the four projects fit together

| Project | Kind | Runs where | In one sentence |
|---|---|---|---|
| [QrDiode.Core](../../src/QrDiode.Core/) | Class library (`net10.0`) | Inside the other three | The QrDiode protocol: keys, encryption, the signed manifest, the fountain code, frames, anti-replay, audit log. No UI, no EF, no SQLite, no SOAP. |
| [QrDiode.KeyCeremony](../../src/QrDiode.KeyCeremony/) | Console exe | Each kiosk, once, at set-up | Creates this machine's keys, exports and imports public-key bundles, shows fingerprints, checks the audit log. |
| [QrDiode.Sender](../../src/QrDiode.Sender/) | WPF exe (`net10.0-windows`) | The sending kiosk (screen) | Turns payloads into a loop of QR codes on a screen. |
| [QrDiode.Receiver](../../src/QrDiode.Receiver/) | WPF exe (`net10.0-windows`) | The receiving kiosk (camera) | Reads QR codes from a camera, checks everything and stores what arrives. |

```text
                 QrDiode.Core  (protocol, crypto, no UI)
                 ▲      ▲      ▲
                 │      │      │
   QrDiode.KeyCeremony  │      │
                 QrDiode.Sender ──light──▶ QrDiode.Receiver
                     │                           │
                     └─────── QrBridge.Shared ───┘   (Bridge mode only: qrbridge.db, bundles, doorbells;
                                                     owned by the SOAP Gateway, referenced from ../../gateway)
```

**Angular comparison:** `QrDiode.Core` is like a shared Angular library (`projects/my-lib`) with services and models
but no components. Sender and Receiver are two Angular apps that import it. KeyCeremony is like a CLI script in
`tools/`.

**Two modes** (`"QrDiode:Mode"` in each exe's `appsettings.json`, enum `QrDiodeMode`):

- `Standalone`: the Sender airs simulator payloads or a file an operator picks; the Receiver stores files in its own
  payload store. Used for demos and bench tests.
- `Bridge`: the Sender airs the SOAP Gateway's Outbox (as bundles); the Receiver writes arriving bundles into the
  gateway's Inbox. Both go through `QrBridge.Shared` (not part of these four projects).

**Files on disk the apps use** ([QrDiodePaths.cs](../../src/QrDiode.Core/QrDiodePaths.cs), all under
`%LocalAppData%\QrDiode`): `trust\` (imported public-key bundles), `audit\` (hash-chained logs), `quarantine\` (default
payload store), `journal.db` (Receiver), `sender-counter.bin` (Sender), `receiver-settings.json`, `sender-stage.json`.

---

## 2. QrDiode.Core: the protocol library

### 2.1 Project root

| File | Types | Purpose |
|---|---|---|
| [QrDiode.Core.csproj](../../src/QrDiode.Core/QrDiode.Core.csproj) | — | Library project. Packages: `System.IO.Hashing` (CRC-32 for frames), `System.Security.Cryptography.ProtectedData` (DPAPI for the Sender's counter file). |
| [packages.lock.json](../../src/QrDiode.Core/packages.lock.json) | — | NuGet lock file (pinned versions). Generated; do not edit by hand. |
| [QrDiodePaths.cs](../../src/QrDiode.Core/QrDiodePaths.cs) | `QrDiodePaths` (static) | The local paths all three exes use (`trust`, `audit`, `quarantine`, `journal.db`, counter file, receiver settings). `EnsureCreated()` creates the folders. |

### 2.2 `Configurations/`: settings and enums

| File | Types | Purpose |
|---|---|---|
| [Options/QrDiodeOptions.cs](../../src/QrDiode.Core/Configurations/Options/QrDiodeOptions.cs) | `QrDiodeOptions` | The `"QrDiode"` section of each exe's `appsettings.json`: `Production` (kiosk rules: no demo keys, TPM required), `Mode` (Standalone/Bridge), `AllowOpaqueFiles` (Receiver). `Load()` reads it. |
| [Enums/Enums.cs](../../src/QrDiode.Core/Configurations/Enums/Enums.cs) | `QrDiodeMode` | `Standalone` or `Bridge`. |
| [Helpers/Utility.cs](../../src/QrDiode.Core/Configurations/Helpers/Utility.cs) | `AppSettings` (static) | `ReadSection<T>()`: reads one section of `appsettings.json` next to the exe. It allows comments and trailing commas, and **refuses unknown settings**, so a typo (`"Prodution"`) stops the app instead of silently using a default. Used for the `QrDiode`, `Sender`, `Receiver` and `Bridge` sections. |

### 2.3 `Audit/`

| File | Types | Purpose |
|---|---|---|
| [AuditLog.cs](../../src/QrDiode.Core/Audit/AuditLog.cs) | `AuditLog`, `AuditVerification` (record) | Append-only JSONL log. Each record contains the SHA-256 of the record before it, so an edited or deleted line breaks the chain. Rolls over at 32 MB. `Append()` writes a record; `VerifyChain()` checks a whole chain (used by `KeyCeremony verify-audit`). Sender, Receiver and KeyCeremony each write their own file. |

### 2.4 `Crypto/`: keys, trust, encryption, counter

`Crypto/` has one subfolder per purpose (27 Nov 2026). Every file keeps the namespace `QrDiode.Core.Crypto`, so the
folders are only for people: no caller changed.

| Subfolder | What it holds |
|---|---|
| `Keys/` | This machine's own keys and the other side's public keys |
| `Trust/` | Who we trust: the public-key bundles carried on removable media and the trust folder |
| `Encryption/` | Turning a payload into ciphertext and back |
| `AntiReplay/` | The Sender's counter that never goes backwards |
| `Provisioning/` | Setting keys up under the `Production` rules, and the demo set-up |

| File | Types | Purpose |
|---|---|---|
| [Keys/IEndpointKeys.cs](../../src/QrDiode.Core/Crypto/Keys/IEndpointKeys.cs) | `IEndpointKeys` | The shape of one machine's own keys: an ECDSA P-256 **signing** key and an ECDH P-256 **key-agreement** key, plus their 8-byte ids. |
| [Keys/CngEndpointKeys.cs](../../src/QrDiode.Core/Crypto/Keys/CngEndpointKeys.cs) | `CngEndpointKeys` | The real `IEndpointKeys`: named, **non-exportable** keys in Windows CNG (`QrDiode.<name>.sign` and `QrDiode.<name>.kex`). Prefers the TPM ("Microsoft Platform Crypto Provider"), otherwise uses the software key store. With `requireTpm` (production) it refuses software keys. `OpenOrCreate`, `Exists`, `Delete`. An existing key is reused as it is: a key once made in software stays in software. |
| [Keys/EphemeralEndpointKeys.cs](../../src/QrDiode.Core/Crypto/Keys/EphemeralEndpointKeys.cs) | `EphemeralEndpointKeys` | In-memory `IEndpointKeys` for tests and loopback benches. Never saved. |
| [Keys/PeerPublicKeys.cs](../../src/QrDiode.Core/Crypto/Keys/PeerPublicKeys.cs) | `PeerPublicKeys` | The other side's public keys, as imported from its bundle. |
| [Keys/KeyId.cs](../../src/QrDiode.Core/Crypto/Keys/KeyId.cs) | `KeyId` (static) | Key id = first 8 bytes of SHA-256 of the public key (SPKI). Used to find a peer in the trust store, never instead of a signature check. |
| [Trust/PublicKeyBundle.cs](../../src/QrDiode.Core/Crypto/Trust/PublicKeyBundle.cs) | `PublicKeyBundle`, `BundleJson` (internal) | The JSON file (`qrdiode-pubkeys-v1`) carried between machines on removable media, with `Fingerprint()` for the people to compare. `BundleJson` = its strict JSON options (unknown fields refused). |
| [Trust/ITrustStore.cs](../../src/QrDiode.Core/Crypto/Trust/ITrustStore.cs) | `ITrustStore` | **Who we trust:** finds a peer by its signing key id, or none. |
| [Trust/DirectoryTrustStore.cs](../../src/QrDiode.Core/Crypto/Trust/DirectoryTrustStore.cs) | `DirectoryTrustStore` | Loads every bundle in `trust\` and lists the files it skipped (`Problems`). In production, demo bundles are refused. |
| [Trust/InMemoryTrustStore.cs](../../src/QrDiode.Core/Crypto/Trust/InMemoryTrustStore.cs) | `InMemoryTrustStore` | Trust store for tests. |
| [Encryption/Envelope.cs](../../src/QrDiode.Core/Crypto/Encryption/Envelope.cs) | `Envelope` (static), `SessionKeys` (record) | The encryption: ECDH → HKDF-SHA256 → two keys per session (`PayloadKey` for AES-256-GCM, `FrameKey` for the frame MAC). `BuildAad()` binds the ciphertext to the session id, salt, counter, run id and both key ids. `Seal()` / `Open()` encrypt and decrypt. |
| [AntiReplay/CounterStore.cs](../../src/QrDiode.Core/Crypto/AntiReplay/CounterStore.cs) | `CounterStore`, `CounterReservation` (record struct) | Sender only. The counter that never goes backwards (anti-replay), stored DPAPI-protected in `sender-counter.bin` with its **run id**. `Next()` saves the new value **before** the session uses it. A lost or unreadable file starts a new run at 1. The Receiver's side of anti-replay is `Pipeline/ReplayGuard.cs`. |
| [Provisioning/KeyPolicy.cs](../../src/QrDiode.Core/Crypto/Provisioning/KeyPolicy.cs) | `KeyPolicy` (static) | One place that applies the `Production` rules: refuses the demo endpoints (`demo-ot`, `demo-it`), requires TPM keys, opens the trust store with demo bundles refused. Sender, Receiver and KeyCeremony all go through it so they apply the same rules. |
| [Provisioning/DemoProvisioner.cs](../../src/QrDiode.Core/Crypto/Provisioning/DemoProvisioner.cs) | `DemoProvisioner` (static) | The "⚡ Demo setup" button: creates **both** endpoints (`demo-ot`, `demo-it`) on one machine and makes each trust the other. Security is still fully on; only the key separation is a demo shortcut. Refused when `Production` is true. |

### 2.5 `Manifest/`

| File | Types | Purpose |
|---|---|---|
| [TransferManifest.cs](../../src/QrDiode.Core/Manifest/TransferManifest.cs) | `TransferManifest`, `ContentKind` (enum), `CompressionAlg` (enum) | The signed "cover letter" of one transfer: session id, timestamp, counter, run id, key ids, salt, nonce, symbol size, K, LT seed, sizes, ciphertext hash, filename, content kind. Fixed binary layout. `Serialize()`, `TryParse()` (strict limits: 64 MB max payload, K ≤ 65,536), `Sign()` (low-S ECDSA so each manifest has exactly one valid signature), `VerifySignature()`, `ReceiptHash()`. |

### 2.6 `Fountain/`: the LT fountain code

The fountain code lets the Receiver rebuild the payload from **any** large enough set of QR frames, in any order, with
some frames missed. No back-channel is needed.

| File | Types | Purpose |
|---|---|---|
| [DeterministicRandom.cs](../../src/QrDiode.Core/Fountain/DeterministicRandom.cs) | `DeterministicRandom` (struct) | xoshiro256++ random generator. It gives the same numbers on every machine and every .NET version; `System.Random` does not promise that. Both sides must pick the same blocks for each symbol. |
| [RobustSoliton.cs](../../src/QrDiode.Core/Fountain/RobustSoliton.cs) | `RobustSoliton` | The degree distribution (how many source blocks one coded symbol mixes). Computed once per session. |
| [LtCode.cs](../../src/QrDiode.Core/Fountain/LtCode.cs) | `LtCode` (static) | Shared rules: `GetNeighbors()` (which source blocks a coded symbol XORs) and `SourceBlockCount()` (K). Symbols `0 … K-1` are the plain blocks ("systematic"). |
| [LtEncoder.cs](../../src/QrDiode.Core/Fountain/LtEncoder.cs) | `LtEncoder` | Sender: `GenerateSymbol(id)` produces any symbol at any time, which keeps the carousel loop cheap. |
| [LtDecoder.cs](../../src/QrDiode.Core/Fountain/LtDecoder.cs) | `LtDecoder` | Receiver: "peeling" decoder. Accepts symbols in any order, drops duplicates, and limits memory (`MaxBufferedSymbols`, `MaxTrackedSymbolIds`). |

### 2.7 `Framing/`: one QR code = one frame

| File | Types | Purpose |
|---|---|---|
| [FrameFormat.cs](../../src/QrDiode.Core/Framing/FrameFormat.cs) | `FrameFormat` (static constants), `FrameType` (enum) | The wire format of protocol v2: magic `OD`, version `0x02`, type, 8-byte session tag, sizes, CRC-32 at the end, 16-byte MAC on data frames, 64-byte signature on manifest frames, 4,096-byte maximum frame. |
| [FrameWriter.cs](../../src/QrDiode.Core/Framing/FrameWriter.cs) | `FrameWriter` (static) | Sender: builds manifest frames and data frames (header, symbol id, payload, MAC, CRC). |
| [FrameParser.cs](../../src/QrDiode.Core/Framing/FrameParser.cs) | `FrameParser` (static), `ParsedFrame` (ref struct), `FrameParseError` (enum) | Receiver: the **first contact with untrusted input**. `TryParse()` checks every length before reading. It allocates nothing and throws nothing on bad input. |
| [FrameMac.cs](../../src/QrDiode.Core/Framing/FrameMac.cs) | `FrameMac` (static) | HMAC-SHA256 truncated to 16 bytes, with the session's frame key. Stops a QR code someone holds up to the camera from reaching the decoder. Constant-time `Verify()`. |

### 2.8 `Pipeline/`: the two engines and their checks

| File | Types | Purpose |
|---|---|---|
| [SendSession.cs](../../src/QrDiode.Core/Pipeline/SendSession.cs) | `SendSession`, `SendOptions` | Sender, one transfer: plaintext → Brotli (only if smaller) → session keys → AES-GCM → signed manifest → LT encoder. `Create()` does it; `ManifestFrame`, `GetDataFrame(id)` and `Carousel()` (endless frame sequence, manifest every 20 frames) supply the frames. `SendOptions`: symbol size 1,350, redundancy 3, manifest interval 20. |
| [ReceiveEngine.cs](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs) | `ReceiveEngine`, `FeedResult` (enum), `CompletedTransfer`, `RejectionInfo`, `AbandonedSession`, `ReceiveOptions` | Receiver, the heart of the checking. `Feed(qrBytes)` runs the chain in a fixed order and refuses at the first failure: CRC → signature → addressed to us → anti-replay → frame MAC → LT decode → ciphertext hash → AES-GCM → decompression cap → content gate. `CommitReplay()` is called by the host **after** it stored the payload. `SessionAbandoned` fires when a newer verified session replaces an incomplete one. |
| [ReplayGuard.cs](../../src/QrDiode.Core/Pipeline/ReplayGuard.cs) | `IReplayGuard`, `ReplayVerdict` (enum), `InMemoryReplayGuard` | Anti-replay rules: session id never seen, counter above the watermark for that sender key **and run**, timestamp inside the window (48 h default). The in-memory version is for tests; the Receiver app uses `SqliteJournal`. |
| [ContentGate.cs](../../src/QrDiode.Core/Pipeline/ContentGate.cs) | `ContentGate` (static) | The last check, after the cryptographic checks: XML and JSON are parsed with hardened settings (no DTD, depth ≤ 64); `File` content is not parsed. |

### 2.9 `Presentation/` and `Simulation/`

| File | Types | Purpose |
|---|---|---|
| [Presentation/PayloadFormatter.cs](../../src/QrDiode.Core/Presentation/PayloadFormatter.cs) | `PayloadFormatter` (static), `PayloadText` (record), `PayloadTextKind` (enum) | Turns payload bytes into readable text for the viewers: `Formatted()` (pretty JSON/XML), `Raw()`, `Hex()`, `Snippet()` (first line for list rows). Both apps use it so the two screens can be compared. Not a security check, but the parsers are hardened anyway. |
| [Simulation/PayloadType.cs](../../src/QrDiode.Core/Simulation/PayloadType.cs) | `PayloadType` (record), `PayloadCatalogue` (static) | The kinds of payload (e.g. `order.created` → tile `ORD`, its colours, its content kind). Kept in Core so the Sender's queue and the Receiver's inbox show the same tile. |
| [Simulation/PayloadSimulator.cs](../../src/QrDiode.Core/Simulation/PayloadSimulator.cs) | `PayloadSimulator`, `SimulatorOptions`, `GeneratedPayload` (record) | Standalone demos: generates realistic plant events at irregular times (quiet gaps, then bursts). `NextDelay()`, `Generate()`. Seedable for tests. |

---

## 3. QrDiode.KeyCeremony: the key tool

| File | Purpose |
|---|---|
| [QrDiode.KeyCeremony.csproj](../../src/QrDiode.KeyCeremony/QrDiode.KeyCeremony.csproj) | Console exe, references Core only. Copies `appsettings.json` next to the exe (also after a single-file publish). |
| [appsettings.json](../../src/QrDiode.KeyCeremony/appsettings.json) | `"QrDiode": { "Production": … }` only. |
| [packages.lock.json](../../src/QrDiode.KeyCeremony/packages.lock.json) | NuGet lock file. Generated. |
| [Program.cs](../../src/QrDiode.KeyCeremony/Program.cs) | The whole tool (top-level statements). Commands: `init <name>` (create this machine's keys), `export <name> <file>` (write its public bundle), `import <file>` (trust the other side's bundle; never overwrites), `fingerprint <file>`, `list`, `delete <name> --yes`, `verify-audit [file]`, `demo`, `demo-clean`. Each command is a local function; all key rules go through `KeyPolicy`. |

---

## 4. QrDiode.Receiver: the camera app

**WPF in Angular terms:** a `.xaml` file is the component's template (`.html`), the matching `.xaml.cs` is the
component class (`.ts`, called "code-behind"), `Theme.xaml` is the global stylesheet (`styles.scss`), `App.xaml` is
`main.ts` + `app.config.ts`, and an `IValueConverter` is a pipe.

### 4.1 Project root

| File | Purpose |
|---|---|
| [QrDiode.Receiver.csproj](../../src/QrDiode.Receiver/QrDiode.Receiver.csproj) | WPF exe. References Core and `QrBridge.Shared` (Bridge mode; also brings SQLite). Links `../Shared/PayloadView.cs`. Packages: `FlashCap` (camera), `ZXingCpp` (QR decoding, native). |
| [packages.lock.json](../../src/QrDiode.Receiver/packages.lock.json) | NuGet lock file. Generated. |
| [appsettings.json](../../src/QrDiode.Receiver/appsettings.json) | Sections `QrDiode` (Production, Mode, AllowOpaqueFiles), `Bridge` (Side, DataFolder, MaxPayloadBytes — same as the gateway's), `Receiver` (AutoStart, Endpoint, Camera, StrictMode). |
| [App.xaml](../../src/QrDiode.Receiver/App.xaml) / [App.xaml.cs](../../src/QrDiode.Receiver/App.xaml.cs) | Application start: opens `MainWindow`, loads `Theme.xaml` for the whole app. The `.cs` file is empty (template). |
| [AssemblyInfo.cs](../../src/QrDiode.Receiver/AssemblyInfo.cs) | WPF template boilerplate (`ThemeInfo`: where WPF looks for theme resources). |
| [Theme.xaml](../../src/QrDiode.Receiver/Theme.xaml) | All colours, fonts and control styles (buttons, chips, pills, lists, tabs, scrollbars). Nearly the same as the Sender's; the Receiver adds the tab styles. |
| [Converters.cs](../../src/QrDiode.Receiver/Converters.cs) | `HexBrushConverter`: turns the catalogue's colour strings (`"#FF423A6A"`) into WPF brushes, with a cache. Core cannot create WPF brushes. |
| [MainWindow.xaml](../../src/QrDiode.Receiver/MainWindow.xaml) | The window layout: header (trust/camera pills), **Live** tab (camera preview + controls, live inbox list, selected-entry detail with the verification chain and payload viewer) and **Archive** tab (storage location, filters and totals, archived list, selected record with "verify file"). Row templates (`DataTemplate`s) are at the top. |
| [MainWindow.xaml.cs](../../src/QrDiode.Receiver/MainWindow.xaml.cs) | The Live tab's logic, 1,384 lines. Start-up and settings, Bridge connection and heartbeat (`ConnectBridgeAsync`, `Beat`), kiosk `AutoStart`, keys and demo set-up, camera choice, `Start_Click`/`Stop_Click`, `OnQrPayload` (camera thread → `ReceiveEngine.Feed`), the result handlers (`HandleCompletion`, `HandleBundleAsync` for Bridge mode, `HandleNotABundle`, `HandleRejection`, `HandleAlreadyReceived`, `HandleAbandoned`), the chain texts shown to the operator, the inbox list/filter/detail, and the UI timer (`OnUiTick`). |
| [MainWindow.Archive.cs](../../src/QrDiode.Receiver/MainWindow.Archive.cs) | The Archive tab's logic (a second `partial` file of the same `MainWindow` class): storage settings, `IndexArrival` (writes each arrival to the journal), loading and filtering the archive, record detail, copy/export/open folder, and `VerifyFile_Click` (re-hashes a stored file against the hash recorded on arrival). |

### 4.2 Folders

| File | Types | Purpose |
|---|---|---|
| [Capture/QrDecodePipeline.cs](../../src/QrDiode.Receiver/Capture/QrDecodePipeline.cs) | `QrDecodePipeline`, `LumFrame` (nested record struct) | Camera → greyscale → QR decode. `EnumerateCameras()`, `StartAsync()`. Handles both raw (YUV/BMP) and MJPEG camera frames. Drops frames while a decode is busy (the carousel repeats them anyway). Counts frames seen, decoded, QR hits and unreadable frames. |
| [Configurations/Options/ReceiverOptions.cs](../../src/QrDiode.Receiver/Configurations/Options/ReceiverOptions.cs) | `ReceiverOptions` | The `"Receiver"` section: `AutoStart`, `Endpoint`, `Camera`, `StrictMode` (15-minute replay window instead of 48 h). |
| [Inbox/InboxEntry.cs](../../src/QrDiode.Receiver/Inbox/InboxEntry.cs) | `InboxEntry`, `InboxOutcome` (enum), `ChainStatus` (enum), `ChainStep` (record) | One row of the live inbox (a view model). Rejections, duplicates and incomplete sessions are rows too. Keeps a capped preview of the bytes (128 KB, only for the newest 60 rows). `ChainStep` is one line of the "what was checked" list. |
| [Storage/ArchiveRecord.cs](../../src/QrDiode.Receiver/Storage/ArchiveRecord.cs) | `ArchiveRecord`, `IntegrityState` (enum), `ArchiveQuery`, `ArchiveTotals`, `TypeTally` (records) | One row of the Archive tab (from the journal), with its integrity state after "verify file" (Intact / Altered / Missing). The records are the query and its result totals. |
| [Storage/PayloadStore.cs](../../src/QrDiode.Receiver/Storage/PayloadStore.cs) | `PayloadStore` | Standalone mode: where verified payloads land as files (plus an optional `.meta.json` next to each). Writes atomically: staging file, flush, rename. `SanitizeFilename()` cleans the sender's filename. |
| [Storage/ReceiverSettings.cs](../../src/QrDiode.Receiver/Storage/ReceiverSettings.cs) | `ReceiverSettings` | Operator preferences kept between runs (`receiver-settings.json`): storage folder, folders per day, sidecar on/off. Nothing security-related. |
| [Storage/SqliteJournal.cs](../../src/QrDiode.Receiver/Storage/SqliteJournal.cs) | `SqliteJournal` | `journal.db` (SQLite, WAL, raw ADO.NET — not EF). Two jobs: the real `IReplayGuard` (sessions seen, watermark per sender key and run) and the archive index (`IndexArrival`, `QueryArchive`, `QueryTotals`, `QueryTypeTallies`). Not the gateway's `qrbridge.db`. |

---

## 5. QrDiode.Sender: the screen app

### 5.1 Project root

| File | Purpose |
|---|---|
| [QrDiode.Sender.csproj](../../src/QrDiode.Sender/QrDiode.Sender.csproj) | WPF exe. References Core and `QrBridge.Shared`. Links `../Shared/PayloadView.cs`. Package: `Net.Codecrete.QrCodeGenerator` (draws the QR codes). |
| [packages.lock.json](../../src/QrDiode.Sender/packages.lock.json) | NuGet lock file. Generated. |
| [appsettings.json](../../src/QrDiode.Sender/appsettings.json) | Sections `QrDiode` (Production, Mode), `Bridge` (Side, DataFolder, MaxPayloadBytes), `Sender` (BundleMaxMessages 50, BundleMaxBytes 128 KB, AutoStart, Endpoint, Receiver). |
| [App.xaml](../../src/QrDiode.Sender/App.xaml) / [App.xaml.cs](../../src/QrDiode.Sender/App.xaml.cs) | Application start: opens `MainWindow`, loads `Theme.xaml`. The `.cs` file is empty. |
| [AssemblyInfo.cs](../../src/QrDiode.Sender/AssemblyInfo.cs) | WPF template boilerplate. Identical to the Receiver's. |
| [Theme.xaml](../../src/QrDiode.Sender/Theme.xaml) | The Sender's styles. Nearly the same as the Receiver's (no tab styles). |
| [Converters.cs](../../src/QrDiode.Sender/Converters.cs) | `HexBrushConverter`, the same as the Receiver's, in the Sender's namespace. |
| [MainWindow.xaml](../../src/QrDiode.Sender/MainWindow.xaml) | The operator dashboard, in numbered steps: 1–2 keys and receiver, 3 source (live simulator with a sparkline, manual file, or the Bridge-mode Outbox panel), 4 queue and stream, payload inspector, status strip, demo strip. |
| [MainWindow.xaml.cs](../../src/QrDiode.Sender/MainWindow.xaml.cs) | Dashboard logic, 765 lines: settings and mode (`ApplyMode`), Bridge connection (`ConnectBridgeAsync` → `OutboxSource`), kiosk `AutoStart`, keys/trust/receiver choice, demo set-up, simulator controls (types, interval, run/stop, inject), file browse, opening the stage, queue list and payload inspector, refresh and log. |
| [StageWindow.xaml](../../src/QrDiode.Sender/StageWindow.xaml) | The window the camera looks at: the QR on a pure white plate, with small chrome above and below it. |
| [StageWindow.xaml.cs](../../src/QrDiode.Sender/StageWindow.xaml.cs) | Draws one frame per screen refresh (`OnRendering` → `TransmitEngine.Advance()`), keeps an integer pixel scale so modules stay sharp, size presets, keep-on-top, keys (Space pauses the source; Esc asks first in Bridge/kiosk mode), keeps the display awake, saves its position. |

### 5.2 Folders

| File | Types | Purpose |
|---|---|---|
| [Configurations/Options/SenderOptions.cs](../../src/QrDiode.Sender/Configurations/Options/SenderOptions.cs) | `SenderOptions` | The `"Sender"` section: bundle limits (decision 52), `AutoStart`, `Endpoint`, `Receiver`. `Problem()` checks the values. |
| [Transmit/TransmitEngine.cs](../../src/QrDiode.Sender/Transmit/TransmitEngine.cs) | `TransmitEngine`, `StageState` (enum) | The Sender's scheduler. Takes queue items one at a time, builds a `SendSession` on a background thread (reserving the counter first), airs it for "3 loops **or** 6 s, whichever is longer", then a 1.5 s gap. Drops only `Droppable` (simulator) items when more than 14 wait. Raises `ItemFinished`. |
| [Transmit/QueueItem.cs](../../src/QrDiode.Sender/Transmit/QueueItem.cs) | `QueueItem`, `QueueState` (enum) | One payload's life on the Sender (Queued → Encoding → OnAir → Sent / Skipped / Failed), air time, loops, receipt, `BundleId` in Bridge mode. A view model for the queue list. |
| [Transmit/LiveSource.cs](../../src/QrDiode.Sender/Transmit/LiveSource.cs) | `LiveSource` | Standalone mode: wraps `PayloadSimulator` in a UI timer, raises `Emitted`, keeps the 60 s histogram for the sparkline. |
| [Transmit/OutboxSource.cs](../../src/QrDiode.Sender/Transmit/OutboxSource.cs) | `OutboxSource` | Bridge mode: waits on the gateway's Outbox doorbell (2 s poll as fallback), claims the next bundle (`OutboxBundler`) when the queue is empty, queues it, and when it ends marks the rows: Sent → `Aired`; Skipped → back now; Failed → back after 30 s. Reaches the engine only on the UI thread. |
| [Rendering/CarouselPump.cs](../../src/QrDiode.Sender/Rendering/CarouselPump.cs) | `CarouselPump` | Background producer: walks `SendSession.Carousel()` and renders QR pixel buffers into a bounded channel (16 frames), recycling buffers, so the UI thread only copies pixels. |
| [Rendering/QrFrameRenderer.cs](../../src/QrDiode.Sender/Rendering/QrFrameRenderer.cs) | `QrFrameRenderer` | Frame bytes → greyscale QR pixels. Picks one QR version per session (smallest that fits, ECC L) so the code never changes size mid-session; 8-module quiet zone. |
| [Rendering/StagePlacement.cs](../../src/QrDiode.Sender/Rendering/StagePlacement.cs) | `StagePlacement` | Saves and restores the stage window's position, size and keep-on-top (`sender-stage.json`), so a kiosk restart puts the QR back in front of the camera. |

---

## 6. `src/Shared/PayloadView.cs`: shared source file

| File | Types | Purpose |
|---|---|---|
| [PayloadView.cs](../../src/Shared/PayloadView.cs) | `PayloadView` (static partial, namespace `QrDiode.Ui`) | Syntax colouring for the payload viewers (turns a `PayloadText` into a WPF `FlowDocument`). It is **compiled into both apps as a linked file** (`<Compile Include … Link=…>` in each `.csproj`), not a separate DLL, because Core has no WPF and both screens must colour a payload the same way. Shows up as `Inbox/PayloadView.cs` in the Receiver and `Transmit/PayloadView.cs` in the Sender. |

---

## 7. Notes for the refactor

### 7.1 Rules a refactor must keep

From [copilot-instructions.md](../../../../.github/copilot-instructions.md) and
[qrdiode-wpf.instructions.md](../../../../.github/instructions/qrdiode-wpf.instructions.md):

- **Keep the project structure** (settled decision 3): the projects Core, KeyCeremony, Sender and Receiver keep their
  names and folders. A refactor works **inside** them. Restructuring projects needs Rowshan's agreement.
- **`QrDiode.Core` stays independent**: no EF, no SQLite, no SOAP, no WPF. Gateway and database code stays in
  `QrBridge.Shared`.
- **Do not change the wire format by accident.** `FrameFormat`, `TransferManifest`'s byte layout, `Envelope`'s HKDF
  labels and AAD, `DeterministicRandom` and `LtCode` must give the same bytes on both sides. A change means a new protocol
  version and updating both kiosks together.
- **Keep the order of the checks** in `ReceiveEngine.Feed` and the rule "store first, then `CommitReplay()`".
- Outbox items stay non-droppable; never log payloads.
- After each step: `dotnet test sourcecode\qrdiode\QrDiode.slnx`, then `dotnet test All.slnx` (expected 564 + 116
  passed).

### 7.2 Where the code does not follow the file-layout rules yet

The rule is: one class or interface per file, named after it; **all** of a project's enums in
`Configurations/Enums/Enums.cs`; static helpers in `Configurations/Helpers/Utility.cs`; a record that belongs to a class
may stay in that class's file. The instructions note that older QrDiode files do not follow it yet. Here they are:

| File | What does not fit the rule |
|---|---|
| [Utility.cs](../../src/QrDiode.Core/Configurations/Helpers/Utility.cs) | Contains a class called `AppSettings`, not `Utility`. |
| [ReplayGuard.cs](../../src/QrDiode.Core/Pipeline/ReplayGuard.cs) | `IReplayGuard` + `InMemoryReplayGuard` + enum `ReplayVerdict`. |
| [ReceiveEngine.cs](../../src/QrDiode.Core/Pipeline/ReceiveEngine.cs) | Enum `FeedResult`, class `CompletedTransfer` and options record `ReceiveOptions` next to the engine (the result records can stay). |
| [SendSession.cs](../../src/QrDiode.Core/Pipeline/SendSession.cs) | `SendOptions` (a settings class) in the same file. |
| [PayloadSimulator.cs](../../src/QrDiode.Core/Simulation/PayloadSimulator.cs) | `SimulatorOptions` (a settings class) in the same file. |
| [PayloadType.cs](../../src/QrDiode.Core/Simulation/PayloadType.cs) | `PayloadType` + `PayloadCatalogue`. |
| [FrameFormat.cs](../../src/QrDiode.Core/Framing/FrameFormat.cs), [FrameParser.cs](../../src/QrDiode.Core/Framing/FrameParser.cs), [TransferManifest.cs](../../src/QrDiode.Core/Manifest/TransferManifest.cs), [PayloadFormatter.cs](../../src/QrDiode.Core/Presentation/PayloadFormatter.cs) | Enums kept next to their class (`FrameType`, `FrameParseError`, `ContentKind`, `CompressionAlg`, `PayloadTextKind`) instead of in `Enums.cs`. |
| [InboxEntry.cs](../../src/QrDiode.Receiver/Inbox/InboxEntry.cs), [ArchiveRecord.cs](../../src/QrDiode.Receiver/Storage/ArchiveRecord.cs) | Receiver enums (`InboxOutcome`, `ChainStatus`, `IntegrityState`) in class files; the Receiver has no `Configurations/Enums/Enums.cs` yet. |
| [TransmitEngine.cs](../../src/QrDiode.Sender/Transmit/TransmitEngine.cs), [QueueItem.cs](../../src/QrDiode.Sender/Transmit/QueueItem.cs) | Sender enums (`StageState`, `QueueState`) in class files; the Sender has no `Configurations/Enums/Enums.cs` yet. |
| [QrDiodePaths.cs](../../src/QrDiode.Core/QrDiodePaths.cs) | Sits in the project root; it is configuration-like and could move under `Configurations/` (same namespace, so no caller changes). |

Moving an enum or a class to another file **in the same namespace** changes no caller and no bytes on the wire: these
are the safest first steps.

### 7.3 Larger candidates (ask before doing)

| Where | What is seen | Possible direction |
|---|---|---|
| [Receiver MainWindow.xaml.cs](../../src/QrDiode.Receiver/MainWindow.xaml.cs) (1,384 lines) | One class does start-up, Bridge connection, camera, engine wiring, every result handler, chain texts and the inbox UI. | Move the non-UI parts into classes (e.g. the chain texts into a static class in `Inbox/`, the Bridge store step next to `HandleBundleAsync` into its own class), or more `partial` files like `MainWindow.Archive.cs`. In Angular terms: take logic out of the component into services. |
| [Sender MainWindow.xaml.cs](../../src/QrDiode.Sender/MainWindow.xaml.cs) (765 lines) | Same pattern, smaller. | Same approach. |
| `Theme.xaml`, `Converters.cs`, `AssemblyInfo.cs` in both apps | Copied files: `AssemblyInfo.cs` is identical; `Converters.cs` has the same code (only the namespace and a comment differ); `Theme.xaml` differs in about 50 lines. | Could become linked files under `src/Shared/` like `PayloadView.cs`. The theme needs the per-app differences (accent, tabs) kept. |
| `BundleType` (`"gateway bundle"`, `"QBB"`) | Defined twice: Receiver `MainWindow.xaml.cs` and Sender `OutboxSource.cs`. | One definition in `PayloadCatalogue` (Core). |
