# WPF Quick Start — develop, publish, run the .exe

A practical primer for this project (QrDiode.Sender / QrDiode.Receiver on .NET 10).
Read sections 1–4 once, then use 5–8 as a reference.

---

## 1. What WPF is, in one minute

WPF (Windows Presentation Foundation) is Microsoft's desktop UI framework for Windows.

- The **UI is written in XAML** (an XML markup language), like Angular templates.
- The **logic is written in C#**.
- They are glued together with **data binding**, like Angular's `{{ }}` and `[(ngModel)]`.

If you know Angular, this map will get you most of the way:

| Angular | WPF |
|---|---|
| `component.html` | `MainWindow.xaml` |
| `component.ts` | `MainWindow.xaml.cs` ("code-behind") or, better, a ViewModel class |
| `{{ name }}` / `[value]="name"` | `Text="{Binding Name}"` |
| `[(ngModel)]="name"` | `Text="{Binding Name, Mode=TwoWay}"` |
| `(click)="save()"` | `Command="{Binding SaveCommand}"` |
| `*ngFor` | `ItemsControl` / `ListBox` with `ItemsSource="{Binding Items}"` |
| Change detection | `INotifyPropertyChanged` (you raise "property changed" yourself) |
| Services + DI | Same idea: `Microsoft.Extensions.DependencyInjection` |
| `styles.css` | `ResourceDictionary` (e.g. `Theme.xaml` in QrDiode) |
| `main.ts` bootstrap | `App.xaml` + `App.xaml.cs` |

The recommended pattern is **MVVM** (Model–View–ViewModel):

- **View** = XAML. Only layout, with no logic.
- **ViewModel** = a plain C# class with properties and commands that the View binds to.
- **Model** = your data and services (for us: SQLite repositories, the QrDiode engines).

> **In this repo:** the QrDiode windows are written in **code-behind**. Event handlers in `MainWindow.xaml.cs` set
> the controls directly, and small observable item classes back the lists (`Transmit/QueueItem.cs` in the Sender,
> `Inbox/InboxEntry.cs` in the Receiver). When you change those windows, follow that style. MVVM is still the better
> pattern for new, separate windows.

---

## 2. One-time setup

1. **.NET 10 SDK.** Install the released SDK (not a preview) from https://dotnet.microsoft.com/download.
   Check it with:
   ```powershell
   dotnet --list-sdks      # you want a released 10.0.x line, e.g. 10.0.404 (not "-rc"); global.json requires 10.0
   ```
2. **Editor.** Use one of these:
   - **VS Code** with the **C# Dev Kit** and **GitHub Copilot** extensions. It's good for code, building, debugging
     and Copilot Chat. This repo's Copilot instructions, prompts and agents are in `.github/`.
     It has **no visual XAML designer**, so you type the XAML and run the app to see it.
   - **Visual Studio 2022/2026 Community** (free). It has a XAML designer, **XAML Hot Reload**
     (edit XAML while the app runs) and the Live Visual Tree. It's very helpful while learning.
     You can use both editors on the same files.

---

## 3. Your first WPF app (10 minutes)

### 3.1 Create and run

```powershell
mkdir C:\src\WpfHello; cd C:\src\WpfHello
dotnet new wpf -n WpfHello
cd WpfHello
dotnet run
```

A blank window should appear. This is the project structure:

```
WpfHello/
  WpfHello.csproj      <- project file (like package.json + angular.json)
  App.xaml             <- app start-up + global resources (styles)
  App.xaml.cs
  MainWindow.xaml      <- the window's UI
  MainWindow.xaml.cs   <- code-behind for the window
  AssemblyInfo.cs
```

The important lines in `WpfHello.csproj` are:

```xml
<OutputType>WinExe</OutputType>                 <!-- a GUI .exe, no console window -->
<TargetFramework>net10.0-windows</TargetFramework> <!-- WPF is Windows-only -->
<UseWPF>true</UseWPF>                           <!-- turns WPF on -->
```

QrDiode.Sender's csproj has exactly these lines too.

### 3.2 Add a ViewModel (MVVM done by hand, so you see what's happening)

Create `MainViewModel.cs`:

```csharp
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace WpfHello;

public class MainViewModel : INotifyPropertyChanged
{
    private string _name = "";
    private string _greeting = "Type a name and press Greet";

    public string Name
    {
        get => _name;
        set { _name = value; OnPropertyChanged(); }
    }

    public string Greeting
    {
        get => _greeting;
        set { _greeting = value; OnPropertyChanged(); }
    }

    public ICommand GreetCommand { get; }

    public MainViewModel()
    {
        GreetCommand = new RelayCommand(() => Greeting = $"Hello, {Name}!");
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? prop = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
}

// Minimal ICommand implementation (button -> method)
public class RelayCommand(Action execute) : ICommand
{
    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? parameter) => true;
    public void Execute(object? parameter) => execute();
}
```

Replace `MainWindow.xaml`:

```xml
<Window x:Class="WpfHello.MainWindow"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="WPF Hello" Height="220" Width="400">
    <StackPanel Margin="16">
        <TextBlock Text="Name:" />
        <TextBox Text="{Binding Name, UpdateSourceTrigger=PropertyChanged}" Margin="0,4,0,8"/>
        <Button Content="Greet" Command="{Binding GreetCommand}" Width="100" HorizontalAlignment="Left"/>
        <TextBlock Text="{Binding Greeting}" FontSize="18" Margin="0,12,0,0"/>
    </StackPanel>
</Window>
```

Connect the View to the ViewModel in `MainWindow.xaml.cs`:

```csharp
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainViewModel();   // <- everything {Binding ...} reads from this
    }
}
```

Run it again with `dotnet run`. Typing updates `Name`, and the button runs `GreetCommand`.
When the command sets `Greeting`, it raises `PropertyChanged` and the label updates.
**This loop is how all WPF apps work.**

> Shortcut for real code: the NuGet package **CommunityToolkit.Mvvm** generates the
> `INotifyPropertyChanged` and command plumbing for you, using `[ObservableProperty]` and `[RelayCommand]`.
> Learn the manual way first (above), then switch.

### 3.3 Layout basics

| Panel | Use it for |
|---|---|
| `Grid` | Rows and columns. It's the main layout tool (like CSS grid). |
| `StackPanel` | Stacking children vertically or horizontally. |
| `DockPanel` | Toolbars and status bars docked to the edges. |
| `Border` | A background, border or padding around one child. |
| `ScrollViewer` | Making its content scroll. |

```xml
<Grid>
  <Grid.RowDefinitions>
    <RowDefinition Height="Auto"/>   <!-- size to content -->
    <RowDefinition Height="*"/>      <!-- take the rest -->
  </Grid.RowDefinitions>
  <TextBlock Grid.Row="0" Text="Header"/>
  <ListBox   Grid.Row="1" ItemsSource="{Binding Items}"/>
</Grid>
```

Use `ObservableCollection<T>` (not `List<T>`) for lists the UI shows. Adding or removing items then updates the UI.

---

## 4. Rules that matter for THIS project

1. **Never block the UI thread.** Use `await` for SQLite, file and camera work.
   ```csharp
   var counts = await outboxRepository.GetCountsAsync(ct);   // good
   var counts = outboxRepository.GetCountsAsync(ct).Result;  // BAD: freezes the window, can deadlock
   ```
2. **Only the UI thread may touch UI objects.** From a background loop (camera, sender),
   either update a ViewModel property (WPF marshals simple property bindings for you), or queue the change on the
   UI thread:
   ```csharp
   Application.Current.Dispatcher.BeginInvoke(() => Items.Add(row));
   ```
   Changes to an `ObservableCollection` from a background thread **throw**, so always go through the Dispatcher.
   Prefer `BeginInvoke` / `InvokeAsync` over `Invoke`. `Invoke` makes the background thread wait for the UI thread,
   which can deadlock. The Receiver does exactly this for every decoded QR code (`OnQrPayload` in
   `sourcecode\qrdiode\src\QrDiode.Receiver\MainWindow.xaml.cs`).
3. **Long-running loops** (the sender carousel, the camera reader) run as `Task`s started from
   `App.OnStartup` or the window's `Loaded` event, and stop through a `CancellationToken` in `OnExit`.
4. **Settings.** Today the QR apps keep their settings, keys and journal per Windows user in `%LocalAppData%\QrDiode\`
   (for example `receiver-settings.json`; see `sourcecode\qrdiode\src\QrDiode.Core\QrDiodePaths.cs`). Connecting them to the Gateway-to-QrDiode system
   adds an `appsettings.json` next to the `.exe` for `GatewayDatabase:Side` and `GatewayDatabase:DataFolder`. It is loaded with
   `Microsoft.Extensions.Configuration`, as in the Gateway ([Integration Plan §2.4](../../../docs/gateway-to-qrdiode/integration-plan.md)).
   Mark it *Copy to Output Directory* so it ships next to the `.exe`:
   ```xml
   <ItemGroup>
     <None Update="appsettings*.json" CopyToOutputDirectory="PreserveNewest" />
   </ItemGroup>
   ```
5. **The shared message database (`qrbridge.db`, one file per machine) lives in `C:\ProgramData\QrBridge\Data`**, never next to the
   .exe and never in Program Files (design record D2).

---

## 5. Build, run and debug the QrDiode apps

Run these from the solution folder (`QrDiode_V2`). Keep that folder at a **short path** such as `C:\src\QrDiode_V2`:
in a very deep folder, Windows refuses to load the native `ZXing.dll` the Receiver uses.

```powershell
dotnet test All.slnx        # the quickest full check: builds both solutions, runs all tests

dotnet restore sourcecode\qrdiode\QrDiode.slnx
dotnet build   sourcecode\qrdiode\QrDiode.slnx
dotnet test    sourcecode\qrdiode\QrDiode.slnx

dotnet run --project sourcecode\qrdiode\src\QrDiode.Sender      # start the sender
dotnet run --project sourcecode\qrdiode\src\QrDiode.Receiver    # start the receiver (second terminal)
```

To **debug in VS Code**, open the folder and press **F5**. C# Dev Kit asks which project to launch;
pick `QrDiode.Sender`. You can set breakpoints in `.cs` files (not in XAML).

The build output lands in `sourcecode\qrdiode\src\QrDiode.Sender\bin\Debug\net10.0-windows\QrDiode.Sender.exe`.
You can double-click that .exe, but it is a **debug build that needs .NET installed**, so don't ship it.

---

## 6. Publish: make the .exe you deploy

"Publish" produces a folder you can copy to another machine.

**For this repo**, publish the gateway for IIS into `publish\gateway\`, and the Sender, Receiver and KeyCeremony as
self-contained single files (option C below) into `publish\sender\`, `publish\receiver\` and `publish\keys\`; the
exact commands are in the [guide §12.3](../../../docs/gateway-to-qrdiode/technical-guide.md#123-publish). Right after a publish, the next normal build of the WPF projects can fail
**once** with `BG1002` / `CS2001` (a missing `.baml` / `.g.cs`). Just build again.

To do the same by hand, there are three common choices:

### Option A — Framework-dependent (small; the target needs .NET 10 Desktop Runtime)

```powershell
dotnet publish sourcecode\qrdiode\src\QrDiode.Sender -c Release -r win-x64 --self-contained false
```
- The output is a few MB.
- The target machine must have the **.NET 10 Desktop Runtime** installed (not just the ASP.NET runtime).

### Option B — Self-contained (recommended for the kiosk machines)

```powershell
dotnet publish sourcecode\qrdiode\src\QrDiode.Sender -c Release -r win-x64 --self-contained true
```
- It bundles the .NET runtime, so **nothing needs installing** on the target. That matters on locked-down DMZ boxes.
- The output is about 150 MB across many files.

### Option C — Self-contained single file (one .exe)

```powershell
dotnet publish sourcecode\qrdiode\src\QrDiode.Sender -c Release -r win-x64 --self-contained true `
  -p:PublishSingleFile=true `
  -p:IncludeNativeLibrariesForSelfExtract=true
```
- You get one big `QrDiode.Sender.exe`, plus your `appsettings*.json` files.
- `IncludeNativeLibrariesForSelfExtract=true` puts the native DLLs inside the .exe as well: WPF's own, SQLite's
  `e_sqlite3.dll`, and the camera/QR libraries' (ZXing). Without it they are written next to the .exe, and copying
  only the .exe makes it crash at start-up on the target.
- **Test the single-file .exe on a clean machine.** This is the classic "works on my PC" trap (record Q2).

**Where's the output?**
```
sourcecode\qrdiode\src\QrDiode.Sender\bin\Release\net10.0-windows\win-x64\publish\
```
Copy that whole folder.

**Don't** use `PublishTrimmed`, because WPF does not support trimming.

### Put the settings in the csproj instead of typing them each time

```xml
<PropertyGroup Condition="'$(Configuration)' == 'Release'">
  <RuntimeIdentifier>win-x64</RuntimeIdentifier>
  <SelfContained>true</SelfContained>
  <PublishSingleFile>true</PublishSingleFile>
  <IncludeNativeLibrariesForSelfExtract>true</IncludeNativeLibrariesForSelfExtract>
</PropertyGroup>
```
After that you only need `dotnet publish sourcecode\qrdiode\src\QrDiode.Sender -c Release`.

(Visual Studio can also save these as a *Publish Profile* in `Properties\PublishProfiles\*.pubxml`.)

---

## 7. Run the published .exe on the kiosk machine

1. Copy the publish folder to, for example, `C:\Apps\QrDiode.Sender\`.
   A path under `C:\Program Files` is fine for the **app**, but the **data** goes in `C:\ProgramData\QrBridge\Data`.
2. Once the apps are connected to the Gateway-to-QrDiode system ([Integration Plan §2.4–2.5](../../../docs/gateway-to-qrdiode/integration-plan.md)), edit
   `appsettings.json` next to the .exe and set `GatewayDatabase:Side` (`Corp` or `Dmz`) and `GatewayDatabase:DataFolder`. Until then
   there is no settings file to edit: the apps keep their state in `%LocalAppData%\QrDiode\`.
3. Double-click the .exe, or run it from PowerShell:
   ```powershell
   & "C:\Apps\QrDiode.Sender\QrDiode.Sender.exe"
   ```
4. **Run it as the kiosk Windows user**, because QrDiode's keys are per-user (review finding 2.6).
5. **Auto-start at logon.** Create a Task Scheduler task "At log on of <kiosk user>" that runs the .exe.
   Do it once for the Sender and once for the Receiver, and also set the power plan to never sleep and turn the
   screensaver off (there is no script for this any more; known issue 9 in [handoff.md](../../../docs/handoff.md)).

If the window doesn't appear or closes immediately:
- Check the **Windows Event Viewer → Windows Logs → Application** log for a ".NET Runtime" error.
- The usual causes are a missing .NET Desktop Runtime (option A), a missing native DLL (option C without the flag),
  or no write permission on `C:\ProgramData\QrBridge\Data`.

---

## 8. Common beginner errors

| Symptom | Cause / fix |
|---|---|
| Binding shows nothing, no error | Typo in the property name, or `DataContext` not set. Check the VS/VS Code **Output → Debug** window for `System.Windows.Data Error`. |
| UI doesn't update when a value changes | The property doesn't raise `PropertyChanged`, or the list is a `List<T>` instead of `ObservableCollection<T>`. |
| Window freezes | `.Result` / `.Wait()` or a long loop on the UI thread. Use `await` / `Task.Run`. |
| "The calling thread cannot access this object…" | You touched UI from a background thread. Use `Dispatcher.BeginInvoke` / `InvokeAsync`. |
| `NETSDK1100` when building on non-Windows | WPF builds only on Windows. |
| Single-file exe crashes on another PC | You forgot `IncludeNativeLibrariesForSelfExtract=true`, or the target lacks the runtime (framework-dependent build). |
| `SQLite Error 14: unable to open database file` | The folder doesn't exist or the user lacks Modify permission. Create it and give that user Modify ([guide §12.4](../../../docs/gateway-to-qrdiode/technical-guide.md#124-deploy-per-side)). |
| `DllNotFoundException` for `ZXing`: "The filename or extension is too long" | The solution folder is too deep for the native DLL. Move it to a short path such as `C:\src\QrDiode_V2`. |
| `BG1002` (`.baml` not found) or `CS2001` (`.g.cs` not found) | A WPF incremental-build quirk right after a `dotnet publish -r win-x64`. Build again; if it persists, delete that project's `obj` folder. |

---

## 9. Where to look next in this repo

1. `sourcecode\qrdiode\src\QrDiode.Sender\App.xaml(.cs)` shows how the app starts.
2. `MainWindow.xaml` and `StageWindow.xaml` are the operator window and the full-screen QR "stage".
3. `Theme.xaml` holds the shared styles (a ResourceDictionary).
4. `Transmit\TransmitEngine.cs` and `Transmit\LiveSource.cs` are the send queue. The
   [Integration Plan §2.4](../../../docs/gateway-to-qrdiode/integration-plan.md) adds an `OutboxSource` beside `LiveSource` that reads the
   Outbox through EF Core.
5. In `sourcecode\qrdiode\src\QrDiode.Receiver\MainWindow.xaml.cs`, two methods matter most:
   - `OnQrPayload` hands work from the camera thread to the UI thread with `Dispatcher.BeginInvoke`;
   - `HandleCompletion` runs when a QR session completes, and §2.5 of the plan changes it.

**Ask Copilot.** In Copilot Chat, pick the **wpf-mentor** agent and ask about any of this. It explains WPF with
Angular analogies, using this repo's code as the examples.

Official docs: https://learn.microsoft.com/dotnet/desktop/wpf/
