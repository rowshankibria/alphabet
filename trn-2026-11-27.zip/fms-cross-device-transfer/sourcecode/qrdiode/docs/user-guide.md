# QrDiode — Step-by-Step User Guide

This guide walks you from a fresh checkout to a completed, verified OT → IT transfer.
Two paths are covered:

- **Part A — 5-minute demo on one machine** (recommended first run; full security active)
- **Part B — production setup on two machines** (the real key ceremony)
- **Part C — connected to the SOAP Gateway** (Gateway mode: the apps carry the gateway's messages)

Everything requires **Windows** and the **.NET 10 SDK**.

> **Since 26 Nov 2026 the apps speak QrDiode protocol v2** (a check on every QR frame, a counter run id, no plaintext
> hash on the screen). A Sender and a Receiver from before that date cannot talk to the new ones: update both together.

> Command note: `dotnet run` forwards trailing arguments to the tool directly — no `--`
> separator is needed (and Windows PowerShell 5.1 actually swallows `--`, so omit it).

---

## Part A · 5-Minute Demo (one machine, full security)

The demo uses one PC as both sides: the Sender plays the QR stream on your monitor and the
Receiver watches it through your webcam. **Nothing is weakened** — real ECDSA signatures,
real ECDH + AES-256-GCM encryption, and anti-replay all run exactly as in production. The
only demo concession is that both key pairs live on the same machine.

### Step 1 — Build

```powershell
cd d:\WORKSPACE\qr-code
dotnet build -c Release
```

### Step 2 — Launch both apps

```powershell
dotnet run --project sourcecode/qrdiode/src/QrDiode.Sender  -c Release     # window 1
dotnet run --project sourcecode/qrdiode/src/QrDiode.Receiver -c Release    # window 2
```

### Step 3 — One click on each side

1. In the **Sender**, click **⚡ Demo setup** (top-right).
   It provisions the `demo-ot` and `demo-it` key pairs in Windows CNG, cross-trusts their
   public bundles, opens the sender keys, and pre-selects `demo-it` as the destination.
2. In the **Receiver**, click **⚡ Demo setup**.
   It opens the `demo-it` keys. The security card should now show **1 trusted sender** (green).
3. Both apps display the same two key **fingerprints** — in a real deployment you would read
   these aloud between rooms; for the demo just eyeball that they match.

### Step 4 — Transfer something

1. **Receiver**: pick your webcam in *Camera*, leave **Strict mode** checked
   (15-minute replay window instead of 48 hours — the "stricter security" demo setting),
   press **● Start receiving**.
2. **Sender**: press **● Start source**. The live simulator begins emitting realistic JSON
   plant events (`order.created`, `sensor.telemetry`, `alarm.raised`, …) at irregular
   intervals, and the **QR stage** window opens with them. Each payload becomes its own
   session: *queued → encoding → ON AIR → sent*, visible in the queue table.
   *Impatient? Press **Inject one now** to emit immediately.*
3. Drag and size the QR stage so it suits the camera — it is a normal window, never
   fullscreen. Its size readout must read **✔ good for 30–50 cm**; if it says
   *move camera closer*, press **L** or drag the window bigger.
4. Point the webcam at the stage, 20–40 cm away, as square-on and steady as you can.
   The preview border and the pill in its corner turn **green ("LOCKED — decoding")** while
   codes are being read; the progress bar shows decoded blocks.
5. Each completed payload slides into the receiver's **inbox** (Live monitor tab) with a ✔
   badge, its verification chain, its **receipt hash** and the payload itself — each row
   carries a one-line preview, and the viewer below shows it **Formatted / Raw / Hex**. The
   sender keeps streaming the next one — you do not have to touch anything between payloads.
6. Compare the receipt on an inbox entry with the one on the sender's stage and queue row —
   **the two hashes matching is your end-to-end proof.**
7. Open the receiver's **Archive** tab: every arrival ever judged is listed there, read back
   from the local store and the journal — searchable, filterable by date and outcome, with the
   payload viewer, a per-type breakdown, and **Verify bytes on disk** to re-hash a stored file
   against the hash recorded when it was verified on arrival.

Both apps show the payload, not just its name: select any row in the sender's queue to read
the exact bytes about to be encrypted (**Formatted / Raw / Hex**, with *Save a copy…*). The
sender is the last place a human can see plaintext — after that it is ciphertext on a screen.

Manual mode is still there: switch *Source* to **Manual file**, *Browse…* to any
XML/JSON/file up to 64 MB, and press **Inject one now**. It joins the same queue and obeys
the same air-time policy, so the receiver cannot tell the two modes apart.

The received file is in the receiver's **local store** — by default
`%LocalAppData%\QrDiode\quarantine\<yyyy-MM-dd>\<session>_<name>`, with a `.meta.json`
sidecar beside it — journaled in the bridge database (`JournalTransfer`, `JournalArchive`; see "Archiving the
Receiver's journal"), with hash-chained audit
logs in `%LocalAppData%\QrDiode\audit\`. Point the store anywhere you like with **Change…**
on the Archive tab.

### Step 5 — See the security actually working (optional but fun)

- **Replay attack**: send the same file again → the sender reserves a *new* counter and
  session, so it works. But feed the Receiver a *screen recording* of an earlier transmission
  → nothing is written. If the recording shows a session this receiver already stored, the
  row reads **◎ duplicate** with the reason *Already received and stored earlier* (the same
  happens, harmlessly, when you stop and start the Receiver while the Sender is still showing
  the last session; the audit log records `receive.already_received`). A recording of a session
  it never received, older than one it did, is rejected with `Replay check failed: StaleCounter`.
- **Missed session**: block the camera halfway through a session and uncover it when the next
  one is on air → the next one is received, and the half-seen one gets a **⚠ incomplete · must
  be re-sent** row. Nothing was written for it.
- **Fake QR codes**: hold another QR code in front of the camera while a session is on air →
  the session still completes; the fake frames fail the per-frame check and are ignored.
- **Duplicate content**: send the same file twice normally → the second run completes but the
  inbox entry shows **◎ duplicate** and nothing is written twice (idempotency). Its
  verification chain shows every step green up to *Stored to the local store*, which reads
  *already stored — nothing written*.
- **Unknown sender**: run `demo-clean` then `demo` again in the KeyCeremony tool on the
  sender side only — the receiver now rejects with `Unknown sender key` until it re-trusts.
- **Tamper check**: `dotnet run --project sourcecode/qrdiode/src/QrDiode.KeyCeremony list` shows the trust
  store; edit any byte of a stored payload, then press **Verify bytes on disk** on that row in
  the **Archive** tab — it reads *✖ file no longer matches the verified hash* and prints what the
  bytes hash to now.

### Cleaning up demo keys

```powershell
dotnet run --project sourcecode/qrdiode/src/QrDiode.KeyCeremony demo-clean
```

Run this before provisioning a machine for production use, then turn on production mode (Part B, Step 0).

---

## Part B · Production Setup (two machines)

### Overview

```
   OT machine (sender)                       IT machine (receiver)
   -------------------                       ---------------------
1. init ot-line-1                         1. init it-recv-1
2. export ot-line-1  -> ot.json  --+   +--  2. export it-recv-1 -> it.json
                                  |USB|
3. import it.json    <------------+   +-->  3. import ot.json
4. COMPARE FINGERPRINTS BY VOICE  <------>  (both sides read the same value aloud)
```

### Step 0 — Turn on production mode on each machine

Next to each exe (`QrDiode.Sender.exe`, `QrDiode.Receiver.exe`, `QrDiode.KeyCeremony.exe`) is an
`appsettings.json`. On the real machines set:

```json
{ "QrDiode": { "Production": true } }
```

| With `"Production": true` | Why |
|---|---|
| **⚡ Demo setup** is hidden in both apps, and `KeyCeremony demo` is refused | One click would make the machine trust a key that sits on the machine itself |
| The demo keys (`demo-ot`, `demo-it`) and demo trust bundles are refused | Same reason |
| Keys must be in the TPM: `init` refuses to fall back to software keys, and existing software keys are refused | Software keys are easier to steal |

On a developer machine leave it `false` (the default): everything works as in Part A. A misspelt or unreadable
setting does not quietly fall back to development mode: the app says so and runs under the strictest rules.
Restart the apps after changing it. Run the apps and the KeyCeremony tool **as the kiosk user**: keys, trust
store and counter are per Windows user.

### Step 1 — Provision keys on each machine

On the **OT machine**:

```powershell
dotnet run --project sourcecode/qrdiode/src/QrDiode.KeyCeremony init ot-line-1
dotnet run --project sourcecode/qrdiode/src/QrDiode.KeyCeremony export ot-line-1 E:\ot-line-1.json
```

On the **IT machine**:

```powershell
dotnet run --project sourcecode/qrdiode/src/QrDiode.KeyCeremony init it-recv-1
dotnet run --project sourcecode/qrdiode/src/QrDiode.KeyCeremony export it-recv-1 E:\it-recv-1.json
```

Notes:
- Keys are created **non-exportable** in Windows CNG. If a TPM is present the tool uses the
  Platform Crypto Provider automatically (`init` prints which storage was used); with
  `"Production": true` it uses the TPM or refuses.
- Only **public** bundles are exported. Private keys never leave the machine, ever.

### Step 2 — Exchange bundles on removable media

Carry `ot-line-1.json` to the IT machine and `it-recv-1.json` to the OT machine
(USB stick, or any approved one-way media process).

```powershell
# On IT:
dotnet run --project sourcecode/qrdiode/src/QrDiode.KeyCeremony import E:\ot-line-1.json
# On OT:
dotnet run --project sourcecode/qrdiode/src/QrDiode.KeyCeremony import E:\it-recv-1.json
```

### Step 3 — Verify fingerprints (do not skip)

Each `import` prints a fingerprint like `3F2A-91CC-07B1-…`. The **exporting** operator runs
`fingerprint <bundle.json>` on their original file, and both operators compare the values
by phone or in person. **If they differ, someone tampered with the bundle in transit —
delete it immediately.** This step is what defeats a swapped-USB-stick attack.

### Step 4 — Daily operation

**Sender (OT):**
1. Launch `QrDiode.Sender` → *Step 1*: endpoint name `ot-line-1` → **Open / create keys**.
2. *Step 2*: pick the IT receiver from the destination list.
3. *Step 3*: choose the source.
   - **Live simulator** — emits JSON plant events on an irregular schedule. Set the interval
     range and burstiness, and enable only the payload types you want. `.json` and `.xml`
     are content-validated on arrival; anything else travels as opaque verified bytes.
   - **Manual file** — browse to one payload (64 MB max) and **Inject one now**.
4. *Step 4*: **Open QR stage**, then size and place the window for the camera.
   - `Esc` closes · `↑`/`↓` changes fps live (start at 15) · `+`/`−` cycles the size presets ·
     `Ctrl+T` keeps it on top · `Ctrl+K` skips the payload on air · `Ctrl+C` copies the receipt.
   - The stage shows what is on air, the QR version, loop count, **receipt hash** and a
     size readout in px/module. The queue table on the dashboard shows what is next and
     what is done, with the **air time** each payload actually got.

Because there is no acknowledgement, a session ends on an **air-time policy**, not on
success: *loop 3× K frames **or** ≥ 6 s, whichever is longer*, then a 1.5 s gap so the
receiver can finalize. Exposure is the only guarantee the sender has.

**Receiver (IT):**
1. Launch `QrDiode.Receiver` → *Step 1*: endpoint `it-recv-1` → **Open keys**.
2. *Step 2*: select the camera (the list pre-picks each camera's fastest mode).
3. *Step 3*: leave **Strict mode** on if OT and IT clocks are reasonably synchronized;
   turn it off only if clock drift between the environments can exceed minutes.
4. *Step 4*: **● Start receiving**, aim the camera at the OT screen.
   - Green border + **LOCKED** pill = codes are decoding; keep the camera steady.
   - Progress shows `blocks decoded / K`. Late joining and dropped frames are harmless —
     the carousel keeps looping until you have everything.
5. On completion the payload lands in the **inbox** (newest first) with its outcome badge,
   full verification chain, receipt and the payload itself. Back-to-back sessions need no
   intervention — the ribbon under the preview reads *session complete → waiting for the
   next manifest*. A session the camera only partly saw before the sender moved on gets a
   **⚠ incomplete · must be re-sent** row: nothing was written for it. If the local store
   cannot be written, the row says so and the session stays receivable while the sender
   still shows it (it is not marked as received until the bytes are on disk).
6. **Compare the receipt hash with the sender's screen** (this is the operator-level
   end-to-end check), then collect the file from the local store — or use
   **Show in folder** on the selected entry.

### The Archive tab (IT)

Everything the receiver has judged is indexed on disk, so it survives closing the app:

| Control | What it does |
|---|---|
| **LOCAL STORE** + *Change…* | Where verified payloads are written. Any local or mapped folder; the receiver proves it is writable before a run starts and refuses to start if it is not. |
| **Date folders** / **Metadata sidecars** | Layout of the store: `<yyyy-MM-dd>\<session>_<name>`, and a `.meta.json` per payload carrying session, counter, key ids, both hashes and the receipt. |
| Search · date range · outcome | Query the index — filename, type, session, receipt, sender key, payload text or rejection reason. Rejections are indexed too: "nothing was written" is evidence. |
| **Verify bytes on disk** | Re-hashes the stored file and compares with the SHA-256 recorded when it arrived (the plaintext the signed manifest had just proven). The one check still available months later, with no back-channel. |
| **Copy** / **Export…** / **Show in folder** | Take a copy out of the store; the store's own copy is never moved or altered. |
| **BY PAYLOAD TYPE** | Count and stored volume per event type in the current filter. |

Payloads received before this index existed are on disk but not listed — the empty state says
so. Everything received from then on is indexed.

### Camera tips (this is the whole bottleneck)

| Symptom | Fix |
|---|---|
| Pill stays "SEARCHING" | Move closer (QR should fill ~½ the frame height), square up the angle; check the stage's px/module readout is green |
| Hits/s very low | Kill reflections/glare on the monitor; increase monitor brightness; lower sender fps with `↓` |
| Progress stalls near 100% | Normal for a few seconds — the last blocks arrive via coded symbols; just wait |
| Blurry preview | Lock focus if your camera app allows it; avoid autofocus hunting |

### Key rotation & revocation

1. Provision a new endpoint (`init ot-line-2`), export/import/verify as above.
2. Both old and new sender keys can be trusted simultaneously during the overlap window.
3. Revoke by deleting the old bundle from `%LocalAppData%\QrDiode\trust\` on the receiver
   and `delete ot-line-1 --yes` on the sender (without `--yes` the tool only explains what
   would be lost).

### If the sender's counter file is lost

`%LocalAppData%\QrDiode\sender-counter.bin` holds the send counter and its **run id**. If it is
lost or unreadable (a rebuilt profile, another Windows user), the Sender starts a **new run** at 1
by itself and writes `counter.new_run` to its audit log; the Receiver accepts the new run and
writes `receive.new_counter_run`. Recordings of the old run stay refused. Nothing to do.

### Checking the audit logs

```powershell
dotnet run --project sourcecode/qrdiode/src/QrDiode.KeyCeremony verify-audit
```

Checks the Sender's and the Receiver's hash chains on this machine, including the older files:
a log rolls over to `name.yyyyMMdd-HHmmssfff.jsonl` at 32 MB and the chain continues in the new
file. It prints *intact* or the first record that was changed, removed or torn. The chain shows
edits; it cannot stop someone who rewrites a whole log, so keep the folder's permissions tight.

### Where everything lives

| Path | Contents |
|---|---|
| `%LocalAppData%\QrDiode\trust\` | Imported public-key bundles (the trust store) |
| `%LocalAppData%\QrDiode\quarantine\` | Default local store: received, fully verified files (`<yyyy-MM-dd>\<session>_<name>` + `.meta.json`). Relocatable from the Archive tab |
| The bridge database (`Bridge` settings: `qrbridge.db` in `C:\ProgramData\QrBridge\Data`, or SQL Server) | Since 27 Nov 2026 also the Receiver's transfer journal, anti-replay watermarks and archive index (tables `Journal…`) |
| `%LocalAppData%\QrDiode\journal.db.imported-…` | The Receiver's former journal, copied into the bridge database once and kept for audit |
| `%LocalAppData%\QrDiode\receiver-settings.json` | Store location and layout (nothing security-relevant) |
| `%LocalAppData%\QrDiode\audit\*.jsonl` | Hash-chained audit logs, rolled over at 32 MB (check with `KeyCeremony verify-audit`) |
| `%LocalAppData%\QrDiode\sender-counter.bin` | DPAPI-protected monotonic send counter and its run id |
| `appsettings.json` next to each exe | Deployment rules: `"Production"`, and on the Receiver `"AllowOpaqueFiles"` |
| `C:\ProgramData\QrDiode\keyexchange.json` | Machine-wide, all three programs: `"KeyExchange"` (key ceremony or certificate) and the `"Certificate"` section. No file = key ceremony. Administrators only may change it ([Part D](#part-d--certificate-mode-instead-of-the-key-ceremony)) |
| `%LocalAppData%\QrDiode\trust\x509-*.json` | Certificate mode: the peer paired over the cameras (with its CertHello, verified again on every load) |
| Windows CNG | Private keys (non-exportable, TPM when available; TPM only in production) |

---

## Part C · Connected to the SOAP Gateway (Gateway mode)

On each islanding machine the SOAP Gateway (IIS) keeps its messages in one database, `qrbridge.db`: an **Outbox**
(what this side must send) and an **Inbox** (what arrived from the other side). In Gateway mode the QrDiode apps are
the delivery van between the two machines' databases:

- the **Sender** takes waiting messages from this machine's Outbox, packs up to 50 of them (at most 128 KB) into one
  **bundle**, airs it as one QR session and marks them *Aired*;
- the **Receiver** stores each arriving bundle in this machine's Inbox in one go and wakes the gateway, which delivers
  the messages and sends back a Receipt (and later the Reply) the same way.

The gateway decides the order (receipts and replies first, then permits and orders, then queries, then feeds), sends
again what the far side never confirmed, and shows every message's status on its read-only pages (`/qrbridge-ui`).

### Settings (next to each exe)

```json
{
  "QrDiode": { "Production": true, "Mode": "Gateway" },
  "QRDatabase": { "Side": "Corp", "DataFolder": "C:\\ProgramData\\QrBridge\\Data", "MaxPayloadBytes": 1000000, "Provider": "Sqlite", "ConnectionString": "" },
  "Sender":  { "AutoStart": true, "Endpoint": "ot-line-1", "Receiver": "it-recv-1" }
}
```

- `"QRDatabase"` must be **the same as the gateway's own `GatewayDatabase` section on that machine** (same side, same folder, same database). The
  Windows user the apps run as needs Modify rights on the data folder.
- The Receiver's file has `"Receiver": { "AutoStart": true, "Endpoint": "...", "Camera": "part of its name", "StrictMode": true }`.
- `"Mode": "Standalone"` (the default) is Parts A and B: simulator payloads and files, no gateway.
- Restart the app after a change. A setting it cannot read is reported and the app runs under the strictest rules.

### What you see

- **Sender:** the Source card shows *Bridge* with the database it airs and counts (bundles queued, aired, put back).
  The simulator and the file picker are hidden. Every queue row is a `gateway bundle` named `bundle-{first}-{last}.qbb`.
  Esc on the stage asks before stopping a bundle on air (it would only be sent again later).
- **Receiver:** each bundle is one inbox row, e.g. *bundle 1042–1061 · 20 messages (2 already there)*. The messages
  themselves are **not** shown or kept by the Receiver (no file, no preview): read them on the gateway's pages.
  Anything that is not a gateway bundle is refused with "accepts only gateway bundles".
- The gateway's `/health` shows the `SenderLoop` and `ReceiverLoop` heartbeats every 30 s while the apps run.

### When things go wrong

| You see | It means | What happens next |
|---|---|---|
| "Gateway mode: the gateway's database … cannot be opened" | Wrong `Bridge` settings, no rights on the folder, or a database the gateway refuses | Nothing is aired or received until it is fixed; restart the app |
| A bundle row "put back in the queue" (Sender) | The stage was closed or the session skipped before it finished | Its messages go out again in the next bundle |
| *⚠ incomplete* (Receiver) | The camera missed part of a bundle | No Receipt goes back, so the gateway airs those messages again after about 2–3 minutes |
| *✖ materialization failed* (Receiver) | The Inbox could not be written | Nothing is marked received; it is stored when it is shown again |
| "(n already there)" | A bundle aired again because a Receipt was lost | The messages already stored are skipped and get a new Receipt |

### Archiving the Receiver's journal

Since 27 Nov 2026 the Receiver's journal is **in the bridge database** it shares with the gateway and the Sender on this
machine (`qrbridge.db` in `GatewayDatabase:DataFolder`, or the SQL Server database in `GatewayDatabase`): the tables
`JournalTransfer`, `JournalWatermark` and `JournalArchive`. It remembers every session the Receiver judged (for
anti-replay and the Archive tab). On its first start with this version the Receiver copies a former
`%LocalAppData%\QrDiode\journal.db` in once and renames it `journal.db.imported-…` (kept for audit); a file that is not a
journal it made stops the start and is left as it was. The Receiver now needs its `"QRDatabase"` settings in both modes; if
the database cannot be opened it says why and closes.

Nothing in the journal is deleted automatically; it grows by well under 1 KB per session — at the maximum rate (about 8
sessions a minute, day and night) roughly 8 MB a day. Back it up with the bridge database (technical guide §12.4). To
make it smaller, an operator may delete old `JournalArchive` rows (the Archive tab then no longer lists them) and old
`JournalTransfer` rows. **Never delete or edit `JournalWatermark` rows.**

Fewer `JournalTransfer` rows also means the Receiver forgets which sessions it saw. For the next 48 hours (15 minutes in
Strict mode) a recording of such an older session could be accepted once more if its counter is above the watermark:
in Standalone mode that stores a second copy of a file; in Gateway mode the gateway's Inbox skips every message it
already has, so nothing is delivered twice. Received files in the local store (`quarantine\`) can be moved to an
archive at any time; the Archive tab then says the file is gone.

---

## Part D · Certificate mode (instead of the key ceremony)

*Built 27 Nov 2026, not yet tried on real screens and cameras.* Design and checks:
[x509-certificate-handshake-plan.md](x509-certificate-handshake-plan.md).

Instead of carrying JSON bundles on a USB stick (Part B), each machine uses **its own company certificate** from the
Windows Certificate Store, and the two sides **pair over the cameras**: whenever a Sender has nothing to send, its stage
shows a **CertHello** QR code (pill "PAIRING": this machine's certificate and encryption key, public keys only). The
other side's Receiver checks it and pins it. Only the one expected peer, with a certificate from your company CA, is
ever accepted — another company machine with a valid certificate is refused.

The mechanism is chosen **once per machine** in `C:\ProgramData\QrDiode\keyexchange.json`, which the Sender, the
Receiver and the KeyCeremony tool all read (so they can never disagree). **No file, or `"KeyExchange": "KeyCeremony"`,
keeps Parts A–C exactly as before**; `"KeyExchange": "Certificate"` turns on this part. Restart the apps after
changing it.

### Set-up on each machine (once)

1. Your PKI team issues the machine an **ECDSA P-256** certificate allowed to sign (key usage Digital Signature),
   e.g. `CN=qrbridge-corp.example.com`, with a non-exportable private key (in the TPM on a kiosk).
2. Install it in **Personal** (`certlm.msc` → Personal → Certificates, = `Cert:\LocalMachine\My`). Then right-click it →
   **All Tasks → Manage Private Keys…** → give the kiosk user **Read**.
3. The company **Root CA** must be in *Trusted Root Certification Authorities* (and any **Issuing CA** in *Intermediate
   Certification Authorities*). On domain-joined machines Group Policy usually puts them there already.
4. As an **administrator**, create `C:\ProgramData\QrDiode\keyexchange.json`:

```json
{
  "KeyExchange": "Certificate",
  "Certificate": {
    "Location": "Cert:\\LocalMachine\\My",
    "OwnSubject": "qrbridge-corp.example.com",
    "TrustedCaThumbprint": "9F8E7D…",              // SHA-1 thumbprint of the Root or Issuing CA
    "ExpectedPeerSubject": "qrbridge-dmz.example.com"
  }
}
```

   The DMZ machine has the names the other way round. Optional: `"OwnThumbprint"` instead of `"OwnSubject"`,
   `"ExpectedPeerThumbprint"` to accept one exact peer certificate only, `"RequireHandshakeOnStart": true` to make the
   Receiver forget the peer at every Start. With `"OwnSubject"`, the newest certificate of that name that passes the
   other side's checks is used, so an auto-enrolled RSA certificate with the same name is skipped.
5. **Lock the folder.** Unlike `Program Files`, `C:\ProgramData` lets ordinary users create and change files, and
   whoever can edit this file decides which peer and which CA the machine trusts. As an administrator:

```powershell
icacls C:\ProgramData\QrDiode /setowner Administrators
icacls C:\ProgramData\QrDiode /inheritance:r /grant:r "Administrators:(OI)(CI)F" "SYSTEM:(OI)(CI)F" "Users:(OI)(CI)RX"
```

   (The owner of a folder can always change its permissions back, so it must not stay owned by a kiosk user.)
   With `"Production": true` the apps **refuse to start** while the kiosk user can still change the file or create files
   in its folder, and say so. Tried on one PC (27 Nov 2026): refused before the second command, accepted after it.
6. Check it: `QrDiode.KeyCeremony check-cert` opens the certificate and runs on it the checks the other side will run
   (run the tool without arguments: its first line names the file and the mechanism in use).

Settings that don't add up are refused — the apps open no keys and say why, naming the file; they never fall back to
another mechanism on their own: `"KeyExchange": "Certificate"` with a half-filled `"Certificate"` section (e.g. no
`ExpectedPeerSubject`), a filled-in `"Certificate"` section while `"KeyExchange"` is `"KeyCeremony"`, or a misspelt
setting.

In certificate mode the KeyCeremony tool offers `check-cert`, `export-hello` and `import-hello` instead of
`init` / `export` / `import` / `demo` (run it without arguments to see the list for this machine).

### Pairing

1. Start both apps on both machines (**Open keys** in the Sender, **Start** in the Receiver; or `AutoStart`). The
   endpoint name box and **⚡ Demo setup** are not used.
2. Open the Sender's stage: it shows the CertHello (pill "PAIRING"). The Receiver's trust pill says *waiting to pair with …*.
3. When this machine's camera reads the other side's CertHello, the Receiver pins it (ribbon: *paired with …*, audit
   `pairing.peer_verified`), and this machine's Sender picks the peer up within 2 seconds. Transfers start.

What is refused, and shows as a rejected row with the reason: a certificate from another CA, another machine's name,
an expired certificate, a tampered key, a CertHello older than the clock window (15 minutes in Strict mode). A
CertHello seen during a transfer is ignored, so pairing never breaks a session.

**Renewal:** a renewed certificate pairs on its own — its CertHello is newer, so it replaces the pin. An *older*
CertHello never replaces a pin (a recording held up to the camera). If a machine's clock was wrong when it paired, delete
`%LocalAppData%\QrDiode\trust\x509-*.json` on the other side (or set `RequireHandshakeOnStart`) and let them pair again.

**Bench test with one camera:** `KeyCeremony export-hello hello.bin` on one machine, carry it, `import-hello hello.bin`
on the other (the same checks as the camera, without the clock window).

---

## Security cheat-sheet

What is **always on** (cannot be disabled anywhere in the UI):

| Layer | Mechanism |
|---|---|
| Authenticity | ECDSA P-256 signature (low-S only) verified **before any payload byte is parsed**; a MAC on **every data frame**, so a QR code from anyone else never reaches the decoder |
| Confidentiality | AES-256-GCM, per-session keys via static-static ECDH P-256 + HKDF-SHA256 (one for the payload, one for the frame MAC) |
| Anti-replay | Session GUID dedupe + monotonic counter per sender key and counter run + timestamp window; saved only once the payload is stored |
| Integrity | CRC-32 per frame → frame MAC → ciphertext SHA-256 (signed) → GCM tag → exact decompressed size |
| Hostile input | XXE-prohibited XML, depth-capped JSON, decompression size cap, sanitized filenames, 64 MB / 65,536-symbol / 256-byte-symbol limits, capped decoder memory |
| Traceability | Hash-chained audit logs both ends + matching receipt hashes |

What **Strict mode** adds: replay acceptance window shrinks 48 h → 15 min.

What the **demo** changes: nothing in the security stack — it only co-locates both key pairs
on one machine so you can evaluate without two PCs. Run `demo-clean` before going to production,
and set `"Production": true` (Part B, Step 0) so the demo cannot come back.
