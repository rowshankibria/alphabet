# X.509 Certificate Store & Optical Public-Key Handshake Plan

**Status: Built 27 Nov 2026** (decisions 58 and 59 in [handoff.md](../../../docs/handoff.md)). Proven in tests and on one PC
against the real Windows Certificate Store (CurrentUser); **not tried** on real screens and cameras, with TPM-backed
certificates, or with company (ADCS) certificates. What was built differs from this plan in a few places: see
[§9 As built](#9-as-built-27-nov-2026). **The mechanism is now chosen explicitly** by `"KeyExchange"` in `C:\ProgramData\QrDiode\keyexchange.json` behind
an `IKeyExchange` abstraction, not by an empty or filled `Certificate:Location` as §1–2 below describe: see
[§10](#10-key-exchange-abstraction-27-nov-2026).  
Applies to: `QrDiode.Core`, `QrDiode.Sender`, `QrDiode.Receiver`, `QrDiode.KeyCeremony` (related to [qrdiode-pending-work.md](./qrdiode-pending-work.md) item P-6).

---

## 1. Goal

Support Windows Certificate Store (`X509Certificate2`) trust and an automatic optical public-key handshake across the **QrDiode optical link**, while keeping a **zero-breaking-change fallback** to the existing CNG + `KeyCeremony` workflow whenever certificate settings are left empty:

1. **When `Certificate:Location` is empty (`""`) or the `"Certificate"` section is omitted:**
   - Everything falls back to **the exact way QrDiode works today** (`CngEndpointKeys` + `%LocalAppData%\QrDiode\trust\*.json` + `KeyCeremony` / developer `Demo setup`).
2. **When `Certificate:Location` is configured (for example `"Cert:\\LocalMachine\\My"` or `"Cert:\\CurrentUser\\My"`):**
   - Each machine (Corp and DMZ) loads its own CA-issued `X509Certificate2` (with non-exportable private key) and the pinned **Con Edison Root/Issuing CA** from the Windows Certificate Store.
   - Before airing any Outbox data, **Sender and Receiver exchange and verify each other's public keys over the cameras first** (`CertHello` QR frame).
   - Once verified, **both machines pin that exact peer public key**: neither Sender nor Receiver accepts frames, manifests, or handshakes from any other PC (even another machine signed by the same corporate CA).

---

## 2. Configuration & Fallback Rules (`appsettings.json`)

Each QrDiode app ([Sender appsettings.json](../src/QrDiode.Sender/appsettings.json), [Receiver appsettings.json](../src/QrDiode.Receiver/appsettings.json), [KeyCeremony appsettings.json](../src/QrDiode.KeyCeremony/appsettings.json)) gets an optional `"Certificate"` section read via [AppSettings.ReadSection](../src/QrDiode.Core/Configurations/Helpers/Utility.cs):

```json
{
  "QrDiode": {
    "Production": false,
    "Mode": "Standalone"
  },
  // Optional X.509 certificate mode.
  // Leave "Location": "" (empty) to fall back to the existing CNG + KeyCeremony / Demo workflow.
  "Certificate": {
    // Windows Certificate Store path: "Cert:\\LocalMachine\\My" or "Cert:\\CurrentUser\\My" (or "" for fallback).
    "Location": "",
    // Match this machine's own X509Certificate2 by Subject/SAN or SHA-1/SHA-256 Thumbprint:
    "OwnSubject": "",
    "OwnThumbprint": "",
    // Thumbprint of the pinned Con Edison Root or Issuing CA in Windows Root/CA store:
    "TrustedCaThumbprint": "",
    // Exact peer identity this lane is allowed to pair with (blocks all other company PCs):
    "ExpectedPeerSubject": "",
    "ExpectedPeerThumbprint": "",
    // true = always run a fresh optical CertHello exchange on every app start; false = reuse pinned peer after first handshake.
    "RequireHandshakeOnStart": false
  }
}
```

### Fallback Decision Table

| `"Certificate"` settings in `appsettings.json` | Active Mode | Startup Behaviour |
|---|---|---|
| Section omitted **or** `"Location": ""` (with all other `Certificate` fields empty) | **Fallback Mode (current behaviour)** | Opens keys via [CngEndpointKeys.cs](../src/QrDiode.Core/Crypto/Keys/CngEndpointKeys.cs) and loads JSON bundles from `%LocalAppData%\QrDiode\trust\` ([DirectoryTrustStore.cs](../src/QrDiode.Core/Crypto/Trust/DirectoryTrustStore.cs)). `KeyCeremony init/export/import` and `Demo setup` work unchanged. `ReceiveEngine` ignores `CertHello` frames. |
| `"Location"` set (e.g. `"Cert:\\LocalMachine\\My"`) + valid `OwnSubject`/`OwnThumbprint`, `TrustedCaThumbprint`, and `ExpectedPeerSubject` | **X.509 Certificate Handshake Mode** | Opens this PC's `X509Certificate2` from the configured Windows store + local TPM ECDH key. Runs the optical `CertHello` exchange at camera startup if the peer key is not yet pinned, then locks strictly to that peer. |
| Partially filled or broken config (e.g. `"Location"` is set, but the cert is missing in Windows Store or `ExpectedPeerSubject` is blank; **or** `"Location"` is `""` while other `Certificate` fields are non-empty) | **Refused at Startup (fail-closed)** | Throws `InvalidDataException` / `InvalidOperationException` with a plain-English message telling the operator what is missing. Never silently downgrades a misconfigured kiosk to unverified keys. |

---

## 3. Important Windows TPM / CNG Key Constraint

QrDiode requires **two** P-256 keys per endpoint ([IEndpointKeys.cs](../src/QrDiode.Core/Crypto/Keys/IEndpointKeys.cs)):
- **ECDSA P-256 (`SigningKey`)** — signs `TransferManifest`.
- **ECDH P-256 (`AgreementKey`)** — derives per-session AES-256-GCM and per-frame HMAC keys ([Envelope.cs](../src/QrDiode.Core/Crypto/Encryption/Envelope.cs)).

In Windows TPM 2.0 (`Microsoft Platform Crypto Provider`), **an `ECDSA_P256` certificate key cannot be opened as `ECDiffieHellman`**, and standard corporate PKI (ADCS) servers typically issue ECDSA signing/TLS templates rather than static ECDH templates.

### Recommended Hybrid Key Model (`X509EndpointKeys`)
- **Identity & Signing Key (`SigningKey`):** Loaded from `X509Certificate2` in the configured `Certificate:Location` (`cert.GetECDsaPrivateKey()`), non-exportable (and TPM-backed when `"Production": true`).
- **Encryption Agreement Key (`AgreementKey`):** Auto-created locally once in Windows TPM CNG (`CngKey` `ECDiffieHellmanP256`, `QrDiode.x509.<thumbprint8>.kex`, non-exportable).
- **Cryptographic Binding:** In the `CertHello` QR frame, the machine's `X509Certificate2` ECDSA private key signs `(CertRawDer ‖ AgreementPublicKeySpki ‖ TimestampUnixMs)`. That proves both keys belong to the exact CA-certified kiosk while requiring only **one** standard corporate certificate per machine.

---

## 4. End-to-End Startup & Optical Handshake Flow

In **Gateway-to-QrDiode**, each side runs both `QrDiode.Sender` (screen) and `QrDiode.Receiver` (camera) on the **same Windows machine** (see [architecture.md](../../../docs/gateway-to-qrdiode/architecture.md)). When `Certificate:Location` is configured, both lanes pair automatically before transferring data:

```text
CORP MACHINE                                            DMZ MACHINE
(OwnSubject:          qrbridge-corp.coned.com)          (OwnSubject:          qrbridge-dmz.coned.com)
(ExpectedPeerSubject: qrbridge-dmz.coned.com)           (ExpectedPeerSubject: qrbridge-corp.coned.com)
──────────────────────────────────────────────          ─────────────────────────────────────────────
1. Sender starts: DMZ key not pinned yet                1. Sender starts: Corp key not pinned yet
   └─ Stage enters Pairing state                           └─ Stage enters Pairing state
   └─ Displays CertHello QR (Corp .cer + ECDH pubkey)      └─ Displays CertHello QR (DMZ .cer + ECDH pubkey)

              ═══════►  DMZ Camera scans Corp CertHello QR  ═══════►
              ◄═══════  Corp Camera scans DMZ CertHello QR  ◄═══════

2. Receiver verifies DMZ CertHello:                     2. Receiver verifies Corp CertHello:
   ✔ Frame CRC-32 valid                                    ✔ Frame CRC-32 valid
   ✔ Offline X509Chain chains to TrustedCaThumbprint       ✔ Offline X509Chain chains to TrustedCaThumbprint
   ✔ Subject/SAN matches "qrbridge-dmz.coned.com"          ✔ Subject/SAN matches "qrbridge-corp.coned.com"
   ✔ Cert ECDSA signature over ECDH key valid              ✔ Cert ECDSA signature over ECDH key valid
   └─ Writes verified DMZ bundle to local trust dir        └─ Writes verified Corp bundle to local trust dir
   └─ Signals local event "Local\QrDiode.TrustUpdated"     └─ Signals local event "Local\QrDiode.TrustUpdated"

3. Sender wakes on "Local\QrDiode.TrustUpdated":        3. Sender wakes on "Local\QrDiode.TrustUpdated":
   └─ Loads verified DMZ PeerPublicKeys                    └─ Loads verified Corp PeerPublicKeys
   └─ Exits Pairing state → opens normal QR stage          └─ Exits Pairing state → opens normal QR stage
   └─ Begins encrypted Outbox QR carousel                  └─ Begins encrypted Outbox QR carousel
```

*(Analogous to Angular: think of `Pairing` state like an `AuthGuard` + `BehaviorSubject` that holds the outbound route on a "Waiting for peer handshake" view until the local Receiver resolves the peer certificate, then automatically activates the main stream.)*

### One-Way Bench Fallback (Single Camera / Single Screen Test)
If testing a single one-way lane where the Sender test PC has no camera looking back at the Receiver PC, run:
`QrDiode.KeyCeremony export-hello <out.bin>` on the Receiver PC → copy once → `QrDiode.KeyCeremony import-hello <in.bin>` on the Sender PC. It runs the exact same `CertHelloValidator` CA and subject checks.

---

## 5. Wire Protocol Addition (`ProtocolVersion = 0x03`)

Per QrDiode protocol rules, adding a frame type bumps `FrameFormat.ProtocolVersion` from `0x02` to `0x03` in [FrameFormat.cs](../src/QrDiode.Core/Framing/FrameFormat.cs) (update Sender and Receiver together):

- Add `FrameFormat.TypeCertHello = 0x03` (`FrameType.CertHello`).
- **`CertHello` binary layout (~850–1,100 bytes — fits in one single QR code at ECC L, Version 24–27):**

| Field | Size | Purpose |
|---|---|---|
| `Header` | 12 bytes | `Magic('O','D')` + `Version(0x03)` + `Type(0x03)` + `SessionTag(first 8 bytes of cert SHA-256)` |
| `TimestampUnixMs` | 8 bytes (`long`) | Rejects stale recorded `CertHello` QR codes outside the anti-replay clock window |
| `CertDerLength` | 2 bytes (`ushort`) | Length of `X509Certificate2.RawData` (hard cap: 2,048 bytes) |
| `CertDer` | `CertDerLength` | Public DER bytes of the sender's `X509Certificate2` (never the private key) |
| `AgreementSpkiLength` | 2 bytes (`ushort`) | Length of ECDH P-256 SubjectPublicKeyInfo (91 bytes) |
| `AgreementSpki` | `AgreementSpkiLength` | Sender's TPM ECDH P-256 public key |
| `Signature` | 64 bytes | Low-S ECDSA P-256 signature (`r ‖ s`) over `"QrDiode.v3.CertHello" ‖ Header ‖ Timestamp ‖ CertDer ‖ AgreementSpki` |
| `Crc32` | 4 bytes | Standard frame trailer CRC |

---

## 6. How Packets From Any Other PC Are Blocked

Even if a third PC (or phone screen) holds up a QR code in view of the camera, it is blocked at **four** independent layers:

1. **Pinned Corporate Root/Issuing CA (`CustomRootTrust`):**
   - `X509Chain` validates offline (`RevocationMode = X509RevocationMode.NoCheck` so air-gapped islanding never tries to reach online CRL/OCSP URLs) with `TrustMode = X509ChainTrustMode.CustomRootTrust` pinned strictly to `TrustedCaThumbprint`.
2. **Exact Peer Identity Match (`ExpectedPeerSubject` / `ExpectedPeerThumbprint`):**
   - Another PC with a valid Con Edison certificate (e.g. `laptop-123.coned.com`) still fails because its `Subject` / SAN DNS name does not match `ExpectedPeerSubject` (e.g. `qrbridge-corp.coned.com`).
3. **Locked Trust Store Lookup:**
   - Once pinned, `ITrustStore` contains **only** that verified peer's `SigningKeyId` and `AgreementKeyId`. In [ReceiveEngine.cs](../src/QrDiode.Core/Pipeline/ReceiveEngine.cs), any manifest signed by any other `SigningKeyId` or addressed to any other `ReceiverAgreementKeyId` is immediately rejected/ignored, and while a transfer session is active, incoming `CertHello` frames are ignored so they can never interrupt an in-flight bundle.
4. **Per-Frame ECDH HMAC (`FrameMac`):**
   - Every data QR frame requires a valid 16-byte HMAC under `FrameKey`, derived from ECDH between **this Receiver's TPM key** and **that pinned Sender's key**. Foreign data frames are dropped before reaching `LtDecoder`.

---

## 7. Implementation Checklist (File by File)

Follow the repository layout rules (`Configurations/Options/` for settings sections, `Configurations/Enums/Enums.cs` for new enums, `Exceptions/` for custom exceptions, and keep `QrDiode.Core` free of WPF/SQLite/EF packages).

### Step 1 — `QrDiode.Core` (Options, Fallback Routing, X.509 Keys, and `CertHello`)
1. **Create** `sourcecode/qrdiode/src/QrDiode.Core/Configurations/Options/CertificateOptions.cs` (namespace `QrDiode.Core`):
   - `SectionName = "Certificate"`, `Location`, `OwnSubject`, `OwnThumbprint`, `TrustedCaThumbprint`, `ExpectedPeerSubject`, `ExpectedPeerThumbprint`, `RequireHandshakeOnStart`.
   - `bool IsConfigured`: `false` when `Location` and all other string properties are blank (triggers **Fallback Mode**); throws `InvalidDataException` when partially filled; parses `"Cert:\\LocalMachine\\My"`, `"LocalMachine\\My"`, `"Cert:\\CurrentUser\\My"`, or `"CurrentUser\\My"` into `(StoreLocation, StoreName)`.
2. **Update** [Enums.cs](../src/QrDiode.Core/Configurations/Enums/Enums.cs):
   - Add `KeyProviderMode { CngFallback, X509Certificate }` if needed by UI status banners.
3. **Create** `sourcecode/qrdiode/src/QrDiode.Core/Crypto/Keys/X509EndpointKeys.cs`:
   - Implements [IEndpointKeys.cs](../src/QrDiode.Core/Crypto/Keys/IEndpointKeys.cs).
   - Opens `X509Store` read-only at the configured `(StoreName, StoreLocation)`, locates the valid certificate matching `OwnThumbprint` / `OwnSubject` with an ECDSA P-256 private key, checks TPM / non-exportable key storage policy when `"Production": true`, and opens/creates the companion TPM `ECDiffieHellmanP256` key in CNG.
4. **Update** [PublicKeyBundle.cs](../src/QrDiode.Core/Crypto/Trust/PublicKeyBundle.cs) & [DirectoryTrustStore.cs](../src/QrDiode.Core/Crypto/Trust/DirectoryTrustStore.cs):
   - Support optional `CertDerBase64` + `HandshakeSignatureBase64` metadata on `qrdiode-pubkeys-v2` (while still accepting `qrdiode-pubkeys-v1` in Fallback Mode!).
   - When `CertificateOptions.IsConfigured` is `true`, `DirectoryTrustStore` trusts **only** a bundle whose embedded `CertDerBase64` validates against `CertHelloValidator` (`TrustedCaThumbprint` + `ExpectedPeerSubject`), ignoring any plain unsigned `.json` files in `%LocalAppData%\QrDiode\trust\`.
5. **Create** `sourcecode/qrdiode/src/QrDiode.Core/Crypto/Trust/CertHelloValidator.cs`:
   - Builds and verifies `CertHello` payloads (offline `X509Chain` with `CustomRootTrust`, validity period, ECDSA P-256 curve, `DigitalSignature` key usage, `ExpectedPeerSubject` / `ExpectedPeerThumbprint`, low-S proof-of-possession signature over `AgreementSpki`, and timestamp window).
6. **Update** [KeyPolicy.cs](../src/QrDiode.Core/Crypto/Provisioning/KeyPolicy.cs):
   - Central switch:
     - `!certOptions.IsConfigured` → existing `CngEndpointKeys.OpenOrCreate(...)` + existing `DirectoryTrustStore(...)` (**100% unchanged fallback**).
     - `certOptions.IsConfigured` → `X509EndpointKeys` + CA-enforcing `DirectoryTrustStore` (and refuses `Demo setup`).
7. **Update** [FrameFormat.cs](../src/QrDiode.Core/Framing/FrameFormat.cs), [FrameWriter.cs](../src/QrDiode.Core/Framing/FrameWriter.cs), [FrameParser.cs](../src/QrDiode.Core/Framing/FrameParser.cs), and [ReceiveEngine.cs](../src/QrDiode.Core/Pipeline/ReceiveEngine.cs):
   - Bump `ProtocolVersion` to `0x03`, add `FrameType.CertHello`.
   - In `ReceiveEngine`: when `CertificateOptions` is **not** configured, ignore `FrameType.CertHello`. When configured and idle (`_manifest is null`), validate `CertHello`, save the verified peer bundle, signal `Local\QrDiode.TrustUpdated`, and raise `PeerCertificateAccepted`.

### Step 2 — `QrDiode.Sender` & `QrDiode.Receiver`
8. **Update** [TransmitEngine.cs](../src/QrDiode.Sender/Transmit/TransmitEngine.cs), [MainWindow.xaml.cs](../src/QrDiode.Sender/MainWindow.xaml.cs), and [Sender appsettings.json](../src/QrDiode.Sender/appsettings.json):
   - Add `"Certificate"` section with `"Location": ""` (empty by default so existing dev setups keep working).
   - When `CertificateOptions.IsConfigured` is `true`:
     - Hide manual key-name textbox / Demo button and open `X509EndpointKeys` automatically via `KeyPolicy`.
     - If the expected peer is not yet in `ITrustStore` (or `RequireHandshakeOnStart == true`), render the single `CertHello` QR on the stage (`StageState.Pairing`) and wait asynchronously (`Task` + `CancellationToken` + `Dispatcher.InvokeAsync`) on `Local\QrDiode.TrustUpdated` (with 2 s poll fallback).
     - As soon as the peer key appears, transition automatically into normal `SendSession` / `OutboxSource` transmission.
9. **Update** [MainWindow.xaml.cs](../src/QrDiode.Receiver/MainWindow.xaml.cs) and [Receiver appsettings.json](../src/QrDiode.Receiver/appsettings.json):
   - Add `"Certificate"` section with `"Location": ""` (empty by default).
   - When `CertificateOptions.IsConfigured` is `true`, open `X509EndpointKeys` automatically via `KeyPolicy`, pass `CertHelloValidator` to `ReceiveEngine`, audit-log accepted/rejected `CertHello` attempts, and update the status ribbon when paired.

### Step 3 — `QrDiode.KeyCeremony`
10. **Update** [Program.cs](../src/QrDiode.KeyCeremony/Program.cs) and [KeyCeremony appsettings.json](../src/QrDiode.KeyCeremony/appsettings.json):
    - Keep all existing commands (`init`, `export`, `import`, `fingerprint`, `list`, `delete`, `verify-audit`, `demo`, `demo-clean`) working when `Certificate:Location` is `""`.
    - Add `check-cert` (verifies `Certificate` settings, TPM/non-exportable private key, and CA chain in Windows Store) and `export-hello` / `import-hello` (for one-way bench tests).

### Step 4 — Automated Tests (`QrDiode.Core.Tests`)
11. **Add** `X509HandshakeTests.cs` in `sourcecode/qrdiode/tests/QrDiode.Core.Tests/`:
    - **Fallback tests:** Empty `Certificate:Location` keeps all 116 existing tests and `CngEndpointKeys` / `DirectoryTrustStore` behaviour unchanged; partial `Certificate` config throws `InvalidDataException`.
    - **Optical handshake loopback (`OpticalLoopbackTests` style):** Render Corp & DMZ `CertHello` frames to real QR bitmaps → decode via `ZXingCpp` → verify `ReceiveEngine` pairs both sides and completes an encrypted `SendSession`.
    - **Rejection tests:** Untrusted CA rejected; **same Con Edison CA but wrong `Subject` (foreign company PC) rejected**; tampered ECDH key rejected; expired/stale `CertHello` rejected; `CertHello` arriving mid-transfer ignored without dropping the active session.

---

## 8. Living Documentation to Update When Built

Per `.github/instructions/documentation.instructions.md`, once implemented and verified with `dotnet test All.slnx`:
- Update [qrdiode-pending-work.md](./qrdiode-pending-work.md) (mark P-6 / X.509 trust store option status).
- Update [user-guide.md](./user-guide.md) (document Windows Certificate Store setup alongside the fallback KeyCeremony procedure).
- Update [architecture.md](../../../docs/gateway-to-qrdiode/architecture.md), `docs/handoff.md`, and `.github/copilot-instructions.md`.

---

## 9. As built (27 Nov 2026)

### Where the build differs from the plan above

| Plan | As built | Why |
|---|---|---|
| A `StageState.Pairing` state that shows the CertHello until paired | No new state. In certificate mode the stage shows the CertHello **whenever it is idle** (nothing queued, or not yet paired), before and after pairing (`TransmitEngine.HelloFrame` / `ShowingHello`) | If one side is reinstalled (its pin lost) while the other side is already paired and busy, the paired side must still show its CertHello now and then, or the lane can never re-pair |
| `KeyProviderMode` enum | `KeyExchangeKind` (`KeyCeremony`, `Certificate`), set by `"KeyExchange"` in `C:\ProgramData\QrDiode\keyexchange.json` (§10) | An explicit choice, and room for more mechanisms |
| `ReceiveEngine` writes the pin and rings the event | The engine only verifies (`FeedResult.PeerAccepted`, `LastPairedPeer`); the **Receiver app** pins (`IKeyExchange.Pin`), swaps the engine's trust store (`ReloadableTrustStore`) and rings `Local\QrDiode.TrustUpdated` (`TrustSignal`) | The engine stays free of files and named events, like the replay commit (the host commits, decision on known issue 3) |
| `RequireHandshakeOnStart` on both apps | Receiver only: at Start it deletes the pins (`x509-*.json`) and rings; the Sender drops the peer at once and shows its CertHello | One owner for the pin files |
| CertHello freshness "anti-replay clock window" | The Receiver's replay window: 15 min in Strict mode, 48 h otherwise. The Sender stamps a fresh CertHello every 60 s | Same clock rule as manifests |
| — | A pinned peer is replaced only by a CertHello with **other keys and a newer timestamp** (`PinOutcome.Older` otherwise); the same keys again write nothing (`Unchanged`) | A recording of an older CertHello can never roll a pin back |
| — | In certificate mode the KeyCeremony tool offers only `check-cert` / `export-hello` / `import-hello` (the mechanism's commands); **⚡ Demo setup** is hidden | A certificate-mode machine never trusts key ceremony bundles |
| — | With `OwnSubject`, the newest certificate of that name **that passes the checks the other side runs** is used (ECDSA P-256, may sign, chains to the trusted CA) | A domain machine often has a newer auto-enrolled RSA certificate with the same name (code review, 27 Nov) |
| — | `CngEndpointKeys` now looks for a named key in **both** the software provider and the TPM (`CngKey.Exists`/`Open` without a provider only search the software one). A key already in the software provider is kept | Without it a TPM key could not be reopened: the second app (or every restart) failed in production, or quietly made a different software key. This also fixes the key ceremony keys on TPM machines (code review, 27 Nov) |

### Files

| File | What |
|---|---|
| `QrDiode.Core/Configurations/Options/CertificateOptions.cs`, `KeyExchangeSettings.cs` | The `"Certificate"` section (`IsEmpty`; `Problem()` refuses half a configuration) inside the machine-wide `keyexchange.json` |
| `QrDiode.Core/Configurations/Enums/Enums.cs` | `PinOutcome` (Pinned, Replaced, Unchanged, Older), `KeyExchangeKind` |
| `QrDiode.Core/Crypto/Exchange/` | The abstraction (§10): `IKeyExchange`, `IPairingVerifier` + `VerifiedPeer`, `KeyExchangeCommand`, `KeyCeremonyExchange`, `CertificateKeyExchange`, `KeyExchanges` |
| `QrDiode.Core/Framing/FrameFormat.cs`, `FrameWriter.cs`, `FrameParser.cs` | Protocol **v3**; `CertHello` frame (type 0x03); v1 and v2 frames refused |
| `QrDiode.Core/Crypto/Keys/X509EndpointKeys.cs` | Certificate from the store signs; named CNG ECDH key `QrDiode.x509-<thumbprint 16>.kex` encrypts |
| `QrDiode.Core/Crypto/Signing/LowSSignature.cs` | Low-S ECDSA P-256 for the manifest and the CertHello (moved out of `TransferManifest`, unchanged) |
| `QrDiode.Core/Crypto/Trust/CertHello.cs`, `CertHelloValidator.cs` | Build and verify a CertHello (§5–6) |
| `QrDiode.Core/Crypto/Trust/CertificatePins.cs`, `ReloadableTrustStore.cs`, `TrustSignal.cs` | Pin files, a trust store the running engine can swap, the doorbell to the Sender |
| `QrDiode.Core/Crypto/Trust/PublicKeyBundle.cs`, `DirectoryTrustStore.cs`, `Provisioning/KeyPolicy.cs` | Bundle v2 (carries the CertHello); certificate-mode trust store re-verifies every pin on load; the key ceremony's rules |
| `QrDiode.Core/Pipeline/ReceiveEngine.cs` | `ReceiveOptions.Pairing` (an `IPairingVerifier`); pairing frames only while no session is in flight, each distinct frame judged once |
| `QrDiode.Sender` (`Transmit/TransmitEngine.cs`, `StageWindow.xaml.cs`, `MainWindow.xaml.cs`) | The pairing frame on the idle stage ("PAIRING"); the pairing loop reloads trust when the trust folder changes |
| `QrDiode.Receiver/MainWindow.xaml.cs` | The exchange's verifier + swappable trust store for the engine; `HandlePairedPeer` pins and rings; audit `pairing.*` |
| `QrDiode.KeyCeremony/Program.cs` | A thin CLI: `fingerprint`, `list`, `delete`, `verify-audit` + the mechanism's commands |
| `tests/QrDiode.Core.Tests/X509HandshakeTests.cs`, `TestPki.cs` | 21 tests: choosing the mechanism, refused settings and a writable file on a kiosk, pairing through real QR codes, every refusal, pins, Issuing-CA anchor |

### Verified

- `dotnet test sourcecode\qrdiode\tests\QrDiode.Core.Tests`: **133 passed** (116 before + 17); after the abstraction
  (§10) **136 passed**; with the machine-wide settings file **138 passed**.
- On one PC with throw-away certificates in **CurrentUser\My** and the CA in **CurrentUser\CA** (removed afterwards):
  `check-cert` opened the certificate, created the ECDH key and verified the chain; `export-hello` wrote a 658-byte
  CertHello; `init` was refused; `import-hello` refused the wrong peer, then pinned the right one (`Pinned`, then
  `Unchanged`); `list` showed the pin and reported the existing demo bundles as not trusted. After the review fixes: a
  newer RSA certificate with the same name was skipped, and three `check-cert` runs opened the same ECDH key.

### Not tried

Real screens and cameras; TPM-backed keys (on the development PC the TPM refused the key creation, so every key fell
back to the software provider: the TPM reopen fix is untested); `"Production": true`; company certificates and an
Issuing CA in `LocalMachine`; the kiosk user's Read permission on a `LocalMachine` private key.

---

## 10. Key exchange abstraction (27 Nov 2026)

Decision 59. **How the two sides come to trust each other's keys is one interface**, so the key ceremony, the
certificates or a future mechanism can be swapped without touching the apps.

```text
C:\ProgramData\QrDiode\keyexchange.json   { "KeyExchange": "KeyCeremony" | "Certificate", "Certificate": { … } }
        │   one file per machine, read by all three programs (no file = KeyCeremony)
        ▼
KeyExchanges.Load(options) ──► IKeyExchange ◄── the only thing these call:
        │                         ├─ KeyCeremonyExchange      QrDiode.Sender   (keys, trust, pairing frame on the stage)
        │                         └─ CertificateKeyExchange   QrDiode.Receiver (keys, trust, verifier, pin)
        │                                                     ReceiveEngine    (IPairingVerifier only)
        └─ refuses settings for another mechanism             QrDiode.KeyCeremony (Commands)
```

| `IKeyExchange` member | Key ceremony | Certificate |
|---|---|---|
| `OpenOwnKeys(endpointName)` | Named CNG keys (`KeyPolicy.OpenKeys`) | `X509EndpointKeys.Open` (endpoint name ignored) |
| `OpenTrustStore()` | v1 bundles (`KeyPolicy.OpenTrustStore`) | Pins whose CertHello still verifies |
| `UsesEndpointName` / `Identity` | true / — | false / `OwnThumbprint` or `OwnSubject` |
| `AllowsDemo` | not in production | never |
| `PairsOverTheLight`, `ExpectedPeer` | false, null | true, `ExpectedPeerSubject` |
| `BuildPairingFrame(keys)` | null | a CertHello (fresh timestamp) |
| `CreatePairingVerifier(freshness)` | null | `CertHelloValidator` (an `IPairingVerifier`) |
| `Pin(peer)`, `ForgetPairedPeers()`, `ForgetsPeersOnStart` | not supported, 0, false | `CertificatePins`, `RequireHandshakeOnStart` |
| `Commands` (KeyCeremony tool) | `init`, `export`, `import`, `demo`, `demo-clean` | `check-cert`, `export-hello`, `import-hello` |

The KeyCeremony tool keeps only what every mechanism shares (`fingerprint`, `list`, `delete`, `verify-audit`) and runs
the mechanism's own commands. A verified peer is a mechanism-neutral `VerifiedPeer` (name, identity, timestamp, the two
public keys, the pairing frame as evidence, audit details).

**Where the settings live:** one machine-wide file, `C:\ProgramData\QrDiode\keyexchange.json`
(`KeyExchangeSettings`, `QrDiodePaths.KeyExchangeFile`), not the per-exe `appsettings.json` files: the Sender and the
Receiver must use the same certificate and peer, and the KeyCeremony tool is not running in normal use, so none of them
can rely on another's file. `C:\ProgramData` is writable by ordinary users by default, so an administrator owns and
locks the folder (user guide Part D), and with `"Production": true` the programs refuse a file or folder the running
user can change.

**Settings rules (fail closed):** no file, or `"KeyExchange"` missing = `KeyCeremony`. `KeyCeremony` with a filled-in
`"Certificate"` section is refused (someone meant certificates). `Certificate` with half a section is refused. An
unknown value or a misspelt setting is refused. Every refusal names the file.

### Adding a mechanism later

1. Add a value to `KeyExchangeKind` (`Configurations/Enums/Enums.cs`).
2. Write `QrDiode.Core/Crypto/Exchange/<Name>KeyExchange.cs` implementing `IKeyExchange` (and, if it pairs over the
   light, an `IPairingVerifier` plus its settings class in `Configurations/Options/`).
3. Add one case to `KeyExchanges.Load`.
4. Only if it pairs with a **new wire frame**: add the frame type to `FrameFormat`/`FrameParser`, route it in
   `ReceiveEngine.Feed` to `FeedPairing`, and bump `FrameFormat.ProtocolVersion` (both sides update together).
5. Tests in `QrDiode.Core.Tests`.

The Sender, the Receiver and the KeyCeremony tool need no change for steps 1–3.
