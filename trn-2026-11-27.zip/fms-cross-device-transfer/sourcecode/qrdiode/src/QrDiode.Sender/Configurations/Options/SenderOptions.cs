using QrBridge.Shared.Bundles;

namespace QrDiode.Sender;

/// <summary>
/// The "Sender" section of the Sender's <c>appsettings.json</c>: bundle limits (Gateway mode) and unattended start-up
/// (kiosk, Integration-Plan §2.6). The "QrDiode" section holds Production and Mode; "QRDatabase" the gateway's database (Side, DataFolder, Provider, ConnectionString).
/// </summary>
public sealed class SenderOptions
{
    public const string SectionName = "Sender";

    /// <summary>Most messages in one bundle (decision 52: 50).</summary>
    public int BundleMaxMessages { get; set; } = BundleCodec.DefaultMaxMessages;

    /// <summary>Largest bundle in bytes (decision 52: 128 KB); a single message bigger than this goes alone.</summary>
    public int BundleMaxBytes { get; set; } = BundleCodec.DefaultMaxBytes;

    /// <summary>Kiosk: open the keys, pick the receiver, open the stage (and in Standalone mode start the simulator) without clicks.</summary>
    public bool AutoStart { get; set; }

    /// <summary>This machine's endpoint name from the key ceremony (e.g. "ot-line-1"); empty = the name in the window.</summary>
    public string Endpoint { get; set; } = "";

    /// <summary>The trusted receiver to address (its bundle name, e.g. "it-recv-1"); empty = the first trusted receiver.</summary>
    public string Receiver { get; set; } = "";

    /// <summary>Why these settings cannot be used, or null.</summary>
    public string? Problem() =>
        BundleMaxMessages is < 1 or > BundleCodec.MaxMessagesLimit ? $"Sender:BundleMaxMessages must be 1–{BundleCodec.MaxMessagesLimit}."
        : BundleMaxBytes < 4096 ? "Sender:BundleMaxBytes must be at least 4096."
        : null;
}
