using System.IO;
using System.Text.Json;
using System.Windows;
using QrDiode.Core;

namespace QrDiode.Sender.Rendering;

/// <summary>
/// Where the operator last put the QR stage, per Windows user (<c>%LocalAppData%\QrDiode\sender-stage.json</c>), so an
/// unattended start (kiosk, Integration-Plan §2.6) puts it back in front of the camera at the same size. Operator
/// state, like the Receiver's store location; nothing security-relevant.
/// </summary>
public sealed class StagePlacement
{
    private static readonly JsonSerializerOptions Json = new() { WriteIndented = true };

    public double Left { get; set; }
    public double Top { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }
    public bool Topmost { get; set; }

    private static string FilePath => Path.Combine(QrDiodePaths.Root, "sender-stage.json");

    /// <summary>The saved placement, or null when there is none or it cannot be read.</summary>
    public static StagePlacement? Load()
    {
        try
        {
            return File.Exists(FilePath) ? JsonSerializer.Deserialize<StagePlacement>(File.ReadAllText(FilePath), Json) : null;
        }
        catch (Exception ex) when (ex is IOException or JsonException or UnauthorizedAccessException)
        {
            return null;
        }
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(QrDiodePaths.Root);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(this, Json));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            // Not worth an error: the stage just opens where Windows puts it next time.
        }
    }

    /// <summary>True when the stage would land on a screen that exists now (a monitor may have been unplugged).</summary>
    public bool IsOnScreen() =>
        Width >= 200 && Height >= 200 &&
        Left + 100 <= SystemParameters.VirtualScreenLeft + SystemParameters.VirtualScreenWidth &&
        Top + 100 <= SystemParameters.VirtualScreenTop + SystemParameters.VirtualScreenHeight &&
        Left + Width >= SystemParameters.VirtualScreenLeft + 100 &&
        Top >= SystemParameters.VirtualScreenTop - 20;
}
