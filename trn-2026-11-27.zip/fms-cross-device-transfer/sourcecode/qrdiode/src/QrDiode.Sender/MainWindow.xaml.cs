using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;
using Path = System.IO.Path;
using QrBridge.Shared;
using QrBridge.Shared.Bundles;
using QrDiode.Core;
using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;
using QrDiode.Core.Presentation;
using QrDiode.Core.Simulation;
using QrDiode.Sender.Transmit;
using QrDiode.Ui;

namespace QrDiode.Sender;

public partial class MainWindow : Window
{
    /// <summary>Deployment rules from appsettings.json next to the exe ("Production", "Mode").</summary>
    private readonly QrDiodeOptions _options;
    /// <summary>Bundle limits and unattended start-up ("Sender" section).</summary>
    private readonly SenderOptions _senderOptions;
    /// <summary>Gateway mode: the gateway's database ("QRDatabase" section, the same values as the gateway's "GatewayDatabase"); null when it cannot be used.</summary>
    private readonly GatewayDatabaseOptions? _bridgeOptions;
    private QrAppBridge? _bridge;
    private OutboxSource? _outbox;
    private bool GatewayMode => _options.Mode == QrDiodeMode.Gateway;
    /// <summary>How this machine and its peer trust each other's keys (the machine's keyexchange.json); null when the settings cannot be used (then no keys are opened at all).</summary>
    private readonly IKeyExchange? _exchange;
    private readonly string? _exchangeError;
    /// <summary>The two sides pair over the light: the stage shows this machine's pairing frame whenever it is idle.</summary>
    private bool PairsOverTheLight => _exchange?.PairsOverTheLight == true;
    /// <summary>How often the pairing frame on the stage gets a fresh timestamp (the Receiver refuses stale ones).</summary>
    private static readonly TimeSpan HelloRefresh = TimeSpan.FromSeconds(60);
    private CancellationTokenSource? _pairingStop;
    private IEndpointKeys? _keys;
    private DirectoryTrustStore? _trust;
    /// <summary>The store before the last reload: a session being encoded may still hold its keys, so it goes one reload later.</summary>
    private DirectoryTrustStore? _retiredTrust;
    private readonly AuditLog _audit;
    private readonly LiveSource _source = new();
    private readonly TransmitEngine _engine;
    private StageWindow? _stage;
    private string? _lastReceipt;
    private QueueItem? _selected;
    private PayloadText _selectedText = PayloadText.Empty;
    private Guid _followedSession;
    /// <summary>XAML property setters raise Checked/ValueChanged while the tree is still half-built.</summary>
    private bool _ready;

    private sealed record ReceiverChoice(PeerPublicKeys Peer)
    {
        public string Label => $"{Peer.Name}   ·   kex {KeyId.ToHex(Peer.AgreementKeyId)}";
    }

    public MainWindow()
    {
        InitializeComponent();
        QrDiodePaths.EnsureCreated();
        _audit = new AuditLog(Path.Combine(QrDiodePaths.AuditDir, "sender-audit.jsonl"));

        string? optionsError = null;
        try
        {
            _options = QrDiodeOptions.Load();
        }
        catch (InvalidDataException ex)
        {
            // Unreadable rules: run under the strictest ones rather than guess, and say why.
            _options = new QrDiodeOptions { Production = true };
            optionsError = ex.Message;
        }
        try
        {
            _exchange = KeyExchanges.Load(_options);
        }
        catch (InvalidDataException ex)
        {
            // Settings for the wrong or half a key exchange must not quietly run another one: open nothing, and say why.
            _exchangeError = ex.Message;
            optionsError ??= ex.Message;
        }
        DemoButton.Visibility = _exchange?.AllowsDemo == true ? Visibility.Visible : Visibility.Collapsed;
        if (_exchange is { UsesEndpointName: false }) EndpointNameBox.Text = _exchange.Identity;

        try
        {
            _senderOptions = AppSettings.ReadSection<SenderOptions>(SenderOptions.SectionName);
            optionsError ??= _senderOptions.Problem();
        }
        catch (InvalidDataException ex)
        {
            _senderOptions = new SenderOptions(); // no auto-start on unreadable settings
            optionsError ??= ex.Message;
        }
        if (GatewayMode)
        {
            try
            {
                if (AppSettings.HasSection(GatewayDatabaseOptions.FormerSectionName))
                    throw new InvalidDataException(GatewayDatabaseOptions.FormerSectionProblem(GatewayDatabaseOptions.QrDiodeSectionName));
                _bridgeOptions = AppSettings.ReadSection<GatewayDatabaseOptions>(GatewayDatabaseOptions.QrDiodeSectionName);
                if (string.IsNullOrWhiteSpace(_bridgeOptions.DataFolder) || _bridgeOptions.MaxPayloadBytes <= 0)
                    throw new InvalidDataException("QRDatabase:DataFolder must be set and QRDatabase:MaxPayloadBytes positive.");
            }
            catch (InvalidDataException ex)
            {
                _bridgeOptions = null; // never guess which database to air
                optionsError ??= ex.Message;
            }
        }

        _engine = new TransmitEngine(_audit);
        QueueList.ItemsSource = _engine.Queue;

        _engine.Changed += OnEngineChanged;
        _engine.SessionEnded += OnSessionEnded;
        _engine.Queue.CollectionChanged += (_, _) => RefreshQueueChrome();

        _source.Emitted += payload => _engine.Enqueue(payload);
        _source.Tick += OnSourceTick;

        BuildTypeToggles();
        ApplyMode();
        _ready = true;
        ReloadTrust();
        Interval_Changed(this, null!);
        Fps_Changed(this, null!);
        RenderDetail(null);
        RefreshEverything();
        if (optionsError is not null)
            Log($"{optionsError} Running with the strictest rules until it is fixed.", "PillBad", "✖");

        Loaded += async (_, _) => await OnLoadedAsync();
    }

    // ═══════════════════ mode, bridge, unattended start ═══════════════════

    /// <summary>Gateway mode: the gateway's Outbox replaces the simulator and the manual file.</summary>
    private void ApplyMode()
    {
        if (!GatewayMode) return;
        SourceModeTray.Visibility = Visibility.Collapsed;
        SourceButtons.Visibility = Visibility.Collapsed;
        LivePanel.Visibility = Visibility.Collapsed;
        ManualPanel.Visibility = Visibility.Collapsed;
        BridgePanel.Visibility = Visibility.Visible;
    }

    private async Task OnLoadedAsync()
    {
        if (GatewayMode) await ConnectBridgeAsync();
        if (_senderOptions.AutoStart) AutoStart();
    }

    private async Task ConnectBridgeAsync()
    {
        if (_bridgeOptions is not { } options)
        {
            BridgeStatusText.Text = "Gateway mode, but the \"QRDatabase\" settings cannot be used — nothing is aired. Fix appsettings.json and restart.";
            return;
        }
        try
        {
            // Off the UI thread: the first start may create or upgrade the bridge database.
            _bridge = await Task.Run(() => QrAppBridge.OpenAsync(options, CancellationToken.None));
            _outbox = new OutboxSource(_bridge, _engine, Dispatcher, _senderOptions, _audit);
            _outbox.StatusChanged += text => BridgeStatusText.Text = text;
            _outbox.Start();
            _audit.Append("bridge.connected", new Dictionary<string, string>
            {
                ["side"] = options.Side.ToString(),
                ["database"] = _bridge.Database,
            });
        }
        catch (Exception ex)
        {
            BridgeStatusText.Text = $"Gateway mode: cannot open {QrAppBridge.Describe(options)}: {ex.Message}";
            Log($"Gateway mode: the gateway's database cannot be opened — nothing is aired. {ex.Message}", "PillBad", "✖");
            _audit.Append("bridge.connect_failed", new Dictionary<string, string> { ["database"] = QrAppBridge.Describe(options), ["message"] = ex.Message });
        }
        RefreshEverything();
    }

    /// <summary>Kiosk (Integration-Plan §2.6): keys, receiver and stage from the settings, no clicks.</summary>
    private void AutoStart()
    {
        if (_exchange is { UsesEndpointName: true } && _senderOptions.Endpoint.Length > 0) EndpointNameBox.Text = _senderOptions.Endpoint;
        OpenKeys_Click(this, new RoutedEventArgs());
        if (_keys is null)
        {
            Log("Auto-start stopped: this machine's keys could not be opened (see above).", "PillBad", "✖");
            return;
        }

        // Pairing over the light: the key exchange names the peer, and an unpaired stage shows the pairing frame until it pairs.
        if (!PairsOverTheLight)
        {
            if (_senderOptions.Receiver.Length > 0)
            {
                var match = ReceiverCombo.Items.OfType<ReceiverChoice>()
                    .FirstOrDefault(c => c.Peer.Name.Equals(_senderOptions.Receiver, StringComparison.OrdinalIgnoreCase));
                if (match is null)
                {
                    Log($"Auto-start stopped: receiver '{_senderOptions.Receiver}' is not in the trust store.", "PillBad", "✖");
                    return;
                }
                ReceiverCombo.SelectedItem = match;
            }
            if (!_engine.CanTransmit)
            {
                Log("Auto-start stopped: no trusted receiver to address.", "PillBad", "✖");
                return;
            }
        }

        if (_stage is null) OpenStage();
        if (!GatewayMode && !_source.IsRunning && _engine.CanTransmit) SourceRun_Click(this, new RoutedEventArgs());
        _audit.Append("send.autostart", new Dictionary<string, string>
        {
            ["endpoint"] = EndpointNameBox.Text.Trim(),
            ["receiver"] = (ReceiverCombo.SelectedItem as ReceiverChoice)?.Peer.Name ?? "",
            ["mode"] = _options.Mode.ToString(),
        });
    }

    // ═══════════════════ identity + trust ═══════════════════

    private void ReloadTrust()
    {
        _retiredTrust?.Dispose();
        _retiredTrust = _trust;
        _trust = null;
        try
        {
            if (_exchange is not null) _trust = _exchange.OpenTrustStore();
        }
        catch (InvalidOperationException ex)
        {
            Log($"Trust store cannot be opened: {ex.Message}", "PillBad", "✖");
        }
        if (_trust is { Problems.Count: > 0 })
            Log("Trust bundles skipped: " + string.Join("; ", _trust.Problems), "PillWarn", "⚠");

        // Everyone in the trust store except ourselves is a valid destination.
        var choices = (_trust?.Peers ?? [])
            .Where(p => _keys is null || !p.SigningKeyId.AsSpan().SequenceEqual(_keys.SigningKeyId))
            .Select(p => new ReceiverChoice(p))
            .ToList();
        ReceiverCombo.ItemsSource = choices;
        if (choices.Count > 0) ReceiverCombo.SelectedIndex = 0;

        SetPill(DestPill, DestPillText,
            choices.Count > 0 ? $"✔ {choices.Count} trusted" : PairsOverTheLight ? "waiting to pair" : "0 trusted",
            choices.Count > 0 ? "PillOk" : "PillIdle");
        DestNote.Text = PairsOverTheLight
            ? choices.Count > 0
                ? $"Paired over the cameras ({_exchange!.Description}): manifests are addressed to this peer only."
                : $"Waiting to pair with {_exchange!.ExpectedPeer}: open the stage (it shows this machine's pairing code) " +
                  "and let this machine's Receiver read the other side's."
            : choices.Count > 0
                ? "Manifests are addressed to this key only."
                : _options.Production
                    ? "Import the IT receiver’s bundle with the KeyCeremony tool."
                    : "Import the IT receiver’s bundle, or press ⚡ Demo setup on both apps.";

        SyncEngineIdentity();
    }

    private void ReloadTrust_Click(object sender, RoutedEventArgs e) => ReloadTrust();

    private void Receiver_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (_ready) SyncEngineIdentity();
    }

    private void SyncEngineIdentity()
    {
        _engine.Keys = _keys;
        _engine.Receiver = (ReceiverCombo.SelectedItem as ReceiverChoice)?.Peer;
        RefreshEverything();
    }

    private void OpenKeys_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            StopPairing();
            _keys?.Dispose();
            _keys = null;
            if (_exchange is null)
                throw new InvalidOperationException(_exchangeError ?? "The key exchange settings cannot be used.");
            _keys = _exchange.OpenOwnKeys(EndpointNameBox.Text.Trim());
            KeyInfoText.Text = (_exchange.UsesEndpointName ? "" : $"{_exchange.Description} {_exchange.Identity} · ") +
                               $"sign {KeyId.ToHex(_keys.SigningKeyId)} · kex {KeyId.ToHex(_keys.AgreementKeyId)}";
            SetPill(KeyStatusPill, KeyStatusPillText,
                _keys.IsTpmBacked ? "✔ TPM-backed" : "✔ software KSP", "PillOk");
            if (_exchange.PairsOverTheLight) StartPairing(_exchange, _keys);
            ReloadTrust();
        }
        catch (Exception ex)
        {
            KeyInfoText.Text = $"Key error: {ex.Message}";
            SetPill(KeyStatusPill, KeyStatusPillText, "✖ error", "PillBad");
            _keys = null;
            SyncEngineIdentity();
        }
    }

    // ═══════════════════ pairing over the light ═══════════════════

    /// <summary>
    /// The key exchange pairs over the light (e.g. certificates): the stage shows this machine's pairing frame whenever
    /// nothing is being sent, and a background loop follows the trust folder, where this machine's Receiver pins the other
    /// side when its camera reads that side's frame. Once the peer is there, the Sender can address it and the queue drains.
    /// </summary>
    private void StartPairing(IKeyExchange exchange, IEndpointKeys keys)
    {
        _engine.HelloFrame = exchange.BuildPairingFrame(keys);
        var stop = new CancellationTokenSource();
        _pairingStop = stop;
        _ = Task.Factory.StartNew(() => FollowTrust(exchange, keys, stop.Token), stop.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        _audit.Append("pairing.started", new Dictionary<string, string>
        {
            ["exchange"] = exchange.Kind.ToString(),
            ["identity"] = exchange.Identity,
            ["signKey"] = KeyId.ToHex(keys.SigningKeyId),
            ["expectedPeer"] = exchange.ExpectedPeer ?? "",
        });
    }

    private void StopPairing()
    {
        _pairingStop?.Cancel();
        _pairingStop = null;
        _engine.HelloFrame = null;
    }

    /// <summary>Background thread: wakes on the Receiver's ring (or every 2 s), reloads trust when the folder changed, refreshes the pairing frame.</summary>
    private void FollowTrust(IKeyExchange exchange, IEndpointKeys keys, CancellationToken ct)
    {
        try
        {
            using var signal = TrustSignal.Open();
            string seen = TrustStamp();
            var nextHello = DateTime.UtcNow + HelloRefresh;
            while (WaitHandle.WaitAny([signal, ct.WaitHandle], TimeSpan.FromSeconds(2)) != 1)
            {
                string stamp = TrustStamp();
                if (stamp != seen)
                {
                    seen = stamp;
                    Dispatcher.BeginInvoke(() => { if (!ct.IsCancellationRequested) ReloadTrust(); });
                }
                if (DateTime.UtcNow >= nextHello)
                {
                    nextHello = DateTime.UtcNow + HelloRefresh;
                    byte[]? hello = exchange.BuildPairingFrame(keys);
                    Dispatcher.BeginInvoke(() => { if (!ct.IsCancellationRequested) _engine.HelloFrame = hello; });
                }
            }
        }
        catch (Exception ex) when (!ct.IsCancellationRequested)
        {
            Dispatcher.BeginInvoke(() => Log($"Pairing stopped: {ex.Message} Press Open keys to start it again.", "PillBad", "✖"));
        }
        catch (Exception)
        {
            // Stopped on purpose (new keys, or the window closed): the keys may already be disposed.
        }
    }

    /// <summary>Names, sizes and times of the trust folder's files: changes when the Receiver pins, replaces or forgets a peer.</summary>
    private static string TrustStamp()
    {
        if (!Directory.Exists(QrDiodePaths.TrustDir)) return "";
        return string.Join("|", Directory.EnumerateFiles(QrDiodePaths.TrustDir, "*.json")
            .Order(StringComparer.OrdinalIgnoreCase)
            .Select(f => new FileInfo(f))
            .Select(f => $"{f.Name}:{f.Length}:{f.LastWriteTimeUtc.Ticks}"));
    }

    private void Demo_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (_exchange?.AllowsDemo != true)
                throw new InvalidOperationException("Demo setup is turned off on this machine (production, or not the key ceremony).");
            KeyPolicy.EnsureDemoAllowed(_options);
            var ids = DemoProvisioner.Provision();
            EndpointNameBox.Text = DemoProvisioner.OtEndpoint;
            OpenKeys_Click(sender, e);

            foreach (ReceiverChoice choice in ReceiverCombo.Items)
            {
                if (choice.Peer.Name == DemoProvisioner.ItEndpoint)
                {
                    ReceiverCombo.SelectedItem = choice;
                    break;
                }
            }

            DemoStrip.Visibility = Visibility.Visible;
            DemoStripText.Text =
                $"ot fingerprint  {ids.OtFingerprint}\n" +
                $"it fingerprint  {ids.ItFingerprint}\n" +
                "Full security is active — real signatures, encryption and anti-replay. " +
                "Now press ⚡ Demo setup in the Receiver, then Start source here.";
            Log($"Demo keys ready — {DemoProvisioner.OtEndpoint} ⟶ {DemoProvisioner.ItEndpoint}.", "PillOk", "⚡");
        }
        catch (Exception ex)
        {
            Log($"Demo setup failed: {ex.Message}", "PillBad", "✖");
        }
    }

    // ═══════════════════ source mode ═══════════════════

    private void Mode_Changed(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        bool live = LiveModeOption.IsChecked == true;
        LivePanel.Visibility = live ? Visibility.Visible : Visibility.Collapsed;
        ManualPanel.Visibility = live ? Visibility.Collapsed : Visibility.Visible;
        if (!live) _source.Pause();
        RefreshEverything();
    }

    private void BuildTypeToggles()
    {
        foreach (var type in PayloadCatalogue.All)
        {
            var toggle = new ToggleButton
            {
                Style = (Style)FindResource("ChipToggle"),
                Content = type.Name,
                Margin = new Thickness(0, 0, 4, 4),
                IsChecked = _source.Options.EnabledTypes.Contains(type.Name),
                ToolTip = $"{type.Code} · {type.Kind}",
                Tag = type,
            };
            toggle.Checked += TypeToggle_Changed;
            toggle.Unchecked += TypeToggle_Changed;
            TypeTogglePanel.Children.Add(toggle);
        }
    }

    private void TypeToggle_Changed(object sender, RoutedEventArgs e)
    {
        if (!_ready || sender is not ToggleButton { Tag: PayloadType type } toggle) return;
        if (toggle.IsChecked == true) _source.Options.EnabledTypes.Add(type.Name);
        else _source.Options.EnabledTypes.Remove(type.Name);
    }

    private void Interval_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;

        // The two handles cannot cross: max is clamped up to min.
        double min = Math.Round(MinIntervalSlider.Value);
        double max = Math.Max(min + 1, Math.Round(MaxIntervalSlider.Value));
        _source.Options.MinInterval = TimeSpan.FromSeconds(min);
        _source.Options.MaxInterval = TimeSpan.FromSeconds(max);
        _source.Options.Burstiness = BurstSlider.Value;

        MinIntervalText.Text = $"{min:0} s";
        MaxIntervalText.Text = $"{max:0} s";
        BurstNote.Text = BurstSlider.Value < 0.15
            ? $"Near-metronome — one payload every {min:0}–{max:0} s."
            : $"Bursts of 2–3, then a quiet {min:0}–{max:0} s.";
    }

    private void SourceRun_Click(object sender, RoutedEventArgs e)
    {
        if (_source.IsRunning)
        {
            _source.Pause();
            Log("Source paused. Queued payloads keep transmitting until the queue drains.", "PillWarn", "❙❙");
        }
        else
        {
            if (!_engine.CanTransmit)
            {
                Log("Open your keys and pick a destination first.", "PillBad", "✖");
                return;
            }
            _source.Start();
            // Starting the source is the operator saying "go" — the stage comes with it.
            if (_stage is null) OpenStage();
            Log("Source running — payloads will be queued and transmitted one session at a time.", "PillAccent", "⟶");
        }
        RefreshEverything();
    }

    private void SourceStop_Click(object sender, RoutedEventArgs e)
    {
        _source.Stop();
        Log("Source stopped.", "PillIdle", "■");
        RefreshEverything();
    }

    private void Inject_Click(object sender, RoutedEventArgs e)
    {
        if (LiveModeOption.IsChecked == true)
        {
            var payload = _source.InjectNow();
            if (payload is null)
            {
                Log("No payload types are enabled — nothing to emit.", "PillWarn", "⚠");
                return;
            }
            Log($"Injected {payload.Type.Name} ({payload.Size:N0} B) into the queue.", "PillAccent", "⟶");
        }
        else if (FileBox.Text.Length > 0 && File.Exists(FileBox.Text))
        {
            _engine.EnqueueFile(FileBox.Text);
            Log($"Queued {Path.GetFileName(FileBox.Text)}.", "PillAccent", "⟶");
        }
        else
        {
            Log("Pick a file to send first.", "PillWarn", "⚠");
        }
        RefreshEverything();
    }

    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Title = "Select payload to transmit" };
        if (dialog.ShowDialog() != true) return;

        var info = new FileInfo(dialog.FileName);
        if (info.Length == 0)
        {
            SetPill(PayloadPill, PayloadPillText, "✖ empty", "PillBad");
            Log("File is empty — nothing to transmit.", "PillBad", "✖");
            return;
        }
        if (info.Length > Core.Manifest.TransferManifest.MaxPayloadBytes)
        {
            SetPill(PayloadPill, PayloadPillText, "✖ too large", "PillBad");
            Log($"That file is {info.Length / (1024.0 * 1024):0.0} MB — beyond the 64 MB design envelope. " +
                "Split it or send a summary.", "PillBad", "✖");
            return;
        }

        FileBox.Text = dialog.FileName;
        var type = PayloadCatalogue.ForFilename(Path.GetFileName(dialog.FileName), DetectKind(dialog.FileName));
        SetPill(PayloadPill, PayloadPillText, $"{type.Code} · {FormatSize(info.Length)}", "PillOutline");
        Log($"Ready — press “Inject one now” to queue {Path.GetFileName(dialog.FileName)}.", "PillAccent", "⟶");
    }

    private static Core.Manifest.ContentKind DetectKind(string path) =>
        Path.GetExtension(path).ToLowerInvariant() switch
        {
            ".xml" => Core.Manifest.ContentKind.Xml,
            ".json" => Core.Manifest.ContentKind.Json,
            _ => Core.Manifest.ContentKind.File,
        };

    private static string FormatSize(long bytes) => bytes switch
    {
        < 1024 => $"{bytes} B",
        < 1024 * 1024 => $"{bytes / 1024.0:0.#} KB",
        _ => $"{bytes / (1024.0 * 1024):0.#} MB",
    };

    // ═══════════════════ stage ═══════════════════

    private void Stage_Click(object sender, RoutedEventArgs e)
    {
        if (_stage is null) OpenStage();
        else _stage.Close();
    }

    private void OpenStage()
    {
        // Pairing over the light opens the stage before it is paired: the stage is how the other side learns this machine.
        bool canPair = PairsOverTheLight && _keys is not null;
        if (!_engine.CanTransmit && !canPair)
        {
            Log(PairsOverTheLight
                    ? "Open this machine's keys (Open keys) before opening the stage."
                    : "Open your keys and pick a destination before opening the stage.", "PillBad", "✖");
            return;
        }

        _stage = new StageWindow(_engine)
        {
            Owner = this,
            ToggleSource = GatewayMode ? null : () => SourceRun_Click(this, new RoutedEventArgs()),
            ConfirmEscape = GatewayMode || _senderOptions.AutoStart,
        };
        _stage.Closed += (_, _) =>
        {
            _stage = null;
            _engine.CloseStage();
            RefreshEverything();
        };
        _engine.OpenStage();
        _stage.Show();
        RefreshEverything();
    }

    private void Fps_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        _engine.Fps = FpsSlider.Value;
        FpsText.Text = $"{FpsSlider.Value:0}";
    }

    private void ClearHistory_Click(object sender, RoutedEventArgs e) => _engine.ClearHistory();

    private void CopyReceipt_Click(object sender, RoutedEventArgs e)
    {
        if (_lastReceipt is null) return;
        try { Clipboard.SetText(_lastReceipt); } catch (Exception) { /* clipboard busy — not worth an error */ }
    }

    // ═══════════════════ payload inspector ═══════════════════

    private void Queue_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_ready) RenderDetail(QueueList.SelectedItem as QueueItem);
    }

    private void ViewMode_Changed(object sender, RoutedEventArgs e)
    {
        if (_ready) RenderPayload();
    }

    private void RenderDetail(QueueItem? item)
    {
        _selected = item;

        if (item is null)
        {
            DetailNameText.Text = "select a queue row";
            SetPill(DetailStatePill, DetailStateText, "—", "PillIdle");
            DetailMetaText.Text = "Nothing selected — pick a payload above to inspect the bytes that go on air.";
            CopyPayloadButton.IsEnabled = false;
            SavePayloadButton.IsEnabled = false;
            _selectedText = PayloadText.Empty;
            PayloadViewer.Document = PayloadView.Message("Select a payload to read it before it leaves.");
            return;
        }

        DetailNameText.Text = item.Filename;
        CopyPayloadButton.IsEnabled = true;
        SavePayloadButton.IsEnabled = true;
        UpdateDetailMeta();
        RenderPayload();
    }

    /// <summary>
    /// The metadata line ticks with the session — air time and loop count keep moving while a
    /// payload is up, and they are the only evidence of exposure a one-way link can offer.
    /// </summary>
    private void UpdateDetailMeta()
    {
        if (_selected is not { } item) return;

        SetPill(DetailStatePill, DetailStateText, item.StateLabel, item.State switch
        {
            QueueState.OnAir => "PillAccent",
            QueueState.Sent => "PillOk",
            QueueState.Skipped => "PillWarn",
            QueueState.Failed => "PillBad",
            _ => "PillIdle",
        });

        string first =
            $"{item.Size:N0} B · {item.Type.Kind.ToString().ToLowerInvariant()} · sha256 {item.Sha256Short}" +
            (_selectedText.Truncated ? $" · showing the first {PayloadFormatter.DefaultLimit / 1024} KB" : "");

        string second = item.State is QueueState.Queued
            ? "not encoded yet — session id, frame count and receipt appear when it goes on air"
            : $"session {item.SessionShort} · {item.KLabel} · loops {item.LoopLabel} · air {item.AirLabel}" +
              (item.Receipt.Length >= 16 ? $" · receipt {QueueItem.Grouped(item.Receipt[..16])}" : "");

        DetailMetaText.Text = item.Error is { Length: > 0 } error
            ? $"{first}\n{second}\n✖ {error}"
            : $"{first}\n{second}";
    }

    private void RenderPayload()
    {
        if (_selected is not { } item)
        {
            PayloadViewer.Document = PayloadView.Message("Select a payload to read it before it leaves.");
            return;
        }

        _selectedText =
            ViewHex.IsChecked == true ? PayloadFormatter.Hex(item.Bytes) :
            ViewRaw.IsChecked == true ? PayloadFormatter.Raw(item.Type.Kind, item.Bytes) :
            PayloadFormatter.Formatted(item.Type.Kind, item.Bytes);

        PayloadViewer.Document = PayloadView.Build(_selectedText);
        UpdateDetailMeta();
    }

    private void CopyPayload_Click(object sender, RoutedEventArgs e)
    {
        if (_selectedText.Text.Length == 0) return;
        try { Clipboard.SetText(_selectedText.Text); } catch (Exception) { /* clipboard busy */ }
    }

    private void SavePayload_Click(object sender, RoutedEventArgs e)
    {
        if (_selected is not { } item) return;

        var dialog = new SaveFileDialog
        {
            Title = "Save a copy of this payload",
            FileName = item.Filename,
            Filter = "Payload|*.*",
        };
        if (dialog.ShowDialog() != true) return;

        try
        {
            File.WriteAllBytes(dialog.FileName, item.Bytes);
            Log($"Saved a copy of {item.Filename} to {dialog.FileName}.", "PillOk", "✔");
        }
        catch (Exception ex)
        {
            Log($"Could not save the payload: {ex.Message}", "PillBad", "✖");
        }
    }

    // ═══════════════════ live refresh ═══════════════════

    private void OnEngineChanged() => RefreshEverything();

    private void OnSessionEnded(QueueItem item)
    {
        if (item.State != QueueState.Sent) return;
        _lastReceipt = item.Receipt;
        CopyReceiptButton.IsEnabled = true;
        Log($"Session ended · {item.DisplayName} · {item.AirSeconds:0.0} s on air · " +
            $"receipt {QueueItem.Grouped(item.Receipt)} ← compare with the receiver’s screen",
            "PillOk", "✔");
    }

    private void OnSourceTick()
    {
        if (!_ready) return;
        DrawSparkline();
        RateText.Text = $"{_source.PerMinute:0.0}";

        if (_source.UntilNext is { } until)
        {
            SetPill(NextEmissionPill, NextEmissionText, $"next emission in {until.TotalSeconds:00} s", "PillAccent");
        }
        else
        {
            SetPill(NextEmissionPill, NextEmissionText,
                LiveModeOption.IsChecked == true ? "source paused" : "manual mode", "PillIdle");
        }

        // The stage drives the session clock, so the dashboard's live columns tick from here too.
        if (_engine.Current is { } current)
        {
            SessionCounterText.Text = $"session {current.SessionId:N}"[..15] + "…";
        }
        UpdateDetailMeta();
        RefreshQueueChrome();
    }

    /// <summary>Keeps the inspector on whatever is currently on air, unless the operator opted out.</summary>
    private void FollowOnAir()
    {
        if (FollowToggle.IsChecked != true) return;
        if (_engine.Current is not { } current || current.SessionId == _followedSession) return;

        _followedSession = current.SessionId;
        QueueList.SelectedItem = current;
    }

    private void RefreshEverything()
    {
        if (!_ready) return;

        bool haveKeys = _keys is not null;
        bool haveDest = ReceiverCombo.SelectedItem is not null;
        bool live = LiveModeOption.IsChecked == true;

        SetBadge(Step1Badge, haveKeys);
        SetBadge(Step2Badge, haveDest);
        SetBadge(Step3Badge, GatewayMode ? _outbox is not null : _source.IsRunning || _engine.Queue.Count > 0);
        SetBadge(Step4Badge, _engine.SentCount > 0);

        StageButton.IsEnabled = _engine.CanTransmit || (PairsOverTheLight && haveKeys);
        StageButton.Content = _stage is null ? "Open QR stage" : "Close QR stage";

        SourceRunButton.Content = _source.IsRunning ? "❙❙ Pause source" : "● Start source";
        SourceRunButton.Style = (Style)FindResource(_source.IsRunning ? "ChipButtonOn" : "ChipButton");
        SourceRunButton.IsEnabled = live && _engine.CanTransmit;
        SourceStopButton.IsEnabled = _source.IsRunning;
        InjectButton.IsEnabled = _engine.CanTransmit;

        // Identity and destination lock while the source runs — the counter and manifests are
        // already committed to this pair.
        bool locked = _source.IsRunning || _engine.State is StageState.OnAir or StageState.Encoding;
        bool namesKeys = _exchange?.UsesEndpointName != false;
        EndpointNameBox.IsEnabled = !locked && namesKeys;
        ReceiverCombo.IsEnabled = !locked;
        LiveModeOption.IsEnabled = !locked;
        ManualModeOption.IsEnabled = !locked;
        string lockHint = locked ? "Stop the source to change." : null!;
        EndpointNameBox.ToolTip = !namesKeys
            ? $"This machine's {_exchange!.Description}, from appsettings.json"
            : lockHint ?? "Name of this machine's key pair in Windows CNG";
        ReceiverCombo.ToolTip = lockHint;

        FollowOnAir();
        RefreshQueueChrome();
    }

    private void RefreshQueueChrome()
    {
        if (!_ready) return;
        QueueTallyText.Text =
            $"{_engine.QueuedCount} queued · {_engine.SentCount} sent" +
            (_engine.SkippedCount > 0 ? $" · {_engine.SkippedCount} skipped" : "");
        QueueEmpty.Visibility = _engine.Queue.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    /// <summary>Sparkline of emissions per bucket — plain Rectangles, redrawn on the source tick.</summary>
    private void DrawSparkline()
    {
        var hist = _source.Histogram;
        double width = Math.Max(60, Sparkline.ActualWidth);
        double slot = width / hist.Count;
        double barWidth = Math.Max(3, slot - 2);
        int peak = Math.Max(3, hist.Max());

        if (Sparkline.Children.Count != hist.Count)
        {
            Sparkline.Children.Clear();
            for (int i = 0; i < hist.Count; i++)
                Sparkline.Children.Add(new Rectangle { RadiusX = 1, RadiusY = 1 });
        }

        var idle = (Brush)FindResource("FieldBrush");
        var low = (Brush)FindResource("Accent600Brush");
        var high = (Brush)FindResource("Accent400Brush");

        for (int i = 0; i < hist.Count; i++)
        {
            var bar = (Rectangle)Sparkline.Children[i];
            double h = 4 + 42.0 * hist[i] / peak;
            bar.Width = barWidth;
            bar.Height = h;
            bar.Fill = hist[i] == 0 ? idle : hist[i] > peak / 2.0 ? high : low;
            Canvas.SetLeft(bar, i * slot);
            Canvas.SetTop(bar, 46 - h);
        }
    }

    // ═══════════════════ small helpers ═══════════════════

    private void Log(string message, string pillStyle, string glyph)
    {
        LogText.Text = message;
        SetPill(LogPill, LogPillText, glyph, pillStyle);
    }

    private void SetPill(Border pill, TextBlock text, string label, string styleKey)
    {
        text.Text = label;
        pill.Style = (Style)FindResource(styleKey);
    }

    private void SetBadge(Border badge, bool satisfied) =>
        badge.Background = (Brush)FindResource(satisfied ? "SuccessBrush" : "Accent500Brush");

    protected override async void OnClosed(EventArgs e)
    {
        _source.Stop();
        _stage?.Close();
        // A bundle still on screen stays Sending; the next start puts it back in the queue (ResetSendingAsync).
        if (_outbox is not null) await _outbox.DisposeAsync();
        if (_bridge is not null) await _bridge.DisposeAsync();
        StopPairing();
        _engine.Dispose();
        _keys?.Dispose();
        _trust?.Dispose();
        _retiredTrust?.Dispose();
        base.OnClosed(e);
    }
}
