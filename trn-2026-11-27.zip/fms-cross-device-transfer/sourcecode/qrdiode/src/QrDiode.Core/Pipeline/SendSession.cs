using System.IO.Compression;
using System.Security.Cryptography;
using QrDiode.Core.Crypto;
using QrDiode.Core.Fountain;
using QrDiode.Core.Framing;
using QrDiode.Core.Manifest;

namespace QrDiode.Core.Pipeline;

public sealed class SendOptions
{
    /// <summary>
    /// Max symbol payload bytes per frame. Frame = symbolSize + <see cref="FrameFormat.DataOverhead"/> (36) bytes;
    /// the renderer picks the smallest QR version that fits (1,386 bytes → version 27 at ECC L).
    /// </summary>
    public int MaxSymbolSize { get; init; } = 1350;
    /// <summary>Total data frames emitted per carousel loop, as a multiple of K.</summary>
    public ushort Redundancy { get; init; } = 3;
    /// <summary>A manifest frame is re-emitted every N frames so late joiners sync fast.</summary>
    public int ManifestInterval { get; init; } = 20;
}

/// <summary>
/// Sender-side pipeline for one transfer:
/// plaintext → Brotli (keep smaller) → ECDH+HKDF → AES-256-GCM → sign manifest → LT-encode → MAC'd frames.
/// </summary>
public sealed class SendSession
{
    private readonly LtEncoder _encoder;
    private readonly byte[] _sessionTag;
    private readonly byte[] _frameKey;
    private readonly int _symbolSize;
    private uint _nextCodedSymbolId;

    public TransferManifest Manifest { get; }
    public byte[] ManifestFrame { get; }
    public string ReceiptHash { get; }
    public int K => _encoder.K;
    public SendOptions Options { get; }

    private SendSession(TransferManifest manifest, byte[] manifestFrame, string receiptHash,
        LtEncoder encoder, int symbolSize, byte[] frameKey, SendOptions options)
    {
        Manifest = manifest;
        ManifestFrame = manifestFrame;
        ReceiptHash = receiptHash;
        _encoder = encoder;
        _symbolSize = symbolSize;
        _frameKey = frameKey;
        _sessionTag = manifest.SessionTag;
        _nextCodedSymbolId = (uint)encoder.K;
        Options = options;
    }

    /// <param name="counter">The value reserved from the sender's <see cref="CounterStore"/>.</param>
    /// <param name="counterRunId">The run that value belongs to (<see cref="CounterReservation.RunId"/>).</param>
    public static SendSession Create(
        byte[] plaintext,
        string filename,
        ContentKind contentType,
        IEndpointKeys senderKeys,
        PeerPublicKeys receiver,
        ulong counter,
        Guid counterRunId,
        SendOptions? options = null,
        TimeProvider? clock = null)
    {
        ArgumentNullException.ThrowIfNull(plaintext);
        if (plaintext.Length == 0) throw new ArgumentException("Payload must not be empty.", nameof(plaintext));
        if (plaintext.Length > TransferManifest.MaxPayloadBytes)
            throw new ArgumentException($"Payload is {plaintext.Length:N0} bytes; the limit is {TransferManifest.MaxPayloadBytes:N0}.", nameof(plaintext));
        options ??= new SendOptions();
        if (options.MaxSymbolSize < TransferManifest.MinSymbolSize || options.MaxSymbolSize > FrameFormat.MaxSymbolSize)
            throw new ArgumentOutOfRangeException(nameof(options),
                $"MaxSymbolSize must be {TransferManifest.MinSymbolSize}–{FrameFormat.MaxSymbolSize} bytes.");
        clock ??= TimeProvider.System;

        // Compress, keep the smaller representation.
        byte[] compressed = CompressBrotli(plaintext);
        CompressionAlg alg = CompressionAlg.Brotli;
        if (compressed.Length >= plaintext.Length)
        {
            compressed = plaintext;
            alg = CompressionAlg.None;
        }

        int ciphertextLength = compressed.Length + Envelope.TagSize;
        int symbolSize = Math.Min(options.MaxSymbolSize, ciphertextLength);
        int k = LtCode.SourceBlockCount(ciphertextLength, symbolSize);
        if (k > TransferManifest.MaxSourceSymbols)
            throw new ArgumentException($"{k:N0} source symbols exceed the limit of {TransferManifest.MaxSourceSymbols:N0}; raise MaxSymbolSize.", nameof(options));

        var sessionId = Guid.NewGuid();
        byte[] salt = RandomNumberGenerator.GetBytes(Envelope.SaltSize);
        byte[] nonce = RandomNumberGenerator.GetBytes(Envelope.NonceSize);
        ulong ltSeed = BitConverter.ToUInt64(RandomNumberGenerator.GetBytes(8));

        byte[] aad = Envelope.BuildAad(sessionId, salt, counter, counterRunId, senderKeys.SigningKeyId, receiver.AgreementKeyId);
        var keys = Envelope.DeriveSessionKeys(senderKeys.AgreementKey, receiver.AgreementPublicKey.PublicKey, salt, sessionId);
        byte[] ciphertext;
        try
        {
            ciphertext = Envelope.Seal(compressed, keys.PayloadKey, nonce, aad);
        }
        finally
        {
            // The frame key lives as long as the carousel; the payload key is done.
            CryptographicOperations.ZeroMemory(keys.PayloadKey);
        }

        var manifest = new TransferManifest
        {
            SessionId = sessionId,
            TimestampUnixMs = clock.GetUtcNow().ToUnixTimeMilliseconds(),
            Counter = counter,
            CounterRunId = counterRunId,
            SenderSigningKeyId = senderKeys.SigningKeyId,
            ReceiverAgreementKeyId = receiver.AgreementKeyId,
            Salt = salt,
            Nonce = nonce,
            SymbolSize = checked((ushort)symbolSize),
            SourceSymbolCount = (uint)k,
            LtSeed = ltSeed,
            RedundancyHint = options.Redundancy,
            OriginalSize = plaintext.Length,
            CompressedSize = compressed.Length,
            CiphertextSize = ciphertext.Length,
            Compression = alg,
            CiphertextSha256 = SHA256.HashData(ciphertext),
            ContentType = contentType,
            Filename = filename,
        };

        byte[] body = manifest.Serialize();
        byte[] signature = manifest.Sign(senderKeys.SigningKey, body);
        byte[] manifestFrame = FrameWriter.WriteManifestFrame(manifest.SessionTag, body, signature);
        string receipt = TransferManifest.ReceiptHash(body, signature);

        var encoder = new LtEncoder(ciphertext, symbolSize, ltSeed);
        return new SendSession(manifest, manifestFrame, receipt, encoder, symbolSize, keys.FrameKey, options);
    }

    /// <summary>Builds the wire frame for one data symbol.</summary>
    public byte[] GetDataFrame(uint symbolId)
    {
        var payload = new byte[_symbolSize];
        _encoder.GenerateSymbol(symbolId, payload);
        return FrameWriter.WriteDataFrame(_sessionTag, symbolId, payload, _frameKey);
    }

    /// <summary>
    /// Infinite carousel: manifest first, then re-emitted every ManifestInterval frames.
    /// Each loop = systematic pass (0..K-1) + (Redundancy-1)×K fresh coded symbols;
    /// coded symbolIds keep increasing across loops so every loop adds new information.
    /// </summary>
    public IEnumerable<byte[]> Carousel()
    {
        while (true)
        {
            int emittedSinceManifest = int.MaxValue; // force manifest as very first frame
            long framesThisLoop = (long)K * Options.Redundancy;

            for (long i = 0; i < framesThisLoop; i++)
            {
                if (emittedSinceManifest >= Options.ManifestInterval)
                {
                    yield return ManifestFrame;
                    emittedSinceManifest = 0;
                }

                uint symbolId = i < K ? (uint)i : NextCodedId();
                yield return GetDataFrame(symbolId);
                emittedSinceManifest++;
            }
        }
    }

    private uint NextCodedId()
    {
        uint id = _nextCodedSymbolId++;
        if (_nextCodedSymbolId < (uint)K) // wrapped around the 32-bit space
            _nextCodedSymbolId = (uint)K;
        return id;
    }

    internal static byte[] CompressBrotli(byte[] data)
    {
        // Max quality pays off on small transactional payloads; on multi-MB files it costs
        // minutes of CPU for little gain over Optimal, so scale the effort down.
        var level = data.Length <= 4 * 1024 * 1024 ? CompressionLevel.SmallestSize : CompressionLevel.Optimal;
        using var output = new MemoryStream();
        using (var brotli = new BrotliStream(output, level, leaveOpen: true))
            brotli.Write(data);
        return output.ToArray();
    }
}
