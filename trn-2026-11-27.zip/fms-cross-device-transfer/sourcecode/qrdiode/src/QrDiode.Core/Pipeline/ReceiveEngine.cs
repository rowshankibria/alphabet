using System.IO.Compression;
using System.Security.Cryptography;
using QrDiode.Core.Crypto;
using QrDiode.Core.Fountain;
using QrDiode.Core.Framing;
using QrDiode.Core.Manifest;

namespace QrDiode.Core.Pipeline;

public enum FeedResult
{
    /// <summary>Not a valid frame, wrong session, or already-seen symbol. Safe to ignore.</summary>
    Ignored = 0,
    ManifestAccepted,
    SymbolAccepted,
    Completed,
    /// <summary>Frame or manifest actively rejected by a security check. See LastRejection.</summary>
    Rejected,
    /// <summary>
    /// A pairing frame passed the key exchange's checks (<see cref="ReceiveEngine.LastPairedPeer"/>). The host pins the
    /// peer and reloads its trust store; the engine itself trusts nothing new until then.
    /// </summary>
    PeerAccepted,
}

public sealed class CompletedTransfer
{
    public required TransferManifest Manifest { get; init; }
    public required byte[] Plaintext { get; init; }

    /// <summary>
    /// SHA-256 of <see cref="Plaintext"/>, computed here. Since protocol v2 the manifest no longer
    /// carries it (it would be readable on the screen); the bytes are proven by the signed ciphertext
    /// hash and the GCM tag.
    /// </summary>
    public required byte[] PlaintextSha256 { get; init; }

    public required string ReceiptHash { get; init; }
}

/// <summary>
/// Everything the UI needs to render one rejection as an inbox entry. The manifest is present only
/// for rejections that happened after the signature verified — before that there is nothing the
/// receiver is entitled to believe about the frame.
/// </summary>
public sealed record RejectionInfo(string Reason, TransferManifest? Manifest);

/// <summary>
/// A session the engine gave up because a newer, fully verified session started before it completed
/// (the camera missed part of it and the sender moved on). It was NOT received and must be re-sent.
/// </summary>
public sealed record AbandonedSession(
    Guid SessionId,
    string Filename,
    ContentKind ContentType,
    long OriginalSize,
    byte[] SenderSigningKeyId,
    ulong Counter,
    int K,
    int DecodedSourceCount,
    int UniqueSymbolsReceived);

/// <summary>Receiver behaviour that differs between deployments.</summary>
public sealed record ReceiveOptions
{
    /// <summary>
    /// Accept payloads of kind File (bytes the content gate cannot check). True for the standalone
    /// file transfer; a transaction-only deployment turns it off.
    /// </summary>
    public bool AllowOpaqueFiles { get; init; } = true;

    /// <summary>
    /// When <see cref="AllowOpaqueFiles"/> is false: a File whose name ends with one of these is still accepted (the
    /// host checks its content, e.g. the Receiver parses a gateway bundle, ".qbb"). Everything else of kind File is refused.
    /// </summary>
    public IReadOnlyList<string> AllowedFileSuffixes { get; init; } = [];

    /// <summary>How many settled session ids the engine remembers (oldest forgotten first; the replay guard still has them).</summary>
    public int MaxSettledSessions { get; init; } = 4096;

    /// <summary>
    /// The key exchange's judge for pairing frames over the light (<see cref="IKeyExchange.CreatePairingVerifier"/>). Null
    /// (the key ceremony, and the default): pairing frames are ignored and only the trust store decides.
    /// </summary>
    public IPairingVerifier? Pairing { get; init; }
}

/// <summary>
/// Receiver-side engine. Feed raw QR payloads; the engine enforces the verification chain in
/// strict order and fails closed at every step:
/// CRC → manifest signature → addressed to us → anti-replay → frame MAC (every data frame) → LT decode
/// → ciphertext hash → AES-GCM → decompression cap → content gate.
///
/// The replay guard is NOT updated when a transfer completes: the host stores the payload first and
/// then calls <see cref="CommitReplay"/>, so a crash in between leaves the session receivable.
///
/// Pairing (<see cref="ReceiveOptions.Pairing"/>, e.g. certificate mode): a pairing frame is verified only while no
/// session is in flight, and an accepted one is only reported (<see cref="FeedResult.PeerAccepted"/>): the host pins it
/// and swaps the trust store; until then the engine trusts nothing new.
/// </summary>
public sealed class ReceiveEngine
{
    private readonly ITrustStore _trust;
    private readonly IReplayGuard _replayGuard;
    private readonly IEndpointKeys _receiverKeys;
    private readonly ReceiveOptions _options;
    private readonly object _lock = new();

    /// <summary>
    /// Sessions this engine already reached a verdict on. The carousel keeps re-emitting a session's
    /// manifest for the rest of its air-time, so without this the receiver would re-verdict the same
    /// session every loop. Entries are only added once the manifest's signature has verified, so a
    /// forged frame can never suppress a legitimate session by squatting its id. Capped at
    /// <see cref="ReceiveOptions.MaxSettledSessions"/>: the oldest is forgotten first.
    /// </summary>
    private readonly HashSet<Guid> _settled = [];
    private readonly Queue<Guid> _settledOrder = new();

    /// <summary>
    /// Pairing frames already judged (SHA-256 of the frame): the Sender shows the same one for a minute, the camera reads
    /// it 30 times a second, and a certificate chain is worth building once. Capped; oldest forgotten first.
    /// </summary>
    private readonly HashSet<string> _seenHellos = [];
    private readonly Queue<string> _seenHelloOrder = new();
    private const int MaxSeenHellos = 64;

    /// <summary>Peers (identity and encryption key) accepted in this run: a fresh timestamp of one is not news.</summary>
    private readonly HashSet<string> _acceptedPeers = [];

    private TransferManifest? _manifest;
    private byte[]? _manifestBody;
    private byte[]? _manifestSignature;
    private byte[] _sessionTag = Array.Empty<byte>();
    private SessionKeys? _keys;
    private LtDecoder? _decoder;
    private CompletedTransfer? _completed;

    public string LastRejection { get; private set; } = "";
    public RejectionInfo? LastRejectionInfo { get; private set; }

    /// <summary>The peer of the last <see cref="FeedResult.PeerAccepted"/>. Read it on the thread that called <see cref="Feed"/>.</summary>
    public VerifiedPeer? LastPairedPeer { get; private set; }
    public TransferManifest? ActiveManifest => _manifest;
    public CompletedTransfer? Completed => _completed;
    public int DecodedSourceCount => _decoder?.DecodedSourceCount ?? 0;
    public int K => _decoder?.K ?? 0;
    public int UniqueSymbolsReceived => _decoder?.UniqueSymbolsReceived ?? 0;
    public double Progress => _decoder is { K: > 0 } d ? (double)d.DecodedSourceCount / d.K : 0;

    /// <summary>Data frames with the right session tag but a wrong MAC: someone else's QR codes in view.</summary>
    public long FramesFailedAuthentication { get; private set; }

    /// <summary>
    /// Raised (outside the engine's lock, on the thread that called <see cref="Feed"/>) when a partly
    /// received session is given up for a newer verified one. The engine is already on the new session:
    /// handlers must not call <see cref="Reset"/>.
    /// </summary>
    public event Action<AbandonedSession>? SessionAbandoned;

    public ReceiveEngine(ITrustStore trust, IReplayGuard replayGuard, IEndpointKeys receiverKeys, ReceiveOptions? options = null)
    {
        _trust = trust;
        _replayGuard = replayGuard;
        _receiverKeys = receiverKeys;
        _options = options ?? new ReceiveOptions();
    }

    /// <summary>
    /// Clears the in-flight session so the next manifest on the wire can be picked up. Call after
    /// handling <see cref="FeedResult.Completed"/> — never after a rejection: the engine clears its own
    /// state when it rejects, and a late reset could drop a session it has locked onto since.
    /// </summary>
    /// <param name="settle">
    /// True (default): remember the session, so the tail of its carousel is ignored rather than re-judged.
    /// False: forget it, so the carousel still on air can deliver it again (the host could not store it).
    /// </param>
    public void Reset(bool settle = true)
    {
        lock (_lock)
        {
            if (_manifest is not null && settle) Settle(_manifest.SessionId);
            ClearSession();
            _completed = null;
        }
    }

    /// <summary>
    /// Records the completed transfer in the replay guard. The host calls this once the payload is
    /// durably stored (or recorded as a duplicate), and only then: a crash before it leaves the session
    /// receivable, at worst as a duplicate.
    /// </summary>
    public void CommitReplay()
    {
        lock (_lock)
        {
            var manifest = _completed?.Manifest ?? throw new InvalidOperationException("No completed transfer to commit.");
            _replayGuard.Commit(manifest.SenderSigningKeyId, manifest.SessionId, manifest.CounterRunId, manifest.Counter);
        }
    }

    /// <summary>Feeds the raw byte payload of one decoded QR code.</summary>
    public FeedResult Feed(ReadOnlySpan<byte> qrPayload)
    {
        FeedResult result;
        AbandonedSession? abandoned = null;
        lock (_lock)
        {
            if (_completed is not null) return FeedResult.Ignored;

            if (!FrameParser.TryParse(qrPayload, out var frame, out _))
                return FeedResult.Ignored; // noise, misdecode, or tamper — CRC/structure said no

            result = frame.Type switch
            {
                FrameType.Manifest => FeedManifest(frame, out abandoned),
                FrameType.DataSymbol => FeedSymbol(frame),
                FrameType.CertHello => FeedPairing(qrPayload, frame.Type),
                _ => FeedResult.Ignored,
            };
        }

        // Outside the lock: a handler can never deadlock or re-enter the engine under it.
        if (abandoned is not null) SessionAbandoned?.Invoke(abandoned);
        return result;
    }

    private FeedResult FeedManifest(ParsedFrame frame, out AbandonedSession? abandoned)
    {
        abandoned = null;
        bool locked = _manifest is not null;

        // Repeats of the session in progress: the carousel shows its manifest all the time.
        if (locked && frame.SessionTag.SequenceEqual(_sessionTag))
            return FeedResult.Ignored;

        // While locked, a different manifest that fails any check is Ignored, not Rejected: nothing an
        // unverified (or replayed) frame says may disturb the session in progress.

        // 1. Structural parse (no trust yet).
        if (!TransferManifest.TryParse(frame.Payload, out var candidate, out string parseError))
            return locked ? FeedResult.Ignored : Reject($"Manifest parse: {parseError}");

        // 2. Signature: the sender must be in the trust store, and the signature must verify
        //    over the exact received body bytes. Nothing downstream runs on failure.
        var peer = _trust.FindBySigningKeyId(candidate!.SenderSigningKeyId);
        if (peer is null)
            return locked ? FeedResult.Ignored : Reject($"Unknown sender key {KeyId.ToHex(candidate.SenderSigningKeyId)}");
        if (!TransferManifest.VerifySignature(peer.SigningPublicKey, frame.Payload, frame.Signature))
            return locked ? FeedResult.Ignored : Reject("Manifest signature verification failed");

        // 3. This transfer must be addressed to us.
        if (!candidate.ReceiverAgreementKeyId.AsSpan().SequenceEqual(_receiverKeys.AgreementKeyId))
            return locked ? FeedResult.Ignored : Reject("Manifest addressed to a different receiver key");

        // The signature has verified, so the session id is now something we may act on: if we have
        // already ruled on this session, the carousel is simply still playing it. Not a new event.
        if (_settled.Contains(candidate.SessionId))
            return FeedResult.Ignored;

        // 4. Anti-replay.
        var verdict = _replayGuard.Check(candidate.SenderSigningKeyId, candidate.SessionId, candidate.CounterRunId,
            candidate.Counter, candidate.TimestampUnixMs);
        if (verdict != ReplayVerdict.Fresh)
        {
            Settle(candidate.SessionId);
            return locked ? FeedResult.Ignored : Reject($"Replay check failed: {verdict}", candidate);
        }

        // 5. The session keys: the frame key authenticates every data frame from here on.
        SessionKeys keys;
        try
        {
            keys = Envelope.DeriveSessionKeys(_receiverKeys.AgreementKey, peer.AgreementPublicKey.PublicKey,
                candidate.Salt, candidate.SessionId);
        }
        catch (CryptographicException)
        {
            return locked ? FeedResult.Ignored : Reject("Key agreement failed", candidate);
        }

        // A newer verified session while locked: the sender moved on, so the partial one is lost.
        if (locked) abandoned = AbandonCurrent();

        _manifest = candidate;
        _manifestBody = frame.Payload.ToArray();
        _manifestSignature = frame.Signature.ToArray();
        _sessionTag = candidate.SessionTag;
        _keys = keys;
        _decoder = new LtDecoder(candidate.CiphertextSize, candidate.SymbolSize, candidate.LtSeed);
        return FeedResult.ManifestAccepted;
    }

    /// <summary>
    /// Pairing over the light. Never while a session is in flight: pairing must not disturb a transfer (and the Sender
    /// shows its pairing frame only when it has nothing to send). Each distinct frame is judged once.
    /// </summary>
    private FeedResult FeedPairing(ReadOnlySpan<byte> frame, FrameType type)
    {
        if (_options.Pairing is not { } verifier || verifier.FrameType != type) return FeedResult.Ignored;
        if (_manifest is not null) return FeedResult.Ignored;

        string digest = Convert.ToHexString(SHA256.HashData(frame));
        if (!_seenHellos.Add(digest)) return FeedResult.Ignored;
        _seenHelloOrder.Enqueue(digest);
        if (_seenHelloOrder.Count > MaxSeenHellos) _seenHellos.Remove(_seenHelloOrder.Dequeue());

        if (!verifier.TryVerify(frame, out var peer, out string reason))
            return Reject($"Pairing refused: {reason}");
        if (!_acceptedPeers.Add($"{peer!.Identity}:{KeyId.ToHex(peer.AgreementKeyId)}"))
            return FeedResult.Ignored;

        LastPairedPeer = peer;
        return FeedResult.PeerAccepted;
    }

    /// <summary>The host could not pin the last accepted peer: offer it again on its next pairing frame.</summary>
    public void ForgetAcceptedPeers()
    {
        lock (_lock)
        {
            _acceptedPeers.Clear();
            _seenHellos.Clear();
            _seenHelloOrder.Clear();
        }
    }

    private AbandonedSession AbandonCurrent()
    {
        var manifest = _manifest!;
        var info = new AbandonedSession(manifest.SessionId, manifest.Filename, manifest.ContentType, manifest.OriginalSize,
            manifest.SenderSigningKeyId, manifest.Counter,
            _decoder?.K ?? 0, _decoder?.DecodedSourceCount ?? 0, _decoder?.UniqueSymbolsReceived ?? 0);
        Settle(manifest.SessionId);
        ClearSession();
        return info;
    }

    private FeedResult FeedSymbol(ParsedFrame frame)
    {
        // No verified manifest yet → we do not touch payload bytes at all. The carousel
        // re-emits everything, so dropping here costs time, never data.
        if (_manifest is null || _decoder is null || _keys is null)
            return FeedResult.Ignored;

        if (!frame.SessionTag.SequenceEqual(_sessionTag))
            return FeedResult.Ignored;
        if (frame.Payload.Length != _manifest.SymbolSize)
            return FeedResult.Ignored;

        // The session tag is on the screen for anyone to copy; the MAC is not. A frame that fails it
        // never reaches the decoder, so it cannot poison the session.
        if (!FrameMac.Verify(_keys.FrameKey, frame.MacCovered, frame.Mac))
        {
            FramesFailedAuthentication++;
            return FeedResult.Ignored;
        }

        bool advanced = _decoder.AddSymbol(frame.SymbolId, frame.Payload);
        if (!_decoder.IsComplete)
            return advanced ? FeedResult.SymbolAccepted : FeedResult.Ignored;

        return FinishTransfer();
    }

    private FeedResult FinishTransfer()
    {
        var manifest = _manifest!;
        byte[] ciphertext = _decoder!.Assemble();

        // 6. Ciphertext hash must match the signed manifest before we spend crypto on it.
        if (!SHA256.HashData(ciphertext).AsSpan().SequenceEqual(manifest.CiphertextSha256))
            return RejectAndReset("Ciphertext hash mismatch after decode");

        // 7. AES-GCM open with AAD rebuilt from the signed manifest.
        byte[] aad = Envelope.BuildAad(manifest.SessionId, manifest.Salt, manifest.Counter, manifest.CounterRunId,
            manifest.SenderSigningKeyId, manifest.ReceiverAgreementKeyId);

        byte[] compressed;
        try
        {
            compressed = Envelope.Open(ciphertext, _keys!.PayloadKey, manifest.Nonce, aad);
        }
        catch (CryptographicException)
        {
            return RejectAndReset("AES-GCM authentication failed");
        }

        // 8. Decompress with a hard output cap (zip-bomb guard).
        byte[] plaintext;
        if (manifest.Compression == CompressionAlg.Brotli)
        {
            if (!TryDecompressBrotli(compressed, manifest.OriginalSize, out plaintext))
                return RejectAndReset("Decompression failed or exceeded declared size");
        }
        else
        {
            plaintext = compressed;
        }

        if (plaintext.LongLength != manifest.OriginalSize)
            return RejectAndReset("Plaintext size mismatch");

        // 9. Content gate.
        if (manifest.ContentType == ContentKind.File && !_options.AllowOpaqueFiles &&
            !_options.AllowedFileSuffixes.Any(s => manifest.Filename.EndsWith(s, StringComparison.OrdinalIgnoreCase)))
            return RejectAndReset("Content gate: files of kind File are not accepted by this receiver");
        if (!ContentGate.Validate(manifest.ContentType, plaintext, out string gateError))
            return RejectAndReset($"Content gate: {gateError}");

        _completed = new CompletedTransfer
        {
            Manifest = manifest,
            Plaintext = plaintext,
            PlaintextSha256 = SHA256.HashData(plaintext),
            ReceiptHash = TransferManifest.ReceiptHash(_manifestBody!, _manifestSignature!),
        };
        ClearKeys(); // the session is decoded; its keys have no further use
        return FeedResult.Completed;
    }

    private static bool TryDecompressBrotli(byte[] compressed, long declaredSize, out byte[] plaintext)
    {
        plaintext = Array.Empty<byte>();
        try
        {
            var output = new byte[declaredSize];
            using var input = new MemoryStream(compressed, writable: false);
            using var brotli = new BrotliStream(input, CompressionMode.Decompress);

            int total = 0;
            while (total < output.Length)
            {
                int read = brotli.Read(output, total, output.Length - total);
                if (read == 0) return false; // stream ended short of the declared size
                total += read;
            }
            // Anything beyond the declared size means the stream lies — fail closed.
            if (brotli.ReadByte() != -1) return false;
            plaintext = output;
            return true;
        }
        catch (Exception ex) when (ex is InvalidDataException or IOException)
        {
            return false;
        }
    }

    private FeedResult Reject(string reason, TransferManifest? manifest = null)
    {
        LastRejection = reason;
        LastRejectionInfo = new RejectionInfo(reason, manifest);
        return FeedResult.Rejected;
    }

    /// <summary>A post-decode failure poisons the whole session — reset so a re-send can start clean.</summary>
    private FeedResult RejectAndReset(string reason)
    {
        LastRejection = reason;
        LastRejectionInfo = new RejectionInfo(reason, _manifest);
        if (_manifest is not null) Settle(_manifest.SessionId);
        ClearSession();
        return FeedResult.Rejected;
    }

    private void Settle(Guid sessionId)
    {
        if (!_settled.Add(sessionId)) return;
        _settledOrder.Enqueue(sessionId);
        while (_settledOrder.Count > Math.Max(1, _options.MaxSettledSessions))
            _settled.Remove(_settledOrder.Dequeue());
    }

    private void ClearSession()
    {
        _manifest = null;
        _manifestBody = null;
        _manifestSignature = null;
        _decoder = null;
        _sessionTag = Array.Empty<byte>();
        ClearKeys();
    }

    private void ClearKeys()
    {
        _keys?.Clear();
        _keys = null;
    }
}
