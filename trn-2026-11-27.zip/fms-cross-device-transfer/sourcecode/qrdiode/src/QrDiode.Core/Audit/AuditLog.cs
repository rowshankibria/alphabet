using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace QrDiode.Core.Audit;

/// <summary>Result of checking a whole audit chain (archived files first, then the current one).</summary>
public sealed record AuditVerification(int Files, long Records, long FirstBrokenIndex, string? BrokenFile, long BrokenLine, string? Problem)
{
    public bool Intact => FirstBrokenIndex < 0;
}

/// <summary>
/// Append-only, hash-chained audit log (JSONL). Each record embeds the SHA-256 of the previous
/// record's serialized bytes, so any edit or deletion breaks the chain from that point on.
///
/// The current file rolls over at <see cref="DefaultMaxFileBytes"/>: it is renamed to
/// <c>name.yyyyMMdd-HHmmssfff.jsonl</c> and a new file starts, its first record chained to the last
/// one of the archive. Start-up reads only the end of the file, so a kiosk that has run for months
/// still starts at once. The chain has no key: it shows edits, it cannot stop someone who rewrites
/// the whole file — protect the folder with ACLs.
/// </summary>
public sealed class AuditLog
{
    /// <summary>32 MB per file: tens of thousands of records, still quick to verify.</summary>
    public const long DefaultMaxFileBytes = 32L * 1024 * 1024;

    private readonly string _path;
    private readonly TimeProvider _clock;
    private readonly long _maxFileBytes;
    private readonly object _lock = new();
    private string _prevHash;
    private bool _startOnNewLine;

    public AuditLog(string path, TimeProvider? clock = null, long maxFileBytes = DefaultMaxFileBytes)
    {
        _path = path;
        _clock = clock ?? TimeProvider.System;
        _maxFileBytes = maxFileBytes;
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        _prevHash = ReadLastHash(path);
        _startOnNewLine = EndsMidLine(path);
    }

    public void Append(string eventType, IReadOnlyDictionary<string, string> data)
    {
        lock (_lock)
        {
            RollOverIfFull();

            var record = new Dictionary<string, object>
            {
                ["ts"] = _clock.GetUtcNow().ToString("O"),
                ["event"] = eventType,
                ["data"] = data,
                ["prev"] = _prevHash,
            };
            string json = JsonSerializer.Serialize(record);
            string hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(json)));
            string line = JsonSerializer.Serialize(new Dictionary<string, object>
            {
                ["ts"] = record["ts"],
                ["event"] = eventType,
                ["data"] = data,
                ["prev"] = _prevHash,
                ["hash"] = hash,
            });

            using var stream = new FileStream(_path, FileMode.Append, FileAccess.Write, FileShare.Read);
            using var writer = new StreamWriter(stream, new UTF8Encoding(false));
            // After a torn write the file ends mid-line: start a fresh line so this record stays whole.
            if (_startOnNewLine) writer.WriteLine();
            writer.WriteLine(line);
            writer.Flush();
            stream.Flush(flushToDisk: true);

            _prevHash = hash;
            _startOnNewLine = false;
        }
    }

    private static bool EndsMidLine(string path)
    {
        if (!File.Exists(path)) return false;
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        if (stream.Length == 0) return false;
        stream.Seek(-1, SeekOrigin.End);
        return stream.ReadByte() != '\n';
    }

    private void RollOverIfFull()
    {
        var info = new FileInfo(_path);
        if (!info.Exists || info.Length < _maxFileBytes) return;

        string stamp = _clock.GetUtcNow().UtcDateTime.ToString("yyyyMMdd-HHmmssfff");
        string archive = Path.Combine(info.DirectoryName!, $"{Path.GetFileNameWithoutExtension(_path)}.{stamp}{Path.GetExtension(_path)}");
        for (int i = 1; File.Exists(archive); i++)
            archive = Path.Combine(info.DirectoryName!, $"{Path.GetFileNameWithoutExtension(_path)}.{stamp}-{i}{Path.GetExtension(_path)}");
        File.Move(_path, archive); // the chain continues: _prevHash is still the archive's last hash
        _startOnNewLine = false;
    }

    /// <summary>Verifies the whole chain. Returns the index of the first broken record, or -1 if intact.</summary>
    public static long Verify(string path) => VerifyChain(path).FirstBrokenIndex;

    /// <summary>Checks the archived files (oldest first) and then the current file as one chain.</summary>
    public static AuditVerification VerifyChain(string path)
    {
        var files = ArchivesOf(path).ToList();
        if (File.Exists(path)) files.Add(path);

        string prev = "";
        long index = 0;
        foreach (var file in files)
        {
            long line = 0;
            foreach (var text in File.ReadLines(file))
            {
                line++;
                if (string.IsNullOrWhiteSpace(text)) continue;
                string? problem = CheckRecord(text, prev, out string hash);
                if (problem is not null)
                    return new AuditVerification(files.Count, index, index, file, line, problem);
                prev = hash;
                index++;
            }
        }
        return new AuditVerification(files.Count, index, -1, null, 0, null);
    }

    /// <summary>Null when the record is intact and chained to <paramref name="prev"/>; otherwise what is wrong.</summary>
    private static string? CheckRecord(string line, string prev, out string hash)
    {
        hash = "";
        try
        {
            using var doc = JsonDocument.Parse(line);
            var root = doc.RootElement;
            string recordedPrev = root.GetProperty("prev").GetString() ?? "";
            string recordedHash = root.GetProperty("hash").GetString() ?? "";
            if (recordedPrev != prev) return "the record does not follow the one before it (a record was removed or reordered)";

            // Recompute hash over the record without its own hash member.
            var replica = new Dictionary<string, object?>
            {
                ["ts"] = root.GetProperty("ts").GetString(),
                ["event"] = root.GetProperty("event").GetString(),
                ["data"] = JsonSerializer.Deserialize<Dictionary<string, string>>(root.GetProperty("data").GetRawText()),
                ["prev"] = recordedPrev,
            };
            string json = JsonSerializer.Serialize(replica);
            hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(json)));
            return hash == recordedHash ? null : "the record was changed after it was written";
        }
        catch (Exception ex) when (ex is JsonException or KeyNotFoundException or InvalidOperationException)
        {
            return "the line is not a readable record (a torn write, or an edit)";
        }
    }

    /// <summary>Archived files of this log, oldest first (their names sort by time).</summary>
    private static IEnumerable<string> ArchivesOf(string path)
    {
        string? folder = Path.GetDirectoryName(Path.GetFullPath(path));
        if (folder is null || !Directory.Exists(folder)) return [];
        var pattern = new Regex("^" + Regex.Escape(Path.GetFileNameWithoutExtension(path)) + @"\.\d{8}-\d{9}(-\d+)?" +
                                Regex.Escape(Path.GetExtension(path)) + "$", RegexOptions.IgnoreCase);
        return Directory.EnumerateFiles(folder)
            .Where(f => pattern.IsMatch(Path.GetFileName(f)))
            .Order(StringComparer.OrdinalIgnoreCase);
    }

    /// <summary>The last intact record's hash: from the current file, else from the newest archive.</summary>
    private static string ReadLastHash(string path)
    {
        if (TailHash(path) is { } hash) return hash;
        string? newestArchive = ArchivesOf(path).LastOrDefault();
        return newestArchive is not null ? TailHash(newestArchive) ?? "" : "";
    }

    /// <summary>
    /// Reads backwards from the end of the file to the last record that parses. A torn final line
    /// from a crash mid-write is skipped: the chain continues from the last intact record.
    /// </summary>
    private static string? TailHash(string path)
    {
        if (!File.Exists(path)) return null;
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        if (stream.Length == 0) return null;

        for (long window = 64 * 1024; ; window *= 4)
        {
            long start = Math.Max(0, stream.Length - window);
            var buffer = new byte[stream.Length - start];
            stream.Seek(start, SeekOrigin.Begin);
            stream.ReadExactly(buffer);
            string[] lines = Encoding.UTF8.GetString(buffer).Split('\n');

            // The first line of a window that does not start at 0 may be cut in half: never trust it.
            for (int i = lines.Length - 1; i >= (start > 0 ? 1 : 0); i--)
            {
                if (string.IsNullOrWhiteSpace(lines[i])) continue;
                try
                {
                    using var doc = JsonDocument.Parse(lines[i]);
                    if (doc.RootElement.TryGetProperty("hash", out var hash) && hash.GetString() is { } value)
                        return value;
                }
                catch (JsonException)
                {
                    // torn or foreign line: keep looking further back
                }
            }
            if (start == 0) return null;
        }
    }
}
