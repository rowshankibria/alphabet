using System.Security.Cryptography.X509Certificates;

namespace QrDiode.Core;

/// <summary>
/// The "Certificate" section of the machine's key exchange file (<see cref="KeyExchangeSettings"/>), used when its
/// "KeyExchange" is <see cref="KeyExchangeKind.Certificate"/>: this machine's identity is its CA-issued certificate in the
/// Windows Certificate Store, and the two sides pair over the cameras with a CertHello QR code
/// (docs/x509-certificate-handshake-plan.md). With the key ceremony the section must be empty.
/// </summary>
public sealed class CertificateOptions
{
    public const string SectionName = "Certificate";

    /// <summary>The store holding this machine's certificate: "Cert:\LocalMachine\My" or "Cert:\CurrentUser\My".</summary>
    public string Location { get; set; } = "";

    /// <summary>This machine's certificate by subject (CN or SAN DNS name) …</summary>
    public string OwnSubject { get; set; } = "";

    /// <summary>… or by thumbprint (SHA-1, 40 hex digits). Wins over <see cref="OwnSubject"/> when both are set.</summary>
    public string OwnThumbprint { get; set; } = "";

    /// <summary>The company Root or Issuing CA every peer certificate must chain to (in the Root or CA store of this machine).</summary>
    public string TrustedCaThumbprint { get; set; } = "";

    /// <summary>The one peer this lane pairs with (CN or SAN DNS name). Another certificate from the same CA is refused.</summary>
    public string ExpectedPeerSubject { get; set; } = "";

    /// <summary>Optional: also pin the peer's exact certificate (SHA-1 or SHA-256 thumbprint).</summary>
    public string ExpectedPeerThumbprint { get; set; } = "";

    /// <summary>Receiver: forget the pinned peer at every start, so the two sides pair again over the cameras.</summary>
    public bool RequireHandshakeOnStart { get; set; }

    /// <summary>Nothing set: what a machine using another key exchange must have.</summary>
    public bool IsEmpty =>
        string.IsNullOrWhiteSpace(Location) && string.IsNullOrWhiteSpace(OwnSubject) && string.IsNullOrWhiteSpace(OwnThumbprint) &&
        string.IsNullOrWhiteSpace(TrustedCaThumbprint) && string.IsNullOrWhiteSpace(ExpectedPeerSubject) &&
        string.IsNullOrWhiteSpace(ExpectedPeerThumbprint) && !RequireHandshakeOnStart;

    /// <summary>What keeps these settings from being used for certificate mode, in plain words; null when they can be.</summary>
    public string? Problem()
    {
        if (string.IsNullOrWhiteSpace(Location))
            return "Certificate:Location must name the store with this machine's certificate: \"Cert:\\\\LocalMachine\\\\My\" or \"Cert:\\\\CurrentUser\\\\My\".";
        if (!TryParseLocation(Location, out _, out _))
            return $"Certificate:Location \"{Location}\" is not a certificate store. Use \"Cert:\\\\LocalMachine\\\\My\" or \"Cert:\\\\CurrentUser\\\\My\".";
        if (string.IsNullOrWhiteSpace(OwnSubject) && string.IsNullOrWhiteSpace(OwnThumbprint))
            return "Certificate:OwnSubject or Certificate:OwnThumbprint must name this machine's certificate.";
        if (!string.IsNullOrWhiteSpace(OwnThumbprint) && !IsThumbprint(OwnThumbprint, sha256Allowed: false))
            return "Certificate:OwnThumbprint must be a SHA-1 thumbprint (40 hex digits).";
        if (!IsThumbprint(TrustedCaThumbprint, sha256Allowed: false))
            return "Certificate:TrustedCaThumbprint must be the SHA-1 thumbprint (40 hex digits) of the company Root or Issuing CA.";
        if (string.IsNullOrWhiteSpace(ExpectedPeerSubject))
            return "Certificate:ExpectedPeerSubject must name the other side's certificate (CN or DNS name).";
        if (!string.IsNullOrWhiteSpace(ExpectedPeerThumbprint) && !IsThumbprint(ExpectedPeerThumbprint, sha256Allowed: true))
            return "Certificate:ExpectedPeerThumbprint must be a SHA-1 (40) or SHA-256 (64) hex thumbprint.";
        return null;
    }

    /// <summary>"Cert:\LocalMachine\My", "LocalMachine\My", "CurrentUser\My" (any case) → the store to open.</summary>
    public static bool TryParseLocation(string location, out StoreLocation storeLocation, out StoreName storeName)
    {
        storeLocation = default;
        storeName = default;
        string path = location.Trim().TrimEnd('\\', '/');
        if (path.StartsWith("Cert:", StringComparison.OrdinalIgnoreCase)) path = path[5..];
        var parts = path.Split(['\\', '/'], StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length != 2) return false;
        if (!Enum.TryParse(parts[0], ignoreCase: true, out storeLocation) || !Enum.IsDefined(storeLocation)) return false;
        // Only the stores that hold a machine's own certificates: "My" (Personal).
        if (!parts[1].Equals("My", StringComparison.OrdinalIgnoreCase)) return false;
        storeName = StoreName.My;
        return true;
    }

    /// <summary>Thumbprints are copied from certlm.msc with spaces and sometimes an invisible mark in front: keep hex only.</summary>
    public static string NormalizeThumbprint(string thumbprint) =>
        string.Concat(thumbprint.Where(Uri.IsHexDigit)).ToUpperInvariant();

    private static bool IsThumbprint(string value, bool sha256Allowed)
    {
        string hex = NormalizeThumbprint(value);
        return hex.Length == 40 || (sha256Allowed && hex.Length == 64);
    }
}
