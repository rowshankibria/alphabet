namespace QrDiode.Core;

/// <summary>
/// The machine-wide key exchange file, <see cref="QrDiodePaths.KeyExchangeFile"/> (<c>C:\ProgramData\QrDiode\keyexchange.json</c>):
/// set once by an administrator and read by the Sender, the Receiver and the KeyCeremony tool, so the three can never
/// disagree. No file: the key ceremony, as before.
/// <code>
/// { "KeyExchange": "Certificate",
///   "Certificate": { "Location": "Cert:\\LocalMachine\\My", "OwnSubject": "qrbridge-corp.example.com",
///                    "TrustedCaThumbprint": "9F8E…", "ExpectedPeerSubject": "qrbridge-dmz.example.com" } }
/// </code>
/// </summary>
public sealed class KeyExchangeSettings
{
    /// <summary>How this machine and its peer trust each other's keys.</summary>
    public KeyExchangeKind KeyExchange { get; set; } = KeyExchangeKind.KeyCeremony;

    /// <summary><see cref="KeyExchangeKind.Certificate"/> only; empty otherwise.</summary>
    public CertificateOptions Certificate { get; set; } = new();

    /// <exception cref="InvalidDataException">The file cannot be read, or has unknown or wrongly typed settings.</exception>
    public static KeyExchangeSettings Load(string path) => AppSettings.ReadFile<KeyExchangeSettings>(path);

    /// <summary>
    /// True when the Windows user running this program can change the file, or create or replace files in its folder.
    /// On a kiosk ("Production": true) that would let anyone at the keyboard change which peer or CA the machine trusts:
    /// unlike Program Files, C:\ProgramData lets ordinary users create and write files unless an administrator locks it.
    /// </summary>
    public static bool IsWritableByCurrentUser(string path)
    {
        string? folder = Path.GetDirectoryName(path);
        if (folder is not null && Directory.Exists(folder))
        {
            try
            {
                using (File.Create(Path.Combine(folder, $".write-probe-{Guid.NewGuid():N}"), 1, FileOptions.DeleteOnClose)) { }
                return true;
            }
            catch (Exception ex) when (ex is UnauthorizedAccessException or IOException) { }
        }
        if (File.Exists(path))
        {
            try
            {
                using (new FileStream(path, FileMode.Open, FileAccess.Write, FileShare.ReadWrite)) { }
                return true;
            }
            catch (Exception ex) when (ex is UnauthorizedAccessException or IOException) { }
        }
        return false;
    }
}
