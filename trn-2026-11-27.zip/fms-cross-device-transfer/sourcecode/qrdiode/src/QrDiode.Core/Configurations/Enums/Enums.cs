namespace QrDiode.Core;

/// <summary>What the QrDiode apps carry (setting "QrDiode:Mode").</summary>
public enum QrDiodeMode
{
    /// <summary>
    /// The apps on their own: the Sender airs simulator payloads or a file an operator picks, the Receiver stores what
    /// arrives in its local payload store. Demos and the bench.
    /// </summary>
    Standalone,

    /// <summary>
    /// Connected to the SOAP Gateway on the same machine through its database (settings section "QRDatabase",
    /// Integration-Plan §2.4–2.5): the Sender airs the gateway's Outbox as bundles, the Receiver stores arriving bundles
    /// in the gateway's Inbox and accepts nothing else.
    /// </summary>
    Gateway,
}

/// <summary>
/// How this machine and its peer come to trust each other's public keys ("KeyExchange" in C:\ProgramData\QrDiode\keyexchange.json). Every value is
/// one <c>IKeyExchange</c> implementation, created in <c>KeyExchanges.Load</c>: a new mechanism is a new value, a new class
/// and one line there; the Sender, the Receiver, the receive engine and the KeyCeremony tool do not change.
/// </summary>
public enum KeyExchangeKind
{
    /// <summary>Named CNG keys; public-key bundles carried by hand and compared by voice (the default).</summary>
    KeyCeremony,

    /// <summary>A company certificate from the Windows Certificate Store; the two sides pair over the cameras (CertHello).</summary>
    Certificate,
}

/// <summary>What happened to a verified peer certificate when the Receiver tried to pin it (certificate mode).</summary>
public enum PinOutcome
{
    /// <summary>No peer of that name was pinned: it is now.</summary>
    Pinned,
    /// <summary>A newer CertHello (renewed certificate or new key) replaced the pinned one.</summary>
    Replaced,
    /// <summary>The same certificate and key are already pinned: nothing written.</summary>
    Unchanged,
    /// <summary>The pinned CertHello is newer than this one (a recording held up to the camera): nothing written.</summary>
    Older,
}
