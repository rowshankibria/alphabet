using System.Security.Cryptography;

namespace QrDiode.Core.Framing;

/// <summary>
/// The data-frame MAC: HMAC-SHA256 truncated to <see cref="FrameFormat.MacSize"/> bytes, keyed with
/// the session's frame key (derived from the same ECDH secret as the payload key, see
/// <c>Envelope.DeriveSessionKeys</c>). Only the two endpoints can compute it, so a frame that fails
/// it is dropped before it can touch decoder state.
/// </summary>
public static class FrameMac
{
    public static void Compute(ReadOnlySpan<byte> frameKey, ReadOnlySpan<byte> covered, Span<byte> destination)
    {
        if (destination.Length != FrameFormat.MacSize)
            throw new ArgumentException($"MAC destination must be {FrameFormat.MacSize} bytes.", nameof(destination));

        Span<byte> full = stackalloc byte[HMACSHA256.HashSizeInBytes];
        HMACSHA256.HashData(frameKey, covered, full);
        full[..FrameFormat.MacSize].CopyTo(destination);
    }

    /// <summary>Constant-time check of a received MAC.</summary>
    public static bool Verify(ReadOnlySpan<byte> frameKey, ReadOnlySpan<byte> covered, ReadOnlySpan<byte> mac)
    {
        if (mac.Length != FrameFormat.MacSize) return false;
        Span<byte> expected = stackalloc byte[FrameFormat.MacSize];
        Compute(frameKey, covered, expected);
        return CryptographicOperations.FixedTimeEquals(expected, mac);
    }
}
