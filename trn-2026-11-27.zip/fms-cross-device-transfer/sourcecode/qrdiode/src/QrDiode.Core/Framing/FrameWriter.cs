using System.Buffers.Binary;
using System.IO.Hashing;
using System.Security.Cryptography;
using QrDiode.Core.Crypto;

namespace QrDiode.Core.Framing;

/// <summary>Builds wire frames. Sender-side only; output arrays feed the QR encoder directly.</summary>
public static class FrameWriter
{
    /// <summary>Data frame: header ‖ symbolId ‖ payload ‖ MAC (under <paramref name="frameKey"/>) ‖ CRC.</summary>
    public static byte[] WriteDataFrame(ReadOnlySpan<byte> sessionTag, uint symbolId, ReadOnlySpan<byte> symbolPayload,
        ReadOnlySpan<byte> frameKey)
    {
        if (sessionTag.Length != FrameFormat.SessionTagSize)
            throw new ArgumentException("Session tag must be 8 bytes.", nameof(sessionTag));

        var frame = new byte[FrameFormat.DataOverhead + symbolPayload.Length];
        WriteHeader(frame, FrameFormat.TypeDataSymbol, sessionTag);
        BinaryPrimitives.WriteUInt32LittleEndian(frame.AsSpan(FrameFormat.HeaderSize, 4), symbolId);
        symbolPayload.CopyTo(frame.AsSpan(FrameFormat.HeaderSize + 4));

        int macOffset = FrameFormat.HeaderSize + 4 + symbolPayload.Length;
        FrameMac.Compute(frameKey, frame.AsSpan(0, macOffset), frame.AsSpan(macOffset, FrameFormat.MacSize));
        AppendCrc(frame);
        return frame;
    }

    public static byte[] WriteManifestFrame(ReadOnlySpan<byte> sessionTag, ReadOnlySpan<byte> manifestBody, ReadOnlySpan<byte> signature)
    {
        if (sessionTag.Length != FrameFormat.SessionTagSize)
            throw new ArgumentException("Session tag must be 8 bytes.", nameof(sessionTag));
        if (signature.Length != FrameFormat.SignatureSize)
            throw new ArgumentException("Signature must be 64 bytes (P-256 r||s).", nameof(signature));
        if (manifestBody.Length > ushort.MaxValue)
            throw new ArgumentException("Manifest body too large.", nameof(manifestBody));

        var frame = new byte[FrameFormat.ManifestOverhead + manifestBody.Length];
        WriteHeader(frame, FrameFormat.TypeManifest, sessionTag);
        BinaryPrimitives.WriteUInt16LittleEndian(frame.AsSpan(FrameFormat.HeaderSize, 2), (ushort)manifestBody.Length);
        manifestBody.CopyTo(frame.AsSpan(FrameFormat.HeaderSize + 2));
        signature.CopyTo(frame.AsSpan(FrameFormat.HeaderSize + 2 + manifestBody.Length));
        AppendCrc(frame);
        return frame;
    }

    /// <summary>
    /// CertHello frame (certificate mode pairing): header ‖ timestamp ‖ certLen ‖ cert ‖ spkiLen ‖ agreementSpki ‖
    /// signature ‖ CRC. <paramref name="certificateKey"/> is the certificate's private key; it signs
    /// <see cref="CertHello.Domain"/> ‖ every byte before the signature, so the agreement key is bound to the certificate.
    /// </summary>
    public static byte[] WriteCertHelloFrame(long timestampUnixMs, ReadOnlySpan<byte> certificateDer,
        ReadOnlySpan<byte> agreementSpki, ECDsa certificateKey)
    {
        if (certificateDer.Length is 0 or > FrameFormat.MaxCertificateSize)
            throw new ArgumentException($"The certificate must be 1–{FrameFormat.MaxCertificateSize} bytes (DER).", nameof(certificateDer));
        if (agreementSpki.Length is 0 or > FrameFormat.MaxAgreementKeySize)
            throw new ArgumentException("Bad agreement key length.", nameof(agreementSpki));

        var frame = new byte[FrameFormat.CertHelloOverhead + certificateDer.Length + agreementSpki.Length];
        WriteHeader(frame, FrameFormat.TypeCertHello, CertHello.SessionTag(certificateDer));
        var span = frame.AsSpan(FrameFormat.HeaderSize);
        BinaryPrimitives.WriteInt64LittleEndian(span, timestampUnixMs);
        BinaryPrimitives.WriteUInt16LittleEndian(span[8..], (ushort)certificateDer.Length);
        certificateDer.CopyTo(span[10..]);
        BinaryPrimitives.WriteUInt16LittleEndian(span[(10 + certificateDer.Length)..], (ushort)agreementSpki.Length);
        agreementSpki.CopyTo(span[(12 + certificateDer.Length)..]);

        int signatureOffset = frame.Length - FrameFormat.CrcSize - FrameFormat.SignatureSize;
        LowSSignature.Sign(certificateKey, CertHello.SignedData(frame.AsSpan(0, signatureOffset)))
            .CopyTo(frame.AsSpan(signatureOffset, FrameFormat.SignatureSize));
        AppendCrc(frame);
        return frame;
    }

    private static void WriteHeader(Span<byte> frame, byte type, ReadOnlySpan<byte> sessionTag)
    {
        frame[0] = FrameFormat.Magic0;
        frame[1] = FrameFormat.Magic1;
        frame[2] = FrameFormat.ProtocolVersion;
        frame[3] = type;
        sessionTag.CopyTo(frame.Slice(FrameFormat.SessionTagOffset, FrameFormat.SessionTagSize));
    }

    private static void AppendCrc(Span<byte> frame)
    {
        uint crc = Crc32.HashToUInt32(frame[..^FrameFormat.CrcSize]);
        BinaryPrimitives.WriteUInt32LittleEndian(frame[^FrameFormat.CrcSize..], crc);
    }
}
