using System.Buffers.Binary;
using System.IO.Hashing;

namespace QrDiode.Core.Framing;

/// <summary>
/// Parsed view over a single frame. Holds spans into the caller's buffer — do not retain.
/// </summary>
public readonly ref struct ParsedFrame
{
    public FrameType Type { get; init; }
    public ReadOnlySpan<byte> SessionTag { get; init; }
    /// <summary>Data frames only.</summary>
    public uint SymbolId { get; init; }
    /// <summary>Data frames: the symbol payload. Manifest frames: the manifest body. CertHello frames: timestamp ‥ agreement key.</summary>
    public ReadOnlySpan<byte> Payload { get; init; }
    /// <summary>Manifest and CertHello frames: raw ECDSA P-256 signature (r||s, 64 bytes).</summary>
    public ReadOnlySpan<byte> Signature { get; init; }
    /// <summary>Data frames only: the frame MAC (<see cref="FrameFormat.MacSize"/> bytes).</summary>
    public ReadOnlySpan<byte> Mac { get; init; }
    /// <summary>Data frames only: the bytes the MAC covers (header ‖ symbolId ‖ payload).</summary>
    public ReadOnlySpan<byte> MacCovered { get; init; }
    /// <summary>CertHello frames only: every byte before the signature (what it covers, after the domain label).</summary>
    public ReadOnlySpan<byte> SignatureCovered { get; init; }
}

public enum FrameParseError
{
    None = 0,
    TooShort,
    TooLong,
    BadMagic,
    BadVersion,
    BadType,
    BadCrc,
    BadLength,
}

/// <summary>
/// Span-based, allocation-free frame parser. This is the primary untrusted-input surface:
/// every length is checked before any read; rejection allocates nothing and throws nothing.
/// </summary>
public static class FrameParser
{
    public static bool TryParse(ReadOnlySpan<byte> frame, out ParsedFrame parsed, out FrameParseError error)
    {
        parsed = default;

        if (frame.Length < FrameFormat.MinFrameSize) { error = FrameParseError.TooShort; return false; }
        if (frame.Length > FrameFormat.MaxFrameSize) { error = FrameParseError.TooLong; return false; }
        if (frame[0] != FrameFormat.Magic0 || frame[1] != FrameFormat.Magic1) { error = FrameParseError.BadMagic; return false; }
        if (frame[2] != FrameFormat.ProtocolVersion) { error = FrameParseError.BadVersion; return false; }

        byte type = frame[3];
        if (type != FrameFormat.TypeManifest && type != FrameFormat.TypeDataSymbol && type != FrameFormat.TypeCertHello)
        {
            error = FrameParseError.BadType;
            return false;
        }

        // CRC over everything except the trailing 4 bytes.
        var crcExpected = BinaryPrimitives.ReadUInt32LittleEndian(frame[^FrameFormat.CrcSize..]);
        var crcActual = Crc32.HashToUInt32(frame[..^FrameFormat.CrcSize]);
        if (crcExpected != crcActual) { error = FrameParseError.BadCrc; return false; }

        var sessionTag = frame.Slice(FrameFormat.SessionTagOffset, FrameFormat.SessionTagSize);

        if (type == FrameFormat.TypeDataSymbol)
        {
            if (frame.Length < FrameFormat.DataOverhead + 1) { error = FrameParseError.TooShort; return false; }
            uint symbolId = BinaryPrimitives.ReadUInt32LittleEndian(frame.Slice(FrameFormat.HeaderSize, 4));
            int macOffset = frame.Length - FrameFormat.CrcSize - FrameFormat.MacSize;
            parsed = new ParsedFrame
            {
                Type = FrameType.DataSymbol,
                SessionTag = sessionTag,
                SymbolId = symbolId,
                Payload = frame[(FrameFormat.HeaderSize + 4)..macOffset],
                Mac = frame.Slice(macOffset, FrameFormat.MacSize),
                MacCovered = frame[..macOffset],
            };
            error = FrameParseError.None;
            return true;
        }

        if (type == FrameFormat.TypeCertHello)
        {
            // header + timestamp(8) + certLen(2) + cert + spkiLen(2) + spki + sig(64) + crc: both lengths must add up exactly.
            if (frame.Length < FrameFormat.CertHelloOverhead + 2) { error = FrameParseError.TooShort; return false; }
            int certLen = BinaryPrimitives.ReadUInt16LittleEndian(frame.Slice(FrameFormat.HeaderSize + 8, 2));
            if (certLen is 0 or > FrameFormat.MaxCertificateSize) { error = FrameParseError.BadLength; return false; }
            int spkiLenOffset = FrameFormat.HeaderSize + 10 + certLen;
            if (spkiLenOffset + 2 > frame.Length) { error = FrameParseError.BadLength; return false; }
            int spkiLen = BinaryPrimitives.ReadUInt16LittleEndian(frame.Slice(spkiLenOffset, 2));
            if (spkiLen is 0 or > FrameFormat.MaxAgreementKeySize) { error = FrameParseError.BadLength; return false; }
            if (frame.Length != FrameFormat.CertHelloOverhead + certLen + spkiLen) { error = FrameParseError.BadLength; return false; }

            int signatureOffset = frame.Length - FrameFormat.CrcSize - FrameFormat.SignatureSize;
            parsed = new ParsedFrame
            {
                Type = FrameType.CertHello,
                SessionTag = sessionTag,
                Payload = frame[FrameFormat.HeaderSize..signatureOffset],
                Signature = frame.Slice(signatureOffset, FrameFormat.SignatureSize),
                SignatureCovered = frame[..signatureOffset],
            };
            error = FrameParseError.None;
            return true;
        }

        // Manifest frame: header + bodyLen(2) + body + sig(64) + crc
        if (frame.Length < FrameFormat.ManifestOverhead + 1) { error = FrameParseError.TooShort; return false; }
        int bodyLen = BinaryPrimitives.ReadUInt16LittleEndian(frame.Slice(FrameFormat.HeaderSize, 2));
        int expectedLen = FrameFormat.ManifestOverhead + bodyLen;
        if (frame.Length != expectedLen) { error = FrameParseError.BadLength; return false; }

        var body = frame.Slice(FrameFormat.HeaderSize + 2, bodyLen);
        var sig = frame.Slice(FrameFormat.HeaderSize + 2 + bodyLen, FrameFormat.SignatureSize);
        parsed = new ParsedFrame
        {
            Type = FrameType.Manifest,
            SessionTag = sessionTag,
            Payload = body,
            Signature = sig,
        };
        error = FrameParseError.None;
        return true;
    }
}
