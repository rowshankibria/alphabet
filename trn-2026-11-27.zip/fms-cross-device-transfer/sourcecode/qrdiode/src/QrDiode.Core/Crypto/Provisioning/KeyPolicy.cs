using System.Runtime.Versioning;

namespace QrDiode.Core.Crypto;

/// <summary>
/// Opens this machine's keys and trust store under the deployment's rules (<see cref="QrDiodeOptions.Production"/>):
/// in production the demo endpoints are refused and keys must be TPM-backed. One place, so the
/// Sender, the Receiver and the KeyCeremony tool cannot drift apart.
/// </summary>
public static class KeyPolicy
{
    /// <summary>The endpoint names the one-click demo set-up (<see cref="DemoProvisioner"/>) uses.</summary>
    public const string DemoOtEndpoint = "demo-ot";
    public const string DemoItEndpoint = "demo-it";

    public static bool IsDemoEndpoint(string name) =>
        name.Equals(DemoOtEndpoint, StringComparison.OrdinalIgnoreCase) ||
        name.Equals(DemoItEndpoint, StringComparison.OrdinalIgnoreCase);

    /// <summary>Throws with a plain message when production forbids the demo set-up.</summary>
    public static void EnsureDemoAllowed(QrDiodeOptions options)
    {
        if (options.Production)
            throw new InvalidOperationException(
                "Demo setup is turned off on this machine (\"Production\": true in appsettings.json). " +
                "Use the KeyCeremony tool: init, export, import, then compare the fingerprints.");
    }

    [SupportedOSPlatform("windows")]
    public static CngEndpointKeys OpenKeys(string endpointName, QrDiodeOptions options)
    {
        if (options.Production && IsDemoEndpoint(endpointName))
            throw new InvalidOperationException(
                $"'{endpointName}' is a demo key, and this machine is in production (\"Production\": true). " +
                "Use this machine's own endpoint name from the key ceremony.");
        return CngEndpointKeys.OpenOrCreate(endpointName, preferTpm: true, requireTpm: options.Production);
    }

    public static DirectoryTrustStore OpenTrustStore(QrDiodeOptions options) =>
        new(QrDiodePaths.TrustDir, refuseDemoBundles: options.Production);
}
