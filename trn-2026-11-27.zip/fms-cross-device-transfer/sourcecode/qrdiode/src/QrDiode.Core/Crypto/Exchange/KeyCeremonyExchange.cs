using System.Runtime.Versioning;

namespace QrDiode.Core.Crypto;

/// <summary>
/// The key ceremony ("KeyExchange": "KeyCeremony", the default): each machine makes named, non-exportable CNG keys
/// (in the TPM when it can), exports its public bundle, the operators carry the bundles across by hand and compare the
/// fingerprints by voice. Nothing pairs over the light. Rules (demo endpoints, TPM in production) are
/// <see cref="KeyPolicy"/>'s.
/// </summary>
public sealed class KeyCeremonyExchange(QrDiodeOptions options) : IKeyExchange
{
    public KeyExchangeKind Kind => KeyExchangeKind.KeyCeremony;
    public string Description => "key ceremony";
    public bool UsesEndpointName => true;
    public string Identity => "";
    public bool AllowsDemo => !options.Production;
    public bool PairsOverTheLight => false;
    public string? ExpectedPeer => null;
    public bool ForgetsPeersOnStart => false;

    [SupportedOSPlatform("windows")]
    public IEndpointKeys OpenOwnKeys(string endpointName) => KeyPolicy.OpenKeys(endpointName, options);

    [SupportedOSPlatform("windows")]
    public DirectoryTrustStore OpenTrustStore() => KeyPolicy.OpenTrustStore(options);

    public byte[]? BuildPairingFrame(IEndpointKeys ownKeys) => null;

    [SupportedOSPlatform("windows")]
    public IPairingVerifier? CreatePairingVerifier(TimeSpan freshness) => null;

    public PinOutcome Pin(VerifiedPeer peer) =>
        throw new NotSupportedException("The key ceremony does not pair over the light: import the peer's bundle instead.");

    public int ForgetPairedPeers() => 0;

    public IReadOnlyList<KeyExchangeCommand> Commands =>
    [
        new("init", "<endpointName>",
            "Create (or open) this machine's key pairs in Windows CNG.\nTPM-backed when available (\"Production\": true: TPM only); always non-exportable.",
            1, (a, o, e) => Init(a[0], o, e)),
        new("export", "<endpointName> <out.json>", "Export this machine's PUBLIC keys as a bundle file.",
            2, (a, o, e) => Export(a[0], a[1], o, e)),
        new("import", "<bundle.json>", "Import a peer's public bundle into the trust store.",
            1, (a, o, e) => Import(a[0], o, e)),
        new("demo", "",
            "One-click single-machine demo setup: provisions BOTH endpoints (demo-ot / demo-it) and cross-trusts them.\n" +
            "Full security stays active — nothing is weakened. Refused when appsettings.json says \"Production\": true.",
            0, (_, o, e) => Demo(o, e)),
        new("demo-clean", "", "Remove the demo keys and bundles again.", 0, (_, o, _) => DemoClean(o)),
    ];

    private int Init(string name, TextWriter output, TextWriter error)
    {
        if (!OperatingSystem.IsWindows()) return WindowsOnly(error);
        bool existed = CngEndpointKeys.Exists(name);
        CngEndpointKeys keys;
        try
        {
            keys = KeyPolicy.OpenKeys(name, options);
        }
        catch (InvalidOperationException ex)
        {
            error.WriteLine(ex.Message);
            return 1;
        }

        using (keys)
        {
            output.WriteLine(existed ? $"Endpoint '{name}' already exists:" : $"Endpoint '{name}' created:");
            output.WriteLine($"  Key storage   : {(keys.IsTpmBacked ? "TPM (Platform Crypto Provider)" : "Software KSP (non-exportable)")}");
            output.WriteLine($"  Signing key id: {KeyId.ToHex(keys.SigningKeyId)}");
            output.WriteLine($"  Kex key id    : {KeyId.ToHex(keys.AgreementKeyId)}");
            output.WriteLine();
            output.WriteLine($"Next: qrdiode-keys export {name} <bundle.json> and carry it to the peer on removable media.");
        }
        return 0;
    }

    private int Export(string name, string outPath, TextWriter output, TextWriter error)
    {
        if (!OperatingSystem.IsWindows()) return WindowsOnly(error);
        if (!CngEndpointKeys.Exists(name))
        {
            error.WriteLine($"Endpoint '{name}' does not exist. Run: init {name}");
            return 1;
        }

        CngEndpointKeys keys;
        try
        {
            keys = KeyPolicy.OpenKeys(name, options);
        }
        catch (InvalidOperationException ex)
        {
            error.WriteLine(ex.Message);
            return 1;
        }

        using (keys)
        {
            var bundle = PublicKeyBundle.FromKeys(name, keys);
            File.WriteAllText(outPath, bundle.ToJson());
            output.WriteLine($"Public bundle written to {outPath}");
            output.WriteLine($"Fingerprint: {bundle.Fingerprint()}");
            output.WriteLine("Verify this fingerprint with the receiving side out-of-band (phone/voice) after import.");
        }
        return 0;
    }

    private int Import(string inPath, TextWriter output, TextWriter error)
    {
        PublicKeyBundle bundle;
        try
        {
            bundle = PublicKeyBundle.Parse(File.ReadAllText(inPath));
        }
        catch (Exception ex)
        {
            error.WriteLine($"Bundle rejected: {ex.Message}");
            return 1;
        }

        if (options.Production && KeyPolicy.IsDemoEndpoint(bundle.Name))
        {
            error.WriteLine($"Bundle rejected: '{bundle.Name}' is a demo bundle, and this machine is in production.");
            return 1;
        }

        string safeName = string.Concat(bundle.Name.Where(char.IsAsciiLetterOrDigit));
        string target = Path.Combine(QrDiodePaths.TrustDir, $"{safeName}.json");
        if (File.Exists(target))
        {
            error.WriteLine($"A trusted bundle named '{bundle.Name}' already exists at {target}.");
            error.WriteLine("Delete it first if you intend to rotate keys (this is a deliberate two-step).");
            return 1;
        }

        File.WriteAllText(target, bundle.ToJson());
        using var peer = bundle.ToPeerKeys();
        output.WriteLine($"Imported '{bundle.Name}' into the trust store.");
        output.WriteLine($"  Signing key id: {KeyId.ToHex(peer.SigningKeyId)}");
        output.WriteLine($"  Kex key id    : {KeyId.ToHex(peer.AgreementKeyId)}");
        output.WriteLine($"  FINGERPRINT   : {bundle.Fingerprint()}");
        output.WriteLine();
        output.WriteLine("CEREMONY STEP: read this fingerprint aloud to the exporting operator.");
        output.WriteLine("Both sides must see the identical value. If they differ, DELETE this bundle immediately.");
        return 0;
    }

    private int Demo(TextWriter output, TextWriter error)
    {
        if (!OperatingSystem.IsWindows()) return WindowsOnly(error);
        try
        {
            KeyPolicy.EnsureDemoAllowed(options);
        }
        catch (InvalidOperationException ex)
        {
            error.WriteLine(ex.Message);
            return 1;
        }

        var ids = DemoProvisioner.Provision();
        output.WriteLine("Demo environment ready — BOTH endpoints provisioned on this machine.");
        output.WriteLine($"  {DemoProvisioner.OtEndpoint}  fingerprint {ids.OtFingerprint}");
        output.WriteLine($"  {DemoProvisioner.ItEndpoint}  fingerprint {ids.ItFingerprint}");
        output.WriteLine();
        output.WriteLine("All security is fully active (real signatures, encryption, anti-replay).");
        output.WriteLine($"Sender:   open keys as '{DemoProvisioner.OtEndpoint}', pick receiver '{DemoProvisioner.ItEndpoint}'.");
        output.WriteLine($"Receiver: open keys as '{DemoProvisioner.ItEndpoint}', start the camera.");
        output.WriteLine("Run 'demo-clean' before provisioning this machine for production.");
        return 0;
    }

    private static int DemoClean(TextWriter output)
    {
        if (!OperatingSystem.IsWindows()) return 2;
        DemoProvisioner.Remove();
        output.WriteLine("Demo keys and trust bundles removed.");
        return 0;
    }

    private static int WindowsOnly(TextWriter error)
    {
        error.WriteLine("The key ceremony needs Windows (CNG key storage).");
        return 2;
    }
}
