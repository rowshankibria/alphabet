namespace QrDiode.Core.Crypto;

/// <summary>
/// The one place that turns the machine's key exchange file (<see cref="QrDiodePaths.KeyExchangeFile"/>) into an
/// <see cref="IKeyExchange"/>. Adding a mechanism: a <see cref="KeyExchangeKind"/> value, an implementation, and one case here.
/// </summary>
public static class KeyExchanges
{
    /// <summary>The machine's key exchange, from <paramref name="settingsPath"/> (default: <see cref="QrDiodePaths.KeyExchangeFile"/>).</summary>
    /// <exception cref="InvalidDataException">
    /// The settings cannot be used: unreadable, the chosen mechanism's section incomplete, another mechanism's section
    /// filled in (a kiosk meant for one mechanism must never quietly run another), or — on a kiosk ("Production": true) —
    /// the file or its folder writable by the Windows user running this program. The message says what to fix.
    /// </exception>
    public static IKeyExchange Load(QrDiodeOptions options, string? settingsPath = null)
    {
        string path = settingsPath ?? QrDiodePaths.KeyExchangeFile;
        if (options.Production && KeyExchangeSettings.IsWritableByCurrentUser(path))
            throw new InvalidDataException(
                $"{path} (or its folder) can be changed by this Windows user, so anyone at the kiosk could change which peer " +
                "this machine trusts. An administrator must make the folder read-only for users (Users: Read & execute only).");

        var settings = KeyExchangeSettings.Load(path);
        switch (settings.KeyExchange)
        {
            case KeyExchangeKind.KeyCeremony:
                if (!settings.Certificate.IsEmpty)
                    throw new InvalidDataException(
                        $"{path}: the \"Certificate\" section is filled in, but \"KeyExchange\" is \"KeyCeremony\". " +
                        "Set \"KeyExchange\": \"Certificate\" to use the certificate, or clear the section.");
                return new KeyCeremonyExchange(options);

            case KeyExchangeKind.Certificate:
                if (settings.Certificate.Problem() is { } problem) throw new InvalidDataException($"{path}: {problem}");
                return new CertificateKeyExchange(options, settings.Certificate);

            default:
                throw new InvalidDataException($"{path}: \"KeyExchange\": \"{settings.KeyExchange}\" is not a key exchange this version knows.");
        }
    }
}
