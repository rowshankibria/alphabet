using System.Runtime.Versioning;

namespace QrDiode.Core.Crypto;

/// <summary>
/// Company certificates ("KeyExchange": "Certificate"; docs/x509-certificate-handshake-plan.md): the machine
/// signs with its ECDSA P-256 certificate from the Windows Certificate Store plus a named CNG ECDH key, and the two sides
/// pair over the cameras — each idle Sender shows its CertHello, the other side's Receiver verifies it
/// (<see cref="CertHelloValidator"/>: the pinned CA, the expected peer, fresh) and pins it (<see cref="CertificatePins"/>).
/// </summary>
public sealed class CertificateKeyExchange(QrDiodeOptions options, CertificateOptions certificate) : IKeyExchange
{
    public KeyExchangeKind Kind => KeyExchangeKind.Certificate;
    public string Description => "company certificate";
    public bool UsesEndpointName => false;
    public string Identity => certificate.OwnThumbprint.Length > 0 ? certificate.OwnThumbprint : certificate.OwnSubject;
    public bool AllowsDemo => false;
    public bool PairsOverTheLight => true;
    public string? ExpectedPeer => certificate.ExpectedPeerSubject;
    public bool ForgetsPeersOnStart => certificate.RequireHandshakeOnStart;

    [SupportedOSPlatform("windows")]
    public IEndpointKeys OpenOwnKeys(string endpointName) => X509EndpointKeys.Open(certificate, options.Production);

    [SupportedOSPlatform("windows")]
    public DirectoryTrustStore OpenTrustStore()
    {
        using var validator = CertHelloValidator.FromStore(certificate);
        return new DirectoryTrustStore(QrDiodePaths.TrustDir, validator);
    }

    public byte[]? BuildPairingFrame(IEndpointKeys ownKeys) => ownKeys is X509EndpointKeys keys
        ? CertHello.Build(keys)
        : throw new InvalidOperationException("A CertHello needs this machine's certificate keys.");

    [SupportedOSPlatform("windows")]
    public IPairingVerifier? CreatePairingVerifier(TimeSpan freshness) => CertHelloValidator.FromStore(certificate, freshness);

    public PinOutcome Pin(VerifiedPeer peer) => CertificatePins.Save(QrDiodePaths.TrustDir, peer);

    public int ForgetPairedPeers() => CertificatePins.Forget(QrDiodePaths.TrustDir);

    public IReadOnlyList<KeyExchangeCommand> Commands =>
    [
        new("check-cert", "",
            "Open this machine's certificate and its encryption key, and run on it the checks the other side will run\n" +
            "(chain to the trusted CA, ECDSA P-256, may sign).",
            0, (_, o, e) => CheckCertificate(o, e)),
        new("export-hello", "<out.bin>", "Write this machine's CertHello (public keys only) to a file.",
            1, (a, o, e) => ExportHello(a[0], o, e)),
        new("import-hello", "<in.bin>",
            "Verify the other side's CertHello like the camera would and pin it.\n" +
            "For one-way bench tests: in normal use the cameras pair the two sides.",
            1, (a, o, e) => ImportHello(a[0], o, e)),
    ];

    private int CheckCertificate(TextWriter output, TextWriter error)
    {
        if (!OperatingSystem.IsWindows()) return WindowsOnly(error);
        try
        {
            using var keys = X509EndpointKeys.Open(certificate, options.Production);
            using var validator = CertHelloValidator.FromStore(certificate);
            output.WriteLine($"This machine     : {keys.Name}");
            output.WriteLine($"  Subject        : {keys.Certificate.Subject}");
            output.WriteLine($"  Thumbprint     : {keys.Certificate.Thumbprint}");
            output.WriteLine($"  Valid until    : {keys.Certificate.NotAfter:yyyy-MM-dd HH:mm}");
            output.WriteLine($"  Key storage    : {(keys.IsTpmBacked ? "TPM (Platform Crypto Provider)" : "not TPM-backed")}");
            output.WriteLine($"  Signing key id : {KeyId.ToHex(keys.SigningKeyId)}");
            output.WriteLine($"  Kex key id     : {KeyId.ToHex(keys.AgreementKeyId)}");
            output.WriteLine($"Trusted CA       : {validator.TrustedCaThumbprint}");
            output.WriteLine($"Pairs only with  : {validator.ExpectedPeerSubject}");

            // The other side runs exactly these checks on this certificate (except its name).
            if (validator.CheckCertificate(keys.Certificate) is { } problem)
            {
                error.WriteLine($"✖ The other side would refuse this certificate: {problem}");
                return 1;
            }
            output.WriteLine("✔ The certificate chains to the trusted CA and can sign. The other side will accept it if it expects this name.");
            return 0;
        }
        catch (InvalidOperationException ex)
        {
            error.WriteLine($"✖ {ex.Message}");
            return 1;
        }
    }

    private int ExportHello(string outPath, TextWriter output, TextWriter error)
    {
        if (!OperatingSystem.IsWindows()) return WindowsOnly(error);
        try
        {
            using var keys = X509EndpointKeys.Open(certificate, options.Production);
            File.WriteAllBytes(outPath, CertHello.Build(keys));
            output.WriteLine($"CertHello of {keys.Name} written to {outPath} (public keys only).");
            output.WriteLine($"Certificate thumbprint: {keys.Certificate.Thumbprint}");
            output.WriteLine("Carry it to the other machine and run: import-hello <file>. For bench tests only: the cameras do this in normal use.");
            return 0;
        }
        catch (InvalidOperationException ex)
        {
            error.WriteLine(ex.Message);
            return 1;
        }
    }

    private int ImportHello(string inPath, TextWriter output, TextWriter error)
    {
        if (!OperatingSystem.IsWindows()) return WindowsOnly(error);
        try
        {
            using var validator = CertHelloValidator.FromStore(certificate);
            // Carried by hand: its age says nothing about a replay. Every other check is the camera's.
            if (!validator.TryVerify(File.ReadAllBytes(inPath), out var peer, out string reason, checkFreshness: false))
            {
                error.WriteLine($"CertHello refused: {reason}");
                return 1;
            }
            var outcome = Pin(peer!);
            TrustSignal.Ring();
            output.WriteLine($"{peer!.Name} ({peer.Identity}): {outcome}.");
            output.WriteLine($"  Signing key id: {KeyId.ToHex(peer.SigningKeyId)}");
            output.WriteLine($"  Kex key id    : {KeyId.ToHex(peer.AgreementKeyId)}");
            return outcome == PinOutcome.Older ? 1 : 0;
        }
        catch (Exception ex) when (ex is InvalidOperationException or IOException or UnauthorizedAccessException)
        {
            error.WriteLine(ex.Message);
            return 1;
        }
    }

    private static int WindowsOnly(TextWriter error)
    {
        error.WriteLine("Certificate mode needs Windows (the Windows Certificate Store).");
        return 2;
    }
}
