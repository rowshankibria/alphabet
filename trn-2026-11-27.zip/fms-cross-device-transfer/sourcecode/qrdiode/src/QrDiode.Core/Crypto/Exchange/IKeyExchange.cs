using System.Runtime.Versioning;

namespace QrDiode.Core.Crypto;

/// <summary>
/// How this machine and its peer come to trust each other's public keys — the one thing the Sender, the Receiver, the
/// receive engine and the KeyCeremony tool know about it. Implementations: <see cref="KeyCeremonyExchange"/> (bundles
/// carried by hand) and <see cref="CertificateKeyExchange"/> (company certificates, paired over the cameras). Chosen by
/// the machine's keyexchange.json through <see cref="KeyExchanges.Load"/>; a new mechanism is a new implementation, a new
/// <see cref="KeyExchangeKind"/> value and one line there.
/// </summary>
public interface IKeyExchange
{
    KeyExchangeKind Kind { get; }

    /// <summary>In plain words, for status lines: "key ceremony", "company certificate".</summary>
    string Description { get; }

    /// <summary>The operator names this machine's keys (the endpoint box). False: the mechanism knows them (<see cref="Identity"/>).</summary>
    bool UsesEndpointName { get; }

    /// <summary>What names this machine when <see cref="UsesEndpointName"/> is false (shown in the endpoint box); else empty.</summary>
    string Identity { get; }

    /// <summary>The one-click demo set-up (both demo endpoints on one machine) may be used.</summary>
    bool AllowsDemo { get; }

    /// <summary>
    /// The two sides pair over the light: the Sender shows <see cref="BuildPairingFrame"/> when idle, the Receiver judges
    /// such frames (<see cref="CreatePairingVerifier"/>) and pins the peer. The trust store may start empty.
    /// </summary>
    bool PairsOverTheLight { get; }

    /// <summary>The one peer this machine pairs with, or null when any trusted peer may be picked.</summary>
    string? ExpectedPeer { get; }

    /// <summary>The Receiver forgets its paired peers at every start (<see cref="ForgetPairedPeers"/>).</summary>
    bool ForgetsPeersOnStart { get; }

    /// <summary>This machine's keys. <paramref name="endpointName"/> is used only when <see cref="UsesEndpointName"/>.</summary>
    /// <exception cref="InvalidOperationException">They cannot be opened; the message says what to do.</exception>
    [SupportedOSPlatform("windows")]
    IEndpointKeys OpenOwnKeys(string endpointName);

    /// <summary>The peers this machine trusts. Problems (files not trusted) are listed, never ignored silently.</summary>
    /// <exception cref="InvalidOperationException">The store cannot be opened; the message says why.</exception>
    [SupportedOSPlatform("windows")]
    DirectoryTrustStore OpenTrustStore();

    /// <summary>The frame the Sender shows when it has nothing to send (fresh timestamp each call); null when not <see cref="PairsOverTheLight"/>.</summary>
    byte[]? BuildPairingFrame(IEndpointKeys ownKeys);

    /// <summary>The Receiver's judge for one run; null when not <see cref="PairsOverTheLight"/>. The caller disposes it.</summary>
    /// <param name="freshness">How far a pairing frame's timestamp may be from now (the replay window).</param>
    [SupportedOSPlatform("windows")]
    IPairingVerifier? CreatePairingVerifier(TimeSpan freshness);

    /// <summary>Pins a verified peer, so <see cref="OpenTrustStore"/> trusts it from now on.</summary>
    /// <exception cref="NotSupportedException">This mechanism does not pair over the light.</exception>
    PinOutcome Pin(VerifiedPeer peer);

    /// <summary>Forgets every paired peer; returns how many there were (0 when not <see cref="PairsOverTheLight"/>).</summary>
    int ForgetPairedPeers();

    /// <summary>The administrator commands this mechanism adds to the KeyCeremony tool.</summary>
    IReadOnlyList<KeyExchangeCommand> Commands { get; }
}
