using System.Security.Cryptography;
using QrDiode.Core.Framing;

namespace QrDiode.Core.Crypto;

/// <summary>
/// A peer whose pairing frame passed every check of its key exchange: its two public keys, ready to pin. Mechanism-neutral:
/// <see cref="Identity"/> and <see cref="Details"/> carry what the mechanism knows (e.g. a certificate's thumbprint).
/// </summary>
/// <param name="Name">The peer's name, shown to operators and used as its trust-store name.</param>
/// <param name="Identity">What makes this peer this peer for its mechanism (a certificate thumbprint).</param>
/// <param name="TimestampUnixMs">When the peer stamped its pairing frame (its clock): a newer one may replace a pin.</param>
/// <param name="Evidence">The pairing frame itself, kept with the pin so every load can verify it again.</param>
/// <param name="Details">For the audit log: names and values, never key material.</param>
public sealed record VerifiedPeer(
    string Name,
    string Identity,
    long TimestampUnixMs,
    byte[] SigningSpki,
    byte[] AgreementSpki,
    byte[] SigningKeyId,
    byte[] AgreementKeyId,
    byte[] Evidence,
    IReadOnlyDictionary<string, string> Details)
{
    public PeerPublicKeys ToPeerKeys()
    {
        var signing = ECDsa.Create();
        signing.ImportSubjectPublicKeyInfo(SigningSpki, out _);
        var agreement = ECDiffieHellman.Create();
        agreement.ImportSubjectPublicKeyInfo(AgreementSpki, out _);
        return new PeerPublicKeys
        {
            Name = Name,
            SigningPublicKey = signing,
            AgreementPublicKey = agreement,
            SigningKeyId = SigningKeyId,
            AgreementKeyId = AgreementKeyId,
        };
    }
}

/// <summary>
/// The Receiver's judge for pairing frames over the light (<see cref="IKeyExchange.CreatePairingVerifier"/>). The
/// receive engine hands it every frame of <see cref="FrameType"/> while no session is in flight, and only reports what it
/// accepts: the host pins the peer (<see cref="IKeyExchange.Pin"/>).
/// </summary>
public interface IPairingVerifier : IDisposable
{
    /// <summary>The wire frame type this mechanism pairs with (CertHello for certificates).</summary>
    FrameType FrameType { get; }

    /// <summary>True when the frame comes from the expected peer and every check holds; otherwise why not.</summary>
    bool TryVerify(ReadOnlySpan<byte> frame, out VerifiedPeer? peer, out string reason);
}
