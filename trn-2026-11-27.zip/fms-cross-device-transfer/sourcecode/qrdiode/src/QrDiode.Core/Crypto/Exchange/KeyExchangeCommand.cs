namespace QrDiode.Core.Crypto;

/// <summary>
/// One administrator command a key exchange offers in the KeyCeremony tool (e.g. <c>init</c>, <c>check-cert</c>). The tool
/// lists and runs whatever the machine's mechanism provides, so a new mechanism brings its own commands.
/// </summary>
/// <param name="Name">What the operator types first, e.g. "import".</param>
/// <param name="Arguments">The usage of its arguments, e.g. "&lt;bundle.json&gt;" (empty when none).</param>
/// <param name="Help">One or more lines of help.</param>
/// <param name="ArgumentCount">Exactly how many arguments it takes.</param>
/// <param name="Run">Runs it with its arguments, writing to standard output and error; returns the exit code.</param>
public sealed record KeyExchangeCommand(
    string Name,
    string Arguments,
    string Help,
    int ArgumentCount,
    Func<IReadOnlyList<string>, TextWriter, TextWriter, int> Run);
