using System.Runtime.Versioning;

namespace QrDiode.Core.Crypto;

/// <summary>
/// Certificate mode doorbell between the two QR apps on one machine: the Receiver rings it after it pinned (or forgot) a
/// peer, the Sender wakes and reloads its trust store. A named event in the user's logon session (both apps run as the
/// kiosk user); the Sender also polls the trust folder, so a missed ring only costs a few seconds.
/// </summary>
[SupportedOSPlatform("windows")]
public static class TrustSignal
{
    public const string Name = @"Local\QrDiode.TrustUpdated";

    /// <summary>The event to wait on (auto-reset). The caller disposes it.</summary>
    public static EventWaitHandle Open() => new(false, EventResetMode.AutoReset, Name);

    public static void Ring()
    {
        using var signal = Open();
        signal.Set();
    }
}
