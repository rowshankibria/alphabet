using System.Security.Cryptography;
using System.Text.Json;

namespace QrDiode.Core.Crypto;

/// <summary>Directory-backed trust store: one JSON bundle per trusted peer.</summary>
public sealed class DirectoryTrustStore : ITrustStore, IDisposable
{
    private readonly List<PeerPublicKeys> _peers = new();
    private readonly List<string> _problems = new();

    /// <param name="refuseDemoBundles">
    /// Production: bundles named like the demo endpoints (<see cref="DemoProvisioner"/>) are not trusted.
    /// </param>
    public DirectoryTrustStore(string directory, bool refuseDemoBundles = false)
    {
        Load(directory, bundle =>
        {
            if (refuseDemoBundles && KeyPolicy.IsDemoEndpoint(bundle.Name))
                return ($"demo bundle '{bundle.Name}' is not trusted in production", null);
            return (null, bundle.ToPeerKeys());
        });
    }

    /// <summary>
    /// Certificate mode: only peers pinned over the cameras whose CertHello still passes <paramref name="validator"/>
    /// (expected peer, chain to the company CA, certificate valid today) are trusted. Key ceremony bundles (v1) and
    /// anything copied in by hand without a valid CertHello are listed as problems, never trusted.
    /// </summary>
    public DirectoryTrustStore(string directory, CertHelloValidator validator)
    {
        Load(directory, bundle =>
        {
            if (bundle.CertHelloFrame is null)
                return ($"'{bundle.Name}' has no certificate (a key ceremony bundle): not trusted in certificate mode", null);

            byte[] frame = Convert.FromBase64String(bundle.CertHelloFrame);
            if (!validator.TryVerify(frame, out var hello, out string reason, checkFreshness: false))
                return ($"'{bundle.Name}' is not trusted: {reason}", null);
            // The keys used are the verified CertHello's; the bundle's copies must agree, or the file was edited.
            if (Convert.ToBase64String(hello!.SigningSpki) != bundle.SigningPublicKeySpki ||
                Convert.ToBase64String(hello.AgreementSpki) != bundle.AgreementPublicKeySpki)
                return ($"'{bundle.Name}' is not trusted: its keys do not match its certificate hello", null);
            return (null, hello.ToPeerKeys());
        });
    }

    private void Load(string directory, Func<PublicKeyBundle, (string? Problem, PeerPublicKeys? Peer)> admit)
    {
        if (!Directory.Exists(directory)) return;
        foreach (var file in Directory.EnumerateFiles(directory, "*.json"))
        {
            try
            {
                var (problem, peer) = admit(PublicKeyBundle.Parse(File.ReadAllText(file)));
                if (peer is not null) _peers.Add(peer);
                else _problems.Add($"{Path.GetFileName(file)}: {problem}");
            }
            catch (Exception ex) when (ex is FormatException or JsonException or CryptographicException or IOException or UnauthorizedAccessException)
            {
                // A corrupt bundle must not take the store down; it is simply not trusted — and said so.
                _problems.Add($"{Path.GetFileName(file)}: not trusted, cannot be read ({ex.Message})");
            }
        }
    }

    public IReadOnlyList<PeerPublicKeys> Peers => _peers;

    /// <summary>Bundle files that were skipped, with the reason. Shown to the operator, never ignored silently.</summary>
    public IReadOnlyList<string> Problems => _problems;

    public PeerPublicKeys? FindBySigningKeyId(ReadOnlySpan<byte> signingKeyId)
    {
        foreach (var peer in _peers)
            if (signingKeyId.SequenceEqual(peer.SigningKeyId))
                return peer;
        return null;
    }

    public void Dispose()
    {
        foreach (var p in _peers) p.Dispose();
    }
}
