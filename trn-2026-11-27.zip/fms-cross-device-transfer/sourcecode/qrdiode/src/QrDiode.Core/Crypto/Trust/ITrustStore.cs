namespace QrDiode.Core.Crypto;

/// <summary>Lookup of trusted peer keys, loaded from imported bundles.</summary>
public interface ITrustStore
{
    /// <summary>Finds a peer whose signing key id matches, or null if untrusted.</summary>
    PeerPublicKeys? FindBySigningKeyId(ReadOnlySpan<byte> signingKeyId);
}
