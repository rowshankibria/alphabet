using System.Buffers.Binary;
using System.Security.Cryptography;
using QrDiode.Core.Framing;

namespace QrDiode.Core.Crypto;

/// <summary>The fields of a CertHello frame, read structurally (nothing verified yet).</summary>
public sealed record CertHelloFields(long TimestampUnixMs, byte[] CertificateDer, byte[] AgreementSpki);

/// <summary>
/// The certificate mode pairing frame: "this is my certificate, and this is my encryption (ECDH) key, signed by the
/// certificate's key". Each Sender shows its machine's CertHello while it has nothing to send; the other side's Receiver
/// verifies it (<see cref="CertHelloValidator"/>) and pins the peer. Only public keys cross: never a private key.
/// </summary>
public static class CertHello
{
    /// <summary>Domain label in front of the signed bytes: a CertHello signature can never pass as any other signature.</summary>
    public static ReadOnlySpan<byte> Domain => "QrDiode.v3.CertHello"u8;

    /// <summary>This machine's CertHello, stamped now (or at <paramref name="clock"/>'s time).</summary>
    public static byte[] Build(X509EndpointKeys keys, TimeProvider? clock = null) =>
        FrameWriter.WriteCertHelloFrame((clock ?? TimeProvider.System).GetUtcNow().ToUnixTimeMilliseconds(),
            keys.Certificate.RawData, keys.AgreementKey.ExportSubjectPublicKeyInfo(), keys.SigningKey);

    /// <summary>The frame's session tag: the first 8 bytes of SHA-256 over the certificate.</summary>
    public static byte[] SessionTag(ReadOnlySpan<byte> certificateDer) =>
        SHA256.HashData(certificateDer)[..FrameFormat.SessionTagSize];

    /// <summary>What the signature covers: <see cref="Domain"/> ‖ every frame byte before the signature.</summary>
    public static byte[] SignedData(ReadOnlySpan<byte> beforeSignature)
    {
        var data = new byte[Domain.Length + beforeSignature.Length];
        Domain.CopyTo(data);
        beforeSignature.CopyTo(data.AsSpan(Domain.Length));
        return data;
    }

    /// <summary>Reads a CertHello frame's fields. Structure and CRC only: <see cref="CertHelloValidator"/> decides whether to believe them.</summary>
    public static bool TryRead(ReadOnlySpan<byte> frame, out CertHelloFields? fields)
    {
        fields = null;
        if (!FrameParser.TryParse(frame, out var parsed, out _) || parsed.Type != FrameType.CertHello) return false;
        var payload = parsed.Payload;
        int certLen = BinaryPrimitives.ReadUInt16LittleEndian(payload.Slice(8, 2));
        fields = new CertHelloFields(
            BinaryPrimitives.ReadInt64LittleEndian(payload),
            payload.Slice(10, certLen).ToArray(),
            payload[(12 + certLen)..].ToArray());
        return true;
    }
}
