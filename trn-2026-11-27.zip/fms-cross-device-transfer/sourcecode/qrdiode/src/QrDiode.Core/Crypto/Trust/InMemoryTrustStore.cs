namespace QrDiode.Core.Crypto;

/// <summary>In-memory trust store for tests.</summary>
public sealed class InMemoryTrustStore : ITrustStore
{
    private readonly List<PeerPublicKeys> _peers = new();
    public void Add(PeerPublicKeys peer) => _peers.Add(peer);

    public PeerPublicKeys? FindBySigningKeyId(ReadOnlySpan<byte> signingKeyId)
    {
        foreach (var peer in _peers)
            if (signingKeyId.SequenceEqual(peer.SigningKeyId))
                return peer;
        return null;
    }
}
