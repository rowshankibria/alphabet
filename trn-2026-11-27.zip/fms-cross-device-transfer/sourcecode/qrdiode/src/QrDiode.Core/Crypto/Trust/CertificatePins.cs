namespace QrDiode.Core.Crypto;

/// <summary>
/// Certificate mode: where the Receiver keeps the peer it paired with over the cameras — one v2 bundle per peer,
/// <c>x509-&lt;name&gt;.json</c> in the trust folder, carrying the peer's verified CertHello. The Sender on the same machine
/// reads the same folder (<see cref="DirectoryTrustStore"/>, which verifies every bundle again).
/// </summary>
public static class CertificatePins
{
    public const string FilePrefix = "x509-";

    public static string PathFor(string trustDirectory, string peerName) =>
        Path.Combine(trustDirectory, $"{FilePrefix}{string.Concat(peerName.Select(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '.' ? c : '_'))}.json");

    /// <summary>
    /// Pins a verified peer. The same certificate and key again: nothing is written. Other keys for the same peer (a
    /// renewed certificate, a new encryption key) replace the pin only when their CertHello is newer, so a recording of an
    /// older CertHello held up to the camera can never roll a peer back.
    /// </summary>
    public static PinOutcome Save(string trustDirectory, VerifiedPeer hello, TimeProvider? clock = null)
    {
        Directory.CreateDirectory(trustDirectory);
        string path = PathFor(trustDirectory, hello.Name);
        bool existed = File.Exists(path);
        if (existed && TryReadPinned(path, out var pinned, out long pinnedTimestamp))
        {
            if (pinned!.SigningPublicKeySpki == Convert.ToBase64String(hello.SigningSpki) &&
                pinned.AgreementPublicKeySpki == Convert.ToBase64String(hello.AgreementSpki))
                return PinOutcome.Unchanged;
            if (pinnedTimestamp >= hello.TimestampUnixMs)
                return PinOutcome.Older;
        }

        // Write next to it, then swap: a crash never leaves half a trust bundle.
        string temp = path + ".tmp";
        File.WriteAllText(temp, PublicKeyBundle.FromPeer(hello, clock).ToJson());
        File.Move(temp, path, overwrite: true);
        return existed ? PinOutcome.Replaced : PinOutcome.Pinned;
    }

    /// <summary>Removes every pinned peer (Certificate:RequireHandshakeOnStart). Returns how many there were.</summary>
    public static int Forget(string trustDirectory)
    {
        if (!Directory.Exists(trustDirectory)) return 0;
        int removed = 0;
        foreach (var file in Directory.EnumerateFiles(trustDirectory, $"{FilePrefix}*.json"))
        {
            File.Delete(file);
            removed++;
        }
        return removed;
    }

    private static bool TryReadPinned(string path, out PublicKeyBundle? bundle, out long timestampUnixMs)
    {
        bundle = null;
        timestampUnixMs = 0;
        try
        {
            bundle = PublicKeyBundle.Parse(File.ReadAllText(path));
            if (bundle.CertHelloFrame is null || !CertHello.TryRead(Convert.FromBase64String(bundle.CertHelloFrame), out var fields))
                return false;
            timestampUnixMs = fields!.TimestampUnixMs;
            return true;
        }
        catch (Exception ex) when (ex is FormatException or System.Text.Json.JsonException or IOException or UnauthorizedAccessException)
        {
            return false; // unreadable: the verified peer replaces it
        }
    }
}
