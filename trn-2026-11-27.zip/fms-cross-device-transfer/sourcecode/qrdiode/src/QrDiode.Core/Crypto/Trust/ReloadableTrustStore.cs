namespace QrDiode.Core.Crypto;

/// <summary>
/// A trust store that can be swapped while a <c>ReceiveEngine</c> runs: certificate mode pins a peer mid-run, and the
/// engine must see it without being rebuilt. Replaced stores are not disposed here (a frame on the camera thread may
/// still hold one of their keys); the owner disposes them when the run ends.
/// </summary>
public sealed class ReloadableTrustStore(ITrustStore initial) : ITrustStore
{
    private volatile ITrustStore _current = initial;

    public ITrustStore Current => _current;

    public void Replace(ITrustStore next) => _current = next;

    public PeerPublicKeys? FindBySigningKeyId(ReadOnlySpan<byte> signingKeyId) => _current.FindBySigningKeyId(signingKeyId);
}
