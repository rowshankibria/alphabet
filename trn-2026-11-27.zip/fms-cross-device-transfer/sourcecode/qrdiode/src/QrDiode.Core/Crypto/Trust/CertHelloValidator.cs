using System.Runtime.Versioning;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using QrDiode.Core.Framing;

namespace QrDiode.Core.Crypto;

/// <summary>
/// Decides whether a CertHello comes from the one peer this lane may pair with. All of these must hold, checked offline
/// (there is no network across the air gap, so no CRL/OCSP and no certificate downloads):
/// structure and CRC → session tag = the certificate → the certificate is <see cref="ExpectedPeerSubject"/> (and the
/// pinned thumbprint, when set) → the certificate's key signed the frame (low-S) → the timestamp is fresh → the
/// certificate is a valid ECDSA P-256 end-entity certificate that chains to the pinned company CA → the ECDH key is P-256.
/// A certificate from the same CA with another name is refused: being a company machine is not enough.
/// The certificate key exchange's <see cref="IPairingVerifier"/>.
/// </summary>
public sealed class CertHelloValidator : IPairingVerifier
{
    /// <summary>The replay guard's default window: two kiosk clocks may drift this far apart.</summary>
    public static readonly TimeSpan DefaultFreshness = TimeSpan.FromHours(48);

    private const string P256Oid = "1.2.840.10045.3.1.7";

    private readonly X509Certificate2 _trustedCa;
    private readonly X509Certificate2Collection _intermediates = [];
    private readonly string _expectedPeerThumbprint;
    private readonly TimeSpan _freshness;
    private readonly TimeProvider _clock;

    public string ExpectedPeerSubject { get; }
    public string TrustedCaThumbprint => _trustedCa.Thumbprint;
    public FrameType FrameType => FrameType.CertHello;

    bool IPairingVerifier.TryVerify(ReadOnlySpan<byte> frame, out VerifiedPeer? peer, out string reason) =>
        TryVerify(frame, out peer, out reason);

    /// <param name="trustedCa">The company Root or Issuing CA. Takes ownership.</param>
    /// <param name="intermediates">CA certificates that may sit between a peer and <paramref name="trustedCa"/>. Takes ownership.</param>
    public CertHelloValidator(X509Certificate2 trustedCa, string expectedPeerSubject, string? expectedPeerThumbprint = null,
        TimeSpan? freshness = null, IEnumerable<X509Certificate2>? intermediates = null, TimeProvider? clock = null)
    {
        if (string.IsNullOrWhiteSpace(expectedPeerSubject))
            throw new ArgumentException("The expected peer must be named.", nameof(expectedPeerSubject));
        _trustedCa = trustedCa;
        ExpectedPeerSubject = expectedPeerSubject.Trim();
        _expectedPeerThumbprint = CertificateOptions.NormalizeThumbprint(expectedPeerThumbprint ?? "");
        _freshness = freshness ?? DefaultFreshness;
        _clock = clock ?? TimeProvider.System;
        if (intermediates is not null) _intermediates.AddRange(intermediates.ToArray());
    }

    /// <summary>
    /// The validator for this machine's settings: the CA by <see cref="CertificateOptions.TrustedCaThumbprint"/> from the
    /// Root or Intermediate store (LocalMachine, then CurrentUser), and every Intermediate CA for chain building.
    /// </summary>
    /// <exception cref="InvalidOperationException">The trusted CA is not installed on this machine.</exception>
    [SupportedOSPlatform("windows")]
    public static CertHelloValidator FromStore(CertificateOptions options, TimeSpan? freshness = null)
    {
        string caThumbprint = CertificateOptions.NormalizeThumbprint(options.TrustedCaThumbprint);
        X509Certificate2? trustedCa = null;
        var intermediates = new List<X509Certificate2>();
        foreach (var location in new[] { StoreLocation.LocalMachine, StoreLocation.CurrentUser })
        {
            foreach (var storeName in new[] { StoreName.Root, StoreName.CertificateAuthority })
            {
                using var store = new X509Store(storeName, location);
                try { store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly); }
                catch (CryptographicException) { continue; }
                foreach (var cert in store.Certificates)
                {
                    if (trustedCa is null && cert.Thumbprint.Equals(caThumbprint, StringComparison.OrdinalIgnoreCase))
                        trustedCa = cert;
                    else if (storeName == StoreName.CertificateAuthority)
                        intermediates.Add(cert);
                    else
                        cert.Dispose();
                }
            }
        }

        if (trustedCa is null)
        {
            foreach (var c in intermediates) c.Dispose();
            throw new InvalidOperationException(
                $"The trusted CA {caThumbprint} (Certificate:TrustedCaThumbprint) is not installed on this machine. " +
                "Import it into Trusted Root Certification Authorities (or Intermediate Certification Authorities) in certlm.msc.");
        }
        return new CertHelloValidator(trustedCa, options.ExpectedPeerSubject, options.ExpectedPeerThumbprint, freshness, intermediates);
    }

    /// <summary>
    /// Verifies one CertHello frame. <paramref name="checkFreshness"/> is false only for a peer pinned earlier (loading the
    /// trust store) or carried by hand (KeyCeremony import-hello): its age then says nothing about a replay.
    /// </summary>
    public bool TryVerify(ReadOnlySpan<byte> frame, out VerifiedPeer? hello, out string reason, bool checkFreshness = true)
    {
        hello = null;
        if (!FrameParser.TryParse(frame, out var parsed, out var parseError) || parsed.Type != FrameType.CertHello)
        {
            reason = parseError == FrameParseError.None ? "not a CertHello frame" : $"frame cannot be read ({parseError})";
            return false;
        }
        CertHello.TryRead(frame, out var fields);

        if (!parsed.SessionTag.SequenceEqual(CertHello.SessionTag(fields!.CertificateDer)))
        {
            reason = "the frame's session tag does not belong to its certificate";
            return false;
        }

        X509Certificate2 certificate;
        try
        {
            certificate = X509CertificateLoader.LoadCertificate(fields.CertificateDer);
        }
        catch (CryptographicException)
        {
            reason = "the certificate cannot be read";
            return false;
        }

        using (certificate)
        {
            string name = certificate.GetNameInfo(X509NameType.SimpleName, false);
            if (!NameMatches(certificate, ExpectedPeerSubject))
            {
                reason = $"certificate '{name}' is not the expected peer '{ExpectedPeerSubject}'";
                return false;
            }
            if (_expectedPeerThumbprint.Length > 0 &&
                !certificate.Thumbprint.Equals(_expectedPeerThumbprint, StringComparison.OrdinalIgnoreCase) &&
                !certificate.GetCertHashString(HashAlgorithmName.SHA256).Equals(_expectedPeerThumbprint, StringComparison.OrdinalIgnoreCase))
            {
                reason = $"certificate '{name}' ({certificate.Thumbprint}) is not the pinned certificate {_expectedPeerThumbprint}";
                return false;
            }

            using var signingKey = certificate.GetECDsaPublicKey();
            if (signingKey is null || !IsP256(signingKey))
            {
                reason = $"certificate '{name}' does not have an ECDSA P-256 key";
                return false;
            }
            if (!LowSSignature.Verify(signingKey, CertHello.SignedData(parsed.SignatureCovered), parsed.Signature))
            {
                reason = $"the signature by certificate '{name}' does not verify (tampered frame or wrong key)";
                return false;
            }

            if (checkFreshness)
            {
                long ageMs = Math.Abs(_clock.GetUtcNow().ToUnixTimeMilliseconds() - fields.TimestampUnixMs);
                if (ageMs > _freshness.TotalMilliseconds)
                {
                    reason = $"CertHello from '{name}' is stale (stamped {DateTimeOffset.FromUnixTimeMilliseconds(fields.TimestampUnixMs):u}; " +
                             "a recording, or the two clocks are apart)";
                    return false;
                }
            }

            if (CheckCertificate(certificate) is { } problem)
            {
                reason = problem;
                return false;
            }

            byte[] agreementSpki;
            try
            {
                using var agreement = ECDiffieHellman.Create();
                agreement.ImportSubjectPublicKeyInfo(fields.AgreementSpki, out int read);
                if (read != fields.AgreementSpki.Length || !IsP256(agreement))
                {
                    reason = "the encryption key is not an ECDH P-256 key";
                    return false;
                }
                agreementSpki = agreement.ExportSubjectPublicKeyInfo();
            }
            catch (CryptographicException)
            {
                reason = "the encryption key cannot be read";
                return false;
            }

            byte[] signingSpki = signingKey.ExportSubjectPublicKeyInfo();
            var details = new Dictionary<string, string>
            {
                ["subject"] = certificate.Subject,
                ["thumbprint"] = certificate.Thumbprint,
                ["notAfter"] = certificate.NotAfter.ToUniversalTime().ToString("u"),
            };
            hello = new VerifiedPeer(name, certificate.Thumbprint, fields.TimestampUnixMs, signingSpki, agreementSpki,
                KeyId.FromSubjectPublicKeyInfo(signingSpki), KeyId.FromSubjectPublicKeyInfo(agreementSpki), frame.ToArray(), details);
            reason = "";
            return true;
        }
    }

    /// <summary>
    /// The checks a certificate needs whoever it names: an end-entity ECDSA P-256 certificate allowed to sign, valid now and
    /// chaining to the pinned CA. Null when it passes, else why not. KeyCeremony check-cert runs it on this machine's own.
    /// </summary>
    public string? CheckCertificate(X509Certificate2 certificate)
    {
        string name = certificate.GetNameInfo(X509NameType.SimpleName, false);
        foreach (var extension in certificate.Extensions)
        {
            if (extension is X509BasicConstraintsExtension { CertificateAuthority: true })
                return $"certificate '{name}' is a CA certificate, not a machine certificate";
            if (extension is X509KeyUsageExtension usage && !usage.KeyUsages.HasFlag(X509KeyUsageFlags.DigitalSignature))
                return $"certificate '{name}' may not sign (key usage {usage.KeyUsages})";
        }
        using (var key = certificate.GetECDsaPublicKey())
        {
            if (key is null || !IsP256(key)) return $"certificate '{name}' does not have an ECDSA P-256 key";
        }

        using var chain = new X509Chain();
        var policy = chain.ChainPolicy;
        policy.TrustMode = X509ChainTrustMode.CustomRootTrust;
        policy.CustomTrustStore.Add(_trustedCa);
        policy.ExtraStore.Add(_trustedCa);
        policy.ExtraStore.AddRange(_intermediates);
        // Offline by design: islanding has no route to a CRL or OCSP responder, and nothing may be fetched.
        policy.RevocationMode = X509RevocationMode.NoCheck;
        policy.DisableCertificateDownloads = true;
        policy.VerificationTime = _clock.GetLocalNow().DateTime;
        policy.VerificationTimeIgnored = false;
        chain.Build(certificate);

        // The pinned CA may be the Root or an Issuing CA. Everything from the peer up to it must be clean; what lies above
        // it (an untrusted or missing root, when an Issuing CA is pinned) does not matter.
        int anchor = -1;
        for (int i = 1; i < chain.ChainElements.Count; i++)
        {
            if (chain.ChainElements[i].Certificate.Thumbprint.Equals(_trustedCa.Thumbprint, StringComparison.OrdinalIgnoreCase))
            {
                anchor = i;
                break;
            }
        }
        if (anchor < 0)
            return $"certificate '{name}' does not chain to the trusted CA {_trustedCa.Thumbprint} ({_trustedCa.GetNameInfo(X509NameType.SimpleName, false)})";

        for (int i = 0; i <= anchor; i++)
        {
            var element = chain.ChainElements[i];
            foreach (var status in element.ChainElementStatus)
            {
                if (status.Status is X509ChainStatusFlags.NoError or X509ChainStatusFlags.UntrustedRoot or X509ChainStatusFlags.PartialChain)
                    continue;
                return $"certificate chain of '{name}': {status.Status} at '{element.Certificate.GetNameInfo(X509NameType.SimpleName, false)}' ({status.StatusInformation.Trim()})";
            }
        }
        return null;
    }

    /// <summary>
    /// True when <paramref name="name"/> is the certificate's CN, one of its SAN DNS names, or its whole subject
    /// ("CN=…, O=…"). Case-insensitive, exact: no wildcards.
    /// </summary>
    public static bool NameMatches(X509Certificate2 certificate, string name)
    {
        string wanted = name.Trim();
        if (wanted.Length == 0) return false;
        if (certificate.GetNameInfo(X509NameType.SimpleName, false).Equals(wanted, StringComparison.OrdinalIgnoreCase)) return true;
        if (certificate.Subject.Equals(wanted, StringComparison.OrdinalIgnoreCase)) return true;
        foreach (var extension in certificate.Extensions)
        {
            if (extension.Oid?.Value != "2.5.29.17") continue;
            var san = extension as X509SubjectAlternativeNameExtension ?? new X509SubjectAlternativeNameExtension(extension.RawData, extension.Critical);
            if (san.EnumerateDnsNames().Any(dns => dns.Equals(wanted, StringComparison.OrdinalIgnoreCase))) return true;
        }
        return false;
    }

    /// <summary>A named NIST P-256 key: the only curve QrDiode signs and agrees keys on.</summary>
    public static bool IsP256(ECAlgorithm key)
    {
        if (key.KeySize != 256) return false;
        var curve = key.ExportParameters(false).Curve;
        if (!curve.IsNamed) return false;
        return curve.Oid.Value == P256Oid ||
               curve.Oid.FriendlyName is "nistP256" or "ECDSA_P256" or "ECDH_P256" or "secp256r1";
    }

    public void Dispose()
    {
        _trustedCa.Dispose();
        foreach (var c in _intermediates) c.Dispose();
    }
}
