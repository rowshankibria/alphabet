using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>
/// The two keys of one session, both from one ECDH agreement: <see cref="PayloadKey"/> seals the
/// payload (AES-256-GCM), <see cref="FrameKey"/> authenticates every data frame (see
/// <c>Framing.FrameMac</c>). Callers zero them with <see cref="Clear"/> when the session is over.
/// </summary>
public sealed record SessionKeys(byte[] PayloadKey, byte[] FrameKey)
{
    public void Clear()
    {
        CryptographicOperations.ZeroMemory(PayloadKey);
        CryptographicOperations.ZeroMemory(FrameKey);
    }
}

/// <summary>
/// Authenticated-encryption envelope: static-static ECDH P-256 → HKDF-SHA256 → AES-256-GCM.
/// The AAD binds the ciphertext to the session identity carried in the signed manifest,
/// so a ciphertext can never be paired with a foreign manifest (and vice versa).
/// </summary>
public static class Envelope
{
    public const int SaltSize = 32;
    public const int NonceSize = 12;
    public const int TagSize = 16;
    public const int KeySize = 32;

    // Separate HKDF labels give independent keys from one secret: knowing a frame key (it is used on
    // every frame) says nothing about the payload key.
    private static readonly byte[] PayloadInfo = "QrDiode.v2.payload"u8.ToArray();
    private static readonly byte[] FrameInfo = "QrDiode.v2.frame"u8.ToArray();

    /// <summary>
    /// AAD = sessionGuid(16) ‖ salt(32) ‖ counter(8) ‖ counterRunId(16) ‖ senderSigKeyId(8) ‖ receiverKexKeyId(8).
    /// </summary>
    public static byte[] BuildAad(Guid sessionId, ReadOnlySpan<byte> salt, ulong counter, Guid counterRunId,
        ReadOnlySpan<byte> senderSigningKeyId, ReadOnlySpan<byte> receiverAgreementKeyId)
    {
        if (salt.Length != SaltSize) throw new ArgumentException("Bad salt length.", nameof(salt));
        if (senderSigningKeyId.Length != KeyId.Size) throw new ArgumentException("Bad key id length.", nameof(senderSigningKeyId));
        if (receiverAgreementKeyId.Length != KeyId.Size) throw new ArgumentException("Bad key id length.", nameof(receiverAgreementKeyId));

        var aad = new byte[16 + SaltSize + 8 + 16 + KeyId.Size + KeyId.Size];
        var span = aad.AsSpan();
        sessionId.TryWriteBytes(span[..16]);
        salt.CopyTo(span[16..]);
        System.Buffers.Binary.BinaryPrimitives.WriteUInt64LittleEndian(span.Slice(16 + SaltSize, 8), counter);
        counterRunId.TryWriteBytes(span.Slice(16 + SaltSize + 8, 16));
        senderSigningKeyId.CopyTo(span[(16 + SaltSize + 8 + 16)..]);
        receiverAgreementKeyId.CopyTo(span[(16 + SaltSize + 8 + 16 + KeyId.Size)..]);
        return aad;
    }

    /// <summary>Both session keys from one ECDH: HKDF-Extract once, then one Expand per label.</summary>
    public static SessionKeys DeriveSessionKeys(ECDiffieHellman ownAgreementKey, ECDiffieHellmanPublicKey peerPublicKey,
        ReadOnlySpan<byte> salt, Guid sessionId)
    {
        byte[] sharedSecret = ownAgreementKey.DeriveRawSecretAgreement(peerPublicKey);
        byte[] prk = HKDF.Extract(HashAlgorithmName.SHA256, sharedSecret, salt.ToArray());
        try
        {
            return new SessionKeys(
                HKDF.Expand(HashAlgorithmName.SHA256, prk, KeySize, Info(PayloadInfo, sessionId)),
                HKDF.Expand(HashAlgorithmName.SHA256, prk, KeySize, Info(FrameInfo, sessionId)));
        }
        finally
        {
            CryptographicOperations.ZeroMemory(sharedSecret);
            CryptographicOperations.ZeroMemory(prk);
        }
    }

    private static byte[] Info(byte[] label, Guid sessionId)
    {
        var info = new byte[label.Length + 16];
        label.CopyTo(info, 0);
        sessionId.TryWriteBytes(info.AsSpan(label.Length, 16));
        return info;
    }

    /// <summary>Encrypts. Output = ciphertext ‖ 16-byte GCM tag.</summary>
    public static byte[] Seal(ReadOnlySpan<byte> plaintext, byte[] key, ReadOnlySpan<byte> nonce, ReadOnlySpan<byte> aad)
    {
        var output = new byte[plaintext.Length + TagSize];
        using var gcm = new AesGcm(key, TagSize);
        gcm.Encrypt(nonce, plaintext, output.AsSpan(0, plaintext.Length), output.AsSpan(plaintext.Length, TagSize), aad);
        return output;
    }

    /// <summary>Decrypts and authenticates. Throws <see cref="AuthenticationTagMismatchException"/> on any tamper.</summary>
    public static byte[] Open(ReadOnlySpan<byte> ciphertextWithTag, byte[] key, ReadOnlySpan<byte> nonce, ReadOnlySpan<byte> aad)
    {
        if (ciphertextWithTag.Length < TagSize) throw new CryptographicException("Ciphertext too short.");
        var plaintext = new byte[ciphertextWithTag.Length - TagSize];
        using var gcm = new AesGcm(key, TagSize);
        gcm.Decrypt(nonce,
            ciphertextWithTag[..^TagSize],
            ciphertextWithTag[^TagSize..],
            plaintext,
            aad);
        return plaintext;
    }
}
