using System.Buffers.Binary;
using System.Runtime.Versioning;
using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>
/// One reserved counter value. <see cref="StartedNewRun"/> is true when this value opened a new run
/// (the counter file was missing, unreadable or exhausted), so the host can record it.
/// </summary>
public readonly record struct CounterReservation(Guid RunId, ulong Counter, bool StartedNewRun);

/// <summary>
/// Sender-side monotonic counter, persisted DPAPI-protected (current user scope), together with the
/// id of its run. The counter is part of the anti-replay contract: within a run it must never move
/// backwards, so it is incremented and flushed BEFORE a session is created with its value.
///
/// A run ends only when its file is gone or unreadable (a rebuilt kiosk profile, another Windows
/// user, a corrupt file). The next reservation then starts a new run at 1 instead of failing, and
/// the receiver — which keeps one watermark per sender key and run — accepts it. Replays stay
/// impossible: every session is still signed fresh and an old run's watermark is kept.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class CounterStore
{
    private static readonly byte[] Entropy = "QrDiode.counter.v2"u8.ToArray();
    private const int StateSize = 16 + 8; // run id + counter
    private readonly string _path;
    private readonly object _lock = new();

    public CounterStore(string path)
    {
        _path = path;
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
    }

    /// <summary>Atomically reserves and returns the next counter value (a new run starts at 1).</summary>
    public CounterReservation Next()
    {
        lock (_lock)
        {
            var (run, current) = TryRead();
            bool newRun = run == Guid.Empty || current == ulong.MaxValue;
            if (newRun)
            {
                run = Guid.NewGuid();
                current = 0;
            }
            ulong next = current + 1;
            Write(run, next);
            return new CounterReservation(run, next, newRun);
        }
    }

    /// <summary>The last reserved value, or an empty run if nothing was reserved yet.</summary>
    public CounterReservation Peek()
    {
        lock (_lock)
        {
            var (run, current) = TryRead();
            return new CounterReservation(run, current, false);
        }
    }

    /// <summary>Guid.Empty when there is no usable state: the next reservation opens a new run.</summary>
    private (Guid Run, ulong Counter) TryRead()
    {
        if (!File.Exists(_path)) return (Guid.Empty, 0);
        try
        {
            byte[] plain = ProtectedData.Unprotect(File.ReadAllBytes(_path), Entropy, DataProtectionScope.CurrentUser);
            if (plain.Length != StateSize) return (Guid.Empty, 0);
            return (new Guid(plain.AsSpan(0, 16)), BinaryPrimitives.ReadUInt64LittleEndian(plain.AsSpan(16)));
        }
        catch (Exception ex) when (ex is CryptographicException or IOException or UnauthorizedAccessException)
        {
            // Another user's file, a v1 file (different entropy) or a corrupt one: start a new run.
            return (Guid.Empty, 0);
        }
    }

    private void Write(Guid run, ulong value)
    {
        var plain = new byte[StateSize];
        run.TryWriteBytes(plain.AsSpan(0, 16));
        BinaryPrimitives.WriteUInt64LittleEndian(plain.AsSpan(16), value);
        byte[] protectedBytes = ProtectedData.Protect(plain, Entropy, DataProtectionScope.CurrentUser);

        // Write-temp-then-rename so a crash never leaves a torn state file.
        string tmp = _path + ".tmp";
        using (var stream = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None))
        {
            stream.Write(protectedBytes);
            stream.Flush(flushToDisk: true);
        }
        File.Move(tmp, _path, overwrite: true);
    }
}
