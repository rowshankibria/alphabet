using System.Numerics;
using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>
/// ECDSA P-256 signatures in one form only: IEEE P1363 r‖s (64 bytes) with s ≤ n/2. A signature (r, s) and (r, n − s)
/// both verify, so the signer always picks the low-S one and the verifier refuses the other: one message has exactly
/// one valid signature. Used for the transfer manifest and the CertHello frame.
/// </summary>
public static class LowSSignature
{
    public const int Size = 64;

    // P-256 group order n.
    private static readonly BigInteger CurveOrder = new(
        Convert.FromHexString("FFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551"),
        isUnsigned: true, isBigEndian: true);
    private static readonly BigInteger HalfOrder = CurveOrder >> 1;

    public static byte[] Sign(ECDsa signingKey, ReadOnlySpan<byte> data)
    {
        byte[] signature = signingKey.SignData(data, HashAlgorithmName.SHA256);
        var s = new BigInteger(signature.AsSpan(32, 32), isUnsigned: true, isBigEndian: true);
        if (s > HalfOrder) WriteScalar(CurveOrder - s, signature.AsSpan(32, 32));
        return signature;
    }

    /// <summary>True only for a 64-byte low-S signature that verifies over exactly these bytes.</summary>
    public static bool Verify(ECDsa publicKey, ReadOnlySpan<byte> data, ReadOnlySpan<byte> signature)
    {
        if (signature.Length != Size) return false;
        var s = new BigInteger(signature.Slice(32, 32), isUnsigned: true, isBigEndian: true);
        if (s > HalfOrder) return false;
        return publicKey.VerifyData(data, signature, HashAlgorithmName.SHA256);
    }

    private static void WriteScalar(BigInteger value, Span<byte> destination)
    {
        destination.Clear();
        byte[] bytes = value.ToByteArray(isUnsigned: true, isBigEndian: true);
        bytes.CopyTo(destination[(destination.Length - bytes.Length)..]);
    }
}
