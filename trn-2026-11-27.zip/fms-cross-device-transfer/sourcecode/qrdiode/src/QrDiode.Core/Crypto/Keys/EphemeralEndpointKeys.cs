using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>In-memory keys for tests and loopback benches. Never persisted.</summary>
public sealed class EphemeralEndpointKeys : IEndpointKeys
{
    public ECDsa SigningKey { get; }
    public ECDiffieHellman AgreementKey { get; }
    public byte[] SigningKeyId { get; }
    public byte[] AgreementKeyId { get; }

    public EphemeralEndpointKeys()
    {
        SigningKey = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        AgreementKey = ECDiffieHellman.Create(ECCurve.NamedCurves.nistP256);
        SigningKeyId = KeyId.FromPublicKey(SigningKey);
        AgreementKeyId = KeyId.FromPublicKey(AgreementKey);
    }

    public void Dispose()
    {
        SigningKey.Dispose();
        AgreementKey.Dispose();
    }
}
