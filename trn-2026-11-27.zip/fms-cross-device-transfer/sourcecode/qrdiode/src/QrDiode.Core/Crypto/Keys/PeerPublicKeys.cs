using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>A peer's public keys as imported from a trust bundle.</summary>
public sealed class PeerPublicKeys : IDisposable
{
    public required string Name { get; init; }
    public required ECDsa SigningPublicKey { get; init; }
    public required ECDiffieHellman AgreementPublicKey { get; init; }
    public required byte[] SigningKeyId { get; init; }
    public required byte[] AgreementKeyId { get; init; }

    public void Dispose()
    {
        SigningPublicKey.Dispose();
        AgreementPublicKey.Dispose();
    }
}
