using System.Runtime.Versioning;
using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>
/// Endpoint keys persisted as named, non-exportable keys in Windows CNG.
/// Prefers the Platform Crypto Provider (TPM-backed); falls back to the software KSP.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class CngEndpointKeys : IEndpointKeys
{
    internal const string PlatformProvider = "Microsoft Platform Crypto Provider";

    public ECDsa SigningKey { get; }
    public ECDiffieHellman AgreementKey { get; }
    public byte[] SigningKeyId { get; }
    public byte[] AgreementKeyId { get; }
    public bool IsTpmBacked { get; }

    private CngEndpointKeys(ECDsa signing, ECDiffieHellman agreement, bool tpm)
    {
        SigningKey = signing;
        AgreementKey = agreement;
        IsTpmBacked = tpm;
        SigningKeyId = KeyId.FromPublicKey(signing);
        AgreementKeyId = KeyId.FromPublicKey(agreement);
    }

    public static bool Exists(string endpointName)
        => KeyExists(SignKeyName(endpointName)) && KeyExists(KexKeyName(endpointName));

    /// <summary>Opens existing named keys, or creates them (non-exportable) on first use.</summary>
    /// <param name="requireTpm">
    /// Production: never fall back to software keys — refuse existing software keys and fail when the
    /// TPM cannot create new ones. The message says what to do.
    /// </param>
    public static CngEndpointKeys OpenOrCreate(string endpointName, bool preferTpm = true, bool requireTpm = false)
    {
        ValidateName(endpointName);
        var (signCng, tpm1) = OpenOrCreateKey(SignKeyName(endpointName), CngAlgorithm.ECDsaP256, preferTpm || requireTpm, requireTpm);
        CngKey kexCng;
        bool tpm2;
        try
        {
            (kexCng, tpm2) = OpenOrCreateKey(KexKeyName(endpointName), CngAlgorithm.ECDiffieHellmanP256, preferTpm || requireTpm, requireTpm);
        }
        catch
        {
            signCng.Dispose();
            throw;
        }

        if (requireTpm && !(tpm1 && tpm2))
        {
            signCng.Dispose();
            kexCng.Dispose();
            throw new InvalidOperationException(
                $"The keys of endpoint '{endpointName}' are software keys, and production requires TPM-backed keys. " +
                $"Delete them (KeyCeremony delete {endpointName} --yes) and run KeyCeremony init on a machine with a TPM, " +
                "then repeat the key exchange with the other side.");
        }
        return new CngEndpointKeys(new ECDsaCng(signCng), new ECDiffieHellmanCng(kexCng), tpm1 && tpm2);
    }

    /// <summary>
    /// Certificate mode: the named, non-exportable ECDH key that goes with this machine's certificate (the certificate's
    /// own key can only sign). Created on first use under the same TPM rules as the endpoint keys.
    /// </summary>
    internal static (ECDiffieHellman Key, bool Tpm) OpenOrCreateAgreementKey(string endpointName, bool requireTpm)
    {
        ValidateName(endpointName);
        var (cng, tpm) = OpenOrCreateKey(KexKeyName(endpointName), CngAlgorithm.ECDiffieHellmanP256, preferTpm: true, requireTpm);
        if (requireTpm && !tpm)
        {
            cng.Dispose();
            throw new InvalidOperationException(
                $"The encryption key '{KexKeyName(endpointName)}' is a software key, and production requires TPM-backed keys. " +
                $"Delete it (KeyCeremony delete {endpointName} --yes) on a machine with a TPM and start again.");
        }
        return (new ECDiffieHellmanCng(cng), tpm);
    }

    public static void Delete(string endpointName)
    {
        ValidateName(endpointName);
        foreach (var name in new[] { SignKeyName(endpointName), KexKeyName(endpointName) })
        {
            foreach (var provider in new[] { CngProvider.MicrosoftSoftwareKeyStorageProvider, Platform })
            {
                if (!ExistsIn(name, provider)) continue;
                using var key = CngKey.Open(name, provider);
                key.Delete();
            }
        }
    }

    private static (CngKey Key, bool Tpm) OpenOrCreateKey(string name, CngAlgorithm algorithm, bool preferTpm, bool requireTpm)
    {
        // CngKey.Exists/Open without a provider look only in the software provider, never in the TPM: ask each one.
        // The software provider first, so a key that already exists there stays the key the other side trusts.
        if (ExistsIn(name, CngProvider.MicrosoftSoftwareKeyStorageProvider))
            return (CngKey.Open(name, CngProvider.MicrosoftSoftwareKeyStorageProvider), false);
        if (ExistsIn(name, Platform))
            return (CngKey.Open(name, Platform), true);

        var creation = new CngKeyCreationParameters
        {
            ExportPolicy = CngExportPolicies.None, // non-exportable, by design
            KeyUsage = CngKeyUsages.AllUsages,
        };

        if (preferTpm)
        {
            try
            {
                creation.Provider = Platform;
                return (CngKey.Create(algorithm, name, creation), true);
            }
            catch (CryptographicException ex) when (requireTpm)
            {
                throw new InvalidOperationException(
                    $"This machine's TPM could not create the key '{name}' ({ex.Message}). Production requires TPM-backed keys.", ex);
            }
            catch (CryptographicException)
            {
                // No TPM / PCP unavailable — fall through to software KSP.
            }
        }

        creation.Provider = CngProvider.MicrosoftSoftwareKeyStorageProvider;
        return (CngKey.Create(algorithm, name, creation), false);
    }

    private static string SignKeyName(string endpointName) => $"QrDiode.{endpointName}.sign";
    private static string KexKeyName(string endpointName) => $"QrDiode.{endpointName}.kex";

    private static readonly CngProvider Platform = new(PlatformProvider);

    private static bool KeyExists(string name) =>
        ExistsIn(name, CngProvider.MicrosoftSoftwareKeyStorageProvider) || ExistsIn(name, Platform);

    private static bool ExistsIn(string name, CngProvider provider)
    {
        try
        {
            return CngKey.Exists(name, provider);
        }
        catch (CryptographicException)
        {
            return false; // no TPM, or the Platform Crypto Provider is unavailable
        }
    }

    private static void ValidateName(string name)
    {
        if (string.IsNullOrWhiteSpace(name) || name.Length > 64 || name.Any(c => !char.IsAsciiLetterOrDigit(c) && c != '-' && c != '_'))
            throw new ArgumentException("Endpoint name must be 1-64 chars of [A-Za-z0-9-_].", nameof(name));
    }

    public void Dispose()
    {
        SigningKey.Dispose();
        AgreementKey.Dispose();
    }
}
