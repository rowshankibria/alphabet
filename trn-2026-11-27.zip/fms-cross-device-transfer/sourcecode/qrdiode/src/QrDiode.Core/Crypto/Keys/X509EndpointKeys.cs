using System.Runtime.Versioning;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace QrDiode.Core.Crypto;

/// <summary>
/// Certificate mode endpoint keys: the signing key is this machine's CA-issued ECDSA P-256 certificate in the Windows
/// Certificate Store; the encryption (ECDH) key is a named, non-exportable CNG key that goes with it, because a
/// certificate's ECDSA key cannot also do key agreement. The CertHello frame binds the two (the certificate signs the
/// ECDH public key), so the other side needs only the company CA to trust both.
/// </summary>
public sealed class X509EndpointKeys : IEndpointKeys
{
    public X509Certificate2 Certificate { get; }
    public ECDsa SigningKey { get; }
    public ECDiffieHellman AgreementKey { get; }
    public byte[] SigningKeyId { get; }
    public byte[] AgreementKeyId { get; }

    /// <summary>Both private keys live in the TPM (Platform Crypto Provider).</summary>
    public bool IsTpmBacked { get; }

    /// <summary>The certificate's name (CN), shown to operators and used as the peer name on the other side.</summary>
    public string Name => Certificate.GetNameInfo(X509NameType.SimpleName, false);

    private X509EndpointKeys(X509Certificate2 certificate, ECDsa signingKey, ECDiffieHellman agreementKey, bool tpm)
    {
        Certificate = certificate;
        SigningKey = signingKey;
        AgreementKey = agreementKey;
        IsTpmBacked = tpm;
        using var publicKey = certificate.GetECDsaPublicKey()!;
        SigningKeyId = KeyId.FromPublicKey(publicKey);
        AgreementKeyId = KeyId.FromPublicKey(agreementKey);
    }

    /// <summary>
    /// Keys from a certificate that carries its private key and an ECDH P-256 key. Takes ownership of both. Tests and
    /// <see cref="Open"/> use it.
    /// </summary>
    /// <exception cref="InvalidOperationException">Not an ECDSA P-256 certificate with its private key, or not a P-256 agreement key.</exception>
    public static X509EndpointKeys FromCertificate(X509Certificate2 certificate, ECDiffieHellman agreementKey, bool tpm = false)
    {
        ECDsa signing = certificate.GetECDsaPrivateKey()
            ?? throw new InvalidOperationException($"The certificate '{certificate.Subject}' has no ECDSA private key on this machine.");
        if (!CertHelloValidator.IsP256(signing) || !CertHelloValidator.IsP256(agreementKey))
        {
            signing.Dispose();
            throw new InvalidOperationException($"The certificate '{certificate.Subject}' must have an ECDSA P-256 key (QrDiode signs with P-256 only).");
        }
        return new X509EndpointKeys(certificate, signing, agreementKey, tpm);
    }

    /// <summary>
    /// Opens this machine's certificate from <see cref="CertificateOptions.Location"/> (by thumbprint, else by subject: the
    /// newest one that passes the checks the other side runs) and its ECDH key, created on first use.
    /// <paramref name="production"/>: both keys must be in the TPM.
    /// </summary>
    /// <exception cref="InvalidOperationException">No usable certificate, the trusted CA is missing, no access to the private key, or not TPM-backed in production. The message says what to do.</exception>
    [SupportedOSPlatform("windows")]
    public static X509EndpointKeys Open(CertificateOptions options, bool production)
    {
        if (!CertificateOptions.TryParseLocation(options.Location, out var location, out var name))
            throw new InvalidOperationException($"Certificate:Location \"{options.Location}\" is not a certificate store.");

        var certificate = FindOwnCertificate(options, location, name);
        ECDsa? signing = null;
        try
        {
            try
            {
                signing = certificate.GetECDsaPrivateKey();
            }
            catch (CryptographicException ex)
            {
                throw new InvalidOperationException(
                    $"This Windows user cannot use the private key of '{certificate.Subject}' ({ex.Message}). " +
                    "In certlm.msc: Personal → Certificates → the certificate → All Tasks → Manage Private Keys → give the kiosk user Read.", ex);
            }
            if (signing is null || !CertHelloValidator.IsP256(signing))
                throw new InvalidOperationException($"The certificate '{certificate.Subject}' must have an ECDSA P-256 private key.");

            bool signingTpm = signing is ECDsaCng cng && cng.Key.Provider?.Provider == CngEndpointKeys.PlatformProvider;
            if (production && !signingTpm)
                throw new InvalidOperationException(
                    $"The private key of '{certificate.Subject}' is not in the TPM, and production requires TPM-backed keys. " +
                    "Enrol the certificate with the Microsoft Platform Crypto Provider.");

            // One ECDH key per certificate: a renewed certificate gets a new one, and the other side pins both again.
            var (agreement, agreementTpm) = CngEndpointKeys.OpenOrCreateAgreementKey($"x509-{certificate.Thumbprint[..16]}", production);
            var keys = new X509EndpointKeys(certificate, signing, agreement, signingTpm && agreementTpm);
            signing = null;
            return keys;
        }
        catch
        {
            signing?.Dispose();
            certificate.Dispose();
            throw;
        }
    }

    [SupportedOSPlatform("windows")]
    private static X509Certificate2 FindOwnCertificate(CertificateOptions options, StoreLocation location, StoreName name)
    {
        // The other side will check this certificate against the trusted CA: pick one that passes those checks, not
        // merely the newest with the right name (a domain machine often has an auto-enrolled RSA "Computer" certificate
        // with the same name, or one from another CA).
        using var validator = CertHelloValidator.FromStore(options);
        using var store = new X509Store(name, location);
        store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);
        var all = store.Certificates;
        try
        {
            DateTime now = DateTime.Now;
            string thumbprint = CertificateOptions.NormalizeThumbprint(options.OwnThumbprint);
            string wanted = thumbprint.Length > 0 ? $"thumbprint {thumbprint}" : $"'{options.OwnSubject}'";
            var candidates = all
                .Where(c => c.HasPrivateKey && c.NotBefore <= now && now <= c.NotAfter)
                .Where(c => thumbprint.Length > 0
                    ? c.Thumbprint.Equals(thumbprint, StringComparison.OrdinalIgnoreCase)
                    : CertHelloValidator.NameMatches(c, options.OwnSubject))
                .OrderByDescending(c => c.NotBefore)
                .ToList();
            if (candidates.Count == 0)
                throw new InvalidOperationException(
                    $"No valid certificate with a private key for {wanted} in {options.Location}. " +
                    "Check certlm.msc (LocalMachine) or certmgr.msc (CurrentUser).");

            string? firstProblem = null;
            foreach (var candidate in candidates)
            {
                if (validator.CheckCertificate(candidate) is { } problem)
                {
                    firstProblem ??= problem;
                    continue;
                }
                // The store's collection owns every certificate it handed out; keep only the chosen one.
                return new X509Certificate2(candidate);
            }
            throw new InvalidOperationException(
                $"None of the {candidates.Count} certificate(s) for {wanted} in {options.Location} can be used: {firstProblem}");
        }
        finally
        {
            foreach (var c in all) c.Dispose();
        }
    }

    public void Dispose()
    {
        SigningKey.Dispose();
        AgreementKey.Dispose();
        Certificate.Dispose();
    }
}
