using System.Security.Cryptography;

namespace QrDiode.Core.Crypto;

/// <summary>
/// An endpoint's own key material: one ECDSA P-256 signing pair and one ECDH P-256
/// key-agreement pair. Backed either by ephemeral keys (tests) or Windows CNG named keys.
/// </summary>
public interface IEndpointKeys : IDisposable
{
    ECDsa SigningKey { get; }
    ECDiffieHellman AgreementKey { get; }
    byte[] SigningKeyId { get; }
    byte[] AgreementKeyId { get; }

    /// <summary>Both private keys live in the TPM. False for keys that never do (tests).</summary>
    bool IsTpmBacked => false;
}
