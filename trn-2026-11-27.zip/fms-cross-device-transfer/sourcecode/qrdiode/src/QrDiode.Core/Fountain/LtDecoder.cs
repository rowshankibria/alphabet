namespace QrDiode.Core.Fountain;

/// <summary>
/// Incremental LT decoder using belief-propagation peeling. Symbols may arrive in any order,
/// duplicated, or not at all — the carousel guarantees more will come.
///
/// Memory is bounded: at most <see cref="MaxBufferedSymbols"/> coded symbols wait for their
/// neighbours (oldest evicted first), and at most <see cref="MaxTrackedSymbolIds"/> symbol ids are
/// remembered for de-duplication (oldest forgotten first; a forgotten id that comes round again is
/// simply redundant). Both scale with K, so a legitimate session is never starved.
/// </summary>
public sealed class LtDecoder
{
    private sealed class CodedSymbol(HashSet<int> remaining, byte[] data)
    {
        public readonly HashSet<int> Remaining = remaining;
        public byte[] Data = data;

        /// <summary>Still waiting for neighbours (two or more unresolved). Resolved or evicted otherwise.</summary>
        public bool Waiting => Remaining.Count > 1;
    }

    private readonly int _symbolSize;
    private readonly long _payloadLength;
    private readonly ulong _sessionSeed;
    private readonly RobustSoliton _soliton;

    private readonly byte[]?[] _source;
    private readonly Dictionary<int, List<CodedSymbol>> _bySource = new();
    private readonly Queue<CodedSymbol> _waitingOrder = new(); // oldest first, for eviction
    private int _waitingCount;
    private readonly HashSet<uint> _seenSymbolIds = new();
    private readonly Queue<uint> _seenOrder = new();

    public int K { get; }
    public int DecodedSourceCount { get; private set; }
    public int UniqueSymbolsReceived { get; private set; }
    public bool IsComplete => DecodedSourceCount == K;

    /// <summary>Clamp(4·K, 1,024, 65,536): enough for heavy loss, never more than about 4× the payload.</summary>
    public int MaxBufferedSymbols { get; }

    /// <summary>Clamp(16·K, 4,096, 1,048,576) symbol ids remembered for de-duplication.</summary>
    public int MaxTrackedSymbolIds { get; }

    /// <summary>Coded symbols currently waiting for neighbours.</summary>
    public int BufferedSymbols => _waitingCount;

    /// <summary>Symbol ids currently remembered.</summary>
    public int TrackedSymbolIds => _seenSymbolIds.Count;

    /// <summary>Coded symbols dropped because the buffer was full. Non-zero means very heavy loss.</summary>
    public long EvictedSymbols { get; private set; }

    public LtDecoder(long payloadLength, int symbolSize, ulong sessionSeed)
    {
        if (payloadLength <= 0) throw new ArgumentOutOfRangeException(nameof(payloadLength));
        _payloadLength = payloadLength;
        _symbolSize = symbolSize;
        _sessionSeed = sessionSeed;
        K = LtCode.SourceBlockCount(payloadLength, symbolSize);
        _soliton = new RobustSoliton(K);
        _source = new byte[]?[K];
        MaxBufferedSymbols = (int)Math.Clamp(4L * K, 1024, 65_536);
        MaxTrackedSymbolIds = (int)Math.Clamp(16L * K, 4096, 1_048_576);
    }

    /// <summary>Feeds one received symbol. Returns true if it advanced decoding (new + useful).</summary>
    public bool AddSymbol(uint symbolId, ReadOnlySpan<byte> payload)
    {
        if (IsComplete) return false;
        if (payload.Length != _symbolSize) return false;
        if (!RememberSymbolId(symbolId)) return false;
        UniqueSymbolsReceived++;

        if (symbolId < (uint)K)
        {
            if (_source[symbolId] is not null) return false; // already recovered by peeling
            Resolve((int)symbolId, payload.ToArray());
            return true;
        }

        var neighbors = LtCode.GetNeighbors(_sessionSeed, symbolId, _soliton);
        var remaining = new HashSet<int>(neighbors.Length);
        var data = payload.ToArray();

        foreach (int n in neighbors)
        {
            var src = _source[n];
            if (src is not null)
                Xor(data, src);
            else
                remaining.Add(n);
        }

        if (remaining.Count == 0)
            return false; // fully redundant

        if (remaining.Count == 1)
        {
            int only = remaining.First();
            Resolve(only, data);
            return true;
        }

        var coded = new CodedSymbol(remaining, data);
        foreach (int n in remaining)
        {
            if (!_bySource.TryGetValue(n, out var list))
                _bySource[n] = list = new List<CodedSymbol>();
            list.Add(coded);
        }
        _waitingOrder.Enqueue(coded);
        _waitingCount++;
        EvictIfFull();
        return true;
    }

    private bool RememberSymbolId(uint symbolId)
    {
        if (!_seenSymbolIds.Add(symbolId)) return false;
        _seenOrder.Enqueue(symbolId);
        if (_seenOrder.Count > MaxTrackedSymbolIds)
            _seenSymbolIds.Remove(_seenOrder.Dequeue());
        return true;
    }

    private void EvictIfFull()
    {
        while (_waitingCount > MaxBufferedSymbols && _waitingOrder.TryDequeue(out var oldest))
        {
            if (!oldest.Waiting) continue; // resolved meanwhile; just leaving the queue
            oldest.Remaining.Clear();
            oldest.Data = Array.Empty<byte>();
            _waitingCount--;
            EvictedSymbols++;
        }

        // Resolved symbols leave the queue lazily; rebuild it when they make up most of it.
        if (_waitingOrder.Count > 2 * MaxBufferedSymbols)
        {
            var stillWaiting = _waitingOrder.Where(c => c.Waiting).ToList();
            _waitingOrder.Clear();
            foreach (var coded in stillWaiting) _waitingOrder.Enqueue(coded);
        }
    }

    private void Resolve(int sourceIndex, byte[] data)
    {
        if (_source[sourceIndex] is not null) return;

        var queue = new Queue<(int Index, byte[] Data)>();
        queue.Enqueue((sourceIndex, data));

        while (queue.Count > 0)
        {
            var (idx, resolved) = queue.Dequeue();
            if (_source[idx] is not null) continue;
            _source[idx] = resolved;
            DecodedSourceCount++;

            if (!_bySource.Remove(idx, out var dependents)) continue;
            foreach (var coded in dependents)
            {
                if (!coded.Remaining.Remove(idx)) continue; // evicted, or already used
                Xor(coded.Data, resolved);
                if (coded.Remaining.Count == 1)
                {
                    int only = coded.Remaining.First();
                    coded.Remaining.Clear();
                    _waitingCount--;
                    // The bytes now belong to the source block they recover; drop the symbol's reference.
                    byte[] recovered = coded.Data;
                    coded.Data = Array.Empty<byte>();
                    if (_source[only] is null)
                        queue.Enqueue((only, recovered));
                }
            }
        }
    }

    /// <summary>Assembles the decoded payload. Only valid when <see cref="IsComplete"/>.</summary>
    public byte[] Assemble()
    {
        if (!IsComplete) throw new InvalidOperationException("Decoding is not complete.");
        var result = new byte[_payloadLength];
        for (int i = 0; i < K; i++)
        {
            long offset = (long)i * _symbolSize;
            int len = (int)Math.Min(_symbolSize, _payloadLength - offset);
            _source[i]!.AsSpan(0, len).CopyTo(result.AsSpan((int)offset, len));
        }
        return result;
    }

    private static void Xor(byte[] target, byte[] operand)
    {
        for (int i = 0; i < target.Length; i++)
            target[i] ^= operand[i];
    }
}
