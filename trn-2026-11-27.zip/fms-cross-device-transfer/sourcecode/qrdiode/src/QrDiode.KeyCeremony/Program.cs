using QrDiode.Core;
using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;

// The administrator's tool for this machine's key exchange (C:\ProgramData\QrDiode\keyexchange.json). A few commands are the same for every
// mechanism; the rest come from the mechanism itself (IKeyExchange.Commands), so a new mechanism needs no change here.

if (!OperatingSystem.IsWindows())
{
    Console.Error.WriteLine("QrDiode.KeyCeremony requires Windows (CNG key storage).");
    return 2;
}

IKeyExchange exchange;
try
{
    exchange = KeyExchanges.Load(QrDiodeOptions.Load());
}
catch (InvalidDataException ex)
{
    Console.Error.WriteLine(ex.Message);
    return 2;
}

QrDiodePaths.EnsureCreated();

switch (args)
{
    case ["fingerprint", string path]: return Fingerprint(path);
    case ["list"]: return List();
    case ["delete", string name]: return DeleteRefused(name);
    case ["delete", string name, "--yes"]: return Delete(name);
    case ["verify-audit"]: return VerifyAudit(null);
    case ["verify-audit", string path]: return VerifyAudit(path);
}

if (args.Length > 0 && exchange.Commands.FirstOrDefault(c => c.Name == args[0]) is { } command)
{
    if (args.Length - 1 != command.ArgumentCount)
    {
        Console.Error.WriteLine($"Usage: {command.Name} {command.Arguments}".TrimEnd());
        return 1;
    }
    return command.Run(args[1..], Console.Out, Console.Error);
}
return Usage();

static int Fingerprint(string path)
{
    try
    {
        var bundle = PublicKeyBundle.Parse(File.ReadAllText(path));
        Console.WriteLine($"{bundle.Name}: {bundle.Fingerprint()}");
        return 0;
    }
    catch (Exception ex)
    {
        Console.Error.WriteLine($"Cannot read bundle: {ex.Message}");
        return 1;
    }
}

int List()
{
    Console.WriteLine(exchange.PairsOverTheLight ? $"Trusted peers (paired over the cameras, {exchange.Description}):" : "Trusted peers:");
    DirectoryTrustStore store;
    try
    {
        store = exchange.OpenTrustStore();
    }
    catch (InvalidOperationException ex)
    {
        Console.Error.WriteLine(ex.Message);
        return 1;
    }
    using (store)
    {
        if (store.Peers.Count == 0) Console.WriteLine("  (none)");
        foreach (var peer in store.Peers)
            Console.WriteLine($"  {peer.Name}  sign={KeyId.ToHex(peer.SigningKeyId)}  kex={KeyId.ToHex(peer.AgreementKeyId)}");
        if (store.Problems.Count > 0)
        {
            Console.WriteLine("Skipped (NOT trusted):");
            foreach (var problem in store.Problems) Console.WriteLine($"  {problem}");
        }
    }
    return 0;
}

static int DeleteRefused(string name)
{
    // Irreversible: the other side would have to repeat the whole key exchange.
    Console.Error.WriteLine($"This permanently deletes the private keys of endpoint '{name}' on this machine.");
    Console.Error.WriteLine("The other side's trust store then holds a key nobody has; you would have to repeat the key exchange.");
    Console.Error.WriteLine($"To go ahead, run: delete {name} --yes");
    return 1;
}

static int Delete(string name)
{
    CngEndpointKeys.Delete(name);
    Console.WriteLine($"Local CNG keys for endpoint '{name}' deleted (trust-store bundles are not touched).");
    return 0;
}

static int VerifyAudit(string? path)
{
    string[] files = path is not null
        ? [path]
        : [Path.Combine(QrDiodePaths.AuditDir, "sender-audit.jsonl"), Path.Combine(QrDiodePaths.AuditDir, "receiver-audit.jsonl")];

    int broken = 0, checkedLogs = 0;
    foreach (var file in files)
    {
        var result = AuditLog.VerifyChain(file);
        if (result.Files == 0)
        {
            if (path is not null) { Console.Error.WriteLine($"{file}: no audit log here."); return 1; }
            continue;
        }

        checkedLogs++;
        if (result.Intact)
        {
            Console.WriteLine($"✔ {Path.GetFileName(file)}: intact — {result.Records:N0} records in {result.Files} file(s).");
        }
        else
        {
            broken++;
            Console.WriteLine($"✖ {Path.GetFileName(file)}: BROKEN at record {result.FirstBrokenIndex:N0} " +
                              $"({result.BrokenFile}, line {result.BrokenLine}): {result.Problem}.");
        }
    }

    if (checkedLogs == 0) Console.WriteLine($"No audit logs found in {QrDiodePaths.AuditDir}.");
    return broken == 0 ? 0 : 1;
}

int Usage()
{
    Console.WriteLine($"""
        QrDiode key exchange tool — this machine uses: {exchange.Description} ("KeyExchange": "{exchange.Kind}" in {QrDiodePaths.KeyExchangeFile})

        Usage:
        """);
    foreach (var command in exchange.Commands)
        PrintCommand($"{command.Name} {command.Arguments}".TrimEnd(), command.Help);
    PrintCommand("fingerprint <bundle.json>", "Print a bundle's fingerprint for out-of-band comparison.");
    PrintCommand("list", "List trusted peers (and bundles that were skipped, and why).");
    PrintCommand("delete <endpointName> --yes", "Delete this machine's local key pairs (irreversible).");
    PrintCommand("verify-audit [file.jsonl]",
        "Check the audit log chain (default: the Sender's and the Receiver's logs on this machine, archived files included).");

    if (exchange.Kind == KeyExchangeKind.KeyCeremony)
        Console.WriteLine("""

            Ceremony:
              OT machine:  init ot-line-1  →  export ot-line-1 ot.json  →  carry ot.json to IT
              IT machine:  init it-recv-1  →  export it-recv-1 it.json  →  carry it.json to OT
              Each side:   import <other side's json>  →  compare FINGERPRINT verbally.
            """);
    return 1;
}

static void PrintCommand(string usage, string help)
{
    string[] lines = help.Split('\n');
    Console.WriteLine($"  {usage,-33}{lines[0]}");
    foreach (var line in lines.Skip(1)) Console.WriteLine($"  {"",-33}{line}");
}
