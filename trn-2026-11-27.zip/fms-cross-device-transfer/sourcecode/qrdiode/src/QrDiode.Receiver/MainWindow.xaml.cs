using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using FlashCap;
using QrBridge.Shared;
using QrBridge.Shared.Bundles;
using QrDiode.Core;
using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using QrDiode.Core.Presentation;
using QrDiode.Core.Simulation;
using QrDiode.Receiver.Capture;
using QrDiode.Receiver.Inbox;
using QrDiode.Receiver.Storage;
using QrDiode.Ui;

namespace QrDiode.Receiver;

public partial class MainWindow : Window
{
    /// <summary>The chain, in the exact order the engine enforces it. Index = how far a session got.</summary>
    private static readonly string[] ChainSteps =
    [
        "Manifest structure",
        "Manifest signature (ECDSA P-256)",
        "Addressed to this receiver key",
        "Anti-replay window",
        "Session keys + frame MAC",
        "Ciphertext hash",
        "AES-256-GCM decrypt",
        "Decompression cap",
        "Plaintext size",
        "Content gate",
        "Stored to the local store",
    ];

    private const int StoredStep = 10;

    /// <summary>Deployment rules from appsettings.json next to the exe ("Production", "Mode", "AllowOpaqueFiles").</summary>
    private readonly QrDiodeOptions _options;
    /// <summary>Unattended start-up ("Receiver" section).</summary>
    private readonly ReceiverOptions _receiverOptions;
    /// <summary>
    /// The "QRDatabase" settings (Side, DataFolder, Provider, ConnectionString: the same values as the gateway's
    /// "GatewayDatabase" on this machine). The Receiver's journal is in that database in both modes; Gateway mode also
    /// stores arriving bundles in its Inbox.
    /// </summary>
    private readonly GatewayDatabaseOptions? _bridgeOptions;
    private QrAppBridge? _bridge;
    private readonly DispatcherTimer _beatTimer = new() { Interval = QrAppBridge.HeartbeatInterval };
    private bool GatewayMode => _options.Mode == QrDiodeMode.Gateway;
    private static readonly PayloadType BundleType = PayloadCatalogue.ManualFile with { Name = "gateway bundle", Code = "QBB" };
    private long _lastFaultTicks = long.MinValue / 2;

    private IEndpointKeys? _keys;
    private DirectoryTrustStore? _trust;
    /// <summary>How this machine and its peer trust each other's keys (the machine's keyexchange.json); null when the settings cannot be used (then no keys are opened at all).</summary>
    private readonly IKeyExchange? _exchange;
    private readonly string? _exchangeError;
    /// <summary>The two sides pair over the light: the camera pins the peer from its pairing frame.</summary>
    private bool PairsOverTheLight => _exchange?.PairsOverTheLight == true;
    /// <summary>What the running engine trusts: swapped when a peer is pinned mid-run.</summary>
    private ReloadableTrustStore? _engineTrust;
    private IPairingVerifier? _pairingVerifier;
    /// <summary>Stores replaced mid-run: a frame on the camera thread may still hold their keys, so they go when the run ends.</summary>
    private readonly List<DirectoryTrustStore> _retiredTrust = [];
    /// <summary>
    /// Accepted sessions, anti-replay watermarks and the archive, in the bridge database (opened at start-up in both modes);
    /// the archive tab reads it while nothing is receiving.
    /// </summary>
    private readonly ReceiveJournal _journal;
    private readonly ReceiverSettings _settings;
    private readonly PayloadStore _store;
    private ReceiveEngine? _engine;
    private QrDecodePipeline? _pipeline;
    private readonly AuditLog _audit;
    private WriteableBitmap? _previewBitmap;
    private QrDecodePipeline.LumFrame _pendingPreview;
    private readonly DispatcherTimer _uiTimer;

    private readonly ObservableCollection<InboxEntry> _inbox = [];
    private readonly ListCollectionView _inboxView;
    private InboxEntry? _selected;
    private PayloadText _selectedText = PayloadText.Empty;

    private DateTime _runStartedUtc;
    private DateTime? _sessionStartedUtc;
    private Guid _lastActiveSession;
    private long _lastQrHits;
    private int _tallyOk, _tallyDup, _tallyBad;
    /// <summary>XAML property setters raise Checked/SelectionChanged while the tree is half-built.</summary>
    private bool _ready;

    private sealed record CameraChoice(CaptureDeviceDescriptor Descriptor, VideoCharacteristics Characteristics)
    {
        private double Fps => Characteristics.FramesPerSecond.Numerator /
                              Math.Max(1.0, Characteristics.FramesPerSecond.Denominator);

        // The pixel format is on the label because it decides how the frame gets decoded — an
        // operator chasing a dead preview should not have to guess what the camera is emitting.
        public string Label =>
            $"{Descriptor.Name} — {Characteristics.Width}×{Characteristics.Height} @ {Fps:0.#} fps · {Characteristics.PixelFormat}";
    }

    public MainWindow()
    {
        InitializeComponent();
        QrDiodePaths.EnsureCreated();
        _audit = new AuditLog(Path.Combine(QrDiodePaths.AuditDir, "receiver-audit.jsonl"));

        string? optionsError = null;
        try
        {
            _options = QrDiodeOptions.Load();
        }
        catch (InvalidDataException ex)
        {
            // Unreadable rules: run under the strictest ones rather than guess, and say why.
            _options = new QrDiodeOptions { Production = true, AllowOpaqueFiles = false };
            optionsError = ex.Message;
        }
        try
        {
            _exchange = KeyExchanges.Load(_options);
        }
        catch (InvalidDataException ex)
        {
            // Settings for the wrong or half a key exchange must not quietly run another one: open nothing, and say why.
            _exchangeError = ex.Message;
            optionsError ??= ex.Message;
        }
        DemoButton.Visibility = _exchange?.AllowsDemo == true ? Visibility.Visible : Visibility.Collapsed;
        if (_exchange is { UsesEndpointName: false }) EndpointNameBox.Text = _exchange.Identity;

        try
        {
            _receiverOptions = AppSettings.ReadSection<ReceiverOptions>(ReceiverOptions.SectionName);
        }
        catch (InvalidDataException ex)
        {
            _receiverOptions = new ReceiverOptions(); // no auto-start on unreadable settings
            optionsError ??= ex.Message;
        }
        try
        {
            if (AppSettings.HasSection(GatewayDatabaseOptions.FormerSectionName))
                throw new InvalidDataException(GatewayDatabaseOptions.FormerSectionProblem(GatewayDatabaseOptions.QrDiodeSectionName));
            _bridgeOptions = AppSettings.ReadSection<GatewayDatabaseOptions>(GatewayDatabaseOptions.QrDiodeSectionName);
            if (string.IsNullOrWhiteSpace(_bridgeOptions.DataFolder) || _bridgeOptions.MaxPayloadBytes <= 0)
                throw new InvalidDataException("QRDatabase:DataFolder must be set and QRDatabase:MaxPayloadBytes positive.");
        }
        catch (InvalidDataException ex)
        {
            _bridgeOptions = null; // never guess which database to write
            optionsError ??= ex.Message;
        }
        StrictModeCheck.IsChecked = _receiverOptions.StrictMode;
        _beatTimer.Tick += (_, _) => Beat();

        _settings = ReceiverSettings.Load();
        _store = new PayloadStore(_settings);
        _journal = OpenJournalOrExit(optionsError);

        _inboxView = (ListCollectionView)CollectionViewSource.GetDefaultView(_inbox);
        _inboxView.Filter = o => o is InboxEntry entry && PassesFilter(entry);
        InboxList.ItemsSource = _inboxView;

        _uiTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(150) };
        _uiTimer.Tick += OnUiTick;

        _ready = true;
        RefreshCameras_Click(this, null!);
        RefreshTrustPill();
        RenderDetail(null);
        InitArchive();
        UpdateButtons();
        if (optionsError is not null)
            ShowError($"{optionsError} Running with the strictest rules until it is fixed.");

        Loaded += (_, _) => { if (_receiverOptions.AutoStart) AutoStart(); };
    }

    // ═══════════════════ bridge, unattended start ═══════════════════

    /// <summary>
    /// Opens the bridge database (creates or upgrades it, like the gateway), copies a former journal.db in once, and returns
    /// the journal on it. Without the journal nothing may be received — there would be no anti-replay — so when it cannot
    /// be opened the Receiver says why and exits.
    /// </summary>
    private ReceiveJournal OpenJournalOrExit(string? optionsError)
    {
        try
        {
            if (_bridgeOptions is not { } options)
                throw new InvalidOperationException(optionsError ?? "The \"QRDatabase\" settings cannot be used.");
            // Off the UI thread: the first start may create or upgrade the bridge database.
            _bridge = Task.Run(() => QrAppBridge.OpenAsync(options, CancellationToken.None)).GetAwaiter().GetResult();
            if (_bridge.ImportLegacyJournal(QrDiodePaths.JournalDb) is { } sessions)
                _audit.Append("journal.imported", new Dictionary<string, string>
                {
                    ["from"] = QrDiodePaths.JournalDb,
                    ["sessions"] = sessions.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    ["database"] = _bridge.Database,
                });
            return new ReceiveJournal(_bridge.Journal);
        }
        catch (Exception ex)
        {
            string where = _bridgeOptions is { } o ? QrAppBridge.Describe(o) : "the gateway's database";
            _audit.Append("journal.open_failed", new Dictionary<string, string> { ["database"] = where, ["message"] = ex.Message });
            MessageBox.Show(
                $"The Receiver's journal (its anti-replay store) cannot be opened in {where}:\n\n{ex.Message}\n\n" +
                "Nothing can be received without it. Fix the \"QRDatabase\" settings in appsettings.json (the same values as the gateway's \"GatewayDatabase\" on this machine) and start again.",
                "QrDiode Receiver", MessageBoxButton.OK, MessageBoxImage.Error);
            Environment.Exit(2);
            throw; // not reached
        }
    }

    /// <summary>Gateway mode: the bridge database and its doorbells, opened at start-up with the journal. False when they are not.</summary>
    private async Task<bool> ConnectBridgeAsync()
    {
        if (_bridge is not null) return true;
        if (_bridgeOptions is not { } options)
        {
            ShowError("Gateway mode, but the \"QRDatabase\" settings cannot be used — nothing is received. Fix appsettings.json and restart.");
            return false;
        }
        try
        {
            // Off the UI thread: the first start may create or upgrade the bridge database.
            _bridge = await Task.Run(() => QrAppBridge.OpenAsync(options, CancellationToken.None));
            _audit.Append("bridge.connected", new Dictionary<string, string>
            {
                ["side"] = options.Side.ToString(),
                ["database"] = _bridge.Database,
            });
            return true;
        }
        catch (Exception ex)
        {
            ShowError($"Gateway mode: the gateway's database {QrAppBridge.Describe(options)} cannot be opened — nothing is received. {ex.Message}");
            _audit.Append("bridge.connect_failed", new Dictionary<string, string> { ["database"] = QrAppBridge.Describe(options), ["message"] = ex.Message });
            return false;
        }
    }

    /// <summary>Liveness for the gateway's /health (Components.ReceiverLoop), every 30 s while receiving.</summary>
    private void Beat()
    {
        var bridge = _bridge;
        if (bridge is null) return;
        string info = $"{bridge.Options.Side} · receiving · {_tallyOk} stored, {_tallyDup} duplicate, {_tallyBad} not stored";
        _ = Task.Run(async () =>
        {
            try { await bridge.Heartbeats.BeatAsync(Components.ReceiverLoop, info, CancellationToken.None); }
            catch (Exception) { /* a busy database: the next beat tries again */ }
        });
    }

    /// <summary>Kiosk (Integration-Plan §2.6): keys, camera and Strict mode from the settings, then Start, no clicks.</summary>
    private void AutoStart()
    {
        if (_exchange is { UsesEndpointName: true } && _receiverOptions.Endpoint.Length > 0) EndpointNameBox.Text = _receiverOptions.Endpoint;
        OpenKeys_Click(this, new RoutedEventArgs());
        if (_keys is null)
        {
            ShowError("Auto-start stopped: this machine's keys could not be opened.");
            return;
        }

        if (_receiverOptions.Camera.Length > 0)
        {
            var match = CameraCombo.Items.OfType<CameraChoice>()
                .FirstOrDefault(c => c.Descriptor.Name.Contains(_receiverOptions.Camera, StringComparison.OrdinalIgnoreCase));
            if (match is null)
            {
                ShowError($"Auto-start stopped: no camera named like '{_receiverOptions.Camera}'.");
                return;
            }
            CameraCombo.SelectedItem = match;
        }
        if (CameraCombo.SelectedItem is null)
        {
            ShowError("Auto-start stopped: no camera found.");
            return;
        }

        _audit.Append("receive.autostart", new Dictionary<string, string>
        {
            ["endpoint"] = EndpointNameBox.Text.Trim(),
            ["camera"] = (CameraCombo.SelectedItem as CameraChoice)?.Label ?? "",
            ["mode"] = _options.Mode.ToString(),
        });
        Start_Click(this, new RoutedEventArgs());
    }

    // ═══════════════════ identity, trust, camera ═══════════════════

    private void RefreshTrustPill()
    {
        DirectoryTrustStore trust;
        try
        {
            if (_exchange is null) throw new InvalidOperationException(_exchangeError ?? "The key exchange settings cannot be used.");
            trust = _exchange.OpenTrustStore();
        }
        catch (InvalidOperationException ex)
        {
            SetPill(TrustPill, TrustPillText, "✖ trust store cannot be opened", "PillBad");
            TrustPill.ToolTip = ex.Message;
            return;
        }
        using (trust)
        {
            int senders = trust.Peers.Count(p => _keys is null || !p.SigningKeyId.AsSpan().SequenceEqual(_keys.SigningKeyId));
            SetPill(TrustPill, TrustPillText,
                (senders > 0 ? $"✔ {senders} trusted sender{(senders == 1 ? "" : "s")}"
                    : PairsOverTheLight ? $"waiting to pair with {_exchange.ExpectedPeer}" : "✖ 0 trusted senders") +
                (trust.Problems.Count > 0 ? $" · ⚠ {trust.Problems.Count} skipped" : ""),
                senders > 0 ? "PillOk" : PairsOverTheLight ? "PillWarn" : "PillBad");
            TrustPill.ToolTip = trust.Problems.Count > 0 ? string.Join("\n", trust.Problems) : null;
        }
    }

    private void OpenKeys_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            _keys?.Dispose();
            _keys = null;
            if (_exchange is null)
                throw new InvalidOperationException(_exchangeError ?? "The key exchange settings cannot be used.");
            _keys = _exchange.OpenOwnKeys(EndpointNameBox.Text.Trim());
            KeyInfoText.Text = (_exchange.UsesEndpointName ? "" : $"{_exchange.Description} {_exchange.Identity} · ") +
                               $"kex {KeyId.ToHex(_keys.AgreementKeyId)} — senders must address transfers to this key.";
            SetPill(KeyPill, KeyPillText, _keys.IsTpmBacked ? "✔ TPM-backed" : "✔ software KSP", "PillOk");
            HideError();
        }
        catch (Exception ex)
        {
            KeyInfoText.Text = $"Key error: {ex.Message}";
            SetPill(KeyPill, KeyPillText, "✖ error", "PillBad");
            _keys = null;
        }
        RefreshTrustPill();
        UpdateButtons();
    }

    private void Demo_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (_exchange?.AllowsDemo != true)
                throw new InvalidOperationException("Demo setup is turned off on this machine (production, or not the key ceremony).");
            KeyPolicy.EnsureDemoAllowed(_options);
            var ids = DemoProvisioner.Provision();
            EndpointNameBox.Text = DemoProvisioner.ItEndpoint;
            OpenKeys_Click(sender, e);
            RibbonText.Text =
                $"demo ready · ot {ids.OtFingerprint[..19]}… · it {ids.ItFingerprint[..19]}… — " +
                "pick a camera, press Start, and aim it at the OT stage";
        }
        catch (Exception ex)
        {
            ShowError($"Demo setup failed: {ex.Message}");
        }
    }

    private void RefreshCameras_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            CameraCombo.ItemsSource = QrDecodePipeline.EnumerateCameras()
                .Select(c => new CameraChoice(c.Descriptor, c.Characteristics)).ToList();
            if (CameraCombo.Items.Count > 0) CameraCombo.SelectedIndex = 0;
            else ShowError("No camera found. Connect a webcam and press ↻ Refresh.");
        }
        catch (Exception ex)
        {
            ShowError($"Camera enumeration failed: {ex.Message}");
        }
        UpdateButtons();
    }

    private void Camera_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (!_ready) return;
        CameraBadgeText.Text = (CameraCombo.SelectedItem as CameraChoice)?.Label ?? "no camera";
        UpdateButtons();
    }

    private void UpdateButtons()
    {
        bool running = _pipeline is not null;
        StartButton.IsEnabled = !running && _keys is not null && CameraCombo.SelectedItem is not null;
        StopButton.IsEnabled = running;

        // Identity, camera and Strict mode are committed for the whole run — the journal's
        // replay window and the addressed key cannot change under a session in flight.
        EndpointNameBox.IsEnabled = !running && _exchange?.UsesEndpointName != false;
        CameraCombo.IsEnabled = !running;
        StrictModeCheck.IsEnabled = !running;
        StrictModeCheck.ToolTip = running
            ? "Stop receiving to change."
            : "Recommended whenever the sender's and receiver's clocks are in sync.";

        SetPill(RunPill, RunPillText, running ? "● receiving" : "● stopped", running ? "PillOk" : "PillIdle");
    }

    // ═══════════════════ run lifecycle ═══════════════════

    private async void Start_Click(object sender, RoutedEventArgs e)
    {
        if (_keys is null || CameraCombo.SelectedItem is not CameraChoice camera) return;

        try
        {
            var exchange = _exchange!; // keys are open, so the settings could be used
            // Forget the paired peers on every start (e.g. Certificate:RequireHandshakeOnStart): pair again over the
            // cameras. This machine's Sender hears the ring and stops addressing the old peer until the new pin is there.
            if (exchange.ForgetsPeersOnStart && exchange.ForgetPairedPeers() is > 0 and var forgotten)
            {
                _audit.Append("pairing.forgotten", new Dictionary<string, string> { ["peers"] = forgotten.ToString() });
                TrustSignal.Ring();
            }

            foreach (var retired in _retiredTrust) retired.Dispose();
            _retiredTrust.Clear();
            _trust?.Dispose();
            _trust = exchange.OpenTrustStore();
            RefreshTrustPill();
            // Pairing over the light starts unpaired on purpose: the camera pins the peer from its pairing frame.
            if (_trust.Peers.Count == 0 && !exchange.PairsOverTheLight)
            {
                ShowError("Trust store is empty — import the OT sender’s bundle (KeyCeremony tool)" +
                          (_options.Production ? "." : " or use ⚡ Demo setup on both apps.") +
                          (_trust.Problems.Count > 0 ? " Skipped: " + string.Join("; ", _trust.Problems) : ""));
                return;
            }
            HideError();

            // Gateway mode: the gateway's Inbox is where everything goes, so it must open first.
            if (GatewayMode && !await ConnectBridgeAsync()) return;

            // A store that cannot be written to must fail here, not three payloads into a session
            // with verified plaintext in hand and nowhere to put it. (Gateway mode writes no files.)
            if (!GatewayMode)
            {
                try
                {
                    _store.EnsureReady();
                }
                catch (Exception ex)
                {
                    ShowError($"The local store at “{_store.Root}” is not writable: {ex.Message} — " +
                              "pick another folder on the Archive tab.");
                    return;
                }
            }

            // Strict mode: shrink the replay acceptance window from 48 h to 15 min.
            _journal.ReplayWindow = StrictModeCheck.IsChecked == true
                ? TimeSpan.FromMinutes(15)
                : TimeSpan.FromHours(48);

            // Pairing frames must be as fresh as manifests (the same clock window).
            _pairingVerifier?.Dispose();
            _pairingVerifier = exchange.CreatePairingVerifier(_journal.ReplayWindow);
            _engineTrust = new ReloadableTrustStore(_trust);

            // Gateway mode accepts gateway bundles only: no opaque file gets past the engine unless it is a .qbb, which
            // HandleCompletion then parses; XML/JSON payloads are refused there.
            _engine = new ReceiveEngine(_engineTrust, _journal, _keys, GatewayMode
                ? new ReceiveOptions { AllowOpaqueFiles = false, AllowedFileSuffixes = [BundleCodec.FileExtension], Pairing = _pairingVerifier }
                : new ReceiveOptions { AllowOpaqueFiles = _options.AllowOpaqueFiles, Pairing = _pairingVerifier });
            // Raised on the camera thread; the engine is already on the newer session, so no Reset.
            _engine.SessionAbandoned += abandoned => Dispatcher.BeginInvoke(() => HandleAbandoned(abandoned));
            _runStartedUtc = DateTime.UtcNow;
            _sessionStartedUtc = null;
            _lastActiveSession = Guid.Empty;
            _lastQrHits = 0;
            TransferProgress.Value = 0;
            ProgressPercent.Text = "0%";
            ProgressText.Text = "waiting for a manifest…";
            RibbonText.Text = exchange.PairsOverTheLight && _trust.Peers.Count == 0
                ? $"receiving · waiting to pair: aim the camera at {exchange.ExpectedPeer}'s stage (it shows its pairing code)"
                : "receiving · waiting for the first manifest";

            _pipeline = new QrDecodePipeline(OnQrPayload, frame => _pendingPreview = frame);
            await _pipeline.StartAsync(camera.Descriptor, camera.Characteristics);

            _audit.Append("receive.started", new Dictionary<string, string>
            {
                ["camera"] = camera.Label,
                ["endpoint"] = EndpointNameBox.Text.Trim(),
                ["strictMode"] = (StrictModeCheck.IsChecked == true).ToString(),
                ["production"] = _options.Production.ToString(),
                ["mode"] = _options.Mode.ToString(),
                ["allowOpaqueFiles"] = _options.AllowOpaqueFiles.ToString(),
                ["storageRoot"] = GatewayMode ? _bridge?.Database ?? QrAppBridge.Describe(_bridgeOptions!) : _store.Root,
            });
            if (GatewayMode)
            {
                Beat();
                _beatTimer.Start();
            }

            // Not a reason to stop: the readable bundles are trusted. But never silently.
            if (_trust.Problems.Count > 0)
                ShowError("Some trust bundles were skipped: " + string.Join("; ", _trust.Problems));

            PreviewHint.Visibility = Visibility.Collapsed;
            _uiTimer.Start();
        }
        catch (Exception ex)
        {
            ShowError($"Failed to start: {ex.Message}");
            if (_pipeline is not null) { await _pipeline.DisposeAsync(); _pipeline = null; }
        }
        UpdateButtons();
    }

    private async void Stop_Click(object sender, RoutedEventArgs e)
    {
        _uiTimer.Stop();
        _beatTimer.Stop(); // the gateway's /health then shows the receiver as not seen
        if (_pipeline is not null)
        {
            await _pipeline.DisposeAsync();
            _pipeline = null;
        }
        PreviewHint.Visibility = Visibility.Visible;
        SetLock(false);
        RibbonText.Text = "stopped · the inbox keeps everything received in this run";
        PreviewProgressText.Text = "idle";
        UpdateButtons();
    }

    /// <summary>Called from the capture thread for every decoded QR payload.</summary>
    private void OnQrPayload(byte[] payload)
    {
        var engine = _engine;
        if (engine is null) return;

        FeedResult result;
        try
        {
            result = engine.Feed(payload);
        }
        catch (Exception ex)
        {
            // This is the camera's thread: an exception escaping here could stop the capture or end
            // the app. The engine's state is unchanged by a failed check, so report and carry on.
            ReportEngineFault(ex);
            return;
        }

        if (result == FeedResult.Completed)
        {
            Dispatcher.BeginInvoke(HandleCompletion);
        }
        else if (result == FeedResult.PeerAccepted && engine.LastPairedPeer is { } peer)
        {
            Dispatcher.BeginInvoke(() => HandlePairedPeer(engine, peer));
        }
        else if (result == FeedResult.Rejected)
        {
            // Snapshot on this thread: another frame may overwrite the engine's last rejection
            // before the dispatcher gets round to us.
            var info = engine.LastRejectionInfo ?? new RejectionInfo(engine.LastRejection, null);
            Dispatcher.BeginInvoke(() => HandleRejection(info));
        }
    }

    /// <summary>At most one report every 10 s: a failing disk would otherwise raise one per frame.</summary>
    private void ReportEngineFault(Exception ex)
    {
        long now = Environment.TickCount64;
        if (now - Interlocked.Read(ref _lastFaultTicks) < 10_000) return; // milliseconds (TickCount64): 10 s
        Interlocked.Exchange(ref _lastFaultTicks, now);

        Dispatcher.BeginInvoke(() =>
        {
            _audit.Append("receive.engine_error", new Dictionary<string, string>
            {
                ["error"] = ex.GetType().Name,
                ["message"] = ex.Message,
            });
            ShowError($"Receiving hit an error and carries on: {ex.Message}");
        });
    }

    // ═══════════════════ outcomes ═══════════════════

    /// <summary>
    /// The other side's pairing frame passed every check of the key exchange. Pin it (unless the same or a newer one
    /// already is), swap the trust store under the running engine, and ring this machine's Sender so it can address the peer.
    /// </summary>
    private void HandlePairedPeer(ReceiveEngine engine, VerifiedPeer peer)
    {
        var exchange = _exchange!;
        var details = new Dictionary<string, string>(peer.Details)
        {
            ["exchange"] = exchange.Kind.ToString(),
            ["peer"] = peer.Name,
            ["signKey"] = KeyId.ToHex(peer.SigningKeyId),
            ["kexKey"] = KeyId.ToHex(peer.AgreementKeyId),
        };
        try
        {
            var outcome = exchange.Pin(peer);
            details["outcome"] = outcome.ToString();
            _audit.Append("pairing.peer_verified", details);
            switch (outcome)
            {
                case PinOutcome.Pinned or PinOutcome.Replaced:
                    var fresh = exchange.OpenTrustStore();
                    if (_trust is not null) _retiredTrust.Add(_trust);
                    _trust = fresh;
                    _engineTrust?.Replace(fresh);
                    TrustSignal.Ring();
                    RefreshTrustPill();
                    RibbonText.Text = $"paired with {peer.Name} ({exchange.Description} {peer.Identity}) · its transfers are accepted from now on";
                    break;
                case PinOutcome.Older:
                    ShowError($"A pairing code from {peer.Name} older than the pinned one was ignored (a recording held up to the camera?).");
                    break;
            }
        }
        catch (Exception ex)
        {
            // Verified but not pinned: let the engine offer it again on the Sender's next pairing frame.
            engine.ForgetAcceptedPeers();
            details["error"] = ex.Message;
            _audit.Append("pairing.pin_failed", details);
            ShowError($"{peer.Name} was verified but could not be pinned: {ex.Message}");
        }
    }

    private void HandleCompletion()
    {
        var engine = _engine;
        if (engine?.Completed is not { } completed) return;

        // Gateway mode first, before the "same content" check below: a bundle aired again (its Receipt was lost) can be
        // byte-identical, and must still reach the Inbox so it is owed a Receipt again (pending work B-06).
        if (GatewayMode)
        {
            if (_bridge is not null && BundleCodec.IsBundleFileName(completed.Manifest.Filename))
                _ = HandleBundleAsync(engine, completed);
            else
                HandleNotABundle(engine, completed);
            return;
        }

        var manifest = completed.Manifest;
        double seconds = (DateTime.UtcNow - (_sessionStartedUtc ?? _runStartedUtc)).TotalSeconds;
        var type = PayloadCatalogue.ForFilename(manifest.Filename, manifest.ContentType);
        string senderKey = "sign " + Short(KeyId.ToHex(manifest.SenderSigningKeyId));
        string sha256 = Convert.ToHexString(completed.PlaintextSha256);

        // Whether the replay guard now has this session. Only then is it settled; until then the
        // carousel still on air may deliver it again, so a store failure or a crash never loses it.
        bool committed = false;
        try
        {
            bool newRun = _journal.IsNewRun(manifest.SenderSigningKeyId, manifest.CounterRunId);

            if (_journal.IsDuplicateContent(manifest.SenderSigningKeyId, completed.PlaintextSha256))
            {
                engine.CommitReplay();
                committed = true;
                if (newRun) AuditNewCounterRun(manifest);
                _journal.RecordTransfer(manifest.SessionId, completed.PlaintextSha256, manifest.Filename,
                    manifest.OriginalSize, "duplicate");
                _audit.Append("receive.duplicate", new Dictionary<string, string>
                {
                    ["session"] = manifest.SessionId.ToString(),
                    ["file"] = manifest.Filename,
                });

                AddEntry(new InboxEntry
                {
                    Type = type,
                    Name = manifest.Filename,
                    Size = manifest.OriginalSize,
                    ArrivedAt = DateTime.Now,
                    Outcome = InboxOutcome.Duplicate,
                    SenderKeyShort = senderKey,
                    SenderKeyId = KeyId.ToHex(manifest.SenderSigningKeyId),
                    SessionId = manifest.SessionId.ToString("N"),
                    Receipt = completed.ReceiptHash,
                    Seconds = seconds,
                    ContentType = manifest.ContentType,
                    Counter = manifest.Counter,
                    PlaintextSha256 = sha256,
                    Reason = "This exact content from this sender was already stored earlier. " +
                             "Nothing was written — idempotency guaranteed.",
                    Chain = DuplicateChain(),
                    PreviewData = Capped(completed.Plaintext),
                    PreviewTruncated = completed.Plaintext.Length > InboxEntry.PreviewBytes,
                    Snippet = PayloadFormatter.Snippet(manifest.ContentType, completed.Plaintext),
                });
                return;
            }

            // Atomic materialization into the configured store: staging write + fsync, then rename.
            // Only once the bytes are durable does the session count as received (CommitReplay).
            string finalPath = _store.Save(manifest, completed.PlaintextSha256, completed.Plaintext, completed.ReceiptHash, DateTime.Now);
            engine.CommitReplay();
            committed = true;
            if (newRun) AuditNewCounterRun(manifest);

            _journal.RecordTransfer(manifest.SessionId, completed.PlaintextSha256, manifest.Filename,
                manifest.OriginalSize, "stored");
            _audit.Append("receive.completed", new Dictionary<string, string>
            {
                ["session"] = manifest.SessionId.ToString(),
                ["file"] = manifest.Filename,
                ["stored"] = finalPath,
                ["size"] = manifest.OriginalSize.ToString(),
                ["sha256"] = sha256,
                ["receipt"] = completed.ReceiptHash,
            });

            TransferProgress.Value = 1;
            ProgressPercent.Text = "100%";

            AddEntry(new InboxEntry
            {
                Type = type,
                Name = manifest.Filename,
                Size = manifest.OriginalSize,
                ArrivedAt = DateTime.Now,
                Outcome = InboxOutcome.Verified,
                SenderKeyShort = senderKey,
                SenderKeyId = KeyId.ToHex(manifest.SenderSigningKeyId),
                SessionId = manifest.SessionId.ToString("N"),
                Receipt = completed.ReceiptHash,
                StoredPath = finalPath,
                Seconds = seconds,
                ContentType = manifest.ContentType,
                Counter = manifest.Counter,
                PlaintextSha256 = sha256,
                Chain = VerifiedChain(manifest, sha256, seconds),
                PreviewData = Capped(completed.Plaintext),
                PreviewTruncated = completed.Plaintext.Length > InboxEntry.PreviewBytes,
                Snippet = PayloadFormatter.Snippet(manifest.ContentType, completed.Plaintext),
            });
        }
        catch (Exception ex)
        {
            _audit.Append("receive.store_failed", new Dictionary<string, string>
            {
                ["session"] = manifest.SessionId.ToString(),
                ["error"] = ex.Message,
                ["committed"] = committed.ToString(),
            });

            // Not committed: the session stays receivable, and the carousel will deliver it again —
            // one row per session that counts the attempts, not one row per attempt.
            if (_inbox.FirstOrDefault() is { Outcome: InboxOutcome.StoreFailed } top &&
                top.SessionId == manifest.SessionId.ToString("N"))
            {
                top.Repeats++;
                return;
            }

            AddEntry(new InboxEntry
            {
                Type = type,
                Name = manifest.Filename,
                Size = manifest.OriginalSize,
                ArrivedAt = DateTime.Now,
                Outcome = InboxOutcome.StoreFailed,
                SenderKeyShort = senderKey,
                SenderKeyId = KeyId.ToHex(manifest.SenderSigningKeyId),
                SessionId = manifest.SessionId.ToString("N"),
                Receipt = completed.ReceiptHash,
                Seconds = seconds,
                ContentType = manifest.ContentType,
                Counter = manifest.Counter,
                PlaintextSha256 = sha256,
                Reason = committed
                    ? $"Payload stored, but the journal could not complete its row: {ex.Message}"
                    : $"Payload verified but not stored: {ex.Message} — it can still arrive while the sender shows it.",
                Chain = StoreFailedChain(ex.Message),
                PreviewData = Capped(completed.Plaintext),
                PreviewTruncated = completed.Plaintext.Length > InboxEntry.PreviewBytes,
                Snippet = PayloadFormatter.Snippet(manifest.ContentType, completed.Plaintext),
            });
        }
        finally
        {
            // Back-to-back sessions: clear the in-flight state so the next manifest is picked up.
            // Committed: the engine remembers the session, so the tail of the carousel is ignored
            // rather than re-judged. Not committed: it forgets it, so the carousel can deliver it again.
            engine.Reset(settle: committed);
            _sessionStartedUtc = null;
            _lastActiveSession = Guid.Empty;
            TransferProgress.Value = 0;
            ProgressPercent.Text = "0%";
            RibbonText.Text = "session complete → waiting for the next manifest";
        }
    }

    /// <summary>
    /// Gateway mode (Integration-Plan §2.5): stores a verified bundle in the gateway's Inbox in one transaction and rings
    /// its doorbell, then commits the replay state — in that order, so a crash in between loses nothing (the carousel or a
    /// re-air delivers it again and the Inbox skips what it already has). Nothing of the payload is kept here: no file,
    /// no snippet, no preview (gateway payloads are never logged; S-06).
    /// </summary>
    private async Task HandleBundleAsync(ReceiveEngine engine, CompletedTransfer completed)
    {
        var manifest = completed.Manifest;
        var bridge = _bridge!;
        double seconds = (DateTime.UtcNow - (_sessionStartedUtc ?? _runStartedUtc)).TotalSeconds;
        string senderKey = "sign " + Short(KeyId.ToHex(manifest.SenderSigningKeyId));
        string sha256 = Convert.ToHexString(completed.PlaintextSha256);
        bool committed = false;

        InboxEntry Row(InboxOutcome outcome, string name, string? reason, IReadOnlyList<ChainStep> chain) => new()
        {
            Type = BundleType,
            Name = name,
            Size = manifest.OriginalSize,
            ArrivedAt = DateTime.Now,
            Outcome = outcome,
            SenderKeyShort = senderKey,
            SenderKeyId = KeyId.ToHex(manifest.SenderSigningKeyId),
            SessionId = manifest.SessionId.ToString("N"),
            Receipt = completed.ReceiptHash,
            Seconds = seconds,
            ContentType = manifest.ContentType,
            Counter = manifest.Counter,
            PlaintextSha256 = sha256,
            Reason = reason,
            Chain = chain,
            Bridged = true,
        };

        try
        {
            StoredBundle stored;
            try
            {
                // Off the UI thread: SQLite's async calls run synchronously.
                stored = await Task.Run(() => bridge.Writer.StoreAsync(completed.Plaintext, manifest.SessionId, CancellationToken.None));
            }
            catch (InvalidDataException ex)
            {
                // A genuine session whose bundle is not acceptable: the same bytes would fail again, so settle it.
                engine.CommitReplay();
                committed = true;
                _journal.RecordTransfer(manifest.SessionId, completed.PlaintextSha256, manifest.Filename, manifest.OriginalSize, "bundle_rejected");
                _audit.Append("receive.bundle_rejected", new Dictionary<string, string>
                {
                    ["session"] = manifest.SessionId.ToString(),
                    ["file"] = manifest.Filename,
                    ["reason"] = ex.Message,
                });
                AddEntry(Row(InboxOutcome.Rejected, manifest.Filename, $"Content gate: bundle refused — {ex.Message} Nothing was stored.",
                    RejectionChain("Content gate")));
                return;
            }

            bool newRun = _journal.IsNewRun(manifest.SenderSigningKeyId, manifest.CounterRunId);
            engine.CommitReplay(); // only now: the messages are in the Inbox
            committed = true;
            if (newRun) AuditNewCounterRun(manifest);
            _journal.RecordTransfer(manifest.SessionId, completed.PlaintextSha256, manifest.Filename, manifest.OriginalSize, "stored");
            _audit.Append("receive.bundle_stored", new Dictionary<string, string>
            {
                ["session"] = manifest.SessionId.ToString(),
                ["bundle"] = stored.BundleId.ToString(),
                ["messages"] = stored.Count.ToString(),
                ["added"] = stored.Added.ToString(),
                ["duplicates"] = stored.Duplicates.ToString(),
                ["sequences"] = $"{stored.MinSequence}-{stored.MaxSequence}",
                ["receipt"] = completed.ReceiptHash,
            });

            string name = $"bundle {stored.MinSequence}–{stored.MaxSequence} · {stored.Count} message{(stored.Count == 1 ? "" : "s")}" +
                          (stored.Duplicates > 0 ? $" ({stored.Duplicates} already there)" : "");
            AddEntry(Row(InboxOutcome.Verified, name,
                $"Stored in the gateway's Inbox ({bridge.Database}); the gateway delivers it. " +
                (stored.Duplicates > 0 ? "Messages already there were skipped and are owed a new Receipt." : ""),
                VerifiedChain(manifest, sha256, seconds)));
        }
        catch (Exception ex)
        {
            _audit.Append("receive.store_failed", new Dictionary<string, string>
            {
                ["session"] = manifest.SessionId.ToString(),
                ["error"] = ex.Message,
                ["committed"] = committed.ToString(),
            });
            if (_inbox.FirstOrDefault() is { Outcome: InboxOutcome.StoreFailed } top && top.SessionId == manifest.SessionId.ToString("N"))
                top.Repeats++;
            else
                AddEntry(Row(InboxOutcome.StoreFailed, manifest.Filename,
                    committed
                        ? $"Stored in the gateway's Inbox, but the journal could not complete its row: {ex.Message}"
                        : $"The gateway's Inbox could not be written: {ex.Message} — it can still arrive while the sender shows it.",
                    StoreFailedChain(ex.Message)));
        }
        finally
        {
            engine.Reset(settle: committed);
            _sessionStartedUtc = null;
            _lastActiveSession = Guid.Empty;
            TransferProgress.Value = 0;
            ProgressPercent.Text = "0%";
            RibbonText.Text = "session complete → waiting for the next manifest";
        }
    }

    /// <summary>Gateway mode received a genuine session that is not a gateway bundle (an XML or JSON file): refused, nothing written.</summary>
    private void HandleNotABundle(ReceiveEngine engine, CompletedTransfer completed)
    {
        var manifest = completed.Manifest;
        try
        {
            engine.CommitReplay(); // genuine, but not for this receiver: never judged again
            _journal.RecordTransfer(manifest.SessionId, completed.PlaintextSha256, manifest.Filename, manifest.OriginalSize, "not_a_bundle");
        }
        catch (Exception) { /* the journal is busy: the carousel shows it again and it is refused again */ }

        _audit.Append("receive.not_a_bundle", new Dictionary<string, string>
        {
            ["session"] = manifest.SessionId.ToString(),
            ["file"] = manifest.Filename,
        });
        AddEntry(new InboxEntry
        {
            Type = PayloadCatalogue.ForFilename(manifest.Filename, manifest.ContentType),
            Name = manifest.Filename,
            Size = manifest.OriginalSize,
            ArrivedAt = DateTime.Now,
            Outcome = InboxOutcome.Rejected,
            SenderKeyShort = "sign " + Short(KeyId.ToHex(manifest.SenderSigningKeyId)),
            SenderKeyId = KeyId.ToHex(manifest.SenderSigningKeyId),
            SessionId = manifest.SessionId.ToString("N"),
            ContentType = manifest.ContentType,
            Counter = manifest.Counter,
            Reason = "Content gate: this receiver runs in Gateway mode and accepts only gateway bundles. Nothing was written.",
            Chain = RejectionChain("Content gate"),
        });
        engine.Reset();
        RibbonText.Text = "not a gateway bundle — nothing was written → waiting for the next manifest";
    }

    /// <summary>
    /// Shows a rejection. It never resets the engine: the engine has already cleared its own state,
    /// and by the time this runs on the UI thread it may have locked onto the next, genuine session —
    /// a reset here would throw that session away.
    /// </summary>
    private void HandleRejection(RejectionInfo info)
    {
        var manifest = info.Manifest;

        // The tail of a session stored before a Stop/Start: the new engine does not remember it, the
        // journal does. Not an attack and not a failure, so no red row.
        if (manifest is not null &&
            info.Reason.EndsWith(nameof(ReplayVerdict.DuplicateSession), StringComparison.Ordinal) &&
            IsStoredSession(manifest.SessionId))
        {
            HandleAlreadyReceived(manifest);
            return;
        }

        _audit.Append("receive.rejected", new Dictionary<string, string> { ["reason"] = info.Reason });

        var type = manifest is not null
            ? PayloadCatalogue.ForFilename(manifest.Filename, manifest.ContentType)
            : PayloadCatalogue.ManualFile with { Name = "unverified frame", Code = "???" };

        // The carousel replays a bad manifest for the rest of its air time; identical
        // back-to-back rejections coalesce into one row instead of flooding the inbox.
        if (_inbox.FirstOrDefault() is { Outcome: InboxOutcome.Rejected } top &&
            top.Reason == info.Reason &&
            (DateTime.Now - top.ArrivedAt) < TimeSpan.FromSeconds(30))
        {
            top.Repeats++;
            return;
        }

        AddEntry(new InboxEntry
        {
            Type = type,
            Name = manifest?.Filename ?? "unverified frame",
            Size = manifest?.OriginalSize ?? 0,
            ArrivedAt = DateTime.Now,
            Outcome = InboxOutcome.Rejected,
            SenderKeyShort = manifest is not null
                ? "sign " + Short(KeyId.ToHex(manifest.SenderSigningKeyId))
                : "sender not established",
            SenderKeyId = manifest is not null ? KeyId.ToHex(manifest.SenderSigningKeyId) : "",
            SessionId = manifest?.SessionId.ToString("N") ?? "",
            ContentType = manifest?.ContentType ?? ContentKind.File,
            Counter = manifest?.Counter ?? 0,
            Reason = info.Reason,
            Chain = RejectionChain(info.Reason),
        });

        // Only clear the progress display when the engine is not already on a newer session.
        if (_engine?.ActiveManifest is null)
        {
            _sessionStartedUtc = null;
            _lastActiveSession = Guid.Empty;
            TransferProgress.Value = 0;
            ProgressPercent.Text = "0%";
            RibbonText.Text = "session rejected — nothing was written → waiting for the next manifest";
        }
    }

    private bool IsStoredSession(Guid sessionId)
    {
        try
        {
            return _journal.IsStoredSession(sessionId);
        }
        catch (Exception)
        {
            return false; // unknown: show the rejection as it is
        }
    }

    /// <summary>A session the journal already stored, seen again (its carousel tail after a restart).</summary>
    private void HandleAlreadyReceived(TransferManifest manifest)
    {
        string session = manifest.SessionId.ToString("N");
        if (_inbox.FirstOrDefault() is { Outcome: InboxOutcome.Duplicate } top && top.SessionId == session)
        {
            top.Repeats++;
            return;
        }

        _audit.Append("receive.already_received", new Dictionary<string, string>
        {
            ["session"] = manifest.SessionId.ToString(),
            ["file"] = manifest.Filename,
        });
        AddEntry(new InboxEntry
        {
            Type = PayloadCatalogue.ForFilename(manifest.Filename, manifest.ContentType),
            Name = manifest.Filename,
            Size = manifest.OriginalSize,
            ArrivedAt = DateTime.Now,
            Outcome = InboxOutcome.Duplicate,
            SenderKeyShort = "sign " + Short(KeyId.ToHex(manifest.SenderSigningKeyId)),
            SenderKeyId = KeyId.ToHex(manifest.SenderSigningKeyId),
            SessionId = session,
            ContentType = manifest.ContentType,
            Counter = manifest.Counter,
            Reason = "Already received and stored earlier: the sender was still showing it when this receiver " +
                     "started. Nothing was written.",
            Chain = AlreadyReceivedChain(),
        });
    }

    /// <summary>
    /// A partly received session the engine gave up for a newer one. The engine is already on the new
    /// session, so nothing is reset here. The sender must send this one again.
    /// </summary>
    private void HandleAbandoned(AbandonedSession abandoned)
    {
        _audit.Append("receive.abandoned", new Dictionary<string, string>
        {
            ["session"] = abandoned.SessionId.ToString(),
            ["file"] = abandoned.Filename,
            ["counter"] = abandoned.Counter.ToString(),
            ["blocks"] = $"{abandoned.DecodedSourceCount}/{abandoned.K}",
            ["symbols"] = abandoned.UniqueSymbolsReceived.ToString(),
        });
        AddEntry(new InboxEntry
        {
            Type = PayloadCatalogue.ForFilename(abandoned.Filename, abandoned.ContentType),
            Name = abandoned.Filename,
            Size = abandoned.OriginalSize,
            ArrivedAt = DateTime.Now,
            Outcome = InboxOutcome.Incomplete,
            SenderKeyShort = "sign " + Short(KeyId.ToHex(abandoned.SenderSigningKeyId)),
            SenderKeyId = KeyId.ToHex(abandoned.SenderSigningKeyId),
            SessionId = abandoned.SessionId.ToString("N"),
            ContentType = abandoned.ContentType,
            Counter = abandoned.Counter,
            Reason = $"Incomplete: {abandoned.Filename} was NOT received ({abandoned.DecodedSourceCount}/{abandoned.K} blocks). " +
                     "It must be re-sent.",
            Chain = IncompleteChain(abandoned),
        });
    }

    private void AuditNewCounterRun(TransferManifest manifest) =>
        _audit.Append("receive.new_counter_run", new Dictionary<string, string>
        {
            ["senderKey"] = KeyId.ToHex(manifest.SenderSigningKeyId),
            ["run"] = manifest.CounterRunId.ToString("N"),
            ["counter"] = manifest.Counter.ToString(),
        });

    // ═══════════════════ verification chain ═══════════════════

    private static IReadOnlyList<ChainStep> VerifiedChain(TransferManifest manifest, string plaintextSha256, double seconds) =>
    [
        new(ChainSteps[0], ChainStatus.Passed, "CRC-32 + span parse"),
        new(ChainSteps[1], ChainStatus.Passed, "sign " + Short(KeyId.ToHex(manifest.SenderSigningKeyId))),
        new(ChainSteps[2], ChainStatus.Passed, "kex " + Short(KeyId.ToHex(manifest.ReceiverAgreementKeyId))),
        new(ChainSteps[3], ChainStatus.Passed, $"counter {manifest.Counter} · run {manifest.CounterRunId.ToString("N")[..8]}"),
        new(ChainSteps[4], ChainStatus.Passed, "every data frame authenticated"),
        new(ChainSteps[5], ChainStatus.Passed, "sha256 " + Short(Convert.ToHexString(manifest.CiphertextSha256))),
        new(ChainSteps[6], ChainStatus.Passed, "tag ok"),
        new(ChainSteps[7], ChainStatus.Passed, manifest.Compression == CompressionAlg.Brotli
            ? $"{manifest.CompressedSize:N0} → {manifest.OriginalSize:N0} B" : "not compressed"),
        new(ChainSteps[8], ChainStatus.Passed, $"{manifest.OriginalSize:N0} B · sha256 {Short(plaintextSha256)}"),
        new(ChainSteps[9], ChainStatus.Passed, manifest.ContentType.ToString().ToLowerInvariant()),
        new(ChainSteps[StoredStep], ChainStatus.Passed, $"journal.db + audit · {seconds:0.0} s"),
    ];

    private static IReadOnlyList<ChainStep> DuplicateChain()
    {
        var steps = new List<ChainStep>();
        for (int i = 0; i < StoredStep; i++) steps.Add(new ChainStep(ChainSteps[i], ChainStatus.Passed, ""));
        steps.Add(new ChainStep(ChainSteps[StoredStep], ChainStatus.NotReached, "already stored — nothing written"));
        return steps;
    }

    private static IReadOnlyList<ChainStep> StoreFailedChain(string error)
    {
        var steps = new List<ChainStep>();
        for (int i = 0; i < StoredStep; i++) steps.Add(new ChainStep(ChainSteps[i], ChainStatus.Passed, ""));
        steps.Add(new ChainStep(ChainSteps[StoredStep], ChainStatus.Failed, Trim(error, 40)));
        return steps;
    }

    private static IReadOnlyList<ChainStep> AlreadyReceivedChain()
    {
        var steps = new List<ChainStep>();
        for (int i = 0; i < ChainSteps.Length; i++)
        {
            steps.Add(i switch
            {
                < 3 => new ChainStep(ChainSteps[i], ChainStatus.Passed, ""),
                3 => new ChainStep(ChainSteps[i], ChainStatus.Failed, "already received earlier"),
                _ => new ChainStep(ChainSteps[i], ChainStatus.NotReached,
                    i == StoredStep ? "already stored — nothing written" : "not needed"),
            });
        }
        return steps;
    }

    /// <summary>The frames that arrived were genuine; there were not enough before the sender moved on.</summary>
    private static IReadOnlyList<ChainStep> IncompleteChain(AbandonedSession abandoned)
    {
        var steps = new List<ChainStep>();
        for (int i = 0; i < ChainSteps.Length; i++)
        {
            steps.Add(i switch
            {
                < 5 => new ChainStep(ChainSteps[i], ChainStatus.Passed, ""),
                5 => new ChainStep(ChainSteps[i], ChainStatus.Failed,
                    $"only {abandoned.DecodedSourceCount}/{abandoned.K} blocks — sender moved on"),
                _ => new ChainStep(ChainSteps[i], ChainStatus.NotReached,
                    i == StoredStep ? "nothing written — must be re-sent" : "not reached"),
            });
        }
        return steps;
    }

    /// <summary>
    /// Everything before the failing step verified, everything after it was never reached —
    /// which is the whole point of failing closed, so the operator gets to see it.
    /// </summary>
    private static IReadOnlyList<ChainStep> RejectionChain(string reason)
    {
        int failed = reason switch
        {
            _ when reason.StartsWith("Manifest parse", StringComparison.Ordinal) => 0,
            _ when reason.StartsWith("Unknown sender key", StringComparison.Ordinal) => 1,
            _ when reason.Contains("signature", StringComparison.OrdinalIgnoreCase) => 1,
            _ when reason.Contains("different receiver", StringComparison.OrdinalIgnoreCase) => 2,
            _ when reason.StartsWith("Replay check", StringComparison.Ordinal) => 3,
            _ when reason.StartsWith("Key agreement", StringComparison.Ordinal) => 4,
            _ when reason.StartsWith("Ciphertext hash", StringComparison.Ordinal) => 5,
            _ when reason.StartsWith("AES-GCM", StringComparison.Ordinal) => 6,
            _ when reason.StartsWith("Decompression", StringComparison.Ordinal) => 7,
            _ when reason.StartsWith("Plaintext", StringComparison.Ordinal) => 8,
            _ when reason.StartsWith("Content gate", StringComparison.Ordinal) => 9,
            _ => StoredStep,
        };

        var steps = new List<ChainStep>();
        for (int i = 0; i < ChainSteps.Length; i++)
        {
            if (i < failed) steps.Add(new ChainStep(ChainSteps[i], ChainStatus.Passed, ""));
            else if (i == failed) steps.Add(new ChainStep(ChainSteps[i], ChainStatus.Failed, Trim(reason, 44)));
            else steps.Add(new ChainStep(ChainSteps[i], ChainStatus.NotReached,
                i == ChainSteps.Length - 1 ? "nothing written" : "not reached"));
        }
        return steps;
    }

    /// <summary>The viewer's copy of a payload — bounded, because 500 rows of 64 MB is not a UI.</summary>
    private static byte[] Capped(byte[] plaintext) =>
        plaintext.Length <= InboxEntry.PreviewBytes ? plaintext : plaintext[..InboxEntry.PreviewBytes];

    // ═══════════════════ inbox ═══════════════════

    private void AddEntry(InboxEntry entry)
    {
        _inbox.Insert(0, entry);

        // Rows keep their metadata for the whole run; their bytes only while they are near the top.
        // Anything older is read back from the store on demand.
        if (_inbox.Count > InboxEntry.PreviewDepth)
            _inbox[InboxEntry.PreviewDepth].PreviewData = null;
        while (_inbox.Count > 500) _inbox.RemoveAt(_inbox.Count - 1);

        IndexArrival(entry);

        switch (entry.Outcome)
        {
            case InboxOutcome.Verified: _tallyOk++; break;
            case InboxOutcome.Duplicate: _tallyDup++; break;
            default: _tallyBad++; break;
        }
        RefreshTallies();

        if (AutoFollowToggle.IsChecked == true && PassesFilter(entry))
            InboxList.SelectedItem = entry;
    }

    private bool PassesFilter(InboxEntry entry)
    {
        if (!entry.Matches(SearchBox?.Text ?? "")) return false;
        if (FilterOk?.IsChecked == true) return entry.Outcome == InboxOutcome.Verified;
        if (FilterDup?.IsChecked == true) return entry.Outcome == InboxOutcome.Duplicate;
        if (FilterBad?.IsChecked == true) return entry.Outcome is InboxOutcome.Rejected or InboxOutcome.StoreFailed or InboxOutcome.Incomplete;
        return true;
    }

    private void Filter_Changed(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        _inboxView.Refresh();
        RefreshTallies();
    }

    private void RefreshTallies()
    {
        InboxCountText.Text = _inboxView.Count == _inbox.Count
            ? _inbox.Count.ToString()
            : $"{_inboxView.Count}/{_inbox.Count}";
        TallyOkText.Text = $"✔ {_tallyOk}";
        TallyDupText.Text = $"◎ {_tallyDup}";
        TallyBadText.Text = $"✖ {_tallyBad}";
        InboxEmpty.Visibility = _inboxView.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    private void Inbox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_ready) RenderDetail(InboxList.SelectedItem as InboxEntry);
    }

    private void ViewMode_Changed(object sender, RoutedEventArgs e)
    {
        if (_ready) RenderPayload();
    }

    private void RenderDetail(InboxEntry? entry)
    {
        _selected = entry;
        ChainList.ItemsSource = entry?.Chain;

        if (entry is null)
        {
            SetPill(DetailOutcomePill, DetailOutcomeText, "nothing selected", "PillIdle");
            DetailNameText.Text = "";
            ReceiptBox.Text = "———— ———— ———— ————";
            ReceiptBox.Foreground = (Brush)FindResource("MutedBrush");
            StoredPathText.Text = "";
            CopyPayloadButton.IsEnabled = false;
            CopyReceiptButton.IsEnabled = false;
            OpenFolderButton.IsEnabled = false;
            PayloadViewer.Document = PayloadView.Message("Select an arrival to see its payload.");
            PreviewNoteText.Text = "";
            return;
        }

        SetPill(DetailOutcomePill, DetailOutcomeText, entry.OutcomeLabel, entry.Outcome switch
        {
            InboxOutcome.Verified => "PillOk",
            InboxOutcome.Duplicate or InboxOutcome.Incomplete => "PillWarn",
            _ => "PillBad",
        });
        DetailNameText.Text = $"{entry.Name} · {entry.SizeLabel}";

        bool hasReceipt = entry.Receipt.Length >= 16;
        ReceiptBox.Text = hasReceipt ? entry.ReceiptGrouped : "no receipt — nothing was verified";
        ReceiptBox.Foreground = (Brush)FindResource(
            entry.Outcome == InboxOutcome.Verified ? "SuccessTextBrush"
            : hasReceipt ? "WarningTextBrush" : "MutedBrush");

        StoredPathText.Text = entry.StoredPath is not null
            ? "stored  " + entry.StoredPath
            : entry.Reason ?? "nothing written";

        CopyReceiptButton.IsEnabled = hasReceipt;
        CopyPayloadButton.IsEnabled = entry.PreviewData is not null || entry.HasFile;
        OpenFolderButton.IsEnabled = entry.HasFile;
        RenderPayload();
    }

    private void RenderPayload()
    {
        var entry = _selected;
        _selectedText = PayloadText.Empty;

        if (entry is null)
        {
            PayloadViewer.Document = PayloadView.Message("Select an arrival to see its payload.");
            PreviewNoteText.Text = "";
            return;
        }

        if (entry.Bridged)
        {
            PayloadViewer.Document = PayloadView.Message(
                "Gateway messages are not kept or shown here: they are in the gateway's Inbox (qrbridge.db). " +
                "Open the gateway's read-only pages (/qrbridge-ui) to read them.");
            PreviewNoteText.Text = "";
            return;
        }

        byte[]? bytes = ResolveBytes(entry);
        if (bytes is null)
        {
            PayloadViewer.Document = PayloadView.Message(
                entry.Outcome is InboxOutcome.Rejected or InboxOutcome.Incomplete
                    ? "No payload to show — the chain did not complete, so nothing was ever decrypted."
                    : "No payload to show — this row's bytes are no longer in memory and the file is gone from the store.");
            PreviewNoteText.Text = "";
            return;
        }

        _selectedText =
            ViewHex.IsChecked == true ? PayloadFormatter.Hex(bytes) :
            ViewRaw.IsChecked == true ? PayloadFormatter.Raw(entry.ContentType, bytes) :
            PayloadFormatter.Formatted(entry.ContentType, bytes);

        PayloadViewer.Document = PayloadView.Build(_selectedText);

        PreviewNoteText.Text =
            entry.PreviewTruncated || _selectedText.Truncated
                ? $"showing the first {bytes.Length / 1024} KB — the whole payload is in the store"
                : entry.PlaintextSha256 is { Length: 64 } hash ? "sha256 " + Short(hash) : "";
    }

    /// <summary>
    /// The viewer's bytes: the in-memory copy while the row is recent, otherwise read back from the
    /// store. An arrival that scrolled out of the preview window is still fully inspectable —
    /// that is the point of writing it down.
    /// </summary>
    private byte[]? ResolveBytes(InboxEntry entry)
    {
        if (entry.PreviewData is { } cached) return cached;
        if (ReferenceEquals(_loadedFor, entry)) return _loadedBytes;
        if (entry.StoredPath is not { Length: > 0 } path || !File.Exists(path)) return null;

        try
        {
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            int length = (int)Math.Min(stream.Length, InboxEntry.PreviewBytes);
            var buffer = new byte[length];
            stream.ReadExactly(buffer);
            _loadedFor = entry;
            _loadedBytes = buffer;
            return buffer;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return null;
        }
    }

    private InboxEntry? _loadedFor;
    private byte[]? _loadedBytes;

    private void CopyPayload_Click(object sender, RoutedEventArgs e) => CopyToClipboard(_selectedText.Text);

    private void CopyReceipt_Click(object sender, RoutedEventArgs e) => CopyToClipboard(_selected?.Receipt);

    private void OpenFolder_Click(object sender, RoutedEventArgs e)
    {
        if (_selected?.StoredPath is not { } path || !File.Exists(path)) return;
        try
        {
            Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{path}\"") { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            ShowError($"Could not open the quarantine folder: {ex.Message}");
        }
    }

    private static void CopyToClipboard(string? text)
    {
        if (string.IsNullOrEmpty(text)) return;
        try { Clipboard.SetText(text); } catch (Exception) { /* clipboard busy — not worth an error */ }
    }

    // ═══════════════════ live tick ═══════════════════

    private void OnUiTick(object? sender, EventArgs e)
    {
        var engine = _engine;
        var pipeline = _pipeline;
        if (engine is null || pipeline is null) return;

        if (engine.ActiveManifest is { } manifest)
        {
            if (manifest.SessionId != _lastActiveSession)
            {
                _lastActiveSession = manifest.SessionId;
                _sessionStartedUtc = DateTime.UtcNow;
                RibbonText.Text = $"manifest verified · receiving {manifest.Filename} — nothing is written until the chain completes";
            }
            TransferProgress.Value = engine.Progress;
            ProgressPercent.Text = $"{engine.Progress * 100:0}%";
            ProgressText.Text =
                $"{manifest.Filename} ({manifest.OriginalSize:N0} B) · blocks {engine.DecodedSourceCount}/{engine.K} · " +
                $"symbols {engine.UniqueSymbolsReceived} · session {manifest.SessionId:N}";
            PreviewProgressText.Text = $"blocks {engine.DecodedSourceCount}/{engine.K} · symbols {engine.UniqueSymbolsReceived}";
        }
        else
        {
            ProgressText.Text = "waiting for a manifest…";
            PreviewProgressText.Text = "searching for a manifest";
        }

        double elapsed = Math.Max(0.1, (DateTime.UtcNow - _runStartedUtc).TotalSeconds);
        TelemetryText.Text =
            $"frames {pipeline.FramesSeen} · analyzed {pipeline.FramesDecoded} · QR hits {pipeline.QrHits} · " +
            $"{pipeline.FramesDecoded / elapsed:0.0} analyzed/s · {pipeline.QrHits / elapsed:0.0} hits/s" +
            (pipeline.FramesUnreadable > 0 ? $" · {pipeline.FramesUnreadable} unreadable" : "");

        // Frames arriving but none of them convertible is a broken capture path, not a bad aim.
        // Say so rather than leaving the operator staring at a black preview and "analyzed 0".
        if (pipeline.FramesDecoded == 0 && pipeline.FramesUnreadable > 60)
            ShowError($"The camera is delivering frames this build cannot read " +
                      $"({(CameraCombo.SelectedItem as CameraChoice)?.Characteristics.PixelFormat}). " +
                      "Pick a different camera mode with ↻ Refresh, or choose another camera.");

        // Lock-on: the border is the peripheral-vision signal, the pill carries the word.
        long hits = pipeline.QrHits;
        SetLock(hits > _lastQrHits);
        _lastQrHits = hits;

        var preview = _pendingPreview;
        if (preview.Pixels is { Length: > 0 })
        {
            _pendingPreview = default;
            if (_previewBitmap is null || _previewBitmap.PixelWidth != preview.Width || _previewBitmap.PixelHeight != preview.Height)
            {
                _previewBitmap = new WriteableBitmap(preview.Width, preview.Height, 96, 96,
                    System.Windows.Media.PixelFormats.Gray8, null);
                PreviewImage.Source = _previewBitmap;
            }
            _previewBitmap.WritePixels(new Int32Rect(0, 0, preview.Width, preview.Height), preview.Pixels, preview.Width, 0);
        }
    }

    private bool _locked;
    private bool _lockShownRunning;
    private void SetLock(bool locked)
    {
        bool running = _pipeline is not null;
        // Both inputs must be compared: after a Stop/Start the pill was left reading STOPPED
        // because the lock state itself had not changed.
        if (locked == _locked && running == _lockShownRunning) return;
        _locked = locked;
        _lockShownRunning = running;

        PreviewBorder.BorderBrush = (Brush)FindResource(
            !running ? "Neutral800Brush" : locked ? "SuccessBrush" : "Neutral700Brush");
        ScanDot.Fill = (Brush)FindResource(!running ? "Neutral500Brush" : locked ? "SuccessBrush" : "Neutral500Brush");
        ScanPillText.Text = !running ? "STOPPED" : locked ? "LOCKED — decoding" : "SEARCHING";
        ScanPill.Style = (Style)FindResource(!running ? "PillIdle" : locked ? "PillOk" : "PillIdle");
    }

    // ═══════════════════ helpers ═══════════════════

    private void ShowError(string message)
    {
        ErrorPill.Visibility = Visibility.Visible;
        ErrorPillText.Text = "✖ " + message;
    }

    private void HideError() => ErrorPill.Visibility = Visibility.Collapsed;

    private void SetPill(Border pill, TextBlock text, string label, string styleKey)
    {
        text.Text = label;
        pill.Style = (Style)FindResource(styleKey);
    }

    /// <summary>First and last four of a long hex value — enough to compare, short enough to fit.</summary>
    private static string Short(string hex) =>
        hex.Length <= 12 ? hex : $"{hex[..4]}…{hex[^4..]}";

    private static string Trim(string text, int max) =>
        text.Length <= max ? text : text[..(max - 1)] + "…";

    protected override async void OnClosed(EventArgs e)
    {
        _uiTimer.Stop();
        _beatTimer.Stop();
        if (_pipeline is not null) await _pipeline.DisposeAsync();
        if (_bridge is not null) await _bridge.DisposeAsync();
        _trust?.Dispose();
        foreach (var retired in _retiredTrust) retired.Dispose();
        _pairingVerifier?.Dispose();
        _keys?.Dispose();
        base.OnClosed(e);
    }
}
