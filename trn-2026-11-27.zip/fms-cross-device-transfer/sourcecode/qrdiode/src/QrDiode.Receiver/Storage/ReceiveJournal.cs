using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrDiode.Core.Manifest;
using QrDiode.Core.Pipeline;
using QrDiode.Receiver.Inbox;

namespace QrDiode.Receiver.Storage;

/// <summary>
/// The Receiver's transfer journal and anti-replay store, kept in the bridge database it shares with the gateway and
/// the Sender on this machine (<see cref="IReceiveJournalRepository"/>, through <c>QrAppBridge.Journal</c>). This class
/// holds no data access of its own: it translates between QrDiode's types (<see cref="IReplayGuard"/>, the archive tab's
/// records) and the shared repository. Until 27 Nov 2026 it was a SQLite file of its own (journal.db), copied in once.
/// Status flow: the payload is written to the store first, then <see cref="Commit"/> adds a 'verified' row and the
/// watermark, then the row becomes 'stored' (or 'duplicate'). A crash before the commit leaves the session receivable
/// again; a 'verified' row means a crash after it, with the file already on disk.
/// </summary>
public sealed class ReceiveJournal(IReceiveJournalRepository journal, TimeProvider? clock = null, TimeSpan? replayWindow = null)
    : IReplayGuard
{
    private readonly TimeProvider _clock = clock ?? TimeProvider.System;
    private readonly object _lock = new();

    /// <summary>
    /// Anti-replay timestamp tolerance. Settable because the journal outlives a run — the archive
    /// tab reads it while nothing is being received — but the receiver commits it at Start and
    /// locks the control for the duration, so it never moves under a session in flight.
    /// </summary>
    public TimeSpan ReplayWindow { get; set; } = replayWindow ?? TimeSpan.FromHours(48);

    public ReplayVerdict Check(ReadOnlySpan<byte> senderSigningKeyId, Guid sessionId, Guid counterRunId, ulong counter, long timestampUnixMs)
    {
        string key = Convert.ToHexString(senderSigningKeyId);
        lock (_lock)
        {
            return journal.CheckReplay(key, sessionId, counterRunId, counter, timestampUnixMs, ReplayWindow, _clock.GetUtcNow()) switch
            {
                JournalReplayCheck.KnownSession => ReplayVerdict.DuplicateSession,
                JournalReplayCheck.StaleCounter => ReplayVerdict.StaleCounter,
                JournalReplayCheck.OutsideWindow => ReplayVerdict.TimestampOutOfWindow,
                _ => ReplayVerdict.Fresh,
            };
        }
    }

    public void Commit(ReadOnlySpan<byte> senderSigningKeyId, Guid sessionId, Guid counterRunId, ulong counter)
    {
        // The host calls this (through ReceiveEngine.CommitReplay) once the payload is stored; the
        // row is completed by RecordTransfer.
        string key = Convert.ToHexString(senderSigningKeyId);
        lock (_lock) journal.CommitReplay(key, sessionId, counterRunId, counter, _clock.GetUtcNow());
    }

    /// <summary>True when this sender key has never committed a session in this counter run.</summary>
    public bool IsNewRun(ReadOnlySpan<byte> senderSigningKeyId, Guid counterRunId)
    {
        string key = Convert.ToHexString(senderSigningKeyId);
        lock (_lock) return journal.IsNewRun(key, counterRunId);
    }

    /// <summary>True when this session was already received and stored (or recorded as a duplicate).</summary>
    public bool IsStoredSession(Guid sessionId)
    {
        lock (_lock) return journal.IsStoredSession(sessionId);
    }

    /// <summary>True if this sender has already delivered a payload with this plaintext hash.</summary>
    public bool IsDuplicateContent(ReadOnlySpan<byte> senderSigningKeyId, ReadOnlySpan<byte> plaintextSha256)
    {
        string key = Convert.ToHexString(senderSigningKeyId);
        string hash = Convert.ToHexString(plaintextSha256);
        lock (_lock) return journal.IsDuplicateContent(key, hash);
    }

    /// <summary>Completes the journal row for a materialized (or deduplicated) transfer.</summary>
    public void RecordTransfer(Guid sessionId, ReadOnlySpan<byte> plaintextSha256, string filename, long size, string status)
    {
        string hash = Convert.ToHexString(plaintextSha256);
        lock (_lock) journal.RecordTransfer(sessionId, hash, filename, size, status);
    }

    // ═══════════════════ archive index ═══════════════════

    /// <summary>
    /// Records one arrival — stored, duplicate, rejected or failed — for the archive browser.
    /// This is an index over what happened, not the payload itself: the bytes live in the payload
    /// store, and this row is what makes them findable months later.
    /// </summary>
    public long IndexArrival(ArchiveRecord record)
    {
        var entry = new JournalArchiveEntry
        {
            ReceivedUtc = record.ReceivedUtc.ToUniversalTime(),
            Outcome = ToStatus(record.Outcome),
            SessionId = record.SessionId,
            SenderKeyId = record.SenderKeyId,
            Counter = unchecked((long)record.Counter),
            TypeCode = record.Type.Code,
            TypeName = record.Type.Name,
            ContentKind = (int)record.ContentType,
            Filename = record.Filename,
            Size = record.Size,
            Sha256 = record.Sha256,
            Receipt = record.Receipt,
            StoredPath = record.StoredPath,
            Reason = record.Reason,
            Seconds = record.Seconds,
            Snippet = record.Snippet,
        };
        lock (_lock) return journal.AddArchiveEntry(entry);
    }

    public IReadOnlyList<ArchiveRecord> QueryArchive(ArchiveQuery query)
    {
        IReadOnlyList<JournalArchiveEntry> rows;
        lock (_lock) rows = journal.FindArchiveEntries(Filter(query), query.Limit); // rows, not bytes
        return rows.Select(r => new ArchiveRecord
        {
            Id = r.Id,
            ReceivedUtc = r.ReceivedUtc,
            Outcome = FromStatus(r.Outcome),
            SessionId = r.SessionId,
            SenderKeyId = r.SenderKeyId,
            Counter = unchecked((ulong)r.Counter),
            ContentType = (ContentKind)r.ContentKind,
            Filename = r.Filename,
            Size = r.Size,
            Sha256 = r.Sha256,
            Receipt = r.Receipt,
            StoredPath = r.StoredPath,
            Reason = r.Reason,
            Seconds = r.Seconds,
            Snippet = r.Snippet,
        }).ToList();
    }

    /// <summary>Totals over everything the filter matches, not just the page that got loaded.</summary>
    public ArchiveTotals QueryTotals(ArchiveQuery query)
    {
        JournalArchiveTotals t;
        lock (_lock) t = journal.CountArchive(Filter(query with { Outcome = null }));
        return new ArchiveTotals(t.Arrivals, t.Verified, t.Duplicates, t.NotLanded, t.StoredBytes, t.FirstUtc, t.LastUtc);
    }

    /// <summary>What arrived, by payload type — the shape of the traffic this receiver sees.</summary>
    public IReadOnlyList<TypeTally> QueryTypeTallies(ArchiveQuery query)
    {
        lock (_lock) return journal.CountArchiveByType(Filter(query)).Select(t => new TypeTally(t.Code, t.Name, t.Count, t.Bytes)).ToList();
    }

    private static JournalArchiveFilter Filter(ArchiveQuery query) => new(
        query.Search,
        query.Outcome switch
        {
            null => null,
            // "✖" on the filter tray means "did not land", which covers every way that happens.
            InboxOutcome.Rejected => JournalOutcomes.NotLanded.ToArray(),
            { } outcome => [ToStatus(outcome)],
        },
        query.SinceUtc?.ToUniversalTime());

    private static string ToStatus(InboxOutcome outcome) => outcome switch
    {
        InboxOutcome.Verified => JournalOutcomes.Verified,
        InboxOutcome.Duplicate => JournalOutcomes.Duplicate,
        InboxOutcome.StoreFailed => JournalOutcomes.StoreFailed,
        InboxOutcome.Incomplete => JournalOutcomes.Incomplete,
        _ => JournalOutcomes.Rejected,
    };

    private static InboxOutcome FromStatus(string status) => status switch
    {
        JournalOutcomes.Verified => InboxOutcome.Verified,
        JournalOutcomes.Duplicate => InboxOutcome.Duplicate,
        JournalOutcomes.StoreFailed => InboxOutcome.StoreFailed,
        JournalOutcomes.Incomplete => InboxOutcome.Incomplete,
        _ => InboxOutcome.Rejected,
    };
}