# GitHub Copilot Instructions — Gateway-to-QrDiode (`QrDiode_V2`)

Con Edison FMS **islanding mode**: when the firewalls between CorpNet and the FMS DMZ (ECC/AECC) are cut, SOAP/WCF
calls between the corporate apps (Rapid Restore FCR/FOD/SSO, DSS, FTC, Verizon) and the FMS-side services cross a
**light-only air gap** — QR codes on a screen, read by a camera, one lane per direction. Per side: **`QrBridge.Gateway`**
(IIS) stands in for the services on the other side and replays arrived calls to the real ones; **`QrDiode.Sender` /
`QrDiode.Receiver`** (WPF exe) carry the messages over the light (QrDiode is the only encryption layer). They meet only through
`C:\ProgramData\QrBridge\Data\qrbridge.db` (one SQLite file per machine: Outbox + Inbox tables; EF Core) and two named events.

**New on this machine?** Read [`docs/copilot-handover.md`](../docs/copilot-handover.md) first: what was built (the
read-only web UI last, 25–26 Nov 2026), how to check the machine, and where the work continues.

## Settled decisions — never reverse without asking Rowshan

1. **Callers cannot change** (not Con Ed's project). Corp callers reach services only via the **corporate load
   balancer**; islanding = LB re-pointed to the Corp gateway; DMZ side = configuration changes only. The gateway must
   be indistinguishable from the real service: same paths, SOAPActions, reply shapes and return types.
2. **Generic SOAP gateway that handles ANY WCF request** (SOAP 1.1/1.2, WS-Addressing, document/literal, RPC/encoded),
   driven by `sourcecode/gateway/src/QrBridge.Gateway/routes.json`. **No CoreWCF, no per-service contract classes.**
3. **Two solutions:** `sourcecode/gateway/QrGateway.slnx` (QrBridge.*) and `sourcecode/qrdiode/QrDiode.slnx` (QrDiode.*), each
   with `src/` + `tests/`; root `All.slnx` holds both. **Keep the QrDiode project structure** (Core, KeyCeremony,
   Sender, Receiver: same folders and names) **but implement features inside them** — notably EF Core SQLite access,
   via a relative `ProjectReference` to `sourcecode/gateway/src/QrBridge.Shared` (one copy; the gateway owns the schema).
4. **Deployables:** gateway → IIS site (the read-only UI is part of the gateway project, folder `Ui/`, decision 48);
   Sender/Receiver/KeyCeremony → self-contained single-file exe; `QrBridge.Shared` compiled into both. Two programs per
   machine, no Windows service.
5. **.NET 10 LTS**, Windows only (`global.json` pins 10.0; gateway packages 10.0.15). Do not move to .NET 11.

## Rules in the code

- **One way into the Gateway-to-QrDiode system:** `OutboxWriter`. Reply to the caller **only after the Outbox commit**.
- **Never re-serialize a caller's request:** the SOAP body passes through byte for byte (`MessageSerializer` never parses it) (legacy quirks like
  `<SOURCE_APPLICAION>` and static `MSG_ID="456"` must survive; never dedupe on `MSG_ID`).
- **Untrusted XML only through `SafeXml`** (DTDs prohibited, no resolver, size caps).
- **Receiver URLs only from configuration** (`Gateway:Receiver`), never from a message.
- **Services are configuration:** new/changed interfaces = `routes.json` + the service's WSDL in
  `QrBridge.Gateway/Contracts/` + a test — not code. Forwarded calls must match that WSDL before they are queued. The
  gateway serves no WSDL: only `GET /health`, the one Registered Tags GET route (`"HttpGet": true` in `routes.json`,
  decision D18) and the read-only UI under `/qrbridge-ui` (decision 48) answer; every other GET gets 405 (the
  simulator's clients never download a WSDL). No route may use a path under `/qrbridge-ui` (start-up refuses it).
- **The UI (gateway `Ui/`) is read-only:** it opens `qrbridge.db` only through `ReadOnlyBridgeDb` (SQLite
  `Mode=ReadOnly`), sees the gateway only through `UiGatewayInfo` (a test fails if a UI class takes a writer), has no
  button that changes anything, shows payloads only HTML-encoded (Razor, never `Html.Raw`) and never logs them.
  Requeue / acknowledge / archive from the UI: ask first.
  Both gateways must deploy the **identical** `routes.json`: every message carries its fingerprint, a mismatch is Rejected.
- **Never delete Outbox/Inbox rows automatically** (audit): operators archive manually.
- **`QrDiode.Core` stays independent of the SOAP Gateway** (no EF, SQLite or SOAP). Gateway and shared data code lives in `QrBridge.*`.
- **Never log payloads** — only service, operation, label, ids and sizes.
- Options are read after `Build()` through `IOptions<T>`. Pin package versions; no wildcards.
- Match the surrounding code: naming, comment density, "why" comments. Keep changes small and tested.
- **File layout:** one class or interface per file, named after it; exception classes go in the project's `Exceptions/`
  folder (one file each). Grouped instead: a record that belongs to a class goes in that class's file. Each project has
  `Configurations/Options/` (settings classes, one file per settings section with all its parts, e.g. `RoutingOptions.cs` =
  the whole `routes.json` shape), `Configurations/Enums/Enums.cs` (**all** its enums) and
  `Configurations/Helpers/Utility.cs` (static helpers used across the project) — all in the project's root
  namespace. Private nested types stay in their class. Static classes with
  their own logic (`SoapReplyWriter`, `PayloadInspector`) keep their own files. (Gateway, Shared and their tests follow
  this; some older QrDiode files do not yet — don't add more.)

## Working with Rowshan

- Owns the project; **new to WPF, comes from Angular** — explain WPF/XAML with Angular analogies.
- Wants **direct, plain English** and practical answers; when there are options, recommend one.
- Ask before restructuring projects or changing anything callers depend on. Don't commit or push unless asked.

## Build and check (Copilot agent mode can run these)

```powershell
dotnet test All.slnx                       # build both solutions + all tests — expected: 564 + 116 passed
dotnet build sourcecode\gateway\QrGateway.slnx    # one solution only (or sourcecode\qrdiode\QrDiode.slnx)
dotnet test sourcecode\gateway\tests\QrBridge.Tests --filter "FullyQualifiedName~EndToEnd"
# sample data for the read-only UI in C:\QrBridgeDev (the launch profiles' folders), see read-only-ui.md §2:
$env:QRBRIDGE_DEMO_ROOT = "C:\QrBridgeDev"; dotnet test sourcecode\gateway\tests\QrBridge.Tests --filter "FullyQualifiedName~UiDemoDataTests"
```

Environment traps (details in `docs/handoff.md` §7):

- Keep the solution at a **short path** (e.g. `C:\src\QrDiode_V2`): deep paths make Windows refuse to load the native
  `ZXing.dll` ("filename or extension is too long", 0x800700CE).
- Right after a `dotnet publish -r win-x64` the next build of the WPF projects can fail **once** (BG1002/CS2001:
  missing `.baml`/`.g.cs` in `obj`) — build again.
- Windows PowerShell 5.1: don't run `dotnet` under `$ErrorActionPreference = "Stop"` while capturing output (stderr
  lines become terminating errors); check `$LASTEXITCODE`.

## Map

| Path | What |
|---|---|
| `sourcecode/gateway/src/QrBridge.Gateway/` | IIS app: `Program.cs` (one call per start-up step), `Initializer/` (the steps: service registration per area, `StartupChecks`), `Configurations/` (`Options/`, `Enums/`, `Helpers/`), `Exceptions/`, `Controllers/` (thin HTTP entry points: SOAP POST, `/health`), `Ingress/` (gateway Sender part: `SenderEndpoint`, `OutboxWriter`; `Ingress/Validation/` = `ContractCatalog`: requests checked against `Contracts/*.wsdl`; `Ingress/Soap/` = `SoapRequest`, `PayloadInspector`, `SoapReplyWriter`), `Routing/` (catalogue + `RouteTable`), `Egress/` (gateway Receiver part: `SoapForwarderHttpClient`; `Egress/Workers/` = InboxWorker, MaintenanceWorker), `routes.json` |
| `sourcecode/gateway/src/QrBridge.Shared/` | `Data/` (entities, EF configs, `BridgeDbContext` for `qrbridge.db`, stores, `Migrations/`, `Initializers/SchemaAdoption`), `Serialization/` (`MessageSerializer` — `MessageHeader` + checksum + Brotli body, not encrypted), `Bundles/` (QR bundle format `BundleCodec`; the QR apps' ends: `OutboxBundler`, `InboxBundleWriter`, `QrAppBridge`), `Signals/` (doorbells), `SafeXml` (in `Configurations/Helpers/Utility.cs`) |
| `sourcecode/gateway/src/QrBridge.Gateway/Ui/` | Read-only web UI (Razor Pages in the gateway project, under `/qrbridge-ui`, login; wired in `Initializer/UiRegistration.cs`): `Pages/` (overview, Outbox/Inbox list and detail, login), `Data/` (`ReadOnlyBridgeDb`, `MessageQueries`), `Reading/MessageReader` (bytes → readable XML), `UiGatewayInfo` (its one way to the rest of the gateway), `Display`, `Security/`, `Assets/` (CSS/JS, embedded). Guide: `sourcecode/gateway/docs/reference/read-only-ui.md` |
| `sourcecode/qrdiode/src/QrDiode.Core/` | QR wire protocol, LT fountain codes, crypto; `Pipeline/ReceiveEngine.cs` |
| `sourcecode/qrdiode/src/QrDiode.Sender/`, `sourcecode/qrdiode/src/QrDiode.Receiver/` | WPF apps (`Transmit/TransmitEngine.cs`, Bridge mode `Transmit/OutboxSource.cs`; `MainWindow.xaml.cs` → `HandleCompletion` / `HandleBundleAsync`); settings in `appsettings.json` next to each exe (sections `QrDiode`, `Bridge`, `Sender`/`Receiver`) |
| `sourcecode/gateway/tests/QrBridge.Tests/` | `Gateway/Infrastructure/GatewayHost.cs` (real gateway in memory), `FakeSoapService.cs`, `Samples/` (simulator templates) |
| `sourcecode/qrdiode/tests/QrDiode.Core.Tests/` | QrDiode protocol tests |
| `docs/` | Shared: `gateway-to-qrdiode/architecture.md` (single system architecture), `handoff.md`, operations reference and integration plan |
| `sourcecode/gateway/docs/` | `gateway.md` is the entry point; `workflows/` has request/reply diagrams, `reference/` has code and service coverage, `reviews/` has the V6 review, fix plan and tracker |
| `sourcecode/qrdiode/docs/` | QrDiode protocol development notes, user guide, WPF tutorial, design prompt and HTML/PDF briefs in `brief/` |

## Known issues (as of 27 Nov 2026)

1. ~~`ReceiveEngine.FeedManifest` ignores every manifest while locked on a session.~~ Resolved 26 Nov: a newer verified
   session abandons the partial one (`SessionAbandoned`, an "Incomplete — must be re-sent" inbox row).
2. ~~`TransmitEngine` drops queued items beyond 14.~~ Resolved 26 Nov for everything but simulator payloads: only
   `QueueItem.Droppable` items (the simulator's) are ever skipped; Outbox items must stay non-droppable.
3. ~~`ReceiveEngine` commits the anti-replay watermark before the host stores the payload.~~ Resolved 26 Nov: the host
   stores first, then calls `engine.CommitReplay()`; a failed store uses `Reset(settle: false)`.
4. ~~Receiver pins its own SQLite packages.~~ Resolved 27 Nov: the Receiver gets SQLite only through `QrBridge.Shared`
   (EF Core 10.0.15 → Microsoft.Data.Sqlite.Core 10.0.15, one SQLitePCLRaw 2.1.13).
5. ~~Nothing sets Outbox rows `Aired`.~~ Resolved 27 Nov: with `"QrDiode:Mode": "Bridge"` the QR Sender airs the Outbox as
   bundles (`OutboxSource` → `OutboxBundler`, up to 50 messages / 128 KB, strict order, decision 52) and marks them
   `Aired` with their QR session; the QR Receiver stores arriving bundles in the Inbox (`InboxBundleWriter`, one
   transaction) and rings the doorbell. Proven with two in-memory gateways and the apps' own bundle code
   (`BundleLightTests`); **not tried on real screens and cameras**.
6. ~~Schema via `EnsureCreated`.~~ Resolved 27 Nov: EF migrations in `QrBridge.Shared/Data/Migrations` (`Initial`,
   `Bundles`). A database made earlier is matched against them and adopted with its rows (`SchemaAdoption`; tried on
   copies of both `C:\QrBridgeDev` databases); one that matches none stops the start unchanged (`SchemaMismatchException`).
   **From now on every entity or enum change needs `dotnet tool run dotnet-ef migrations add <Name> --project
   sourcecode\gateway\src\QrBridge.Shared --startup-project sourcecode\gateway\src\QrBridge.Shared`** (the tool is in
   `dotnet-tools.json`; `dotnet tool restore` on a new machine), and `MigrationTests` fails when one is missing.
   Since 25 Nov there is **one** database per machine, `qrbridge.db`; the gateway refuses to start while a former
   `send.db`/`received.db` is still in the data folder: move it out.
7. ~~`FOD2FMSInterface.svc` WSDL missing; DSS WSDL derived from FOD's.~~ Resolved 23 Nov: the gateway serves no WSDL.
8. ~~`?wsdl` shows `http://` behind TLS termination.~~ Resolved 23 Nov: the gateway serves no WSDL.
9. No deployment scripts (`deploy/`, `scripts/` removed): IIS, folder ACLs and kiosk set-up are manual (guide §12.4).
10. DMZ → Corp services are in `routes.json` (11 services, from workspace-master-v2's DMZ outbound interfaces), but
    their contracts are mostly **derived** from client proxies, their paths need confirming, and Corp receiver hosts are empty.
11. The read-only UI (25 Nov) has one configured login (`Ui:Username`/`Ui:Password`, default admin/admin: the start-up
    log warns) and shows payloads in clear: before go-live set a real password per site, serve it over https and
    restrict `/qrbridge-ui` by IP in IIS. Cookie keys use ASP.NET's default key ring (lost on recycle unless the app
    pool loads its user profile: users just sign in again). Not tried on a real IIS. A delivered Inbox row's body is
    cleared (D77), so the UI shows its URL and answer but not its request (the sending side's Outbox has it).
12. QrDiode: the status of every item is `sourcecode/qrdiode/docs/qrdiode-pending-work.md`. 26 Nov: bugs and hardening,
    **QrDiode protocol v2** (a MAC on every data frame, no plaintext hash in the manifest, a counter run id; v1 apps
    are refused — update both sides together) and `"Production"`. 27 Nov: the **gateway connection** ("Mode": "Bridge",
    issues 4–6 above), kiosk start-up ("AutoStart"), the Esc guard. Still open (its §1, P-1 … P-11): the
    physical screen/camera test, the single-file publish with the gateway connection, the round-trip time, a real
    kiosk, the trust-folder ACLs, a time source, the key rotation runbook, and S-03/S-04 (deferred to security sign-off).

## Next steps

Follow `docs/gateway-to-qrdiode/integration-plan.md` §5. Done: receiver fix (26 Nov); data model + bundles +
migrations, Sender reads the Outbox, Receiver writes the Inbox, kiosk start-up (27 Nov). Next: the first end-to-end run
on real screens and cameras (one PC, or two), then islanding operations (switch-in / switch-back, operator actions).
After each step run `dotnet test All.slnx` and update `docs/handoff.md` and the known-issues list above.

## Reusable prompts and agents

Prompts in `.github/prompts/` (type `/` in Copilot Chat): `verify-solution`, `fix-receive-engine-bug`,
`add-bundles-and-outbox-status`, `connect-sender-to-outbox`, `connect-receiver-to-inbox`, `add-bridged-service`,
`extend-read-only-ui`, `update-handoff`. Custom agents in `.github/agents/`: `bridge-architect`, `wpf-mentor`.
Path-specific rules in `.github/instructions/` apply automatically to matching files.

## Open questions — ask Rowshan, don't decide alone

Queries in islanding (currently "Unavailable", 1599) · SOAP Gateway response codes 1597/1598/1599 OK with the Rapid Restore team? ·
do XA/21, BFC, Registered Tags cross the gap? · load balancer details · MAXIMO/OSS/NRI payloads · dual-site behaviour ·
security sign-off · per-order ordering (`docs/handoff.md` §10; bundling was decided 27 Nov, decision 52).
