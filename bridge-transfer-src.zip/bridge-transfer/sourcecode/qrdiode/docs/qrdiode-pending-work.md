# QrDiode — status and pending work

State on **27 Nov 2026**. Last full run: `dotnet test All.slnx` → **564 gateway + 116 QrDiode passed**.

- **Code:** all done, including the gateway connection (`"QrDiode:Mode": "Bridge"`).
- **Not done:** nothing has run on real screens and cameras yet (P-1 to P-4). Deployment and security work remain
  (P-5 to P-11).

How to use this page: work through §1 from the top. When an item is finished, move it to §2 with the date and the
evidence. Then run `dotnet test All.slnx` and update [handoff.md](../../../docs/handoff.md) §5 and known issue 12 in
[copilot-instructions.md](../../../.github/copilot-instructions.md).

---

## 1. Pending

| ID | Item | Kind | Needs first |
|---|---|---|---|
| P-1 | Standalone run on a screen and a camera | Test, hardware | A PC with a webcam |
| P-2 | Bridge run, one direction (Corp → DMZ) | Test, hardware | P-1 |
| P-3 | Single-file publish with the gateway connection | Test, no hardware | — |
| P-4 | Round-trip time, both directions | Test, hardware | P-2; two Sender/Receiver pairs |
| P-5 | Kiosk set-up and a 48–72 h soak | Deployment | P-2, P-3; the kiosk PCs |
| P-6 | Trust folder protected from changes | Security, set-up | Done during P-5 |
| P-7 | Time source on both sides while islanded | Security, operations | An operations decision |
| P-8 | Key rotation and revocation runbook | Security, procedure | — |
| P-9 | S-04: QR decoder in its own process | Security, design · **deferred** (decision 51) | Security sign-off |
| P-10 | S-03: forward secrecy | Security, design · **deferred** (decision 51) | Security sign-off |
| P-11 | Security sign-off | Approval | P-6 … P-10 (handoff §10 Q7) |

### P-1 · Standalone run

Set-up: one PC, a webcam pointed at the Sender's stage, **⚡ Demo setup** in both apps
([user guide Part A](user-guide.md#part-a--5-minute-demo-one-machine-full-security)).

Done when:
- [ ] A transfer completes; the receipt hash is the same on both screens.
- [ ] Cover the camera halfway through a session and uncover it during the next one → the next one arrives; the first
      shows **⚠ incomplete · must be re-sent**.
- [ ] Another QR code in view during a session → the session still completes.
- [ ] Restart the Receiver while the Sender re-airs the last session → **◎ duplicate**, not a red row.
- [ ] `"Production": true` in both `appsettings.json` (dev build: `bin\Debug\net10.0-windows\`) → no Demo button,
      demo keys refused. Set it back afterwards.

### P-2 · Bridge run, one direction

Set-up ([user guide Part C](user-guide.md#part-c--connected-to-the-soap-gateway-bridge-mode)):
- Start both gateways: launch profiles `Gateway (Corp)` and `Gateway (Dmz)`, data in `C:\QrBridgeDev`.
- Sender `appsettings.json`: `"Mode": "Bridge"`, `"Bridge": { "Side": "Corp", "DataFolder": "C:\\QrBridgeDev\\Corp\\Data" }`.
- Receiver `appsettings.json`: `"Mode": "Bridge"`, `"Bridge": { "Side": "Dmz", "DataFolder": "C:\\QrBridgeDev\\Dmz\\Data" }`.
- Start a listener on `http://localhost:5099` (the DMZ profile's target) that answers `RETURN_CODE 0`
  ([connect-receiver-to-inbox prompt](../../../.github/prompts/connect-receiver-to-inbox.prompt.md), "Check"). Without
  it, rows end `NotDelivered` instead of `Done`.

Done when:
- [ ] One SOAP call to the Corp gateway (a sample from `QrBridge.Tests/Samples`) → a `gateway bundle` on the stage
      within about 1 s. Its Corp Outbox row becomes `Aired`, and the message reaches `Done` in the DMZ Inbox
      (`/qrbridge-ui`).
- [ ] Ten quick calls → fewer bundles than calls.
- [ ] Close the Sender while a bundle is on air, then restart it → the bundle airs again, and the DMZ Inbox has each
      message once.

This is the first run of the WPF code that has no automated test: `OutboxSource` (Sender) and `HandleBundleAsync`
(Receiver). Corp rows reach `Received` only with the reverse lane (P-4).

### P-3 · Single-file publish

Run the Sender and Receiver commands of
[guide §12.3](../../../docs/gateway-to-qrdiode/technical-guide.md#123-publish). This has not been tried since the apps
started using `QrBridge.Shared` (EF Core and a native SQLite library inside a single-file exe).

Done when:
- [ ] `publish\sender\` and `publish\receiver\` each hold the exe and its `appsettings.json`.
- [ ] Each published exe starts in Bridge mode and opens `qrbridge.db`: the Sender's bridge line shows the database
      path, and the Receiver shows no "cannot be opened" error.
- [ ] Afterwards, build the WPF projects twice: the first build after a publish can fail once.

### P-4 · Round-trip time, both directions

Set-up: two Sender/Receiver pairs, Corp → DMZ and DMZ → Corp. This is a gate in the
[V6 tracker §3.2](../../gateway/docs/reviews/gateway-review-v6-fix-tracker.md#32-before-any-real-islanding-use-gates-not-code).

Done when:
- [ ] A RoundTrip call (permit or order) gets the real answer back, and Corp Outbox rows reach `Received`.
- [ ] Call → answer time is measured idle and with about 50 calls queued, and recorded in handoff §5. Compare it with
      the caller holds (90–270 s); one bundle is about 7.5–19 s on air per direction.

### P-5 · Kiosk set-up and soak

Steps: [guide §12.4](../../../docs/gateway-to-qrdiode/technical-guide.md#124-deploy-per-side) item 11. On each side:
- a kiosk Windows user with auto-logon;
- scheduled tasks that start the Sender and the Receiver at logon;
- the kiosk user has Modify on `Bridge:DataFolder`;
- `appsettings.json`: `"Production": true`, `"Mode": "Bridge"`, and `"AutoStart": true` with the endpoint, receiver and
  camera names;
- the key ceremony ([user guide Part B](user-guide.md#part-b--production-setup-two-machines)).

Done when:
- [ ] After a reboot, both apps start and carry calls without anyone touching them.
- [ ] A 48–72 h soak leaves no stuck rows (integration plan §5 step 7).

### P-6 … P-11 · Security

| ID | Risk | Done when |
|---|---|---|
| P-6 | Anyone who can write a file into `%LocalAppData%\QrDiode\trust\` becomes a trusted sender | The kiosk user can read the folder but not change it outside the key ceremony (ACLs), and the procedure is in the user guide Part B. Optional, for the sign-off: trust only keys signed by a company certificate (not built) |
| P-7 | The Receiver refuses manifests more than 15 min off its own clock (Strict mode, the default). Islanded machines lose network time, so clocks drift | Each side has a time source that works while islanded (GPS clock or plant NTP), written in guide §12.4 |
| P-8 | No written steps for a planned key change, or for removing a stolen kiosk's key at once. The tools exist: `KeyCeremony list`, `delete … --yes`, `verify-audit` | A runbook in the user guide Part B, agreed with security |
| P-9 | ZXing (native code) decodes camera images inside the Receiver, which can also use the keys (CNG/TPM, not exportable) and writes the Inbox. An exploit of a decoder bug could inject messages; a fake QR code alone cannot (frame MAC and signature) | Decided at the sign-off: either a decode-only child process with no keys and no database access (`Capture/QrDecodePipeline.cs`; conflicts with decision 4, two programs per machine), or the risk accepted |
| P-10 | Static-static ECDH (`Crypto/Envelope.cs`): a recording of the screen plus a private key stolen later decrypts old sessions. TPM keys make the theft hard | Decided at the sign-off: either a design (for example one-time keys sent back on the reverse lane), or the risk accepted |
| P-11 | — | Security approves both lanes, Replies and Receipts carrying data, and the gateway database stored in plain text (protected by BitLocker and ACLs) |

### Optional (code, no hardware)

| ID | Item | Where |
|---|---|---|
| O-1 | Release claimed bundles when the Sender closes. Today their rows stay `Sending` until the Sender starts again (`ResetSendingAsync`), and the gateway never re-airs `Sending` rows | `Transmit/OutboxSource.cs` `DisposeAsync` |
| O-2 | Show the Outbox backlog in the Sender. Today it shows session counts only; the gateway's `/qrbridge-ui` shows the backlog | `OutboxRepository.GetCountsAsync` |
| O-3 | F-08: throughput (protocol Phase 2), only if P-4 shows it is needed | [protocol notes](protocol-development-notes.md) |
| O-4 | Bring older QrDiode files in line with the file-layout rules. **Ask Rowshan first** | — |

---

## 2. Done

Evidence: **T** = an automated test covers it · **R** = read in the code, not run. Decisions are numbered as in
[handoff §3](../../../docs/handoff.md).

| ID | Date | What | Where | Evidence |
|---|---|---|---|---|
| B-01 | 26 Nov | A partial session no longer blocks the Receiver: a newer verified manifest abandons it | Core `Pipeline/ReceiveEngine.cs` | T `SessionAbandonTests` |
| B-02 | 26 Nov | A rejection no longer drops the next session (no late `Reset`) | Receiver `MainWindow.xaml.cs` `HandleRejection` | T `SessionAbandonTests` |
| B-03 | 26 Nov | A forged frame can't destroy a session: 16-byte MAC on every data frame (protocol v2, decision 49) | Core `Framing/FrameMac.cs` | T `FrameAuthenticationTests` |
| B-04 | 26–27 Nov | Replay state is committed only after the store (file or Inbox) | `ReceiveEngine.CommitReplay`, Receiver | T `ReplayCommitTests` |
| B-05 | 26 Nov | The Sender drops only simulator items, never Outbox bundles | Sender `Transmit/TransmitEngine.cs` | R |
| B-06 | 27 Nov | A re-aired bundle is stored again and owed a Receipt (the bundle branch runs before the "same content" check) | Receiver `HandleCompletion` | T `BundleRepositoryTests`, `BundleLightTests`; WPF part: P-2 |
| B-07 | 26 Nov | Camera-thread exceptions are caught, audited, and shown at most every 10 s | Receiver | R |
| B-08 | 26 Nov | The stage ends a session as `Failed` when its frame producer stops | Sender `Rendering/CarouselPump.cs` | R |
| B-09 | 26 Nov | Stop/Start shows ◎ duplicate, not a false red replay row | Receiver `MainWindow.xaml.cs` | R |
| H-01 | 26 Nov | No plaintext hash in the manifest | Core `Manifest/TransferManifest.cs` | T |
| H-02 | 26 Nov | Limits: payload ≤ 64 MB, K ≤ 65,536, symbol 256–4,060 B | `TransferManifest.cs` | T `LimitsTests` |
| H-03 | 26 Nov | Decoder memory capped; used symbols release their bytes | Core `Fountain/LtDecoder.cs` | T `LimitsTests` |
| H-04 | 26 Nov | Settled sessions capped at 4,096 | `ReceiveEngine.cs` | T `LimitsTests` |
| H-05 | 26–27 Nov | `"AllowOpaqueFiles"`; Bridge mode accepts only `.qbb` (`AllowedFileSuffixes`) | `ReceiveEngine.cs` | T `LimitsTests` |
| H-06 | 26 Nov | Low-S signatures only, both sides | `TransferManifest.cs` | T `ManifestAndAuditTests` |
| H-07 | 26 Nov | Counter run id: a lost counter file starts a new run at 1 | Core `Crypto/CounterStore.cs`, `Pipeline/ReplayGuard.cs` | T `ReplayCommitTests` |
| H-08 | 26 Nov | `packages.lock.json` in all QrDiode projects | — | build |
| S-01 | 26 Nov | Frames authenticated (B-01 … B-03) | — | T |
| S-02 | 26 Nov | `"Production": true`: no demo, TPM keys only, demo bundles refused (decision 50). The rest is P-6 and P-8 | Core `Crypto/KeyPolicy.cs` | T `SettingsAndTrustTests` |
| S-05 | 26 Nov | Audit log: fast start, 32 MB rollover, `KeyCeremony verify-audit` | Core `Audit/AuditLog.cs` | T `ManifestAndAuditTests` |
| S-06 | 27 Nov | Bridge mode keeps no payload in the Receiver (no file, snippet or preview) | Receiver `HandleBundleAsync` | R |
| F-01 | 27 Nov | Bundles of up to 50 messages / 128 KB in strict order, a bigger message alone (decision 52). `BundleId` and `QrSessionId` columns. EF migrations `Initial` + `Bundles`; older databases adopted with their rows (decision 54) | Shared `Bundles/`, `Data/Migrations/`, `Data/Initializers/SchemaAdoption.cs` | T `BundleCodecTests`, `BundleRepositoryTests`, `MigrationTests` |
| F-02 | 27 Nov | The Sender airs the Outbox (decision 53) | Sender `Transmit/OutboxSource.cs`; Shared `Bundles/OutboxBundler.cs` | T `BundleLightTests`; WPF part: P-2 |
| F-03 | 27 Nov | The Receiver writes the Inbox in one transaction, then rings the doorbell (decision 53) | Receiver `HandleBundleAsync`; Shared `Bundles/InboxBundleWriter.cs` | T `QrAppBridgeTests`, `BundleLightTests`; WPF part: P-2 |
| F-04 | 27 Nov | One SQLite library, through `QrBridge.Shared` | Receiver `.csproj` | build |
| F-05 | 27 Nov | Kiosk code: `"AutoStart"`, the stage reopens where it was, Esc asks first | `SenderOptions.cs`, `ReceiverOptions.cs`, `Rendering/StagePlacement.cs`, `StageWindow.xaml.cs` | R; on a kiosk: P-5 |
| F-06 | 26–27 Nov | Operator tools: `verify-audit`, `delete … --yes`, journal archive steps | KeyCeremony `Program.cs`; [user guide](user-guide.md#archiving-the-receivers-journal) | R |

Tests T-01 … T-08 of the earlier list are the test classes named above.

---

## 3. Rules that must stay true

- **Protocol v2 on both sides.** A wire-format change bumps `FrameFormat.ProtocolVersion`; always deploy the Sender and
  the Receiver together.
- Receive order in `ReceiveEngine`: CRC → manifest signature (low-S) → addressed to us → anti-replay → frame MAC →
  LT decode → ciphertext hash → AES-GCM → exact size → content gate.
- The host stores first, then calls `engine.CommitReplay()`. A failed store calls `engine.Reset(settle: false)`.
  Never `Reset()` after a rejection.
- **Bridge mode:**
  - the bundle branch stays first in `HandleCompletion`;
  - the Receiver keeps no gateway payload;
  - Outbox items are never droppable;
  - every Sender item outcome goes through `TransmitEngine.ItemFinished`;
  - database work runs off the UI thread.
- **Schema changes are EF migrations**, never a deleted database:
  `dotnet tool run dotnet-ef migrations add <Name> --project sourcecode\gateway\src\QrBridge.Shared --startup-project sourcecode\gateway\src\QrBridge.Shared`.
  `MigrationTests` fails when a migration is missing.
- Open keys and trust stores only through `KeyPolicy` (it applies `"Production"`).
- `QrDiode.Core` stays free of EF, SQLite, SOAP and WPF. Gateway knowledge lives in `QrBridge.Shared`.

The same rules apply automatically through
[qrdiode-wpf.instructions.md](../../../.github/instructions/qrdiode-wpf.instructions.md) and
[bridge-gateway.instructions.md](../../../.github/instructions/bridge-gateway.instructions.md).

---

## 4. New machine

1. **`bridge-transfer` is not in git.** Copy the whole folder (leave out `bin\` and `obj\`), or commit it first.
2. Use a short path, e.g. `C:\src\QrDiode_V2`. From a deep path Windows refuses to load the native `ZXing.dll`.
3. Install the .NET 10 SDK, then run `dotnet tool restore` (dotnet-ef 10.0.15; needed only to add migrations).
4. `dotnet test All.slnx` → 564 + 116 passed. A first WPF build can fail once: build again.
5. These don't come with the code, by design:
   - **private keys** (CNG/TPM, per Windows user): run **⚡ Demo setup** (dev) or the key ceremony (kiosk);
   - trust files, the send counter, the journal and the audit logs (`%LocalAppData%\QrDiode\`): they start fresh.
6. `qrbridge.db` belongs to the gateway. A file from before 27 Nov is adopted with its rows on first start.

---

## 5. Code map

| What | Where |
|---|---|
| Protocol, crypto, receive pipeline | `QrDiode.Core/`: `Framing/` (`FrameMac`), `Manifest/`, `Fountain/LtDecoder.cs`, `Crypto/` (`Envelope`, `KeyPolicy`, `CounterStore`, `TrustStore`), `Pipeline/` (`ReceiveEngine`, `ReplayGuard`, `SendSession`) |
| QrDiode settings | Core `Configurations/`: `Options/QrDiodeOptions.cs`, `Helpers/Utility.cs` (`AppSettings`), `Enums/Enums.cs` (`QrDiodeMode`) |
| Sender | `Transmit/TransmitEngine.cs` (queue, `ItemFinished`), `Transmit/OutboxSource.cs` (Bridge mode), `StageWindow.xaml.cs`, `Rendering/StagePlacement.cs`, `Configurations/Options/SenderOptions.cs` |
| Receiver | `MainWindow.xaml.cs` (`HandleCompletion` → `HandleBundleAsync` or file store), `Capture/QrDecodePipeline.cs`, `Storage/SqliteJournal.cs`, `Configurations/Options/ReceiverOptions.cs` |
| Gateway code used by both apps | `sourcecode/gateway/src/QrBridge.Shared/`: `Bundles/` (`BundleCodec`, `OutboxBundler`, `InboxBundleWriter`, `QrAppBridge`), `Data/Repositories/` (`OutboxRepository.ClaimBundleAsync` …, `InboxRepository.AddMessagesAsync`), `Data/Migrations/`, `Data/Initializers/SchemaAdoption.cs` |
| Settings files | `appsettings.json` next to each exe. Sections: `QrDiode` (`Production`, `Mode`, `AllowOpaqueFiles`); `Bridge` (`Side`, `DataFolder`: the same as the gateway's on that machine); `Sender` / `Receiver` (`AutoStart`, …) |
| Tests | `sourcecode/qrdiode/tests/QrDiode.Core.Tests/`; `sourcecode/gateway/tests/QrBridge.Tests/` (`Bundle*Tests`, `MigrationTests`, `QrAppBridgeTests`, `Gateway/BundleLightTests`) |
| More | [User guide](user-guide.md) (A demo, B production, C Bridge mode) · handoff decisions 49–54 · [integration plan §2](../../../docs/gateway-to-qrdiode/integration-plan.md#2-connecting-qrdiode-to-the-shared-message-database) |
