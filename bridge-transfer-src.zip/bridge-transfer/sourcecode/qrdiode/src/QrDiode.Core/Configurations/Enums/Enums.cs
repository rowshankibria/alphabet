namespace QrDiode.Core;

/// <summary>What the QrDiode apps carry (setting "QrDiode:Mode").</summary>
public enum QrDiodeMode
{
    /// <summary>
    /// The apps on their own: the Sender airs simulator payloads or a file an operator picks, the Receiver stores what
    /// arrives in its local payload store. Demos and the bench.
    /// </summary>
    Standalone,

    /// <summary>
    /// Connected to the SOAP Gateway on the same machine through qrbridge.db (Integration-Plan §2.4–2.5): the Sender airs
    /// the gateway's Outbox as bundles, the Receiver stores arriving bundles in the gateway's Inbox and accepts nothing else.
    /// </summary>
    Bridge,
}
