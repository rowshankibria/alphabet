namespace QrDiode.Core;

/// <summary>
/// The "QrDiode" section of the <c>appsettings.json</c> next to each exe (Sender, Receiver, KeyCeremony): deployment
/// rules, set once per machine, not operator preferences.
/// <code>
/// { "QrDiode": { "Production": true, "Mode": "Bridge" } }
/// </code>
/// </summary>
public sealed class QrDiodeOptions
{
    public const string SectionName = "QrDiode";
    public const string FileName = AppSettings.FileName;

    /// <summary>
    /// True on the real kiosks: the "⚡ Demo setup" button is hidden, the demo keys and demo trust
    /// bundles (demo-ot, demo-it) are refused, and the app refuses keys that are not in the TPM.
    /// False (the default) on a developer machine: everything works as before.
    /// </summary>
    public bool Production { get; set; }

    /// <summary>
    /// Standalone (default): simulator payloads and files. Bridge: the SOAP Gateway's Outbox and Inbox on this machine
    /// (settings section "Bridge", the same as the gateway's). Both apps on one kiosk use the same mode.
    /// </summary>
    public QrDiodeMode Mode { get; set; } = QrDiodeMode.Standalone;

    /// <summary>
    /// Receiver, Standalone mode: accept payloads of kind File (bytes the content gate cannot check). In Bridge mode the
    /// Receiver accepts only gateway bundles, whatever this says.
    /// </summary>
    public bool AllowOpaqueFiles { get; set; } = true;

    /// <summary>
    /// Reads the section from <c>appsettings.json</c> in <paramref name="directory"/> (default: the exe's folder). No
    /// file, or no section: the defaults. A file that cannot be read, or a section with unknown or wrongly typed
    /// settings, throws — the caller must refuse to run rather than guess.
    /// </summary>
    /// <exception cref="InvalidDataException">The file or the section cannot be read.</exception>
    public static QrDiodeOptions Load(string? directory = null) => AppSettings.ReadSection<QrDiodeOptions>(SectionName, directory);
}
