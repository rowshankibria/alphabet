using System.Text.Json;
using System.Text.Json.Serialization;

namespace QrDiode.Core;

/// <summary>
/// Reads one section of the <c>appsettings.json</c> next to an exe into a settings class. Shared by the Sender, the
/// Receiver and the KeyCeremony tool, for their own sections ("QrDiode", "Sender", "Receiver") and for the gateway's
/// "Bridge" section the QR apps share with the SOAP Gateway on the same machine.
/// </summary>
public static class AppSettings
{
    public const string FileName = "appsettings.json";

    private static readonly JsonSerializerOptions SectionJson = new()
    {
        PropertyNameCaseInsensitive = true,
        // Hand-edited on each kiosk: comments and a trailing comma are not mistakes worth refusing.
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
        // A typo ("Prodution": true) must not silently leave a kiosk on a default.
        UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow,
        Converters = { new JsonStringEnumConverter() },
    };

    /// <summary>
    /// The section <paramref name="sectionName"/> of <c>appsettings.json</c> in <paramref name="directory"/> (default:
    /// the exe's folder). No file, or no such section: a new <typeparamref name="T"/> (its defaults). A file that cannot
    /// be read, or a section with unknown or wrongly typed settings, throws — the caller refuses to guess.
    /// </summary>
    /// <exception cref="InvalidDataException">The file or the section cannot be read.</exception>
    public static T ReadSection<T>(string sectionName, string? directory = null) where T : new()
    {
        string path = Path.Combine(directory ?? AppContext.BaseDirectory, FileName);
        if (!File.Exists(path)) return new T();

        try
        {
            using var document = JsonDocument.Parse(File.ReadAllText(path), new JsonDocumentOptions
            {
                CommentHandling = JsonCommentHandling.Skip,
                AllowTrailingCommas = true,
            });
            foreach (var section in document.RootElement.EnumerateObject())
            {
                if (section.Name.Equals(sectionName, StringComparison.OrdinalIgnoreCase))
                    return section.Value.Deserialize<T>(SectionJson) ?? new T();
            }
            return new T();
        }
        catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException or InvalidOperationException or NotSupportedException)
        {
            throw new InvalidDataException($"{path}: the \"{sectionName}\" settings cannot be read ({ex.Message}).", ex);
        }
    }
}
