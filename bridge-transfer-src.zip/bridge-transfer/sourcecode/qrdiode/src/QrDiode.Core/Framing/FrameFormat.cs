namespace QrDiode.Core.Framing;

/// <summary>
/// Wire format constants for QrDiode protocol v2. One QR code carries exactly one frame.
/// All integers are little-endian. Every frame ends with a CRC-32 over all preceding bytes.
/// v2 (26 Nov 2026) added a per-frame MAC to data frames: v1 frames are refused (BadVersion), so
/// Sender and Receiver must be updated together.
/// </summary>
public static class FrameFormat
{
    public const byte Magic0 = 0x4F; // 'O'
    public const byte Magic1 = 0x44; // 'D'
    public const byte ProtocolVersion = 0x02;

    public const byte TypeManifest = 0x01;
    public const byte TypeDataSymbol = 0x02;

    /// <summary>magic(2) + version(1) + type(1) + sessionTag(8)</summary>
    public const int HeaderSize = 12;
    public const int SessionTagOffset = 4;
    public const int SessionTagSize = 8;
    public const int CrcSize = 4;

    /// <summary>
    /// Truncated HMAC-SHA256 over header ‖ symbolId ‖ payload, under the session's frame key. The CRC
    /// only catches misreads; the MAC is what stops a QR code someone holds up to the camera from
    /// reaching the decoder.
    /// </summary>
    public const int MacSize = 16;

    /// <summary>Data frame: header + symbolId(4) + payload + mac(16) + crc.</summary>
    public const int DataOverhead = HeaderSize + 4 + MacSize + CrcSize;

    /// <summary>Manifest frame: header + bodyLen(2) + body + signature(64) + crc. The signature authenticates it.</summary>
    public const int SignatureSize = 64;
    public const int ManifestOverhead = HeaderSize + 2 + SignatureSize + CrcSize;

    /// <summary>Hard upper bound on any frame we will parse (V40 QR byte capacity is 2953).</summary>
    public const int MaxFrameSize = 4096;
    public const int MinFrameSize = HeaderSize + CrcSize + 1;

    /// <summary>The largest symbol a data frame can carry.</summary>
    public const int MaxSymbolSize = MaxFrameSize - DataOverhead;
}

public enum FrameType : byte
{
    Manifest = FrameFormat.TypeManifest,
    DataSymbol = FrameFormat.TypeDataSymbol,
}
