using System.Buffers.Binary;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using QrDiode.Core.Crypto;
using QrDiode.Core.Framing;

namespace QrDiode.Core.Manifest;

public enum ContentKind : byte
{
    File = 0,
    Xml = 1,
    Json = 2,
}

public enum CompressionAlg : byte
{
    None = 0,
    Brotli = 1,
}

/// <summary>
/// The transfer manifest: everything a receiver needs to reconstruct, decrypt and verify
/// one transfer. Serialized to a fixed binary layout and signed with the sender's ECDSA key.
///
/// v2 layout (protocol 0x02): the plaintext hash is no longer carried — the manifest is signed but
/// shown in clear on the screen, and a hash of a short, predictable message lets an observer confirm
/// a guess. The signed ciphertext hash and the GCM tag already prove the plaintext; the receiver
/// computes its hash itself. v2 also carries the sender's counter run id (see <see cref="CounterRunId"/>).
/// </summary>
public sealed class TransferManifest
{
    public const int MaxFilenameBytes = 255;

    /// <summary>The design envelope: payloads up to 64 MB. Anything larger is refused before it costs memory.</summary>
    public const long MaxPayloadBytes = 64L * 1024 * 1024;

    /// <summary>
    /// Smallest symbol, unless the whole ciphertext fits in one (K = 1). Stops a manifest from asking
    /// the decoder for millions of tiny symbols (and the arrays that go with them).
    /// </summary>
    public const int MinSymbolSize = 256;

    /// <summary>Most source symbols per session: 64 MB at the default 1,350-byte symbol is K ≈ 49,700.</summary>
    public const int MaxSourceSymbols = 65_536;

    private const int FixedSize = 183; // bytes before the variable-length filename

    // P-256 group order n. A signature (r, s) and (r, n − s) both verify, so the sender always signs
    // with s ≤ n/2 and the receiver refuses the other form: one manifest has exactly one valid signature.
    private static readonly BigInteger CurveOrder = new(
        Convert.FromHexString("FFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551"),
        isUnsigned: true, isBigEndian: true);
    private static readonly BigInteger HalfOrder = CurveOrder >> 1;

    public required Guid SessionId { get; init; }
    public required long TimestampUnixMs { get; init; }
    public required ulong Counter { get; init; }

    /// <summary>
    /// Identifies the sender's counter file. A new run starts when that file is created (first use,
    /// or after it was lost or unreadable), so the counter can restart at 1 without the receiver
    /// refusing everything as stale. Example: run 3f2a… counted to 812, the kiosk profile was rebuilt,
    /// run 9c41… starts at 1. The receiver keeps one watermark per sender key and run.
    /// </summary>
    public required Guid CounterRunId { get; init; }

    public required byte[] SenderSigningKeyId { get; init; }      // 8
    public required byte[] ReceiverAgreementKeyId { get; init; }  // 8
    public required byte[] Salt { get; init; }                    // 32
    public required byte[] Nonce { get; init; }                   // 12
    public required ushort SymbolSize { get; init; }
    public required uint SourceSymbolCount { get; init; }         // K
    public required ulong LtSeed { get; init; }
    public required ushort RedundancyHint { get; init; }
    public required long OriginalSize { get; init; }
    public required long CompressedSize { get; init; }
    public required long CiphertextSize { get; init; }
    public required CompressionAlg Compression { get; init; }
    public required byte[] CiphertextSha256 { get; init; }        // 32
    public required ContentKind ContentType { get; init; }
    public required string Filename { get; init; }

    public byte[] SessionTag => SessionId.ToByteArray().AsSpan(0, 8).ToArray();

    // Layout: session(16) · timestamp(8) · counter(8) · counterRun(16) · senderSigKeyId(8) · receiverKexKeyId(8)
    //         · salt(32) · nonce(12) · symbolSize(2) · K(4) · ltSeed(8) · redundancy(2) · originalSize(8)
    //         · compressedSize(8) · ciphertextSize(8) · compression(1) · ciphertextSha256(32) · contentType(1)
    //         · filenameLength(1) · filename(≤255)
    public byte[] Serialize()
    {
        byte[] nameBytes = Encoding.UTF8.GetBytes(Filename);
        if (nameBytes.Length > MaxFilenameBytes)
            throw new InvalidOperationException("Filename exceeds 255 UTF-8 bytes.");

        var body = new byte[FixedSize + nameBytes.Length];
        var span = body.AsSpan();

        SessionId.TryWriteBytes(span[..16]);
        BinaryPrimitives.WriteInt64LittleEndian(span[16..], TimestampUnixMs);
        BinaryPrimitives.WriteUInt64LittleEndian(span[24..], Counter);
        CounterRunId.TryWriteBytes(span.Slice(32, 16));
        Require(SenderSigningKeyId, KeyId.Size).CopyTo(span[48..]);
        Require(ReceiverAgreementKeyId, KeyId.Size).CopyTo(span[56..]);
        Require(Salt, Envelope.SaltSize).CopyTo(span[64..]);
        Require(Nonce, Envelope.NonceSize).CopyTo(span[96..]);
        BinaryPrimitives.WriteUInt16LittleEndian(span[108..], SymbolSize);
        BinaryPrimitives.WriteUInt32LittleEndian(span[110..], SourceSymbolCount);
        BinaryPrimitives.WriteUInt64LittleEndian(span[114..], LtSeed);
        BinaryPrimitives.WriteUInt16LittleEndian(span[122..], RedundancyHint);
        BinaryPrimitives.WriteInt64LittleEndian(span[124..], OriginalSize);
        BinaryPrimitives.WriteInt64LittleEndian(span[132..], CompressedSize);
        BinaryPrimitives.WriteInt64LittleEndian(span[140..], CiphertextSize);
        span[148] = (byte)Compression;
        Require(CiphertextSha256, 32).CopyTo(span[149..]);
        span[181] = (byte)ContentType;
        span[182] = (byte)nameBytes.Length;
        nameBytes.CopyTo(span[FixedSize..]);
        return body;
    }

    /// <summary>
    /// Parses a manifest body. Structural validation only — signature verification is the
    /// caller's job and MUST happen against these exact bytes before the result is trusted.
    /// </summary>
    public static bool TryParse(ReadOnlySpan<byte> body, out TransferManifest? manifest, out string error)
    {
        manifest = null;

        if (body.Length < FixedSize) { error = "Manifest body too short."; return false; }
        int nameLen = body[182];
        if (body.Length != FixedSize + nameLen) { error = "Manifest body length mismatch."; return false; }

        byte compression = body[148];
        if (compression > (byte)CompressionAlg.Brotli) { error = "Unknown compression algorithm."; return false; }
        byte contentType = body[181];
        if (contentType > (byte)ContentKind.Json) { error = "Unknown content type."; return false; }

        long originalSize = BinaryPrimitives.ReadInt64LittleEndian(body[124..]);
        long compressedSize = BinaryPrimitives.ReadInt64LittleEndian(body[132..]);
        long ciphertextSize = BinaryPrimitives.ReadInt64LittleEndian(body[140..]);
        ushort symbolSize = BinaryPrimitives.ReadUInt16LittleEndian(body[108..]);
        uint k = BinaryPrimitives.ReadUInt32LittleEndian(body[110..]);

        // Sanity bounds: fail closed on anything outside the design envelope, before the decoder
        // allocates anything sized from these numbers.
        if (originalSize <= 0 || originalSize > MaxPayloadBytes) { error = "Original size out of range."; return false; }
        if (compressedSize <= 0 || compressedSize > MaxPayloadBytes) { error = "Compressed size out of range."; return false; }
        if (ciphertextSize != compressedSize + Envelope.TagSize) { error = "Ciphertext size inconsistent."; return false; }
        if (compression == (byte)CompressionAlg.None && compressedSize != originalSize) { error = "Uncompressed size mismatch."; return false; }
        if (compression == (byte)CompressionAlg.Brotli && compressedSize > originalSize) { error = "Compressed larger than original."; return false; }
        if (symbolSize == 0 || symbolSize > FrameFormat.MaxSymbolSize) { error = "Symbol size out of range."; return false; }
        long expectedK = (ciphertextSize + symbolSize - 1) / symbolSize;
        if (k == 0 || k != expectedK) { error = "Source symbol count inconsistent."; return false; }
        if (k > MaxSourceSymbols) { error = "Too many source symbols."; return false; }
        if (k > 1 && symbolSize < MinSymbolSize) { error = "Symbol size too small."; return false; }

        string filename;
        try
        {
            filename = new UTF8Encoding(false, throwOnInvalidBytes: true).GetString(body.Slice(FixedSize, nameLen));
        }
        catch (ArgumentException) { error = "Invalid filename encoding."; return false; }

        manifest = new TransferManifest
        {
            SessionId = new Guid(body[..16]),
            TimestampUnixMs = BinaryPrimitives.ReadInt64LittleEndian(body[16..]),
            Counter = BinaryPrimitives.ReadUInt64LittleEndian(body[24..]),
            CounterRunId = new Guid(body.Slice(32, 16)),
            SenderSigningKeyId = body.Slice(48, KeyId.Size).ToArray(),
            ReceiverAgreementKeyId = body.Slice(56, KeyId.Size).ToArray(),
            Salt = body.Slice(64, Envelope.SaltSize).ToArray(),
            Nonce = body.Slice(96, Envelope.NonceSize).ToArray(),
            SymbolSize = symbolSize,
            SourceSymbolCount = k,
            LtSeed = BinaryPrimitives.ReadUInt64LittleEndian(body[114..]),
            RedundancyHint = BinaryPrimitives.ReadUInt16LittleEndian(body[122..]),
            OriginalSize = originalSize,
            CompressedSize = compressedSize,
            CiphertextSize = ciphertextSize,
            Compression = (CompressionAlg)compression,
            CiphertextSha256 = body.Slice(149, 32).ToArray(),
            ContentType = (ContentKind)contentType,
            Filename = filename,
        };
        error = "";
        return true;
    }

    /// <summary>Signs the body (IEEE P1363 r‖s, 64 bytes for P-256), always in the low-S form.</summary>
    public byte[] Sign(ECDsa signingKey, byte[] serializedBody)
    {
        byte[] signature = signingKey.SignData(serializedBody, HashAlgorithmName.SHA256);
        var s = new BigInteger(signature.AsSpan(32, 32), isUnsigned: true, isBigEndian: true);
        if (s > HalfOrder) WriteScalar(CurveOrder - s, signature.AsSpan(32, 32));
        return signature;
    }

    /// <summary>True only for a 64-byte low-S signature that verifies over exactly these bytes.</summary>
    public static bool VerifySignature(ECDsa signingPublicKey, ReadOnlySpan<byte> body, ReadOnlySpan<byte> signature)
    {
        if (signature.Length != FrameFormat.SignatureSize) return false;
        var s = new BigInteger(signature.Slice(32, 32), isUnsigned: true, isBigEndian: true);
        if (s > HalfOrder) return false;
        return signingPublicKey.VerifyData(body, signature, HashAlgorithmName.SHA256);
    }

    /// <summary>Receipt hash: SHA-256 over body ‖ signature. Shown on both screens for comparison.</summary>
    public static string ReceiptHash(ReadOnlySpan<byte> body, ReadOnlySpan<byte> signature)
    {
        var buf = new byte[body.Length + signature.Length];
        body.CopyTo(buf);
        signature.CopyTo(buf.AsSpan(body.Length));
        return Convert.ToHexString(SHA256.HashData(buf).AsSpan(0, 8));
    }

    private static void WriteScalar(BigInteger value, Span<byte> destination)
    {
        destination.Clear();
        byte[] bytes = value.ToByteArray(isUnsigned: true, isBigEndian: true);
        bytes.CopyTo(destination[(destination.Length - bytes.Length)..]);
    }

    private static byte[] Require(byte[] value, int length)
        => value.Length == length ? value : throw new InvalidOperationException($"Expected {length}-byte field, got {value.Length}.");
}
