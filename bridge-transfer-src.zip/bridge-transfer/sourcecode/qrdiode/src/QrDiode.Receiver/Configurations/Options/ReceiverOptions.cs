namespace QrDiode.Receiver;

/// <summary>
/// The "Receiver" section of the Receiver's <c>appsettings.json</c>: unattended start-up (kiosk, Integration-Plan §2.6).
/// The "QrDiode" section holds Production and Mode; "Bridge" the gateway's Side and DataFolder.
/// </summary>
public sealed class ReceiverOptions
{
    public const string SectionName = "Receiver";

    /// <summary>Kiosk: open the keys, pick the camera and start receiving without clicks.</summary>
    public bool AutoStart { get; set; }

    /// <summary>This machine's endpoint name from the key ceremony (e.g. "it-recv-1"); empty = the name in the window.</summary>
    public string Endpoint { get; set; } = "";

    /// <summary>Part of the camera's name to pick (e.g. "Logitech"); empty = the first camera.</summary>
    public string Camera { get; set; } = "";

    /// <summary>Strict mode at start-up: a 15-minute replay window instead of 48 h. Needs both clocks in step.</summary>
    public bool StrictMode { get; set; } = true;
}
