using System.Windows.Threading;
using QrBridge.Shared;
using QrBridge.Shared.Bundles;
using QrDiode.Core.Audit;
using QrDiode.Core.Simulation;

namespace QrDiode.Sender.Transmit;

/// <summary>
/// The Bridge-mode source (Integration-Plan §2.4): it airs the SOAP Gateway's Outbox on this machine. A background loop
/// waits on the gateway's Outbox doorbell (2 s poll as fallback) and, whenever the stage is open and nothing waits in
/// the <see cref="TransmitEngine"/> queue, claims the next bundle (<see cref="OutboxBundler"/>) and queues it — so at
/// most one bundle waits behind the one on air. When an item ends (<see cref="TransmitEngine.ItemFinished"/>) its rows
/// are marked: Sent → Aired in its QR session; Skipped → back to the queue at once; Failed → back after 30 s.
/// Everything else — order, priorities, re-airing unconfirmed rows, Receipts — is the gateway's job.
///
/// Only the UI thread touches the engine (like a component that reaches the DOM only through Angular's zone): the
/// loop goes through <see cref="Dispatcher.InvokeAsync(Action)"/>.
/// </summary>
public sealed class OutboxSource : IAsyncDisposable
{
    private static readonly TimeSpan FailedRetryDelay = TimeSpan.FromSeconds(30);
    private static readonly PayloadType BundleType = PayloadCatalogue.ManualFile with { Name = "gateway bundle", Code = "QBB" };

    private readonly QrAppBridge _bridge;
    private readonly TransmitEngine _engine;
    private readonly Dispatcher _dispatcher;
    private readonly SenderOptions _options;
    private readonly AuditLog _audit;
    private readonly CancellationTokenSource _stop = new();
    private readonly SemaphoreSlim _wake = new(0, int.MaxValue);
    private Task? _loop;

    private int _queued, _aired, _released;

    public OutboxSource(QrAppBridge bridge, TransmitEngine engine, Dispatcher dispatcher, SenderOptions options, AuditLog audit)
    {
        _bridge = bridge;
        _engine = engine;
        _dispatcher = dispatcher;
        _options = options;
        _audit = audit;
    }

    /// <summary>Raised on the UI thread with a one-line status for the dashboard.</summary>
    public event Action<string>? StatusChanged;

    public void Start()
    {
        _engine.ItemFinished += OnItemFinished;
        _loop = Task.Run(() => RunAsync(_stop.Token));
    }

    private async Task RunAsync(CancellationToken ct)
    {
        try
        {
            // Rows a crash left on screen (Sending) go back to Pending; the gateway's receipts decide what was seen.
            int reset = await _bridge.Outbox.ResetSendingAsync(ct);
            if (reset > 0)
                _audit.Append("bridge.reset_sending", new Dictionary<string, string> { ["rows"] = reset.ToString() });
            await ReportAsync("connected");

            var nextBeat = DateTime.MinValue;
            Task? wake = null; // one pending wait at a time, kept across passes
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    if (DateTime.UtcNow >= nextBeat)
                    {
                        await _bridge.Heartbeats.BeatAsync(Components.SenderLoop, Summary(), ct);
                        nextBeat = DateTime.UtcNow + QrAppBridge.HeartbeatInterval;
                    }

                    bool room = await _dispatcher.InvokeAsync(() =>
                        _engine.CanTransmit && _engine.State != StageState.Stopped && _engine.QueuedCount == 0);
                    if (room && await _bridge.Bundler.ClaimAsync(_options.BundleMaxMessages, _options.BundleMaxBytes, ct) is { } bundle)
                    {
                        await _dispatcher.InvokeAsync(() =>
                        {
                            var item = _engine.Enqueue(BundleType, bundle.FileName, bundle.Bytes); // never droppable
                            item.BundleId = bundle.BundleId;
                        });
                        Interlocked.Increment(ref _queued);
                        _audit.Append("bridge.bundle_queued", new Dictionary<string, string>
                        {
                            ["bundle"] = bundle.BundleId.ToString(),
                            ["messages"] = bundle.Count.ToString(),
                            ["sequences"] = $"{bundle.MinSequence}-{bundle.MaxSequence}",
                            ["size"] = bundle.Bytes.Length.ToString(),
                        });
                        await ReportAsync($"bundle {bundle.MinSequence}–{bundle.MaxSequence} · {bundle.Count} message(s) queued");
                        continue;
                    }

                    // The gateway rings after every Outbox insert; an item ending rings _wake. Either way, poll every 2 s.
                    var doorbell = _bridge.Signals.Outbox.WaitAsync(TimeSpan.FromSeconds(2), ct);
                    wake ??= _wake.WaitAsync(ct);
                    await Task.WhenAny(doorbell, wake);
                    if (wake.IsCompleted) wake = null;
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    return;
                }
                catch (Exception ex)
                {
                    // A busy or missing database must not stop the light for good: say so, wait, try again.
                    _audit.Append("bridge.sender_error", new Dictionary<string, string> { ["error"] = ex.GetType().Name, ["message"] = ex.Message });
                    await ReportAsync($"database error, retrying in 5 s: {ex.Message}");
                    await Task.Delay(TimeSpan.FromSeconds(5), ct);
                }
            }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
        }
    }

    /// <summary>UI thread. Writes the item's outcome back to its Outbox rows.</summary>
    private void OnItemFinished(QueueItem item)
    {
        if (item.BundleId is not { } bundleId) return;
        // Off the UI thread: SQLite's async calls run synchronously.
        var (state, session, error) = (item.State, item.SessionId, item.Error);
        _ = Task.Run(() => SettleAsync(item, bundleId, state, session, error));
        _wake.Release();
    }

    private async Task SettleAsync(QueueItem item, Guid bundleId, QueueState outcome, Guid sessionId, string? error)
    {
        for (int attempt = 1; ; attempt++)
        {
            try
            {
                if (outcome == QueueState.Sent)
                {
                    await _bridge.Bundler.MarkAiredAsync(bundleId, sessionId, CancellationToken.None);
                    Interlocked.Increment(ref _aired);
                }
                else
                {
                    var delay = outcome == QueueState.Failed ? FailedRetryDelay : TimeSpan.Zero;
                    await _bridge.Bundler.ReleaseAsync(bundleId, error ?? "Not aired.", delay, CancellationToken.None);
                    Interlocked.Increment(ref _released);
                }
                _audit.Append(outcome == QueueState.Sent ? "bridge.bundle_aired" : "bridge.bundle_released", new Dictionary<string, string>
                {
                    ["bundle"] = bundleId.ToString(),
                    ["session"] = sessionId.ToString(),
                    ["outcome"] = outcome.ToString(),
                    ["file"] = item.Filename,
                });
                await ReportAsync($"{item.Filename}: {(outcome == QueueState.Sent ? "aired" : "put back in the queue")}");
                return;
            }
            catch (Exception) when (attempt < 3)
            {
                await Task.Delay(TimeSpan.FromSeconds(attempt)); // a busy database: try again
            }
            catch (Exception ex)
            {
                // The rows stay Sending: the next start of the Sender puts them back (ResetSendingAsync).
                _audit.Append("bridge.settle_failed", new Dictionary<string, string> { ["bundle"] = bundleId.ToString(), ["message"] = ex.Message });
                await ReportAsync($"could not record {item.Filename} in the Outbox: {ex.Message}");
                return;
            }
        }
    }

    private string Summary() =>
        $"{_bridge.Options.Side} · {Volatile.Read(ref _queued)} bundles queued, {Volatile.Read(ref _aired)} aired, {Volatile.Read(ref _released)} put back";

    private async Task ReportAsync(string what)
    {
        string line = $"Bridge ({_bridge.Options.Side} side, {_bridge.Options.DatabasePath}) · {what} · {Summary()}";
        await _dispatcher.InvokeAsync(() => StatusChanged?.Invoke(line));
    }

    public async ValueTask DisposeAsync()
    {
        _engine.ItemFinished -= OnItemFinished;
        await _stop.CancelAsync();
        if (_loop is not null)
        {
            try { await _loop; } catch (OperationCanceledException) { }
        }
        _stop.Dispose();
        _wake.Dispose();
    }
}
