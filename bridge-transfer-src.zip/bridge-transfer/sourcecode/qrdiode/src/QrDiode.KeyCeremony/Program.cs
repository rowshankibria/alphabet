using QrDiode.Core;
using QrDiode.Core.Audit;
using QrDiode.Core.Crypto;

if (!OperatingSystem.IsWindows())
{
    Console.Error.WriteLine("QrDiode.KeyCeremony requires Windows (CNG key storage).");
    return 2;
}

QrDiodeOptions options;
try
{
    options = QrDiodeOptions.Load();
}
catch (InvalidDataException ex)
{
    Console.Error.WriteLine(ex.Message);
    return 2;
}

QrDiodePaths.EnsureCreated();

return args switch
{
    ["init", string name] => Init(name),
    ["export", string name, string outPath] => Export(name, outPath),
    ["import", string inPath] => Import(inPath),
    ["fingerprint", string path] => Fingerprint(path),
    ["list"] => List(),
    ["delete", string name] => DeleteRefused(name),
    ["delete", string name, "--yes"] => Delete(name),
    ["verify-audit"] => VerifyAudit(null),
    ["verify-audit", string path] => VerifyAudit(path),
    ["demo"] => Demo(),
    ["demo-clean"] => DemoClean(),
    _ => Usage(),
};

int Demo()
{
    try
    {
        KeyPolicy.EnsureDemoAllowed(options);
    }
    catch (InvalidOperationException ex)
    {
        Console.Error.WriteLine(ex.Message);
        return 1;
    }

    var ids = DemoProvisioner.Provision();
    Console.WriteLine("Demo environment ready — BOTH endpoints provisioned on this machine.");
    Console.WriteLine($"  {DemoProvisioner.OtEndpoint}  fingerprint {ids.OtFingerprint}");
    Console.WriteLine($"  {DemoProvisioner.ItEndpoint}  fingerprint {ids.ItFingerprint}");
    Console.WriteLine();
    Console.WriteLine("All security is fully active (real signatures, encryption, anti-replay).");
    Console.WriteLine($"Sender:   open keys as '{DemoProvisioner.OtEndpoint}', pick receiver '{DemoProvisioner.ItEndpoint}'.");
    Console.WriteLine($"Receiver: open keys as '{DemoProvisioner.ItEndpoint}', start the camera.");
    Console.WriteLine("Run 'demo-clean' before provisioning this machine for production.");
    return 0;
}

static int DemoClean()
{
    DemoProvisioner.Remove();
    Console.WriteLine("Demo keys and trust bundles removed.");
    return 0;
}

int Init(string name)
{
    bool existed = CngEndpointKeys.Exists(name);
    CngEndpointKeys keys;
    try
    {
        keys = KeyPolicy.OpenKeys(name, options);
    }
    catch (InvalidOperationException ex)
    {
        Console.Error.WriteLine(ex.Message);
        return 1;
    }

    using (keys)
    {
        Console.WriteLine(existed ? $"Endpoint '{name}' already exists:" : $"Endpoint '{name}' created:");
        Console.WriteLine($"  Key storage   : {(keys.IsTpmBacked ? "TPM (Platform Crypto Provider)" : "Software KSP (non-exportable)")}");
        Console.WriteLine($"  Signing key id: {KeyId.ToHex(keys.SigningKeyId)}");
        Console.WriteLine($"  Kex key id    : {KeyId.ToHex(keys.AgreementKeyId)}");
        Console.WriteLine();
        Console.WriteLine($"Next: qrdiode-keys export {name} <bundle.json> and carry it to the peer on removable media.");
    }
    return 0;
}

int Export(string name, string outPath)
{
    if (!CngEndpointKeys.Exists(name))
    {
        Console.Error.WriteLine($"Endpoint '{name}' does not exist. Run: init {name}");
        return 1;
    }

    CngEndpointKeys keys;
    try
    {
        keys = KeyPolicy.OpenKeys(name, options);
    }
    catch (InvalidOperationException ex)
    {
        Console.Error.WriteLine(ex.Message);
        return 1;
    }

    using (keys)
    {
        var bundle = PublicKeyBundle.FromKeys(name, keys);
        File.WriteAllText(outPath, bundle.ToJson());
        Console.WriteLine($"Public bundle written to {outPath}");
        Console.WriteLine($"Fingerprint: {bundle.Fingerprint()}");
        Console.WriteLine("Verify this fingerprint with the receiving side out-of-band (phone/voice) after import.");
    }
    return 0;
}

int Import(string inPath)
{
    PublicKeyBundle bundle;
    try
    {
        bundle = PublicKeyBundle.Parse(File.ReadAllText(inPath));
    }
    catch (Exception ex)
    {
        Console.Error.WriteLine($"Bundle rejected: {ex.Message}");
        return 1;
    }

    if (options.Production && KeyPolicy.IsDemoEndpoint(bundle.Name))
    {
        Console.Error.WriteLine($"Bundle rejected: '{bundle.Name}' is a demo bundle, and this machine is in production.");
        return 1;
    }

    string safeName = string.Concat(bundle.Name.Where(char.IsAsciiLetterOrDigit));
    string target = Path.Combine(QrDiodePaths.TrustDir, $"{safeName}.json");
    if (File.Exists(target))
    {
        Console.Error.WriteLine($"A trusted bundle named '{bundle.Name}' already exists at {target}.");
        Console.Error.WriteLine("Delete it first if you intend to rotate keys (this is a deliberate two-step).");
        return 1;
    }

    File.WriteAllText(target, bundle.ToJson());
    using var peer = bundle.ToPeerKeys();
    Console.WriteLine($"Imported '{bundle.Name}' into the trust store.");
    Console.WriteLine($"  Signing key id: {KeyId.ToHex(peer.SigningKeyId)}");
    Console.WriteLine($"  Kex key id    : {KeyId.ToHex(peer.AgreementKeyId)}");
    Console.WriteLine($"  FINGERPRINT   : {bundle.Fingerprint()}");
    Console.WriteLine();
    Console.WriteLine("CEREMONY STEP: read this fingerprint aloud to the exporting operator.");
    Console.WriteLine("Both sides must see the identical value. If they differ, DELETE this bundle immediately.");
    return 0;
}

static int Fingerprint(string path)
{
    try
    {
        var bundle = PublicKeyBundle.Parse(File.ReadAllText(path));
        Console.WriteLine($"{bundle.Name}: {bundle.Fingerprint()}");
        return 0;
    }
    catch (Exception ex)
    {
        Console.Error.WriteLine($"Cannot read bundle: {ex.Message}");
        return 1;
    }
}

int List()
{
    Console.WriteLine("Trusted peers:");
    using var store = KeyPolicy.OpenTrustStore(options);
    if (store.Peers.Count == 0) Console.WriteLine("  (none)");
    foreach (var peer in store.Peers)
        Console.WriteLine($"  {peer.Name}  sign={KeyId.ToHex(peer.SigningKeyId)}  kex={KeyId.ToHex(peer.AgreementKeyId)}");
    if (store.Problems.Count > 0)
    {
        Console.WriteLine("Skipped (NOT trusted):");
        foreach (var problem in store.Problems) Console.WriteLine($"  {problem}");
    }
    return 0;
}

static int DeleteRefused(string name)
{
    // Irreversible: the other side would have to repeat the whole key exchange.
    Console.Error.WriteLine($"This permanently deletes the private keys of endpoint '{name}' on this machine.");
    Console.Error.WriteLine("The other side's trust store then holds a key nobody has; you would have to repeat the key ceremony.");
    Console.Error.WriteLine($"To go ahead, run: delete {name} --yes");
    return 1;
}

static int Delete(string name)
{
    CngEndpointKeys.Delete(name);
    Console.WriteLine($"Local CNG keys for endpoint '{name}' deleted (trust-store bundles are not touched).");
    return 0;
}

static int VerifyAudit(string? path)
{
    string[] files = path is not null
        ? [path]
        : [Path.Combine(QrDiodePaths.AuditDir, "sender-audit.jsonl"), Path.Combine(QrDiodePaths.AuditDir, "receiver-audit.jsonl")];

    int broken = 0, checkedLogs = 0;
    foreach (var file in files)
    {
        var result = AuditLog.VerifyChain(file);
        if (result.Files == 0)
        {
            if (path is not null) { Console.Error.WriteLine($"{file}: no audit log here."); return 1; }
            continue;
        }

        checkedLogs++;
        if (result.Intact)
        {
            Console.WriteLine($"✔ {Path.GetFileName(file)}: intact — {result.Records:N0} records in {result.Files} file(s).");
        }
        else
        {
            broken++;
            Console.WriteLine($"✖ {Path.GetFileName(file)}: BROKEN at record {result.FirstBrokenIndex:N0} " +
                              $"({result.BrokenFile}, line {result.BrokenLine}): {result.Problem}.");
        }
    }

    if (checkedLogs == 0) Console.WriteLine($"No audit logs found in {QrDiodePaths.AuditDir}.");
    return broken == 0 ? 0 : 1;
}

static int Usage()
{
    Console.WriteLine("""
        QrDiode key ceremony tool

        Usage:
          init <endpointName>              Create (or open) this machine's key pairs in Windows CNG.
                                           TPM-backed when available ("Production": true: TPM only);
                                           always non-exportable.
          export <endpointName> <out.json> Export this machine's PUBLIC keys as a bundle file.
          import <bundle.json>             Import a peer's public bundle into the trust store.
          fingerprint <bundle.json>        Print a bundle's fingerprint for out-of-band comparison.
          list                             List trusted peers (and bundles that were skipped, and why).
          delete <endpointName> --yes      Delete this machine's local key pairs (irreversible).
          verify-audit [file.jsonl]        Check the audit log chain (default: the Sender's and the
                                           Receiver's logs on this machine, archived files included).
          demo                             One-click single-machine demo setup: provisions BOTH
                                           endpoints (demo-ot / demo-it) and cross-trusts them.
                                           Full security stays active — nothing is weakened.
                                           Refused when appsettings.json says "Production": true.
          demo-clean                       Remove the demo keys and bundles again.

        Ceremony:
          OT machine:  init ot-line-1  →  export ot-line-1 ot.json  →  carry ot.json to IT
          IT machine:  init it-recv-1  →  export it-recv-1 it.json  →  carry it.json to OT
          Each side:   import <other side's json>  →  compare FINGERPRINT verbally.
        """);
    return 1;
}
