using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using QrBridge.Shared;
using QrBridge.Shared.Bundles;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;

namespace QrBridge.Tests;

/// <summary>
/// The QR apps' bundle operations on qrbridge.db (decision 52: up to 50 messages / 128 KB, strict order): the sender's
/// claim, aired and release; the receiver's one-transaction, idempotent insert.
/// </summary>
public sealed class BundleRepositoryTests : IAsyncLifetime
{
    private readonly string _folder = Path.Combine(Path.GetTempPath(), "qrbridge-tests-" + Guid.NewGuid().ToString("N"));
    private ServiceProvider _sp = null!;
    private long _nextSequence;

    private OutboxRepository Outbox => _sp.GetRequiredService<OutboxRepository>();
    private InboxRepository Inbox => _sp.GetRequiredService<InboxRepository>();

    public async Task InitializeAsync()
    {
        var services = new ServiceCollection();
        services.AddBridgeData(new BridgeOptions { DataFolder = _folder });
        _sp = services.BuildServiceProvider();
        await DatabaseInitializer.InitializeAsync(_sp, NullLogger.Instance);
    }

    public async Task DisposeAsync()
    {
        await _sp.DisposeAsync();
        Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
        try { Directory.Delete(_folder, recursive: true); } catch { /* best effort */ }
    }

    private async Task<OutboxMessage> QueueAsync(int size = 10, MessagePriority priority = MessagePriority.Normal,
                                                 MessageKind kind = MessageKind.Request, DateTime? nextAttemptUtc = null)
    {
        await using var db = await _sp.GetRequiredService<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        var bytes = new byte[size];
        Random.Shared.NextBytes(bytes);
        var row = new OutboxMessage
        {
            MessageId = Guid.NewGuid(), Direction = Direction.CorpToDmz, ServiceName = "FC2FMS", Operation = "SendToFMS",
            Sequence = ++_nextSequence, PayloadFormat = PayloadFormat.RawSoap, Kind = kind,
            CorrelationId = kind == MessageKind.Request ? null : Guid.NewGuid(),
            Priority = kind == MessageKind.Request ? priority : MessagePriority.Answer,
            MessageBytes = bytes, MessageHash = Hashing.Sha256Hex(bytes), LightStatus = OutboxLightStatus.Pending,
            CreatedUtc = DateTime.UtcNow, NextAttemptUtc = nextAttemptUtc,
        };
        db.Outbox.Add(row);
        await db.SaveChangesAsync();
        return row;
    }

    private async Task<List<OutboxMessage>> RowsAsync()
    {
        await using var db = await _sp.GetRequiredService<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        return await db.Outbox.AsNoTracking().OrderBy(m => m.Sequence).ToListAsync();
    }

    private static int Size(params int[] envelopes) => BundleCodec.HeaderSize + envelopes.Sum(e => BundleCodec.EntryOverhead + e);

    [Fact]
    public async Task A_bundle_takes_at_most_the_message_limit()
    {
        for (int i = 0; i < 7; i++) await QueueAsync();

        var first = await Outbox.ClaimBundleAsync(maxMessages: 5, maxBytes: 1_000_000, CancellationToken.None);
        var second = await Outbox.ClaimBundleAsync(maxMessages: 5, maxBytes: 1_000_000, CancellationToken.None);

        Assert.Equal(5, first!.Messages.Count);
        Assert.Equal(2, second!.Messages.Count);
        Assert.Null(await Outbox.ClaimBundleAsync(5, 1_000_000, CancellationToken.None));
        Assert.Equal([1L, 2, 3, 4, 5], first.Messages.Select(m => m.Sequence));
    }

    [Fact]
    public async Task A_bundle_stops_at_the_first_message_that_does_not_fit_and_never_skips_ahead()
    {
        var a = await QueueAsync(100);
        var big = await QueueAsync(1000);
        var small = await QueueAsync(10); // would fit after a, but must not overtake big

        var bundle = await Outbox.ClaimBundleAsync(50, maxBytes: Size(100, 100), CancellationToken.None);

        Assert.Equal([a.MessageId], bundle!.Messages.Select(m => m.MessageId));
        var next = await Outbox.ClaimBundleAsync(50, maxBytes: Size(100, 100), CancellationToken.None);
        Assert.Equal([big.MessageId], next!.Messages.Select(m => m.MessageId)); // too big for any bundle: goes alone
        var last = await Outbox.ClaimBundleAsync(50, maxBytes: Size(100, 100), CancellationToken.None);
        Assert.Equal([small.MessageId], last!.Messages.Select(m => m.MessageId));
    }

    [Fact]
    public async Task A_bundle_follows_the_claim_order_answers_then_priorities_then_sequence()
    {
        var low = await QueueAsync(priority: MessagePriority.Low);
        var normal = await QueueAsync(priority: MessagePriority.Normal);
        var high = await QueueAsync(priority: MessagePriority.High);
        var receipt = await QueueAsync(kind: MessageKind.Receipt);

        var bundle = await Outbox.ClaimBundleAsync(50, 1_000_000, CancellationToken.None);

        Assert.Equal([receipt.MessageId, high.MessageId, normal.MessageId, low.MessageId], bundle!.Messages.Select(m => m.MessageId));
    }

    [Fact]
    public async Task Rows_not_yet_due_stay_out_and_a_row_is_never_in_two_bundles()
    {
        await QueueAsync(nextAttemptUtc: DateTime.UtcNow.AddMinutes(5));
        for (int i = 0; i < 30; i++) await QueueAsync();

        var bundles = (await Task.WhenAll(Enumerable.Range(0, 10).Select(_ => Outbox.ClaimBundleAsync(4, 1_000_000, CancellationToken.None)))).ToList();
        while (await Outbox.ClaimBundleAsync(4, 1_000_000, CancellationToken.None) is { } more) bundles.Add(more); // a claimer may give up under contention

        var ids = bundles.Where(b => b is not null).SelectMany(b => b!.Messages.Select(m => m.MessageId)).ToList();
        Assert.Equal(ids.Count, ids.Distinct().Count());
        Assert.Equal(30, ids.Count);
        Assert.All(await RowsAsync(), r => Assert.Equal(r.NextAttemptUtc is null ? OutboxLightStatus.Sending : OutboxLightStatus.Pending, r.LightStatus));
    }

    [Fact]
    public async Task An_aired_bundle_records_its_qr_session_and_a_late_call_cannot_undo_a_receipt()
    {
        var a = await QueueAsync();
        var b = await QueueAsync();
        var bundle = await Outbox.ClaimBundleAsync(50, 1_000_000, CancellationToken.None);
        await Outbox.MarkReceivedAsync([b.MessageId], CancellationToken.None); // its Receipt raced ahead

        var session = Guid.NewGuid();
        Assert.Equal(1, await Outbox.MarkAiredAsync(bundle!.BundleId, session, CancellationToken.None));

        var rows = await RowsAsync();
        Assert.Equal((OutboxLightStatus.Aired, session, bundle.BundleId), (rows[0].LightStatus, rows[0].QrSessionId, rows[0].BundleId));
        Assert.Equal(OutboxLightStatus.Received, rows[1].LightStatus);
        Assert.Equal(OutboxServiceStatus.Waiting, rows[0].ServiceStatus);
        Assert.Equal(1, rows[0].Attempts);
        Assert.Null(rows[0].LockedUtc);
        _ = a;
    }

    [Fact]
    public async Task A_released_bundle_goes_back_to_the_queue_after_the_delay_with_its_reason()
    {
        await QueueAsync();
        await QueueAsync();
        var bundle = await Outbox.ClaimBundleAsync(50, 1_000_000, CancellationToken.None);

        Assert.Equal(2, await Outbox.ReleaseBundleAsync(bundle!.BundleId, "Stage closed during encode.", TimeSpan.FromMinutes(1), CancellationToken.None));

        var rows = await RowsAsync();
        Assert.All(rows, r =>
        {
            Assert.Equal(OutboxLightStatus.Pending, r.LightStatus);
            Assert.Null(r.BundleId);
            Assert.Equal("Stage closed during encode.", r.LightComment);
            Assert.True(r.NextAttemptUtc > DateTime.UtcNow);
        });
        Assert.Null(await Outbox.ClaimBundleAsync(50, 1_000_000, CancellationToken.None)); // not due yet
    }

    [Fact]
    public async Task Restarting_the_qr_sender_puts_a_bundle_on_screen_back_in_the_queue()
    {
        await QueueAsync();
        await Outbox.ClaimBundleAsync(50, 1_000_000, CancellationToken.None);

        Assert.Equal(1, await Outbox.ResetSendingAsync(CancellationToken.None));

        var row = Assert.Single(await RowsAsync());
        Assert.Equal((OutboxLightStatus.Pending, (Guid?)null), (row.LightStatus, row.BundleId));
        Assert.NotNull(await Outbox.ClaimBundleAsync(50, 1_000_000, CancellationToken.None));
    }

    private static (MessageHeader, byte[]) Arrival(MessageKind kind = MessageKind.Request, Guid? id = null)
    {
        var header = new MessageHeader
        {
            MessageId = id ?? Guid.NewGuid(), Direction = Direction.CorpToDmz, ServiceName = "FC2FMS", Operation = "SendToFMS",
            Sequence = 1, Kind = kind, CorrelationId = kind == MessageKind.Request ? null : Guid.NewGuid(),
            Priority = kind == MessageKind.Request ? MessagePriority.Normal : MessagePriority.Answer,
            Path = kind == MessageKind.Request ? "/FMS_FC2FMSInterface/FC2FMSInterface.svc" : "",
            ContentType = kind == MessageKind.Request ? "text/xml; charset=utf-8" : "",
        };
        return (header, [1, 2, 3]);
    }

    [Fact]
    public async Task A_bundle_is_stored_in_one_go_with_its_ids_and_each_message_owed_a_receipt()
    {
        var bundleId = Guid.NewGuid();
        var session = Guid.NewGuid();
        var request = Arrival();
        var receipt = Arrival(MessageKind.Receipt);

        var result = await Inbox.AddMessagesAsync([request, receipt], bundleId, session, CancellationToken.None);

        Assert.Equal(new BundleStoreResult(2, 0), result);
        var stored = await Inbox.FindAsync(request.Item1.MessageId, CancellationToken.None);
        Assert.Equal((bundleId, session), (stored!.BundleId, stored.QrSessionId));
        Assert.NotNull(stored.ReceiptDueUtc);
        Assert.Null((await Inbox.FindAsync(receipt.Item1.MessageId, CancellationToken.None))!.ReceiptDueUtc); // a Receipt gets none
    }

    [Fact]
    public async Task A_bundle_aired_again_is_not_stored_twice_but_owed_a_receipt_again()
    {
        var request = Arrival();
        await Inbox.AddMessagesAsync([request], Guid.NewGuid(), Guid.NewGuid(), CancellationToken.None);
        var due = await Inbox.FindDueReceiptsAsync(10, CancellationToken.None);
        await Inbox.ClearReceiptDueAsync(Assert.Single(due), CancellationToken.None); // the gateway queued the Receipt; it got lost

        var newer = Guid.NewGuid();
        var result = await Inbox.AddMessagesAsync([request, Arrival()], newer, Guid.NewGuid(), CancellationToken.None);

        Assert.Equal(new BundleStoreResult(1, 1), result);
        var row = await Inbox.FindAsync(request.Item1.MessageId, CancellationToken.None);
        Assert.NotNull(row!.ReceiptDueUtc);
        Assert.Equal(newer, row.BundleId); // the latest crossing
    }

    [Fact]
    public async Task The_same_message_twice_in_one_bundle_is_stored_once()
    {
        var request = Arrival();

        var result = await Inbox.AddMessagesAsync([request, request], Guid.NewGuid(), Guid.NewGuid(), CancellationToken.None);

        Assert.Equal(new BundleStoreResult(1, 1), result);
    }
}
