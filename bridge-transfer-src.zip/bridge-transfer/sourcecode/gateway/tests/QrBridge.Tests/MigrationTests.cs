using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using QrBridge.Shared;
using QrBridge.Shared.Data;

namespace QrBridge.Tests;

/// <summary>
/// qrbridge.db under EF migrations (known issue 6, 27 Nov 2026): a new file gets every migration; a file made earlier
/// by EnsureCreated is matched against the migrations and adopted with its rows; one that matches none is refused unchanged.
/// </summary>
public sealed class MigrationTests : IDisposable
{
    private readonly string _folder = Path.Combine(Path.GetTempPath(), "qrbridge-migrations-" + Guid.NewGuid().ToString("N"));
    private string DatabasePath => Path.Combine(_folder, BridgeOptions.DatabaseFileName);

    public MigrationTests() => Directory.CreateDirectory(_folder);

    public void Dispose()
    {
        SqliteConnection.ClearAllPools();
        try { Directory.Delete(_folder, recursive: true); } catch { /* best effort */ }
    }

    private ServiceProvider Services()
    {
        var services = new ServiceCollection();
        services.AddBridgeData(new BridgeOptions { DataFolder = _folder });
        return services.BuildServiceProvider();
    }

    private BridgeDbContext Context(string path)
    {
        var options = new DbContextOptionsBuilder<BridgeDbContext>();
        DatabaseSetup.Configure(options, path);
        return new BridgeDbContext(options.Options);
    }

    private static async Task ExecuteAsync(BridgeDbContext db, string sql) => await db.Database.ExecuteSqlRawAsync(sql);

    private static async Task<long> ScalarAsync(BridgeDbContext db, string sql)
    {
        await db.Database.OpenConnectionAsync();
        try
        {
            await using var cmd = db.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = sql;
            return Convert.ToInt64(await cmd.ExecuteScalarAsync());
        }
        finally { await db.Database.CloseConnectionAsync(); }
    }

    /// <summary>The state of a file made before 27 Nov: the Initial tables, no migration history (as EnsureCreated left it).</summary>
    private async Task MakeOldDatabaseAsync(Func<BridgeDbContext, Task>? change = null)
    {
        await using var db = Context(DatabasePath);
        string initial = db.Database.GetMigrations().First();
        await db.GetService<IMigrator>().MigrateAsync(initial);
        await ExecuteAsync(db, "UPDATE SequenceCounter SET LastValue = 42;");
        await ExecuteAsync(db, "INSERT INTO Heartbeat (Component, LastSeenUtc, Info) VALUES ('SenderLoop', '2026-11-26 10:00:00', 'old');");
        if (change is not null) await change(db);
        await ExecuteAsync(db, "DROP TABLE __EFMigrationsHistory;");
        await ExecuteAsync(db, "DROP TABLE IF EXISTS __EFMigrationsLock;");
    }

    [Fact]
    public async Task A_new_database_gets_every_migration()
    {
        await using var sp = Services();
        await DatabaseInitializer.InitializeAsync(sp, NullLogger.Instance);

        await using var db = Context(DatabasePath);
        Assert.Equal(db.Database.GetMigrations(), await db.Database.GetAppliedMigrationsAsync());
        Assert.Empty(await db.Database.GetPendingMigrationsAsync());
    }

    [Fact]
    public async Task The_migrations_build_exactly_the_tables_of_the_current_model()
    {
        // Fails when an entity changed without "dotnet ef migrations add", and proves the adoption comparison sees
        // EnsureCreated's tables and the migrations' tables as the same.
        await using (var sp = Services())
            await DatabaseInitializer.InitializeAsync(sp, NullLogger.Instance);
        string modelPath = Path.Combine(_folder, "model.db");
        await using (var model = Context(modelPath))
            await model.Database.EnsureCreatedAsync();

        await using var migrated = Context(DatabasePath);
        await using var created = Context(modelPath);
        Assert.Equal(await SignatureAsync(created), await SignatureAsync(migrated));
    }

    private static async Task<SortedSet<string>> SignatureAsync(BridgeDbContext db)
    {
        await db.Database.OpenConnectionAsync();
        try { return await SchemaAdoption.ReadSignatureAsync((SqliteConnection)db.Database.GetDbConnection(), CancellationToken.None); }
        finally { await db.Database.CloseConnectionAsync(); }
    }

    [Fact]
    public async Task A_database_made_before_migrations_is_adopted_and_keeps_its_rows_and_sequence_state()
    {
        await MakeOldDatabaseAsync();

        await using (var sp = Services())
            await DatabaseInitializer.InitializeAsync(sp, NullLogger.Instance);

        await using var db = Context(DatabasePath);
        Assert.Equal(db.Database.GetMigrations(), await db.Database.GetAppliedMigrationsAsync());
        Assert.Equal(2, await ScalarAsync(db, "SELECT COUNT(*) FROM SequenceCounter WHERE LastValue = 42;")); // the counter goes on, never restarts
        Assert.Equal(1, await ScalarAsync(db, "SELECT COUNT(*) FROM Heartbeat WHERE Info = 'old';"));
        Assert.Equal(1, await ScalarAsync(db, "SELECT COUNT(*) FROM pragma_table_info('Outbox') WHERE name = 'BundleId';")); // later migration applied
    }

    [Fact]
    public async Task An_adopted_database_starts_normally_the_next_time()
    {
        await MakeOldDatabaseAsync();
        await using (var sp = Services()) await DatabaseInitializer.InitializeAsync(sp, NullLogger.Instance);

        await using (var sp = Services()) await DatabaseInitializer.InitializeAsync(sp, NullLogger.Instance);

        await using var db = Context(DatabasePath);
        Assert.Equal(2, await ScalarAsync(db, "SELECT COUNT(*) FROM __EFMigrationsHistory;"));
    }

    [Fact]
    public async Task A_database_with_a_changed_table_is_refused_and_left_as_it_was()
    {
        await MakeOldDatabaseAsync(db => ExecuteAsync(db, "ALTER TABLE Outbox ADD COLUMN Surprise TEXT;"));

        await using var sp = Services();
        var ex = await Assert.ThrowsAsync<SchemaMismatchException>(() => DatabaseInitializer.InitializeAsync(sp, NullLogger.Instance));

        Assert.Contains("match no known version", ex.Message);
        await using var db = Context(DatabasePath);
        Assert.Equal(0, await ScalarAsync(db, "SELECT COUNT(*) FROM sqlite_master WHERE name = '__EFMigrationsHistory';"));
        Assert.Equal(1, await ScalarAsync(db, "SELECT COUNT(*) FROM pragma_table_info('Outbox') WHERE name = 'Surprise';"));
        Assert.Equal(2, await ScalarAsync(db, "SELECT COUNT(*) FROM SequenceCounter WHERE LastValue = 42;"));
    }

    [Fact]
    public async Task A_partial_database_is_refused()
    {
        await MakeOldDatabaseAsync(db => ExecuteAsync(db, "DROP TABLE AcknowledgedGap;"));

        await using var sp = Services();
        await Assert.ThrowsAsync<SchemaMismatchException>(() => DatabaseInitializer.InitializeAsync(sp, NullLogger.Instance));
    }
}
