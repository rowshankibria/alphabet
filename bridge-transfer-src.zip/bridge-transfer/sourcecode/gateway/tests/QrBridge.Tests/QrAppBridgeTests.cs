using Microsoft.EntityFrameworkCore;
using QrBridge.Shared;
using QrBridge.Shared.Bundles;
using QrBridge.Shared.Data;
using QrBridge.Shared.Serialization;

namespace QrBridge.Tests;

/// <summary>
/// The QR apps' side of qrbridge.db (Integration-Plan §2.4–2.5), as the Sender and the Receiver open it in Bridge mode:
/// <see cref="QrAppBridge"/> creates or upgrades the database, the receiver's <see cref="InboxBundleWriter"/> refuses a
/// bundle that is not for its side — storing nothing — and stores a good one.
/// </summary>
public sealed class QrAppBridgeTests : IAsyncLifetime
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "qrbridge-qrapp-" + Guid.NewGuid().ToString("N"));
    private QrAppBridge _dmz = null!;

    public async Task InitializeAsync() =>
        _dmz = await QrAppBridge.OpenAsync(new BridgeOptions { Side = BridgeSide.Dmz, DataFolder = Path.Combine(_root, "Dmz") }, CancellationToken.None);

    public async Task DisposeAsync()
    {
        await _dmz.DisposeAsync();
        Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
        try { Directory.Delete(_root, recursive: true); } catch { /* best effort */ }
    }

    private static byte[] Envelope(Direction direction, long sequence = 1) => new MessageSerializer().Serialize(new MessageHeader
    {
        MessageId = Guid.NewGuid(), Direction = direction, ServiceName = "FC2FMS", Operation = "SendToFMS", Sequence = sequence,
        Path = "/FMS_FC2FMSInterface/FC2FMSInterface.svc", ContentType = "text/xml; charset=utf-8",
    }, "<s:Envelope/>"u8);

    private async Task<int> InboxCountAsync()
    {
        var options = new DbContextOptionsBuilder<BridgeDbContext>();
        DatabaseSetup.Configure(options, _dmz.Options.DatabasePath);
        await using var db = new BridgeDbContext(options.Options);
        return await db.Inbox.CountAsync();
    }

    [Fact]
    public async Task Opening_creates_the_database_on_the_latest_migration_and_the_doorbells()
    {
        Assert.True(File.Exists(_dmz.Options.DatabasePath));
        Assert.True(_dmz.Signals.Inbox.IsAvailable);

        await using var again = await QrAppBridge.OpenAsync(_dmz.Options, CancellationToken.None); // the gateway or the other app opened it first
        Assert.Null(await again.Outbox.FindAsync(Guid.NewGuid(), CancellationToken.None));
    }

    [Fact]
    public async Task A_bundle_for_this_side_is_stored_with_its_bundle_and_session()
    {
        var bundleId = Guid.NewGuid();
        byte[] bundle = BundleCodec.Build(bundleId, [(1, Envelope(Direction.CorpToDmz, 1)), (2, Envelope(Direction.CorpToDmz, 2))]);

        var stored = await _dmz.Writer.StoreAsync(bundle, Guid.NewGuid(), CancellationToken.None);

        Assert.Equal(new StoredBundle(bundleId, 1, 2, 2, 2, 0), stored);
        Assert.Equal(2, await InboxCountAsync());
    }

    [Fact]
    public async Task A_bundle_with_a_message_for_the_other_side_is_refused_and_nothing_is_stored()
    {
        byte[] bundle = BundleCodec.Build(Guid.NewGuid(), [(1, Envelope(Direction.CorpToDmz)), (2, Envelope(Direction.DmzToCorp))]);

        var ex = await Assert.ThrowsAsync<InvalidDataException>(() => _dmz.Writer.StoreAsync(bundle, Guid.NewGuid(), CancellationToken.None));

        Assert.Contains("DmzToCorp", ex.Message);
        Assert.Equal(0, await InboxCountAsync());
    }

    [Theory]
    [InlineData(new byte[] { 1, 2, 3 })]       // not a bundle
    [InlineData(new byte[] { 0x42, 0x52, 0x47 })] // not even a message
    public async Task Bytes_that_are_not_a_bundle_or_hold_a_broken_message_are_refused(byte[] junk)
    {
        await Assert.ThrowsAsync<InvalidDataException>(() => _dmz.Writer.StoreAsync(junk, Guid.NewGuid(), CancellationToken.None));
        byte[] brokenMessage = BundleCodec.Build(Guid.NewGuid(), [(1, junk)]);
        await Assert.ThrowsAsync<InvalidDataException>(() => _dmz.Writer.StoreAsync(brokenMessage, Guid.NewGuid(), CancellationToken.None));

        Assert.Equal(0, await InboxCountAsync());
    }
}
