using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using QrBridge.Shared.Data.Repositories;

namespace QrBridge.Shared.Data;

public static class DataServiceCollectionExtensions
{
    /// <summary>
    /// Registers the bridge DbContext factory and the repositories. Call from both apps.
    /// The database path is read from <see cref="IOptions{BridgeOptions}"/> when the first context is
    /// created, so configure <see cref="BridgeOptions"/> (e.g. BindConfiguration("Bridge")) before resolving.
    /// </summary>
    public static IServiceCollection AddBridgeData(this IServiceCollection services)
    {
        services.AddDbContextFactory<BridgeDbContext>((sp, o) =>
            DatabaseSetup.Configure(o, sp.GetRequiredService<IOptions<BridgeOptions>>().Value.DatabasePath));

        services.AddSingleton<OutboxRepository>();
        services.AddSingleton<InboxRepository>();
        services.AddSingleton<HeartbeatRepository>();
        // The QR apps' two ends of the light (the receiver's also needs BridgeSignals, which each app registers).
        services.AddSingleton<Bundles.OutboxBundler>();
        services.AddSingleton<Bundles.InboxBundleWriter>();
        return services;
    }

    /// <summary>Same as <see cref="AddBridgeData(IServiceCollection)"/> with fixed options (tests, tools).</summary>
    public static IServiceCollection AddBridgeData(this IServiceCollection services, BridgeOptions options)
    {
        services.AddSingleton(Options.Create(options));
        return services.AddBridgeData();
    }
}
