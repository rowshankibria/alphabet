namespace QrBridge.Shared.Data.Entities;

/// <summary>
/// The columns the Outbox and the Inbox tables of qrbridge.db share: one stored message and its processing state.
/// Not a table itself — each derived class is its own table. Each adds its own LightStatus and ServiceStatus and its own columns.
/// </summary>
public abstract class BaseMessage
{
    /// <summary>Primary key. End-to-end id of the message: set once by the sending gateway, the same in the Outbox and the Inbox.</summary>
    public Guid MessageId { get; set; }

    /// <summary>Which way the message goes: CorpToDmz (Inbound) or DmzToCorp (Outbound).</summary>
    public Direction Direction { get; set; }

    /// <summary>Route service name from routes.json, e.g. "FC2FMS" (or the request path for unlisted calls).</summary>
    public string ServiceName { get; set; } = "";

    /// <summary>SOAP operation the caller called, e.g. "SendToFMS".</summary>
    public string Operation { get; set; } = "";

    /// <summary>Operator label from the payload (FMS MESSAGE/@TYPE or root element), copied from the message header; null when unknown.</summary>
    public string? BusinessType { get; set; }

    /// <summary>The sender's per-direction running number (1, 2, 3, …), also in the header. Rows are claimed in this order, and it lets the receiving side spot a gap.</summary>
    public long Sequence { get; set; }

    /// <summary>
    /// Which run of the sender's counter <see cref="Sequence"/> belongs to (header SequenceRunId). Gaps are looked for
    /// per direction and run: numbers restart at 1 in a new run, so 1, 2, 3 of a new run are neither duplicates nor a gap.
    /// </summary>
    public Guid SequenceRunId { get; set; }

    /// <summary>What the body is. Always RawSoap: the caller's SOAP body, exactly as received.</summary>
    public PayloadFormat PayloadFormat { get; set; }

    // ----- Copies of header fields (header v4), so the round trip can query them without unpacking MessageBytes. -----

    /// <summary>Request (a caller's call), Receipt or Reply. Only Requests are ever posted to a real service.</summary>
    public MessageKind Kind { get; set; } = MessageKind.Request;

    /// <summary>Reply: the MessageId of the request it answers. Null for a Request.</summary>
    public Guid? CorrelationId { get; set; }

    /// <summary>Lower-case hex SHA-256 of the business content (how a caller's retry is recognised). Null when not computed.</summary>
    public string? ContentFingerprint { get; set; }

    /// <summary>After this time (sender's clock, UTC) a request is not delivered or re-aired. Null = no expiry.</summary>
    public DateTime? ExpiresUtc { get; set; }

    /// <summary>
    /// Header Priority (decision D73): Answer (Receipts, Replies), then High, Normal, Low. Stored as its number (0–3) so
    /// the claims can order by it: the QR sender airs the lowest first, the far side has one delivery loop per class.
    /// </summary>
    public MessagePriority Priority { get; set; } = MessagePriority.Normal;

    /// <summary>
    /// The QR bundle (several messages in one QR session, decision 52) that carried this message: set by the QR sender
    /// when it claims the bundle (Outbox) and copied from the bundle by the QR receiver (Inbox), so both sides' rows of
    /// one bundle share it. Null until claimed or for rows that never crossed in a bundle.
    /// </summary>
    public Guid? BundleId { get; set; }

    /// <summary>
    /// The QrDiode session (its SessionId, the same on both screens) the bundle went out in: Outbox once aired, Inbox on
    /// arrival. A re-aired message keeps the latest. Lets an operator match a row to the QR apps' audit logs.
    /// </summary>
    public Guid? QrSessionId { get; set; }

    /// <summary>The serialized message (MessageSerializer bytes: header + checksum + compressed SOAP body). Never changed after insert.</summary>
    public byte[] MessageBytes { get; set; } = [];

    /// <summary>Lower-case hex SHA-256 of <see cref="MessageBytes"/>. Equal on both sides when nothing was damaged (reconciliation).</summary>
    public string MessageHash { get; set; } = "";

    /// <summary>How many times the row has been claimed for work (Outbox: by the QR sender; Inbox: delivery attempts).</summary>
    public int Attempts { get; set; }

    /// <summary>When the sending gateway accepted the caller's request (UTC; from the header on the Inbox side).</summary>
    public DateTime CreatedUtc { get; set; }

    /// <summary>When the row was claimed for work (UTC); null while not claimed.</summary>
    public DateTime? LockedUtc { get; set; }

    /// <summary>Earliest time the row may be claimed again after a release or a transient failure (UTC).</summary>
    public DateTime? NextAttemptUtc { get; set; }

    // ----- Status: the light group (LightStatus in each table) and the service group (ServiceStatus in each table). -----

    /// <summary>Why the light status is what it is (arrival check failed, released, out of re-air tries…), for operators. Never the payload.</summary>
    public string? LightComment { get; set; }

    /// <summary>The real service's HTTP status code; null when there was no HTTP answer (yet), e.g. DNS, refused connection, timeout.</summary>
    public int? ServiceHttpStatus { get; set; }

    /// <summary>The service outcome and its probable reason in plain words, for operators. Never the payload.</summary>
    public string? ServiceComment { get; set; }

    /// <summary>When ServiceStatus last changed (UTC).</summary>
    public DateTime? ServiceUpdatedUtc { get; set; }
}