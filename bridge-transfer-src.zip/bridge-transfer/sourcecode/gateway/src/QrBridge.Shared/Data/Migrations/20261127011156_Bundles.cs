﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace QrBridge.Shared.Data.Migrations
{
    /// <inheritdoc />
    public partial class Bundles : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "BundleId",
                table: "Outbox",
                type: "TEXT",
                maxLength: 36,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "QrSessionId",
                table: "Outbox",
                type: "TEXT",
                maxLength: 36,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BundleId",
                table: "Inbox",
                type: "TEXT",
                maxLength: 36,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "QrSessionId",
                table: "Inbox",
                type: "TEXT",
                maxLength: 36,
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Outbox_Bundle",
                table: "Outbox",
                column: "BundleId",
                filter: "BundleId IS NOT NULL");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Outbox_Bundle",
                table: "Outbox");

            migrationBuilder.DropColumn(
                name: "BundleId",
                table: "Outbox");

            migrationBuilder.DropColumn(
                name: "QrSessionId",
                table: "Outbox");

            migrationBuilder.DropColumn(
                name: "BundleId",
                table: "Inbox");

            migrationBuilder.DropColumn(
                name: "QrSessionId",
                table: "Inbox");
        }
    }
}
