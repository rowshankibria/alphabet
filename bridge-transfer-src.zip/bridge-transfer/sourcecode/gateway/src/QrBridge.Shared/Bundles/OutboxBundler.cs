using QrBridge.Shared.Data.Repositories;

namespace QrBridge.Shared.Bundles;

/// <summary>One bundle ready for the QR sender: the bytes to air and what to show on the stage.</summary>
public sealed record OutgoingBundle(Guid BundleId, string FileName, byte[] Bytes, int Count, long MinSequence, long MaxSequence);

/// <summary>
/// The QR sender's side of the Outbox (Integration-Plan §2.4): claim the next bundle and build its bytes, then mark it
/// aired after its QrDiode session, or put it back when it could not be aired. The rows' order, priorities, re-airing
/// and Receipts are the gateway's business; the sender only carries what it is given.
/// </summary>
public sealed class OutboxBundler(OutboxRepository outbox)
{
    /// <summary>The next bundle, or null when nothing is due.</summary>
    public async Task<OutgoingBundle?> ClaimAsync(int maxMessages, int maxBytes, CancellationToken ct)
    {
        var claimed = await outbox.ClaimBundleAsync(maxMessages, maxBytes, ct);
        if (claimed is null) return null;

        var items = claimed.Messages.Select(m => (m.Sequence, m.MessageBytes)).ToList();
        long min = items.Min(i => i.Sequence), max = items.Max(i => i.Sequence);
        return new OutgoingBundle(claimed.BundleId, BundleCodec.FileName(min, max), BundleCodec.Build(claimed.BundleId, items),
                                  items.Count, min, max);
    }

    /// <summary>The bundle was on air for its full air time in QR session <paramref name="qrSessionId"/>.</summary>
    public Task<int> MarkAiredAsync(Guid bundleId, Guid qrSessionId, CancellationToken ct) =>
        outbox.MarkAiredAsync(bundleId, qrSessionId, ct);

    /// <summary>The bundle was not aired (stage closed, skipped, encode error): back to the queue after <paramref name="retryDelay"/>.</summary>
    public Task<int> ReleaseAsync(Guid bundleId, string reason, TimeSpan retryDelay, CancellationToken ct) =>
        outbox.ReleaseBundleAsync(bundleId, reason, retryDelay, ct);
}
