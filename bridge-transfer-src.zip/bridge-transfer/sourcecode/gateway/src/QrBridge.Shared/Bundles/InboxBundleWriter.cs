using System.Runtime.Versioning;
using Microsoft.Extensions.Options;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;

namespace QrBridge.Shared.Bundles;

/// <summary>What <see cref="InboxBundleWriter.StoreAsync"/> stored. Ids and counts only, never a payload.</summary>
public sealed record StoredBundle(Guid BundleId, long MinSequence, long MaxSequence, int Count, int Added, int Duplicates);

/// <summary>
/// The QR receiver's side of the Inbox (Integration-Plan §2.5): a bundle that QrDiode verified and decrypted is parsed,
/// every message's header is peeked (the gateway checks the rest when it opens them), and all of them are stored in one
/// transaction; then the gateway's Inbox doorbell rings. A message already in the Inbox is skipped and owed a Receipt
/// again, so a re-aired bundle is harmless.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class InboxBundleWriter(InboxRepository inbox, BridgeSignals signals, IOptions<BridgeOptions> options)
{
    /// <exception cref="InvalidDataException">
    /// The bundle is not acceptable — malformed, or a message for the other direction. Nothing was stored; the same bytes
    /// would fail again, so the QR session should not be received again.
    /// </exception>
    /// <remarks>Any other exception means storing failed (nothing stored): the session may be received again.</remarks>
    public async Task<StoredBundle> StoreAsync(byte[] bundleBytes, Guid qrSessionId, CancellationToken ct)
    {
        var bridge = options.Value;
        var bundle = BundleCodec.Parse(bundleBytes, BundleCodec.MaxEnvelopeBytes(bridge.MaxPayloadBytes));

        var messages = new List<(MessageHeader Header, byte[] MessageBytes)>(bundle.Envelopes.Count);
        for (int i = 0; i < bundle.Envelopes.Count; i++)
        {
            MessageHeader header;
            try
            {
                header = MessageSerializer.PeekHeader(bundle.Envelopes[i]);
            }
            catch (Exception ex) when (ex is InvalidDataException or EndOfStreamException or IOException or ArgumentException or FormatException)
            {
                throw new InvalidDataException($"Message {i + 1} of the bundle cannot be read: {ex.Message}", ex);
            }

            // One bundle comes from one sender: a message for the other direction means the bundle is not for this side.
            if (header.Direction != bridge.ReceiveDirection)
                throw new InvalidDataException(
                    $"Message {i + 1} of the bundle goes {header.Direction}; the {bridge.Side} side receives {bridge.ReceiveDirection}.");
            messages.Add((header, bundle.Envelopes[i]));
        }

        var stored = await inbox.AddMessagesAsync(messages, bundle.BundleId, qrSessionId, ct);
        signals.Inbox.Set();
        return new StoredBundle(bundle.BundleId, bundle.MinSequence, bundle.MaxSequence, messages.Count, stored.Added, stored.Duplicates);
    }
}
