using System.Runtime.Versioning;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Signals;

namespace QrBridge.Shared.Bundles;

/// <summary>
/// What a QrDiode app (Sender or Receiver, "QrDiode:Mode" = Bridge) needs of the gateway's database on its machine: one
/// small composition root, so the WPF apps need no generic host. <see cref="OpenAsync"/> creates or upgrades qrbridge.db
/// exactly as the gateway does (whichever starts first), and opens the doorbells. Both apps and the gateway on one
/// machine must use the same "Bridge" settings (Side, DataFolder).
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class QrAppBridge : IAsyncDisposable
{
    /// <summary>How often each QR app writes its liveness row (Components.SenderLoop / ReceiverLoop), shown on the gateway's /health.</summary>
    public static readonly TimeSpan HeartbeatInterval = TimeSpan.FromSeconds(30);

    private readonly ServiceProvider _services;

    private QrAppBridge(ServiceProvider services, BridgeOptions options)
    {
        _services = services;
        Options = options;
    }

    public BridgeOptions Options { get; }
    public OutboxBundler Bundler => _services.GetRequiredService<OutboxBundler>();
    public InboxBundleWriter Writer => _services.GetRequiredService<InboxBundleWriter>();
    public OutboxRepository Outbox => _services.GetRequiredService<OutboxRepository>();
    public HeartbeatRepository Heartbeats => _services.GetRequiredService<HeartbeatRepository>();
    public BridgeSignals Signals => _services.GetRequiredService<BridgeSignals>();

    /// <exception cref="InvalidOperationException">The database cannot be opened (a former send.db/received.db in the folder, a schema that matches no migration…).</exception>
    public static async Task<QrAppBridge> OpenAsync(BridgeOptions options, CancellationToken ct, ILoggerFactory? loggerFactory = null)
    {
        var factory = loggerFactory ?? NullLoggerFactory.Instance;
        var services = new ServiceCollection();
        services.AddBridgeData(options);
        services.AddSingleton(factory);
        services.AddSingleton<BridgeSignals>();
        var provider = services.BuildServiceProvider();
        try
        {
            await DatabaseInitializer.InitializeAsync(provider, factory.CreateLogger<QrAppBridge>(), ct);
            _ = provider.GetRequiredService<BridgeSignals>(); // open the doorbells now, not on the first message
            return new QrAppBridge(provider, options);
        }
        catch
        {
            await provider.DisposeAsync();
            throw;
        }
    }

    public ValueTask DisposeAsync() => _services.DisposeAsync();
}
