# Gateway-to-QrDiode — developer workflow reference

For the single current system architecture and its two vertical round trips, see
[system architecture](../../../../docs/gateway-to-qrdiode/architecture.md). This document is the detailed
developer reference for the individual workflow steps and queue handling.

How one WCF call crosses the air gap, step by step, in both directions. Each direction is explained in full:
gateway → database → QrDiode sending → QrDiode receiving → database → HttpClient call to the real service.

**Status:** ✅ built and tested · 🔶 planned (not built yet).
The gateway, the bridge database (`qrbridge.db`, one per machine) and the QrDiode optical protocol are built. The two connections **QrDiode Sender ← Outbox**
and **QrDiode Receiver → Inbox** are planned ([integration-plan.md](../../../../docs/gateway-to-qrdiode/integration-plan.md) §2.2–2.5).
In the diagrams, planned steps are inside a lightly shaded block marked PLANNED, or on dashed arrows.

**For design review:** step ids (I1–I49 Inbound, O1–O49 Outbound) are the same in the tables and the diagrams.
Section 7 collects the delivery guarantees, crash points, ordering rules, limits and the weak points found in the code.

## Contents

1. [Overview and terms](#1-overview-and-terms)
2. [Inbound — Corp → DMZ](#2-inbound--corp--dmz)
3. [Outbound — DMZ → Corp](#3-outbound--dmz--corp)
4. [Shared logic in detail](#4-shared-logic-in-detail)
5. [Database reference](#5-database-reference)
6. [Security and integrity](#6-security-and-integrity)
7. [Design review notes](#7-design-review-notes)
8. [Not built yet / open points](#8-not-built-yet--open-points)

---

## 1. Overview and terms

Each machine runs the Gateway (IIS website) and two QrDiode WPF apps: Sender for the screen and Receiver for the
camera. Each machine is the sender for one direction and the receiver for the other. Only `Bridge:Side`
(`Corp` / `Dmz`) in `appsettings.{Side}.json` makes them different. The planned integration shares one SQLite
file, `qrbridge.db`, in `C:\ProgramData\QrBridge\Data\` and two named events (doorbells); the QR apps are not connected yet.

See the [system architecture](../../../../docs/gateway-to-qrdiode/architecture.md) for the current overview and vertical round-trip diagrams.

| Term | Meaning |
|---|---|
| **Inbound** / **Outbound** | Corp → DMZ / DMZ → Corp. Stored as `Direction = CorpToDmz` / `DmzToCorp`. |
| **Gateway Sender part** | Gateway code that takes a caller's call and saves it (`Ingress/` folder). |
| **Gateway Receiver part** | Gateway code that delivers an arrived message to the real service (`Egress/` folder). |
| **Outbox** | Table in `qrbridge.db`: messages waiting to go to the other side. |
| **Inbox** | Table in `qrbridge.db`: messages that arrived from the other side. |
| **Doorbell** | Windows named event (`Global\QrBridge.{Side}.Outbox` / `.Inbox`) that wakes the other program at once. If it is missed, the program still checks the table every 2 s. |
| **MessageBytes** | One message packed into one byte array: a small header + checksum + the caller's original request, compressed. |
| **MessageHash** | SHA-256 of MessageBytes. Same value in the Outbox and the far Inbox = the message arrived undamaged. |
| **Bundle** 🔶 | Several messages put on screen together in one QR session, so a burst of calls moves faster. |
| **Aired** 🔶 | Shown on screen long enough for the camera to read it. The Outbox light status `Aired` exists ✅ (24 Nov), but nothing sets it yet. The receiving gateway writes Receipts ✅ (step 9b) and the sending gateway reads them ✅ (`AnswerReader`, tracker step 10a: a Receipt moves the row on to `Received`), but nothing carries them over the light yet 🔶, so on real hardware this is the sender's "done". |
| **Receipt / Reply** ✅ | Messages the **receiving** gateway writes into its own Outbox for the opposite lane (V6 fix step 9b): a Receipt for every arrived message ("it crossed the light"), a Reply for every final outcome of a Request ("this is what the real service did", with its answer). Written ✅; read by the sending side ✅ (step 10a: Outbox row updated, a held RoundTrip caller gets the real answer); carried over the light 🔶. |
| **Heartbeat message** ✅ | An empty message a gateway queues when its side has sent nothing for `Gateway:HeartbeatMinutes` (5) (step 17, D80–D83): "I am still here". It takes a sequence number (so a lost last message becomes a gap), goes first, gets no Receipt, is never re-aired, and is not queued while an earlier one still waits to be aired. The far side reads it (`AnswerReader`) and counts it as "heard"; nothing heard for `Gateway:FarSideSilentMinutes` (15) = **far side silent** (`/health` unhealthy + a `Light:` warning). Written and read ✅; carried over the light 🔶. Not the same as the component heartbeats in the `Heartbeat` table ("this loop is alive"). |
| **Light / service status** ✅ | Each Outbox and Inbox row has two status groups (decision D24): `LightStatus` (did it cross the light? screens, cameras, QR apps) and `ServiceStatus` (what did the real service do?). An operator sees at once where a problem is. |

---

## 2. Inbound — Corp → DMZ

**Example:** Rapid Restore FCR sends a permit request to FMS: operation `SendToFMS` on
`/FMS_FC2FMSInterface/FC2FMSInterface.svc`, message type `REQUEST_FOR_PERMIT`.

| | Corp machine (sender) | DMZ machine (receiver) |
|---|---|---|
| Who | Caller: Rapid Restore FCR | Real service: `FC2FMSInterface.svc` on the DMZ RR server |
| How the call arrives | Corporate load balancer is pointed at the Corp gateway | — |
| Gateway settings | `appsettings.Corp.json`: `Bridge:Side = Corp` | `appsettings.Dmz.json`: `Side = Dmz`, `Receiver:DefaultBaseUrl = https://dmz-rr-server` (placeholder) |
| Route in `routes.json` | `FC2FMS`, `SenderSide: Corp` | same file, same entry |
| WSDL used for the check | `Contracts/Inbound/FC2FMS/` | — |
| Database | `qrbridge.db` → `Outbox` | `qrbridge.db` → `Inbox` |
| Doorbell | `Global\QrBridge.Corp.Outbox` | `Global\QrBridge.Dmz.Inbox` |
| QrDiode app | Sender (screen) | Receiver (camera) |

### 2.0 Inbound sequence diagram

```mermaid
sequenceDiagram
    box transparent Corp machine
        participant RR as Rapid Restore FCR
        participant LB as Corp load balancer
        participant GS as Corp Gateway Sender part
        participant SDB as Corp qrbridge.db - Outbox
        participant QS as Corp QrDiode Sender
    end
    box transparent DMZ machine
        participant QR as DMZ QrDiode Receiver
        participant RDB as DMZ qrbridge.db - Inbox
        participant GR as DMZ Gateway Receiver part
        participant SVC as FC2FMS real service
        participant ADB as DMZ qrbridge.db - Outbox - Replies and Receipts
    end

    RR->>LB: I1 POST /FMS_FC2FMSInterface/FC2FMSInterface.svc SendToFMS
    LB->>GS: I2 same request, unchanged
    GS->>GS: I3-I4 read body as byte[] (max 1 MB)
    break body over 1 MB
        GS-->>RR: SOAP fault HTTP 413, nothing stored
    end
    GS->>GS: I5 SoapRequest.TryParse through SafeXml
    break not a SOAP 1.1 or 1.2 request
        GS-->>RR: SOAP fault HTTP 400, nothing stored
    end
    GS->>GS: I6 RouteTable.Resolve(path, SendToFMS) = RoundTrip
    GS->>GS: I7 PayloadInspector reads TYPE = REQUEST_FOR_PERMIT
    break route is Echo, Unavailable or Reject
        GS-->>RR: I8 echo, RETURN_CODE 1599 or SOAP fault, nothing stored
    end
    GS->>GS: I9 ContractCatalog.Check against Contracts/Inbound/FC2FMS
    break request does not match the WSDL
        GS-->>RR: SOAP fault naming the mismatch, nothing stored
    end
    GS->>GS: I10 AllowedTypes of SendToFMS contains REQUEST_FOR_PERMIT
    break type not allowed
        GS-->>RR: RETURN_CODE 1597, nothing stored
    end
    GS->>GS: I11 build MessageHeader, ExpiresUtc = now + 600 s
    GS->>SDB: I14 COUNT Outbox Requests, LightStatus Pending, Sending or Aired
    break 5000 or more waiting
        GS-->>RR: RETURN_CODE 1598, nothing stored
    end
    GS->>SDB: I16 BEGIN transaction
    GS->>SDB: I17 UPDATE SequenceCounter CorpToDmz RETURNING LastValue, RunId
    GS->>GS: I18-I19 MessageBytes = Serialize(header, body), MessageHash = SHA-256
    GS->>SDB: I20 INSERT Outbox row, LightStatus Pending, ServiceStatus Waiting
    GS->>SDB: I21 COMMIT
    GS--)QS: I22 SetEvent Global\QrBridge.Corp.Outbox
    GS-->>RR: I13 held up to 270 s - FMS's answer from the DMZ Reply, else RETURN_CODE 1596 - header X-QrBridge-MessageId

    rect rgba(255,193,7,0.12)
        Note over SDB,RDB: PLANNED I24-I39 - QrDiode is not connected to the database yet
        QS->>SDB: I26 claim Pending rows - answers first, then High, Normal, Low, by Sequence (max 50 or 128 KB), set Sending
        QS->>QS: I27 pack rows into bundle-firstSeq-lastSeq.qbb
        QS->>QS: I28 SendSession.Create - Brotli, ECDH P-256 + HKDF, AES-256-GCM, ECDSA-signed manifest
        QS->>QS: I29 LT fountain encode, K symbols of up to 1350 bytes
        loop I30 at least 3 x K frames and at least 6 s, 15 fps
            QS-)QR: QR frame - manifest every 20 frames, otherwise one data symbol
        end
        QS->>SDB: I31 rows LightStatus Aired (skipped - Pending now, encode error - Pending after 30 s)
        QR->>QR: I32 CRC-32 per frame, bad frames dropped
        QR->>QR: I33 manifest - trusted signature, addressed to this receiver, anti-replay Fresh
        QR->>QR: I34 frame MAC on every data frame, then LT decode until all K source symbols recovered
        QR->>QR: I35 ciphertext hash, AES-GCM open, capped Brotli (exact size), content gate
        QR->>QR: I36 BundleCodec.Parse, PeekHeader each message, Direction must be CorpToDmz
        QR->>RDB: I37 BEGIN, INSERT each message (skip existing MessageId), COMMIT
        QR->>QR: I38 CommitReplay only after the Inbox commit
        QR--)GR: I39 SetEvent Global\QrBridge.Dmz.Inbox
    end

    GR->>RDB: I41 claim lowest Sequence, LightStatus Received, ServiceStatus Pending (or Retrying and due), set Delivering, Attempts + 1
    GR->>GR: I42 MessageSerializer.Deserialize - magic, lengths, SHA-256 checksum, capped Brotli
    GR->>GR: I43 header equals row, catalogue fingerprint equals this side, Direction CorpToDmz, age within 7 days, not over 60 min ahead
    GR->>GR: I44 routes.json - FC2FMS SenderSide Corp, SendToFMS is RoundTrip, not past ExpiresUtc
    break checksum, header or route check fails
        GR->>ADB: Reply Rejected (CorrelationId = the request)
        GR->>RDB: LightStatus Rejected, reason in LightComment, never retried
    end
    GR->>GR: I45 URL from appsettings.Dmz.json only - https://dmz-rr-server/FMS_FC2FMSInterface/FC2FMSInterface.svc
    break no URL configured
        GR->>ADB: Reply NotDelivered
        GR->>RDB: ServiceStatus NotDelivered
    end
    GR->>RDB: I45 Verified = true
    GR->>SVC: I46 HttpClient POST original bytes, original Content-Type and SOAPAction, timeout 120 s
    SVC-->>GR: I47 SOAP reply
    alt RETURN_CODE 0 or HTTP 202
        GR->>ADB: I48 Reply Done - HTTP status, FC2FMS's answer byte for byte
        GR->>RDB: I48 Done, DownstreamResult RETURN_CODE=0
    else RETURN_CODE not 0, SOAP fault, HTTP 4xx, 3xx, 501, 505
        GR->>ADB: I48 Reply Refused with the answer
        GR->>RDB: I48 Refused, ServiceHttpStatus, DownstreamResult = the service's error
    else may have arrived: no answer after sending, reset, 500, 502, 503, 504, unreadable 2xx
        GR->>ADB: I48 Reply Unknown
        GR->>RDB: I48 Unknown - may have been processed, never posted again
    else nothing sent: DNS, refused, connect timeout 15 s, TLS, 408, 429
        GR->>RDB: I48 Retrying, NextAttemptUtc = now + 30 s x 2^(n-1), max 30 min, no Reply yet
        Note over GR,ADB: after 8 tries - Reply NotDelivered, then the row NotDelivered
    end
    GR->>RDB: I49 ReceiptWorker reads ReceiptDueUtc (set when the row arrived)
    GR->>ADB: I49 Receipt (CorrelationId = the arrived message), then clear ReceiptDueUtc
    Note over ADB: PLANNED - the DMZ QrDiode Sender airs Replies and Receipts on lane 1 like any row; the Corp gateway reads them with AnswerReader (built, step 10a)
```

### 2.1 Corp gateway receives the call ✅

| # | Step | Class | If it goes wrong |
|---|---|---|---|
| I1 | Rapid Restore calls the FC2FMS WCF service exactly as it always does: same URL, same operation, same message. It does not know the network is islanded. | — | — |
| I2 | The corporate load balancer sends the call to the Corp gateway instead of the real service. | — | — |
| I3 | The gateway accepts the call, whatever the URL, and hands it on untouched. | [SenderSoapController](../../src/QrBridge.Gateway/Controllers/SenderSoapController.cs) → [SenderEndpoint](../../src/QrBridge.Gateway/Ingress/SenderEndpoint.cs) | — |
| I4 | It reads the request body as raw bytes (`byte[]`), exactly as sent. Larger than 1 MB is refused. | `SenderEndpoint` | Caller gets an error: "request too large" |
| I5 | It reads the request safely to learn the SOAP version, the operation (`SendToFMS`) and the message inside. Dangerous XML tricks are blocked. | [SoapRequest](../../src/QrBridge.Gateway/Ingress/Soap/SoapRequest.cs) | Caller gets an error: "not a valid SOAP request" |
| I6 | It looks up the URL + operation in `routes.json`: **send it across** (`Bridge`), **send it across and hold the caller for the real answer** (RoundTrip, step 10a), **answer it here** (Echo / Unavailable) or **refuse** (Reject). `FC2FMS.SendToFMS` = RoundTrip with `OnHoldTimeout: Pending` (since step 10c, D60: a permit waits for FMS's real answer). | [RouteTable](../../src/QrBridge.Gateway/Routing/RouteTable.cs) | Caller gets an error: "not a bridged service" |
| I7 | It reads the message type inside the message (`REQUEST_FOR_PERMIT`). Read only; nothing is changed. | [PayloadInspector](../../src/QrBridge.Gateway/Ingress/Soap/PayloadInspector.cs) | — |
| I8 | If the route says "answer it here", it replies now and stores nothing. Example: an XA/21 poll gets a SOAP fault "not available". A RoundTrip call such as this `SendToFMS` or a `GetFromFMS` goes through I9–I12 like `Bridge`, then its caller is held (I13). | `SenderEndpoint` | — |
| I9 | **Contract check:** it compares the request with the FC2FMS WSDL: right SOAP version, right SOAPAction (when sent), operation exists, the message has the fields the service expects. | [ContractCatalog](../../src/QrBridge.Gateway/Ingress/Validation/ContractCatalog.cs), [ServiceContract](../../src/QrBridge.Gateway/Ingress/Validation/ServiceContract.cs) | Caller gets an error saying what does not match. Nothing is stored. |
| I10 | **Allowed types:** `REQUEST_FOR_PERMIT` must be in `SendToFMS`'s allowed list in `routes.json`. | `SenderEndpoint` | Caller gets code 1597 "message type not allowed" |
| I11 | It writes a small header: service, operation, URL path, original SOAPAction and Content-Type, message type, content fingerprint, and `ExpiresUtc` = now + `Gateway:Expiry` (600 s, D62; a query: now + its hold). The DMZ side needs it to repeat the call exactly, and does not post it after `ExpiresUtc`. | `SenderEndpoint` | — |
| I12 | It saves the header + original bytes in the Outbox (2.2). A retry with the same content within 30 min is attached to the first message instead (D56), unless that one surely was not done (Expired, NotDelivered, Rejected): then it is a new message (D63). | [OutboxWriter](../../src/QrBridge.Gateway/Ingress/OutboxWriter.cs) | Queue full → code 1598 "try later". Save failed → error "not accepted, retry". |
| I13 | **Only after the save succeeds**, it **holds** Rapid Restore (up to `Gateway:Hold`, 270 s on Corp) and re-reads the Outbox row every 2 s or when `AnswerReader` wakes it. When the DMZ Reply comes back (I48, carried 🔶, read ✅), Rapid Restore gets FMS's own answer byte for byte; when the hold runs out, `RETURN_CODE 1596` "sent over the QR bridge, confirmation not yet received". | `SenderEndpoint.HoldAsync`, [SoapReplyWriter](../../src/QrBridge.Gateway/Ingress/Soap/SoapReplyWriter.cs) | Hold runs out or the row's light status is `Failed` → 1596. Caller hangs up → the message stays queued |

Until step 10c this call was `Bridge` and got `RETURN_CODE 0` at once, which only meant "saved", not "FMS processed
it". Now Rapid Restore gets FMS's own answer when it comes back in time, and an honest 1596 otherwise; a retry gets
the first message's answer. Until the QR apps carry messages 🔶, it always gets 1596 after 270 s (accepted by Rowshan).
Feeds such as `FTC2FMS.SendToFMS` stay `Bridge`: `RETURN_CODE 0` at once.

### 2.2 Corp gateway saves the call in the Outbox (`qrbridge.db`) ✅

All in [OutboxWriter](../../src/QrBridge.Gateway/Ingress/OutboxWriter.cs), the only code that writes to the Outbox.

| # | Step | If it goes wrong |
|---|---|---|
| I14 | Checks the queue: if 5,000 Requests are already waiting (`Kind = Request`, `LightStatus` `Pending` + `Sending` + `Aired`), it refuses. Receipts and Replies are not counted and never refused (D47). | Caller gets 1598 "try later" |
| I15 | Gives the message a new **MessageId** (GUID). The same id follows it into the DMZ Inbox. | — |
| I16 | Starts a database transaction: everything below is saved together or not at all. | — |
| I17 | Takes the next **sequence number** for Corp → DMZ (1, 2, 3…) and the counter's **run id**, in one SQL statement so two calls never get the same number. The run id is set on the counter's first use and never changes (D27); with the catalogue fingerprint (D31) it goes into the header. | — |
| I18 | Packs header + original request into **MessageBytes**: request compressed, never edited, not encrypted (QrDiode encrypts). Layout in §5.2. | — |
| I19 | Computes **MessageHash** = SHA-256 of MessageBytes. | — |
| I20 | Inserts one Outbox row with `LightStatus = Pending` and `ServiceStatus = Waiting` (columns in §5.1). | — |
| I21 | Commits. The message is now safe on disk. | Nothing saved; caller told "not accepted, retry" |
| I22 | Rings the `Corp.Outbox` doorbell to wake the QrDiode Sender. | Sender still finds it within 2 s |
| I23 | Returns the MessageId; step I13 holds Rapid Restore for the answer. | — |

### 2.3 Corp QrDiode Sender shows it on screen ✅ (Bridge mode, 27 Nov 2026; not tried on a real screen)

| # | Step | Where | Status |
|---|---|---|---|
| I24 | At start-up, rows left in `Sending` by a crash go back to `Pending`. | `OutboxRepository.ResetSendingAsync` | ✅ method exists |
| I25 | Waits for the `Corp.Outbox` doorbell, or checks every 2 s. | `BridgeSignal.WaitAsync` (in `OutboxSource`) | ✅ |
| I26 | When nothing else is waiting to go on screen, takes `Pending` rows (up to 50 messages / 128 KB) and marks them `Sending`: Receipts, Replies and Heartbeats first, then the priority classes High (permits, orders, cards), Normal (queries), Low (feeds), lowest sequence within a class (✅ in `OutboxRepository.ClaimNextAsync` since step 14, D73: the Sender needs no change for it). Only rows still `Pending` can be taken, so a row is never taken twice. Strict order: it stops at the first row that does not fit (decision 52). | `OutboxRepository.ClaimBundleAsync` | ✅ |
| I27 | Puts their MessageBytes together in one bundle file `bundle-{min}-{max}.qbb`, with the bundle id. | `BundleCodec`, `OutboxBundler` | ✅ |
| I28 | Compresses the bundle, **encrypts it so only the DMZ Receiver can open it**, and **signs it with the Corp Sender's key** (ECDH P-256 + AES-256-GCM, ECDSA P-256 signature). Uses a fresh counter so an old recording can't be replayed. | [SendSession](../../../qrdiode/src/QrDiode.Core/Pipeline/SendSession.cs) | ✅ |
| I29 | Cuts it into small pieces with a fountain code: the camera can rebuild the bundle from *enough* pieces, even if it misses some. | `LtEncoder` | ✅ |
| I30 | Shows the pieces as QR codes on screen, in a loop: at least 3 loops and 6 s, then a 1.5 s pause. A signed summary (manifest) is shown every 20 frames. | [TransmitEngine](../../../qrdiode/src/QrDiode.Sender/Transmit/TransmitEngine.cs) | ✅ |
| I31 | Marks the rows `Aired` with the QR session id (`TransmitEngine.ItemFinished` → `OutboxSource`). If the session was skipped → back to `Pending` at once; if encoding failed → `Pending` after ~30 s; after too many airs the gateway sets `Failed` for an operator (reason in `LightComment`). | `MarkAiredAsync` / `ReleaseBundleAsync` | ✅ |

There is no answer over the light yet: the Corp side cannot know whether the DMZ side read it. That is why the Sender
airs each session several times. The DMZ gateway already writes a Receipt for every arrived message (I49 ✅), and the
Corp gateway reads arriving Receipts ✅ (`AnswerReader`, tracker step 10a), but carrying them back over the light is
planned 🔶 (QrDiode work).

### 2.4 DMZ QrDiode Receiver reads the screen and saves in the Inbox (`qrbridge.db`) ✅ (Bridge mode, 27 Nov 2026; not tried with a real camera)

| # | Step | Where | Status |
|---|---|---|---|
| I32 | The camera reads QR codes. Each one has a checksum (CRC-32); damaged or foreign codes are ignored. | [QrDecodePipeline](../../../qrdiode/src/QrDiode.Receiver/Capture/QrDecodePipeline.cs) | ✅ |
| I33 | On the manifest, it checks: signed by the trusted Corp Sender, addressed to this DMZ Receiver, not a replay. | [ReceiveEngine](../../../qrdiode/src/QrDiode.Core/Pipeline/ReceiveEngine.cs) | ✅ |
| I34 | Checks each piece's MAC (protocol v2: a piece from anyone but the Sender is dropped), then collects pieces until the whole bundle is rebuilt. | `FrameMac`, `LtDecoder` | ✅ |
| I35 | Checks the signed ciphertext hash, decrypts (fails if any byte was changed), decompresses to exactly the declared size. | `ReceiveEngine` | ✅ |
| I36 | Opens the bundle and reads each message's header (without unpacking the body). Each must say `CorpToDmz`. | `InboxBundleWriter` (`BundleCodec`, `MessageSerializer.PeekHeader`) | ✅ |
| I37 | Inserts all messages into the Inbox **in one transaction**: same MessageId, same MessageBytes, MessageHash recomputed, `LightStatus = Received`, `ServiceStatus = Pending`, `ReceiptDueUtc` = now (a Receipt is owed). A message already there is skipped, so a re-aired bundle is never stored twice, but it is owed a Receipt again (the first one was lost). Receipts, Replies and Heartbeats from the Corp side are stored the same way (a Receipt or Heartbeat is never owed a Receipt). | `InboxRepository.AddMessagesAsync` | ✅ |
| I38 | Only now records the session as received for anti-replay, so a crash between I35 and I37 can't lose a session. | `engine.CommitReplay()` | ✅ (after the Inbox transaction, `HandleBundleAsync`) |
| I39 | Rings the `Dmz.Inbox` doorbell to wake the DMZ gateway. | `BridgeSignals.Inbox` (in `InboxBundleWriter`) | ✅ |

Fixed 26 Nov 2026: if the camera misses part of one session, a newer verified session now replaces it (the Receiver
shows "Incomplete — must be re-sent"; known issue 1). Since QrDiode protocol v2 (same day) every data frame carries a
MAC, so a QR code someone holds up to the camera (I32) is dropped before I34.

### 2.5 DMZ gateway calls FC2FMS with HttpClient ✅

All in [InboxWorker](../../src/QrBridge.Gateway/Egress/Workers/InboxWorker.cs) (background loop inside the DMZ gateway) and
[SoapForwarderHttpClient](../../src/QrBridge.Gateway/Egress/SoapForwarderHttpClient.cs). One delivery loop per priority
class (High, Normal, Low; step 14, D73), each one message at a time, in order.

| # | Step | If it goes wrong |
|---|---|---|
| I40 | Wakes on the `Dmz.Inbox` doorbell (it wakes one loop; the others poll), or every 2 s. | — |
| I41 | The loop for the row's class (`FC2FMS.SendToFMS` with 1596: High) takes the next row of its class that arrived intact (`LightStatus` `Received`) and waits for delivery (`ServiceStatus` `Pending`, or `Retrying` and due) — by run of the Corp counter, then sequence — and marks it `Delivering`. Not while an earlier FC2FMS High request is `Retrying` (strict order per service, D74). Only one loop can take a row. | — |
| I42 | Unpacks MessageBytes: checks the checksum, decompresses → header + the **exact original request bytes**. | `LightStatus` `Rejected`, reason in `LightComment` (never retried) |
| I43 | Checks the header matches the row (run id included), the Corp side ran the same `routes.json` (catalogue fingerprint, D31), the direction is `CorpToDmz`, and it is not older than 7 days or dated in the future ([ArrivalChecks](../../src/QrBridge.Gateway/Egress/ArrivalChecks.cs), shared with `AnswerReader` since step 10a). On the row's **first** check only (step 17, D84): its number (direction + run + sequence) is not already held by another message that arrived earlier, and is not at or below the run's `SequenceWatermark` with no row holding it (an old message shown again after its row was archived). All passed → the row is marked `Verified`. | `Rejected` ("already used", or "an old message shown again", whatever its date) |
| I44 | Checks the DMZ copy of `routes.json`: `FC2FMS` has callers on Corp and `SendToFMS` is RoundTrip (`Bridge` and RoundTrip operations are both delivered). Then the expiry: past its `ExpiresUtc` → not posted, `Expired` (table below). | `Rejected` |
| I45 | Finds the URL **from DMZ configuration only**, never from the message: `Targets[FC2FMS]`, else `DefaultBaseUrl` + original path → `https://dmz-rr-server/FMS_FC2FMSInterface/FC2FMSInterface.svc`. | No URL configured → `ServiceStatus` `NotDelivered` (D25) |
| I46 | **HttpClient POST** of the original bytes with the original Content-Type and SOAPAction. To FC2FMS it looks like Rapid Restore's own call. Only exception: a WS-Addressing `To` header (if present) is pointed at the real URL. Timeout 120 s, redirects not followed. Credentials: the app pool identity or anonymous, per target (`UseDefaultCredentials`, D75). The log line names the caller (`CallerHost`, e.g. "from 10.1.2.3 (via 10.0.0.9)"), never the payload. | see table below |
| I47 | Reads FC2FMS's reply: SOAP fault? `RETURN_CODE`? | see table below |
| I48 | **First** writes a **Reply** into the DMZ Outbox (through `OutboxWriter`, [AnswerWriter](../../src/QrBridge.Gateway/Egress/AnswerWriter.cs)): `Kind = Reply`, `CorrelationId` = this message, the outcome, HTTP code, reason and FC2FMS's answer byte for byte (left out, and said so, when larger than 1 MB). **Then** saves the outcome on the row: `ServiceStatus`, the HTTP code in `ServiceHttpStatus`, a plain-words reason in `ServiceComment`, and FC2FMS's answer in `DownstreamResult` (e.g. `RETURN_CODE=0`). Every final outcome gets a Reply, Rejected included; `Retrying` does not (yet). | Reply could not be written → logged, the row is still marked |
| I49 | [ReceiptWorker](../../src/QrBridge.Gateway/Egress/Workers/ReceiptWorker.cs), every 2 s, separately from I40–I48: writes a **Receipt** (`Kind = Receipt`, `CorrelationId` = the arrived message, empty body) into the DMZ Outbox for every row with `ReceiptDueUtc` set, then clears it. A Receipt never gets a Receipt. The Replies and Receipts then wait for the DMZ QrDiode Sender like any Outbox row 🔶. | A crash in between → the same Receipt is sent twice (harmless) |

| FC2FMS answered | Inbox `ServiceStatus` | Next |
|---|---|---|
| `RETURN_CODE=0` (or HTTP 202 for one-way) | `Done` | Kept: rows are never deleted automatically (D28); an operator archives them. Its body (`MessageBytes`) is cleared; `MessageHash` stays (D77) |
| `RETURN_CODE≠0` (FMS refused the message) | `Refused` | Operator reads `ServiceComment` / `DownstreamResult`, fixes, requeues |
| SOAP fault, HTTP 4xx (not 408/429), 3xx, 501, 505 | `Refused` | Operator |
| 2xx, but the expected result can't be read | `Unknown` | Operator checks with FMS whether it was processed; never retried on its own |
| **May have arrived:** no answer within 120 s after sending, connection reset, HTTP 500, 502, 503, 504 (or another 5xx) | `Unknown` | Operator checks with FMS first (D9: re-posting is how duplicate permits happen) |
| **Nothing sent:** name not resolved, connection refused, no connection within 15 s, TLS failure, HTTP 408, 429 | `Retrying` | Retried after 30 s, 1 min, 2 min… (max 30 min); after 8 tries → `NotDelivered` (D25: an operator may resend). A round-trip **query** is not retried: `NotDelivered` at once, its caller is waiting (step 10b). While it is `Retrying`, later requests of the same service and class wait (D74) |
| Past its `ExpiresUtc` (a permit 600 s after it was sent, D62; a query after its hold, D54) | `Expired` | Not posted; the Reply says so, and a caller still held gets "not available" |
| DMZ gateway stopped during the POST | `Unknown` (with an Unknown Reply) | Operator (D41); stopped **before** the POST → back to `Pending`, the try not counted |
| Found still `Delivering` after a crash (after 5 min) | the outcome of the Reply written for this attempt, if there is one (D64: not one from before an operator's requeue), else `Unknown` with an Unknown Reply (D46) | Never posted again; operator for `Unknown` |

On routes that recognise retries (by default RoundTrip routes with a 1596 hold-timeout answer, `SendToFMS` included since step 10c), before
I46 the worker also looks for the **same content** that arrived within 30 min (step 10b, D58): if that one is `Done`,
this one is not posted and ends `Done` with the earlier Reply's answer; if it is `Unknown` or still `Delivering`, this
one is not posted and ends `Unknown`; after `Refused`, `NotDelivered` or `Expired` it is posted normally.

### 2.6 End state

| Where | What you see |
|---|---|
| Rapid Restore | Held (I13); gets FMS's answer (e.g. `RETURN_CODE 0`) once the DMZ Reply is back. Today, with nothing carried over the light 🔶, `RETURN_CODE 1596` after 270 s |
| Corp Outbox | Row light `Aired` 🔶 (today stays `Pending`: no QR Sender connection yet), service `Waiting` until the DMZ Reply is carried back 🔶 and read ✅ (`AnswerReader`, tracker step 10a; it then becomes `Answered` or `Refused` and light `Received`) |
| DMZ Inbox | Row light `Received`, service `Done` with `RETURN_CODE=0`, or `Refused` with FMS's error message; `ReceiptDueUtc` cleared |
| DMZ Outbox | A Reply (outcome + FMS's answer) and a Receipt for the message, light `Pending` until the DMZ QrDiode Sender airs them 🔶 |
| Both | Same MessageId and MessageHash → proof the same bytes arrived |

---

## 3. Outbound — DMZ → Corp

**Example:** FMS issues an order to Rapid Restore SSO: operation `IssueOrder` on `/FMSRRInterface/FMS2SSOInterface.svc`,
message type `ISSUE_ORDER`, caller `FMS_FMS2SSOService`.

| | DMZ machine (sender) | Corp machine (receiver) |
|---|---|---|
| Who | Caller: FMS outbound service `FMS_FMS2SSOService` | Real service: `FMS2SSOInterface.svc` on the Rapid Restore server |
| How the call arrives | FMS client's endpoint URL is changed to the DMZ gateway (configuration only) | — |
| Gateway settings | `appsettings.Dmz.json`: `Bridge:Side = Dmz` | `appsettings.Corp.json`: `Side = Corp`, `Receiver:DefaultBaseUrl` / `Targets` (**empty today — to fill in**) |
| Route in `routes.json` | `FMS2SSO`, `SenderSide: Dmz` | same file, same entry |
| WSDL used for the check | `Contracts/Outbound/FMS2SSO/` (built from the client proxy; replace with the real WSDL when captured) | — |
| Database | `qrbridge.db` → `Outbox` | `qrbridge.db` → `Inbox` |
| Doorbell | `Global\QrBridge.Dmz.Outbox` | `Global\QrBridge.Corp.Inbox` |
| QrDiode app | Sender (screen) | Receiver (camera) |

### 3.0 Outbound sequence diagram

```mermaid
sequenceDiagram
    box transparent DMZ machine
        participant FMS as FMS_FMS2SSOService
        participant GS as DMZ Gateway Sender part
        participant SDB as DMZ qrbridge.db - Outbox
        participant QS as DMZ QrDiode Sender
    end
    box transparent Corp machine
        participant QR as Corp QrDiode Receiver
        participant RDB as Corp qrbridge.db - Inbox
        participant GR as Corp Gateway Receiver part
        participant SVC as Rapid Restore SSO FMS2SSOInterface.svc
        participant ADB as Corp qrbridge.db - Outbox - Replies and Receipts
    end

    FMS->>GS: O1-O2 POST /FMSRRInterface/FMS2SSOInterface.svc IssueOrder (endpoint URL now points to the DMZ gateway)
    GS->>GS: O3-O4 read body as byte[] (max 1 MB)
    break body over 1 MB
        GS-->>FMS: SOAP fault HTTP 413, nothing stored
    end
    GS->>GS: O5 SoapRequest.TryParse through SafeXml
    break not a SOAP 1.1 or 1.2 request
        GS-->>FMS: SOAP fault HTTP 400, nothing stored
    end
    GS->>GS: O6 RouteTable.Resolve(path, IssueOrder) = RoundTrip
    GS->>GS: O7 PayloadInspector reads TYPE = ISSUE_ORDER
    break route is Echo, Unavailable or Reject
        GS-->>FMS: O8 echo, RETURN_CODE 1599 or SOAP fault, nothing stored
    end
    GS->>GS: O9 ContractCatalog.Check against Contracts/Outbound/FMS2SSO
    break request does not match the WSDL
        GS-->>FMS: SOAP fault naming the mismatch, nothing stored
    end
    GS->>GS: O10 AllowedTypes of IssueOrder contains ISSUE_ORDER
    break type not allowed
        GS-->>FMS: RETURN_CODE 1597, nothing stored
    end
    GS->>GS: O11 build MessageHeader, ExpiresUtc = now + 600 s
    GS->>SDB: O14 COUNT Outbox Requests, LightStatus Pending, Sending or Aired
    break 5000 or more waiting
        GS-->>FMS: RETURN_CODE 1598, nothing stored
    end
    GS->>SDB: O16 BEGIN transaction
    GS->>SDB: O17 UPDATE SequenceCounter DmzToCorp RETURNING LastValue, RunId
    GS->>GS: O18-O19 MessageBytes = Serialize(header, body), MessageHash = SHA-256
    GS->>SDB: O20 INSERT Outbox row, Direction DmzToCorp, LightStatus Pending, ServiceStatus Waiting
    GS->>SDB: O21 COMMIT
    GS--)QS: O22 SetEvent Global\QrBridge.Dmz.Outbox
    GS-->>FMS: O13 held up to 90 s - SSO's answer from the Corp Reply, else RETURN_CODE 1596 - header X-QrBridge-MessageId

    rect rgba(255,193,7,0.12)
        Note over SDB,RDB: PLANNED O24-O39 - QrDiode is not connected to the database yet
        QS->>SDB: O26 claim Pending rows - answers first, then High, Normal, Low, by Sequence (max 50 or 128 KB), set Sending
        QS->>QS: O27 pack rows into bundle-firstSeq-lastSeq.qbb
        QS->>QS: O28 SendSession.Create - encrypted for the Corp Receiver, signed by the DMZ Sender
        QS->>QS: O29 LT fountain encode
        loop O30 at least 3 x K frames and at least 6 s, 15 fps
            QS-)QR: QR frame - manifest every 20 frames, otherwise one data symbol
        end
        QS->>SDB: O31 rows LightStatus Aired (skipped - Pending now, encode error - Pending after 30 s)
        QR->>QR: O32-O35 CRC-32, manifest signature and anti-replay, LT decode, decrypt, hashes
        QR->>QR: O36 BundleCodec.Parse, PeekHeader each message, Direction must be DmzToCorp
        QR->>RDB: O37 BEGIN, INSERT each message (skip existing MessageId), COMMIT
        QR->>QR: O38 CommitReplay only after the Inbox commit
        QR--)GR: O39 SetEvent Global\QrBridge.Corp.Inbox
    end

    GR->>RDB: O41 claim lowest Sequence, LightStatus Received, ServiceStatus Pending (or Retrying and due), set Delivering, Attempts + 1
    GR->>GR: O42 Deserialize - checksum, capped Brotli
    GR->>GR: O43 header equals row, catalogue fingerprint equals this side, Direction DmzToCorp, age within 7 days, not over 60 min ahead
    GR->>GR: O44 routes.json - FMS2SSO SenderSide Dmz, IssueOrder is RoundTrip, not past ExpiresUtc
    break checksum, header or route check fails
        GR->>ADB: Reply Rejected
        GR->>RDB: LightStatus Rejected, reason in LightComment, never retried
    end
    GR->>GR: O45 URL from appsettings.Corp.json only - Targets FMS2SSO, else DefaultBaseUrl + path
    break no URL configured - TRUE TODAY, both are empty
        GR->>ADB: Reply NotDelivered
        GR->>RDB: ServiceStatus NotDelivered, no Receiver target
    end
    GR->>RDB: O45 Verified = true
    GR->>SVC: O46 HttpClient POST original bytes, original Content-Type and SOAPAction, timeout 120 s
    SVC-->>GR: O47 SOAP reply
    alt RETURN_CODE 0 or HTTP 202
        GR->>ADB: O48 Reply Done with SSO's answer byte for byte
        GR->>RDB: O48 Done, DownstreamResult RETURN_CODE=0
    else RETURN_CODE not 0, SOAP fault, HTTP 4xx, 3xx, 501, 505
        GR->>ADB: O48 Reply Refused with the answer
        GR->>RDB: O48 Refused, DownstreamResult = the service's error
    else may have arrived: no answer after sending, reset, 500, 502, 503, 504, unreadable 2xx
        GR->>ADB: O48 Reply Unknown
        GR->>RDB: O48 Unknown - may have been processed, never posted again
    else nothing sent: DNS, refused, connect timeout, TLS, 408, 429
        GR->>RDB: O48 Retrying with backoff, no Reply yet - after 8 tries Reply NotDelivered, then NotDelivered
    end
    GR->>ADB: O49 ReceiptWorker - Receipt for the arrived message, then clear ReceiptDueUtc
```

### 3.1 DMZ gateway receives the call ✅

| # | Step | Class | If it goes wrong |
|---|---|---|---|
| O1 | FMS calls the FMS2SSO WCF service exactly as it always does: same path, operation and message. | — | — |
| O2 | Because its endpoint URL was changed, the call goes to the DMZ gateway instead of Rapid Restore. | — | — |
| O3 | The gateway accepts the call and hands it on untouched. | [SenderSoapController](../../src/QrBridge.Gateway/Controllers/SenderSoapController.cs) → [SenderEndpoint](../../src/QrBridge.Gateway/Ingress/SenderEndpoint.cs) | — |
| O4 | Reads the request body as raw bytes (`byte[]`). Larger than 1 MB is refused. | `SenderEndpoint` | Error: "request too large" |
| O5 | Reads the request safely: SOAP version, operation (`IssueOrder`), message inside. | [SoapRequest](../../src/QrBridge.Gateway/Ingress/Soap/SoapRequest.cs) | Error: "not a valid SOAP request" |
| O6 | Looks up URL + operation in `routes.json`: `FMS2SSO.IssueOrder` = RoundTrip with `OnHoldTimeout: Pending` (since step 10c, D60: an order waits for SSO's real answer). A Corp-side service called on the DMZ gateway is refused here. | [RouteTable](../../src/QrBridge.Gateway/Routing/RouteTable.cs) | Error: "not a bridged service" |
| O7 | Reads the message type inside (`ISSUE_ORDER`). Read only. | [PayloadInspector](../../src/QrBridge.Gateway/Ingress/Soap/PayloadInspector.cs) | — |
| O8 | If the route says "answer it here", replies now and stores nothing (e.g. a poll such as XA/21 `DISPLAY_POLL` → SOAP fault). A `RoundTrip` route (this `IssueOrder`, or `FMS2FC.PortalSyncRequest`) is stored like `Bridge` and its caller held for the far side's Reply (O13); when the hold runs out → 1596, or for `PortalSyncRequest` 1599 with an empty `GMT_TIME_STAMP` (step 10a). Feeds (`FMS2FSS`, `FMS2Dashboard`, `FMS2SSLog`, `FMS2VR`) stay `Bridge`: answered at once. | `SenderEndpoint` | — |
| O9 | **Contract check** against the FMS2SSO WSDL. | [ContractCatalog](../../src/QrBridge.Gateway/Ingress/Validation/ContractCatalog.cs), [ServiceContract](../../src/QrBridge.Gateway/Ingress/Validation/ServiceContract.cs) | Error saying what does not match. Nothing stored. |
| O10 | **Allowed types:** `ISSUE_ORDER` must be allowed for `IssueOrder`. | `SenderEndpoint` | Code 1597 |
| O11 | Writes the small header (service, operation, path, SOAPAction, Content-Type, message type, content fingerprint, `ExpiresUtc` = now + `Gateway:Expiry`, 600 s, D62). | `SenderEndpoint` | — |
| O12 | Saves header + original bytes in the DMZ Outbox (3.2); a retry with the same content within 30 min is attached to the first message (D56, D63 as in I12). | [OutboxWriter](../../src/QrBridge.Gateway/Ingress/OutboxWriter.cs) | Queue full → 1598. Save failed → "not accepted, retry". |
| O13 | **Only after the save**, **holds** FMS (up to `Gateway:Hold`, 90 s on the DMZ, below the FMS clients' 100 s timeout) for the Corp Reply: SSO's own answer byte for byte when it comes back in time, else `RETURN_CODE 1596`. | `SenderEndpoint.HoldAsync`, [SoapReplyWriter](../../src/QrBridge.Gateway/Ingress/Soap/SoapReplyWriter.cs) | Hold runs out → 1596 |

### 3.2 DMZ gateway saves the call in the Outbox (`qrbridge.db`) ✅

Same code as 2.2, on the DMZ machine's own `qrbridge.db`.

| # | Step | If it goes wrong |
|---|---|---|
| O14 | Checks the queue is not full (5,000 Requests waiting; Receipts and Replies not counted). | FMS gets 1598 |
| O15 | New MessageId. | — |
| O16 | Starts a transaction. | — |
| O17 | Next sequence number and run id for **DMZ → Corp** (its own counter, separate from Corp → DMZ). | — |
| O18 | Packs header + original request into MessageBytes (compressed, never edited, not encrypted). | — |
| O19 | MessageHash = SHA-256 of MessageBytes. | — |
| O20 | Inserts the Outbox row, `Direction = DmzToCorp`, `LightStatus = Pending`, `ServiceStatus = Waiting`. | — |
| O21 | Commits. | Nothing saved; FMS told "not accepted" |
| O22 | Rings the `Dmz.Outbox` doorbell. | Found within 2 s anyway |
| O23 | Returns the MessageId; O13 holds FMS for the answer. | — |

### 3.3 DMZ QrDiode Sender shows it on screen 🔶 (QR protocol ✅)

| # | Step | Status |
|---|---|---|
| O24 | At start-up, rows stuck in `Sending` go back to `Pending`. | ✅ method exists |
| O25 | Waits for the `Dmz.Outbox` doorbell, or checks every 2 s. | ✅ method exists |
| O26 | Takes the oldest `Pending` rows (up to 50 / 128 KB) → `Sending`. | 🔶 |
| O27 | Packs them into one bundle file. | 🔶 |
| O28 | Compresses, **encrypts for the Corp Receiver only**, **signs with the DMZ Sender's key**, new counter. | ✅ |
| O29 | Cuts into fountain-code pieces. | ✅ |
| O30 | Shows them as QR codes: ≥ 3 loops and ≥ 6 s, then 1.5 s pause. | ✅ |
| O31 | Marks rows `Aired` (status exists ✅, nothing sets it yet); skipped/failed → back to `Pending`; too many tries → `Failed`. | 🔶 |

### 3.4 Corp QrDiode Receiver reads the screen and saves in the Inbox (`qrbridge.db`) 🔶 (checks ✅)

| # | Step | Status |
|---|---|---|
| O32 | Camera reads QR codes; damaged or foreign codes are ignored (CRC-32). | ✅ |
| O33 | Manifest checks: signed by the trusted DMZ Sender, addressed to this Corp Receiver, not a replay. | ✅ |
| O34 | Collects pieces until the bundle is rebuilt. | ✅ |
| O35 | Hash, decrypt, decompress with cap, hash again. | ✅ |
| O36 | Opens the bundle; each message header must say `DmzToCorp`. | 🔶 |
| O37 | Inserts all into the Corp Inbox in one transaction, `LightStatus = Received`, `ServiceStatus = Pending`; duplicates skipped. | 🔶 |
| O38 | Records the session for anti-replay only after the save. | 🔶 |
| O39 | Rings the `Corp.Inbox` doorbell. | 🔶 |

### 3.5 Corp gateway calls FMS2SSO with HttpClient ✅

| # | Step | If it goes wrong |
|---|---|---|
| O40 | Corp InboxWorker wakes on the `Corp.Inbox` doorbell, or every 2 s (one loop per priority class). | — |
| O41 | The loop of the row's class (`FMS2SSO.IssueOrder`: High) takes the next `Received` row of its class whose `ServiceStatus` is `Pending` (or `Retrying` and due) → `Delivering`; same order rules as I41. | — |
| O42 | Unpacks MessageBytes: checksum, decompress → header + original bytes. | `Rejected` |
| O43 | Header matches the row, same catalogue fingerprint as the Corp side, direction is `DmzToCorp`, date within 7 days / not in the future; on the first check, its number not reused or old (as I43), then `Verified`. | `Rejected` |
| O44 | Corp `routes.json`: `FMS2SSO` has callers on DMZ, `IssueOrder` is RoundTrip; then the expiry (past `ExpiresUtc` → `Expired`, not posted). | `Rejected` |
| O45 | URL **from Corp configuration only**: `Targets[FMS2SSO]`, else `DefaultBaseUrl` + `/FMSRRInterface/FMS2SSOInterface.svc`. **Both empty today.** | `NotDelivered` "no Receiver target" until configured |
| O46 | **HttpClient POST** of the original bytes, original Content-Type and SOAPAction, to Rapid Restore SSO. Timeout 120 s. Windows authentication (the app pool identity) if `UseDefaultCredentials` is on, globally or for this target (`Targets:FMS2SSO:UseDefaultCredentials`, D75). | see 2.5 table |
| O47 | Reads SSO's reply (`RETURN_CODE` / fault). | see 2.5 table |
| O48 | **First** a Reply into the Corp Outbox (outcome, HTTP code, reason, SSO's answer byte for byte), **then** the outcome on the row with SSO's answer in `DownstreamResult`: `Done`, `Refused`, `Unknown` or `NotDelivered` — same rules as the 2.5 table. `Retrying` gets no Reply yet. | — |
| O49 | `ReceiptWorker` writes a Receipt for the arrived message into the Corp Outbox. | — |

### 3.6 End state

| Where | What you see |
|---|---|
| FMS | Held (O13); gets SSO's answer once the Corp Reply is back. Today `RETURN_CODE 1596` after 90 s (nothing carried over the light 🔶, and no Corp Receiver target) |
| DMZ Outbox | Row light `Aired` 🔶, service `Waiting` |
| Corp Inbox | Row service `Done`, or `Refused` with SSO's error message (today `NotDelivered`: no Corp Receiver target) |
| Corp Outbox | A Reply (today `NotDelivered`) and a Receipt for the message, light `Pending` until the Corp QrDiode Sender airs them 🔶 |
| Both | Same MessageId and MessageHash |

---

## 4. Shared logic in detail

Both directions run this same code. Only the side's configuration differs.

### 4.1 Gateway Sender part — every decision and reply

[SenderEndpoint](../../src/QrBridge.Gateway/Ingress/SenderEndpoint.cs), [RouteTable](../../src/QrBridge.Gateway/Routing/RouteTable.cs),
[OutboxWriter](../../src/QrBridge.Gateway/Ingress/OutboxWriter.cs). Every red end means **nothing is stored**.

```mermaid
flowchart TD
    A["POST to any path<br/>SenderSoapController"] --> B["Read body as byte[]"]
    B --> B1{"Body over MaxPayloadBytes 1,000,000<br/>or the route's smaller MaxRequestBytes?"}
    B1 -- yes --> R413["SOAP 1.1 fault, HTTP 413"]
    B1 -- no --> C["SoapRequest.TryParse<br/>SafeXml: no DTD, no resolver, character cap"]
    C --> C1{"SOAP 1.1 or 1.2 envelope<br/>with an operation in the Body?"}
    C1 -- no --> R400["SOAP fault, HTTP 400"]
    C1 -- yes --> INS["PayloadInspector: MESSAGE TYPE and MSG_ID<br/>read only, for routing, allow-list and reply text"]
    INS --> D["RouteTable.Resolve(path, operation, type)"]
    D --> D1{"Path listed in routes.json?"}
    D1 -- "no, AcceptUnlisted = false" --> RREJ["SOAP fault: not bridged"]
    D1 -- "no, AcceptUnlisted = true" --> E
    D1 -- yes --> D2{"Service SenderSide =<br/>this gateway's Side?"}
    D2 -- no --> RREJ
    D2 -- yes --> D3{"Operation mode (or its MESSAGE TYPE's)<br/>listed, else OtherOperations"}
    D3 -- Reject --> RREJ
    D3 -- Echo --> RECHO["Reply: first parameter echoed back"]
    D3 -- Unavailable --> RUN["Unavailable profile: RETURN_CODE 1599<br/>or SOAP fault when no profile"]
    D3 -- "Bridge, RoundTrip" --> E{"Matches the service WSDL?<br/>ContractCatalog.Check"}
    E -- no --> RWSDL["SOAP fault naming the mismatch"]
    E -- "yes, or service has no Contract" --> F{"AllowedTypes empty<br/>or contains TYPE?"}
    F -- no --> R1597["Rejected profile: RETURN_CODE 1597<br/>or SOAP fault"]
    F -- yes --> G["OutboxWriter.EnqueueAsync"]
    G --> G1{"Outcome"}
    G1 -- "backlog at MaxBacklog 5000,<br/>or the service's own MaxBacklog" --> R1598["Busy profile: RETURN_CODE 1598<br/>or SOAP fault HTTP 503"]
    G1 -- "database error" --> RDBERR["SOAP fault: NOT accepted, retry"]
    G1 -- committed --> H0{"RoundTrip?"}
    H0 -- yes --> HOLD["Hold (Gateway:Hold): the far side's Reply<br/>= real answer byte for byte (D50),<br/>else OnHoldTimeout: 1596 or 1599"]
    H0 -- no --> H{"One-way operation?"}
    H -- yes --> R202["HTTP 202, empty body"]
    H -- no --> ROK["Ok profile: RETURN_CODE 0<br/>or empty Response element<br/>+ header X-QrBridge-MessageId"]

    classDef stop fill:#fde2e2,stroke:#c0392b
    classDef ok fill:#e2f5e2,stroke:#27ae60
    classDef local fill:#eef,stroke:#669
    class R413,R400,RREJ,RWSDL,R1597,R1598,RDBERR stop
    class R202,ROK ok
    class RECHO,RUN local
```

### 4.2 Outbox write — one transaction

```mermaid
sequenceDiagram
    participant EP as SenderEndpoint
    participant OW as OutboxWriter
    participant DB as qrbridge.db (SQLite, WAL, busy_timeout 5 s)
    participant EV as Outbox doorbell

    EP->>OW: EnqueueAsync(header, body)
    OW->>OW: MessageId = new GUID, Direction = this side's SendDirection
    OW->>DB: BEGIN
    OW->>DB: Requests only - SELECT COUNT Outbox WHERE Kind = Request AND LightStatus IN (Pending, Sending, Aired) - inside the transaction, and the same count for the service when it has its own MaxBacklog
    alt count at least MaxBacklog
        OW-->>EP: throw BridgeBacklogFullException - caller gets 1598
    end
    OW->>DB: UPDATE SequenceCounter SET LastValue = LastValue + 1, RunId = COALESCE(RunId, new run) WHERE Direction = d RETURNING LastValue, RunId
    OW->>OW: header + MessageId, Direction, Sequence, SequenceRunId, CatalogFingerprint, CreatedUtc, RawSoap, Brotli (Receipts and Replies - Priority Answer)
    OW->>OW: MessageBytes = MessageSerializer.Serialize(header, body)
    OW->>OW: MessageHash = lower-case hex SHA-256(MessageBytes)
    OW->>DB: INSERT Outbox (LightStatus Pending, ServiceStatus Waiting, PayloadSize = body length)
    OW->>DB: COMMIT
    alt any error before COMMIT
        OW-->>EP: exception - nothing stored, caller gets NOT accepted
    end
    OW->>EV: Set() - never throws, polling covers a miss
    OW-->>EP: MessageId
```

### 4.3 QrDiode — sending and receiving one session

[SendSession](../../../qrdiode/src/QrDiode.Core/Pipeline/SendSession.cs) builds the session;
[ReceiveEngine](../../../qrdiode/src/QrDiode.Core/Pipeline/ReceiveEngine.cs) checks it. Built and tested; only the
database ends are planned.

```mermaid
flowchart LR
    subgraph SEND["Sender - SendSession.Create"]
        direction TB
        P["Bundle bytes 🔶<br/>today: simulator payload or file"] --> HS["SHA-256 of plaintext"]
        HS --> Z["Brotli, kept only if smaller"]
        Z --> K["Counter reserved and flushed to disk<br/>ECDH P-256 + HKDF-SHA256, random salt"]
        K --> ENC["AES-256-GCM<br/>AAD = session id, salt, counter, key ids"]
        ENC --> MF["Manifest: session id, counter, time, sizes,<br/>both hashes, LT seed, file name<br/>signed ECDSA P-256"]
        ENC --> LT["LT fountain encoder<br/>K source symbols up to 1350 B<br/>+ coded symbols"]
        MF --> FR["Frames: OD, version, type, session tag,<br/>payload, CRC-32"]
        LT --> FR
        FR --> SCR["Carousel on screen, 15 fps<br/>manifest every 20 frames<br/>at least 3 x K frames and 6 s, then 1.5 s gap"]
    end
    SCR ==>|"light only"| CAM["Camera"]
```

```mermaid
flowchart TD
    F["QR frame from camera"] --> C1{"CRC-32 and structure OK?"}
    C1 -- no --> IGN["Ignored"]
    C1 -- yes --> T{"Frame type"}
    T -- manifest --> L{"Already locked on a session?"}
    L -- yes --> IGN1["Ignored<br/>KNOWN ISSUE 1: a NEW session is ignored too"]
    L -- no --> M1{"Signed by a sender<br/>in the trust store?"}
    M1 -- no --> REJ["Rejected"]
    M1 -- yes --> M2{"Addressed to this<br/>receiver's key?"}
    M2 -- no --> REJ
    M2 -- yes --> M3{"Session already settled?"}
    M3 -- yes --> IGN
    M3 -- no --> M4{"Anti-replay: Fresh?"}
    M4 -- no --> REJ
    M4 -- yes --> LOCK["Lock on session, start LT decoder"]
    T -- data --> D1{"Locked and session tag matches?"}
    D1 -- no --> IGN
    D1 -- yes --> D2["Add symbol to LT decoder"]
    D2 --> D3{"All K source symbols recovered?"}
    D3 -- no --> WAIT["Wait for more frames"]
    D3 -- yes --> V1{"Ciphertext SHA-256 = manifest?"}
    V1 -- no --> REJ
    V1 -- yes --> V2{"AES-GCM opens?"}
    V2 -- no --> REJ
    V2 -- yes --> V3{"Brotli within declared size and<br/>plaintext SHA-256 = manifest?"}
    V3 -- no --> REJ
    V3 -- yes --> V4{"Content gate passes?"}
    V4 -- no --> REJ
    V4 -- yes --> CR["Anti-replay committed<br/>KNOWN ISSUE 3: before the host stores it"]
    CR --> DONE["Completed - host stores the payload<br/>planned: bundle into Inbox, one transaction"]

    classDef stop fill:#fde2e2,stroke:#c0392b
    classDef warn fill:#fff3cd,stroke:#b58900
    class REJ stop
    class IGN1,CR warn
```

### 4.4 Gateway Receiver part — InboxWorker loop

[InboxWorker](../../src/QrBridge.Gateway/Egress/Workers/InboxWorker.cs) is one `BackgroundService` per gateway that runs
**one delivery loop per priority class** — High, Normal, Low (`InboxWorker.DeliveryClasses`; step 14, D73) — so a
slow or stuck feed never holds back a permit. Each loop delivers one message at a time, in order. The Inbox doorbell
wakes one loop; the others find new work at their next poll. The diagram shows one loop.

```mermaid
flowchart TD
    W["Wait: Inbox doorbell or 2 s<br/>heartbeat every 30 s"] --> CL["ClaimNextAsync(this loop's class)<br/>Kind Request, LightStatus Received, this Priority,<br/>ServiceStatus Pending, or Retrying with NextAttemptUtc due,<br/>no earlier Request of the same service and class Retrying (D74)<br/>order: sender's counter runs as they started, then Sequence<br/>conditional UPDATE to Delivering, Attempts + 1"]
    CL --> N{"Row claimed?"}
    N -- no --> W
    N -- yes --> DS{"Deserialize OK?<br/>magic, lengths, version, enums,<br/>no trailing bytes, SHA-256 checksum,<br/>Brotli within MaxPayloadBytes"}
    DS -- no --> REJ["Reply Rejected, then<br/>LightStatus Rejected - never retried<br/>reason in LightComment"]
    DS -- yes --> V{"Header MessageId, service, operation, run id = row?<br/>Catalogue fingerprint = this side's?<br/>    Direction = this side's ReceiveDirection?<br/>RawSoap or HttpGet? CreatedUtc within 7 days<br/>and at most 60 min ahead?<br/>First check only (D84): number not held by<br/>another message, not at or below the run's<br/>SequenceWatermark? All yes: mark Verified"}
    V -- no --> REJ
        V -- yes --> PL{"routes.json on THIS side:<br/>service SenderSide = other side?<br/>operation mode = Bridge or RoundTrip?<br/>HttpGet message only for the HttpGet route,<br/>SOAP message never for it<br/>unlisted only if AcceptUnlisted"}
    PL -- no --> REJ
    PL -- yes --> URL{"Target URL from configuration:<br/>Targets service Url,<br/>else DefaultBaseUrl + header Path"}
    URL -- none --> DL["Reply, then NotDelivered -<br/>no Receiver target, operator may resend"]
    URL -- found --> VER["Target found"]
    VER --> EXP{"Past ExpiresUtc?"}
    EXP -- yes --> EXPD["Reply, then Expired - not posted"]
    EXP -- no --> POST["HttpClient POST original bytes<br/>Content-Type and SOAPAction from header<br/>(HttpGet message: a GET, no body)<br/>wsa:To rewritten only if present<br/>no redirects, connect timeout 15 s,<br/>per-call timeout 120 s, reply read up to 4 MB"]
    POST --> CLS{"Classify reply<br/>HTTP code kept in ServiceHttpStatus"}
    CLS -- "SOAP fault" --> DL2["Reply with the answer,<br/>then Refused"]
    CLS -- "HTTP 202" --> DONE["Reply with the answer,<br/>then Done, body cleared (D77)"]
    CLS -- "2xx, RETURN_CODE 0 / return code 0 /<br/>no result check" --> DONE
    CLS -- "2xx, RETURN_CODE not 0" --> DL2
    CLS -- "may have arrived: 2xx result unreadable,<br/>no answer after sending, reset,<br/>500, 502, 503, 504, other 5xx" --> UNK["Reply, then Unknown -<br/>may have been processed, never posted again"]
    CLS -- "nothing sent: DNS, refused,<br/>connect timeout, TLS, 408, 429" --> FA{"Attempts at least 8?"}
    FA -- no --> FAIL["Retrying, no Reply yet<br/>NextAttemptUtc = now + 30 s x 2^(n-1), max 30 min"]
    FA -- yes --> ND["Reply, then NotDelivered -<br/>surely never sent, operator may resend"]
    CLS -- "other 4xx, 3xx, 501, 505" --> DL2
    POST -. "gateway stopping during the POST" .-> UNK
    VER -. "gateway stopping before the POST" .-> REL["Back to Pending,<br/>attempt not counted"]
    DONE --> W
    DL --> W
    DL2 --> W
    UNK --> W
    ND --> W
    EXPD --> W
    FAIL --> W
    REJ --> W
    REL --> W

    classDef stop fill:#fde2e2,stroke:#c0392b
    classDef ok fill:#e2f5e2,stroke:#27ae60
    classDef retry fill:#fff3cd,stroke:#b58900
    class REJ,DL,DL2,UNK,ND,EXPD stop
    class DONE ok
    class FAIL,REL retry
```

"Reply" in the boxes = [AnswerWriter](../../src/QrBridge.Gateway/Egress/AnswerWriter.cs) writes a Reply (`Kind = Reply`,
`CorrelationId` = this message, the outcome, HTTP code, reason, the real answer byte for byte up to 1 MB) into this
side's Outbox **before** it marks the row (D43, D45, D46). Next to this loop,
[ReceiptWorker](../../src/QrBridge.Gateway/Egress/Workers/ReceiptWorker.cs) writes a Receipt every 2 s for each arrived
row with `ReceiptDueUtc` set (Requests, Replies and Rejected rows; never for a Receipt or a Heartbeat), then clears it (D44).

### 4.5 Housekeeping

[MaintenanceWorker](../../src/QrBridge.Gateway/Egress/Workers/MaintenanceWorker.cs) (each gateway, every 60 s): settles
Inbox rows still `Delivering` after 5 min (a crash or recycle during the POST) through `AnswerWriter.RecoverStuckAsync`
— the outcome of the Reply already written for the row's current attempt (D64: a Reply from before an operator's
requeue is not used), or `Unknown` with an Unknown Reply; never posted again (D46) —
looks for messages that never arrived
([SequenceGapMonitor](../../src/QrBridge.Gateway/Egress/SequenceGapMonitor.cs), below), re-airs unconfirmed Outbox rows
✅ (step 11, below), logs warnings in two groups —
`Light: …` for Outbox `Failed`, Inbox `Rejected`, an unconfirmed Outbox message older than 30 min ("is the link
down?"; Receipt and Heartbeat rows not counted), each re-aired or failed row and each new sequence gap; `Service: …` for Inbox `Unknown`, `Refused` and `NotDelivered` — and writes
heartbeats (with the light and service counts and `missing=`). It deletes nothing (decision D28, 24 Nov 2026): rows are
kept and archived manually; never delete rows younger than `ReplayWindowDays`, and **never archive `SequenceWatermark`
or `AcknowledgedGap`** (both tiny; without the watermark an archived message shown again is no longer recognised by its
number).

**Far side** (G-16, decisions D80–D83, built 25 Nov 2026 ✅ in the gateway; carried by the QR apps 🔶): each run,
`MaintenanceWorker` calls [FarSideMonitor](../../src/QrBridge.Gateway/Egress/FarSideMonitor.cs). `SendHeartbeatIfIdleAsync`
queues a **Heartbeat** message through `OutboxWriter` when this side has queued nothing (any kind) for
`Gateway:HeartbeatMinutes` (5; 0 = off), counted from start-up at the latest — but not while an earlier Heartbeat is
still waiting to be aired (light `Pending` or `Sending`, `OutboxRepository.AnyHeartbeatWaitingAsync`): while the light is
down they would pile up and, going first, hold back real messages when it returns. `GetAsync` gives the last time anything
acceptable arrived from the far side (Inbox light `Received`, this side's receive direction; Heartbeats included), the
last Receipt, and **silent** = nothing heard for longer than `Gateway:FarSideSilentMinutes` (15), counted from start-up
until something is heard. When silent the worker logs `Light: nothing heard from the far side since … — is the light or
the far gateway down?` and `/health` turns unhealthy. Proven only with two in-memory gateways and a fake light.

**Lost messages** (G-02 "detect", decisions D27, D29, D30, built 24 Nov 2026): every message carries its sequence
number and the run id of the sender's counter. Per run, every number below the highest received that never arrived is
a gap — first numbers of a run too (a run whose first row is 5 → gap 1–4). A gap counts once the message after it
arrived `GapGraceMinutes` (5) ago, because bundles may arrive out of order; every row counts as arrived, `Rejected`
ones too. The monitor logs one warning per new gap ("Light: N message(s) from–to of sender run … never arrived …") and
keeps the result for `/health`. A gap stays until the number arrives, the sender's counter starts a new run, or an
operator acknowledges it (`InboxRepository.AcknowledgeGapAsync`, stored in `AcknowledgedGap` with who and why; no UI
yet). Since step 17 an idle side sends a Heartbeat with the next number, so a lost **last** message becomes a gap once
the Heartbeat after it arrives (within about `HeartbeatMinutes` + `GapGraceMinutes`).

**Old messages by number** (G-13, decision D84, built 25 Nov 2026): each maintenance run, `SequenceGapMonitor` also
moves up the **watermark** of each run (`InboxRepository.AdvanceSequenceWatermarksAsync`, table `SequenceWatermark`):
every number up to `ContiguousTo` arrived and was checked (`Verified` or `Rejected`) or was acknowledged as a gap. It
never goes back. On a row's first check `ArrivalChecks` rejects a number another message that arrived earlier already
holds (the sender's `qrbridge.db` restored from an old backup, or a copy) and a number at or below the watermark that no row holds (an
old message shown again after its row was archived), whatever its date. Only on the first check, because a row posted
again after a "surely not sent" failure, or requeued, may itself have moved the watermark. Not used: "lower than the
newest Done = old", because answers jump the queue (step 14) and re-airs (step 11) make lower numbers arriving later
normal.

**Re-air** (V6 fix step 11, decisions D65–D68, built 24 Nov 2026 ✅ in the gateway; carried by the QR apps 🔶): once a
minute `MaintenanceWorker` calls `OutboxRepository.ReairUnconfirmedAsync`. An Outbox row (not a Receipt or Heartbeat) still light
`Aired` `Gateway:ReceiptTimeoutSeconds` (120) after it was aired goes back to `Pending`, so the QR Sender airs it again,
lowest Sequence first (real wait 120–180 s, because the check runs once a minute). After `Gateway:MaxAirAttempts` (3)
airs in total (the `Attempts` column), it becomes light `Failed`; past its `ExpiresUtc` it becomes `Failed` at once and
is never aired again. Each change is one conditional UPDATE (only if still `Aired` and not re-aired since), so a Receipt
arriving at the same moment wins; a Receipt that arrives later still moves a `Failed` row to `Received`. A Receipt or Heartbeat row
is done once aired (neither gets a Receipt, D44, D80); a Reply row is re-aired. Safe: the far Inbox skips a
MessageId it already has and owes a new Receipt, so a re-aired Request is never posted twice. A caller's retry of a
light-`Failed` message still gets the hold-timeout answer at once (D55, D68); only an operator requeue
(`RequeueFailedAsync`, no UI) airs it again. Proven only with in-memory gateways and a fake light: nothing sets `Aired`
on real hardware yet 🔶. The effect on light capacity under load is not measured.

`GET /health` ([HealthController](../../src/QrBridge.Gateway/Controllers/HealthController.cs)): `light` and `service`
counts of both queues (every status listed, with `oldestUndeliveredUtc`; aired Receipt and Heartbeat rows are done and not counted), component heartbeats, `farSide` (`lastHeardUtc`, `lastReceiptUtc`, `silent`, `silentAfterMinutes`; step 17), `catalogFingerprint` (compare
both sides), `missingMessages`, up to 20 `gaps` and `gapsCheckedUtc` (from the last maintenance run, not queried per
probe), `lightProblems` (Outbox `Failed` + missing messages), `serviceProblems` (Inbox `Unknown` + `Refused` +
`NotDelivered`), and `healthy = no component heartbeat older than 2 min, lightProblems = 0, serviceProblems = 0, far side not silent` (D83). It is the
gateway's health probe. The only other GET answered is a route marked `"HttpGet": true` on its own side: the
Registered Tags report on Corp (V6 fix step 12, D18), carried as a round trip (the real answer, or HTTP 504). Every
other GET, and every HEAD, gets 405.

---

## 5. Database reference

### 5.1 Tables

SQLite, **one file per machine**, `qrbridge.db`, opened by the gateway and both QR apps (until 25 Nov 2026 two files, `send.db` and
`received.db`), with the tables `Outbox`, `SequenceCounter`, `Inbox`, `Heartbeat`, `AcknowledgedGap` and `SequenceWatermark`. The start is refused while a former `send.db` or `received.db` is in the data folder (they may hold undelivered messages). All writers share the file's one write lock. WAL mode (readers don't block the writer), `busy_timeout = 5 s` (a writer
waits for the lock instead of failing), `synchronous = FULL` (every commit on disk). The schema comes from EF migrations (since 27 Nov 2026; a file made
earlier is adopted with its rows). Every "take the next row" is one conditional UPDATE (Outbox `… WHERE LightStatus = 'Pending'`, Inbox `… WHERE
LightStatus = 'Received' AND ServiceStatus IN ('Pending', 'Retrying')`), so two workers can never take the same row.

Each row has **two status groups** (decision D24, built 24 Nov 2026): **light** (did it cross the light? screens,
cameras, QR apps) and **service** (what did the real service do?). An operator sees at once where a problem is.

| Column | Outbox | Inbox |
|---|---|---|
| `MessageId` (primary key) | set by the sending gateway | same value, copied from the header |
| `Direction`, `Sequence`, `SequenceRunId` | this side's direction + its counter and the counter's run id (unique index on direction + sequence) | copied from the header (index `IX_Inbox_Sequence (Direction, SequenceRunId, Sequence)`, not unique: the gap check) |
| `ServiceName`, `Operation`, `BusinessType` | e.g. `FC2FMS`, `SendToFMS`, `REQUEST_FOR_PERMIT` | same |
| `PayloadFormat` | `RawSoap`, or `HttpGet` for the plain GET Request (empty body; step 12) | same |
| `MessageBytes` | the packed message; never changed | same bytes; **emptied when the row ends `Done`** (D77, step 15: plaintext at rest), kept for every other outcome |
| `MessageHash` | SHA-256 of `MessageBytes` | recomputed on arrival |
| `LightStatus` | `Pending`, `Sending`, `Aired`, `Received`, `Failed` (`Aired`: value exists, set by the QR Sender 🔶; `Received`: set by `AnswerReader` ✅ when a Receipt or Reply is read, tracker step 10a; `Aired` → `Pending` or `Failed`: set by `MaintenanceWorker` ✅ when no Receipt comes, step 11) | `Received`, `Rejected` |
| `LightComment` | why the light status is what it is (released, aired again, out of re-air tries, expired before confirmed…) | why the message was rejected |
| `ServiceStatus` | `Waiting`, `Answered`, `Unknown`, `Refused`, `Expired`, `NotDelivered`, `Rejected` (set from the far side's Reply by `AnswerReader` ✅, step 10a; on real hardware always `Waiting` until Replies are carried 🔶; `NotAvailable` is still in the enum but never set) | `Pending`, `Delivering`, `Done`, `Retrying`, `Unknown`, `Refused`, `Expired`, `NotDelivered` (`Expired`: only when a header has an `ExpiresUtc`: round-trip queries (their hold, D54) and state-changing RoundTrip calls such as permits, orders and cards (`Gateway:Expiry`, 600 s, D62)) |
| `ServiceHttpStatus`, `ServiceComment`, `ServiceUpdatedUtc` | service group details (set when a Reply is read ✅, step 10a) | the real service's HTTP code (null if no HTTP answer), the outcome and its probable reason, when it last changed |
| `Attempts`, `LockedUtc`, `NextAttemptUtc` | claim and retry tracking | same |
| `CreatedUtc` | when the gateway accepted the call | copied from the header |
| `Kind`, `CorrelationId`, `ContentFingerprint`, `ExpiresUtc` | copies of the header fields (V6 step 5b); since step 9b the Outbox also holds this side's Receipts and Replies (`Kind` Receipt / Reply, `CorrelationId` = the message they are about), and since step 17 its Heartbeats (`Kind` Heartbeat, no `CorrelationId`) | same; must equal the header, and only `Kind = Request` is ever posted |
| `Priority` | ✅ step 14 (D73): `Answer` 0 (Receipts, Replies, Heartbeats), `High` 1, `Normal` 2, `Low` 3, stored as its number (the one enum not stored by name, so it can be ordered); the QR Sender's claim order | same; each delivery loop claims only its class |
| Own columns | `PayloadSize`, `LightUpdatedUtc`, `ReplyContentType`, `ReplyBody` (the far service's answer), `ReplyCreatedUtc` (when that Reply was written, far side's clock, D59) — set by `MarkAnsweredAsync` ✅ when a Reply is read (steps 10a, 10b) | `Verified`, `ReceivedUtc`, `DownstreamResult`, `ReceiptDueUtc` (✅ step 9b: a Receipt is owed since then; set on arrival and again when the same `MessageId` arrives twice; cleared when the Receipt is queued; never set for a Receipt or a Heartbeat). `Verified`: set by `ArrivalChecks` when every check passed (step 17; before, `InboxWorker` set it) |
| Planned 🔶 | `BundleId`, `QrSessionId` (`AiredUtc` is not needed: `LightUpdatedUtc`) | `BundleId`, `QrSessionId` |

`SequenceCounter`: one row per direction, gives the next sequence number; its `RunId` is null until the first number
is handed out, then fixed (a new or deleted `qrbridge.db` starts a new run; a restored backup keeps its run, so restore
only one whose numbers the far side has not passed). `AcknowledgedGap`: missing numbers an operator accepted as lost
(`Direction`, `SequenceRunId`, `FromSequence`, `ToSequence`, `AcknowledgedUtc`, `AcknowledgedBy`, `Reason`; key
direction + run + from). `SequenceWatermark` (step 17, D84): per `Direction` + `SequenceRunId` (key), `ContiguousTo`
and `UpdatedUtc` — every number up to `ContiguousTo` arrived and was checked or acknowledged; never archive it.
`Heartbeat`: last-seen time of each
component, shown on `/health` (not the Heartbeat **message** kind). Indexes for claiming: `IX_Outbox_LightStatus (LightStatus, Priority, Sequence)` and
`IX_Inbox_Status (LightStatus, ServiceStatus, Kind, Priority, CreatedUtc)`; for Receipts owed: `IX_Inbox_ReceiptDue (ReceiptDueUtc)`,
filtered on `ReceiptDueUtc IS NOT NULL`; for "far side last heard" (step 17): `IX_Inbox_Arrived (Direction, LightStatus, ReceivedUtc)`; for the round trip (steps 10a, 10b):
`IX_Outbox_ContentFingerprint (ContentFingerprint, CreatedUtc)`, `IX_Outbox_CorrelationId` and
`IX_Inbox_ContentFingerprint (ContentFingerprint, ReceivedUtc)`. CHECK constraints allow only the enum names in each status
column, only 0–3 in `Priority` (`CK_Outbox_Priority`, `CK_Inbox_Priority`) and only null or 100–599 in `ServiceHttpStatus`.

### 5.2 MessageBytes layout

Built by [MessageSerializer](../../src/QrBridge.Shared/Serialization/MessageSerializer.cs):

```
"BRG7" (4) | header length (4) | header | SHA-256 of header + body (32) | body length (4) | body (Brotli-compressed)
```

The body is the original request (Request), the real service's answer (Reply, may be empty) or empty (Receipt, Heartbeat).

Header ([MessageHeader](../../src/QrBridge.Shared/Serialization/MessageHeader.cs)): version (7), direction, payload format,
compression, MessageId, sequence, created time, service, operation, message type, URL path, SOAPAction header as received,
Content-Type as received; since 24 Nov 2026 (V6 review fix, step 4, header version 4) also `Kind` (Request / Receipt / Reply),
`CorrelationId`, `ContentFingerprint`, `ExpiresUtc`, `SequenceRunId` (called `SequenceEpoch` until step 6; same bytes),
`CatalogFingerprint`, `CallerHost`; and since step 9b (header version 5, decision D43) `Outcome` (Done, Refused,
Unknown, Expired, NotDelivered, Rejected), `ServiceHttpStatus` (100–599, written as an int16) and `ServiceComment`
(≤ 1,024 characters, no control characters, plain words, never the payload); and since step 14 (header version 6,
decision D73) `Priority` (one byte: `Answer` 0 for Receipts and Replies; a Request is `High` 1, `Normal` 2 or `Low` 3,
never `Answer`); since step 17 (header version 7, decision D80) no new field, but `Kind` may be `Heartbeat`. Each version adds its fields at the end.
Set and used today: `SequenceRunId`, `CatalogFingerprint`, `ContentFingerprint`, `Priority`, and for Receipts and Replies `Kind`,
`CorrelationId` and the version-5 fields; `ExpiresUtc` for RoundTrip requests (a query: now + hold, D54, step 10a; a
state-changing call: now + `Gateway:Expiry`, D62, step 10c); `CallerHost` on every request since step 15 (the first
`X-Forwarded-For` address labelled with the connection's, e.g. `10.1.2.3 (via 10.0.0.9)`, else the connection's; D76). The header is readable
without unpacking the body (`PeekHeader`). Limits: header 64 KB, names 256 characters, path / SOAPAction /
Content-Type 4,096 characters, body 1 MB after decompression, `CallerHost` 256 characters without control characters,
fingerprints exactly a SHA-256.

Rules between fields (checked on writing and reading): a **Request** names no other message, carries no outcome, and
must have a Path and Content-Type; a **Receipt** must carry the `CorrelationId` of the message that arrived and no
outcome, status or comment; a **Reply** must carry the `CorrelationId` of its Request and an `Outcome`; a **Heartbeat**
has an empty body, no `CorrelationId`, `ContentFingerprint`, `ExpiresUtc` or outcome, priority `Answer` and payload
`RawSoap` (its service / operation, set by `FarSideMonitor`, are `QrBridge` / `Heartbeat`, never a route). Receipts, Replies and Heartbeats may have an empty Path and Content-Type.
`BRG3` … `BRG6` messages are refused with a clear reason ("previous format … Delete old dev databases"); version 7
changes the bytes and the schema (CHECK on `Kind`, table `SequenceWatermark`, index `IX_Inbox_Arrived`), so delete dev
databases.

### 5.3 Outbox status flow

Light group (`LightStatus`):

```mermaid
stateDiagram-v2
    [*] --> Pending : OutboxWriter COMMIT
    Pending --> Sending : QR Sender claims - planned ClaimBundleAsync
    Sending --> Aired : session aired - status exists, planned MarkAiredAsync
    Sending --> Pending : skipped, encode error after 30 s, or Sender restart
    Sending --> Failed : too many attempts
    Failed --> Pending : operator RequeueFailedAsync
    Aired --> Received : Receipt or Reply read by AnswerReader - built step 10a
    Aired --> Pending : no Receipt after ReceiptTimeoutSeconds, tries left - MaintenanceWorker, built step 11
    Aired --> Failed : out of air tries, or expired - MaintenanceWorker, built step 11
    Failed --> Received : a Receipt that arrives late
    Received --> [*] : kept, archived manually by an operator
```

Service group (`ServiceStatus`): `Waiting` until the far side's Reply arrives. Since tracker step 10a, `AnswerReader`
moves it to `Answered`, `Unknown`, `Refused`, `Expired`, `NotDelivered` or `Rejected`; a newer Reply after an operator
requeue replaces an answer that is not `Answered` (step 10b, D59). The far side writes
Replies since step 9b ✅. Receipt, Reply and Heartbeat rows in the Outbox follow the same light flow; a Receipt or a
Heartbeat never gets a Receipt, so such a row will never become `Received` that way: it stays `Aired` and is done (never
re-aired, not counted as unconfirmed).

### 5.4 Inbox status flow

Light group (`LightStatus`): `Received` when stored; `Rejected` (corrupt, wrong direction, too old, not allowed by
`routes.json`, a different catalogue fingerprint, a sequence number already used by another message or an old number
shown again (D84); reason in `LightComment`) — never delivered, never requeued, not
counted as service work. Like every row it is never deleted automatically.

Service group (`ServiceStatus`, only for `Received` rows):

```mermaid
stateDiagram-v2
    [*] --> Pending : QR Receiver INSERT - planned AddMessagesAsync, ReceiptDueUtc set
    Pending --> Delivering : InboxWorker loop of its class claims a Request, Attempts + 1
    Delivering --> Done : Reply first, then - RETURN_CODE 0, return code 0, HTTP 202, 2xx with no result check
    Delivering --> Refused : Reply first, then - SOAP fault, 4xx, 3xx, 501, 505, RETURN_CODE not 0
    Delivering --> Unknown : Reply first, then - no answer after sending, reset, 5xx, 2xx result unreadable, stopped during the POST
    Delivering --> NotDelivered : Reply first, then - no target URL, or 8th failure where nothing was sent, or at once for a round-trip query
    Delivering --> Expired : Reply first, then - past ExpiresUtc, not posted
    Delivering --> Done : same content already Done - not posted, its Reply reused - step 10b
    Delivering --> Unknown : same content Unknown or still Delivering - not posted - step 10b
    Delivering --> Retrying : nothing sent - DNS, refused, connect timeout, TLS, 408, 429 - no Reply yet
    Delivering --> Pending : gateway stopping before the POST
    Delivering --> Unknown : still Delivering after 5 min and no Reply - Unknown Reply first
    Retrying --> Delivering : NextAttemptUtc reached
    Refused --> Pending : operator RequeueAsync - its next outcome sends a second Reply
    Unknown --> Pending : operator RequeueAsync, after checking
    NotDelivered --> Pending : operator RequeueAsync
    Done --> [*] : kept without its body, archived manually by an operator
```

A row still `Delivering` after 5 min whose Reply for this attempt was already written (the crash came between the Reply and the row,
D46) takes that Reply's outcome — Done, Refused, Unknown, Expired or NotDelivered — and is never posted again. A
Reply written before the row's current claim (an earlier attempt, before an operator's requeue) is not used: the row
ends `Unknown` (D64).
Every arrived row except a Receipt is also owed a **Receipt** (`ReceiptDueUtc`), whatever its status, Rejected included; `ReceiptWorker`
writes it into this side's Outbox and clears the column. The same `MessageId` arriving again makes it owed again. Rows
with `Kind` Receipt or Reply are never claimed by `InboxWorker`: `AnswerReader` reads them (step 10a) and ends each one
`Done` once used, or light `Rejected` when it fails a check or answers no message of this side.

---

## 6. Security and integrity

| Protection | Against | Where |
|---|---|---|
| Size limits everywhere (request — per route `MaxRequestBytes` since step 16 —, XML, header, decompressed body, service reply) | Memory exhaustion, zip bombs, an oversized call blocking the light | Gateway, serializer, QrDiode |
| Safe XML reading (no DTD, nothing external loaded) | XML attacks (XXE) | All untrusted XML |
| `routes.json` + `SenderSide` | Unlisted services, wrong direction | `RouteTable`, `InboxWorker` |
| Catalogue fingerprint in every header | A sender running a different `routes.json` | `RouteTable`, `OutboxWriter`, `InboxWorker` |
| WSDL check + allowed message types | Bad requests entering the queue | `ContractCatalog`, `SenderEndpoint` |
| Reply only after the database commit | Losing an accepted call | `OutboxWriter` |
| Checksum in MessageBytes, MessageHash on both sides | Corruption; reconciliation | `MessageSerializer`, Outbox/Inbox |
| Signature, encryption, anti-replay counter | Forged, changed, read or replayed QR sessions | QrDiode Core |
| MessageId as Inbox primary key | Storing the same message twice | `InboxRepository` |
| Date window (7 days, 60 min skew) | Old or future-dated messages | `ArrivalChecks` |
| Sequence number not reused, not at or below the run's watermark (D84, first check only) | The sender's `qrbridge.db` restored from an old backup or copied; an archived message shown again, whatever its date | `ArrivalChecks`, `InboxRepository.FindSequenceConflictAsync`, table `SequenceWatermark` |
| Target URL from configuration only, no redirects | A message choosing where it goes | `SoapForwarderHttpClient` |
| Logs hold service, operation, type, ids and sizes only | Data leaking into logs | Everywhere |
| Caller's address in every Request (`CallerHost`, only address characters from `X-Forwarded-For`), logged at delivery | Not knowing who sent a call; log injection | `SenderEndpoint.CallerHostOf`, `InboxWorker` |
| Inbox body cleared once `Done` (D77) | Payloads kept readable on disk after use | `InboxRepository` |
| Credentials per target, never a password in configuration (D75) | Stored secrets | `SoapForwarderHttpClient` |

The original request is never edited: legacy quirks (`<SOURCE_APPLICAION>`, static `MSG_ID="456"`) arrive unchanged.
`MSG_ID` is never used to detect duplicates; `MessageId` is. Who may call: the DMZ gateway accepts anonymous calls from
anyone on the intranet (D6, Rowshan's decision against the review's recommendation; IIS configuration only; IP
restrictions may be added later).

---

## 7. Design review notes

Facts from the code as of 24 Nov 2026 (updated 25 Nov for V6 fix steps 14–18), collected for reviewing the design. Planned behaviour is marked 🔶.

### 7.1 Delivery guarantees per hop

| Hop | Guarantee | Why |
|---|---|---|
| Caller → Outbox | "OK" (`Bridge`) or a held call (RoundTrip) = committed to disk. Any error before the commit = nothing stored and the caller is told so. | Reply or hold after `COMMIT` (I13/I21) |
| Outbox → screen 🔶 | Every light `Pending` row is eventually aired or ends `Failed` for an operator. | Claim / release / restart reset |
| Screen → Inbox | **None yet.** Until Receipts travel back, `Aired` does not mean received. A session the camera never completes is lost; the sending side gets **no signal**. Since 24 Nov the receiving gateway reports the missing sequence numbers once a later message arrives (log and `/health`; since step 17 an idle side's Heartbeat is such a later message), since step 9b it writes a Receipt for every arrived message ✅, and since step 10a the sending gateway reads arriving Receipts ✅ — but nothing carries Receipts back over the light yet, so on real hardware the `Received` light status is still never set. Since step 17 each side reports the far side **silent** when nothing arrives for 15 min ✅ (on real hardware it always will, until the QR apps carry messages 🔶). | Receipts written and read ✅ (steps 9b, 10a), not carried 🔶 (QrDiode work); gap detection ✅; re-air of rows with no Receipt built in the gateway ✅ (step 11), carried by the QR apps 🔶; Heartbeats and far-side-silent ✅ (step 17), carried 🔶 |
| Inbox → real service | **At most one POST that may have reached the service.** Re-posted only when the call surely did not arrive (D9); a crash or timeout during the POST ends `Unknown`, never re-posted on its own. On routes that recognise retries, the same content that may already have reached the service is not posted again (step 10b). | Retries only for "nothing sent" (none for a round-trip query, step 10b); stuck rows settled from the Reply of their current attempt or `Unknown` (D46, D64) |
| End to end | The receiving gateway writes a Reply with the real outcome and answer for every final outcome ✅; the sending gateway reads it, stores it on the Outbox row and gives it to a held RoundTrip caller ✅ (step 10a). But nothing carries Replies over the light yet, so on real hardware a held caller always gets its hold-timeout answer and the refusal is visible only on the receiving side. | Replies written and read ✅; carried 🔶 (QrDiode work) |

### 7.2 Crash and failure points

| Where it fails | What happens | Result |
|---|---|---|
| Gateway dies before `COMMIT` | Nothing stored; caller sees a connection error | Caller decides whether to retry |
| Gateway dies **after** `COMMIT`, before the reply | Message is stored and will be sent; caller sees an error and may retry | On RoundTrip routes (permits, orders, cards, `GetFrom…` with 1596) a retry with the same content within 30 min is attached to the first message (D56), unless that one surely was not done (D63); on `Bridge` feeds a **duplicate** with a new MessageId (`MSG_ID` is not unique, so no other dedupe) |
| Caller's own timeout shorter than the gateway's reply | Same as above | Same as above; the holds (270 s / 90 s) are set below the callers' timeouts |
| QR Sender dies while a bundle is on screen 🔶 | Rows stay `Sending`; reset to `Pending` at restart and aired again | Receiver skips them by MessageId if they already arrived, and the gateway sends their Receipt again |
| Camera misses part of a session | Since 26 Nov: the next verified session replaces it; the Receiver shows "Incomplete — must be re-sent" (known issue 1 fixed) | The lane carries on; the incomplete session is re-aired like a lost one (no Receipt) |
| Someone holds a QR code up to the camera ✅ | Since protocol v2 (26 Nov): a data frame without the session's MAC is dropped before the decoder; an untrusted manifest is rejected (or ignored while a session is in progress) | No effect on the session in progress |
| Camera never completes a session after the sender moved on 🔶 | Rows are `Aired`; nothing arrives | **Loss**, reported on the receiving side as a sequence gap once a later message arrives; the sending gateway puts the rows back to `Pending` after 120–180 s with no Receipt ✅ (step 11) and the QR Sender airs them again 🔶; after 3 airs, light `Failed` |
| `qrbridge.db` deleted or the machine rebuilt | The counter starts again at 1 with a new run id | The far side sees a new run, not duplicates; numbers missing at the end of the old run are not noticed |
| `qrbridge.db` restored from an old backup, or copied to a second machine | The counter hands out numbers the far side already has, in the same run | Since step 17 (D84) each such message is `Rejected` on the far side ("already used"), and an old message shown again after its row was archived is `Rejected` by the watermark. Back up the sequence state with the database; a restore also brings this side's Inbox back to the backup (guide §12.4) |
| QR Receiver dies after decrypting, before the Inbox commit | Since 26 Nov the anti-replay state is committed only after the store (I38, known issue 3 fixed): the session is received again while still on screen, or re-aired | No loss; at worst a duplicate, skipped by MessageId |
| Inbox commit fails 🔶 | Planned: don't commit anti-replay; session can be read again while still on screen | Recovers only if the sender is still airing it |
| Gateway dies after the POST, before saving the outcome | Before the Reply is written: row stays `Delivering`; after 5 min it becomes `Unknown` with an Unknown Reply. After the Reply: the row takes the Reply's outcome (D46). Never POSTed again | No duplicate; an operator checks `Unknown` rows |
| Real service processes the call but the reply times out (120 s) | `Unknown` (it may have been processed), with a Reply | Operator checks before requeueing |
| App pool recycle during the POST | `Unknown` at once, with an Unknown Reply (D41); a recycle **before** the POST puts the row back to `Pending`, attempt not counted | No automatic duplicate |
| Real service down for a long time | 8 tries only while nothing was sent (refused, DNS, connect timeout, TLS, 408, 429); waits of 30 s, 1, 2, 4, 8, 16, 30 min (about 1 h), then `NotDelivered` with a Reply (D25) | Operator may resend |
| Gateway dies after writing a Receipt, before clearing `ReceiptDueUtc` | The same Receipt is written again on the next pass | Harmless duplicate Receipt |
| Doorbell can't be created/opened (permissions) | Falls back to polling only | Up to 2 s extra delay |

### 7.3 Ordering

- Sequence numbers are per direction and per run of the counter (`SequenceRunId`), given inside the insert
  transaction: no gaps and no duplicates on the sending side.
- The Outbox is claimed answers first (Receipts, Replies, Heartbeats), then by class — High, Normal, Low — and by Sequence within
  a class (✅ step 14, D73). 🔶 A bundle released after an encode error waits ~30 s, so later rows can overtake it.
- The Inbox is claimed by **one loop per class** (✅ step 14). Inside a class: the sender's counter runs in the order
  they started (their first message's `CreatedUtc`), then Sequence, so a new run (counter restarted at 1) never jumps
  ahead of older messages. **Strict order per service (D74):** a Request is not claimed while an earlier Request of
  the same service and class is `Retrying`; other services and classes go on. A message that arrives late (in a
  later QR session) is still delivered after higher numbers that arrived first.
- **Gap detection** (since 24 Nov): missing numbers are reported per run after `GapGraceMinutes` (§4.5). The sending
  gateway re-airs rows with no Receipt ✅ (step 11, §4.5); the QR apps do not carry them yet 🔶. A lower number
  arriving after higher ones is normal (answers jump the queue, re-airs) and is accepted; only a number already held by
  another message, or at or below the run's watermark with no row holding it, is refused (D84, §4.5).
- A slow service (up to 120 s per try) delays only the other messages of its own class; the other two loops go on.
- Per-order ordering (`OrderingKey`, so other orders of the same service can pass a stuck one) is a design idea only
  (Integration-Plan §4).

### 7.4 Limits and timers

| Setting | Value | Where |
|---|---|---|
| `Bridge:MaxPayloadBytes` | 1,000,000 bytes (request and decompressed body) | appsettings |
| `MaxRequestBytes` (per service) | 10 × the largest simulator template on 11 routes, e.g. SSO2FMS 120,950, IR2BFC 8,480 (D78); other routes 1 MB. ⚠️ Not verified against real sizes (review Q4): a bigger real call gets 413 | `routes.json` |
| `Gateway:MaxBacklog` | 5,000 Requests with light status `Pending` + `Sending` + `Aired` (Receipts, Replies and Heartbeats not counted, D47); per service `MaxBacklog` in `routes.json` (none set) | appsettings, `routes.json` |
| `Gateway:Light` | 6,700 bytes/s, 6 s minimum, 1.5 s gap: only for the start-up warning when a RoundTrip route's size limit takes longer to air than its hold (1 MB ≈ 151 s; D79). Arithmetic, not measured | appsettings, `StartupChecks` |
| `InboxPollSeconds` | 2 s (also how often `AnswerReader` reads arrived Receipts and Replies) | appsettings |
| `Gateway:Hold` | Corp 270 s, DMZ 90 s: how long a RoundTrip caller is held; a held caller re-reads its Outbox row every 2 s | appsettings, `SenderEndpoint` |
| `Gateway:Expiry` | 600 s on both sides: a state-changing RoundTrip call (permit, order, card) is not posted on the far side after this (D62); start-up refuses a value not longer than the hold | appsettings, `SenderEndpoint`, `StartupChecks` |
| `MaxAttempts` / backoff | 8 tries; 30 s × 2ⁿ⁻¹, max 30 min | appsettings |
| `ReplayWindowDays` / `MaxClockSkewMinutes` | 7 days / 60 min | appsettings |
| `LockTimeoutMinutes` | 5 min; start-up refuses if not longer than the delivery timeout + 30 s | appsettings, `StartupChecks` |
| `GapGraceMinutes` | 5 min before a missing number counts as lost (0 = at once); start-up refuses a negative value. No retention setting: nothing is deleted automatically | appsettings, `StartupChecks` |
| `Gateway:ReceiptTimeoutSeconds` / `Gateway:MaxAirAttempts` | 120 s with no Receipt before an `Aired` row is aired again (real wait 120–180 s) / 3 airs in total, then light `Failed`; start-up refuses 0 or less | appsettings, `MaintenanceWorker`, `StartupChecks` |
| `Gateway:HeartbeatMinutes` / `Gateway:FarSideSilentMinutes` | 5 min with nothing queued before a Heartbeat message is sent (0 = off) / 15 min with nothing heard before the far side counts as silent (D81, D82; same on both sides). Start-up refuses `HeartbeatMinutes` < 0 and `FarSideSilentMinutes` ≤ 0 or not longer than `HeartbeatMinutes`. Checked once a minute, so a Heartbeat leaves 5–6 min after the last message | appsettings, `FarSideMonitor`, `MaintenanceWorker`, `StartupChecks` |
| `Receiver:TimeoutSeconds` / `MaxResponseBytes` | 120 s / 4,000,000 bytes | appsettings |
| Maintenance interval / stale heartbeat / old Outbox warning | 60 s / 2 min / 30 min | code |
| SQLite `busy_timeout` | 5 s | `SqlitePragmaInterceptor` |
| QR symbol size / redundancy / manifest interval | 1,350 B / 3 loops / every 20 frames | `SendOptions` |
| QR frame rate / minimum air time / gap | 15 fps / 6 s / 1.5 s | `TransmitEngine` |
| QR air time per session | ≈ max(6 s, 3 × K ÷ 15 fps), K = encrypted size ÷ 1,350 B, + 1.5 s gap | derived |
| Transmit queue depth | 14; older items are **dropped** (known issue 2) | `TransmitEngine` |
| Bundle size 🔶 | 50 messages / 128 KB | Integration-Plan §2.3 |

### 7.5 Weak points found in the code

Fixed 24 Nov 2026 (V6 review fix, step 2): the backlog is now counted inside the insert transaction, so concurrent
calls can no longer overfill the Outbox (G-13); start-up refuses `RetentionDays < ReplayWindowDays` and a zero or
negative replay window or clock-skew limit; a 2xx reply whose result can't be read is dead-lettered instead of
counted as `Done` (G-17; since step 5a it ends as Inbox `Unknown`); SQLite runs with `synchronous = FULL` (G-14).
(The `RetentionDays` check went with the setting in step 6.)

Fixed 24 Nov 2026 (V6 review fix, step 6, checks on arrival): the route catalogue fingerprint travels in every header
and a mismatch is rejected (G-15, D31); the sender's counter has a run id (D27); lost messages are detected and shown on
`/health`, with operator acknowledgement (G-02 "detect", D29, D30); rows are never deleted automatically (D28).

1. ~~**`routes.json` must be identical on both sides**, but nothing checks it.~~ **Fixed 24 Nov (step 6):** every header
   carries the sender's catalogue fingerprint and the receiving gateway rejects a mismatch with a clear reason;
   `/health` and the start-up log show the fingerprint, so both sides can be compared. A mismatch still shows up only
   as `Rejected` rows on the receiving side: deploy the same file to both.
2. **The message is not encrypted on disk.** `MessageBytes` is stored as plain compressed bytes in both tables of `qrbridge.db`.
   Protection is the folder permissions, which are set up by hand. Since step 15 (D77) an Inbox row's body is cleared
   once it is `Done`; Outbox rows and Inbox rows waiting for an operator keep theirs.
3. **Each side monitors only itself.** A `Refused`, `Unknown` or `NotDelivered` Inbox row on the DMZ side is invisible
   on the Corp side and to the caller. Since step 9b the DMZ gateway writes a Reply for it ✅ and since step 10a the Corp
   gateway reads it ✅, but the Corp Outbox row stays service `Waiting` until Replies are carried over the light
   (QrDiode work) 🔶.
4. **The Outbox light status `Aired` exists, but nothing sets it yet** 🔶 (it waits for the QR Sender). `Received` is
   set by `AnswerReader` since step 10a ✅, but only once Receipts are carried over the light 🔶.
5. **Clocks:** `CreatedUtc` comes from the sender's clock and is checked against the receiver's clock (7 days, 60 min).
   Both sides need NTP; during islanding they may not share a time source.
6. **Queries, permits, orders and cards wait for the light.** Since step 10a the `RoundTrip` queries, and since step
   10c (D60) permits, orders and cards, are queued and their callers held for the real answer ✅; until the QR apps
   carry messages 🔶, every query gets "not available" (1599) and every permit, order or card 1596 when its hold runs
   out (accepted by Rowshan: it replaces the false "0" these calls got as `Bridge`). `FMS2FC.IssueWorkPermit` is
   RoundTrip too (D61) but pilot-only until the FMS team explains what `IntMgr.CardCutOut` does after a non-zero
   answer (open question D12). XA/21 and BFC stay `Unavailable` until open question D23 is answered (D52).
7. ~~**Schema via `EnsureCreated`.**~~ Since 27 Nov 2026 EF migrations: an entity change is a new migration, never a deleted database.
8. **Lost messages are detected, and re-aired by the gateway, but not yet over the real light:** a gap is seen only
   once a later message arrives (since step 17 an idle side sends a Heartbeat every 5 min, so a lost last message
   shows within minutes); the sending gateway re-airs rows with no Receipt ✅ (step 11), but nothing sets
   `Aired` until the QR Sender reads the Outbox 🔶. The database grows without limit until an operator archives rows.
9. ~~**An old message is recognised only by its date.**~~ **Fixed 25 Nov (step 17, D84):** a reused number or a number
   at or below the run's watermark is rejected whatever its date. The rule depends on operators **never archiving
   `SequenceWatermark`**; it is checked only on a row's first check.
10. **The gateway may run as an administrator.** Since step 18 (D4) start-up logs a warning when the process is
    elevated, but still starts. A dedicated app pool identity per side, the data-folder ACL, BitLocker, IIS request
    limits and a fixed recycle time are operations steps written in the guide §12.4, not tried on a real server.

---

## 8. Not built yet / open points

| Item | State |
|---|---|
| QrDiode Sender ↔ Outbox, QrDiode Receiver ↔ Inbox, bundles, setting the `Aired` light status (the value exists since 24 Nov) | 🔶 Integration-Plan §2.2–2.5 |
| Receiver stuck after a partly read session; anti-replay recorded before saving | 🔶 known issues 1 and 3 — fix first |
| Database migrations (today the schema is created directly) | 🔶 before go-live |
| Order per FMS order when one message is being retried | Strict order per service and class ✅ (step 14, D74); per order (`OrderingKey`) 🔶 Integration-Plan §4 |
| Switch back after islanding without reordering (stop → drain → flip load balancer) | 🔶 Integration-Plan §3.2 |
| Calls that need a live answer (queries), and permits, orders and cards | `RoundTrip` routes held for the real answer ✅ (queries step 10a, permits/orders/cards step 10c), "not available" (1599) or 1596 when the hold runs out — always, until the QR apps carry messages 🔶; XA/21 and BFC `Unavailable` until D23 is answered; `IssueWorkPermit` pilot-only until D12 is answered |
| Outbound: WSDLs built from client proxies, paths to confirm, Corp delivery URLs empty | To confirm / configure |
| Receipts and Replies back over the light | Written by the receiving gateway ✅ (step 9b); read by the sending gateway ✅ (`AnswerReader`, tracker step 10a); aired and stored by the QR apps 🔶 (Integration-Plan §2). The two-way link needs security sign-off |
| Re-airing lost messages (detection ✅ since 24 Nov) | Gateway re-air ✅ (step 11: `Aired` with no Receipt → `Pending`, then `Failed`); on real hardware 🔶 once the QR Sender sets `Aired`; effect on light capacity not measured |
| Heartbeat messages and "far side silent" | Built in the gateway ✅ (step 17); the QR Sender must air Heartbeat rows like Receipts and mark them `Aired`, the QR Receiver store them like any message 🔶. Until then each side reports the other silent after 15 min |
| Operator UI: requeue, acknowledge a gap, archive | 🔶 the methods exist; no UI (archiving is manual) |
