# QrBridge Gateway — generic SOAP stand-in

## Documentation map

Start here for configuration, deployment and the gateway's behaviour. Then choose the detail you need:

| Category | Document | Use it for |
|---|---|---|
| Workflows | [Gateway-to-QrDiode workflow](workflows/gateway-qrdiode-workflow.md) | Inbound and Outbound request/reply diagrams and the end-to-end message journey |
| Reference | [Code walkthrough](reference/gateway-code-walkthrough.md) | Sender/Receiver roles, class responsibilities, shared data layer and code map |
| Q&A | [Round-trip files, explained simply](q_&_a/round-trip-files-explained.md) | Plain-words purpose of the Receipt/Reply/Heartbeat classes (`AnswerReader`, `AnswerWriter`, `ArrivalChecks`, `WaiterRegistry`, monitors…) |
| Q&A | [RoundTrip walkthrough: POST and GET](q_&_a/round-trip-post-and-get-walkthrough.md) | Demo guide: each step of a POST and a GET RoundTrip, Corp → DMZ and DMZ → Corp, with class, database table and step; no-answer cases; retries and `ContentFingerprint`; QrDiode security |
| Q&A | [The `-wal` and `-shm` files, explained](q_&_a/sqlite-wal-files-explained.md) | Why `qrbridge.db` has two companion files: SQLite's WAL mode, the settings our code makes (and where), checkpoints, crash safety, what would change without WAL, and the rules for backups, permissions and network shares |
| Reviews | [Single database: plan prompt](reviews/single-database-plan-prompt.md) and [tracker](reviews/single-database-tracker.md) | How and why `send.db` + `received.db` became one `qrbridge.db` per machine (25 Nov 2026), with the verification log |
| Reference | [Unimplemented work and service coverage](reference/uncovered-services.md) | Only unfinished integration, blocked/unconfirmed interfaces and missing deployment inputs, with reasons and next actions |
| Reference | [Read-only web UI](reference/read-only-ui.md) | `/qrbridge-ui`: what it shows, how to run and deploy it, how it is built (Angular analogies), how to change it |
| Reviews | [Original V6 review](reviews/qr-proxy-design-review-and-security-audit-v6.0.md) | Historical findings and monitor-source evidence; not current implementation status |
| Reviews | [V6 fix plan](reviews/gateway-review-v6-fix-plan.md) | The agreed design and rationale for addressing those findings |
| Reviews | [V6 fix tracker](reviews/gateway-review-v6-fix-tracker.md) | Decisions, progress, verification results and remaining release gates |

The duplicate class summary was consolidated into the code walkthrough. Historical review logs may still name
that former document.

> One-page reference. The full explanation — why WCF calls are hard to carry across the air gap, how the gateway
> solves each issue, data, security, operations, deployment and status — is in
> [gateway-to-qrdiode/technical-guide.md](../../../docs/gateway-to-qrdiode/technical-guide.md).

The gateway sits where the real services used to be. In islanding mode the load balancer (Corp side) or the
FMS interface configuration (DMZ side) sends callers here, unchanged. The gateway:

1. **accepts any SOAP request** — SOAP 1.1 or 1.2, document/literal (WCF, ASMX) or RPC/encoded (SOAP Toolkit
   `*.WSDL` endpoints), with or without WS-Addressing — without knowing the service's contract;
2. **stores the request bytes exactly as received** in the Outbox of `qrbridge.db` (Brotli-compressed with a checksum; not encrypted — QrDiode encrypts the QR link), then
3. **replies like the real service** (`<RESPONSE><RETURN_CODE>0…`, a `long`, an `int`, or an automatic reply) —
   at once for feeds (`Bridge`), or after **holding** the caller for the real service's answer from the other side
   (`RoundTrip`: permits, orders, cards, queries; 1596 "confirmation not yet received" or "not available" when it does
   not come back in time);
4. on the other side, **replays** requests that arrived over the QR link to the real service — same bytes,
   same `SOAPAction`, same path — records what the service answered, and sends back a **Reply** (the outcome and
   the real answer) and a **Receipt** ("it arrived") over the opposite lane.

System overview: the [current architecture](../../../docs/gateway-to-qrdiode/architecture.md). The remaining work is
designed in [gateway-to-qrdiode/integration-plan.md](../../../docs/gateway-to-qrdiode/integration-plan.md). On a new machine, start with [handoff.md](../../../docs/handoff.md).

## Projects

| Project | Deployed as | Role |
|---|---|---|
| `sourcecode/gateway/src/QrBridge.Gateway` | IIS site | Sender (callers → Outbox), receiver worker (Inbox → real services, then Replies and Receipts → Outbox), maintenance, `/health` |
| `sourcecode/gateway/src/QrBridge.Shared` | compiled into the gateway and the QrDiode apps | EF Core + SQLite (one database per machine, `qrbridge.db`: Outbox, Inbox and their bookkeeping tables; the start is refused beside a former `send.db` / `received.db`), message envelope (`BRG7`; not encrypted — QrDiode encrypts the QR link), named-event doorbells |
| `sourcecode/gateway/src/QrBridge.Gateway/Ui` | part of the gateway (same project, same IIS site) | Read-only web UI under `/qrbridge-ui` (login): Outbox and Inbox in plain words, `/health` figures. Opens `qrbridge.db` read-only. [Guide](reference/read-only-ui.md) |
| `sourcecode/gateway/tests/QrBridge.Tests` | — | Unit + integration tests (real WCF clients, the simulator's 43 message templates, end-to-end, light and caller faults with a fake light, the read-only UI) |

Publishing (`dotnet publish`, commands in [the guide §12.3](../../../docs/gateway-to-qrdiode/technical-guide.md#123-publish)) gives `publish/gateway`
(IIS) and `publish/sender`, `publish/receiver`, `publish/keys` (self-contained exe files for the kiosk PC).

## How a call is handled

```
POST /FMS_SSO2FMSInterface/SSO2FMSInterface.svc   SOAPAction: "http://tempuri.org/ISSO2FMSInterface/SendToFMS"
  1. body read (max Bridge:MaxPayloadBytes, or the route's
     smaller MaxRequestBytes)                                      too big          -> 413 + SOAP fault
  2. SOAP envelope parsed (DTDs prohibited)                        not SOAP         -> 400 + SOAP fault
  3. route = path in routes.json; operation = SOAP body element    not listed      -> SOAP fault (allow-list)
  4. Mode (per operation, or per MESSAGE/@TYPE when the operation lists "Types"):
       Echo         -> reply with the request value (EchoString)
       Unavailable  -> reply "not available while islanded" (RETURN_CODE 1599) — queries can't cross the gap
       RoundTrip    -> same checks and queuing as Bridge (+ ExpiresUtc, see below), then HOLD the caller (Gateway:Hold,
                       Corp 270 s / DMZ 90 s) until
                       the far side's Reply is read (step 10a): Done/Refused with the real answer -> that answer byte
                       for byte; Unknown or no answer carried -> OnHoldTimeout answer; Expired/NotDelivered/Rejected ->
                       "not available"; hold runs out or light Failed -> OnHoldTimeout answer
                       (permits, orders, cards: Pending = RETURN_CODE 1596; queries: Unavailable = 1599)
       Bridge       -> (feeds: FMS2FSS, FMS2Dashboard, FMS2SSLog, FMS2VR, FTC2FMS SendToFMS, VZ2TLS)
                       MESSAGE/@TYPE on the allow-list?           no               -> RETURN_CODE 1597
                       same content queued < 30 min ago?          yes + RecogniseRetries -> attached: same answer, no new row
                       backlog below Gateway:MaxBacklog and the
                       service's own MaxBacklog (if set)?         no               -> RETURN_CODE 1598  (counts Requests only)
                       store in Outbox, commit, ring the doorbell, THEN reply RETURN_CODE 0
```

The reply carries the response header `X-QrBridge-MessageId` (the gateway-assigned id for the stored message). Every queued
Request also carries the caller's address (`CallerHost`: the first `X-Forwarded-For` address labelled with the
connection's, e.g. `10.1.2.3 (via 10.0.0.9)`, else the connection's; step 15, D76), logged by the far side at
delivery, and its **priority class** (below). The DMZ gateway accepts anonymous calls from anyone on the intranet
(D6, IIS configuration only; IP restrictions may come later).

**Caller retries** are recognised by a content fingerprint (SHA-256 without the per-send fields `MSG_ID`,
`GMT_TIME_SENT`, `RRMsgID` and without SOAP headers). On routes with `RecogniseRetries` (by default only RoundTrip
routes with `OnHoldTimeout: Pending`, decision D56) a retry within `Gateway:RetryWindowMinutes` is attached to the
first message and held for the same answer (permits, orders and cards since step 10c, D60); `Bridge` routes (feeds)
still queue it again and only count it (`/health` → `retries`). A retry of a message the far side surely did not carry
out (Outbox service status Expired, NotDelivered or Rejected) is queued as a **new** message instead (D63). A query
(`OnHoldTimeout: Unavailable`) is never attached and gets `ExpiresUtc` = now + hold (D54): the far side never runs it
after its caller was told "not available". A state-changing RoundTrip call (`Pending`) gets `ExpiresUtc` = now +
`Gateway:Expiry` (600 s on both sides, D62): the far side does not post it after that (Inbox Expired), so a permit
never lands after the dispatcher has gone verbal. `Bridge` calls have no expiry. If a held caller hangs up, its
message stays queued.

**Until the QR apps carry messages over the light** (not built), every RoundTrip call waits the full hold and gets its
hold-timeout answer: permits, orders and cards get 1596, not the false "0" `Bridge` gave before (accepted by Rowshan).
`FMS2FC.IssueWorkPermit` is RoundTrip too (D61); what FMS does after a non-zero answer is open (D12), so it stays
pilot-only until the FMS team explains it.

## The route catalogue: `sourcecode/gateway/src/QrBridge.Gateway/routes.json`

One file, deployed to **both sides — the same file**. Every message carries a fingerprint of the catalogue (SHA-256 of
its services, reply profiles and `FingerprintIgnore` list); the receiving gateway rejects a message whose sender had a different one. Compare
`catalogFingerprint` in `/health` on both sides. Each service lists the paths callers use, its style, and its operations:

```json
{ "Name": "SSO2FMS", "SenderSide": "Corp",
  "Paths": [ "/FMS_SSO2FMSInterface/SSO2FMSInterface.svc" ],
  "Style": "Document",
  "Operations": {
    "SendToFMS":  { "Mode": "RoundTrip", "Reply": "FmsResponse", "AllowedTypes": [ "SSO_RESPONSE", "RETURN_ORDER" ] },
    "GetFromFMS": { "Mode": "RoundTrip", "Reply": "FmsResponse", "OnHoldTimeout": "Pending" },
    "EchoString": { "Mode": "Echo" } } }
```

`OnHoldTimeout` (for `RoundTrip`) is the answer when the real one does not come back within `Gateway:Hold`
(Corp 270 s, DMZ 90 s): `Pending` = `RETURN_CODE 1596` (state-changing calls; the default) or `Unavailable` (queries).
`Gateway:Expiry` (`DefaultSeconds` + per-service `Services`, like `Gateway:Hold`; 600 s) is how long a `Pending` call
may still be posted on the far side; start-up refuses a value not longer than the service's hold. `"Types"`
sets these per MESSAGE TYPE inside an operation (e.g. FC2FMS `GetFromFMS`: `AUTHORIZE_USERS` → `Unavailable`).

Optional, since 25 Nov 2026: `"Priority"` (`High`/`Normal`/`Low`) on an operation or a type overrides the route's
default class (`Answer` is refused at start-up; no route sets it today); per service, `"MaxRequestBytes"` (bigger calls
get HTTP 413 before anything is parsed or queued; the smaller of it and `Bridge:MaxPayloadBytes` applies) and
`"MaxBacklog"` (that service's Requests waiting to cross before new calls get its Busy answer, 1598). Start-up refuses
values ≤ 0. `MaxRequestBytes` is set to 10 × the largest simulator template on DSS2FMS, FC2FMS, FOD2FMS, FTC2FMS,
IR2BFC, SSO2DSO, SSO2FMS, SSO2TLS, SSO2TOMS, VZ2TLS and XA2FMS (D78); every other route stays on 1 MB; no `MaxBacklog`
is set. **Not verified:** real messages may be larger than the templates, and would then get 413 (review Q4). At
start-up the gateway **warns** about each RoundTrip route on its side whose size limit takes longer to air than its
hold, at `Gateway:Light` speed (6,700 bytes/s, 6 s minimum, 1.5 s gap: the review's arithmetic, not measured; D79):
1 MB takes about 151 s, so every DMZ round-trip route warns against the 90 s DMZ hold.

**Adding a service needs no code:** add an entry and set its receiver target on the delivering side. Reply profiles
(`FmsResponse`, `ReturnCode`) are defined once at the top of the file.

`Routing:AcceptUnlisted = true` makes the gateway accept **any** SOAP service not in the catalogue, with an
automatic reply (`<OpResponse/>` — WCF reads it as null / default / void). Use it to test or discover a new
service; keep it `false` in production so only listed services pass.

Shipped catalogue (from the fms-interface-simulator): FC2FMS, FOD2FMS, SSO2FMS, SSO2TOMS, SSO2TLS, SSO2DSO,
FTC2FMS (WCF), VZ2TLS (ASMX), DSS2FMS and the six legacy `RR_*.WSDL` endpoints (SOAP Toolkit), plus XA2FMS and
IR2BFC as "Unavailable" (they need live answers), and RegisteredTags (plain HTTP GET, round trip). DMZ → Corp (from the DMZ interface services in workspace-master-v2):
FMS2FC, FMS2FOD, FMS2SSO, TLS2SSO, TOMS2SSO, DSO2SSO (WCF), FMS2FSS, FMS2Dashboard, FMS2SSLog, FMS2VR, and
FMS2FTC as "Unavailable". Every SOAP route has a WSDL in `Contracts/` (except FOD2FMS) and calls must match it.

**GET requests:** `GET /health` is answered (use it for the load balancer probe). The only other GET answered is a
route marked `"HttpGet": true` on its own side: the Registered Tags report (`RegisteredTags`,
`/FMS_ReportService/RegisteredTags.asmx/GetData`, callers on Corp; V6 fix step 12, D18, D69–D72). It crosses as a
round trip (payload format `HttpGet`: no body, no Content-Type, no SOAPAction), is replayed on the DMZ as a GET, and the
caller gets the real answer byte for byte (status, Content-Type, body) or, when none comes back within the hold
(Corp 270 s), **HTTP 504** text/plain. A query string gets 400; a SOAP POST to that path gets a fault. The read-only
UI's pages under `/qrbridge-ui` answer too (decision 48, behind a login; `Ui:Enabled = false` removes them; no route
may use that prefix). Any other GET, and every HEAD, gets HTTP 405: no WSDL or help pages, because the simulator's
clients never fetch them. Not verified against the real report service; WebClient's 100 s default timeout is shorter
than the hold (a risk).

## Delivery on the other side (`Gateway:Receiver`)

The target URL comes from **this side's configuration only**, never from the message:
`Receiver:Targets:<Service>:Url`, else `Receiver:DefaultBaseUrl` + the caller's original path. On the DMZ the RR
servers host the same paths as before, so one `DefaultBaseUrl` covers every service. Credentials:
`Receiver:UseDefaultCredentials` (app pool identity or anonymous), overridden per service by
`Receiver:Targets:<Service>:UseDefaultCredentials` (D75); never a password in configuration.

**Priority classes** (step 14, D73, D74): `Answer` (Receipts, Replies, Heartbeats), `High` (RoundTrip with 1596: permits, orders,
cards), `Normal` (RoundTrip queries, incl. Registered Tags and PortalSync), `Low` (`Bridge` feeds). The QR sender's
claim (`OutboxRepository.ClaimNextAsync`) airs Answers first, then High, Normal, Low. The receiving gateway runs **one
delivery loop per class** (High, Normal, Low), so a slow feed never holds back a permit. Inside a class: the sender's
counter runs in the order they started, then its sequence. **Strict order:** a Request waits while an earlier Request
of the same service and class is `Retrying`; other services and classes go on.

Each Inbox row has two status groups (decision D24): `LightStatus` (did it arrive intact?) and `ServiceStatus` (what did
the real service do?). The real service's HTTP code goes in `ServiceHttpStatus`.

| Real service answers | Inbox status |
|---|---|
| RETURN_CODE 0 / return code 0 / HTTP 202 | service Done (`DownstreamResult` keeps the answer) |
| RETURN_CODE ≠ 0, return code ≠ 0, SOAP fault | service Refused — never retried automatically; operator |
| 404 / 401 / 403 / 415… | service Refused — configuration problem; operator |
| no answer after sending, reset, 500 / 502 / 503 / 504, a 2xx whose expected result can't be read | service Unknown — may have been processed; never retried automatically; operator |
| nothing was sent: DNS, connection refused, connect timeout, TLS, 408, 429 | service Retrying → retried with backoff (`MaxAttempts`, then NotDelivered: it surely never reached the service). A round-trip **query** (`OnHoldTimeout: Unavailable`) is not retried: NotDelivered at once (step 10b) |
| no Receiver target configured | service NotDelivered — never reached the service; operator may resend |
| corrupt envelope (checksum), wrong direction, not in catalogue, different `routes.json` on the sender, a sequence number already used by another message or an old number shown again (below) | light Rejected — never delivered |

`Bridge` and RoundTrip Requests are both delivered. **Same content again** (step 10b, only on routes with
`RecogniseRetries`): before the POST, a Request whose content fingerprint matches one that arrived within
`Gateway:RetryWindowMinutes` is not posted when that earlier one is Done (it ends Done and reuses the earlier Reply's
answer) or Unknown / still Delivering (it ends Unknown); after Refused, NotDelivered or Expired it is posted normally.

**Replies and Receipts** (V6 fix step 9b): every final outcome above (Done, Refused, Unknown, Expired, NotDelivered,
Rejected; not Retrying) is first written as a **Reply** into this side's Outbox — outcome, HTTP code, reason, and the
real answer byte for byte (left out above `Bridge:MaxPayloadBytes`) — and only then stored on the Inbox row. A row
found still Delivering after a crash takes the outcome of a Reply written for its current attempt (D64: not one from
before an operator's requeue), or becomes Unknown with an Unknown Reply; it is never
posted again. `ReceiptWorker` writes a **Receipt** for every arrived message (again if it arrives twice; never for a
Receipt). Both cross back like any Outbox row and never count against `MaxBacklog`. On the sending side
`AnswerReader` reads them (step 10a, after the same arrival checks): a Receipt sets the Outbox row's light status to
Received; a Reply sets its service status (Answered/Refused/Unknown/Expired/NotDelivered/Rejected) and wakes the held
callers. A newer Reply after an operator requeue on the far side replaces the stored answer unless that one is
Answered (D59). Not built yet: carrying them over the light (QrDiode work), so on real hardware every held call still waits
the full hold. Messages use header version 7
(`BRG7`: `Priority` since v6, the kind `Heartbeat` since v7); older `BRG3`…`BRG6` messages are refused, so delete old dev databases. When an Inbox
row ends Done its body is cleared (D77): `MessageHash`, `DownstreamResult` and the header columns stay; rows an
operator may requeue keep theirs; Outbox rows are not cleared.

**Lost messages:** each side numbers its messages per run of its counter. The receiving gateway looks for missing
numbers once a minute; a gap counts once the message after it arrived `Gateway:GapGraceMinutes` (5) ago. It logs a
`Light: …` warning and stays until the message arrives or an operator acknowledges it (`AcknowledgeGapAsync`; no UI
yet). **Old messages by number** (step 17, D84): the first time an arrived message is checked, it is Rejected when
another message that arrived earlier already has its number (same direction and counter run: the sender's `qrbridge.db` restored
from an old backup, or a copy), or when its number is at or below the run's watermark and no row holds it (an old
message shown again after its row was archived), whatever its date. The watermark (table `SequenceWatermark` in
`qrbridge.db`) means "every number up to here arrived and was checked, or was acknowledged as a gap"; the gap check
moves it up once a minute. **Never archive `SequenceWatermark` or `AcknowledgedGap`.** The date window
(`ReplayWindowDays`, `MaxClockSkewMinutes`) stays as a second check. **Re-air** (step 11, built in the gateway): once a minute an Outbox row (not a Receipt or Heartbeat) still light Aired
`Gateway:ReceiptTimeoutSeconds` (120) after it was aired goes back to Pending, so the QR sender airs it again; after
`Gateway:MaxAirAttempts` (3) airs, or once past its expiry, it becomes light Failed for an operator
(`RequeueFailedAsync`; no UI). Safe: the far side skips a MessageId it already has and sends a new Receipt. Nothing sets
Aired on real hardware yet (QR sender not connected), so this is proven only by tests. Rows are never deleted
automatically: archive them manually.

**Far side and Heartbeat messages** (step 17, D80–D83): when a gateway has queued nothing for
`Gateway:HeartbeatMinutes` (5; 0 = off), it queues an empty **Heartbeat** message (service `QrBridge`, operation
`Heartbeat`, priority Answer) — unless an earlier one is still waiting to be aired, so they never pile up while the
light is down and then go out ahead of real messages. It takes a sequence number, so a lost last message becomes a gap once the Heartbeat
after it arrives; it gets no Receipt and is never re-aired. The far side checks it like any message and ends it Done.
When nothing has arrived from the far side for longer than `Gateway:FarSideSilentMinutes` (15, counted from start-up
until something is heard), `/health` turns unhealthy and the log says `Light: nothing heard from the far side since …`.
Use the same two settings on both sides; start-up refuses `HeartbeatMinutes` < 0 and a `FarSideSilentMinutes` that is
≤ 0 or not longer than `HeartbeatMinutes`. Proven only with two in-memory gateways and a fake light.

`GET /health` shows the light and service counts of both queues, the oldest undelivered row of each,
`catalogFingerprint`, `missingMessages` and the first 20 `gaps`, `lightProblems` (Outbox light Failed + missing
messages), `serviceProblems` (Inbox Unknown + Refused + NotDelivered) and `farSide` (`lastHeardUtc`,
`lastReceiptUtc`, `silent`, `silentAfterMinutes`); `healthy` is false if either count is not 0, the far side is
silent, or a component heartbeat is stale.

At start-up the gateway logs a **warning** (it still starts) when its process runs as an administrator: use a
dedicated app pool identity per side ([guide §12.4](../../../docs/gateway-to-qrdiode/technical-guide.md#124-deploy-per-side)).

## Run it locally

```powershell
dotnet build sourcecode\gateway\QrGateway.slnx
dotnet test sourcecode\gateway\tests\QrBridge.Tests                      # 519 tests
# a real gateway on http://localhost:5080 (dev data under C:\QrBridgeDev):
dotnet run --project sourcecode\gateway\src\QrBridge.Gateway --launch-profile "Gateway (Corp)"
# then open http://localhost:5080/qrbridge-ui (admin / admin) to see its Outbox and Inbox;
```

## Limits (true of any generic proxy)

- **Message-level security** (WS-Security signing/encryption, secure conversation), reliable sessions and duplex
  callbacks cannot be replayed. None of the FMS services in the simulator use them.
- **Replies that carry live data** (queries) only work if the answer crosses back within the caller's hold: they are
  `RoundTrip` with `OnHoldTimeout: Unavailable` (or `Unavailable` outright where no round trip is agreed, e.g. XA2FMS).
- **Unlisted operations** get an empty reply; a caller that reads a result needs a catalogue entry with a reply profile.
