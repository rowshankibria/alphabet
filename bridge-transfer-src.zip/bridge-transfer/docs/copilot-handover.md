# Handover to GitHub Copilot: what was built, and where to continue (26 Nov 2026)

This solution moved to a machine where the only assistant is **GitHub Copilot**. This file says what exists,
what was finished last (the read-only web UI), how to check the machine, and where the work continues. It is an
index: the detail lives in the documents it links to.

## 1. Read in this order

1. [`.github/copilot-instructions.md`](../.github/copilot-instructions.md): the settled decisions and the rules
   in the code. Copilot loads it on every request; the path-specific rules in
   [`.github/instructions/`](../.github/instructions/) load for matching files.
2. This file.
3. [`docs/handoff.md`](handoff.md): the decision log (numbered decisions), what was built, verification,
   known issues, next steps and open questions.
4. [`sourcecode/gateway/docs/reference/read-only-ui.md`](../sourcecode/gateway/docs/reference/read-only-ui.md):
   the web UI guide (pages, code map, how to change it, settings, limits).
5. [`docs/gateway-to-qrdiode/integration-plan.md`](gateway-to-qrdiode/integration-plan.md) §5: the order of the
   remaining work.
6. [`sourcecode/qrdiode/docs/qrdiode-pending-work.md`](../sourcecode/qrdiode/docs/qrdiode-pending-work.md): the QrDiode
   status. §1 is what is pending (P-1 … P-11, in order, each with "done when"), §2 what is done, §4 the checklist
   for a new machine (none of it is in git; keys do not move).

## 2. Set up and check this machine

1. Unzip **every** part (`bridge-transfer-part1.zip`, `-part2.zip`, …, if there is more than one) into **one** folder
   at a short path, for example `C:\src\QrDiode_V2`. Each part holds different files; together they are the whole
   tree. A deep path makes Windows refuse to load the native `ZXing.dll` ("filename or extension is too long").
2. Install a .NET 10 SDK (`global.json` pins 10.0) and a Visual Studio that builds .NET 10 (ASP.NET and WPF
   workloads), or use VS Code with the C# Dev Kit. A package source must be reachable for the first restore.
3. Check it:

   ```powershell
   dotnet test All.slnx      # expected: QrBridge.Tests 519 passed, QrDiode.Core.Tests 75 passed
   ```

4. Look at the web UI with sample data (both gateways stopped first; takes about 20 s):

   ```powershell
   $env:QRBRIDGE_DEMO_ROOT = "C:\QrBridgeDev"
   dotnet test sourcecode\gateway\tests\QrBridge.Tests --filter "FullyQualifiedName~UiDemoDataTests"
   Remove-Item Env:QRBRIDGE_DEMO_ROOT
   ```

   Then in Visual Studio open `sourcecode\gateway\QrGateway.slnx`, make `QrBridge.Gateway` the start-up project,
   pick the launch profile **Gateway (Corp)** and press F5: the browser opens `http://localhost:5080/qrbridge-ui`.
   Sign in with **admin / admin**. The DMZ side is the profile **Gateway (Dmz)** on port 5090 (start the second one
   from a terminal: `dotnet run --project sourcecode\gateway\src\QrBridge.Gateway --launch-profile "Gateway (Dmz)"`).

**Not in the zip, on purpose:** build output (`bin/`, `obj/`, `.vs/`), local databases (`*.db`), keys (`*.key`)
and user settings (`*.user`). Visual Studio rebuilds the first; step 4 recreates the sample databases.

## 3. The system in one paragraph

Con Edison FMS **islanding mode**: when the firewalls between CorpNet and the FMS DMZ are cut, SOAP/WCF calls
between the corporate apps and the FMS-side services cross a light-only air gap (QR codes on a screen, read by a
camera, one lane per direction). On each side **`QrBridge.Gateway`** (an IIS site) stands in for the services on the
other side: it stores each caller's call in the Outbox of `qrbridge.db`, and replays calls that arrived (Inbox) to
the real services. **`QrDiode.Sender` / `QrDiode.Receiver`** (WPF apps) carry the messages over the light. The
gateway and the QrDiode apps meet only through that one SQLite file and two named events. Architecture:
[`docs/gateway-to-qrdiode/architecture.md`](gateway-to-qrdiode/architecture.md).

## 4. State at handover

| Area | State |
|---|---|
| SOAP gateway (`sourcecode/gateway/src/QrBridge.Gateway`) | Built and tested with a **fake light**: ingress and WSDL checks, durable Outbox, delivery, Receipts, Replies, retries, heartbeats, `/health`. Not yet tried on IIS or with real services. |
| Shared data (`sourcecode/gateway/src/QrBridge.Shared`) | One `qrbridge.db` per machine (Outbox, Inbox and bookkeeping tables), EF Core, **EF migrations since 27 Nov 2026** (older files adopted with their rows; `dotnet tool restore` brings `dotnet-ef`). Also the QR bundle format and the QR apps' ends of the light (`Bundles/`). |
| **Read-only web UI** (gateway folder `Ui/`, decision 48) | **Finished 25–26 Nov 2026**, section 5. |
| QrDiode apps (`sourcecode/qrdiode/`) | Protocol v2 (26 Nov). **Connected to the gateway since 27 Nov** with `"QrDiode:Mode": "Bridge"`: the Sender airs the Outbox as bundles, the Receiver writes the Inbox; kiosk start-up. Tested with two in-memory gateways; **not yet on real screens and cameras** — the next work (section 7). Status of every item: [qrdiode-pending-work.md](../sourcecode/qrdiode/docs/qrdiode-pending-work.md). |

## 5. The read-only web UI (the newest work)

**Where:** inside the gateway project, folder `sourcecode/gateway/src/QrBridge.Gateway/Ui/` (Razor Pages,
`RootDirectory = "/Ui/Pages"`), served by the gateway itself under `/qrbridge-ui`: one project, one publish, one
IIS site. Wiring: `Initializer/UiRegistration.cs`. Guide and code map:
[read-only-ui.md](../sourcecode/gateway/docs/reference/read-only-ui.md).

**What a user sees**

- **Overview** (`/qrbridge-ui`): health in words, QrData and Service counts per status (each opens the filtered
  list), far side last heard, the newest Requests sent and arrived.
- **Outbox / Inbox lists**: message id, correlation id, time, message (service.operation + kind + business
  type), service URL, statuses and one line of content. Paging, filters and search run **in the database**; the
  footer (rows shown, rows per page, page number, previous / next) stays in view.
- **One message** (`/qrbridge-ui/{outbox|inbox}/{id}`): the ids with Copy buttons, the QrData and Service status
  cards, then three **bands**, each opened by a coloured strip that folds it away when clicked:
  - **REQUEST** (blue, "what was asked"): the call (request line and headers), the request shown three ways
    (the message itself, the SOAP envelope, the exact bytes), and, on a Reply or Receipt page, the Request it
    answers.
  - **RESPONSE** (purple, "what came back"): the real service's response, then the **Reply** and **Receipt**
    of the round trip, each in its own section with its id (a link), statuses and times.
  - **DETAILS** (grey): every field of the message, then the **Related messages** table.
- Every text box and every round-trip section has **one plain line under its title** saying what it is.
- Dark and light theme (follows Windows; the button switches and remembers it). One login (`Ui:Username` /
  `Ui:Password`, admin / admin by default; change them before go-live).

**Words and formats Rowshan chose (keep them)**

| Topic | Decision |
|---|---|
| First status group | Shown as **QrData** ("has it crossed the air gap as QR codes?"), never "light". Code names (`LightStatus`, `Display.Light`, the `light=` query) stay. |
| Receipt | "**it arrived safely**": the other side received and saved the message. Says nothing about the service. |
| Reply | "**what the real service did**": its answer (accepted, refused…), or why the request was never sent to it (too late, unreachable). |
| Times | US format, 12-hour clock, US Eastern: **`11/25/2026 05:05:39 PM EST`** (EDT in summer); UTC in the tooltip. The database keeps UTC; do not change columns to `DateTimeOffset` (read-only-ui.md §7). |
| Not shown | Priority, sequence number, caller address, catalogue fingerprint, and the overview's "This gateway" / "Missing messages" sections. Ask before showing them again. |
| Brand | **QrNexus** in the top bar, the page titles and the sign-in heading (renamed from QrGateway on 26 Nov 2026); the sign-in page has no top bar or footer. |

**Rules that keep it safe** (full list: [read-only-ui.instructions.md](../.github/instructions/read-only-ui.instructions.md))

- **Read-only.** Only `Ui/Data/ReadOnlyBridgeDb` (SQLite `Mode=ReadOnly`) and `Ui/Data/MessageQueries` touch the
  database; the rest of the gateway only through `Ui/UiGatewayInfo`. The test
  `UiReadOnlyTests.No_ui_class_depends_on_code_that_writes` fails if a UI class takes a writer. Requeue,
  acknowledge or archive buttons: **ask Rowshan first** (an `Unknown` requeue can duplicate a permit).
- **Payloads are untrusted and in clear:** Razor encoding only (never `Html.Raw`), XML only through `SafeXml`,
  never logged. Content security policy: no inline script or style, no CDN.
- **A page whose browser left stops quietly:** pass the handler's `CancellationToken` to every query and return
  `EmptyResult` on `OperationCanceledException` when it is cancelled (see `MessagesModel.OnGetAsync`).
- **Paging stays in the database** (`Skip`/`Take`), never a whole table in memory.

**Tests:** `sourcecode/gateway/tests/QrBridge.Tests/Ui/` (68 tests: pages, paging, login, read-only guard, round
trip on two gateways, bands, wording, time format, a whole busy day rendered page by page). Run them with
`dotnet test sourcecode\gateway\tests\QrBridge.Tests --filter "FullyQualifiedName~QrBridge.Tests.Ui"`.

**Known limits** (read-only-ui.md §7): one login from configuration; not tried on a real IIS; a delivered Inbox
Request keeps no body (decision D77: the sending side's Outbox has it); what the gateway itself answered a caller
(for example 1596) is not stored.

## 6. Test infrastructure worth knowing

- `Gateway/Infrastructure/GatewayHost.cs`: a real gateway in memory. `TwoGatewayBench`: Corp and DMZ gateways joined
  by `FakeLight`, a stand-in for the QR link. To hold a lane, call `FakeLight.PauseAsync(side)`, not the flag alone:
  the flag can race with an air that has just begun.
- `Ui/Infrastructure/DemoTraffic.cs`: the busy islanding day behind the sample data (every status on both sides).
- `UiBrowser`: signs in through the form (antiforgery token included) and reads pages as a person would
  (`UiBrowser.Text`).

## 7. How to continue

1. **Next work:** [integration plan §5](gateway-to-qrdiode/integration-plan.md#5-order-of-work). The receiver's
   stuck-session bug (§2.1) and the other QrDiode fixes were done on 26 Nov (QrDiode protocol v2, the `"Production"`
   setting); bundles, migrations, the Sender and the Receiver connected to the gateway, and kiosk start-up on 27 Nov
   (§2.2–2.6; [qrdiode-pending-work.md](../sourcecode/qrdiode/docs/qrdiode-pending-work.md)). Next: the first run on real
   screens and cameras (its §0.4), then islanding operations (§3).
2. **Reusable prompts** (type `/` in Copilot Chat): `verify-solution`, `fix-receive-engine-bug`,
   `add-bundles-and-outbox-status`, `connect-sender-to-outbox`, `connect-receiver-to-inbox`, `add-bridged-service`,
   `extend-read-only-ui`, `update-handoff`, `fix-review-v6-step`. **Custom agents:** `bridge-architect`,
   `wpf-mentor` (Rowshan is new to WPF and comes from Angular: explain XAML with Angular analogies).
3. **After every change:** `dotnet test All.slnx`, then update `docs/handoff.md`, the known issues in
   `.github/copilot-instructions.md`, and the recorded test counts (they appear in several docs: search for the
   old number).
4. **Ask Rowshan before:** reversing a settled decision, restructuring projects, changing anything callers depend
   on, adding write actions to the UI, committing or pushing. Open questions are in
   [handoff.md §10](handoff.md#10-open-questions-for-rowshan).
