# Handoff — Gateway-to-QrDiode, 25 Nov 2026

A concise handoff for the next developer: current status, decisions, known issues, verification and open questions.
For the system design use the architecture; do not treat historical decisions as current implementation status.

## 1. Read in this order

- [Copilot handover](copilot-handover.md): what was built (the read-only web UI last), checking a new machine, where to continue.
- [Architecture](gateway-to-qrdiode/architecture.md): current system and both round trips.
- [Integration plan](gateway-to-qrdiode/integration-plan.md): unfinished work and proposed sequence.
- [Technical guide](gateway-to-qrdiode/technical-guide.md): configuration, security and operations.
- [Gateway documentation](../sourcecode/gateway/docs/gateway.md): code, workflow, service gaps and reviews.
- [Copilot instructions](../.github/copilot-instructions.md): settled rules and project conventions.

## 2. How this folder came about

Gateway-to-QrDiode evolved from a prototype into a generic SOAP gateway and separate QrDiode applications.
The [V6 fix tracker](../sourcecode/gateway/docs/reviews/gateway-review-v6-fix-tracker.md) preserves the
gateway review decisions, implementation steps and test history. Section 3 preserves the project decision IDs;
it is a decision log, not a substitute for the current status in sections 4 and 8.

## 3. Decisions log

Decision IDs are retained for references in the review tracker. Entries describe the latest known position;
gateway logic marked built has not yet been carried over a real optical round trip.

| # | Decision | By | Why |
|---|---|---|---|
| 1 | The gateway impersonates the existing endpoints exactly (paths, SOAPActions, reply shapes) | Rowshan (constraint) | Callers are not ours and only go through the corporate LB |
| 2 | **Generic SOAP gateway**, no CoreWCF; it must handle any WCF request | Rowshan | No per-service code; works for RPC/encoded (DSS); payload passes through verbatim; new services are configuration |
| 3 | ~~One solution `QrDiode.slnx`~~ → since 20 Nov: **two solutions** — `sourcecode/gateway/QrGateway.slnx` (QrBridge.Gateway, QrBridge.Shared, QrBridge.Tests) and `sourcecode/qrdiode/QrDiode.slnx` (QrDiode.*), plus `All.slnx` at the root for both. Keep the QrDiode project structure; implement EF SQLite features inside the QrDiode apps, which will reference `sourcecode/gateway/src/QrBridge.Shared` by relative `ProjectReference` | Rowshan | Gateway and optical link are separate products; one copy of the shared data layer, owned by the gateway (it owns the schema) |
| 4 | Deployables: gateway → IIS, Sender and Receiver → separate WPF exe files; shared data code is intended to be compiled into both apps when connected | Rowshan | Keep the current QrDiode project structure; no additional Windows service |
| 5 | Stay on .NET 10 LTS (packages 10.0.15) although .NET 11 is out; `global.json` pins 10.0 | agent | LTS, and QrDiode was built on 10 |
| 6 | Copy (not move) the prototype parts; the original `QrBridge/` folder stays as history | agent | Nothing lost |
| 7 | Service is found by **path**, operation by the **SOAP body element** (not by SOAPAction) | agent | Five legacy endpoints share one SOAPAction; body element works for every style |
| 8 | Store the request as `RawSoapMessage` (exact bytes + SOAPAction + Content-Type) inside the ~~existing AES-GCM~~ envelope (encryption removed by decision 23; `RawSoapMessage` folded into `MessageHeader` by decision 25) | agent | Verbatim replay |
| 9 | Envelope header gained a plain `BusinessType` label | agent | Operators and the QR receiver can see what a row is without unpacking it; it is not business data |
| 10 | The initial query-unavailable decision was superseded: configured queries use gateway `RoundTrip`; XA/21 and BFC remain `Unavailable` pending scope, and Registered Tags is a configured GET round trip (decisions 26 and 29). QR queue integration is still missing. | agent, then Rowshan | Queries need a real answer or an honest timeout |
| 11 | Backlog full → `RETURN_CODE 1598` (not a SOAP fault); message type not allowed → `1597` | agent, recommended; codes to confirm | Callers already show `ERROR_MESSAGE` for non-zero codes |
| 12 | Allow-list per operation (`AllowedTypes`) mirroring what each real service accepts | agent | Refuse at once, while the caller is on the line, instead of a dead letter an hour later |
| 13 | Real-service refusals (non-zero code, fault) → **DeadLetter** with `DownstreamResult`; never retried automatically. *Since 24 Nov the status is called `Refused` (decision 31)* | agent; Q4 open | Retrying a business refusal cannot succeed and could duplicate side effects |
| 14 | Receiver target only from configuration: `Targets[service]` or `DefaultBaseUrl` + original path | agent | A message can never choose where it is sent |
| 15 | Removed from the prototype: CoreWCF samples, typed clients/handlers, `PayloadSerializer`, `FrameCodec`, the `InboundChunk` table, `QrBridge.Station` | agent | Superseded by the generic gateway and by QrDiode (D12) |
| 16 | Unlisted services refused by default; `Routing:AcceptUnlisted` for test/discovery | agent | Allow-list in production (D7); "any WCF request" when needed |
| 17 | Agent instructions live in `.github/` (`copilot-instructions.md`, `instructions/`, `prompts/`, `agents/`); `CLAUDE.md` only points there | Rowshan (the new machine has Copilot only) | One source of truth, whichever assistant is used |
| 19 | No `deploy/` or `scripts/` folders: build/test with `dotnet test All.slnx`, publish with `dotnet publish`, set up IIS, folders and kiosk by hand | Rowshan | The move to the new machine is done; fewer files to keep in step |
| 18 | The project moves through GitHub. Build output and the fms-interface-simulator copy stay out of the repository (`.gitignore`), and the handoff zip matches | Rowshan (the new machine already has the simulator) | A small repository; the simulator stays in its own project; the code uses its own copies (`sourcecode/gateway/tests/QrBridge.Tests/Samples`, `sourcecode/gateway/src/QrBridge.Gateway/Contracts`) |
| 20 | HTTP entry points are **MVC controllers** in `Controllers/` (`SenderSoapController`, `HealthController`), not inline minimal-API maps. They stay thin, are not `[ApiController]` and bind no parameters; the SOAP logic stays in `SenderEndpoint` | Rowshan | Easier for developers to find where requests land; raw-body and SOAP-fault behaviour unchanged |
| 21 | **The gateway does not serve WSDLs, XSDs or help pages.** `GET /health` and the configured Registered Tags GET are the two supported GET routes (plus, since decision 48, the read-only UI under `/qrbridge-ui`); other GET/HEAD requests receive 405. WSDL files remain in the gateway for request validation (decision 24). | Rowshan | Callers use compiled proxies and do not download WSDLs |
| 22 | Remove unused future-only code. Message kind and `CorrelationId` were later reintroduced and are used by the implemented gateway Reply and Receipt handling (decision 26). | Rowshan | Avoid unused code while retaining the fields required by the actual message flow |
| 23 | **No gateway encryption; QrDiode is the only encryption layer** (replaces design record D8's keys and D13 "double layer"). The envelope keeps its header and Brotli compression and gains a SHA-256 checksum (corruption detection only). Removed `KeyTool`, `DpapiKeyStore`/`IKeyProvider`, the key settings and startup check, `KeyId`. Consequence: payloads are readable in `qrbridge.db` (until 25 Nov: `send.db`/`received.db`), and the gateway trusts what is in its Inbox — protect the data folder with NTFS permissions (and BitLocker if required) | Rowshan | QrDiode already encrypts and authenticates the QR link; one less key to create, carry and rotate |
| 24 | **Forwarded SOAP calls are checked against the configured WSDL**: SOAP version, supplied SOAPAction, body element and schema/parts. A mismatch is not queued. WSDL files are read, never served. The separately configured Registered Tags GET has no SOAP contract. | Rowshan | Reject malformed calls before queueing |
| 25 | **One message format:** `MessageHeader` plus the original body, now `BRG7`. It also supports Replies, Receipts, Heartbeats and the configured HTTP GET; original request bytes are preserved. | Rowshan | Avoid redundant serialization layers |
| 26 | **Round trip over the opposite lane:** gateway Request, Receipt and correlated Reply handling is built and tested with fake light. Heartbeats were added later. Actual QR-app queue integration remains unbuilt; configured polls stay `Unavailable`. | Rowshan, 24 Nov | Do not tell a caller that a permit was completed before the real service answers |
| 27 | **Recognise eligible caller retries by content:** configured retry-recognising routes attach eligible retries within the window; queries do not attach and `Bridge` feeds queue again. Never dedupe on `MSG_ID` or `RRMsgID` alone. Verify against real captured retries. | Rowshan, 24 Nov | One business identifier alone does not identify a retry |
| 28 | **Re-sending rules** (V6 D9): gateway retry classification and bounded re-air scheduling are built; optical re-airing still requires QR Sender integration. To the real service, re-post only when the call surely did not arrive; if it may have arrived, mark `Unknown` and do not re-post automatically. Business refusals are not automatically retried; expired requests are not posted. | Rowshan, 24 Nov | Avoid duplicate permits and orders while recovering safely from confirmed non-delivery |
| 29 | **Registered Tags GET is supported as a round trip** (V6 D18, D69–D72). *Built 24 Nov (V6 step 12).* Partly reverses decision 21 for this one configured GET path (`routes.json` `RegisteredTags`, `"HttpGet": true`, Corp callers); every other GET still gets 405. The caller is held (Corp 270 s) for the real answer, replayed byte for byte; otherwise **HTTP 504**. A query string is refused (400) | Rowshan, 24 Nov | The report is needed while islanded |
| 30 | **Hold times and timeout responses:** default Corp hold 270 s, DMZ 90 s; state-changing calls can return 1596 when confirmation is pending, while query timeout behaviour is route-configured. `IssueWorkPermit` remains pilot-only pending the FMS team's explanation. Gateway logic is built; actual QR round trips are not. | Rowshan, 24 Nov | A timeout must not be presented as confirmed success |
| 31 | **Two status groups per Outbox/Inbox row instead of one `Status`** (V6 D24). *Built 24 Nov (V6 step 5a).* No new table. A light group (`LightStatus`, `LightComment`, `LightUpdatedUtc`) and a service group (`ServiceStatus`, `ServiceHttpStatus`, `ServiceComment`, `ServiceUpdatedUtc`; the Inbox keeps `DownstreamResult`). Hardware failures show as a light status that does not advance, with the reason in `LightComment`. Inbox `DeadLetter` is gone: `Refused`, `Unknown`, or `NotDelivered` (surely never sent, an operator may resend; V6 D25); since V6 step 9a, out of retries ends as `NotDelivered` (only "nothing sent" failures are retried) | Rowshan, 24 Nov | An operator must see at once whether a problem is on the light or at the service end |
| 32 | **No automatic deletion of Outbox or Inbox rows** (V6 D28). Operators archive manually and never archive rows younger than `ReplayWindowDays`; retain sequence watermarks and acknowledged gaps. | Rowshan, 24 Nov | Preserve audit and replay-detection state |
| 33 | **Lost messages are found by sequence gaps, per run of the sender's counter** (V6 D27, D29, D30). *Built 24 Nov (V6 step 6).* `SequenceRunId` (was "epoch") identifies the counter's run: a new `qrbridge.db` (until 25 Nov: `send.db`) starts at 1 in a new run, so it is neither a duplicate nor a gap. A gap shows on `/health` (unhealthy, light problem) after `Gateway:GapGraceMinutes` until the message arrives, a new run starts, or an operator acknowledges it (`InboxRepository.AcknowledgeGapAsync`, audit table `AcknowledgedGap`) | Rowshan, 24 Nov | The one-way light can lose a message silently (V6 G-02); now it is at least visible on the receiving side |
| 34 | **Both gateways must run the same `routes.json`** (V6 D31). *Built 24 Nov (V6 step 6).* Every message carries a SHA-256 of the sender's service list and reply profiles (and, since V6 step 7, its `FingerprintIgnore` list); a different or missing fingerprint → `Rejected`. `/health` and the start-up log show `catalogFingerprint`: compare both sides after every deployment | Rowshan, 24 Nov | A message must never be judged by rules its sender did not have (V6 G-15) |
| 35 | **Interim query handling was superseded by decision 37.** Configured RoundTrip gateway routes now queue and hold callers; XA/21 and BFC remain unavailable pending question 3. | Rowshan, 24 Nov | Avoid presenting the interim behaviour as current |
| 36 | **The receiving gateway answers every Request: Receipts and Replies** (V6 D43–D48). *Built 24 Nov (V6 step 9b); consumed since V6 step 10a.* One Receipt per arrived message, again on re-arrival; one Reply per final outcome (Rejected included), with the real answer, in header v5 (`BRG5`); Reply first, then the Inbox row; never refused for a full Outbox, not counted in `MaxBacklog` | Rowshan, 24 Nov | The sending side must always learn whether a message crossed and what the real service did — the base of re-airing (step 11) and of the held caller's answer (step 10) |
| 37 | **RoundTrip callers are held for the real answer** (V6 D49–D56). *Built 24 Nov (V6 step 10a); replaces decision 35's "answer at once".* The caller gets the real answer byte for byte when the service accepted or refused it and the answer came back; `1596` (state-changing) or "not available" (queries) when the hold runs out, the outcome is unknown or no answer came back; "not available" when it surely was not done. A query expires with its hold and is never attached to an earlier call (it always asks the real service); a state-changing retry is attached and gets the first answer; a message that can no longer cross (light `Failed`) gets the hold-timeout answer at once. XA/21 and BFC types stay `Unavailable` until HANDOFF §10 Q3 (V6 D23) is answered. `PortalSyncRequest` with a full Outbox: the same "no data" answer | Rowshan, 24 Nov | A false failure leads to the manual fallback; a false success can kill: only a real answer from the real service is ever passed on as one |
| 38 | **The far side never posts the same command twice, and requeued results reach the caller's side** (V6 D57–D59). *Built 24 Nov (V6 step 10b).* On routes that recognise retries, a request with the same content as one that arrived in the last `Gateway:RetryWindowMinutes` is not posted if that one is `Done` (its answer is reused) or may have been processed (`Unknown`, still `Delivering` → `Unknown`); it is posted if that one surely was not processed. A round-trip query whose service surely cannot be reached ends `NotDelivered` at once. A newer Reply after an operator requeue replaces a stored answer that is not `Answered` | Rowshan, 24 Nov | Two sending sites, a reset `qrbridge.db` or a late retry must not deliver a permit twice; an operator's successful requeue must reach the waiting side |
| 39 | **Permits, orders, cards and their responses are held for the real answer** on configured RoundTrip routes; feeds remain `Bridge`. `Gateway:Expiry` defaults to 600 s. Gateway logic is built; actual QR round trips are not. | Rowshan, 24 Nov | Avoid a false success before the real service answers |
| 40 | **A message the far side never confirmed is aired again, a bounded number of times** (V6 D65–D68). *Built 24 Nov (V6 step 11).* `Aired` + no Receipt after `Gateway:ReceiptTimeoutSeconds` (120) → `Pending`; after `Gateway:MaxAirAttempts` (3) airs or past `ExpiresUtc` → `Failed` + alarm, never aired again; Receipt rows are never re-aired; a retry of a `Failed` message keeps the D55 answer | Rowshan, 24 Nov | The light is one-way and loses sessions; re-airing is safe because the far Inbox ignores a known `MessageId`, and an operator must know when a message never crossed |
| 41 | **Answers first, then priority classes:** gateway claim ordering and one receiving delivery loop per class are built. The QR Sender bundles in the same order (built 27 Nov, decision 52). Strict ordering applies per service and class; per-order ordering remains undecided. | Rowshan, 25 Nov | A slow feed should not block a permit |
| 42 | **Caller identity and plaintext at rest** (V6 D3, D6, D75–D77): `CallerHost` is recorded, per-target default credentials are configurable and delivered Inbox bodies are cleared. Anonymous DMZ access was chosen for IIS configuration; IP restrictions and security sign-off remain deployment concerns. | Rowshan, 25 Nov | Trace delivery and limit retained payload data |
| 43 | **Per-route request limits and air-time warning** (V6 D78, D79): limits derive from simulator templates; `Gateway:Light` supplies estimated throughput for a startup warning. Oversize requests are rejected by size limits, not merely because the estimated air time exceeds the hold. Confirm real payload sizes and optical speed. | Rowshan, 25 Nov | Bound requests and highlight possible timeout risk |
| 44 | **Each side knows whether the far side is alive: idle Heartbeat messages and "far side silent"** (V6 D80–D83). *Built 25 Nov (V6 step 17).* New message kind `Heartbeat` (header v7, `BRG7`): empty, names no message, priority Answer, takes a sequence number, gets no Receipt, never re-aired; queued when a side has queued nothing for `Gateway:HeartbeatMinutes` (5; 0 = off), never while an earlier one still waits to be aired. Far side silent = nothing acceptable arrived from it for `Gateway:FarSideSilentMinutes` (15; start-up refuses ≤ 0 or ≤ `HeartbeatMinutes`): `/health` `farSide.silent`, `healthy = false`, a `Light:` warning. Same settings on both sides. Proven only with in-memory gateways and a fake light | Rowshan, 25 Nov (the two values: the proposed defaults) | Silence must mean "the light or the far gateway is down", never just "nothing to say"; and a lost **last** message must show as a gap (V6 G-16) |
| 45 | **An old message is recognised by its number, not only its date** (V6 D84). *Built 25 Nov (V6 step 17).* On a row's first check: a (direction, run, sequence) already held by another message that arrived earlier → `Rejected` ("already used": a restored or copied `qrbridge.db`); a number at or below the run's `SequenceWatermark` that no row holds → `Rejected` ("an old message shown again": the original was archived), whatever its date. The date window stays as a second check. **`SequenceWatermark` and `AcknowledgedGap` are never archived.** Not used: "lower than the newest Done = old" (answers jump the queue, re-airs make lower numbers arriving later normal) | Rowshan, 25 Nov | A replay inside the 7-day window, or after its row was archived, must not be posted again (V6 G-13) |
| 46 | **Process separation by operations, one code warning** (V6 D4, answered 25 Nov). *Built 25 Nov (V6 step 18).* A start-up **warning** (never a refusal) when the gateway process runs elevated (`StartupChecks.AdministratorWarning`). One dedicated app pool identity per side with only the data-folder ACL and the network access it needs, IIS request limits, IP restrictions later (D6), BitLocker, backup of the sequence state, a fixed recycle time: written in [guide §12.4](gateway-to-qrdiode/technical-guide.md#124-deploy-per-side), **not tried on a real server** | Rowshan, 25 Nov (the recommended option) | The gateway holds plaintext payloads and talks to the real services; least privilege is an IIS setting, so the code only warns |
| 47 | **One bridge database per machine: `qrbridge.db`** (replaces `send.db` + `received.db`). *Built 25 Nov.* One SQLite file in `Bridge:DataFolder` holds all six tables (Outbox, SequenceCounter, Inbox, Heartbeat, AcknowledgedGap, SequenceWatermark), opened through one `BridgeDbContext`; same schema, indexes, PRAGMAs, transactions and queries as before. Each machine (Corp, DMZ) has its own copy. The start is **refused** while a former `send.db` or `received.db` is in the data folder (they may hold accepted, undelivered messages). Trade-offs accepted: one write lock per machine for the gateway and both QR apps (not measured with the QR apps, which are not connected); backup and restore cover both directions together; a damaged or locked file stops both directions on that machine. Work log: [single-database-tracker.md](../sourcecode/gateway/docs/reviews/single-database-tracker.md) | Rowshan, 25 Nov (asked for it after the two-file reasons were explained) | One database is simpler to explain, deploy and back up |

| 48 | **A read-only web UI inside the gateway: folder `Ui/` of the gateway project, under `/qrbridge-ui`, behind one login** (narrows decision 21: these GET pages answer too; every other GET still gets 405). *Built 25 Nov.* Razor Pages in the gateway project itself (one project, one publish, one IIS site, one process; no Angular, no Node build). First built as a separate `QrBridge.Ui` library compiled into the gateway, then merged into the gateway project the same day at Rowshan's request (one project to deploy and look at); since the build no longer separates it, a test fails if a UI class takes a dependency that writes. It shows the Outbox and Inbox in plain words — service URL (Outbox: the path called here; Inbox: the URL this side posts to, from `Gateway:Receiver`), the SOAP request, the FMS message unescaped and indented, the real answer, both status groups — and the `/health` figures. **Read-only:** `qrbridge.db` opened `Mode=ReadOnly`, the rest of the gateway reached only through `UiGatewayInfo` (`UiReadOnlyTests`), no action buttons. Login `Ui:Username` / `Ui:Password` (admin / admin by default, a start-up warning while unchanged); dark and light theme; `Ui:Enabled = false` turns it off; start-up refuses a route under `/qrbridge-ui`. `SafeXml` moved to `QrBridge.Shared` so both use it. 26 Nov (Rowshan): a detail page shows the whole round trip (the Reply and Receipts of a Request, or the Request a Reply or Receipt answers, each in its own section, before Related messages), and the pages say **QrData** instead of "light" for the first status group (code names unchanged). Guide: [read-only-ui.md](../sourcecode/gateway/docs/reference/read-only-ui.md) | Rowshan, 25 Nov (asked for a read-only UI with the gateway, one IIS app, admin/admin, dark/light) | Operators and developers need to verify what crossed and what the real service answered without SQL; actions (requeue, acknowledge, archive) stay out until decided |
| 49 | **QrDiode protocol v2** (review G-04 / B-03, H-01, H-07). *Built 26 Nov.* Every data frame carries a 16-byte MAC (HMAC-SHA256 under a per-session frame key from the same ECDH as the payload key); the manifest no longer carries the plaintext hash (the receiver computes it) and does carry the sender's **counter run id** (a lost or unreadable counter file starts a new run at 1; the receiver keeps one watermark per sender key and run); signatures are low-S only. `FrameFormat.ProtocolVersion` = 0x02: v1 frames are refused, so **both apps must be updated together**. Same QR version as before (27 at ECC L for the default 1,350-byte symbol) | Rowshan, 26 Nov | One fake QR code could destroy a session; the screen showed a hash of the plaintext; a lost counter file blocked the link |
| 50 | **`"Production"` setting in each QrDiode app's `appsettings.json`** (review S-02). *Built 26 Nov.* `true` on the real kiosks: "⚡ Demo setup" hidden (and refused by KeyCeremony), demo keys and demo trust bundles refused, only TPM-backed keys accepted or created. `false` (default) on a developer machine: unchanged. A file that cannot be read, or an unknown setting, runs the app under the strictest rules and says why | Rowshan, 26 Nov | A demo click on a kiosk made it trust a key stored on itself; software keys are easier to steal |
| 51 | **QrDiode S-03 (forward secrecy) and S-04 (decoder in its own process) deferred** to the security sign-off | Rowshan, 26 Nov | S-04 conflicts with decision 4 (two programs per machine); S-03 needs a key-exchange design. Pairing is already pinned: only peers whose public keys were exchanged in the key ceremony can talk |
| 52 | **QR bundles: up to 50 messages / 128 KB per QrDiode session, strict order.** *Built 27 Nov.* The QR Sender claims due Outbox rows in the gateway's claim order (answers, then High, Normal, Low; lowest sequence) and stops at the first row that would not fit — never skips ahead; a single message bigger than 128 KB goes alone. Format `QBB1` (`BundleCodec`): bundle id, count, sequence range (display only), length-prefixed envelopes; file name `bundle-{min}-{max}.qbb`. Both sides' rows of a bundle share `BundleId` and `QrSessionId` | Rowshan, 27 Nov | One trip costs at least ~7.5 s: one message per trip carries only ~8 a minute. A full bundle is ~19 s on air, well inside the 90–270 s holds |
| 53 | **QrDiode apps connect to the gateway with `"QrDiode:Mode": "Bridge"`** (default `Standalone` keeps the demos). *Built 27 Nov.* The apps read the same `"Bridge"` settings as the gateway on their machine (`Side`, `DataFolder`, `MaxPayloadBytes`) and reference `QrBridge.Shared` (decision 3; it is in both solutions). Sender: the Outbox is its only source (`OutboxSource`); Receiver: accepts gateway bundles only and stores them in the Inbox before committing its replay state; payloads are not kept in its store, journal snippet or preview. Unattended start-up: `Sender:AutoStart` / `Receiver:AutoStart` with endpoint, receiver and camera names | Rowshan, 27 Nov ("all pending QrDiode tasks") | Integration-Plan §2.4–2.6 |
| 54 | **EF migrations for `qrbridge.db`** (known issue 6). *Built 27 Nov.* `Initial` (the 26 Nov schema) and `Bundles` (four nullable columns, one index). A database made earlier by `EnsureCreated` is compared with each migration's schema (tables, columns, CHECK constraints, indexes) and, on an exact match, recorded as migrated with its rows; otherwise start-up stops with `SchemaMismatchException` and the file is not touched. `dotnet-ef` 10.0.15 is a local tool (`dotnet-tools.json`) | Rowshan, 27 Nov | A schema change must never mean deleting a database with messages in it |

The V6 decisions (D1–D24) in full, and the steps that build decisions 26–31, are in
[gateway-review-v6-fix-tracker.md](../sourcecode/gateway/docs/reviews/gateway-review-v6-fix-tracker.md); the design is in
[gateway-review-v6-fix-plan.md](../sourcecode/gateway/docs/reviews/gateway-review-v6-fix-plan.md) §4.

Earlier decisions D1–D14 were not all retained: see
[the guide, Appendix B](gateway-to-qrdiode/technical-guide.md#appendix-b-design-record-decisions-and-what-changed)
for what changed, and the decision log above for the current decisions.

## 4. What was built (summary)

- Gateway ingress, validation, durable Outbox, delivery worker, Receipts, Replies, heartbeats, retries and
  health monitoring are implemented. Gateway round trips were tested with a **fake light**.
- QrDiode Sender, Receiver and optical protocol (v2 since 26 Nov) transfer simulator payloads or files on their own
  (`"Mode": "Standalone"`).
- **Connected since 27 Nov (`"Mode": "Bridge"`, decisions 52–54):** the Sender airs the gateway's Outbox as bundles and
  marks them Aired; the Receiver stores arriving bundles in the gateway's Inbox and rings its doorbell. Proven with two
  in-memory gateways joined by the apps' own bundle code; **a run on real screens and cameras has not been done yet**.
- The Registered Tags GET route is implemented as a round trip; its actual islanding scope remains unconfirmed.
  The gateway does not serve WSDLs.
- **Read-only web UI** (decision 48, 25 Nov): `/qrbridge-ui` on each gateway shows its Outbox and Inbox in plain words
  (service URL, SOAP request, FMS message, real answer, statuses) and the `/health` figures, behind one login. It
  cannot change anything. Requeue / acknowledge-gap / archive from a UI are still not built (operators use SQL).

The [architecture](gateway-to-qrdiode/architecture.md) is the authoritative system overview. Current service
gaps and deployment inputs are in [uncovered services](../sourcecode/gateway/docs/reference/uncovered-services.md).

## 5. Verification state at handoff

| Check | Last recorded result |
|---|---|
| QrDiode ↔ gateway connection (decisions 52–54) | 27 Nov 2026: `dotnet test All.slnx` **564 Gateway + 116 QrDiode passed** (519 + 45 new: bundle format, bundle claims and the one-transaction Inbox insert, migrations and the adoption of older files, the QR apps' connection, two gateways joined by the bundle code — round trip, five calls in one bundle, a lost bundle re-aired, a bundle arriving twice; 113 + 3: settings sections and modes, `.qbb`-only files). `QrDiode.slnx` (now with `QrBridge.Shared`): clean build 0 warnings. Adoption tried on **copies** of both `C:\QrBridgeDev` databases: every row and sequence counter kept, both migrations recorded, the new columns present. The Receiver loads one SQLite (SQLitePCLRaw 2.1.13). Not tried: the WPF windows in Bridge mode, real screens and cameras, a kiosk ([QrDiode status page, P-1 … P-4](../sourcecode/qrdiode/docs/qrdiode-pending-work.md#1-pending)). |
| Full `dotnet test All.slnx` | 26 Nov 2026, after the read-only UI (decision 48): **519 Gateway + 75 QrDiode tests passed** (451 before + 68 UI tests: the whole round trip on one detail page, the QrData wording, database paging and its footer, correlation ids, Eastern times, a whole busy day on two gateways rendered page by page, login, read-only connection, no UI class depends on code that writes, no row changed by browsing, readable URL and content on both sides of a round trip, payload markup shown as text, 405 for every other GET, UI off, a route under the prefix refused). Before it, after the single-database change: 451 + 75. |
| QrDiode fixes (decisions 49–51) | 26 Nov 2026: `dotnet test All.slnx` **519 Gateway + 113 QrDiode passed** (75 before + 38 new: session abandon, frame MAC, limits and caps, replay commit order, counter runs, settings and trust store, audit rollover, low-S). `dotnet build` of `QrDiode.slnx`: 0 warnings. Software bench: 64 MB with 5 % loss decoded in 1.6 s CPU through the frame MAC and decoder caps; frames 1,386 B at QR version 27 (unchanged). Not tried on real screens and cameras; the WPF windows were built, not clicked through. |
| Read-only UI smoke test | 25 Nov 2026: the Corp gateway on Kestrel (`dotnet run`, environment Corp); two real feed calls stored; sign-in with admin/admin; overview, Outbox, Inbox, one message and the stylesheet answered 200; `?wsdl` still 405. After the UI moved into the gateway project (same day, Rowshan's choice): the **published folder itself** (`QrBridge.Gateway.exe` from `dotnet publish`) answered sign-in, overview, Outbox, Inbox and the assets; it contains only `QrBridge.Gateway.dll` + `QrBridge.Shared.dll`, no `wwwroot`. Sample data (`UiDemoDataTests` with `QRBRIDGE_DEMO_ROOT=C:\QrBridgeDev`) was written and both launch profiles served it (Corp Outbox 14 Requests, DMZ Inbox 13 + the missing one). The `Gateway (Dmz)` launch profile could not start before (its `http://localhost:5099` target was refused by the https rule); it now sets `Gateway:Receiver:AllowHttp` (dev only). Not tried on IIS or in a real browser on the target machine. |
| Administrator-warning test | 25 Nov 2026: one focused Gateway test passed after the technical-guide rename; the full suite was not rerun for that change. |
| Gateway smoke test | 25 Nov 2026: Kestrel on one machine; feed queued, held request timed out with 1596, `/health` answered and `?wsdl` returned 405. No real service or far side. |

The [V6 fix tracker](../sourcecode/gateway/docs/reviews/gateway-review-v6-fix-tracker.md) contains the detailed
earlier test history. Real IIS hosting, the production load balancer, real service contracts and a complete
two-lane physical screen/camera round trip remain unverified. A software QR loopback is not a hardware test.
No tests were run for this documentation review.

## 6. Setting up a new machine

- Use Windows and a released .NET 10 SDK compatible with `global.json`; first restore requires a configured
  package source. Put the solution at a short path such as `C:\src\QrDiode_V2`.
- Open the solution root in VS Code so `.github/` instructions and prompts apply. The FMS simulator is a
  separate project and is not required for the build or tests.
- Run `dotnet test All.slnx`. The last recorded full-suite baseline is 564 + 116, not a guarantee of current results.
- To look at the messages: fill the dev databases with sample data and start both launch profiles, then open
  `http://localhost:5080/qrbridge-ui` and `http://localhost:5090/qrbridge-ui` (admin / admin) — commands in
  [read-only-ui.md §2](../sourcecode/gateway/docs/reference/read-only-ui.md#2-run-it).
- IIS, its .NET Hosting Bundle, real endpoints and physical screen/camera hardware are needed for deployment
  validation. Follow the [deployment guide](gateway-to-qrdiode/technical-guide.md#124-deploy-per-side).

## 7. Troubleshooting

| Symptom | Action |
|---|---|
| ZXing native DLL load fails with path-too-long `0x800700CE` | Move the solution to a short path. |
| WPF `.baml` / `.g.cs` missing after RID-specific publish | Build again; see the [WPF tutorial](../sourcecode/qrdiode/docs/wpf-tutorial.md). |
| Restore or NU1900 vulnerability lookup fails | Check package feeds, proxy and network. An unreachable Telerik feed produced NU1900 warnings in the focused test. |
| `/health` reports the far side silent | Check the light and the far side: both QR apps in `"Mode": "Bridge"`, the camera sees the stage, the far gateway runs. Expected while the QR apps run Standalone or are closed. |
| Start-up stops: "… has bridge tables but no migration history, and they match no known version of the schema" | `qrbridge.db` is a partial or changed copy (decision 54). It was not touched. Check its undelivered rows, then move it (with `-wal`, `-shm`) out of the data folder; the next start creates a new one. A file made before 27 Nov by `EnsureCreated` is adopted automatically, rows kept. |
| A model change builds but `MigrationTests` fails | An entity or enum changed without a migration: `dotnet tool restore`, then `dotnet tool run dotnet-ef migrations add <Name> --project sourcecode\gateway\src\QrBridge.Shared --startup-project sourcecode\gateway\src\QrBridge.Shared`. |
| A QR app says "Bridge mode: the gateway's database … cannot be opened" | Its `"Bridge"` settings (Side, DataFolder) must equal the gateway's on that machine, and the kiosk user needs Modify on the data folder (guide §12.4). |
| Gateway refuses to start: "send.db … found in …" | The data folder still has a database of the former two-file layout (decision 47). Check it for Outbox rows not yet Received or still Waiting, and Inbox rows not yet Done; deal with them; then move `send.db` / `received.db` (and their `-wal`, `-shm` files) out of the folder and start again. On a dev machine with no data worth keeping, just move them away. |
| `dotnet run --launch-profile "Gateway (Dmz)"` stops: "`http://localhost:5099` is plain http://" | Fixed 25 Nov: the profile sets `Gateway__Receiver__AllowHttp=true` (dev only). On an older copy, add that line to `Properties/launchSettings.json`. |
| The read-only UI shows no messages on a dev machine | Fill the dev databases with sample data ([read-only-ui.md §2](../sourcecode/gateway/docs/reference/read-only-ui.md#2-run-it)); stop the gateways first. |
| IIS cannot access the database or gateway starts elevated | Check data-folder permissions and app pool identity in the [deployment guide](gateway-to-qrdiode/technical-guide.md#124-deploy-per-side). |

## 8. Known issues (detail)

Numbering follows the known-issues list in the Copilot instructions.

| # | Current issue | Next action |
|---|---|---|
| 1 | ~~`ReceiveEngine.FeedManifest` ignores new sessions while one is incomplete.~~ | Resolved 26 Nov: a newer verified session abandons the partial one (`SessionAbandonTests`); the Receiver shows "Incomplete — must be re-sent". |
| 2 | ~~`TransmitEngine.TrimQueue` skips waiting items beyond 14.~~ | Resolved 26 Nov: only simulator payloads (`QueueItem.Droppable`) are ever skipped. Keep Outbox items non-droppable (§2.4). |
| 3 | ~~Receiver commits the anti-replay watermark before the host stores the payload.~~ | Resolved 26 Nov: store first, then `engine.CommitReplay()`; a failed store keeps the session receivable (`ReplayCommitTests`). The Inbox write (§2.5) must follow the same order. |
| 4 | ~~Receiver pins SQLite packages differently from the EF Core shared data layer.~~ | Resolved 27 Nov: one SQLite (through `QrBridge.Shared`: Microsoft.Data.Sqlite.Core 10.0.15, SQLitePCLRaw 2.1.13). |
| 5 | ~~No QR Sender integration sets Outbox rows `Aired`.~~ | Resolved 27 Nov (decisions 52–53): Bridge mode carries Requests, Replies, Receipts and Heartbeats as bundles. Not tried on real screens and cameras yet. |
| 6 | ~~No EF migrations exist.~~ | Resolved 27 Nov (decision 54): migrations `Initial` + `Bundles`; older files adopted with their rows (tried on copies of both `C:\QrBridgeDev` databases), mismatches refused untouched. |
| 7 | FOD WSDL issue | Resolved: gateway does not serve WSDLs. |
| 8 | WSDL URL behind TLS termination | Resolved: gateway does not serve WSDLs. |
| 9 | No deployment scripts | IIS, ACLs and kiosk setup are manual and unverified on a real server. |
| 10 | DMZ → Corp contracts and paths need confirmation; Corp targets are empty and the DMZ host is a placeholder. | Obtain real contracts and HTTPS target URLs; validate with service owners. |
| 11 | The read-only UI has one configured login (admin/admin by default) and shows payloads in clear; its cookie keys are lost on an app pool recycle without a loaded user profile. | Before go-live: own `Ui:Username`/`Ui:Password` per site, https, IIS IP restriction on `/qrbridge-ui`, and keep the load balancer from forwarding it; or `Ui:Enabled = false`. Try it on a real IIS. |
| 12 | QrDiode: the list of pending bugs, hardening and features on the optical link. On 26 Nov the bugs and hardening items were fixed (decisions 49–51), including the two Receiver bugs found that day (a rejection's late `Reset` dropped the next genuine session; one forged data frame destroyed a session). On 27 Nov the gateway connection was built (F-01–F-06, B-06, S-06; decisions 52–54). Still open (P-1 … P-11): the first run on real screens and cameras, the single-file publish with the gateway connection, the round-trip time, a real kiosk, the trust-folder ACLs, a time source, the key rotation runbook, S-04, S-03 and the security sign-off. | Work from [qrdiode-pending-work.md §1](../sourcecode/qrdiode/docs/qrdiode-pending-work.md#1-pending) (in order); move items to its §2 when done. |

## 9. Next steps, with "done when"

1. ~~Fix and test the stuck Receiver session.~~ Done 26 Nov, with the other QrDiode fixes (decisions 49–51).
2. ~~Bundle rules, shared data changes, safe migrations, bundle handling.~~ Done 27 Nov (decisions 52, 54).
3. ~~Connect Sender to the Outbox.~~ Done 27 Nov (decision 53): never drops a bundle, recovers rows left on screen at start-up.
4. ~~Connect Receiver to the Inbox, replay commit after the store.~~ Done 27 Nov (decision 53).
5. **Next:** the first run on real screens and cameras — one PC (both gateways, both QR apps, a webcam pointed at the
   stage) or two — with `"Mode": "Bridge"`; measure the round-trip time idle and under load. Then validate both
   directions with real services, and complete security, operations and switch-back drills (integration plan §3).

Acceptance details and proposals are in the [integration plan](gateway-to-qrdiode/integration-plan.md#5-order-of-work).
Record mode, snapshots and per-order ordering are not approved merely because they are proposed (bundling limits:
decision 52).
After each implementation step run `dotnet test All.slnx` and update this handoff and the Copilot known-issues list.

## 10. Open questions for Rowshan

1. **Queries:** gateway RoundTrip handling exists for configured routes, but real optical delivery is not built.
   Confirm islanding scope and timeout behaviour with service owners; snapshot caching is only a proposal.
2. Confirm codes 1596, 1597, 1598 and 1599 and caller behaviour with the Rapid Restore team, including
   `IssueWorkPermit`'s pilot-only handling.
3. Do XA/21, BFC and Registered Tags need to cross the gap? XA/21 and BFC stay `Unavailable` pending scope and
   real reply details; Registered Tags is configured but its actual scope still needs confirmation.
4. Confirm the corporate load balancer's paths, TLS termination, health probe and active/standby topology.
5. Obtain scope, payloads, protocols and endpoints for MAXIMO, OSS, NRI, RTF, ReportService, diagnostic
   interfaces and any separate Feeder Status interface.
6. Decide ECC/AECC failover, queue ownership and cross-site deduplication.
7. Obtain security sign-off for both optical lanes, Replies/Receipts and plaintext-at-rest database protection.
8. ~~Agree bundling, size limits and ordering rules, including oversized messages.~~ Answered 27 Nov (decision 52): up
   to 50 messages / 128 KB, strict order, a bigger message goes alone. Per-order ordering (decision 41) is still open.

Other unconfirmed interfaces and required evidence are in [uncovered services](../sourcecode/gateway/docs/reference/uncovered-services.md).

## 11. Original machine (for reference only)

The earlier machine and prototype paths are not prerequisites for this solution. The simulator remains a
separate project; ask Rowshan for its location when its original contracts or caller behaviour are needed.
