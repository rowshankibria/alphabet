# Integration plan — the work that remains

This is the working plan for the **unfinished** Gateway-to-QrDiode integration, reviewed against the current
repository on 25 Nov 2026. It is not a description of a working end-to-end optical system. The gateway's
request/reply handling is built; connecting the QR apps to its queues is not.

The steps and acceptance criteria below guide future work. Examples of bundle format, limits, migrations, UI and
administration endpoints are **proposals**, not implemented features or approved decisions. Confirm bundling,
ordering and other open questions with Rowshan before implementing them; review the code again at each step.
For the current message journey, use the [workflow](../../sourcecode/gateway/docs/workflows/gateway-qrdiode-workflow.md);
for operation and deployment, use the [project guide](technical-guide.md).

Status per item, the verification state and the questions for Rowshan are in [../handoff.md](../handoff.md).
Settled decisions are in [../../.github/copilot-instructions.md](../../.github/copilot-instructions.md); don't reverse
them without asking.

## Contents

1. [Where we are](#1-where-we-are)
2. [Connecting QrDiode to the shared message database](#2-connecting-qrdiode-to-the-shared-message-database)
3. [Islanding operations](#3-islanding-operations)
4. [Remaining gateway items](#4-remaining-gateway-items)
5. [Order of work](#5-order-of-work)

---

## 1. Where we are

| Area | State |
|---|---|
| Gateway Sender part (any SOAP request → Outbox, reply like the real service) | built, tested |
| Gateway Receiver part (Inbox → replay to the real service, classify the answer) | built, tested |
| Receipts and Replies written by the receiving gateway into its own Outbox (V6 fix step 9b, 24 Nov 2026) | built, tested (tests copy the bytes between two gateways); **read** by the sending gateway since tracker step 10a (`AnswerReader`); **not carried** over the light (§2) |
| Round trip on the gateways: RoundTrip calls queued and the caller held for the far side's Reply; far-side same-content check and query fast failure (V6 fix tracker steps 10a, 10b, 24 Nov 2026) | built, tested between two in-memory gateways; on real hardware every held call waits the full hold and gets its hold-timeout answer until the QR apps carry messages (§2) |
| Permits, orders and cards held for the real answer (`RoundTrip`, 1596 on hold timeout), their expiry `Gateway:Expiry` (600 s), a new message for a retry of one surely not done, crash recovery per attempt (V6 fix tracker step 10c, D60–D64, 24 Nov 2026) | built, tested between two in-memory gateways; until the QR apps carry messages every such call gets 1596 after the full hold (accepted by Rowshan; it replaces the false "0" of the `Bridge` mode). Feeds stay `Bridge` |
| Heartbeat messages when a side is idle, "far side silent" on `/health`, old messages recognised by their sequence number (V6 fix tracker step 17, D80–D84, 25 Nov 2026) | built, tested between two in-memory gateways and a fake light; on real hardware nothing crosses until the QR apps carry Heartbeat rows like Receipts (§2), so each side would report the other silent after `Gateway:FarSideSilentMinutes` |
| Route catalogue and health endpoint | built; publishing uses `dotnet publish`, not a deployment script |
| Read-only web UI (`/qrbridge-ui`, folder `Ui/` of the gateway project, decision 48, 25 Nov 2026) | built, tested in memory; shows both queues in plain words, changes nothing. Operator **actions** (requeue, acknowledge a gap, archive, stop accepting) are still not built — §3 |
| Shared data layer (EF Core + SQLite), envelope, doorbells | built, tested |
| QrDiode apps reading the Outbox / writing the Inbox | **built 27 Nov 2026** ("Mode": "Bridge", decisions 52–54): bundles, first EF migrations, Sender airs the Outbox, Receiver writes the Inbox, kiosk start-up — §2. Tested with two in-memory gateways and the apps' own bundle code; **not tried on real screens and cameras** |
| Islanding switch-in / switch-back tooling | **not built** — §3 |
| Ordering, record mode | strict order per service and class **built** (V6 fix tracker step 14, D74: one delivery loop per priority class); per-order `OrderingKey` and record mode **not built** — §4 |
| DMZ → Corp catalogue | in `routes.json` (11 services, from the DMZ callers' proxies); paths and contracts to confirm, Corp receiver hosts empty — §4 |

Today the QR apps run on their own: the Sender airs simulator payloads or a file, the Receiver stores files under
`%LocalAppData%\QrDiode\` (`QrDiode.Core/QrDiodePaths.cs`). Neither knows about the bridge database, `qrbridge.db`
(one file per machine since 25 Nov 2026; before that `send.db` and `received.db`).

---

## 2. Connecting QrDiode to the shared message database

Rules that stay in force: the QrDiode **project structure stays as it is** (features are added inside the existing
projects), and **`QrDiode.Core` stays independent of the SOAP Gateway** — no EF, SQLite or SOAP in it. Gateway integration knowledge lives in
`QrBridge.Shared`, which the Sender and Receiver will reference.

### 2.1 Fix the receiver's stuck-session bug — first

> **Done 26 Nov 2026**, as designed below, together with the other QrDiode fixes in
> [qrdiode-pending-work.md](../../sourcecode/qrdiode/docs/qrdiode-pending-work.md) (decisions 49–51). One change from
> the design: the Receiver window no longer calls `engine.Reset()` after a rejection at all (pending work B-02: the
> late reset dropped the next genuine session even when the engine was not locked). Tests: `SessionAbandonTests`.
> QrDiode is now on **protocol v2** (frame MAC, counter run id, no plaintext hash in the manifest).

The design, kept for reference. `sourcecode/qrdiode/src/QrDiode.Core/Pipeline/ReceiveEngine.cs`, `FeedManifest`:

```csharp
// Already locked onto a session? Ignore repeats of it, and ignore other sessions.
if (_manifest is not null)
    return FeedResult.Ignored;
```

If the camera misses part of session A and the sender moves on, sessions B, C, D… are ignored forever, silently.
Proposed fix:

- repeats of the **current** session are still ignored (cheap session-tag comparison);
- a **different** manifest that passes parse + signature + addressed-to-us + not-already-settled + anti-replay
  (`Fresh`) **abandons** the partial session: mark it settled, raise a `SessionAbandoned` event carrying an
  `AbandonedSession` record, and lock onto the new one. A forged frame cannot force this, because the signature is
  checked first. Nor can a replayed recording, because the anti-replay check comes before the abandon;
- while locked, a different manifest that fails any check returns `Ignored`, **not** `Rejected`. The Receiver calls
  `engine.Reset()` after every rejection (`HandleRejection`), so a `Rejected` would drop the session after all;
- `SessionAbandoned` is raised outside the engine's lock, and the Receiver handles it with `Dispatcher.BeginInvoke`;
- the Receiver UI adds an "Incomplete … NOT received — must be re-sent" inbox row and a `receive.abandoned` audit
  event, without resetting the engine.

**Done when** (met 26 Nov): the new regression tests in `sourcecode/qrdiode/tests/QrDiode.Core.Tests/SessionAbandonTests.cs` pass, and all 75 existing
tests still pass. The new tests cover: a partial session followed by a new one → the new one completes; a forged or a
replayed manifest while locked → ignored, no abandon. Copilot prompt: `/fix-receive-engine-bug`.

### 2.2 Data model additions (`QrBridge.Shared`)

> **Built 27 Nov 2026** (decisions 52, 54): `BundleId` and `QrSessionId` on both tables (in `BaseMessage`), index
> `IX_Outbox_Bundle`; `OutboxRepository.ClaimBundleAsync` / `MarkAiredAsync(bundleId, qrSessionId)` /
> `ReleaseBundleAsync`, `ResetSendingAsync` clears the bundle; `InboxRepository.AddMessagesAsync` (one `BEGIN IMMEDIATE`
> transaction, idempotent, a re-arrival owed a Receipt again and given the latest bundle ids). Migrations `Initial` and
> `Bundles` in `Data/Migrations`; an older file is adopted after its schema matched a migration exactly
> (`SchemaAdoption`), otherwise refused. Tests: `BundleRepositoryTests`, `MigrationTests`. The text below is the design,
> kept for reference.

The additions and method signatures below depend on the bundle decision in §2.3.

| Table | Add | Why |
|---|---|---|
| `Outbox` | columns `BundleId` (TEXT NULL), `QrSessionId` (TEXT NULL). **No new status and no `AiredUtc`:** since 24 Nov 2026 (V6 fix step 5a) each row has a light group (`LightStatus` `Pending`/`Sending`/`Aired`/`Received`/`Failed`, `LightUpdatedUtc`) and a service group (`ServiceStatus` `Waiting`/`Answered`/`Unknown`/`Refused`/`Expired`/`NotDelivered`/`Rejected`; `NotAvailable` is in the enum but never set) (decision D24). `Aired` exists but nothing sets it yet; `Received` and the service outcomes are set by the gateway when a Receipt or Reply arrives (`AnswerReader`, tracker step 10a) | QrDiode is one-way, so "sent" means "aired" until receipts exist; trace a row to its QR session |
| `Inbox` | `BundleId`, `QrSessionId` | trace a row to the QR session that carried it |

V6 fix step 5b (done 24 Nov 2026) already added `MarkAiredAsync(messageIds)`, `MarkAnsweredAsync`, the columns `Kind`,
`CorrelationId`, `ContentFingerprint`, `ExpiresUtc` (both tables) and `ReplyContentType` / `ReplyBody` (Outbox). V6 fix
step 9b (done 24 Nov 2026) added the Inbox column `ReceiptDueUtc` and header version 5 (`BRG5`), and the gateway now
writes **Receipt** and **Reply** rows into its own Outbox (a Receipt for every arrived message, a Reply for every final
outcome of a Request). V6 fix step 14 (done 25 Nov 2026, D73) added the `Priority` column to both tables (a number
0–3: `Answer`, `High`, `Normal`, `Low`) and header version 6 (`BRG6`; `BRG3`–`BRG5` refused). V6 fix step 17
(done 25 Nov 2026, D80–D84) added the message kind **`Heartbeat`** (an empty
message the gateway queues when its side has sent nothing for `Gateway:HeartbeatMinutes`, priority `Answer`, with a
sequence number), header version 7 (`BRG7`; `BRG3`–`BRG6` refused) and the Inbox-side table `SequenceWatermark`.
On 25 Nov 2026 the two files `send.db` and `received.db` became **one, `qrbridge.db`** (handoff decision 47), with the
same tables; the QR apps will open it through `BridgeDbContext`. The gateway refuses to start while a former file is
still in the data folder.
Old development databases may need recreation; preserve any data that must be kept. What that means for the QR apps
— not built yet:

- The **QR Sender** must air Receipt, Reply and Heartbeat rows **like any other row**: same claim, same bundles, same
  `MarkAiredAsync` (so a Heartbeat row ends `Aired`). It never needs to look at `Kind`.
- The **QR Receiver** stores arriving Receipts, Replies and Heartbeats in the Inbox like any other message, with
  `InboxRepository.AddMessageAsync` (it copies `Kind`, `CorrelationId`, `SequenceRunId` and, since step 14, `Priority`). Besides skipping a
  `MessageId` that is already there, `AddMessageAsync` **owes it a Receipt again** (`ReceiptDueUtc` = now; never for a
  Receipt or a Heartbeat): a message
  that arrives twice was re-aired because its first Receipt was lost. The planned `AddMessagesAsync` (below) must
  keep both behaviours. Nothing else is needed for Heartbeats: the gateway reads them (`AnswerReader`) and uses their
  arrival for "far side last heard" and for finding a lost last message.
- **A Receipt never gets a Receipt** (otherwise the two sides would confirm each other forever), and neither does a
  Heartbeat. So a Receipt or Heartbeat row is
  done once aired. *Built 24 Nov 2026 (V6 fix step 11, D65–D67), in the gateway:* `MaintenanceWorker` re-airs `Aired`
  rows whose Receipt never came (`OutboxRepository.ReairUnconfirmedAsync`) and skips Receipt (and, since step 17,
  Heartbeat) rows; an aired Receipt or Heartbeat
  row stays `Aired` and does not count as unconfirmed. Reply rows are re-aired (a Reply gets a Receipt).

Build each thing once.

Store methods to add:

- `OutboxRepository.ClaimBundleAsync(maxMessages, maxBytes)` — in one transaction, `UPDATE Outbox SET LightStatus='Sending',
  BundleId=@b, LockedUtc=now WHERE MessageId IN (the first Pending rows within the limits) AND LightStatus='Pending'`, returning the
  claimed rows in the same order as `ClaimNextAsync` since step 14: Receipts, Replies and Heartbeats (`Answer`) first, then
  `High`, `Normal`, `Low`, lowest `Sequence` within a class (index `IX_Outbox_LightStatus (LightStatus, Priority, Sequence)`).
- `OutboxRepository.MarkAiredAsync(bundleId, qrSessionId)`: `LightStatus` `Sending` → `Aired`. *Since 24 Nov (V6 step 5b)
  `MarkAiredAsync(messageIds)` exists (only rows still `Sending`; sets `LightUpdatedUtc`, so no `AiredUtc` column is
  needed); this step adds the bundle and session ids.*
- `OutboxRepository.ReleaseBundleAsync(bundleId, reason, retryDelay)`: back to `Pending`, due again after `retryDelay`,
  reason in `LightComment`. Use zero after a stage close or an operator skip, and about 30 s after an encode error, so
  a broken bundle cannot spin.
- `ResetSendingAsync` already exists: call it at Sender startup, and make it also clear `BundleId`.
- `InboxRepository.AddMessagesAsync(messages, bundleId, qrSessionId)` — **one** transaction, idempotent on
  `MessageId` (duplicates skipped, not failed, and owed a Receipt again, like `AddMessageAsync`).
- No retention step: since 24 Nov rows are **never deleted automatically** (decision D28: an Inbox row is what stops a
  replayed `MessageId`, and the lost-message check needs every number). `Aired` rows stay until receipts move them to
  `Received`; operators archive rows manually.

The CHECK constraints are generated from the enums (`SqlIn(..., Enum.GetNames<OutboxLightStatus>())` and the other
three status enums), so adding a status changes the schema; this step adds none. Create the **first EF migrations**
here, for the one context `BridgeDbContext` (`dotnet ef migrations add …`; the design-time factory
`BridgeDesignTimeFactory` is in `Data/Contexts/`):
1. `Initial`, from the current model **before** changing it;
2. then one migration for the new columns.

`DatabaseInitializer` already applies migrations when they exist. A database made by `EnsureCreated` has tables
but no migration history, so `Initial` would fail on it. Plan and test a safe upgrade for existing databases:
verify the actual schema before baselining; the mere existence of tables is not proof that they match the baseline.
Never delete production databases or mark a mismatched schema as migrated. Dev databases may be recreated when safe.

**Done when:** store tests cover claim/aired/release/idempotent insert; the migration applies to a fresh database
and to each supported, verified existing schema without losing data.

### 2.3 Bundles — many messages per QR session

> **Built 27 Nov 2026** (decision 52, Rowshan): up to **50 messages / 128 KB**, filled in **strict claim order** (stop
> at the first message that does not fit; a single bigger message goes alone). `QrBridge.Shared/Bundles/BundleCodec.cs`:
> `"QBB1"` · version · **bundle id** (so both sides' rows share it) · count · min/max sequence (display only) · entries.
> The parser accepts up to 1,000 messages and envelopes up to `MaxPayloadBytes` + header and framing, so a receiver
> never refuses a sender's own limits. Tests: `BundleCodecTests`.

Why: one message per QR session costs at least 6 s of air time plus a 1.5 s gap (`TransmitEngine.MinAirSeconds`,
`GapSeconds`) — about 8 messages per minute per lane, too slow for a burst of FMS events.

**Decision required:** bundling, ordering and size limits still need Rowshan's approval. The following format
and limits are a starting proposal, not a committed protocol. Resolve these issues before implementation:

- The gateway's default request limit is 1,000,000 bytes, larger than the proposed 128 KB bundle limit. Define
  how a valid larger envelope is sent without dropping it or permanently blocking the queue.
- Priority-based claiming does not guarantee that sequence numbers are consecutive or increasing within a
  bundle. Do not treat `firstSeq`/`lastSeq` as a complete range of messages.
- Confirm maximum serialized envelope size, framing overhead, QR session capacity, and whole-bundle rejection
  and retry behaviour against the actual code and hardware.

Proposed `QrBridge.Shared/Bundles/BundleCodec.cs`:

```
magic "QBB1" (4) · version (1) · count (uint16) · firstSeq (int64) · lastSeq (int64)
repeat count × { length (int32) · envelope bytes }
```

- The parser is bounded: `count ≤ MaxBundleMessages`, each `length ≤ MaxPayloadBytes` + the 64 KB header limit and framing,
  the lengths must add up exactly to the remaining bytes. Any mismatch rejects the whole bundle, without throwing
  anything but `InvalidDataException`.
- The QrDiode session's filename is `bundle-{firstSeq}-{lastSeq}.qbb`, content kind `File`.
- Example limits (not approved): `MaxBundleMessages` 50, `MaxBundleBytes` 128 KB. A lone message still goes out at once;
  bundling only happens when several rows are waiting.

**Done when:** round-trip tests pass, and malformed, truncated or oversized input is rejected cleanly. Copilot prompt
for §2.2 + §2.3: `/add-bundles-and-outbox-status`.

### 2.4 Sender: read the Outbox

> **Built 27 Nov 2026** (decision 53): `"QrDiode:Mode": "Bridge"` in the Sender's `appsettings.json` plus the gateway's
> `"Bridge"` section. `QrAppBridge.OpenAsync` (in `QrBridge.Shared`) is the small composition root; `Transmit/OutboxSource.cs`
> is the loop (doorbell + 2 s poll, claims only when the engine queue is empty and the stage is open, `ResetSendingAsync` at
> start, heartbeat `SenderLoop` every 30 s); `TransmitEngine.ItemFinished` writes every outcome back. Bundle limits in the
> `"Sender"` section. The simulator and manual file stay for `"Mode": "Standalone"`. End-to-end through the bundle code:
> `BundleLightTests`. The text below is the design, kept for reference.

The Sender is a plain WPF app (no generic host). Give it a small composition root: a `ServiceCollection` with
`AddBridgeData(options)`, logging and `BridgeSignals`; read `Bridge:Side` and `Bridge:DataFolder` from an
`appsettings.json` next to the exe (new; `CopyToOutputDirectory`), and run `DatabaseInitializer.InitializeAsync` at
startup. Keep the existing QrDiode settings and keys under `%LocalAppData%\QrDiode\` as they are.

- **Source switch:** `Sender:Source = Outbox | Simulator`. An `OutboxSource` replaces `LiveSource` when `Outbox`;
  the simulator stays for demos and the bench.
- **Claiming:** claim a bundle (§2.2) **only when the `TransmitEngine` queue is empty**, so at most one bundle waits
  behind the one on air. Check `QueuedCount == 0` on the UI thread: the engine and its queue belong to it. Enqueue it with `TransmitEngine.Enqueue(type, "bundle-….qbb", bundleBytes)`.
- **`TransmitEngine`:** never drop Outbox items. *Since 26 Nov `TrimQueue` only skips `QueueItem.Droppable` items
  (the simulator's); enqueue Outbox bundles with the default `droppable: false`.*
  `SessionEnded` fires only for items that went on air. So add an `ItemFinished` event raised for **every** final
  state, including an encode failure and a stage closed during encoding. On it:
  - `Sent` → `MarkAiredAsync(bundleId, sessionId)`;
  - `Skipped` → `ReleaseBundleAsync(…, TimeSpan.Zero)`;
  - `Failed` → `ReleaseBundleAsync(…, ~30 s)`.
- **Startup:** `ResetSendingAsync` (rows left in light status `Sending` by a crash go back to `Pending`).
- **Every kind of row:** callers' Requests and this side's Receipts and Replies (written by the gateway since V6 fix
  step 9b) and Heartbeats (since step 17) are aired the same way, by the claim's order, and marked `Aired`.
- **Priorities need no Sender change:** since V6 fix step 14 (25 Nov 2026, D73) `OutboxRepository.ClaimNextAsync`
  takes Receipts, Replies and Heartbeats first, then the classes High (permits, orders, cards), Normal (queries), Low (feeds),
  lowest `Sequence` within a class. The Sender just claims; the bundle claim (§2.2) keeps the same order. Not tried
  with a real Sender yet.
- **Re-air needs no Sender change:** since V6 fix step 11 (24 Nov 2026) the gateway's `MaintenanceWorker` puts an
  `Aired` row with no Receipt after `Gateway:ReceiptTimeoutSeconds` (120) back to `Pending`, so the Sender just claims
  it again (in claim order). After `Gateway:MaxAirAttempts` (3) airs — counted by `Attempts`, one per claim —
  or once expired, the gateway sets light `Failed` instead. Not tried with a real Sender yet; the effect on light
  capacity under load is not measured.
- **Wake-up:** wait on the Outbox doorbell (`BridgeSignals.Outbox`), with a 2 s poll as fallback.
- **Heartbeat:** `Components.SenderLoop` every 30 s (shown by the gateway's `/health`).
- **Never block the UI thread:** all database work is `async`; UI updates go through the Dispatcher
  (see [wpf-tutorial.md](../../sourcecode/qrdiode/docs/wpf-tutorial.md) §4).

**Done when:** a SOAP call to the gateway shows on the stage within about a second and its row ends light status `Aired`
(service status stays `Waiting`); killing
the Sender mid-session re-airs the bundle after restart; 200 concurrent calls air as bundles; nothing is dropped.
Copilot prompt: `/connect-sender-to-outbox`.

### 2.5 Receiver: write the Inbox

> **Built 27 Nov 2026** (decision 53): in Bridge mode the engine accepts files only when they are `.qbb`; `HandleCompletion`
> sends a bundle to `HandleBundleAsync` **before** the "same content" check (B-06): `InboxBundleWriter.StoreAsync` (parse,
> direction check, one transaction, doorbell), then `CommitReplay()`; a refused bundle is settled (the same bytes would
> fail again), a failed write uses `Reset(settle: false)`. Nothing of the payload is kept in the Receiver (S-06). XML/JSON
> payloads are refused in Bridge mode. Heartbeat `ReceiverLoop` every 30 s while receiving. Packages aligned (known issue 4).
> Tests: `QrAppBridgeTests`, `BundleLightTests`. The text below is the design, kept for reference.

In `sourcecode/qrdiode/src/QrDiode.Receiver/MainWindow.xaml.cs`, `HandleCompletion`, before the existing journal/archive code:

```
if filename ends with ".qbb":
    bundle = BundleCodec.Parse(plaintext)                    -- fail → rejection row + audit event
    for each envelope: header = MessageSerializer.PeekHeader(envelope)
                       require header.Direction == this side's inbound direction
    InboxRepository.AddMessagesAsync(all, bundleId, sessionId)    -- ONE transaction, idempotent; a duplicate is owed a Receipt again
    BridgeSignals.Inbox.Set()                                -- wake the gateway worker
    journal + audit + inbox UI row ("bundle 1042–1061, 20 messages")
    do NOT write the payload store: the Inbox is the store (one copy of each payload on disk; not encrypted — decision 23)
```

The bundle may hold Requests, Receipts, Replies and Heartbeats from the other side: store them all the same way. The gateway
decides what to do with each kind (it posts only Requests; it reads Receipts, Replies and Heartbeats with
`AnswerReader`, steps 10a and 17; it sends a Receipt for everything except a Receipt or a Heartbeat).

**Anti-replay commit order:** *built 26 Nov 2026 in the engine.* `ReceiveEngine` returns the completed transfer
**without** committing; the host calls `engine.CommitReplay()` after the Inbox transaction (today, for files, after
the payload store write). The Inbox insert is idempotent, so the worst case after a crash is a re-aired bundle whose
rows are skipped as duplicates. If the Inbox write fails, don't commit: `engine.Reset(settle: false)`, so the session
can still be received while the sender is airing it. `HandleCompletion` already does this for files.

**Two traps** (pending work B-06, S-06): the `.qbb` branch must run **before** the existing `IsDuplicateContent`
check (which drops a payload whose plaintext was ever stored — a re-aired bundle can be byte-identical, and must
still reach `AddMessagesAsync` so it is owed a Receipt again); and for bundles write no payload store, no `.meta.json`,
no journal snippet and no preview (gateway payloads are never logged). Set `"AllowOpaqueFiles": false` in the
Receiver's `appsettings.json` once bundles are the only traffic, and accept a `File` only when it is a `.qbb` that
`BundleCodec` parses.

Also: same composition root as the Sender; heartbeat `Components.ReceiverLoop`; **align packages** — the Receiver pins
`Microsoft.Data.Sqlite` 10.0.10 and `SQLitePCLRaw.bundle_e_sqlite3` 3.0.5, while EF Core 10.0.15 brings SQLitePCLRaw
2.1.13. One native SQLite per process: move the Receiver to the same `Microsoft.Data.Sqlite` as EF and let EF's
SQLitePCLRaw win (check the Receiver's own journal still works).

**Done when:** end to end on one PC (screen + webcam, or an optical loopback test): a call to the Corp gateway reaches
`Done` on the DMZ gateway; a duplicate bundle is not processed twice. Copilot prompt: `/connect-receiver-to-inbox`.

### 2.6 Unattended (kiosk) operation

> **Built 27 Nov 2026:** `"Sender": { "AutoStart": true, "Endpoint", "Receiver" }` opens the keys, picks the receiver and
> opens the stage where the operator last put it (`%LocalAppData%\QrDiode\sender-stage.json`); `"Receiver": { "AutoStart":
> true, "Endpoint", "Camera", "StrictMode" }` opens the keys, picks the camera by name and starts. In Bridge or kiosk
> mode Esc on the stage asks before stopping a session on air. The scheduled tasks are set up by hand (guide §12.4).
> Not tried on a real kiosk.

- Both apps start without clicks: keys and peer from configuration, the stage on the configured monitor at the saved
  size, the saved camera.
- No kiosk script any more (`deploy/` removed): register two scheduled tasks (Sender, Receiver) for the kiosk user by
  hand, or add a script again if you prefer.
- Run the apps **as the kiosk user**: QrDiode's keys and state are per Windows user (`%LocalAppData%`, CNG user store).

### 2.7 Possible future QR Station app

Each machine has a screen facing out and a camera facing in, so a single WPF "QR Station" running both engines would
make it exactly two programs per machine (gateway + station). This would change the current Sender/Receiver project
structure and deployment, so **do not merge or restructure them without asking Rowshan**. It is not needed for the
first end-to-end test.

---

## 3. Islanding operations

### 3.1 Switch in

Point the corporate load balancer at the Corp gateway, and the FMS outbound clients at the DMZ gateway. Everything is
already running (IIS AlwaysRunning, kiosk auto-start), so nothing has to start.

### 3.2 Switch back — without reordering

Queued messages must not arrive *after* newer ones sent over the restored network:

1. **Stop accepting** on both gateways (new admin endpoint, e.g. `POST /admin/stop-accepting`, protected): sender
   then answers with the `Busy` reply profile.
2. Wait until **both** sides are drained: Outbox has no light `Pending`/`Sending` rows (and the last bundle has been
   aired), Inbox has no service `Pending`/`Delivering`/`Retrying` rows.
3. Flip the load balancer and the DMZ configuration back.
4. Handle any Inbox `Refused` / `Unknown` / `NotDelivered` / `Rejected` and Outbox `Failed` rows by hand, and any
   missing messages `/health` reports (`gaps`): find out what was lost, then acknowledge the gap.

### 3.3 `/status`

Per side: queue depth per route, oldest undelivered age, light problems (Outbox `Failed`, Inbox `Rejected`) and service
problems (Inbox `Unknown`/`Refused`/`NotDelivered`) with the real service's `ERROR_MESSAGE`, heartbeat staleness of
gateway, sender and receiver, and a `drained` flag for step 2 above. (`/health` already shows the light and service
counts and `lightProblems` / `serviceProblems` since 24 Nov, and since the same day the oldest undelivered row of each
queue, `catalogFingerprint`, `missingMessages` and `gaps`; missing messages count as light problems.) Each side is
monitored on its own network; nothing crosses the gap for monitoring.

### 3.4 Two sites (ECC primary, AECC standby)

Each site's gateway and QR apps have their own database (`qrbridge.db`) and keys, and appear in the peers' trust stores. Open: do
queued rows move on failover (recommended: no — they go out when ECC returns); must Inbox deduplication span both
sites (yes, if both deliver into the same RR servers); is AECC warm or cold (recommended: warm).

**Done when:** a scripted switch-in / switch-back drill on test servers loses and reorders nothing.

---

## 4. Remaining gateway items

| Item | Design |
|---|---|
| **Ordering** | *Built 25 Nov 2026 (V6 fix tracker step 14, D73, D74):* the receiving gateway runs one delivery loop per priority class (High, Normal, Low), so a slow feed never holds back a permit. Inside a class it delivers by run of the sender's counter (in the order the runs started), then `Sequence`, and keeps **strict order per service**: a Request is not claimed while an earlier Request of the same service and class is `Retrying`; other services and classes go on. *Not built:* an optional `OrderingKey` per operation in `routes.json` (e.g. the XPath `//FMS_ORDER_NUMBER \| //FMS_CARD_ID`, evaluated on the payload), so that only rows with the same key wait behind a retrying row — head-of-line blocking per order instead of per service, so one stuck order doesn't stall the other orders of that service. |
| **Record mode** | `Gateway:Mode = Record` turns the Sender part into a transparent proxy to `Record:UpstreamUrl`: forwards the request, returns the real reply, and saves request + reply (path, headers, body) under the data folder. Never writes the Outbox; refused while islanded. The easiest way to capture the DMZ → Corp contracts and real reply texts. |
| **Answers for queries** | The round trip is built on the gateways (tracker step 10a) for the `RoundTrip` routes in `routes.json` — the caller is held for the real answer, and a query gets "not available" when the hold runs out (permits, orders and cards use the same round trip since step 10c, with 1596 instead). Carrying requests and answers through the QR apps remains unfinished (§2). Only unfinished integration, unresolved service coverage and missing deployment inputs are listed in [uncovered-services.md](../../sourcecode/gateway/docs/reference/uncovered-services.md). Snapshot idea: the far side periodically sends snapshots (authorised users, feeder list, registered tags) over the light, and the gateway answers queries from them. Needs its own approval. |
| **DMZ → Corp catalogue** | The 11 services the DMZ interface services call are in `routes.json` with `"SenderSide": "Dmz"` (derived from their client proxies). Still to do: confirm their paths on the DMZ load balancer and their contracts (record mode would capture both), and fill `appsettings.Corp.json` `Receiver` with the corporate hosts. |
| **Delivery receipts (D14)** | *Writing them is built (V6 fix step 9b, D44):* the receiving gateway writes a Receipt (`Kind = Receipt`, `CorrelationId` = the stored message) into its own Outbox for every arrived message, and again when the same `MessageId` arrives twice; they cross back as ordinary messages, not as separate QrDiode sessions. *Reading them is built (tracker step 10a):* the sending gateway's `AnswerReader` moves the Outbox row's light status to `Received` (`MarkReceivedAsync`; a Reply does the same through `MarkAnsweredAsync`). *Re-airing unconfirmed `Aired` rows is built (tracker step 11, D65–D67):* `MaintenanceWorker` puts them back to `Pending` after `Gateway:ReceiptTimeoutSeconds`, then light `Failed` after `Gateway:MaxAirAttempts` airs or once expired; Receipt and Heartbeat rows are never re-aired, because neither gets a Receipt. **Not built:** carrying them (§2.4–§2.5). The two-way link needs security sign-off. |
| **Lost messages (G-02)** | *Detection built 24 Nov (D27, D29, D30):* each message carries its sequence number and the run id of the sender's counter; the receiving gateway reports missing numbers per run (`SequenceGapMonitor`, `/health`), and an operator acknowledges a gap (`InboxRepository.AcknowledgeGapAsync`, table `AcknowledgedGap`; no UI yet). *Re-airing built 24 Nov in the gateway (V6 fix tracker step 11):* the sending side re-airs a message with no Receipt (above). On real hardware it starts once the QR Sender sets `Aired` (§2.4); proven only with in-memory gateways and a fake light. *Built 25 Nov (V6 fix tracker step 17, D80, D84):* an idle side's Heartbeat takes a sequence number, so a lost **last** message becomes a gap once the Heartbeat after it arrives; a message whose number another message already has, or whose number is at or below the run's `SequenceWatermark` (an archived message shown again), is `Rejected`. |

---

## 5. Order of work

The record-mode, snapshot, per-order ordering and administration ideas above are **not approved requirements**.
Any proposed record mode must first be reviewed against the Outbox-only ingress rule, caller compatibility,
payload handling and security. Do not implement them solely because they appear in this plan.

| # | Step | Done when |
|---|---|---|
| 1 | §2.1 receiver fix — **done 26 Nov 2026** (with protocol v2 and the other QrDiode fixes) | 113 QrDiode tests pass, `SessionAbandonTests` included |
| 2 | Agree bundle/ordering rules, then §2.2 data model + migrations and §2.3 bundle codec — **done 27 Nov 2026** | store and codec tests pass, including oversized valid messages; migration applies safely to fresh and supported existing DBs — met (`BundleRepositoryTests`, `BundleCodecTests`, `MigrationTests`, copies of both dev databases) |
| 3 | §2.4 Sender — **built 27 Nov 2026** | gateway call on the stage within ~1 s, row light status `Aired`; crash re-airs; nothing dropped — in code; **not tried on a screen** |
| 4 | §2.5 Receiver — **built 27 Nov 2026** | end to end on one PC reaches Done on the far gateway; duplicates skipped — proven with in-memory gateways (`BundleLightTests`); **not tried with a camera** |
| 5 | §2.6 kiosk (**built 27 Nov 2026**), §3 islanding operations | switch-in / switch-back drill clean |
| 6 | §4 items | per item |
| 7 | Hardening and rollout | load test (2–3× peak), 48–72 h soak, failure tests (camera blocked, app killed mid-message, IIS recycle under load, wrong key, oversized payload, real service down), reconciliation, one service at a time behind the LB |

After each step:
1. run `dotnet test All.slnx`;
2. update [../handoff.md](../handoff.md) (state, known issues, next steps) and the known-issues list in
   `.github/copilot-instructions.md`. The Copilot prompt `/update-handoff` does this.
