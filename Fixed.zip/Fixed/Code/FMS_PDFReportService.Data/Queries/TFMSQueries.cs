namespace FMS_PDFReportService.Data.Queries
{
    /// <summary>
    /// SQL query constants for TFMS/TOMS card data retrieval.
    /// Ported from CardTFMS_ASE, Job_ASE, CardLogClass_ASE, WorkPermit_ASE.
    /// </summary>
    public static class TFMSQueries
    {
        public const string LoadCardHeader = @"
            SELECT C.Card, C.CardNumber, C.Description, C.FeederNames
            FROM   TFMS_Card C
            WHERE  C.Card = ?";

        public const string LoadCardHeaderArchive = @"
            SELECT C.Card, C.CardNumber, C.Description, C.FeederNames
            FROM   TFMS_ArchiveCard C
            WHERE  C.Card = ?";

        // CardSOA.LoadCard (cac.dmt), active TFMS card: class, cut out/in, note, status come from SOA_Card.
        public const string LoadSoaCard = @"
            SELECT S.CardClassName, S.CutOut, S.CutIn, S.Note,
                   S.Status, S.Activated, S.Closed
            FROM   SOA_Card S
            WHERE  S.Card = ?";

        // CardSOA.LoadCard, archived TFMS card: same fields from TFMS_ArchiveCard (no Note on archive, as OpenROAD).
        public const string LoadSoaCardArchive = @"
            SELECT C.CardClassName, C.CutOut, C.CutIn,
                   C.Status, C.Activated, C.Closed
            FROM   TFMS_ArchiveCard C
            WHERE  C.Card = ?";

        // ItemCategory_ASE.LoadEquip (cac.dmt): equipment on the card linked to an active information item.
        // ORDER BY matters: the first row per Equip is the one used (TfmsRowRules.FirstSeverityPerEquip).
        public static readonly string LoadInfoItemEquipSeverity = @"
            SELECT E.Equip AS Equip,
                   I.Severity AS Severity
            FROM   SLC_InformationItemEquip E,
                   SLC_InformationItem I,
                   SOA_Job J,
                   SOA_JobControl JC,
                   SOA_Job J2
            WHERE  JC.Card = ? AND
                   JC.Job = J.Job AND
                   J.Equip = E.Equip AND
                   E.Job = I.Job AND
                   I.Job = J2.Job AND
                   J2.MoveCategory = " + FMS_PDFReportService.Models.Constants.MoveCategory_InformationItem + @" AND
                   J2.SwItemStatus = " + FMS_PDFReportService.Models.Constants.Card_Active + @"
            ORDER BY 1, 2";

        // WorkPermit_ASE.LoadSOA_WP (cac.dmt), active card. Parameters: Card, PermitType (StepPair).
        // PermitType = StepHeading_WorkPermit (600) or StepHeading_TestPermit (650).
        public static readonly string LoadPermits = @"
            SELECT J.Job, J.Status, J.JobClass,
                   JC.Card, JC.Seq,
                   J.Equip, J.EquipClass, J.EquipClassName,
                   JC.MoveEquipClass, JC.PrintID,
                   J.EquipName,
                   O.Name AS Subsordesk,
                   J.Substation,
                   JC.StepPair,
                   J.TOMove, J.TOIssued, J.TOComplete,
                   J.RSMove, J.RSIssued, J.RSComplete,
                   J.MoveFGColor,
                   1 AS IsWorkPermit
            FROM   SOA_Job J,
                   SOA_JobControl JC,
                   Udb_Object O
            WHERE  JC.Card = ? AND
                   JC.StepPair = ? AND
                   JC.Job = J.Job AND
                   J.Status IN ('', '" + FMS_PDFReportService.Models.Constants.JobStatus_NIS + "', '" + FMS_PDFReportService.Models.Constants.JobStatus_Table + @"') AND
                   J.MoveCategory = " + FMS_PDFReportService.Models.Constants.MoveCategory_Normal + @" AND
                   J.Substation = O.Object
            ORDER BY JC.Seq";

        // WorkPermit_ASE.LoadSOA_WP, archived card. Parameters: Card, PermitType (StepPair).
        public static readonly string LoadPermitsArchive = @"
            SELECT J.Job, J.Status, J.JobClass,
                   J.Card, J.Seq,
                   J.Equip, J.EquipClass, J.EquipClassName,
                   J.EquipClass AS MoveEquipClass, J.PrintID,
                   J.EquipName,
                   O.Name AS Subsordesk,
                   J.Substation,
                   J.StepPair,
                   J.TOMove, J.TOIssued, J.TOComplete,
                   J.RSMove, J.RSIssued, J.RSComplete,
                   1 AS IsWorkPermit
            FROM   SOA_ArchiveJob J,
                   Udb_Object O
            WHERE  J.Card = ? AND
                   J.StepPair = ? AND
                   J.Status = '' AND
                   J.MoveCategory = " + FMS_PDFReportService.Models.Constants.MoveCategory_Normal + @" AND
                   J.Substation = O.Object
            ORDER BY J.Seq";

        public const string LoadChecklist = @"
            SELECT CL.Card, CL.Desk,
                   CL.PermitsReturned, CL.GroundsRemoved,
                   CL.DisconnectsClosed, CL.HSGSReset,
                   CL.RelaySysNormal, CL.OilPresNormal,
                   CL.EquipCanBeEnerg, CL.EquipPrepForServ,
                   CL.CheckedStnLogCrd, CL.AmmeterClearPerf,
                   CL.AcceptanceLetter
            FROM   TFMS_CheckList CL
            WHERE  CL.Card = ?";

        public const string LoadChecklistArchive = @"
            SELECT CL.Card, CL.Desk,
                   CL.PermitsReturned, CL.GroundsRemoved,
                   CL.DisconnectsClosed, CL.HSGSReset,
                   CL.RelaySysNormal, CL.OilPresNormal,
                   CL.EquipCanBeEnerg, CL.EquipPrepForServ,
                   CL.CheckedStnLogCrd, CL.AmmeterClearPerf,
                   CL.AcceptanceLetter
            FROM   TFMS_ArchiveCheckList CL
            WHERE  CL.Card = ?";

        public const string LoadPrepBy = @"
            SELECT CP.Desk, O.Name AS DeskName,
                   CP.PreparedBy, CP.CheckedBy
            FROM   TFMS_CardPrepBy CP,
                   Udb_Object O
            WHERE  CP.Card = ? AND
                   CP.Desk = O.Object
            UNION
            SELECT CP.Desk, 'OldDataNoDesk' AS DeskName,
                   CP.PreparedBy, CP.CheckedBy
            FROM   TFMS_CardPrepBy CP
            WHERE  CP.Card = ? AND CP.Desk = 1";

        public const string LoadPrepByArchive = @"
            SELECT CP.Desk, O.Name AS DeskName,
                   CP.PreparedBy, CP.CheckedBy
            FROM   TFMS_ArchiveCardPrepBy CP,
                   Udb_Object O
            WHERE  CP.Card = ? AND
                   CP.Desk = O.Object
            UNION
            SELECT CP.Desk, 'OldDataNoDesk' AS DeskName,
                   CP.PreparedBy, CP.CheckedBy
            FROM   TFMS_ArchiveCardPrepBy CP
            WHERE  CP.Card = ? AND CP.Desk = 1";

        public const string LoadCardObjects = @"
            SELECT CTO.Object, CTO.Name, CTO.Status AS ObjectStatus, CTO.ValidatedBy,
                   O.Type AS ObjectType, O.TypeName
            FROM   TFMS_CardToObject CTO,
                   Udb_Object O
            WHERE  CTO.Card = ? AND
                   CTO.Object = O.Object";

        public const string LoadCardObjectsArchive = @"
            SELECT CTO.Object, CTO.Name, CTO.Status AS ObjectStatus, CTO.ValidatedBy,
                   O.Type AS ObjectType, O.TypeName
            FROM   TFMS_ArchiveCardToObject CTO,
                   Udb_Object O
            WHERE  CTO.Card = ? AND
                   CTO.Object = O.Object";

        public const string LoadJobs = @"
            SELECT J.Job, SJ.Card, SJ.Seq,
                   J.Status, J.JobClass,
                   J.Equip, J.EquipClass, J.EquipClassName, J.EquipName,
                   SJ.StepPair, J.Grounds, J.MoveType,
                   J.TOMove, J.TOMoveRules, J.TOOperator, J.TOIssued, J.TOComplete,
                   J.GroundOn,
                   J.RSMove, J.RSMoveRules, J.RSOperator, J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   SJ.MoveEquipClass,
                   J.Substation, O.Name AS SubstationName,
                   O.PrimaryGroupingName, O.Type AS StructureType,
                   J.ShadowLink, J.MoveCategory,
                   SJ.StepLevel, J.ControlCard,
                   J.MoveFGColor, J.MoveBGColor, J.DeskName
            FROM   SOA_Job J,
                   SOA_JobControl SJ,
                   Udb_Object O
            WHERE  SJ.Card = ? AND
                   SJ.Job = J.Job AND
                   J.Substation = O.Object AND
                   J.Status <> 'Del'
            ORDER BY SJ.StepPair, SJ.StepLevel, SJ.Seq";

        public const string LoadJobsArchive = @"
            SELECT J.Job, J.Card, J.Seq,
                   J.Status, J.JobClass,
                   J.Equip, J.EquipClass, J.EquipClassName, J.EquipName,
                   J.StepPair, J.MoveType,
                   J.TOMove, J.TOOperator, J.TOIssued, J.TOComplete,
                   J.RSMove, J.RSOperator, J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   J.Substation, J.MoveCategory, J.StepLevel,
                   J.MoveFGColor, J.MoveBGColor,
                   0 AS Grounds, ? AS ControlCard
            FROM   SOA_ArchiveJob J
            WHERE  J.Card = ? AND
                   J.Status <> 'Del'
            ORDER BY J.StepPair, J.StepLevel, J.Seq";

        public const string LoadCardLog = @"
            SELECT CL.Card, CL.SwitchingItem, CL.Log,
                   CL.LogStatus, CL.LogTime,
                   CL.EnteredBy, O.Description AS EnteredByName
            FROM   SOA_CardLog CL,
                   Udb_Object O
            WHERE  CL.Card = ? AND
                   CL.EnteredBy = O.Object
            ORDER BY CL.LogTime DESC";

        public const string LoadCardLogArchive = @"
            SELECT CL.Card, CL.SwitchingItem, CL.Log,
                   CL.LogStatus, CL.LogTime,
                   CL.EnteredBy, O.Description AS EnteredByName
            FROM   SOA_ArchiveCardLog CL,
                   Udb_Object O
            WHERE  CL.Card = ? AND
                   CL.EnteredBy = O.Object
            ORDER BY CL.LogTime DESC";

        // OBSOLETE - do not use for printing. StepPair = 3 never matches a TOMS permit
        // (TOMS permits are StepPair 600 / 650), which is why "TOMS Work Permits" printed empty.
        // Kept unchanged only so nothing else that might reference it breaks. Use LoadPermits.
        public const string LoadWorkPermits = @"
            SELECT 1 AS CardType, 'TOMS' AS CardTypeName,
                   '' AS CardName, '' AS CardStatus,
                   J.Job, J.Status, J.JobClass,
                   JC.Card, JC.Seq,
                   J.Equip, J.EquipClass, J.EquipClassName,
                   JC.MoveEquipClass, JC.PrintID,
                   J.EquipName,
                   '' AS Subsordesk,
                   J.Substation,
                   JC.StepPair, J.MoveType,
                   J.TOMove, J.TOMoveRules, J.TOOperator,
                   J.TOIssued, J.TOComplete,
                   J.RSMove, J.RSMoveRules, J.RSOperator,
                   J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   J.MoveFGColor,
                   1 AS IsWorkPermit
            FROM   SOA_Job J,
                   SOA_JobControl JC
            WHERE  JC.Card = ? AND
                   JC.Job = J.Job AND
                   J.Status IN ('', 'OPC') AND
                   JC.StepPair = 3 AND
                   J.JobClass <> 0
            ORDER BY JC.Seq";

        public const string LoadWorkPermitsArchive = @"
            SELECT 1 AS CardType, 'TOMS' AS CardTypeName,
                   '' AS CardName, 'Cls' AS CardStatus,
                   J.Job, J.Status, J.JobClass,
                   J.Card, J.Seq,
                   J.Equip, J.EquipClass, J.EquipClassName,
                   0 AS MoveEquipClass, J.PrintID,
                   J.EquipName,
                   '' AS Subsordesk,
                   J.Substation,
                   J.StepPair, J.MoveType,
                   J.TOMove, '' AS TOMoveRules, J.TOOperator,
                   J.TOIssued, J.TOComplete,
                   J.RSMove, '' AS RSMoveRules, J.RSOperator,
                   J.RSIssued, J.RSComplete,
                   J.Response, J.ActivityIdentifier,
                   J.MoveFGColor,
                   1 AS IsWorkPermit
            FROM   SOA_ArchiveJob J
            WHERE  J.Card = ? AND
                   J.Status <> 'Del' AND
                   J.StepPair = 3 AND
                   J.JobClass <> 0
            ORDER BY J.Seq";
    }
}
