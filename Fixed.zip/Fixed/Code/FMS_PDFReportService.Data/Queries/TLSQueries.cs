namespace FMS_PDFReportService.Data.Queries
{
    /// <summary>
    /// SQL query constants for TLS (Telephone Line Switching) card data retrieval.
    /// Ported from TLSCard_ASE, TLSJob_ASE.
    /// </summary>
    public static class TLSQueries
    {
        public const string LoadCardHeader = @"
            SELECT Card, Circuit, Linenumber, AltLine1, AltLine2,
                   LineType, CardType, LineTypeName, RouteName,
                   TroubleCategory, TroubleCategoryName,
                   FunctionArea, FunctionAreaName,
                   ReasonForFailure, ValidatedBy,
                   ShowNote, Notes,
                   Status, Carrier, CarrierName,
                   Opened, Closed, Priority
            FROM   TC_Card
            WHERE  Card = ?";

        public const string LoadCardHeaderArchive = @"
            SELECT Card, Circuit, Linenumber, AltLine1, AltLine2,
                   LineType, CardType, LineTypeName, RouteName,
                   TroubleCategory, TroubleCategoryName,
                   FunctionArea, FunctionAreaName,
                   ReasonForFailure, '' AS ValidatedBy,
                   ShowNote, Notes,
                   Status, Carrier, CarrierName,
                   Opened, Closed, 0 AS Priority
            FROM   TC_ArchiveCard
            WHERE  Card = ?";

        public const string LoadCardNote = @"
            SELECT Note AS CardNote
            FROM   TC_CardNote
            WHERE  Card = ?";

        // TLSCard_ASE.LoadFeedersAndStations (cac.dmt), active card. Parameter: the card's Circuit.
        // No ORDER BY, same as OpenROAD.
        public static readonly string LoadFeeders = @"
            SELECT SQUEEZE(O.Name) AS Name,
                   O.Object AS Object
            FROM   Udb_Object O,
                   Udb_Grouping G
            WHERE  G.Grouping = O.Object
            AND    G.GroupingType IN ( SELECT Type
                                       FROM   Udb_ExtendedType
                                       WHERE  Supertype IN (" + FMS_PDFReportService.Models.Constants.Type_Feeder + ", "
                                                              + FMS_PDFReportService.Models.Constants.Type_Network + ", "
                                                              + FMS_PDFReportService.Models.Constants.Type_Line + ", "
                                                              + FMS_PDFReportService.Models.Constants.Type_DivisionWorkstation + @") )
            AND    G.Relationship = " + FMS_PDFReportService.Models.Constants.Interaction_MemberOf + @"
            AND    G.Member = ?";

        public static readonly string LoadStations = @"
            SELECT O.Name AS Name,
                   O.Object AS Object
            FROM   Udb_Object O,
                   Udb_Grouping G
            WHERE  G.Grouping = O.Object
            AND    G.GroupingType IN ( SELECT Type
                                       FROM   Udb_ExtendedType
                                       WHERE  Supertype IN (" + FMS_PDFReportService.Models.Constants.Type_Substation + ", "
                                                              + FMS_PDFReportService.Models.Constants.Type_TelCircuitTerminal + @") )
            AND    G.Relationship = " + FMS_PDFReportService.Models.Constants.Interaction_MemberOf + @"
            AND    G.Member = ?";

        // Archive card: names are stored on the card (TLSCard_ASE.LoadFeedersAndStations ELSE branch).
        public const string LoadFeederStationNamesArchive = @"
            SELECT FeederNames, SubstationNames
            FROM   TC_ArchiveCard
            WHERE  Card = ?";

        // TLSJob_ASE.SetMoveColors "Highlight move if Co-Op test is PENDING ticketnumber". Parameter: Job.
        // Any row returned = pending (OpenROAD: SELECT :m = 1 ... ; IF m = 1).
        public static readonly string FindCoopPending = @"
            SELECT PermitJobID
            FROM   TC_WorkPermit
            WHERE  PermitJobID = ? AND
                   VendorTicketNumber = '" + FMS_PDFReportService.Models.Constants.Pending_TicketNumber + "'";

        public const string LoadJobs = @"
            SELECT Job, Card, Status, Seq, JobClass, JobClassSeq,
                   Circuit, Linenumber, CircuitClass, CircuitClassName,
                   StepPair, MoveType,
                   TOMoveRules, TOOperator, TOOperatorName, TOIssued,
                   TOComplete, TOMove, TOStep,
                   Results, ResultsCode, ResultsCodeName,
                   Substation, SubstationName,
                   Organization, OrganizationName,
                   RSMoveRules, RSOperator, RSOperatorName,
                   RSIssued, RSComplete, RSMove, RSStep,
                   InitialSwitchPos, FinalSwitchPos,
                   InService, OutService
            FROM   TC_Job
            WHERE  Card = ? AND
                   Status <> 'Del' AND
                   Status <> 'Hid'
            ORDER BY StepPair, Seq, Job";

        public const string LoadJobsArchive = @"
            SELECT Job, Card, Status, Seq, JobClass, JobClassSeq,
                   Circuit, Linenumber, CircuitClass, CircuitClassName,
                   StepPair, MoveType,
                   TOMoveRules, TOOperator, TOOperatorName, TOIssued,
                   TOComplete, TOMove, TOStep,
                   Results, ResultsCode, ResultsCodeName,
                   Substation, SubstationName,
                   Organization, OrganizationName,
                   RSMoveRules, RSOperator, RSOperatorName,
                   RSIssued, RSComplete, RSMove, RSStep,
                   InitialSwitchPos, FinalSwitchPos,
                   InService, OutService
            FROM   TC_ArchiveJob
            WHERE  Card = ? AND
                   Status <> 'Del'
            ORDER BY StepPair, Seq, Job";

        public const string LoadLineOOS = @"
            SELECT C.Card, C.Linenumber, C.RouteName,
                   C.CarrierName, C.TroubleCategoryName,
                   C.Opened, C.Status
            FROM   TC_Card C
            WHERE  C.Status <> 0
            ORDER BY C.Linenumber";

        public const string LoadCircuitChanges = @"
            SELECT C.Card, C.Linenumber, C.RouteName,
                   J.TOComplete AS ChangeDate,
                   J.TOMove AS ChangeDescription
            FROM   TC_Card C,
                   TC_Job J
            WHERE  C.Card = J.Card AND
                   J.TOComplete BETWEEN ? AND ?
            ORDER BY C.Linenumber, J.TOComplete";

        public const string LoadRevisionLog = @"
            SELECT C.Card, C.Linenumber, C.RouteName,
                   J.RSComplete AS RevisionDate,
                   J.RSMove AS RevisionDescription
            FROM   TC_Card C,
                   TC_Job J
            WHERE  C.Card = J.Card AND
                   J.RSComplete BETWEEN ? AND ?
            ORDER BY C.Linenumber, J.RSComplete";
    }
}
