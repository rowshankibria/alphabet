using System.Collections.Generic;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Data.Repositories
{
    public interface ITFMSCardRepository
    {
        TfmsCardHeader LoadCardHeader(int cardId, int archiveFlag);
        IEnumerable<TfmsJob> LoadJobs(int cardId, int archiveFlag);
        IEnumerable<SoaCardLogEntry> LoadCardLog(int cardId, int archiveFlag);
        IEnumerable<WorkPermit> LoadWorkPermits(int cardId, int archiveFlag);
        List<WorkPermit> LoadPermitsWithProtections(int cardId, int archiveFlag);
        Dictionary<int, int?> LoadInfoItemEquipSeverity(int cardId);
    }
}
