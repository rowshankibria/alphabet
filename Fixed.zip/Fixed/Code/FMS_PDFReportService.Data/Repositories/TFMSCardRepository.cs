using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;
using FMS_PDFReportService.Models.Jobs.Colors;

namespace FMS_PDFReportService.Data.Repositories
{
    public class TFMSCardRepository : ITFMSCardRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public TFMSCardRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public TfmsCardHeader LoadCardHeader(int cardId, int archiveFlag)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                var headerSql = archiveFlag == 1 ? TFMSQueries.LoadCardHeaderArchive : TFMSQueries.LoadCardHeader;
                var header = conn.QueryFirstOrDefault<TfmsCardHeader>(headerSql, new { p1 = cardId });
                if (header == null) return null;

                // Card class, Cut Out / Cut In, Note, Status (CardSOA.LoadCard). Separate query, as in OpenROAD,
                // so a missing SOA_Card row leaves these blank instead of losing the whole header.
                var soaSql = archiveFlag == 1 ? TFMSQueries.LoadSoaCardArchive : TFMSQueries.LoadSoaCard;
                var soa = conn.QueryFirstOrDefault<TfmsCardHeader>(soaSql, new { p1 = cardId });
                if (soa != null)
                {
                    header.CardClassName = soa.CardClassName;
                    header.CutOut = soa.CutOut;
                    header.CutIn = soa.CutIn;
                    header.Note = soa.Note;
                    header.Status = soa.Status;
                    header.Activated = soa.Activated;
                    header.Closed = soa.Closed;
                }

                var clSql = archiveFlag == 1 ? TFMSQueries.LoadChecklistArchive : TFMSQueries.LoadChecklist;
                header.Checklists = conn.Query<TfmsChecklist>(clSql, new { p1 = cardId }).ToList();

                var prepSql = archiveFlag == 1 ? TFMSQueries.LoadPrepByArchive : TFMSQueries.LoadPrepBy;
                header.PrepBy = conn.Query<TfmsCardPrepBy>(prepSql, new { p1 = cardId, p2 = cardId }).ToList();

                var objSql = archiveFlag == 1 ? TFMSQueries.LoadCardObjectsArchive : TFMSQueries.LoadCardObjects;
                header.Objects = conn.Query<TfmsCardObject>(objSql, new { p1 = cardId }).ToList();

                return header;
            }
        }

        public IEnumerable<TfmsJob> LoadJobs(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? TFMSQueries.LoadJobsArchive : TFMSQueries.LoadJobs;
            using (var conn = _connectionFactory.GetConnection())
            {
                var param = archiveFlag == 1 ? new { p1 = cardId, p2 = cardId } : (object)new { p1 = cardId };
                return conn.Query<TfmsJob>(sql, param).ToList();
            }
        }

        public IEnumerable<SoaCardLogEntry> LoadCardLog(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? TFMSQueries.LoadCardLogArchive : TFMSQueries.LoadCardLog;
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<SoaCardLogEntry>(sql, new { p1 = cardId }).ToList();
            }
        }

        // OBSOLETE - returns nothing for TOMS cards (see TFMSQueries.LoadWorkPermits). Use LoadPermitsWithProtections.
        public IEnumerable<WorkPermit> LoadWorkPermits(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? TFMSQueries.LoadWorkPermitsArchive : TFMSQueries.LoadWorkPermits;
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<WorkPermit>(sql, new { p1 = cardId }).ToList();
            }
        }

        // "Permits and Protections": Work Permits (StepPair 600) then Test Permits (StepPair 650), each by Seq,
        // each with its protection moves (WorkPermit_ASE.LoadSOA_WP).
        public List<WorkPermit> LoadPermitsWithProtections(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? TFMSQueries.LoadPermitsArchive : TFMSQueries.LoadPermits;
            var permits = new List<WorkPermit>();
            using (var conn = _connectionFactory.GetConnection())
            {
                foreach (var permitType in new[] { FMS_PDFReportService.Models.Constants.StepHeading_WorkPermit, FMS_PDFReportService.Models.Constants.StepHeading_TestPermit })
                    permits.AddRange(conn.Query<WorkPermit>(sql, new { p1 = cardId, p2 = permitType }));
            }

            // Protection moves: FMS_WorkPermitProtection links + the LoadProtectionMove cascade
            // (cac_include_scripts.dmt). That port already exists, card-type independent, in FMSCardRepository;
            // reuse it instead of duplicating it.
            var protectionSource = new FMSCardRepository(_connectionFactory);
            foreach (var p in permits)
                p.Protections = protectionSource.LoadProtections(p.Job, archiveFlag).ToList();

            return permits;
        }

        // ItemCategory_ASE.LoadEquip. Caller must only use it for an active, non-archived card.
        public Dictionary<int, int?> LoadInfoItemEquipSeverity(int cardId)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                var rows = conn.Query<InfoItemEquipSeverity>(TFMSQueries.LoadInfoItemEquipSeverity, new { p1 = cardId }).ToList();
                return TfmsRowRules.FirstSeverityPerEquip(rows);
            }
        }
    }
}
