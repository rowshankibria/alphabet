using System.Collections.Generic;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Data.Repositories
{
    public interface ITLSCardRepository
    {
        TlsCardHeader LoadCardHeader(int cardId, int archiveFlag);
        IEnumerable<TlsJob> LoadJobs(int cardId, int archiveFlag);
        HashSet<int> LoadCoopPendingJobs(IEnumerable<TlsJob> jobs);
        IEnumerable<TlsLineOOS> LoadLineOOS(string divisions, int status);
        IEnumerable<TlsCircuitChange> LoadCircuitChanges(string divisions, string startDate, string endDate);
        IEnumerable<TlsRevisionLogEntry> LoadRevisionLog(string divisions, string startDate, string endDate);
    }
}
