using System.Collections.Generic;
using System.Linq;
using Dapper;
using FMS_PDFReportService.Data.Connection;
using FMS_PDFReportService.Data.Queries;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Data.Repositories
{
    public class TLSCardRepository : ITLSCardRepository
    {
        private readonly IConnectionFactory _connectionFactory;

        public TLSCardRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public TlsCardHeader LoadCardHeader(int cardId, int archiveFlag)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                var sql = archiveFlag == 1 ? TLSQueries.LoadCardHeaderArchive : TLSQueries.LoadCardHeader;
                var header = conn.QueryFirstOrDefault<TlsCardHeader>(sql, new { p1 = cardId });
                if (header == null) return null;

                var note = conn.QueryFirstOrDefault<string>(TLSQueries.LoadCardNote, new { p1 = cardId });
                header.CardNote = note;

                // Feeders / Stations ("Fdrs / Nwks:" and "Stations:"), TLSCard_ASE.LoadFeedersAndStations.
                if (archiveFlag == 1)
                {
                    var names = conn.QueryFirstOrDefault<TlsCardHeader>(TLSQueries.LoadFeederStationNamesArchive, new { p1 = cardId });
                    header.FeederNames = names?.FeederNames;
                    header.SubstationNames = names?.SubstationNames;
                    header.Feeders = TlsCardHeader.SplitNames(header.FeederNames).ConvertAll(n => new TlsFeeder { Name = n });
                    header.Stations = TlsCardHeader.SplitNames(header.SubstationNames).ConvertAll(n => new TlsStation { Name = n });
                }
                else
                {
                    header.Feeders = conn.Query<TlsFeeder>(TLSQueries.LoadFeeders, new { p1 = header.Circuit }).ToList();
                    header.Stations = conn.Query<TlsStation>(TLSQueries.LoadStations, new { p1 = header.Circuit }).ToList();
                }

                return header;
            }
        }

        // Jobs on the card whose Co-Op test ticket is still PENDING (TLSJob_ASE.SetMoveColors).
        // Same per-job check as OpenROAD, run only for MoveType = COOP rows.
        public HashSet<int> LoadCoopPendingJobs(IEnumerable<TlsJob> jobs)
        {
            var result = new HashSet<int>();
            if (jobs == null) return result;
            var coopJobs = jobs
                .Where(j => string.Equals((j.MoveType ?? string.Empty).Trim(), FMS_PDFReportService.Models.Constants.MoveType_COOP, System.StringComparison.Ordinal))
                .Select(j => j.Job)
                .Distinct()
                .ToList();
            if (coopJobs.Count == 0) return result;

            using (var conn = _connectionFactory.GetConnection())
            {
                foreach (var job in coopJobs)
                {
                    if (conn.Query<int>(TLSQueries.FindCoopPending, new { p1 = job }).Any())
                        result.Add(job);
                }
            }
            return result;
        }

        public IEnumerable<TlsJob> LoadJobs(int cardId, int archiveFlag)
        {
            var sql = archiveFlag == 1 ? TLSQueries.LoadJobsArchive : TLSQueries.LoadJobs;
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<TlsJob>(sql, new { p1 = cardId }).ToList();
            }
        }

        public IEnumerable<TlsLineOOS> LoadLineOOS(string divisions, int status)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<TlsLineOOS>(TLSQueries.LoadLineOOS).ToList();
            }
        }

        public IEnumerable<TlsCircuitChange> LoadCircuitChanges(string divisions, string startDate, string endDate)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<TlsCircuitChange>(
                    TLSQueries.LoadCircuitChanges,
                    new { p1 = startDate, p2 = endDate }).ToList();
            }
        }

        public IEnumerable<TlsRevisionLogEntry> LoadRevisionLog(string divisions, string startDate, string endDate)
        {
            using (var conn = _connectionFactory.GetConnection())
            {
                return conn.Query<TlsRevisionLogEntry>(
                    TLSQueries.LoadRevisionLog,
                    new { p1 = startDate, p2 = endDate }).ToList();
            }
        }
    }
}
