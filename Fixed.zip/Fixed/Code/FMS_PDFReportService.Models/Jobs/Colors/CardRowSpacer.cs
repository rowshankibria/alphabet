using System;
using System.Collections.Generic;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // Spare blank rows for the TLS and TOMS cards (query string LINE -> ReportRequest.SpareLines),
    // same algorithm as GroupSpacer (FMS card):
    //   - a group starts at a step heading row;
    //   - LINE blank rows (clamped 0..GroupSpacer.MaxLines) are added at the end of every group,
    //     including a group that has only its heading,
    //   - EXCEPT the last group when it has no data rows;
    //   - every other row (notes, substation headings, moves) is a data row; rows above the first heading form a group.
    // Must run AFTER TlsRowRules / TfmsRowRules: blank rows are created already "coloured" (empty and white).
    public static class CardRowSpacer
    {
        // TLS step heading = the navy rows (Alarms, Switching Operations, ...): JobClass 0 AND CircuitClass -99
        // (TLSJob_ASE.SetMoveColors). Other JobClass 0 rows are notes = data rows.
        public static bool IsTlsStepHeading(TlsJob j)
        {
            return j.JobClass == 0 && j.CircuitClass == -99;
        }

        // TOMS step heading = De-Energize, Disconnects, Work Permits, Test, EN - DE - EN ...:
        // JobClass 0 AND (blue text like FMS, or MoveCategory StepHeading / EN-DE-EN).
        // Substation headings (coloured bands) and FIELD WORK are sub-headings inside a group = data rows.
        public static bool IsTfmsStepHeading(TfmsJob j)
        {
            return j.JobClass == 0 &&
                   (j.MoveFGColor == Constants.CC_BLUE ||
                    j.MoveCategory == Constants.MoveCategory_StepHeading ||
                    j.MoveCategory == Constants.MoveCategory_EnDeEn);
        }

        public static List<TlsJob> AddBlankRows(IEnumerable<TlsJob> jobs, int lines)
        {
            return AddBlankRows(jobs, lines, IsTlsStepHeading, BlankTls);
        }

        public static List<TfmsJob> AddBlankRows(IEnumerable<TfmsJob> jobs, int lines)
        {
            return AddBlankRows(jobs, lines, IsTfmsStepHeading, BlankTfms);
        }

        public static List<T> AddBlankRows<T>(IEnumerable<T> rows, int lines, Func<T, bool> isStepHeading, Func<T> makeBlank)
        {
            if (lines < 0) lines = 0;
            if (lines > GroupSpacer.MaxLines) lines = GroupSpacer.MaxLines;

            var result = new List<T>();
            if (rows == null) return result;
            bool lastGroupHasData = false;

            foreach (var r in rows)
            {
                if (isStepHeading(r))
                {
                    // A new heading closes the previous group (if there is one)
                    if (result.Count > 0) AddBlanks(result, lines, makeBlank);
                    lastGroupHasData = false;
                }
                else
                {
                    lastGroupHasData = true;
                }
                result.Add(r);
            }

            // Close the last group only if it has at least one data row
            if (lastGroupHasData) AddBlanks(result, lines, makeBlank);
            return result;
        }

        private static void AddBlanks<T>(List<T> list, int lines, Func<T> makeBlank)
        {
            for (int i = 0; i < lines; i++)
                list.Add(makeBlank());
        }

        // An empty grid row: all cells blank and white, normal (not bold) Move cell.
        public static TlsJob BlankTls()
        {
            string w = DosColors.KeyCellBg;
            var j = new TlsJob
            {
                IsBlankRow = true, IsHeading = false,
                TOIssuedText = "", TOCompleteText = "", RSIssuedText = "", RSCompleteText = "",
                TOIssuedBgKey = w, TOCompleteBgKey = w, RSIssuedBgKey = w, RSCompleteBgKey = w,
                StationText = "", CircuitText = "", MoveText = "", MoveFgKey = DosColors.KeyText, MoveBgKey = w,
                ResultsText = "", StatusText = ""
            };
            TlsRowRules.Resolve(j);
            return j;
        }

        public static TfmsJob BlankTfms()
        {
            string w = DosColors.KeyCellBg, t = DosColors.KeyText;
            var j = new TfmsJob
            {
                IsBlankRow = true, IsHeading = false, MoveBold = false,
                TOIssuedText = "", TOCompleteText = "", RSIssuedText = "", RSCompleteText = "",
                TOIssuedBgKey = w, TOCompleteBgKey = w, RSIssuedBgKey = w, RSCompleteBgKey = w,
                TypeText = "", EquipText = "", EquipFgKey = t, GText = "", GFgKey = t,
                MoveText = "", MoveFgKey = t, MoveBgKey = w, OriginText = "", OriginBgKey = w, ResponseText = ""
            };
            TfmsRowRules.Resolve(j);
            return j;
        }
    }
}
