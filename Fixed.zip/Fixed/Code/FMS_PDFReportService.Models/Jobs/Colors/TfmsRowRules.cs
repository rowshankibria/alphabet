using System;
using System.Collections.Generic;
using System.Globalization;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // One row of ItemCategory_ASE.LoadEquip (cac.dmt): equipment on the card that is linked to an
    // active information item, with the item's severity.
    public class InfoItemEquipSeverity
    {
        public int Equip { get; set; }
        public int? Severity { get; set; }
    }

    // Display values and colours for one TOMS card row (TFMSCard.trdx).
    // Port of soa.dmt SOA_Main  ON USEREVENT 'MoveColors'  (TFMS branch), limited to what the DOS
    // benchmark (toms-dos.pdf) draws. Timestamp text colours (operating-order gray/red) are NOT drawn:
    // toms-dos.pdf has no coloured date text in 180 pages.
    public static class TfmsRowRules
    {
        // ItemCategory_ASE.LoadEquip keeps the FIRST row per equipment of
        // "ORDER BY Equip, Severity"; SOA_Main then uses the first match. Rows must arrive in that order.
        public static Dictionary<int, int?> FirstSeverityPerEquip(IEnumerable<InfoItemEquipSeverity> rows)
        {
            var map = new Dictionary<int, int?>();
            if (rows == null) return map;
            foreach (var r in rows)
                if (!map.ContainsKey(r.Equip))
                    map.Add(r.Equip, r.Severity);
            return map;
        }

        // cardId    : the card being printed (SOA_Main Card.Card)
        // archived  : request.ArchiveFlag == 1
        // equipSeverity: from FirstSeverityPerEquip; must be empty unless the card is active and not archived
        //               (SOA_Main only loads it when ArchiveCard = FALSE AND Card.Status = Card$Active).
        public static void Apply(IEnumerable<TfmsJob> jobs, int cardId, bool archived, IDictionary<int, int?> equipSeverity)
        {
            if (jobs == null) return;
            foreach (var j in jobs)
                ApplyRow(j, cardId, archived, equipSeverity);
        }

        public static void ApplyRow(TfmsJob j, int cardId, bool archived, IDictionary<int, int?> equipSeverity)
        {
            // Ingres/OpenROAD string comparison ignores trailing blanks ('' = '   '), so a blank-padded
            // Status must still count as ''. Without this, every ground / info-item / test-letter rule is off.
            string status = (j.Status ?? string.Empty).TrimEnd();
            bool outstanding = status == string.Empty || status == Constants.JobStatus_NIS;   // Status = '' OR 'NIS'

            j.MoveText = j.TOMove ?? string.Empty;   // leading spaces kept: the DOS card indents headings with them

            // Every colour below is a key (= TFMSCard.trdx parameter name); Resolve() turns keys into hex.
            // ---- Move text colour -------------------------------------------------------------
            string moveFg = DosColors.KeyText;
            // tfmscard.js: switching item with a shadow link is green (web rule; not in SOA_Main).
            if (j.MoveCategory == Constants.MoveCategory_SwitchingItem && j.ShadowLink != 0)
                moveFg = DosColors.KeyShadowLink;
            // "IF J[i].MoveFgColor <> 0 THEN FIELD(J[i].TOMove).FgColor = J[i].MoveFgColor"
            if (j.MoveFGColor != 0)
                moveFg = DosColors.KeyFromCode(j.MoveFGColor) ?? moveFg;
            // "Look for moves that set equipment ground" (applied after MoveFgColor, so it wins)
            bool ground = j.Grounds.HasValue && j.Grounds.Value > 0 && j.GroundOn != null && outstanding;
            if (ground) moveFg = DosColors.KeyGround;
            j.MoveFgKey = moveFg;

            // ---- Move background ---------------------------------------------------------------
            string moveBg = j.MoveBGColor != 0 ? (DosColors.KeyFromCode(j.MoveBGColor) ?? DosColors.KeyCellBg) : DosColors.KeyCellBg;
            // "Look for outstanding Test Letter moves": issued, not complete -> CC_PALE_ORANGE,
            // otherwise CC_PALE_YELLOW = the card's normal background (white on the DOS card).
            if (j.JobClass == Constants.JobClass_TestLetter)
                moveBg = (j.TOIssued != null && j.TOComplete == null && outstanding)
                    ? DosColors.KeyTestLetter
                    : DosColors.KeyCellBg;
            j.MoveBgKey = moveBg;

            if (j.JobClass == 0)
            {
                // Step / substation / FIELD WORK heading (tfmscard.js card_IsStepHeading).
                // DOS: bold, coloured only in the Move cell, every other cell empty and white.
                j.IsHeading = true;
                j.MoveBold = true;
                j.TOIssuedText = j.TOCompleteText = j.RSIssuedText = j.RSCompleteText = string.Empty;
                j.TOIssuedBgKey = j.TOCompleteBgKey = j.RSIssuedBgKey = j.RSCompleteBgKey = DosColors.KeyCellBg;
                j.TypeText = j.EquipText = j.GText = j.OriginText = j.ResponseText = string.Empty;
                j.EquipFgKey = j.GFgKey = DosColors.KeyText;
                j.OriginBgKey = DosColors.KeyCellBg;
                Resolve(j);
                return;
            }

            j.IsHeading = false;
            j.MoveBold = false;

            // ---- Timestamps: "Grey issue/complete times as appropriate" (empty date only) ------
            j.TOIssuedText = DateText(j.TOIssued);
            j.TOCompleteText = DateText(j.TOComplete);
            j.RSIssuedText = DateText(j.RSIssued);
            j.RSCompleteText = DateText(j.RSComplete);
            j.TOIssuedBgKey = GrayIfBlank(j.TOIssued);
            j.TOCompleteBgKey = GrayIfBlank(j.TOComplete);
            j.RSIssuedBgKey = GrayIfBlank(j.RSIssued);
            j.RSCompleteBgKey = GrayIfBlank(j.RSComplete);

            // ---- Type / Equipment: "If card does not have control of the move, grey out the equipment"
            j.TypeText = j.EquipClassName ?? string.Empty;
            j.EquipText = j.EquipName ?? string.Empty;
            j.EquipFgKey = (j.ControlCard != cardId && j.MoveCategory == Constants.MoveCategory_Normal)
                ? DosColors.KeyEquipNoControl
                : DosColors.KeyText;

            // ---- G column ---------------------------------------------------------------------
            j.GText = j.Grounds.HasValue && j.Grounds.Value > 0
                ? j.Grounds.Value.ToString(CultureInfo.InvariantCulture)
                : string.Empty;
            j.GFgKey = ground ? DosColors.KeyGround : DosColors.KeyText;

            // ---- Origin cell (ActivityIdentifier) -----------------------------------------------
            // Text: S is not printed on a closed (archived) card (tfmscard.js; same rule as FeederCard).
            string act = j.ActivityIdentifier ?? string.Empty;
            j.OriginText = (archived && act.Trim() == "S") ? string.Empty : act;
            // Colour: "Look for equipment moves associated to an info item"
            j.OriginBgKey = DosColors.KeyCellBg;
            int? sev;
            if (!archived && equipSeverity != null && j.MoveCategory == Constants.MoveCategory_Normal && outstanding
                && equipSeverity.TryGetValue(j.Equip, out sev) && sev.HasValue)
            {
                if (sev.Value == 1) j.OriginBgKey = DosColors.KeyInfoSeverity1;
                else if (sev.Value == 2) j.OriginBgKey = DosColors.KeyInfoSeverity2;
                else if (sev.Value == 3) j.OriginBgKey = DosColors.KeyInfoSeverity3;
            }

            j.ResponseText = j.Response ?? string.Empty;
            Resolve(j);
        }

        // Hex sent with each key = the TFMSCard.trdx parameter default; used by the template only when
        // the template has no parameter for that key.
        public static void Resolve(TfmsJob j)
        {
            j.TOIssuedBg = DosColors.Toms(j.TOIssuedBgKey);
            j.TOCompleteBg = DosColors.Toms(j.TOCompleteBgKey);
            j.RSIssuedBg = DosColors.Toms(j.RSIssuedBgKey);
            j.RSCompleteBg = DosColors.Toms(j.RSCompleteBgKey);
            j.EquipFg = DosColors.Toms(j.EquipFgKey);
            j.GFg = DosColors.Toms(j.GFgKey);
            j.MoveFg = DosColors.Toms(j.MoveFgKey);
            j.MoveBg = DosColors.Toms(j.MoveBgKey);
            j.OriginBg = DosColors.Toms(j.OriginBgKey);
        }

        private static string GrayIfBlank(DateTime? d)
        {
            return FmsColorCalculator.IsBlank(d) ? DosColors.KeyDateGrayOut : DosColors.KeyCellBg;
        }

        public static string DateText(DateTime? d)
        {
            if (!FmsColorCalculator.HasValue(d)) return string.Empty;
            return d.Value.ToString("MM/dd HH:mm", CultureInfo.InvariantCulture);
        }
    }
}
