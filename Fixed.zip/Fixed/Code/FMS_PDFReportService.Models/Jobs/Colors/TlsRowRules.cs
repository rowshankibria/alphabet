using System;
using System.Collections.Generic;
using System.Globalization;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // Display values and colours for one TLS card row (TLSCard.trdx).
    // Port of cac.dmt TLSJob_ASE.LoadJobs (Status -> 'T') and TLSJob_ASE.SetMoveColors,
    // limited to what the DOS benchmark (tls-dos.pdf) draws:
    //   - background colours ARE drawn (empty-date gray, Co-Op pending pale red)
    //   - foreground dimming of completed / pending-confirmation moves (CC_LIGHT_GRAY text) is NOT drawn:
    //     tls-dos.pdf has no gray text at all, although it contains moves completed on both sides.
    public static class TlsRowRules
    {
        public static void Apply(IEnumerable<TlsJob> jobs, int cardStatus, ICollection<int> coopPendingJobs)
        {
            if (jobs == null) return;
            foreach (var j in jobs)
                ApplyRow(j, cardStatus, coopPendingJobs);
        }

        public static void ApplyRow(TlsJob j, int cardStatus, ICollection<int> coopPendingJobs)
        {
            // LoadJobs: 'Xfr' (transferred) prints as T, every other status prints blank.
            j.StatusText = j.Status == "Xfr" ? "T" : string.Empty;
            j.MoveText = j.TOMove ?? string.Empty;   // leading spaces kept: the DOS card indents with them
            // Every colour below is a key (= TLSCard.trdx parameter name); Resolve() turns keys into hex.
            j.MoveBgKey = DosColors.KeyCellBg;

            if (j.JobClass == 0)
            {
                // Step heading / note row (tlscard.js card_IsStepHeading). Only the Move cell has text.
                // SetMoveColors: JobClass 0 AND CircuitClass -99 -> CC_BLUE (DOS draws Navy); other rows black.
                // Every other cell is empty and white (all heading rows in tls-dos.pdf).
                j.IsHeading = true;
                j.MoveFgKey = j.CircuitClass == -99 ? DosColors.KeyStepHeading : DosColors.KeyText;
                j.StationText = j.CircuitText = j.ResultsText = j.StatusText = string.Empty;
                j.TOIssuedText = j.TOCompleteText = j.RSIssuedText = j.RSCompleteText = string.Empty;
                j.TOIssuedBgKey = j.TOCompleteBgKey = j.RSIssuedBgKey = j.RSCompleteBgKey = DosColors.KeyCellBg;
                Resolve(j);
                return;
            }

            j.IsHeading = false;
            j.MoveFgKey = DosColors.KeyText;
            j.StationText = j.SubstationName ?? string.Empty;
            j.CircuitText = j.Linenumber ?? string.Empty;
            j.ResultsText = j.Results ?? string.Empty;

            j.TOIssuedText = DateText(j.TOIssued);
            j.TOCompleteText = DateText(j.TOComplete);
            j.RSIssuedText = DateText(j.RSIssued);
            j.RSCompleteText = DateText(j.RSComplete);

            // "Gray out move performance if not available": Ingres empty date ('') only, never NULL.
            j.TOIssuedBgKey = GrayIfBlank(j.TOIssued);
            j.TOCompleteBgKey = GrayIfBlank(j.TOComplete);
            j.RSIssuedBgKey = GrayIfBlank(j.RSIssued);
            j.RSCompleteBgKey = GrayIfBlank(j.RSComplete);

            // "Handle Transferred moves for closed cards": NULL dates also gray.
            // Ported exactly: OpenROAD compares the TC card status (1..4) with Card$Closed (50),
            // so in production this branch never fires. See TLS_Fix.md, open item.
            if (j.StatusText == "T" && cardStatus == Constants.Card_Closed)
            {
                if (j.TOIssued == null) j.TOIssuedBgKey = DosColors.KeyDateGrayOut;
                if (j.TOComplete == null) j.TOCompleteBgKey = DosColors.KeyDateGrayOut;
                if (j.RSIssued == null) j.RSIssuedBgKey = DosColors.KeyDateGrayOut;
                if (j.RSComplete == null) j.RSCompleteBgKey = DosColors.KeyDateGrayOut;
            }

            // "Highlight move if Co-Op test is PENDING ticketnumber"
            if (string.Equals((j.MoveType ?? string.Empty).Trim(), Constants.MoveType_COOP, StringComparison.Ordinal)
                && coopPendingJobs != null && coopPendingJobs.Contains(j.Job))
            {
                j.MoveBgKey = DosColors.KeyCoopPending;
            }
            Resolve(j);
        }

        // Hex sent with each key = the TLSCard.trdx parameter default; used by the template only when
        // the template has no parameter for that key.
        public static void Resolve(TlsJob j)
        {
            j.TOIssuedBg = DosColors.Tls(j.TOIssuedBgKey);
            j.TOCompleteBg = DosColors.Tls(j.TOCompleteBgKey);
            j.RSIssuedBg = DosColors.Tls(j.RSIssuedBgKey);
            j.RSCompleteBg = DosColors.Tls(j.RSCompleteBgKey);
            j.MoveFg = DosColors.Tls(j.MoveFgKey);
            j.MoveBg = DosColors.Tls(j.MoveBgKey);
        }

        private static string GrayIfBlank(DateTime? d)
        {
            return FmsColorCalculator.IsBlank(d) ? DosColors.KeyDateGrayOut : DosColors.KeyCellBg;
        }

        // NULL and the empty-date value both print as nothing; anything else as MM/dd HH:mm.
        public static string DateText(DateTime? d)
        {
            if (!FmsColorCalculator.HasValue(d)) return string.Empty;
            return d.Value.ToString("MM/dd HH:mm", CultureInfo.InvariantCulture);
        }
    }
}
