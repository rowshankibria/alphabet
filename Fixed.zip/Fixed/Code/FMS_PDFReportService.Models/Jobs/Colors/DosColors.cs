using System.Collections.Generic;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // Colours as the DOS (benchmark) PDFs draw them, for the TLS and TOMS card grids.
    // Codes are OpenROAD CC_* values (Constants.cs). The hex values come from fms-online database.js
    // db_GetMappedColor and fms.css, except CC_BLUE (DOS draws step headings Navy, not #0000ff).
    // "Seen" = measured in tls-dos.pdf / toms-dos.pdf. Do NOT use Engine ColorMappingService for these
    // reports: its palette does not match the benchmark (e.g. code 33 there is not Gold).
    //
    // Support-editable colours: each coloured cell gets a colour KEY (TfmsJob/TlsJob ...Key) plus the hex
    // below. The key is the name of a report parameter in TFMSCard.trdx / TLSCard.trdx whose default value
    // is the same hex, so support can change a colour in the Telerik Report Designer without a code change.
    // A key with no parameter in the template falls back to the hex sent by the application.
    public static class DosColors
    {
        public const string White = "#FFFFFF";
        public const string Black = "#000000";
        public const string Navy = "#000080";           // seen: TLS + TOMS step headings
        public const string Red = "#FF0000";            // seen: TOMS ground moves, G column
        public const string Green = "#008000";          // seen: TOMS move text
        public const string Gray = "#808080";           // seen: TOMS Type/Equipment text (CC_LIGHT_GRAY)

        // Ingres empty date ('' = step not used). Both are CC_PALE_GRAY in OpenROAD,
        // but the two DOS reports draw it differently.
        public const string TlsGrayOut = "#DCDCDC";     // seen: tls-dos.pdf (220,220,220)
        public const string TomsGrayOut = "#808080";    // seen: toms-dos.pdf (128,128,128)

        // Origin ("S") cell, information-item severity (fms.css .Info_1/.Info_2/.Info_3)
        public const string InfoSeverity1 = "#FFFF00";  // seen: yellow
        public const string InfoSeverity2 = "#00CED1";  // seen: darkturquoise
        public const string InfoSeverity3 = "#3CB371";  // seen: mediumseagreen

        // ---- Colour keys = report parameter names (roles decided by the row rules) -----------------------
        public const string KeyText = "ColorText";                       // normal text (TOMS + TLS)
        public const string KeyCellBg = "ColorCellBg";                   // normal cell background (TOMS + TLS)
        public const string KeyDateGrayOut = "ColorDateGrayOut";         // empty Ingres date (TOMS + TLS, different defaults)
        public const string KeyEquipNoControl = "ColorEquipNoControl";   // TOMS Type/Equipment when card has no control
        public const string KeyGround = "ColorGround";                   // TOMS ground still applied: G + Move text
        public const string KeyShadowLink = "ColorShadowLink";           // TOMS switching item with shadow link
        public const string KeyTestLetter = "ColorTestLetter";           // TOMS outstanding test letter (Move background)
        public const string KeyInfoSeverity1 = "ColorInfoSeverity1";     // TOMS origin cell, info item severity 1
        public const string KeyInfoSeverity2 = "ColorInfoSeverity2";
        public const string KeyInfoSeverity3 = "ColorInfoSeverity3";
        public const string KeyStepHeading = "ColorStepHeading";         // TLS step heading text (CircuitClass -99)
        public const string KeyCoopPending = "ColorCoopPending";         // TLS Co-Op test pending (Move background)

        // OpenROAD colour codes stored in the database (SOA_Job.MoveFGColor / MoveBGColor): key "DbColor" + name.
        private static readonly (int Code, string Name, string Hex)[] Codes =
        {
            (Constants.CC_BLACK, "Black", Black),
            (Constants.CC_RED, "Red", Red),
            (Constants.CC_GREEN, "Green", Green),
            (Constants.CC_BLUE, "Blue", Navy),
            (Constants.CC_YELLOW, "Yellow", "#FFFF00"),
            (Constants.CC_CYAN, "Cyan", "#00FFFF"),
            (Constants.CC_PINK, "Pink", "#FFC0C0"),
            (Constants.CC_BROWN, "Brown", "#8B4513"),
            (Constants.CC_ORANGE, "Orange", "#FF8C00"),
            (Constants.CC_PURPLE, "Purple", "#800080"),
            (Constants.CC_GRAY, "Gray", "#696969"),
            (Constants.CC_LIGHT_RED, "LightRed", "#FF4500"),
            (Constants.CC_LIGHT_GREEN, "LightGreen", "#3CB371"),
            (Constants.CC_LIGHT_BLUE, "LightBlue", "#6495ED"),
            (Constants.CC_LIGHT_YELLOW, "LightYellow", "#F0E68C"),
            (Constants.CC_LIGHT_CYAN, "LightCyan", "#B0E0E6"),
            (Constants.CC_LIGHT_PINK, "LightPink", "#EE82EE"),
            (Constants.CC_LIGHT_BROWN, "LightBrown", "#D2B48C"),
            (Constants.CC_LIGHT_ORANGE, "LightOrange", "#FFA500"),
            (Constants.CC_LIGHT_PURPLE, "LightPurple", "#8A2BE2"),
            (Constants.CC_LIGHT_GRAY, "LightGray", Gray),
            (Constants.CC_PALE_RED, "PaleRed", "#FFB6C1"),      // seen: LightPink band
            (Constants.CC_PALE_GREEN, "PaleGreen", "#90EE90"),
            (Constants.CC_PALE_BLUE, "PaleBlue", "#87CEFA"),    // seen: LightSkyBlue band
            (Constants.PALE_YELLOW, "PaleYellow", "#FAFAD2"),
            (Constants.CC_PALE_CYAN, "PaleCyan", "#E0FFFF"),
            (Constants.CC_PALE_PINK, "PalePink", "#D8BFD8"),    // seen: Thistle band
            (Constants.CC_PALE_BROWN, "PaleBrown", "#DEB887"),  // seen: BurlyWood band
            (Constants.CC_PALE_ORANGE, "PaleOrange", "#FFD700"),// seen: Gold band
            (Constants.CC_PALE_PURPLE, "PalePurple", "#E6E6FA"),
            (Constants.CC_PALE_GRAY, "PaleGray", "#A9A9A9"),
        };

        // Maps an OpenROAD colour code to hex. Returns null for 0 (not set) and for codes
        // with no mapping, so the caller keeps its default.
        public static string FromCode(int code)
        {
            foreach (var c in Codes) if (c.Code == code) return c.Hex;
            return null;
        }

        // Colour key for an OpenROAD colour code; null when FromCode is null.
        public static string KeyFromCode(int code)
        {
            foreach (var c in Codes) if (c.Code == code) return "DbColor" + c.Name;
            return null;
        }

        // Key -> default hex, per report. These are the report parameters' default values.
        public static readonly IReadOnlyDictionary<string, string> TomsPalette = BuildToms();
        public static readonly IReadOnlyDictionary<string, string> TlsPalette = new Dictionary<string, string>
        {
            { KeyText, Black },
            { KeyCellBg, White },
            { KeyDateGrayOut, TlsGrayOut },
            { KeyStepHeading, Navy },
            { KeyCoopPending, "#FFB6C1" },   // CC_PALE_RED
        };

        private static Dictionary<string, string> BuildToms()
        {
            var p = new Dictionary<string, string>
            {
                { KeyText, Black },
                { KeyCellBg, White },
                { KeyDateGrayOut, TomsGrayOut },
                { KeyEquipNoControl, Gray },
                { KeyGround, Red },
                { KeyShadowLink, Green },
                { KeyTestLetter, "#FFD700" },   // CC_PALE_ORANGE
                { KeyInfoSeverity1, InfoSeverity1 },
                { KeyInfoSeverity2, InfoSeverity2 },
                { KeyInfoSeverity3, InfoSeverity3 },
            };
            foreach (var c in Codes) p.Add("DbColor" + c.Name, c.Hex);
            return p;
        }

        public static string Toms(string key) { return TomsPalette[key]; }
        public static string Tls(string key) { return TlsPalette[key]; }
    }
}
