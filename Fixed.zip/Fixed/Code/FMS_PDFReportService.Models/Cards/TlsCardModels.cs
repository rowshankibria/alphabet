using System;
using System.Collections.Generic;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Models.Cards
{
    public class TlsCardReportData
    {
        public TlsCardHeader Header { get; set; }
        public List<TlsJob> Jobs { get; set; } = new List<TlsJob>();
    }

    public class TlsCardHeader
    {
        public int Card { get; set; }
        public int Circuit { get; set; }
        public string Linenumber { get; set; }
        public string AltLine1 { get; set; }
        public string AltLine2 { get; set; }
        public int LineType { get; set; }
        public int CardType { get; set; }
        public string LineTypeName { get; set; }
        public string RouteName { get; set; }
        public int TroubleCategory { get; set; }
        public string TroubleCategoryName { get; set; }
        public int FunctionArea { get; set; }
        public string FunctionAreaName { get; set; }
        public string ReasonForFailure { get; set; }
        public string ValidatedBy { get; set; }
        public int ShowNote { get; set; }
        public string Notes { get; set; }
        public int Status { get; set; }
        public int Carrier { get; set; }
        public string CarrierName { get; set; }
        public DateTime? Opened { get; set; }
        public DateTime? Closed { get; set; }
        public int Priority { get; set; }
        public string CardNote { get; set; }
        public List<TlsFeeder> Feeders { get; set; } = new List<TlsFeeder>();
        public List<TlsStation> Stations { get; set; } = new List<TlsStation>();

        // Archive card only: comma-separated names stored on TC_ArchiveCard (TLSCard_ASE.LoadFeedersAndStations).
        public string FeederNames { get; set; }
        public string SubstationNames { get; set; }

        // TLSCard_ASE.LoadCard: CardType 0 = TROUBLE, anything else = SCHEDULED ("Type of Work").
        public string CardTypeName { get { return CardType == 0 ? "TROUBLE" : "SCHEDULED"; } }

        // "Fdrs / Nwks:" and "Stations:" lines, joined the way the DOS card prints them.
        public string FeedersText { get { return JoinNames(Feeders == null ? null : Feeders.ConvertAll(f => f.Name)); } }
        public string StationsText { get { return JoinNames(Stations == null ? null : Stations.ConvertAll(s => s.Name)); } }

        private static string JoinNames(List<string> names)
        {
            if (names == null) return string.Empty;
            var kept = names.ConvertAll(n => (n ?? string.Empty).Trim()).FindAll(n => n.Length > 0);
            return string.Join(", ", kept);
        }

        // OpenROAD SQUEEZE(): trim, and collapse runs of white space to one blank.
        public static string Squeeze(string s)
        {
            if (string.IsNullOrEmpty(s)) return string.Empty;
            return System.Text.RegularExpressions.Regex.Replace(s.Trim(), @"\s+", " ");
        }

        // Archive cards keep names as "A, B, C" (TLSCard_ASE.LoadFeedersAndStations ELSE branch).
        public static List<string> SplitNames(string commaSeparated)
        {
            var result = new List<string>();
            if (string.IsNullOrEmpty(commaSeparated)) return result;
            foreach (var part in commaSeparated.Split(','))
            {
                var name = Squeeze(part);
                if (name.Length > 0) result.Add(name);
            }
            return result;
        }
    }

    public class TlsFeeder
    {
        public string Name { get; set; }
        public int Object { get; set; }
    }

    public class TlsStation
    {
        public string Name { get; set; }
        public int Object { get; set; }
    }

    public class TlsLineOOS
    {
        public int Card { get; set; }
        public string Linenumber { get; set; }
        public string RouteName { get; set; }
        public string CarrierName { get; set; }
        public string TroubleCategoryName { get; set; }
        public DateTime? Opened { get; set; }
        public int Status { get; set; }
    }

    public class TlsCircuitChange
    {
        public int Card { get; set; }
        public string Linenumber { get; set; }
        public string RouteName { get; set; }
        public DateTime? ChangeDate { get; set; }
        public string ChangeDescription { get; set; }
    }

    public class TlsRevisionLogEntry
    {
        public int Card { get; set; }
        public string Linenumber { get; set; }
        public string RouteName { get; set; }
        public DateTime? RevisionDate { get; set; }
        public string RevisionDescription { get; set; }
    }
}
