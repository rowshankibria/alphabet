using System;
using System.Collections.Generic;
using FMS_PDFReportService.Models.Jobs;

namespace FMS_PDFReportService.Models.Cards
{
    public class TfmsCardReportData
    {
        public TfmsCardHeader Header { get; set; }
        public List<TfmsJob> Jobs { get; set; } = new List<TfmsJob>();
        public List<SoaCardLogEntry> CardLog { get; set; } = new List<SoaCardLogEntry>();
        public List<WorkPermit> WorkPermits { get; set; } = new List<WorkPermit>();
        public RelaySummaryData RelaySummary { get; set; }
    }

    public class TfmsCardHeader
    {
        public int Card { get; set; }
        public string CardNumber { get; set; }
        public string Description { get; set; }
        public string FeederNames { get; set; }
        public int Status { get; set; }
        public DateTime? Activated { get; set; }
        public DateTime? Closed { get; set; }

        // From SOA_Card (active) / TFMS_ArchiveCard (archive), CardSOA.LoadCard in cac.dmt.
        public string CardClassName { get; set; }
        public DateTime? CutOut { get; set; }
        public DateTime? CutIn { get; set; }
        public string Note { get; set; }

        public List<TfmsChecklist> Checklists { get; set; } = new List<TfmsChecklist>();
        public List<TfmsCardPrepBy> PrepBy { get; set; } = new List<TfmsCardPrepBy>();
        public List<TfmsCardObject> Objects { get; set; } = new List<TfmsCardObject>();
    }

    public class TfmsChecklist
    {
        public int Card { get; set; }
        public int Desk { get; set; }
        public string PermitsReturned { get; set; }
        public string GroundsRemoved { get; set; }
        public string DisconnectsClosed { get; set; }
        public string HSGSReset { get; set; }
        public string RelaySysNormal { get; set; }
        public string OilPresNormal { get; set; }
        public string EquipCanBeEnerg { get; set; }
        public string EquipPrepForServ { get; set; }
        public string CheckedStnLogCrd { get; set; }
        public string AmmeterClearPerf { get; set; }
        public string AcceptanceLetter { get; set; }
    }

    public class TfmsCardPrepBy
    {
        public int Desk { get; set; }
        public string DeskName { get; set; }
        public string PreparedBy { get; set; }
        public string CheckedBy { get; set; }
    }

    public class TfmsCardObject
    {
        public int Object { get; set; }
        public string Name { get; set; }
        public int ObjectStatus { get; set; }
        public string ValidatedBy { get; set; }
        public int ObjectType { get; set; }
        public string TypeName { get; set; }
    }

    public class SoaCardLogEntry
    {
        public int Card { get; set; }
        public int SwitchingItem { get; set; }
        public string Log { get; set; }
        public string LogStatus { get; set; }
        public DateTime? LogTime { get; set; }
        public int EnteredBy { get; set; }
        public string EnteredByName { get; set; }
    }
}
