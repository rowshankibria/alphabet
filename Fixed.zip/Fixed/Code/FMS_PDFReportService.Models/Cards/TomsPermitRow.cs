using System;
using System.Collections.Generic;
using FMS_PDFReportService.Models.Jobs.Colors;

namespace FMS_PDFReportService.Models.Cards
{
    // One printed line of "Permits and Protections for ..." (TOMSWorkPermit.trdx).
    // Every row carries its permit's values; TOMSWorkPermit.trdx groups on PermitKey and prints the permit
    // once in the group header, then one detail line per protection move.
    // A permit without protection moves gets exactly one row with IsEmpty = true, which prints
    // "No protection moves for this permit".
    public class TomsPermitRow
    {
        public int PermitKey { get; set; }          // 1, 2, 3 ... in print order
        public int PermitJob { get; set; }
        public string PermitLabel { get; set; }     // "Work Permit" / "Test Permit"
        public string PermitIssued { get; set; }
        public string PermitID { get; set; }
        public string PermitType { get; set; }
        public string PermitEquipment { get; set; }
        public string PermitMove { get; set; }
        public string PermitComplete { get; set; }

        public bool IsEmpty { get; set; }

        // Protection move, display-ready (same shape and source as FMSProtection.trdx / PermitProtection).
        public string CardTypeName { get; set; }
        public string Card { get; set; }
        public string TOIssued { get; set; }
        public string TOComplete { get; set; }
        public string Subsordesk { get; set; }
        public string PrintID { get; set; }
        public string EquipClassName { get; set; }
        public string EquipName { get; set; }
        public string TOMove { get; set; }
        public string RSIssued { get; set; }
        public string RSComplete { get; set; }

        public const string WorkPermitLabel = "Work Permit";
        public const string TestPermitLabel = "Test Permit";

        // permits: in print order (Work Permits by Seq, then Test Permits by Seq), each with its protections.
        public static List<TomsPermitRow> Build(IEnumerable<WorkPermit> permits)
        {
            var rows = new List<TomsPermitRow>();
            if (permits == null) return rows;

            int key = 0;
            foreach (var p in permits)
            {
                key++;
                var protections = p.Protections ?? new List<PermitProtection>();
                if (protections.Count == 0)
                {
                    var empty = Permit(p, key);
                    empty.IsEmpty = true;
                    rows.Add(empty);
                    continue;
                }
                foreach (var prot in protections)
                {
                    var r = Permit(p, key);
                    r.IsEmpty = false;
                    r.CardTypeName = prot.CardTypeName;
                    r.Card = prot.Card;
                    r.TOIssued = prot.TOIssued;
                    r.TOComplete = prot.TOComplete;
                    r.Subsordesk = prot.Subsordesk;
                    r.PrintID = prot.PrintID;
                    r.EquipClassName = prot.EquipClassName;
                    r.EquipName = prot.EquipName;
                    r.TOMove = prot.TOMove;
                    r.RSIssued = prot.RSIssued;
                    r.RSComplete = prot.RSComplete;
                    rows.Add(r);
                }
            }
            return rows;
        }

        private static TomsPermitRow Permit(WorkPermit p, int key)
        {
            return new TomsPermitRow
            {
                PermitKey = key,
                PermitJob = p.Job,
                PermitLabel = p.StepPair == Constants.StepHeading_TestPermit ? TestPermitLabel : WorkPermitLabel,
                PermitIssued = TfmsRowRules.DateText(p.TOIssued),
                PermitID = p.PrintID ?? string.Empty,
                PermitType = p.EquipClassName ?? string.Empty,
                PermitEquipment = p.EquipName ?? string.Empty,
                PermitMove = p.TOMove ?? string.Empty,
                PermitComplete = TfmsRowRules.DateText(p.RSComplete),
                CardTypeName = string.Empty, Card = string.Empty, TOIssued = string.Empty, TOComplete = string.Empty,
                Subsordesk = string.Empty, PrintID = string.Empty, EquipClassName = string.Empty, EquipName = string.Empty,
                TOMove = string.Empty, RSIssued = string.Empty, RSComplete = string.Empty
            };
        }
    }
}
