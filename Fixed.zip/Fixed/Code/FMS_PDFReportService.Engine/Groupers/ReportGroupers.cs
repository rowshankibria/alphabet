using FMS_PDFReportService.Data.Repositories;
using FMS_PDFReportService.Engine.Rendering;
using FMS_PDFReportService.Engine.Services;
using FMS_PDFReportService.Models.Cards;
using FMS_PDFReportService.Models.Jobs.Colors;
using FMS_PDFReportService.Models.Reports;
using FMS_PDFReportService.Models.Reports.FmsDos;
using FMS_PDFReportService.Models.Reports.FmsOnline;
using System.Collections.Generic;
using System.Linq;
using Telerik.Reporting;

namespace FMS_PDFReportService.Engine.Groupers
{
    public class FMSGrouper : IReportGrouper
    {
        private readonly IFMSCardRepository _repo;
        private readonly TelerikReportRenderer _renderer;
        private readonly PermissionService _permissions;
        private readonly TemplatePathResolver _templatePath;

        public FMSGrouper(IFMSCardRepository repo, TelerikReportRenderer renderer,
            PermissionService permissions, TemplatePathResolver templatePath)
        {
            _repo = repo;
            _renderer = renderer;
            _permissions = permissions;
            _templatePath = templatePath;
        }

        public List<ReportSource> ComposeCard(int cardId, ReportRequest request)
        {
            // D6 layout: one top-level ReportSource per section (ReportBook page-breaks between them),
            // and each WorkPermit is its own composite (WP row + nested PhaseChecks/Protections/Locations
            // rendered inline via SubReport slots in FMSWorkPermit.trdx's ReportFooterSection).
            var header = _repo.LoadCardHeader(cardId, request.ArchiveFlag);
            var note = _repo.LoadCardNote(cardId);
            var jobs = _repo.LoadJobs(cardId, request.ArchiveFlag);

            if (request.ArchiveFlag == 0)
                FmsColorCalculator.Apply(jobs, _repo.LoadFmsColorInputs(cardId));
            PhaseCheckRules.Apply(jobs, _repo.LoadOpenPhaseChecks(cardId));
            jobs = GroupSpacer.AddBlankRows(jobs, request.SpareLines);

            var sources = new List<ReportSource>();

            // FeederCard = feeder header + jobs grid. Stands alone as page 1.
            sources.Add(_renderer.CreateReportSource(
                _templatePath.Resolve("FMS/FeederCard.trdx"),
                jobs,
                BuildHeaderParameters(header, note)));

            if (request.ReportType == 1)
            {
                var log = _repo.LoadFeederLog(cardId, request.ArchiveFlag);
                sources.Add(_renderer.CreateReportSource(
                    _templatePath.Resolve("FMS/FMSCardLog.trdx"),
                    log,
                    new Dictionary<string, object> { { "FeederName", header?.FeederName ?? string.Empty } }));

                // Tag permission gate (BR-RPT-040) — same gPermFMS_Tag gate DOS applies to RegTag and LocationTag.
                bool includeTags = _permissions.HasTagPermission(request.Permission);
                if (includeTags)
                {
                    var tags = _repo.LoadRegisteredTags(header.Feeder);
                    sources.Add(_renderer.CreateReportSource(
                        _templatePath.Resolve("FMS/FMSRegTag.trdx"),
                        tags,
                        new Dictionary<string, object> { { "FeederName", header?.FeederName ?? string.Empty } }));
                }

                var permits = _repo.LoadWorkPermits(cardId, request.ArchiveFlag).ToList();
                if (permits.Count == 0)
                {
                    // Empty-state: still emit one WorkPermit source so title + column headers render,
                    // and nested PhaseCheck/Protection/Location sub-reports show their own empty-state
                    // headers (F7 moved them into ReportHeaderSection so they fire on empty data).
                    var emptyNested = new Dictionary<string, ReportSource>
                    {
                        { "srPhaseCheck", _renderer.CreateReportSource(_templatePath.Resolve("FMS/FMSPhaseCheck.trdx"), new List<PhaseCheck>()) },
                        { "srProtection", _renderer.CreateReportSource(_templatePath.Resolve("FMS/FMSProtection.trdx"), new List<PermitProtection>()) }
                    };
                    if (includeTags)
                        emptyNested["srLocationTag"] = _renderer.CreateReportSource(
                            _templatePath.Resolve("FMS/FMSLocationTag.trdx"), new List<LocationTag>());

                    sources.Add(_renderer.CreateCompositeReportSource(
                        _templatePath.Resolve("FMS/FMSWorkPermit.trdx"),
                        new List<WorkPermit>(),
                        new Dictionary<string, object> { { "FeederName", header?.FeederName ?? string.Empty } },
                        emptyNested));
                }
                foreach (var permit in permits)
                {
                    permit.Protections = _repo.LoadProtections(permit.Job, request.ArchiveFlag).ToList();
                    permit.PhaseChecks = _repo.LoadPhaseChecks(cardId, header.Feeder, permit.Job, request.ArchiveFlag).ToList();
                    if (includeTags)
                        permit.LocationTags = _repo.LoadLocationTags(permit.Job).ToList();

                    var nestedSubs = new Dictionary<string, ReportSource>
                    {
                        { "srPhaseCheck", _renderer.CreateReportSource(_templatePath.Resolve("FMS/FMSPhaseCheck.trdx"), permit.PhaseChecks) },
                        { "srProtection", _renderer.CreateReportSource(_templatePath.Resolve("FMS/FMSProtection.trdx"), permit.Protections) }
                    };
                    if (includeTags)
                    {
                        // Zero-tag locations must print: DOS Detail.Height=0 is a minimum, AR still grows to fit (benchmark 1X24).
                        nestedSubs["srLocationTag"] = _renderer.CreateReportSource(
                            _templatePath.Resolve("FMS/FMSLocationTag.trdx"), permit.LocationTags);
                    }

                    sources.Add(_renderer.CreateCompositeReportSource(
                        _templatePath.Resolve("FMS/FMSWorkPermit.trdx"),
                        new List<WorkPermit> { permit },
                        new Dictionary<string, object> { { "FeederName", header?.FeederName ?? string.Empty } },
                        nestedSubs));
                }

                //This is the relay summary report, which is only generated for ReportType=1 (full card + log + permits + relay summary)
                //Due to proper explanation we are commenting out the relay summary report for now, as it is not required in the current scope of work. If needed, it can be uncommented and used in the future.
                //var relay = _repo.LoadRelaySummary(cardId, request.ArchiveFlag);
                //sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("FMS/FMSRelaySummary.trdx"), relay));
            }

            _renderer.PrependHeader(sources, _templatePath.Resolve("Common/PageHeader.trdx"));
            return sources;
        }

        private static Dictionary<string, object> BuildHeaderParameters(FmsCardHeader header, CardNote note)
        {
            if (header == null)
                return new Dictionary<string, object>();

            return new Dictionary<string, object>
            {
                { "Position", header.Position },
                { "FeederName", header.FeederName },
                { "CardClassName", header.CardClassName },
                { "SubstationName", header.SubstationName },
                { "CutOut", header.CutOut },
                { "CutIn", header.CutIn },
                { "StationGround", header.StationGround },
                { "GroundsOn", header.GroundsOn },
                { "DeadMoves", header.DeadMoves },
                { "DeadMovesTO", header.DeadMovesTO },
                { "Loop1", header.Loop1 },
                { "Loop2", header.Loop2 },
                { "Loop3", header.Loop3 },
                { "Loop4", header.Loop4 },
                { "Assoc", header.Assoc },
                { "NoteText", note?.NoteText }
            };
        }
    }

    public class TFMSGrouper : IReportGrouper
    {
        private readonly ITFMSCardRepository _repo;
        private readonly TelerikReportRenderer _renderer;
        private readonly TemplatePathResolver _templatePath;

        public TFMSGrouper(ITFMSCardRepository repo, TelerikReportRenderer renderer, TemplatePathResolver templatePath)
        {
            _repo = repo;
            _renderer = renderer;
            _templatePath = templatePath;
        }

        public List<ReportSource> ComposeCard(int cardId, ReportRequest request)
        {
            // Same layout as the DOS TOMS card: TFMSCard.trdx = card header + job grid (like FeederCard.trdx),
            // then (ReportType 1) the card log and "Permits and Protections".
            var archived = request.ArchiveFlag == 1;
            var header = _repo.LoadCardHeader(cardId, request.ArchiveFlag);
            var jobs = _repo.LoadJobs(cardId, request.ArchiveFlag).ToList();

            // Information-item severity is only looked up for an active, non-archived card (SOA_Main 'MoveColors').
            var severity = (!archived && header != null && header.Status == FMS_PDFReportService.Models.Constants.Card_Active)
                ? _repo.LoadInfoItemEquipSeverity(cardId)
                : new Dictionary<int, int?>();
            TfmsRowRules.Apply(jobs, cardId, archived, severity);
            jobs = CardRowSpacer.AddBlankRows(jobs, request.SpareLines);   // same as FMS GroupSpacer; keep after the colour rules

            var sources = new List<ReportSource>();
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TFMS/TFMSCard.trdx"),
                jobs, BuildHeaderParameters(header)));

            if (request.ReportType == 1)
            {
                var feederNames = new Dictionary<string, object> { { "FeederNames", header?.FeederNames ?? string.Empty } };

                sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TFMS/TFMSCardLog.trdx"),
                    _repo.LoadCardLog(cardId, request.ArchiveFlag).ToList(), feederNames));

                var permitRows = TomsPermitRow.Build(_repo.LoadPermitsWithProtections(cardId, request.ArchiveFlag));
                sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TFMS/TOMSWorkPermit.trdx"),
                    permitRows, feederNames));
            }

            // Company header + card title at the start of each card, identity line on its other pages.
            _renderer.PrependHeaderAtCardStart(sources, _templatePath.Resolve("Common/PageHeader.trdx"));
            return sources;
        }

        // All header values are passed as display strings (formatting tested in C#, not in the .trdx).
        private static Dictionary<string, object> BuildHeaderParameters(TfmsCardHeader header)
        {
            if (header == null)
                return new Dictionary<string, object>();

            return new Dictionary<string, object>
            {
                { "CardText", header.Card.ToString(System.Globalization.CultureInfo.InvariantCulture) },
                { "CardClassName", header.CardClassName ?? string.Empty },
                { "FeederNames", header.FeederNames ?? string.Empty },
                { "Description", header.Description ?? string.Empty },
                { "CutOutText", HeaderDate(header.CutOut) },
                { "CutInText", HeaderDate(header.CutIn) },
                { "ClosedLabel", ClosedLabel(header.Closed) },
                { "ClosedText", HeaderDate(header.Closed) },
                { "NoteText", header.Note ?? string.Empty }
            };
        }

        // MM/dd/yy HH:mm as on the DOS card; NULL and the Ingres empty date print blank.
        internal static string HeaderDate(System.DateTime? d)
        {
            return FmsColorCalculator.HasValue(d)
                ? d.Value.ToString("MM/dd/yy HH:mm", System.Globalization.CultureInfo.InvariantCulture)
                : string.Empty;
        }

        // "Card Closed:" is printed only on a closed card (tfmscard.js / tlscard.js card header).
        internal static string ClosedLabel(System.DateTime? closed)
        {
            return FmsColorCalculator.HasValue(closed) ? "Card Closed:" : string.Empty;
        }
    }

    public class SLCGrouper : IReportGrouper
    {
        private readonly ISLCCardRepository _repo;
        private readonly TelerikReportRenderer _renderer;
        private readonly TemplatePathResolver _templatePath;

        public SLCGrouper(ISLCCardRepository repo, TelerikReportRenderer renderer, TemplatePathResolver templatePath)
        {
            _repo = repo;
            _renderer = renderer;
            _templatePath = templatePath;
        }

        public List<ReportSource> ComposeCard(int cardId, ReportRequest request)
        {
            var sources = new List<ReportSource>();

            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("SLC/SLCCardHeader.trdx"),
                _repo.LoadCardHeader(cardId, request.ArchiveFlag)));
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("SLC/SLCCard.trdx"),
                _repo.LoadJobs(cardId, request.ArchiveFlag, request.SLCItemType, request.SWItemID)));

            if (request.ReportType == 1)
            {
                sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("SLC/SLCCardLog.trdx"),
                    _repo.LoadCardLog(cardId, request.ArchiveFlag)));
                sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("SLC/SLCWorkPermit.trdx"),
                    _repo.LoadWorkPermits(cardId, request.ArchiveFlag)));
            }

            _renderer.PrependHeader(sources, _templatePath.Resolve("Common/PageHeader.trdx"));
            return sources;
        }
    }

    public class TLSGrouper : IReportGrouper
    {
        private readonly ITLSCardRepository _repo;
        private readonly TelerikReportRenderer _renderer;
        private readonly TemplatePathResolver _templatePath;

        public TLSGrouper(ITLSCardRepository repo, TelerikReportRenderer renderer, TemplatePathResolver templatePath)
        {
            _repo = repo;
            _renderer = renderer;
            _templatePath = templatePath;
        }

        public List<ReportSource> ComposeCard(int cardId, ReportRequest request)
        {
            // TLS ALWAYS generates card-only regardless of ReportType (BR-RPT-029)
            // Same layout as the DOS TLS card: TLSCard.trdx = card header + job grid (like FeederCard.trdx).
            var header = _repo.LoadCardHeader(cardId, request.ArchiveFlag);
            var jobs = _repo.LoadJobs(cardId, request.ArchiveFlag).ToList();
            TlsRowRules.Apply(jobs, header?.Status ?? 0, _repo.LoadCoopPendingJobs(jobs));
            jobs = CardRowSpacer.AddBlankRows(jobs, request.SpareLines);   // same as FMS GroupSpacer; keep after the colour rules

            var sources = new List<ReportSource>();
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TLS/TLSCard.trdx"),
                jobs, BuildHeaderParameters(header)));

            // Company header + card title at the start of each card, identity line on its other pages.
            _renderer.PrependHeaderAtCardStart(sources, _templatePath.Resolve("Common/PageHeader.trdx"));
            return sources;
        }

        // All header values are passed as display strings (formatting tested in C#, not in the .trdx).
        private static Dictionary<string, object> BuildHeaderParameters(TlsCardHeader header)
        {
            if (header == null)
                return new Dictionary<string, object>();

            return new Dictionary<string, object>
            {
                { "Linenumber", header.Linenumber ?? string.Empty },
                { "LineTypeName", header.LineTypeName ?? string.Empty },
                { "RouteName", header.RouteName ?? string.Empty },
                { "CarrierName", header.CarrierName ?? string.Empty },
                { "CardTypeName", header.CardTypeName },
                { "FeedersText", header.FeedersText },
                { "StationsText", header.StationsText },
                { "ClosedLabel", TFMSGrouper.ClosedLabel(header.Closed) },
                { "ClosedText", TFMSGrouper.HeaderDate(header.Closed) },
                { "CardNote", header.CardNote ?? string.Empty },
                { "CircuitNote", header.Notes ?? string.Empty },
                { "ReasonForFailure", header.ReasonForFailure ?? string.Empty }
            };
        }
    }

    public class DSOGrouper : IReportGrouper
    {
        private readonly IDSOCardRepository _repo;
        private readonly TelerikReportRenderer _renderer;
        private readonly TemplatePathResolver _templatePath;

        public DSOGrouper(IDSOCardRepository repo, TelerikReportRenderer renderer, TemplatePathResolver templatePath)
        {
            _repo = repo;
            _renderer = renderer;
            _templatePath = templatePath;
        }

        public List<ReportSource> ComposeCard(int cardId, ReportRequest request)
        {
            var sources = new List<ReportSource>();

            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("DSO/DSOCardHeader.trdx"),
                _repo.LoadCardHeader(cardId, request.ArchiveFlag)));
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("DSO/DSOCard.trdx"),
                _repo.LoadJobs(cardId, request.ArchiveFlag)));

            if (request.ReportType == 1)
            {
                // Log only — Work Permits disabled in legacy (BR-RPT-031)
                sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("DSO/DSOCardLog.trdx"),
                    _repo.LoadCardLog(cardId, request.ArchiveFlag)));
            }

            _renderer.PrependHeader(sources, _templatePath.Resolve("Common/PageHeader.trdx"));
            return sources;
        }
    }

    public class SteamGrouper : IReportGrouper
    {
        private readonly ISteamCardRepository _repo;
        private readonly TelerikReportRenderer _renderer;
        private readonly TemplatePathResolver _templatePath;

        public SteamGrouper(ISteamCardRepository repo, TelerikReportRenderer renderer, TemplatePathResolver templatePath)
        {
            _repo = repo;
            _renderer = renderer;
            _templatePath = templatePath;
        }

        public List<ReportSource> ComposeCard(int cardId, ReportRequest request)
        {
            // Steam ALWAYS generates card-only (BR-RPT-030)
            var sources = new List<ReportSource>();

            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("Steam/SteamCardHeader.trdx"),
                _repo.LoadCardHeader(cardId, request.ArchiveFlag)));
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("Steam/SteamCard.trdx"),
                _repo.LoadJobs(cardId, request.ArchiveFlag)));

            return sources;
        }
    }

    public class ISWPPermitGrouper : IReportGrouper
    {
        private readonly IISWPRepository _repo;
        private readonly TelerikReportRenderer _renderer;
        private readonly TemplatePathResolver _templatePath;

        public ISWPPermitGrouper(IISWPRepository repo, TelerikReportRenderer renderer, TemplatePathResolver templatePath)
        {
            _repo = repo;
            _renderer = renderer;
            _templatePath = templatePath;
        }

        public List<ReportSource> ComposeCard(int cardId, ReportRequest request)
        {
            var permitId = cardId; // For ISWP, the "cardId" is actually a permit ID
            var sources = new List<ReportSource>();

            var permit = _repo.LoadPermitDetail(permitId);
            var equipment = _repo.LoadEquipment(permitId);
            var conditions = _repo.LoadConditions(permitId);
            var permitLog = _repo.LoadPermitLog(permitId);

            // ISWPPermit.trdx is a scalar permit-header sheet, so its DataSource must be the
            // ISWPPermitDetail itself. Equipment / Conditions / Log each flow to their own reports below.
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("ISWP/ISWPPermit.trdx"), permit));
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("ISWP/ISWPEquipment.trdx"), equipment));
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("ISWP/ISWPConditions.trdx"), conditions));
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("ISWP/ISWPPermitLog.trdx"), permitLog));

            if (request.ReportType == 1)
            {
                var requestDetail = _repo.LoadRequestDetail(permitId);
                var requestLog = _repo.LoadRequestLog(permitId);
                sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("ISWP/ISWPRequest.trdx"), requestDetail));
                sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("ISWP/ISWPRequestLog.trdx"), requestLog));
            }

            return sources;
        }
    }

    public class RPMGrouper : IReportGrouper
    {
        private readonly IRPMRepository _repo;
        private readonly TelerikReportRenderer _renderer;
        private readonly TemplatePathResolver _templatePath;

        public RPMGrouper(IRPMRepository repo, TelerikReportRenderer renderer, TemplatePathResolver templatePath)
        {
            _repo = repo;
            _renderer = renderer;
            _templatePath = templatePath;
        }

        public List<ReportSource> ComposeCard(int cardId, ReportRequest request)
        {
            // For RPM, cardId is the groupId
            return ComposeGroup(cardId);
        }

        public List<ReportSource> ComposeGroup(int groupId)
        {
            var sources = new List<ReportSource>();

            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("RPM/RPMFeeders.trdx"),
                _repo.LoadFeeders(groupId)));
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("RPM/RPMCircuits.trdx"),
                _repo.LoadCircuits(groupId)));
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("RPM/RPMGrid.trdx"),
                _repo.LoadMatrixGrid(groupId)));
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("RPM/RPMNotes.trdx"),
                _repo.LoadNotes(groupId)));
            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("RPM/RPMRelayInfo.trdx"),
                _repo.LoadRelayInfo(groupId)));

            var diagrams = _repo.LoadDiagrams(groupId);
            if (diagrams != null && diagrams.Any())
            {
                sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("RPM/RPMDiagrams.trdx"), diagrams));
            }

            return sources;
        }
    }
}
