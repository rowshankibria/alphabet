using System;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Serilog;
using Telerik.Reporting;
using Telerik.Reporting.Processing;
using Telerik.Reporting.XmlSerialization;

namespace FMS_PDFReportService.Engine.Rendering
{
    public class TelerikReportRenderer
    {
        private readonly ExportFormatResolver _formatResolver;

        public TelerikReportRenderer()
        {
            _formatResolver = new ExportFormatResolver();
        }

        public TelerikReportRenderer(ExportFormatResolver formatResolver)
        {
            _formatResolver = formatResolver;
        }

        public byte[] RenderReport(string templatePath, object dataSource, Dictionary<string, object> parameters = null, string format = "PDF")
        {
            Log.Debug("Rendering report: Template={Template} Format={Format}", Path.GetFileName(templatePath), format);
            var reportSource = CreateReportSource(templatePath, dataSource, parameters);
            return RenderFromSource(reportSource, format);
        }

        public byte[] RenderFromSource(ReportSource reportSource, string format = "PDF")
        {
            var sw = Stopwatch.StartNew();
            var formatInfo = _formatResolver.Resolve(format);
            var processor = new ReportProcessor();
            var result = processor.RenderReport(formatInfo.TelerikExtension, reportSource, null);

            if (result.HasErrors)
            {
                var messages = result.Errors.Select(e => e.Message);
                Log.Error("Report rendering failed: {Errors}", string.Join("; ", messages));
                throw new InvalidOperationException(
                    "Report rendering failed: " + string.Join("; ", messages));
            }

            sw.Stop();
            Log.Debug("Report rendered in {ElapsedMs}ms, {Size} bytes", sw.ElapsedMilliseconds, result.DocumentBytes.Length);
            return result.DocumentBytes;
        }

        public bool RenderToFile(string templatePath, object dataSource, Dictionary<string, object> parameters, string outputPath, string format = "PDF")
        {
            var bytes = RenderReport(templatePath, dataSource, parameters, format);
            File.WriteAllBytes(outputPath, bytes);
            return true;
        }

        public ReportSource CreateReportSource(string templatePath, object dataSource, Dictionary<string, object> parameters = null)
        {
            // Templates declare their schema via an ObjectDataSource/ClrType and bind fields with
            // "= Fields.X". Telerik Reporting has no "Object" report-parameter type, so runtime data
            // cannot be handed to the report as a parameter — it must be assigned to Report.DataSource
            // on a materialized report instance. We therefore deserialize the .trdx, inject the data,
            // and wrap it in an InstanceReportSource (which ReportBook and ReportProcessor consume the
            // same way as a UriReportSource).
            var report = DeserializeReport(templatePath);

            if (dataSource != null)
            {
                report.DataSource = dataSource;
            }

            var reportSource = new InstanceReportSource { ReportDocument = report };

            if (parameters != null)
            {
                foreach (var kvp in parameters)
                {
                    // Only forward parameters the template actually declares; supplying a value for an
                    // undeclared parameter throws during processing.
                    if (ReportDeclaresParameter(report, kvp.Key))
                        reportSource.Parameters.Add(kvp.Key, kvp.Value);
                }
            }

            return reportSource;
        }

        // Composes a wrapper template (e.g. FeederCard.trdx) that contains named SubReport slots. Each
        // slot with a matching entry in <paramref name="subReports"/> gets its ReportSource swapped in
        // so the child renders inline; any slot without a match is hidden. This lets us produce a single
        // Report per card whose siblings flow inside one page-stream instead of being page-broken by
        // Telerik.ReportBook.
        public ReportSource CreateCompositeReportSource(
            string topTemplatePath,
            object topDataSource,
            Dictionary<string, object> topParameters,
            IDictionary<string, ReportSource> subReports)
        {
            var report = DeserializeReport(topTemplatePath);

            if (topDataSource != null)
                report.DataSource = topDataSource;

            foreach (var sub in CollectSubReports(report))
            {
                if (subReports != null && !string.IsNullOrEmpty(sub.Name) && subReports.TryGetValue(sub.Name, out var innerSource))
                    sub.ReportSource = innerSource;
                else
                    sub.Visible = false;
            }

            var reportSource = new InstanceReportSource { ReportDocument = report };

            if (topParameters != null)
            {
                foreach (var kvp in topParameters)
                {
                    if (ReportDeclaresParameter(report, kvp.Key))
                        reportSource.Parameters.Add(kvp.Key, kvp.Value);
                }
            }

            return reportSource;
        }

        // SubReport is not allowed in a PageHeaderSection, so the shared header's items are moved into the
        // top of each top-level report's PageHeaderSection (every page), above any existing page-header items.
        public void PrependHeader(IEnumerable<ReportSource> sources, string headerTemplatePath)
        {
            foreach (var source in sources)
            {
                if (!(source is InstanceReportSource instance) || !(instance.ReportDocument is Telerik.Reporting.Report report))
                    continue;

                var header = DeserializeReport(headerTemplatePath);
                var headerBody = header.Items.OfType<Telerik.Reporting.DetailSection>().First();
                var width = report.Width;
                var height = headerBody.Height;

                // The company header supplies its own top whitespace; the host's 0.5in margin leaves a large gap above it.
                var margins = report.PageSettings.Margins;
                var maxTop = Telerik.Reporting.Drawing.Unit.Inch(0.25);
                if (margins.Top > maxTop)
                    report.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(margins.Left, margins.Right, maxTop, margins.Bottom);

                var pageHeader = report.Items.OfType<Telerik.Reporting.PageHeaderSection>().FirstOrDefault();
                if (pageHeader == null)
                {
                    pageHeader = new Telerik.Reporting.PageHeaderSection { Name = "pageHeader", Height = Telerik.Reporting.Drawing.Unit.Inch(0) };
                    report.Items.Add(pageHeader);
                }

                var existingItems = pageHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList();
                foreach (var item in existingItems)
                    item.Top = item.Top + height;
                pageHeader.Height = pageHeader.Height + height;

                if (!pageHeader.PrintOnFirstPage)
                {
                    // Company header must print on page 1; keep the template's own items continuation-only.
                    // PageNumber is book-wide unless the report sets PageNumberingStyle=ResetNumberingAndCount.
                    pageHeader.PrintOnFirstPage = true;
                    foreach (var item in existingItems)
                        item.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= PageNumber > 1"));
                }

                foreach (var item in headerBody.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
                {
                    // Header is authored at landscape width; clip so portrait hosts don't spill onto an extra page.
                    if (item.Left + item.Width > width)
                        item.Width = width - item.Left;
                    headerBody.Items.Remove(item);
                    pageHeader.Items.Add(item);
                }
            }
        }

        // TLS / TOMS cards. Page numbers run on over the whole ReportBook, so "PageNumber = 1" only means
        // "first page of the whole PDF". Instead this relies on PageHeaderSection.PrintOnFirstPage = False,
        // which Telerik applies to the first page of EACH report (= each card):
        //   first page of a card : company header + the template's report header (card title + card box)
        //   other pages of a card: company header + the template's page header (card identity line)
        // So the company header is put in BOTH the report header and the page header, and the page header
        // keeps PrintOnFirstPage = False. Reports whose page header prints on the first page (log, permits)
        // get exactly the old PrependHeader behaviour.
        public void PrependHeaderAtCardStart(IEnumerable<ReportSource> sources, string headerTemplatePath)
        {
            foreach (var source in sources)
            {
                if (!(source is InstanceReportSource instance) || !(instance.ReportDocument is Telerik.Reporting.Report report))
                    continue;

                var pageHeader = report.Items.OfType<Telerik.Reporting.PageHeaderSection>().FirstOrDefault();
                var reportHeader = report.Items.OfType<Telerik.Reporting.ReportHeaderSection>().FirstOrDefault();
                if (pageHeader == null || pageHeader.PrintOnFirstPage || reportHeader == null)
                {
                    PrependHeader(new[] { source }, headerTemplatePath);
                    continue;
                }

                var width = report.Width;

                // Same margin rule as PrependHeader.
                var margins = report.PageSettings.Margins;
                var maxTop = Telerik.Reporting.Drawing.Unit.Inch(0.25);
                if (margins.Top > maxTop)
                    report.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(margins.Left, margins.Right, maxTop, margins.Bottom);

                // Pages 2+ of the card: company header above the card identity line. PrintOnFirstPage stays False.
                var forPageHeader = DeserializeReport(headerTemplatePath).Items.OfType<Telerik.Reporting.DetailSection>().First();
                var pageHeight = forPageHeader.Height;
                foreach (var item in pageHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
                    item.Top = item.Top + pageHeight;
                pageHeader.Height = pageHeader.Height + pageHeight;
                foreach (var item in forPageHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
                {
                    if (item.Left + item.Width > width)
                        item.Width = width - item.Left;
                    forPageHeader.Items.Remove(item);
                    pageHeader.Items.Add(item);
                }

                // First page of the card: company header above the card title and card box (own copy of the items).
                var forReportHeader = DeserializeReport(headerTemplatePath).Items.OfType<Telerik.Reporting.DetailSection>().First();
                var reportHeight = forReportHeader.Height;
                foreach (var item in reportHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
                    item.Top = item.Top + reportHeight;
                reportHeader.Height = reportHeader.Height + reportHeight;
                foreach (var item in forReportHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
                {
                    if (item.Left + item.Width > width)
                        item.Width = width - item.Left;
                    forReportHeader.Items.Remove(item);
                    reportHeader.Items.Add(item);
                }
            }
        }

        private static IEnumerable<Telerik.Reporting.SubReport> CollectSubReports(Telerik.Reporting.Report report)
        {
            foreach (var section in report.Items)
                foreach (var found in WalkForSubReports(section))
                    yield return found;
        }

        // Recursive walk: SubReport items normally live directly inside a Section but reflect-and-recurse
        // guards against future templates that place them inside a PictureBox / Panel / GroupSection.
        private static IEnumerable<Telerik.Reporting.SubReport> WalkForSubReports(object node)
        {
            if (node == null) yield break;
            if (node is Telerik.Reporting.SubReport sub)
            {
                yield return sub;
                yield break;
            }
            var itemsProp = node.GetType().GetProperty("Items");
            if (itemsProp == null) yield break;
            if (!(itemsProp.GetValue(node) is IEnumerable children)) yield break;
            foreach (var child in children)
                foreach (var found in WalkForSubReports(child))
                    yield return found;
        }

        private static Telerik.Reporting.Report DeserializeReport(string templatePath)
        {
            var serializer = new ReportXmlSerializer();
            using (var stream = File.OpenRead(templatePath))
            {
                return (Telerik.Reporting.Report)serializer.Deserialize(stream);
            }
        }

        private static bool ReportDeclaresParameter(Telerik.Reporting.Report report, string name)
        {
            foreach (ReportParameter parameter in report.ReportParameters)
            {
                if (parameter.Name == name)
                    return true;
            }
            return false;
        }

        public string[] GetSupportedFormats()
        {
            return new[] { "PDF", "RTF", "XLS", "XLSX", "HTML", "MHTML", "IMAGE" };
        }
    }
}
