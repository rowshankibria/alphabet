"""Minimal .trdx emulator for visual checking (NOT Telerik). Draws report header, column header and
detail rows of a generated template with rows computed by the real C# rules (rows.json)."""
import json, re, sys
import xml.etree.ElementTree as ET
import pymupdf

trdx, rows_json, key, out_pdf = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
params = json.loads(sys.argv[5]) if len(sys.argv) > 5 else {}
rows = json.load(open(rows_json, encoding="utf-8-sig"))[key]
NS = {"t": "http://schemas.telerik.com/reporting/2026/2.1"}
root = ET.parse(trdx).getroot()
IN = 72.0
# Colour parameter defaults (what support can edit in the Report Designer); argv[5] values override them
for rp in root.iter("{%s}ReportParameter" % NS["t"]):
    s = rp.find("t:Value/t:String", NS)
    if s is not None: params.setdefault(rp.get("Name"), s.text)

def inch(v): return float(v.replace("in", ""))
def hexrgb(h):
    h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))

def ev(expr, row):
    if expr is None: return ""
    e = expr.strip()
    if not e.startswith("="): return e
    e = e[1:].strip()
    # colour chain: IIf(Fields.XKey = "K", Parameters.K.Value, <rest>) ... ending in Fields.X
    while True:
        m = re.fullmatch(r'IIf\(Fields\.(\w+) = "(\w+)", Parameters\.(\w+)\.Value, (.*)\)', e, re.S)
        if not m: break
        if row.get(m.group(1)) == m.group(2): return params.get(m.group(3), "")
        e = m.group(4).strip()
    m = re.fullmatch(r"Not Fields\.(\w+)", e)
    if m: return not row.get(m.group(1))
    m = re.fullmatch(r"Fields\.(\w+)", e)
    if m: return row.get(m.group(1))
    m = re.fullmatch(r"Parameters\.(\w+)\.Value", e)
    if m: return params.get(m.group(1), "")
    m = re.fullmatch(r'"([^"]*)" \+ Parameters\.(\w+)\.Value', e)
    if m: return m.group(1) + params.get(m.group(2), "")
    if e.startswith("Now()") or "PageNumber" in e: return e
    raise ValueError("unsupported expression: " + expr)

def boxes(section):
    res = []
    for tb in section.iter("{%s}TextBox" % NS["t"]):
        st = tb.find("t:Style", NS); font = st.find("t:Font", NS); bs = st.find("t:BorderStyle", NS)
        binds = {b.get("Path"): b.get("Expression") for b in tb.iter("{%s}Binding" % NS["t"])}
        res.append(dict(name=tb.get("Name"), l=inch(tb.get("Left")), t=inch(tb.get("Top")), w=inch(tb.get("Width")),
                        h=inch(tb.get("Height")), value=tb.get("Value"), align=st.get("TextAlign") or "Left",
                        valign=st.get("VerticalAlign"), size=float(font.get("Size").replace("pt", "")),
                        bold=font.get("Bold") == "True", border=dict(bs.attrib) if bs is not None else {}, binds=binds))
    return res

def draw(page, x0, y0, b, row):
    vis = ev(b["binds"].get("Visible"), row) if "Visible" in b["binds"] else True
    if not vis: return
    r = pymupdf.Rect((x0 + b["l"]) * IN, (y0 + b["t"]) * IN, (x0 + b["l"] + b["w"]) * IN, (y0 + b["t"] + b["h"]) * IN)
    bg = ev(b["binds"].get("Style.BackgroundColor"), row) if "Style.BackgroundColor" in b["binds"] else None
    fg = ev(b["binds"].get("Style.Color"), row) if "Style.Color" in b["binds"] else "#000000"
    if bg and bg.upper() != "#FFFFFF": page.draw_rect(r, color=None, fill=hexrgb(bg))
    bd = b["border"]
    if bd.get("Default") == "Solid": page.draw_rect(r, color=(0, 0, 0), width=0.5)
    if bd.get("Bottom") == "Solid": page.draw_line(r.bl, r.br, color=(0, 0, 0), width=0.5)
    text = ev(b["value"], row)
    if not isinstance(text, str) or not text: return
    fontname = "helvetica-bold" if b["bold"] else "helvetica"
    align = {"Left": 0, "Center": 1, "Right": 2}[b["align"]]
    tr = pymupdf.Rect(r.x0 + 2, r.y0 + 1, r.x1 - 2, r.y1)
    if b["valign"] == "Middle":
        tr = pymupdf.Rect(tr.x0, r.y0 + (r.height - b["size"] * 1.25) / 2, tr.x1, r.y1 + 6)
    tr = pymupdf.Rect(tr.x0, tr.y0, tr.x1, tr.y1 + 40)   # emulate CanGrow: never drop overflowing text
    page.insert_textbox(tr, text.replace(" ", " ") if text.startswith(" ") else text,
                        fontsize=b["size"] if pymupdf.get_text_length(text, fontname, b["size"]) < (r.width-4)*1.9 else b["size"]*0.9, fontname=fontname, color=hexrgb(fg or "#000000"), align=align)

doc = pymupdf.open(); page = doc.new_page(width=11 * IN, height=8.5 * IN)
x0, y = 0.15, 0.5
rh = root.find("t:Items/t:ReportHeaderSection", NS)
if rh is not None:
    for b in boxes(rh): draw(page, x0, y, b, {})
    y += inch(rh.get("Height"))
ph = root.find("t:Items/t:PageHeaderSection", NS)
if ph is not None and ph.get("PrintOnFirstPage") != "False":
    for b in boxes(ph): draw(page, x0, y, b, {})
    y += inch(ph.get("Height"))
grp = root.find("t:Groups/t:Group/t:GroupHeader/t:GroupHeaderSection", NS)
gexpr = root.find("t:Groups/t:Group/t:Groupings/t:Grouping", NS).get("Expression")
gfoot = root.find("t:Groups/t:Group/t:GroupFooter/t:GroupFooterSection", NS)
det = root.find("t:Items/t:DetailSection", NS); dh = inch(det.get("Height"))
dboxes = boxes(det); gboxes = boxes(grp); prev = None; first = True
for row in rows:
    gk = ev(gexpr, row) if gexpr != "=1" else 1
    if first or gk != prev:
        if not first and gfoot is not None: y += inch(gfoot.get("Height"))
        for b in gboxes: draw(page, x0, y, b, row)
        y += inch(grp.get("Height")); prev = gk; first = False
    for b in dboxes: draw(page, x0, y, b, row)
    y += dh
    if y > 8.0: break
doc.save(out_pdf)
page.get_pixmap(dpi=110).save(out_pdf.replace(".pdf", ".png"))
print("rendered", len(rows), "rows ->", out_pdf)
