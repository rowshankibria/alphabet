// Type-check stand-ins for the Telerik Reporting API members used by TelerikReportRenderer.cs.
// NO behaviour. Lets the real renderer file (incl. PrependHeaderAtCardStart) be compiled on a machine
// without Telerik, to catch typos / type errors. It cannot prove the real Telerik API accepts the same calls;
// the members used are the same ones the existing, working PrependHeader already uses.
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace Telerik.Reporting.Drawing
{
    public struct Unit
    {
        public double Value;
        public static Unit Inch(double v) { return new Unit { Value = v }; }
        public static Unit operator +(Unit a, Unit b) { return Inch(a.Value + b.Value); }
        public static Unit operator -(Unit a, Unit b) { return Inch(a.Value - b.Value); }
        public static bool operator >(Unit a, Unit b) { return a.Value > b.Value; }
        public static bool operator <(Unit a, Unit b) { return a.Value < b.Value; }
    }
    public class MarginsU
    {
        public MarginsU(Unit left, Unit right, Unit top, Unit bottom) { Left = left; Right = right; Top = top; Bottom = bottom; }
        public Unit Left, Right, Top, Bottom;
    }
}

namespace Telerik.Reporting
{
    using Telerik.Reporting.Drawing;
    public interface IReportDocument { }
    public class ReportSource { }
    public class ParameterCollection { public void Add(string name, object value) { } }
    public class InstanceReportSource : ReportSource { public IReportDocument ReportDocument { get; set; } public ParameterCollection Parameters { get; } = new ParameterCollection(); }
    public class Binding { public Binding(string path, string expression) { } }
    public class BindingCollection : List<Binding> { }
    public class ItemCollection : List<ReportItemBase> { }
    public class ReportItemBase { public string Name { get; set; } public ItemCollection Items { get; } = new ItemCollection(); public bool Visible { get; set; } }
    public class ReportItem : ReportItemBase { public Unit Top { get; set; } public Unit Left { get; set; } public Unit Width { get; set; } public BindingCollection Bindings { get; } = new BindingCollection(); }
    public class SubReport : ReportItem { public ReportSource ReportSource { get; set; } }
    public class ReportSectionBase : ReportItemBase { public Unit Height { get; set; } }
    public class DetailSection : ReportSectionBase { }
    public class PageHeaderSection : ReportSectionBase { public bool PrintOnFirstPage { get; set; } = true; }
    public class ReportHeaderSection : ReportSectionBase { }
    public class PageSettings { public MarginsU Margins { get; set; } }
    public class ReportParameter { public string Name { get; set; } }
    public class ReportParameterCollection : List<ReportParameter> { }
    public class Report : ReportItemBase, IReportDocument
    {
        public object DataSource { get; set; }
        public Unit Width { get; set; }
        public PageSettings PageSettings { get; } = new PageSettings();
        public ReportParameterCollection ReportParameters { get; } = new ReportParameterCollection();
    }
}

namespace Telerik.Reporting.Processing
{
    public class RenderingResult { public bool HasErrors; public Exception[] Errors = new Exception[0]; public byte[] DocumentBytes = new byte[0]; }
    public class ReportProcessor { public RenderingResult RenderReport(string format, Telerik.Reporting.ReportSource source, Hashtable deviceInfo) { return new RenderingResult(); } }
}

namespace Telerik.Reporting.XmlSerialization
{
    public class ReportXmlSerializer { public object Deserialize(Stream s) { return new Telerik.Reporting.Report(); } }
}
