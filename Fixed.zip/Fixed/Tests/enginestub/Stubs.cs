// Type-check stubs ONLY (no behaviour). Signatures copied from the real Engine / Telerik API used by ReportGroupers.cs.
using System.Collections.Generic;
namespace Telerik.Reporting { public class ReportSource { } }
namespace FMS_PDFReportService.Engine.Rendering
{
    using Telerik.Reporting;
    public class TelerikReportRenderer
    {
        public static List<(string Template, object Data, Dictionary<string, object> Params)> Calls = new List<(string, object, Dictionary<string, object>)>();
        public ReportSource CreateReportSource(string templatePath, object dataSource, Dictionary<string, object> parameters = null)
        { Calls.Add((templatePath, dataSource, parameters)); return new ReportSource(); }
        public ReportSource CreateCompositeReportSource(string topTemplatePath, object topDataSource, Dictionary<string, object> topParameters, IDictionary<string, ReportSource> subReports)
        { Calls.Add((topTemplatePath, topDataSource, topParameters)); return new ReportSource(); }
        public static string HeaderMode;
        public void PrependHeader(IEnumerable<ReportSource> sources, string headerTemplatePath) { HeaderMode = "Plain"; }
        public void PrependHeaderAtCardStart(IEnumerable<ReportSource> sources, string headerTemplatePath) { HeaderMode = "AtCardStart"; }
    }
    public class TemplatePathResolver { public string Resolve(string templateRelativePath) { return templateRelativePath; } }
}
namespace FMS_PDFReportService.Engine.Services { public class PermissionService { public bool HasTagPermission(string permission) { return true; } } }
