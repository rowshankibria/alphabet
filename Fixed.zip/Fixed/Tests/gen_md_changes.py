"""Writes the "C# changes - every file" section into TLS_Fix.md and TOMS_Fix.md.
Diffs are generated from the original Telerik-proj files vs Fixed/Code, so the text always matches the code.
Usage: PROJ=<Telerik-proj> python gen_md_changes.py"""
import difflib, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
FX = os.path.dirname(HERE)
PROJ = os.environ["PROJ"]
CODE = os.path.join(FX, "Code")
START, END = "<!-- CSHARP-CHANGES START -->", "<!-- CSHARP-CHANGES END -->"

def read(p):
    with open(p, encoding="utf-8-sig") as f:
        return f.read().replace("\r\n", "\n").split("\n")

def hunks(rel):
    """Unified diff of one file, split into hunks (list of (header, lines))."""
    a, b = read(os.path.join(PROJ, rel)), read(os.path.join(CODE, rel))
    out, cur = [], None
    for line in list(difflib.unified_diff(a, b, lineterm="", n=3))[2:]:
        if line.startswith("@@"):
            cur = [line]; out.append(cur)
        else:
            cur.append(line)
    return out

def count(lines):
    return sum(1 for l in lines if l.startswith("+") and not l.startswith("+++")), \
           sum(1 for l in lines if l.startswith("-") and not l.startswith("---"))

def block(rel, kind, what, hunk_filter=None, shared=None):
    fence = "xml" if rel.endswith(".csproj") else "csharp"
    t = [f"#### `{rel.replace('/', chr(92))}`", "", f"**Action:** {kind}  ", f"**Type of change:** {what}  "]
    if shared:
        t.append(f"**Shared:** {shared}  ")
    if kind.startswith("ADD"):
        body = read(os.path.join(CODE, rel))
        while body and body[-1] == "": body.pop()
        t += [f"**Size:** {len(body)} lines (complete file below)", "", f"```{fence}"] + body + ["```", ""]
        return "\n".join(t)
    hs = hunks(rel)
    if hunk_filter:
        hs = [h for h in hs if hunk_filter("\n".join(h))]
    allines = [l for h in hs for l in h]
    plus, minus = count(allines)
    t += [f"**Lines:** +{plus} / -{minus} (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)", "", "```diff"]
    for h in hs:
        t += h
    t += ["```", ""]
    return "\n".join(t)

M, D, E = "FMS_PDFReportService.Models/", "FMS_PDFReportService.Data/", "FMS_PDFReportService.Engine/"
is_tls_hunk = lambda h: "TLSGrouper" in h or "TlsRowRules" in h or "TLS/TLS" in h
is_tfms_hunk = lambda h: not is_tls_hunk(h)

TLS = [
    ("REPLACE (full file)", M + "Jobs/TlsJob.cs", "Model — 23 new properties added at the end of the class: display text and colours for the grid, `IsBlankRow` for spare rows, and 6 colour keys (`...BgKey` / `...FgKey`, = TLSCard.trdx colour parameter names). No existing property changed or removed.", None, None),
    ("REPLACE (full file)", M + "Cards/TlsCardModels.cs", "Model — `TlsCardHeader`: 2 new data properties (`FeederNames`, `SubstationNames`), 3 new read-only properties (`CardTypeName`, `FeedersText`, `StationsText`), 3 new helper methods (`JoinNames`, `Squeeze`, `SplitNames`).", None, None),
    ("ADD (new file)", M + "Jobs/Colors/DosColors.cs", "New static class — colour palette as the DOS PDFs draw it (OpenROAD colour code → hex), colour keys (= report parameter names), TOMS/TLS palettes (key → default hex) and `KeyFromCode`.", None, "also used by TOMS"),
    ("ADD (new file)", M + "Jobs/Colors/TlsRowRules.cs", "New static class — row rules: texts, date gray-out, heading colour, status T, Co-Op pale red. Rules set colour keys; `Resolve()` derives every hex from the key.", None, None),
    ("ADD (new file)", M + "Jobs/Colors/CardRowSpacer.cs", "New static class — spare blank rows (query string LINE / `request.SpareLines`) for TLS and TOMS, same algorithm as FMS `GroupSpacer`; FMS file not touched.", None, "also used by TOMS (same file as in TOMS_Fix.md)"),
    ("REPLACE (full file)", M + "FMS_PDFReportService.Models.csproj", "Project file — 5 `<Compile Include>` lines for the new .cs files.", None, "same file as in TOMS_Fix.md"),
    ("REPLACE (full file)", D + "Queries/TLSQueries.cs", "SQL — 4 new queries: `LoadFeeders`, `LoadStations`, `LoadFeederStationNamesArchive`, `FindCoopPending`. Existing queries unchanged.", None, None),
    ("REPLACE (full file)", D + "Repositories/ITLSCardRepository.cs", "Interface — 1 new method signature `LoadCoopPendingJobs`.", None, None),
    ("REPLACE (full file)", D + "Repositories/TLSCardRepository.cs", "Repository — `LoadCardHeader` changed (now loads Feeders/Stations); 1 new method `LoadCoopPendingJobs`.", None, None),
    ("REPLACE (full file)", E + "Rendering/TelerikReportRenderer.cs", "Renderer — 1 new public method `PrependHeaderAtCardStart` (company logo + card title at the start of each card, identity line on the card's other pages; works with continuous page numbers). Existing methods unchanged.", None, "used by TLS and TOMS (same file as in TOMS_Fix.md)"),
    ("REPLACE (full file)", E + "Groupers/ReportGroupers.cs", "Grouper — `TLSGrouper.ComposeCard` rewritten (one template, rows coloured, spare blank rows via `CardRowSpacer` like FMS `GroupSpacer`, header as parameters, logo via `PrependHeaderAtCardStart`); 1 new private method `BuildHeaderParameters`. Only the TLS part is shown here.", is_tls_hunk, "the same file also contains the TOMS change (TOMS_Fix.md); copy the file once"),
]
TOMS = [
    ("REPLACE (full file)", M + "Jobs/TfmsJob.cs", "Model — 31 new properties added at the end of the class: display text and colours for the grid, `IsBlankRow` for spare rows, and 9 colour keys (`...BgKey` / `...FgKey`, = TFMSCard.trdx colour parameter names). No existing property changed or removed.", None, None),
    ("REPLACE (full file)", M + "Cards/TfmsCardModels.cs", "Model — `TfmsCardHeader`: 4 new properties (`CardClassName`, `CutOut`, `CutIn`, `Note`).", None, None),
    ("ADD (new file)", M + "Cards/TomsPermitRow.cs", "New class — one printed line of Permits and Protections + `Build()` that flattens permits and their protections.", None, None),
    ("ADD (new file)", M + "Jobs/Colors/TfmsRowRules.cs", "New classes — `InfoItemEquipSeverity` (query row) and `TfmsRowRules` (row rules: dates, gray equipment, G, move colours, bands, S severity; Status compared without trailing blanks). Rules set colour keys; `Resolve()` derives every hex from the key.", None, None),
    ("ADD (new file)", M + "Jobs/Colors/DosColors.cs", "New static class — colour palette as the DOS PDFs draw it, colour keys (= report parameter names), TOMS/TLS palettes (key → default hex) and `KeyFromCode`.", None, "same file as in TLS_Fix.md"),
    ("ADD (new file)", M + "Jobs/Colors/CardRowSpacer.cs", "New static class — spare blank rows (query string LINE / `request.SpareLines`) for TLS and TOMS, same algorithm as FMS `GroupSpacer`; FMS file not touched.", None, "also used by TLS (same file as in TLS_Fix.md)"),
    ("REPLACE (full file)", M + "FMS_PDFReportService.Models.csproj", "Project file — 5 `<Compile Include>` lines for the new .cs files.", None, "same file as in TLS_Fix.md"),
    ("REPLACE (full file)", D + "Queries/TFMSQueries.cs", "SQL — 5 new queries: `LoadSoaCard`, `LoadSoaCardArchive`, `LoadInfoItemEquipSeverity`, `LoadPermits`, `LoadPermitsArchive`; comment marking the old `LoadWorkPermits` (StepPair = 3) obsolete. Existing queries unchanged.", None, None),
    ("REPLACE (full file)", D + "Repositories/ITFMSCardRepository.cs", "Interface — 2 new method signatures `LoadPermitsWithProtections`, `LoadInfoItemEquipSeverity`.", None, None),
    ("REPLACE (full file)", D + "Repositories/TFMSCardRepository.cs", "Repository — `LoadCardHeader` changed (merges SOA_Card fields); 2 new methods `LoadPermitsWithProtections`, `LoadInfoItemEquipSeverity`; 1 `using` added; comment on old `LoadWorkPermits`.", None, None),
    ("REPLACE (full file)", E + "Rendering/TelerikReportRenderer.cs", "Renderer — 1 new public method `PrependHeaderAtCardStart` (company logo + card title at the start of each card, identity line on the card's other pages; works with continuous page numbers). Existing methods unchanged.", None, "used by TLS and TOMS (same file as in TLS_Fix.md)"),
    ("REPLACE (full file)", E + "Groupers/ReportGroupers.cs", "Grouper — `TFMSGrouper.ComposeCard` rewritten (card + log + permits, rows coloured, spare blank rows via `CardRowSpacer` like FMS `GroupSpacer`, header as parameters, logo via `PrependHeaderAtCardStart`); 3 new methods `BuildHeaderParameters`, `HeaderDate`, `ClosedLabel`. Only the TOMS part is shown here.", is_tfms_hunk, "the same file also contains the TLS change (TLS_Fix.md); copy the file once"),
]

def section(items, other):
    t = [START, "", "## 3A. C# changes — every file, every change", "",
         "Generated from your original `Telerik-proj` files compared with `Issues_3\\Fixed\\Code\\`. "
         "**Copy the complete file from `Issues_3\\Fixed\\Code\\`; do not paste these diffs by hand.** "
         "They are here so you (and a reviewer) can see exactly what is different.", "",
         "| # | File | Action | Type of change |", "|---|---|---|---|"]
    for i, (kind, rel, what, _, shared) in enumerate(items, 1):
        short = what.split(" — ")[0]
        t.append(f"| {i} | `{rel.replace('/', chr(92))}` | {kind.split(' ')[0]} | {short}{' (shared with ' + other + ')' if shared else ''} |")
    t += ["", "Change types: **Model** = data class the template binds to; **SQL** = query text; **Interface** / **Repository** = data access; "
          "**Grouper** = which templates are printed and with what data; **New class** = new logic file; **Project file** = list of files to compile.", ""]
    for kind, rel, what, flt, shared in items:
        t.append(block(rel, kind, what, flt, shared))
    t.append(END)
    return "\n".join(t)

for md, items, other in [("TLS_Fix.md", TLS, "TOMS"), ("TOMS_Fix.md", TOMS, "TLS")]:
    p = os.path.join(FX, md)
    s = open(p, encoding="utf-8").read()
    s = re.sub(re.escape(START) + ".*?" + re.escape(END) + r"\n*", "", s, flags=re.S)
    anchor = "## 4. Tests run"
    assert anchor in s
    s = s.replace(anchor, section(items, other) + "\n\n" + anchor, 1)
    open(p, "w", encoding="utf-8").write(s)
    print("wrote section into", md)
