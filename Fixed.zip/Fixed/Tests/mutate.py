import shutil, subprocess, os, sys
# usage: PROJ=<Telerik-proj> python mutate.py   (run runtests.sh first so out/Tests.exe exists)
S = os.path.dirname(os.path.abspath(__file__))
FX = os.path.dirname(S)
PROJ = os.environ["PROJ"]
M = os.path.join(os.environ.get("TEMP", S), "trdx_mutation_copy")
muts = [
 ("Code/FMS_PDFReportService.Models/Jobs/Colors/DosColors.cs", 'TlsGrayOut = "#DCDCDC"', 'TlsGrayOut = "#FFFFFF"', "TLS gray removed"),
 ("Code/FMS_PDFReportService.Models/Jobs/Colors/TfmsRowRules.cs", "&& j.GroundOn != null && outstanding", "", "ground rule loses GroundOn/status check (old template bug)"),
 ("Code/FMS_PDFReportService.Models/Jobs/Colors/TfmsRowRules.cs", "j.ControlCard != cardId &&", "j.ControlCard == cardId &&", "control-card gray inverted"),
 ("Code/FMS_PDFReportService.Models/Jobs/Colors/TlsRowRules.cs", "FmsColorCalculator.IsBlank(d) ? DosColors.KeyDateGrayOut", "FmsColorCalculator.HasValue(d) ? DosColors.KeyDateGrayOut", "gray on real dates"),
 ("Code/FMS_PDFReportService.Models/Jobs/Colors/DosColors.cs", '(Constants.CC_PALE_ORANGE, "PaleOrange", "#FFD700")', '(Constants.CC_PALE_ORANGE, "PaleOrange", "#FFE0C0")', "Gold replaced by ColorMappingService value"),
 ("Code/FMS_PDFReportService.Models/Cards/TomsPermitRow.cs", "if (protections.Count == 0)", "if (protections.Count < 0)", "empty-permit row dropped"),
 ("Code/FMS_PDFReportService.Data/Queries/TFMSQueries.cs", "JC.StepPair = ? AND", "JC.StepPair = 3 AND", "StepPair=3 regression"),
 ("Code/FMS_PDFReportService.Engine/Groupers/ReportGroupers.cs", '{ "ClosedLabel", ClosedLabel(header.Closed) },', '', "TOMS param not sent"),
 ("Templates/TFMS/TFMSCard.trdx", "Fields.EquipFgKey", "Fields.EquipFGKey", "template binds non-existent field"),
 ("Templates/TLS/TLSCard.trdx", 'Left="4.05in" Top="0in" Value="= Fields.MoveText"', 'Left="4.15in" Top="0in" Value="= Fields.MoveText"', "grid gap"),
 ("Templates/TFMS/TOMSWorkPermit.trdx", 'Name="FeederNames"', 'Name="FeederName"', "permit title parameter renamed"),
 ("Code/FMS_PDFReportService.Engine/Groupers/ReportGroupers.cs", "jobs = CardRowSpacer.AddBlankRows(jobs, request.SpareLines);", "", "blank-row call removed (TOMS)"),
 ("Templates/TLS/TLSCard.trdx", 'Name="TLSCard"', 'Name="TLSCard" PageNumberingStyle="ResetNumberingAndCount"', "page numbering reset per card again"),
 ("Templates/TFMS/TFMSCard.trdx", "Transmission Feeder Card for ", "Feeder Card Report for ", "TOMS title text wrong"),
 ("Code/FMS_PDFReportService.Engine/Groupers/ReportGroupers.cs", "_renderer.PrependHeaderAtCardStart(", "_renderer.PrependHeader(", "TOMS back to old header method"),
 ("Templates/TLS/TLSCard.trdx", 'PrintOnFirstPage="False" ', "", "TLS identity line on first page again"),
 ("Templates/TLS/TLSCard.trdx", 'Name="txtReportTitle"', 'Name="txtTitleX"', "TLS title missing from report header"),
 # Issues_3: ground red on blank-padded Status; support-editable colour parameters
 ("Code/FMS_PDFReportService.Models/Jobs/Colors/TfmsRowRules.cs", "(j.Status ?? string.Empty).TrimEnd()", "(j.Status ?? string.Empty)", "padded Status no longer trimmed (34125M ground rows black)"),
 ("Code/FMS_PDFReportService.Models/Jobs/Colors/TfmsRowRules.cs", "if (ground) moveFg = DosColors.KeyGround;", "if (ground) moveFg = DosColors.KeyText;", "ground move text uses the normal-text colour"),
 ("Code/FMS_PDFReportService.Models/Jobs/Colors/DosColors.cs", 'return "DbColor" + c.Name;', 'return "DbColour" + c.Name;', "database colour key misspelt (no parameter)"),
 ("Templates/TFMS/TFMSCard.trdx", 'Text="G and Move text of a ground move that is still applied">\n      <Value>\n        <String>#FF0000', 'Text="G and Move text of a ground move that is still applied">\n      <Value>\n        <String>#000000', "ColorGround default changed to black"),
 ("Templates/TFMS/TFMSCard.trdx", "Parameters.ColorGround.Value", "Parameters.ColorText.Value", "G cell maps ground to the wrong parameter"),
 ("Templates/TLS/TLSCard.trdx", "<String>#DCDCDC</String>", "<String>#FFFFFF</String>", "TLS gray-out default changed to white"),
 ("Code/FMS_PDFReportService.Engine/Groupers/ReportGroupers.cs", '{ "ClosedLabel", ClosedLabel(header.Closed) },', '{ "ClosedLabel", ClosedLabel(header.Closed) }, { "ColorGround", "#000000" },', "grouper overwrites a colour parameter"),
]
gen_backup = None
caught = 0
for rel, old, new, label in muts:
    if os.path.exists(M): shutil.rmtree(M)
    shutil.copytree(FX, M)
    p = os.path.join(M, rel); s = open(p, encoding="utf-8").read()
    assert old in s, "pattern missing: " + label
    open(p, "w", encoding="utf-8").write(s.replace(old, new, 1))
    # build + test against the mutated copy (templates NOT regenerated so template mutations survive)
    b = subprocess.run([sys.executable, os.path.join(S, "build.py"), PROJ, os.path.join(S, "out_mut"), os.path.join(M, "Code")], capture_output=True, text=True, cwd=S)
    if b.returncode != 0:
        print(f"CAUGHT (compile)  {label}"); caught += 1; continue
    for f in ["Serilog.dll","Dapper.StrongName.dll"]:
        shutil.copy(os.path.join(S, "out", f), os.path.join(S, "out_mut"))
    shutil.copy(os.path.join(S, "out", "Tests.exe"), os.path.join(S, "out_mut"))
    r = subprocess.run([os.path.join(S, "out_mut", "Tests.exe"), os.path.join(M, "Templates"), os.path.join(S, "mut.json")], capture_output=True, text=True)
    last = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-200:]
    ok = r.returncode != 0
    caught += ok
    print(("CAUGHT            " if ok else "MISSED !!!        ") + label + "   -> " + last)
print(f"{caught}/{len(muts)} mutations caught")
