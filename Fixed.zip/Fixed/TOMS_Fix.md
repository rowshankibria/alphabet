# TOMS (TFMS) card — final logic (`toms-rpt` = replica of `toms-dos`)

**Benchmarks**
- `issues\v2\Issues_2\toms-dos.pdf` (180 pages). Pages **172-180 are card 372937**, the same card as `toms-rpt.pdf`, compared row by row.
- `issues\v2\Issues_3\34125M-dos.pdf` (card 371044 / 34125M) vs `34125M-rpt.pdf`: ground rows, compared by machine for every text colour and every cell fill.

**This folder (`issues\v2\Issues_3\Fixed\`) is the complete, final delivery** for TLS and TOMS. It replaces `issues\v2\Fixed\`.

| Folder | What |
|---|---|
| `Code\...` | Full replacement C# files, same relative paths as `Telerik-proj` (shared with TLS) |
| `Templates\TFMS\TFMSCard.trdx` | Card header + job grid in one report (FeederCard1 layout), **with support-editable colour parameters** |
| `Templates\TFMS\TOMSWorkPermit.trdx` | "Permits and Protections for …" |
| `Templates\TFMS\TFMSCardLog.trdx` | "TFMS Card Log for …" |
| `Tests\` | Template generator, build, 1412 checks, fault injection, visual emulator (section 4) |
| `Evidence\` | Benchmark pages vs simulated pages from the delivered templates |
| `Color_Parameters.md` | Guide for the support team: how to change a colour in the Telerik Report Designer |

---

## 0. What is new in this final version

| # | Change | Why |
|---|---|---|
| A | **Ground rows red again when Status is blank-padded.** `TfmsRowRules` compares `Status` without trailing blanks (`'   '` = `''`, `'NIS '` = `'NIS'`). | 34125M: the benchmark prints G + Move **red** on 3 ground moves still applied (6G 05/05 07:53, 4G 05/05 07:53, Grd-SwFdr 76). Ours printed them black. Ingres/OpenROAD ignore trailing blanks when comparing; the C# compared exactly. Confirm with the query in section 6, item 1. |
| B | **Colours are report parameters.** Support can change any card colour in the Telerik Report Designer, without a code change. | Support requirement, same approach as `FeederCard1.trdx`. With the default values the cards print exactly as before (pixel-identical in the emulator). |

---

## 1. What was wrong (and is fixed)

| # | Benchmark | Our report (before) | Cause |
|---|---|---|---|
| 1 | Landscape card box: **372937 · Auto · 99153 · Note**, Cut Out / Cut In, description `DUN-S38:(2S,3S) E179ST38:(7W,6W)` | Separate portrait page "TOMS Switching Card" with Objects / Prepared By tables; Status 0; Cut Out/In missing | `TFMSCardHeader.trdx`; the header query never read `SOA_Card` |
| 2 | **ID** column blank | Prints SOA_JobControl Seq | Template bound `Seq` |
| 3 | **Op** columns blank | Prints operator ids | Template |
| 4 | Not-applicable dates gray `#808080`, blank | Prints `12/31 23:59` | Ingres empty date not handled |
| 5 | Headings only in the Move cell, **bold**; substation names on a coloured band; "EN - DE - EN" red on light blue | Full-width rows, plain, no colour | Template; `MoveBGColor`/`MoveFGColor` not mapped |
| 6 | Type + Equipment **gray** when the card doesn't control the move | Black | Rule missing |
| 7 | "S" cell **yellow / turquoise / green** for equipment on an information item | Plain | Rule and its query missing |
| 8 | Hi-Pot rows with G = 3 **black** (p176); other G = 3 rows red (p13) | All rows with Grounds > 0 red | Old template: `Grounds > 0` only |
| 9 | **Permits and Protections**: 8 Work Permits + 1 Test Permit with protections | Page **empty** | Query used `StepPair = 3`; TOMS permits are StepPair **600** / **650** |
| 10 | "TFMS Card Log for 99153", landscape | Portrait, extra columns | Template |
| 11 | Card identity on every page | Missing | No page header |
| 12 | 34125M: 3 ground moves still applied → G + Move **red** | Black | `Status` compared exactly; Ingres pads blanks (fix A) |
| 13 | — | Colours could only be changed by a developer | Requirement (fix B) |

**Row order is correct:** the job query equals OpenROAD `Job_ASE.LoadTFMSJobs` (cac.dmt 104781), including the inner join on `Udb_Object` and `ORDER BY StepPair, StepLevel, Seq`. 34125M: all 11 BurlyWood bands and 36 gray cells match the benchmark, and all other text colours match.

## 2. The rules (with sources)

Main source: `openrd\TOMS_soa\soa.dmt`, `SOA_Main ON USEREVENT 'MoveColors'` (line 35926 ff.). Also `online\toms\tfmscard.js` `card_LoadJob`, `fms-online\database.js` `db_GetMappedColor`, `fms-online\fms.css`.

### 2.1 Row colours and text — `TfmsRowRules.ApplyRow`

"Outstanding" = Status is `''` or `'NIS'`, **compared without trailing blanks** (Ingres semantics).
The colour key column is the report parameter that support can edit (section 2.3).

| Cell | Rule | Colour key | Source |
|---|---|---|---|
| Heading row (JobClass = 0) | Only the Move cell: **bold**, text colour = `MoveFGColor`, background = `MoveBGColor`. All other cells empty and white. Leading spaces kept | `DbColor<code>` / `ColorText`, `ColorCellBg` | tfmscard.js `card_IsStepHeading`; soa.dmt 36117-36144 |
| Dates | `MM/dd HH:mm`; **empty date → gray `#808080`**, blank; NULL → white, blank | `ColorDateGrayOut` / `ColorCellBg` | soa.dmt 36079-36093; measured (128,128,128) |
| Op, ID | Always blank | — | benchmark; tfmscard.js |
| Type, Equipment | Gray `#808080` when `ControlCard ≠ this card` **and** MoveCategory = Normal (0) | `ColorEquipNoControl` / `ColorText` | soa.dmt 36095-36099 |
| G | `Grounds` when > 0, else blank. Red when the ground rule applies | `ColorGround` / `ColorText` | soa.dmt 36146-36153 |
| Move text | Black → green if switching item with shadow link → `MoveFGColor` if ≠ 0 → **red if** Grounds > 0 **and** GroundOn IS NOT NULL **and** outstanding (applied last, so it wins) | `ColorText` → `ColorShadowLink` → `DbColor<code>` → `ColorGround` | tfmscard.js 601; soa.dmt 36142-36153 |
| Move background | `MoveBGColor` if ≠ 0. Test Letter (JobClass 15000): Gold while issued, not complete and outstanding; otherwise white | `DbColor<code>` / `ColorTestLetter` / `ColorCellBg` | soa.dmt 36117, 36155-36165 |
| Origin ("S") text | `ActivityIdentifier`; `S` not printed on an archived card | — | tfmscard.js; FeederCard Fix 2 |
| Origin background | Only for an **active, not archived** card, MoveCategory Normal, outstanding: info item severity **1 → yellow, 2 → darkturquoise, 3 → mediumseagreen**; otherwise white | `ColorInfoSeverity1/2/3` / `ColorCellBg` | soa.dmt 36167-36190 + 35936-35962; fms.css |
| Response | `Response` | — | — |
| Spare blank rows | Empty, white | `ColorCellBg`, `ColorText` | `CardRowSpacer` |

Severity list = `ItemCategory_ASE.LoadEquip` (cac.dmt 102282-102322): `ORDER BY Equip, Severity`, first row per equipment (= most severe). Ported as `TfmsRowRules.FirstSeverityPerEquip`.

**Ground rule: three legacy sources agree.** OpenROAD full load (soa.dmt 36148), the web card (tfmscard.js 601) and this port all use `Grounds > 0 AND GroundOn IS NOT NULL AND Status IN ('', 'NIS')`. Which rows are red depends on database values that are not printed. In toms-dos.pdf many rows with G > 0, take-out complete and restore blank are **black** (p1, p174, p175), so `Grounds > 0` alone is wrong.

**Not ported, with reason:**
- Timestamp text colours (operating-order gray/red, soa.dmt 35990-36077): 180 + 3 benchmark pages contain **no coloured date text**.
- Critical-valve red equipment (soa.dmt 36100-36106): the valve list is only loaded for SDS (steam); for TOMS it is always empty.

### 2.2 Colour palette — `DosColors` (shared with TLS)

| OpenROAD code | Hex | Seen in benchmark as |
|---|---|---|
| CC_BLUE 8 | `#000080` Navy | step headings (DOS uses Navy, not the web's #0000FF) |
| CC_RED 6 / CC_GREEN 7 | `#FF0000` / `#008000` | ground moves, EN - DE - EN / move text |
| CC_LIGHT_GRAY 25 | `#808080` | Type/Equipment not controlled |
| CC_PALE_BROWN 32 | `#DEB887` BurlyWood | substation bands (Dunwoodie, Astoria …) |
| CC_PALE_ORANGE 33 | `#FFD700` Gold | Gownus Gas Turbine band |
| CC_PALE_BLUE 28 | `#87CEFA` LightSkyBlue | GOWN, ASTORIA ANNEX, EN-DE-EN bands |
| CC_PALE_RED 26 | `#FFB6C1` LightPink | East River 69 band |
| CC_PALE_PINK 31 | `#D8BFD8` Thistle | FIELD WORK band |
| severity 1 / 2 / 3 | `#FFFF00` / `#00CED1` / `#3CB371` | S cells |

Other codes use the web map (`database.js`); none of them occurs in the benchmarks.

> **Do not use `Engine\Services\ColorMappingService`** for these reports. Its palette contradicts the benchmark (code 33 = (255,224,192) instead of Gold, code 32 = (224,192,128) instead of BurlyWood).

### 2.3 Support-editable colours — `TFMSCard.trdx` parameters

How it works:
1. The rules choose a **colour key** for every coloured cell (`TfmsJob.TOIssuedBgKey`, `EquipFgKey`, `GFgKey`, `MoveFgKey`, `MoveBgKey`, `OriginBgKey` …). `TfmsRowRules.Resolve()` derives the hex (`TfmsJob.MoveFg` …) from the key through `DosColors.TomsPalette`, so key and hex can never disagree.
2. The template maps the key to the **report parameter with the same name**:
   `= IIf(Fields.GFgKey = "ColorText", Parameters.ColorText.Value, IIf(Fields.GFgKey = "ColorGround", Parameters.ColorGround.Value, Fields.GFg))`
3. The parameter **default value = the benchmark colour**. Support changes the value in the Telerik Report Designer.
4. A key with no parameter falls back to the hex sent by the application (`Fields.GFg`). A cell never goes blank or white.
5. The grouper never sends colour parameters, so it can't overwrite them (test-enforced). The renderer loads the `.trdx` on every print, so an edit applies to the next card printed.

41 parameters: 10 roles + 31 database colour codes.

| Parameter | Default | Colours |
|---|---|---|
| `ColorText` | #000000 | normal text |
| `ColorCellBg` | #FFFFFF | normal cell background, spare blank rows |
| `ColorDateGrayOut` | #808080 | Issued/Complete when the step is not used |
| `ColorEquipNoControl` | #808080 | Type/Equipment when this card does not control the move |
| `ColorGround` | #FF0000 | G + Move of a ground move still applied |
| `ColorShadowLink` | #008000 | switching item with a shadow link |
| `ColorTestLetter` | #FFD700 | outstanding test letter (Move background) |
| `ColorInfoSeverity1/2/3` | #FFFF00 / #00CED1 / #3CB371 | Origin (S) background |
| `DbColor<Name>` × 31 | `DosColors.Codes` | `SOA_Job.MoveFGColor` / `MoveBGColor`: headings, bands, EN - DE - EN |

`ColorGround` and `DbColorRed` are separate, so recolouring ground moves does not change the red EN - DE - EN heading (and vice versa).

**Safety colours** (`ColorGround`, `ColorDateGrayOut`, `ColorEquipNoControl`, `ColorInfoSeverity1-3`, `ColorTestLetter`) should be changed only with operations approval. A wrong value can hide a dangerous condition. Full list and steps: `Color_Parameters.md`.

### 2.4 Header — `CardTFMS.LoadCard` + `CardSOA.LoadCard` (cac.dmt 8950 / 8626)

| Box | Active card | Archived card |
|---|---|---|
| Card · Class · Feeders | `TFMS_Card.Card`, `SOA_Card.CardClassName`, `TFMS_Card.FeederNames` | `TFMS_ArchiveCard` |
| Cut Out / Cut In | `SOA_Card.CutOut` / `CutIn`, `MM/dd/yy HH:mm` | `TFMS_ArchiveCard` |
| Description | `TFMS_Card.Description` | same |
| Note | `SOA_Card.Note` | — (OpenROAD loads no note for archive) |
| Card Closed | only when Closed has a date (tfmscard.js) | |

`SOA_Card` is read in a **separate** query (as OpenROAD does), so a missing `SOA_Card` row blanks those boxes instead of losing the whole header. Card `Status` drives the severity rule.

### 2.5 Permits and Protections — `WorkPermit_ASE.LoadSOA_WP` (cac.dmt 247825)

- Work Permits: `SOA_JobControl.StepPair = 600`, then Test Permits: `StepPair = 650`; each `ORDER BY Seq`; `Status IN ('', 'NIS', 'tbl')`; `MoveCategory = 0`; inner join `Udb_Object` on Substation. Archive: `SOA_ArchiveJob`, `Status = ''`.
- Protections of each permit: `FMS_WorkPermitProtection` (archive `FMS_ArchiveWPProtection`), `PermitCardType = 0`, by Seq, through the `LoadProtectionMove` cascade. That cascade is already ported in `FMSCardRepository.LoadProtections`, which is **reused, not copied**.
- Printed as one group per permit: `Work Permit`/`Test Permit` · Issued · ID · Type · Equipment · Move · Complete. Then `Protections:` with system · Card · Issued · Complete · Station · ID · type · Equipment · Move · Issued · Complete, or "No protection moves for this permit". Title "Permits and Protections for *FeederNames*" on every page.
- C# flattens permits + protections into `TomsPermitRow` rows; the template groups on `PermitKey` (no nested SubReport data binding).
- No colours on this page.

### 2.6 Card log

Same query as before (it was right). Layout: "TFMS Card Log for *FeederNames*", Date `MM/dd/yy HH:mm` · Status · Log Entry, landscape, newest first. No colours.

### 2.7 Layout — `TFMSCard.trdx` (FeederCard1 format)

- Letter landscape, margins 0.15/0.15/0.5/0.5, width 10.7in; column header on every page; footer print time + "Page *n* of *N*".
- **Card start (first page of each card):** company logo, centered title **"Transmission Feeder Card for {FeederNames}"** (12pt bold), card box. The title is in the report header, so each card in a multi-card PDF starts with its own title.
- **Other pages of the card:** logo, then the identity line (Card · Class · Feeders, 9pt bold). This is the page header with `PrintOnFirstPage="False"`, which Telerik applies to the first page of *each* report (= each card).
- The logo is placed by the renderer method `PrependHeaderAtCardStart` (TLS/TOMS cards only), without the `PageNumber > 1` rule of the old `PrependHeader`. FMS / SLC / DSO and the TOMS log and permit sections keep the old `PrependHeader`.
- **Page numbers run continuously over the whole PDF** (all cards, log and permits). No `PageNumberingStyle` attribute.
- **Spare blank rows** (query string `LINE` → `ReportRequest.SpareLines`, default 2), same algorithm as FMS `GroupSpacer`. `CardRowSpacer.AddBlankRows` adds that many empty rows at the end of every step-heading group (De-Energize, Disconnects, Work Permits, Test, EN - DE - EN …), except after a last group with no rows. Clamped 0–10. Runs after the colour rules.
- Grid **identical to FeederCard1** and toms-dos.pdf: Op 0.35 · Issued 0.75 · Complete 0.75 · ID 0.35 · Type 0.85 · Equipment 0.80 · G 0.25 · Move 3.45 · origin 0.25 · Response 1.10 · Op 0.35 · Issued 0.72 · Complete 0.72. Row 0.27in, Arial 8.
- Two Move boxes at the same place (normal / bold), switched by `Visible`.
- Every cell `CanGrow="True"`; every row cell `Anchoring="Top, Bottom"`, so a wrapped value grows the whole row. Enforced by tests.
- 12 colour bindings (4 dates, Type, Equipment, G, Move text + background, Origin, heading Move text + background), all key → parameter with application fallback. The longest chain (Move text) has 34 levels.
- The templates are generated by `Tests\gen_trdx.py`. **Edit the generator, not the XML**, then run `runtests.sh` (it regenerates the templates and fails if a default no longer matches `DosColors`). Support edits a parameter **value** in the deployed `.trdx`; that does not need the generator.

## 3. Steps

> **Replace whole files, do not copy methods.** Every file in `Code\` is the complete file: your original plus the change. Copy it over the file with the same path in `Telerik-proj` (or add it, if new). This is only safe if your `Telerik-proj` file is still the same as the copy in `issues\v2\Issues_2\Telerik-proj` (snapshot of 2026-09-30). Otherwise merge that file by hand.

| # | File | Change |
|---|---|---|
| 1 | `Models\Jobs\TfmsJob.cs` | + 31 properties: display texts/colours, `IsBlankRow`, 9 colour keys. Existing ones unchanged (TFMS Excel unaffected) |
| 2 | `Models\Cards\TfmsCardModels.cs` | `TfmsCardHeader`: + `CardClassName`, `CutOut`, `CutIn`, `Note` |
| 3 | **New** `Models\Cards\TomsPermitRow.cs` | Flattened permit/protection row + `Build()` |
| 4 | **New** `Models\Jobs\Colors\DosColors.cs` | Palette, colour keys, TOMS/TLS palettes, `KeyFromCode` (shared with TLS) |
| 5 | **New** `Models\Jobs\Colors\TfmsRowRules.cs` | Rules of 2.1 (keys + `Resolve`), `InfoItemEquipSeverity`, `FirstSeverityPerEquip`, Status without trailing blanks |
| 6 | **New** `Models\Jobs\Colors\CardRowSpacer.cs` | Spare blank rows for TLS and TOMS (shared) |
| 7 | `Models\FMS_PDFReportService.Models.csproj` | + `<Compile Include>` for the new files (shared) |
| 8 | `Data\Queries\TFMSQueries.cs` | + `LoadSoaCard`, `LoadSoaCardArchive`, `LoadInfoItemEquipSeverity`, `LoadPermits`, `LoadPermitsArchive`. Old `LoadWorkPermits` kept, marked obsolete |
| 9 | `Data\Repositories\ITFMSCardRepository.cs` | + `LoadPermitsWithProtections`, `LoadInfoItemEquipSeverity` |
| 10 | `Data\Repositories\TFMSCardRepository.cs` | Header merges `SOA_Card`; new methods above |
| 11 | `Engine\Rendering\TelerikReportRenderer.cs` | + `PrependHeaderAtCardStart` (shared). Existing `PrependHeader` unchanged |
| 12 | `Engine\Groupers\ReportGroupers.cs` | `TFMSGrouper.ComposeCard` (below). Same file has the TLS change; copy once |
| 13 | `Engine\Templates\TFMS\` | Replace `TFMSCard.trdx`, `TOMSWorkPermit.trdx`, `TFMSCardLog.trdx` |

`TFMSCardHeader.trdx` is no longer used (left as is). No DI / constructor change.

Core of the grouper (copy the delivered file, not this snippet):

```csharp
var archived = request.ArchiveFlag == 1;
var header = _repo.LoadCardHeader(cardId, request.ArchiveFlag);
var jobs = _repo.LoadJobs(cardId, request.ArchiveFlag).ToList();
var severity = (!archived && header != null && header.Status == Constants.Card_Active)
    ? _repo.LoadInfoItemEquipSeverity(cardId) : new Dictionary<int, int?>();
TfmsRowRules.Apply(jobs, cardId, archived, severity);          // sets colour keys + hex
jobs = CardRowSpacer.AddBlankRows(jobs, request.SpareLines);   // like FMS GroupSpacer
sources.Add(... "TFMS/TFMSCard.trdx", jobs, BuildHeaderParameters(header));   // no colour parameters sent
if (request.ReportType == 1)
{
    ... "TFMS/TFMSCardLog.trdx", log, { FeederNames }
    ... "TFMS/TOMSWorkPermit.trdx", TomsPermitRow.Build(_repo.LoadPermitsWithProtections(...)), { FeederNames }
}
```

Deploy the C# and the three templates **together**: the templates bind the new `...Key` fields.

<!-- CSHARP-CHANGES START -->

## 3A. C# changes — every file, every change

Generated from your original `Telerik-proj` files compared with `Issues_3\Fixed\Code\`. **Copy the complete file from `Issues_3\Fixed\Code\`; do not paste these diffs by hand.** They are here so you (and a reviewer) can see exactly what is different.

| # | File | Action | Type of change |
|---|---|---|---|
| 1 | `FMS_PDFReportService.Models\Jobs\TfmsJob.cs` | REPLACE | Model |
| 2 | `FMS_PDFReportService.Models\Cards\TfmsCardModels.cs` | REPLACE | Model |
| 3 | `FMS_PDFReportService.Models\Cards\TomsPermitRow.cs` | ADD | New class |
| 4 | `FMS_PDFReportService.Models\Jobs\Colors\TfmsRowRules.cs` | ADD | New classes |
| 5 | `FMS_PDFReportService.Models\Jobs\Colors\DosColors.cs` | ADD | New static class (shared with TLS) |
| 6 | `FMS_PDFReportService.Models\Jobs\Colors\CardRowSpacer.cs` | ADD | New static class (shared with TLS) |
| 7 | `FMS_PDFReportService.Models\FMS_PDFReportService.Models.csproj` | REPLACE | Project file (shared with TLS) |
| 8 | `FMS_PDFReportService.Data\Queries\TFMSQueries.cs` | REPLACE | SQL |
| 9 | `FMS_PDFReportService.Data\Repositories\ITFMSCardRepository.cs` | REPLACE | Interface |
| 10 | `FMS_PDFReportService.Data\Repositories\TFMSCardRepository.cs` | REPLACE | Repository |
| 11 | `FMS_PDFReportService.Engine\Rendering\TelerikReportRenderer.cs` | REPLACE | Renderer (shared with TLS) |
| 12 | `FMS_PDFReportService.Engine\Groupers\ReportGroupers.cs` | REPLACE | Grouper (shared with TLS) |

Change types: **Model** = data class the template binds to; **SQL** = query text; **Interface** / **Repository** = data access; **Grouper** = which templates are printed and with what data; **New class** = new logic file; **Project file** = list of files to compile.

#### `FMS_PDFReportService.Models\Jobs\TfmsJob.cs`

**Action:** REPLACE (full file)  
**Type of change:** Model — 31 new properties added at the end of the class: display text and colours for the grid, `IsBlankRow` for spare rows, and 9 colour keys (`...BgKey` / `...FgKey`, = TFMSCard.trdx colour parameter names). No existing property changed or removed.  
**Lines:** +35 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -42,6 +42,41 @@
         public int MoveBGColor { get; set; }
         public string DeskName { get; set; }
         public int SwitchingItem { get; set; }
+
+        // Display values for TFMSCard.trdx. Not database columns; set only by TfmsRowRules.Apply.
+        public bool IsHeading { get; set; }
+        public bool IsBlankRow { get; set; }   // spare blank row added by CardRowSpacer
+        public string TOIssuedText { get; set; }
+        public string TOCompleteText { get; set; }
+        public string RSIssuedText { get; set; }
+        public string RSCompleteText { get; set; }
+        public string TOIssuedBg { get; set; }
+        public string TOCompleteBg { get; set; }
+        public string RSIssuedBg { get; set; }
+        public string RSCompleteBg { get; set; }
+        public string TypeText { get; set; }
+        public string EquipText { get; set; }
+        public string EquipFg { get; set; }
+        public string GText { get; set; }
+        public string GFg { get; set; }
+        public string MoveText { get; set; }
+        public string MoveFg { get; set; }
+        public string MoveBg { get; set; }
+        public bool MoveBold { get; set; }
+        public string OriginText { get; set; }
+        public string OriginBg { get; set; }
+        public string ResponseText { get; set; }
+
+        // Colour keys (= TFMSCard.trdx parameter names) for the colours above; see DosColors.
+        public string TOIssuedBgKey { get; set; }
+        public string TOCompleteBgKey { get; set; }
+        public string RSIssuedBgKey { get; set; }
+        public string RSCompleteBgKey { get; set; }
+        public string EquipFgKey { get; set; }
+        public string GFgKey { get; set; }
+        public string MoveFgKey { get; set; }
+        public string MoveBgKey { get; set; }
+        public string OriginBgKey { get; set; }
     }
 }
 
```

#### `FMS_PDFReportService.Models\Cards\TfmsCardModels.cs`

**Action:** REPLACE (full file)  
**Type of change:** Model — `TfmsCardHeader`: 4 new properties (`CardClassName`, `CutOut`, `CutIn`, `Note`).  
**Lines:** +7 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -22,6 +22,13 @@
         public int Status { get; set; }
         public DateTime? Activated { get; set; }
         public DateTime? Closed { get; set; }
+
+        // From SOA_Card (active) / TFMS_ArchiveCard (archive), CardSOA.LoadCard in cac.dmt.
+        public string CardClassName { get; set; }
+        public DateTime? CutOut { get; set; }
+        public DateTime? CutIn { get; set; }
+        public string Note { get; set; }
+
         public List<TfmsChecklist> Checklists { get; set; } = new List<TfmsChecklist>();
         public List<TfmsCardPrepBy> PrepBy { get; set; } = new List<TfmsCardPrepBy>();
         public List<TfmsCardObject> Objects { get; set; } = new List<TfmsCardObject>();
```

#### `FMS_PDFReportService.Models\Cards\TomsPermitRow.cs`

**Action:** ADD (new file)  
**Type of change:** New class — one printed line of Permits and Protections + `Build()` that flattens permits and their protections.  
**Size:** 100 lines (complete file below)

```csharp
using System;
using System.Collections.Generic;
using FMS_PDFReportService.Models.Jobs.Colors;

namespace FMS_PDFReportService.Models.Cards
{
    // One printed line of "Permits and Protections for ..." (TOMSWorkPermit.trdx).
    // Every row carries its permit's values; TOMSWorkPermit.trdx groups on PermitKey and prints the permit
    // once in the group header, then one detail line per protection move.
    // A permit without protection moves gets exactly one row with IsEmpty = true, which prints
    // "No protection moves for this permit".
    public class TomsPermitRow
    {
        public int PermitKey { get; set; }          // 1, 2, 3 ... in print order
        public int PermitJob { get; set; }
        public string PermitLabel { get; set; }     // "Work Permit" / "Test Permit"
        public string PermitIssued { get; set; }
        public string PermitID { get; set; }
        public string PermitType { get; set; }
        public string PermitEquipment { get; set; }
        public string PermitMove { get; set; }
        public string PermitComplete { get; set; }

        public bool IsEmpty { get; set; }

        // Protection move, display-ready (same shape and source as FMSProtection.trdx / PermitProtection).
        public string CardTypeName { get; set; }
        public string Card { get; set; }
        public string TOIssued { get; set; }
        public string TOComplete { get; set; }
        public string Subsordesk { get; set; }
        public string PrintID { get; set; }
        public string EquipClassName { get; set; }
        public string EquipName { get; set; }
        public string TOMove { get; set; }
        public string RSIssued { get; set; }
        public string RSComplete { get; set; }

        public const string WorkPermitLabel = "Work Permit";
        public const string TestPermitLabel = "Test Permit";

        // permits: in print order (Work Permits by Seq, then Test Permits by Seq), each with its protections.
        public static List<TomsPermitRow> Build(IEnumerable<WorkPermit> permits)
        {
            var rows = new List<TomsPermitRow>();
            if (permits == null) return rows;

            int key = 0;
            foreach (var p in permits)
            {
                key++;
                var protections = p.Protections ?? new List<PermitProtection>();
                if (protections.Count == 0)
                {
                    var empty = Permit(p, key);
                    empty.IsEmpty = true;
                    rows.Add(empty);
                    continue;
                }
                foreach (var prot in protections)
                {
                    var r = Permit(p, key);
                    r.IsEmpty = false;
                    r.CardTypeName = prot.CardTypeName;
                    r.Card = prot.Card;
                    r.TOIssued = prot.TOIssued;
                    r.TOComplete = prot.TOComplete;
                    r.Subsordesk = prot.Subsordesk;
                    r.PrintID = prot.PrintID;
                    r.EquipClassName = prot.EquipClassName;
                    r.EquipName = prot.EquipName;
                    r.TOMove = prot.TOMove;
                    r.RSIssued = prot.RSIssued;
                    r.RSComplete = prot.RSComplete;
                    rows.Add(r);
                }
            }
            return rows;
        }

        private static TomsPermitRow Permit(WorkPermit p, int key)
        {
            return new TomsPermitRow
            {
                PermitKey = key,
                PermitJob = p.Job,
                PermitLabel = p.StepPair == Constants.StepHeading_TestPermit ? TestPermitLabel : WorkPermitLabel,
                PermitIssued = TfmsRowRules.DateText(p.TOIssued),
                PermitID = p.PrintID ?? string.Empty,
                PermitType = p.EquipClassName ?? string.Empty,
                PermitEquipment = p.EquipName ?? string.Empty,
                PermitMove = p.TOMove ?? string.Empty,
                PermitComplete = TfmsRowRules.DateText(p.RSComplete),
                CardTypeName = string.Empty, Card = string.Empty, TOIssued = string.Empty, TOComplete = string.Empty,
                Subsordesk = string.Empty, PrintID = string.Empty, EquipClassName = string.Empty, EquipName = string.Empty,
                TOMove = string.Empty, RSIssued = string.Empty, RSComplete = string.Empty
            };
        }
    }
}
```

#### `FMS_PDFReportService.Models\Jobs\Colors\TfmsRowRules.cs`

**Action:** ADD (new file)  
**Type of change:** New classes — `InfoItemEquipSeverity` (query row) and `TfmsRowRules` (row rules: dates, gray equipment, G, move colours, bands, S severity; Status compared without trailing blanks). Rules set colour keys; `Resolve()` derives every hex from the key.  
**Size:** 163 lines (complete file below)

```csharp
using System;
using System.Collections.Generic;
using System.Globalization;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // One row of ItemCategory_ASE.LoadEquip (cac.dmt): equipment on the card that is linked to an
    // active information item, with the item's severity.
    public class InfoItemEquipSeverity
    {
        public int Equip { get; set; }
        public int? Severity { get; set; }
    }

    // Display values and colours for one TOMS card row (TFMSCard.trdx).
    // Port of soa.dmt SOA_Main  ON USEREVENT 'MoveColors'  (TFMS branch), limited to what the DOS
    // benchmark (toms-dos.pdf) draws. Timestamp text colours (operating-order gray/red) are NOT drawn:
    // toms-dos.pdf has no coloured date text in 180 pages.
    public static class TfmsRowRules
    {
        // ItemCategory_ASE.LoadEquip keeps the FIRST row per equipment of
        // "ORDER BY Equip, Severity"; SOA_Main then uses the first match. Rows must arrive in that order.
        public static Dictionary<int, int?> FirstSeverityPerEquip(IEnumerable<InfoItemEquipSeverity> rows)
        {
            var map = new Dictionary<int, int?>();
            if (rows == null) return map;
            foreach (var r in rows)
                if (!map.ContainsKey(r.Equip))
                    map.Add(r.Equip, r.Severity);
            return map;
        }

        // cardId    : the card being printed (SOA_Main Card.Card)
        // archived  : request.ArchiveFlag == 1
        // equipSeverity: from FirstSeverityPerEquip; must be empty unless the card is active and not archived
        //               (SOA_Main only loads it when ArchiveCard = FALSE AND Card.Status = Card$Active).
        public static void Apply(IEnumerable<TfmsJob> jobs, int cardId, bool archived, IDictionary<int, int?> equipSeverity)
        {
            if (jobs == null) return;
            foreach (var j in jobs)
                ApplyRow(j, cardId, archived, equipSeverity);
        }

        public static void ApplyRow(TfmsJob j, int cardId, bool archived, IDictionary<int, int?> equipSeverity)
        {
            // Ingres/OpenROAD string comparison ignores trailing blanks ('' = '   '), so a blank-padded
            // Status must still count as ''. Without this, every ground / info-item / test-letter rule is off.
            string status = (j.Status ?? string.Empty).TrimEnd();
            bool outstanding = status == string.Empty || status == Constants.JobStatus_NIS;   // Status = '' OR 'NIS'

            j.MoveText = j.TOMove ?? string.Empty;   // leading spaces kept: the DOS card indents headings with them

            // Every colour below is a key (= TFMSCard.trdx parameter name); Resolve() turns keys into hex.
            // ---- Move text colour -------------------------------------------------------------
            string moveFg = DosColors.KeyText;
            // tfmscard.js: switching item with a shadow link is green (web rule; not in SOA_Main).
            if (j.MoveCategory == Constants.MoveCategory_SwitchingItem && j.ShadowLink != 0)
                moveFg = DosColors.KeyShadowLink;
            // "IF J[i].MoveFgColor <> 0 THEN FIELD(J[i].TOMove).FgColor = J[i].MoveFgColor"
            if (j.MoveFGColor != 0)
                moveFg = DosColors.KeyFromCode(j.MoveFGColor) ?? moveFg;
            // "Look for moves that set equipment ground" (applied after MoveFgColor, so it wins)
            bool ground = j.Grounds.HasValue && j.Grounds.Value > 0 && j.GroundOn != null && outstanding;
            if (ground) moveFg = DosColors.KeyGround;
            j.MoveFgKey = moveFg;

            // ---- Move background ---------------------------------------------------------------
            string moveBg = j.MoveBGColor != 0 ? (DosColors.KeyFromCode(j.MoveBGColor) ?? DosColors.KeyCellBg) : DosColors.KeyCellBg;
            // "Look for outstanding Test Letter moves": issued, not complete -> CC_PALE_ORANGE,
            // otherwise CC_PALE_YELLOW = the card's normal background (white on the DOS card).
            if (j.JobClass == Constants.JobClass_TestLetter)
                moveBg = (j.TOIssued != null && j.TOComplete == null && outstanding)
                    ? DosColors.KeyTestLetter
                    : DosColors.KeyCellBg;
            j.MoveBgKey = moveBg;

            if (j.JobClass == 0)
            {
                // Step / substation / FIELD WORK heading (tfmscard.js card_IsStepHeading).
                // DOS: bold, coloured only in the Move cell, every other cell empty and white.
                j.IsHeading = true;
                j.MoveBold = true;
                j.TOIssuedText = j.TOCompleteText = j.RSIssuedText = j.RSCompleteText = string.Empty;
                j.TOIssuedBgKey = j.TOCompleteBgKey = j.RSIssuedBgKey = j.RSCompleteBgKey = DosColors.KeyCellBg;
                j.TypeText = j.EquipText = j.GText = j.OriginText = j.ResponseText = string.Empty;
                j.EquipFgKey = j.GFgKey = DosColors.KeyText;
                j.OriginBgKey = DosColors.KeyCellBg;
                Resolve(j);
                return;
            }

            j.IsHeading = false;
            j.MoveBold = false;

            // ---- Timestamps: "Grey issue/complete times as appropriate" (empty date only) ------
            j.TOIssuedText = DateText(j.TOIssued);
            j.TOCompleteText = DateText(j.TOComplete);
            j.RSIssuedText = DateText(j.RSIssued);
            j.RSCompleteText = DateText(j.RSComplete);
            j.TOIssuedBgKey = GrayIfBlank(j.TOIssued);
            j.TOCompleteBgKey = GrayIfBlank(j.TOComplete);
            j.RSIssuedBgKey = GrayIfBlank(j.RSIssued);
            j.RSCompleteBgKey = GrayIfBlank(j.RSComplete);

            // ---- Type / Equipment: "If card does not have control of the move, grey out the equipment"
            j.TypeText = j.EquipClassName ?? string.Empty;
            j.EquipText = j.EquipName ?? string.Empty;
            j.EquipFgKey = (j.ControlCard != cardId && j.MoveCategory == Constants.MoveCategory_Normal)
                ? DosColors.KeyEquipNoControl
                : DosColors.KeyText;

            // ---- G column ---------------------------------------------------------------------
            j.GText = j.Grounds.HasValue && j.Grounds.Value > 0
                ? j.Grounds.Value.ToString(CultureInfo.InvariantCulture)
                : string.Empty;
            j.GFgKey = ground ? DosColors.KeyGround : DosColors.KeyText;

            // ---- Origin cell (ActivityIdentifier) -----------------------------------------------
            // Text: S is not printed on a closed (archived) card (tfmscard.js; same rule as FeederCard).
            string act = j.ActivityIdentifier ?? string.Empty;
            j.OriginText = (archived && act.Trim() == "S") ? string.Empty : act;
            // Colour: "Look for equipment moves associated to an info item"
            j.OriginBgKey = DosColors.KeyCellBg;
            int? sev;
            if (!archived && equipSeverity != null && j.MoveCategory == Constants.MoveCategory_Normal && outstanding
                && equipSeverity.TryGetValue(j.Equip, out sev) && sev.HasValue)
            {
                if (sev.Value == 1) j.OriginBgKey = DosColors.KeyInfoSeverity1;
                else if (sev.Value == 2) j.OriginBgKey = DosColors.KeyInfoSeverity2;
                else if (sev.Value == 3) j.OriginBgKey = DosColors.KeyInfoSeverity3;
            }

            j.ResponseText = j.Response ?? string.Empty;
            Resolve(j);
        }

        // Hex sent with each key = the TFMSCard.trdx parameter default; used by the template only when
        // the template has no parameter for that key.
        public static void Resolve(TfmsJob j)
        {
            j.TOIssuedBg = DosColors.Toms(j.TOIssuedBgKey);
            j.TOCompleteBg = DosColors.Toms(j.TOCompleteBgKey);
            j.RSIssuedBg = DosColors.Toms(j.RSIssuedBgKey);
            j.RSCompleteBg = DosColors.Toms(j.RSCompleteBgKey);
            j.EquipFg = DosColors.Toms(j.EquipFgKey);
            j.GFg = DosColors.Toms(j.GFgKey);
            j.MoveFg = DosColors.Toms(j.MoveFgKey);
            j.MoveBg = DosColors.Toms(j.MoveBgKey);
            j.OriginBg = DosColors.Toms(j.OriginBgKey);
        }

        private static string GrayIfBlank(DateTime? d)
        {
            return FmsColorCalculator.IsBlank(d) ? DosColors.KeyDateGrayOut : DosColors.KeyCellBg;
        }

        public static string DateText(DateTime? d)
        {
            if (!FmsColorCalculator.HasValue(d)) return string.Empty;
            return d.Value.ToString("MM/dd HH:mm", CultureInfo.InvariantCulture);
        }
    }
}
```

#### `FMS_PDFReportService.Models\Jobs\Colors\DosColors.cs`

**Action:** ADD (new file)  
**Type of change:** New static class — colour palette as the DOS PDFs draw it, colour keys (= report parameter names), TOMS/TLS palettes (key → default hex) and `KeyFromCode`.  
**Shared:** same file as in TLS_Fix.md  
**Size:** 132 lines (complete file below)

```csharp
using System.Collections.Generic;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // Colours as the DOS (benchmark) PDFs draw them, for the TLS and TOMS card grids.
    // Codes are OpenROAD CC_* values (Constants.cs). The hex values come from fms-online database.js
    // db_GetMappedColor and fms.css, except CC_BLUE (DOS draws step headings Navy, not #0000ff).
    // "Seen" = measured in tls-dos.pdf / toms-dos.pdf. Do NOT use Engine ColorMappingService for these
    // reports: its palette does not match the benchmark (e.g. code 33 there is not Gold).
    //
    // Support-editable colours: each coloured cell gets a colour KEY (TfmsJob/TlsJob ...Key) plus the hex
    // below. The key is the name of a report parameter in TFMSCard.trdx / TLSCard.trdx whose default value
    // is the same hex, so support can change a colour in the Telerik Report Designer without a code change.
    // A key with no parameter in the template falls back to the hex sent by the application.
    public static class DosColors
    {
        public const string White = "#FFFFFF";
        public const string Black = "#000000";
        public const string Navy = "#000080";           // seen: TLS + TOMS step headings
        public const string Red = "#FF0000";            // seen: TOMS ground moves, G column
        public const string Green = "#008000";          // seen: TOMS move text
        public const string Gray = "#808080";           // seen: TOMS Type/Equipment text (CC_LIGHT_GRAY)

        // Ingres empty date ('' = step not used). Both are CC_PALE_GRAY in OpenROAD,
        // but the two DOS reports draw it differently.
        public const string TlsGrayOut = "#DCDCDC";     // seen: tls-dos.pdf (220,220,220)
        public const string TomsGrayOut = "#808080";    // seen: toms-dos.pdf (128,128,128)

        // Origin ("S") cell, information-item severity (fms.css .Info_1/.Info_2/.Info_3)
        public const string InfoSeverity1 = "#FFFF00";  // seen: yellow
        public const string InfoSeverity2 = "#00CED1";  // seen: darkturquoise
        public const string InfoSeverity3 = "#3CB371";  // seen: mediumseagreen

        // ---- Colour keys = report parameter names (roles decided by the row rules) -----------------------
        public const string KeyText = "ColorText";                       // normal text (TOMS + TLS)
        public const string KeyCellBg = "ColorCellBg";                   // normal cell background (TOMS + TLS)
        public const string KeyDateGrayOut = "ColorDateGrayOut";         // empty Ingres date (TOMS + TLS, different defaults)
        public const string KeyEquipNoControl = "ColorEquipNoControl";   // TOMS Type/Equipment when card has no control
        public const string KeyGround = "ColorGround";                   // TOMS ground still applied: G + Move text
        public const string KeyShadowLink = "ColorShadowLink";           // TOMS switching item with shadow link
        public const string KeyTestLetter = "ColorTestLetter";           // TOMS outstanding test letter (Move background)
        public const string KeyInfoSeverity1 = "ColorInfoSeverity1";     // TOMS origin cell, info item severity 1
        public const string KeyInfoSeverity2 = "ColorInfoSeverity2";
        public const string KeyInfoSeverity3 = "ColorInfoSeverity3";
        public const string KeyStepHeading = "ColorStepHeading";         // TLS step heading text (CircuitClass -99)
        public const string KeyCoopPending = "ColorCoopPending";         // TLS Co-Op test pending (Move background)

        // OpenROAD colour codes stored in the database (SOA_Job.MoveFGColor / MoveBGColor): key "DbColor" + name.
        private static readonly (int Code, string Name, string Hex)[] Codes =
        {
            (Constants.CC_BLACK, "Black", Black),
            (Constants.CC_RED, "Red", Red),
            (Constants.CC_GREEN, "Green", Green),
            (Constants.CC_BLUE, "Blue", Navy),
            (Constants.CC_YELLOW, "Yellow", "#FFFF00"),
            (Constants.CC_CYAN, "Cyan", "#00FFFF"),
            (Constants.CC_PINK, "Pink", "#FFC0C0"),
            (Constants.CC_BROWN, "Brown", "#8B4513"),
            (Constants.CC_ORANGE, "Orange", "#FF8C00"),
            (Constants.CC_PURPLE, "Purple", "#800080"),
            (Constants.CC_GRAY, "Gray", "#696969"),
            (Constants.CC_LIGHT_RED, "LightRed", "#FF4500"),
            (Constants.CC_LIGHT_GREEN, "LightGreen", "#3CB371"),
            (Constants.CC_LIGHT_BLUE, "LightBlue", "#6495ED"),
            (Constants.CC_LIGHT_YELLOW, "LightYellow", "#F0E68C"),
            (Constants.CC_LIGHT_CYAN, "LightCyan", "#B0E0E6"),
            (Constants.CC_LIGHT_PINK, "LightPink", "#EE82EE"),
            (Constants.CC_LIGHT_BROWN, "LightBrown", "#D2B48C"),
            (Constants.CC_LIGHT_ORANGE, "LightOrange", "#FFA500"),
            (Constants.CC_LIGHT_PURPLE, "LightPurple", "#8A2BE2"),
            (Constants.CC_LIGHT_GRAY, "LightGray", Gray),
            (Constants.CC_PALE_RED, "PaleRed", "#FFB6C1"),      // seen: LightPink band
            (Constants.CC_PALE_GREEN, "PaleGreen", "#90EE90"),
            (Constants.CC_PALE_BLUE, "PaleBlue", "#87CEFA"),    // seen: LightSkyBlue band
            (Constants.PALE_YELLOW, "PaleYellow", "#FAFAD2"),
            (Constants.CC_PALE_CYAN, "PaleCyan", "#E0FFFF"),
            (Constants.CC_PALE_PINK, "PalePink", "#D8BFD8"),    // seen: Thistle band
            (Constants.CC_PALE_BROWN, "PaleBrown", "#DEB887"),  // seen: BurlyWood band
            (Constants.CC_PALE_ORANGE, "PaleOrange", "#FFD700"),// seen: Gold band
            (Constants.CC_PALE_PURPLE, "PalePurple", "#E6E6FA"),
            (Constants.CC_PALE_GRAY, "PaleGray", "#A9A9A9"),
        };

        // Maps an OpenROAD colour code to hex. Returns null for 0 (not set) and for codes
        // with no mapping, so the caller keeps its default.
        public static string FromCode(int code)
        {
            foreach (var c in Codes) if (c.Code == code) return c.Hex;
            return null;
        }

        // Colour key for an OpenROAD colour code; null when FromCode is null.
        public static string KeyFromCode(int code)
        {
            foreach (var c in Codes) if (c.Code == code) return "DbColor" + c.Name;
            return null;
        }

        // Key -> default hex, per report. These are the report parameters' default values.
        public static readonly IReadOnlyDictionary<string, string> TomsPalette = BuildToms();
        public static readonly IReadOnlyDictionary<string, string> TlsPalette = new Dictionary<string, string>
        {
            { KeyText, Black },
            { KeyCellBg, White },
            { KeyDateGrayOut, TlsGrayOut },
            { KeyStepHeading, Navy },
            { KeyCoopPending, "#FFB6C1" },   // CC_PALE_RED
        };

        private static Dictionary<string, string> BuildToms()
        {
            var p = new Dictionary<string, string>
            {
                { KeyText, Black },
                { KeyCellBg, White },
                { KeyDateGrayOut, TomsGrayOut },
                { KeyEquipNoControl, Gray },
                { KeyGround, Red },
                { KeyShadowLink, Green },
                { KeyTestLetter, "#FFD700" },   // CC_PALE_ORANGE
                { KeyInfoSeverity1, InfoSeverity1 },
                { KeyInfoSeverity2, InfoSeverity2 },
                { KeyInfoSeverity3, InfoSeverity3 },
            };
            foreach (var c in Codes) p.Add("DbColor" + c.Name, c.Hex);
            return p;
        }

        public static string Toms(string key) { return TomsPalette[key]; }
        public static string Tls(string key) { return TlsPalette[key]; }
    }
}
```

#### `FMS_PDFReportService.Models\Jobs\Colors\CardRowSpacer.cs`

**Action:** ADD (new file)  
**Type of change:** New static class — spare blank rows (query string LINE / `request.SpareLines`) for TLS and TOMS, same algorithm as FMS `GroupSpacer`; FMS file not touched.  
**Shared:** also used by TLS (same file as in TLS_Fix.md)  
**Size:** 110 lines (complete file below)

```csharp
using System;
using System.Collections.Generic;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // Spare blank rows for the TLS and TOMS cards (query string LINE -> ReportRequest.SpareLines),
    // same algorithm as GroupSpacer (FMS card):
    //   - a group starts at a step heading row;
    //   - LINE blank rows (clamped 0..GroupSpacer.MaxLines) are added at the end of every group,
    //     including a group that has only its heading,
    //   - EXCEPT the last group when it has no data rows;
    //   - every other row (notes, substation headings, moves) is a data row; rows above the first heading form a group.
    // Must run AFTER TlsRowRules / TfmsRowRules: blank rows are created already "coloured" (empty and white).
    public static class CardRowSpacer
    {
        // TLS step heading = the navy rows (Alarms, Switching Operations, ...): JobClass 0 AND CircuitClass -99
        // (TLSJob_ASE.SetMoveColors). Other JobClass 0 rows are notes = data rows.
        public static bool IsTlsStepHeading(TlsJob j)
        {
            return j.JobClass == 0 && j.CircuitClass == -99;
        }

        // TOMS step heading = De-Energize, Disconnects, Work Permits, Test, EN - DE - EN ...:
        // JobClass 0 AND (blue text like FMS, or MoveCategory StepHeading / EN-DE-EN).
        // Substation headings (coloured bands) and FIELD WORK are sub-headings inside a group = data rows.
        public static bool IsTfmsStepHeading(TfmsJob j)
        {
            return j.JobClass == 0 &&
                   (j.MoveFGColor == Constants.CC_BLUE ||
                    j.MoveCategory == Constants.MoveCategory_StepHeading ||
                    j.MoveCategory == Constants.MoveCategory_EnDeEn);
        }

        public static List<TlsJob> AddBlankRows(IEnumerable<TlsJob> jobs, int lines)
        {
            return AddBlankRows(jobs, lines, IsTlsStepHeading, BlankTls);
        }

        public static List<TfmsJob> AddBlankRows(IEnumerable<TfmsJob> jobs, int lines)
        {
            return AddBlankRows(jobs, lines, IsTfmsStepHeading, BlankTfms);
        }

        public static List<T> AddBlankRows<T>(IEnumerable<T> rows, int lines, Func<T, bool> isStepHeading, Func<T> makeBlank)
        {
            if (lines < 0) lines = 0;
            if (lines > GroupSpacer.MaxLines) lines = GroupSpacer.MaxLines;

            var result = new List<T>();
            if (rows == null) return result;
            bool lastGroupHasData = false;

            foreach (var r in rows)
            {
                if (isStepHeading(r))
                {
                    // A new heading closes the previous group (if there is one)
                    if (result.Count > 0) AddBlanks(result, lines, makeBlank);
                    lastGroupHasData = false;
                }
                else
                {
                    lastGroupHasData = true;
                }
                result.Add(r);
            }

            // Close the last group only if it has at least one data row
            if (lastGroupHasData) AddBlanks(result, lines, makeBlank);
            return result;
        }

        private static void AddBlanks<T>(List<T> list, int lines, Func<T> makeBlank)
        {
            for (int i = 0; i < lines; i++)
                list.Add(makeBlank());
        }

        // An empty grid row: all cells blank and white, normal (not bold) Move cell.
        public static TlsJob BlankTls()
        {
            string w = DosColors.KeyCellBg;
            var j = new TlsJob
            {
                IsBlankRow = true, IsHeading = false,
                TOIssuedText = "", TOCompleteText = "", RSIssuedText = "", RSCompleteText = "",
                TOIssuedBgKey = w, TOCompleteBgKey = w, RSIssuedBgKey = w, RSCompleteBgKey = w,
                StationText = "", CircuitText = "", MoveText = "", MoveFgKey = DosColors.KeyText, MoveBgKey = w,
                ResultsText = "", StatusText = ""
            };
            TlsRowRules.Resolve(j);
            return j;
        }

        public static TfmsJob BlankTfms()
        {
            string w = DosColors.KeyCellBg, t = DosColors.KeyText;
            var j = new TfmsJob
            {
                IsBlankRow = true, IsHeading = false, MoveBold = false,
                TOIssuedText = "", TOCompleteText = "", RSIssuedText = "", RSCompleteText = "",
                TOIssuedBgKey = w, TOCompleteBgKey = w, RSIssuedBgKey = w, RSCompleteBgKey = w,
                TypeText = "", EquipText = "", EquipFgKey = t, GText = "", GFgKey = t,
                MoveText = "", MoveFgKey = t, MoveBgKey = w, OriginText = "", OriginBgKey = w, ResponseText = ""
            };
            TfmsRowRules.Resolve(j);
            return j;
        }
    }
}
```

#### `FMS_PDFReportService.Models\FMS_PDFReportService.Models.csproj`

**Action:** REPLACE (full file)  
**Type of change:** Project file — 5 `<Compile Include>` lines for the new .cs files.  
**Shared:** same file as in TLS_Fix.md  
**Lines:** +5 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -85,6 +85,10 @@
     <Compile Include="Jobs\Colors\GroupSpacer.cs" />
     <Compile Include="Jobs\Colors\PhaseCheckEquipRow.cs" />
     <Compile Include="Jobs\Colors\PhaseCheckRules.cs" />
+    <Compile Include="Jobs\Colors\DosColors.cs" />
+    <Compile Include="Jobs\Colors\TlsRowRules.cs" />
+    <Compile Include="Jobs\Colors\TfmsRowRules.cs" />
+    <Compile Include="Jobs\Colors\CardRowSpacer.cs" />
     <Compile Include="Jobs\LocationTags\LocationTagFeederCard.cs" />
     <Compile Include="Jobs\PhaseChecks\PhaseCheckFeederCard.cs" />
     <Compile Include="Jobs\Protection\ProtectionLinkFeederCard.cs" />
@@ -101,6 +105,7 @@
     <Compile Include="Cards\TfmsCardModels.cs" />
     <Compile Include="Cards\SlcCardModels.cs" />
     <Compile Include="Cards\TlsCardModels.cs" />
+    <Compile Include="Cards\TomsPermitRow.cs" />
     <Compile Include="Cards\DsoCardModels.cs" />
     <Compile Include="Cards\SteamCardModels.cs" />
     <Compile Include="Jobs\FmsJob.cs" />
```

#### `FMS_PDFReportService.Data\Queries\TFMSQueries.cs`

**Action:** REPLACE (full file)  
**Type of change:** SQL — 5 new queries: `LoadSoaCard`, `LoadSoaCardArchive`, `LoadInfoItemEquipSeverity`, `LoadPermits`, `LoadPermitsArchive`; comment marking the old `LoadWorkPermits` (StepPair = 3) obsolete. Existing queries unchanged.  
**Lines:** +84 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -16,6 +16,87 @@
             FROM   TFMS_ArchiveCard C
             WHERE  C.Card = ?";
 
+        // CardSOA.LoadCard (cac.dmt), active TFMS card: class, cut out/in, note, status come from SOA_Card.
+        public const string LoadSoaCard = @"
+            SELECT S.CardClassName, S.CutOut, S.CutIn, S.Note,
+                   S.Status, S.Activated, S.Closed
+            FROM   SOA_Card S
+            WHERE  S.Card = ?";
+
+        // CardSOA.LoadCard, archived TFMS card: same fields from TFMS_ArchiveCard (no Note on archive, as OpenROAD).
+        public const string LoadSoaCardArchive = @"
+            SELECT C.CardClassName, C.CutOut, C.CutIn,
+                   C.Status, C.Activated, C.Closed
+            FROM   TFMS_ArchiveCard C
+            WHERE  C.Card = ?";
+
+        // ItemCategory_ASE.LoadEquip (cac.dmt): equipment on the card linked to an active information item.
+        // ORDER BY matters: the first row per Equip is the one used (TfmsRowRules.FirstSeverityPerEquip).
+        public static readonly string LoadInfoItemEquipSeverity = @"
+            SELECT E.Equip AS Equip,
+                   I.Severity AS Severity
+            FROM   SLC_InformationItemEquip E,
+                   SLC_InformationItem I,
+                   SOA_Job J,
+                   SOA_JobControl JC,
+                   SOA_Job J2
+            WHERE  JC.Card = ? AND
+                   JC.Job = J.Job AND
+                   J.Equip = E.Equip AND
+                   E.Job = I.Job AND
+                   I.Job = J2.Job AND
+                   J2.MoveCategory = " + FMS_PDFReportService.Models.Constants.MoveCategory_InformationItem + @" AND
+                   J2.SwItemStatus = " + FMS_PDFReportService.Models.Constants.Card_Active + @"
+            ORDER BY 1, 2";
+
+        // WorkPermit_ASE.LoadSOA_WP (cac.dmt), active card. Parameters: Card, PermitType (StepPair).
+        // PermitType = StepHeading_WorkPermit (600) or StepHeading_TestPermit (650).
+        public static readonly string LoadPermits = @"
+            SELECT J.Job, J.Status, J.JobClass,
+                   JC.Card, JC.Seq,
+                   J.Equip, J.EquipClass, J.EquipClassName,
+                   JC.MoveEquipClass, JC.PrintID,
+                   J.EquipName,
+                   O.Name AS Subsordesk,
+                   J.Substation,
+                   JC.StepPair,
+                   J.TOMove, J.TOIssued, J.TOComplete,
+                   J.RSMove, J.RSIssued, J.RSComplete,
+                   J.MoveFGColor,
+                   1 AS IsWorkPermit
+            FROM   SOA_Job J,
+                   SOA_JobControl JC,
+                   Udb_Object O
+            WHERE  JC.Card = ? AND
+                   JC.StepPair = ? AND
+                   JC.Job = J.Job AND
+                   J.Status IN ('', '" + FMS_PDFReportService.Models.Constants.JobStatus_NIS + "', '" + FMS_PDFReportService.Models.Constants.JobStatus_Table + @"') AND
+                   J.MoveCategory = " + FMS_PDFReportService.Models.Constants.MoveCategory_Normal + @" AND
+                   J.Substation = O.Object
+            ORDER BY JC.Seq";
+
+        // WorkPermit_ASE.LoadSOA_WP, archived card. Parameters: Card, PermitType (StepPair).
+        public static readonly string LoadPermitsArchive = @"
+            SELECT J.Job, J.Status, J.JobClass,
+                   J.Card, J.Seq,
+                   J.Equip, J.EquipClass, J.EquipClassName,
+                   J.EquipClass AS MoveEquipClass, J.PrintID,
+                   J.EquipName,
+                   O.Name AS Subsordesk,
+                   J.Substation,
+                   J.StepPair,
+                   J.TOMove, J.TOIssued, J.TOComplete,
+                   J.RSMove, J.RSIssued, J.RSComplete,
+                   1 AS IsWorkPermit
+            FROM   SOA_ArchiveJob J,
+                   Udb_Object O
+            WHERE  J.Card = ? AND
+                   J.StepPair = ? AND
+                   J.Status = '' AND
+                   J.MoveCategory = " + FMS_PDFReportService.Models.Constants.MoveCategory_Normal + @" AND
+                   J.Substation = O.Object
+            ORDER BY J.Seq";
+
         public const string LoadChecklist = @"
             SELECT CL.Card, CL.Desk,
                    CL.PermitsReturned, CL.GroundsRemoved,
@@ -140,6 +221,9 @@
                    CL.EnteredBy = O.Object
             ORDER BY CL.LogTime DESC";
 
+        // OBSOLETE - do not use for printing. StepPair = 3 never matches a TOMS permit
+        // (TOMS permits are StepPair 600 / 650), which is why "TOMS Work Permits" printed empty.
+        // Kept unchanged only so nothing else that might reference it breaks. Use LoadPermits.
         public const string LoadWorkPermits = @"
             SELECT 1 AS CardType, 'TOMS' AS CardTypeName,
                    '' AS CardName, '' AS CardStatus,
```

#### `FMS_PDFReportService.Data\Repositories\ITFMSCardRepository.cs`

**Action:** REPLACE (full file)  
**Type of change:** Interface — 2 new method signatures `LoadPermitsWithProtections`, `LoadInfoItemEquipSeverity`.  
**Lines:** +2 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -10,6 +10,8 @@
         IEnumerable<TfmsJob> LoadJobs(int cardId, int archiveFlag);
         IEnumerable<SoaCardLogEntry> LoadCardLog(int cardId, int archiveFlag);
         IEnumerable<WorkPermit> LoadWorkPermits(int cardId, int archiveFlag);
+        List<WorkPermit> LoadPermitsWithProtections(int cardId, int archiveFlag);
+        Dictionary<int, int?> LoadInfoItemEquipSeverity(int cardId);
     }
 }
 
```

#### `FMS_PDFReportService.Data\Repositories\TFMSCardRepository.cs`

**Action:** REPLACE (full file)  
**Type of change:** Repository — `LoadCardHeader` changed (merges SOA_Card fields); 2 new methods `LoadPermitsWithProtections`, `LoadInfoItemEquipSeverity`; 1 `using` added; comment on old `LoadWorkPermits`.  
**Lines:** +49 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -5,6 +5,7 @@
 using FMS_PDFReportService.Data.Queries;
 using FMS_PDFReportService.Models.Cards;
 using FMS_PDFReportService.Models.Jobs;
+using FMS_PDFReportService.Models.Jobs.Colors;
 
 namespace FMS_PDFReportService.Data.Repositories
 {
@@ -24,6 +25,21 @@
                 var headerSql = archiveFlag == 1 ? TFMSQueries.LoadCardHeaderArchive : TFMSQueries.LoadCardHeader;
                 var header = conn.QueryFirstOrDefault<TfmsCardHeader>(headerSql, new { p1 = cardId });
                 if (header == null) return null;
+
+                // Card class, Cut Out / Cut In, Note, Status (CardSOA.LoadCard). Separate query, as in OpenROAD,
+                // so a missing SOA_Card row leaves these blank instead of losing the whole header.
+                var soaSql = archiveFlag == 1 ? TFMSQueries.LoadSoaCardArchive : TFMSQueries.LoadSoaCard;
+                var soa = conn.QueryFirstOrDefault<TfmsCardHeader>(soaSql, new { p1 = cardId });
+                if (soa != null)
+                {
+                    header.CardClassName = soa.CardClassName;
+                    header.CutOut = soa.CutOut;
+                    header.CutIn = soa.CutIn;
+                    header.Note = soa.Note;
+                    header.Status = soa.Status;
+                    header.Activated = soa.Activated;
+                    header.Closed = soa.Closed;
+                }
 
                 var clSql = archiveFlag == 1 ? TFMSQueries.LoadChecklistArchive : TFMSQueries.LoadChecklist;
                 header.Checklists = conn.Query<TfmsChecklist>(clSql, new { p1 = cardId }).ToList();
@@ -57,6 +73,7 @@
             }
         }
 
+        // OBSOLETE - returns nothing for TOMS cards (see TFMSQueries.LoadWorkPermits). Use LoadPermitsWithProtections.
         public IEnumerable<WorkPermit> LoadWorkPermits(int cardId, int archiveFlag)
         {
             var sql = archiveFlag == 1 ? TFMSQueries.LoadWorkPermitsArchive : TFMSQueries.LoadWorkPermits;
@@ -65,6 +82,38 @@
                 return conn.Query<WorkPermit>(sql, new { p1 = cardId }).ToList();
             }
         }
+
+        // "Permits and Protections": Work Permits (StepPair 600) then Test Permits (StepPair 650), each by Seq,
+        // each with its protection moves (WorkPermit_ASE.LoadSOA_WP).
+        public List<WorkPermit> LoadPermitsWithProtections(int cardId, int archiveFlag)
+        {
+            var sql = archiveFlag == 1 ? TFMSQueries.LoadPermitsArchive : TFMSQueries.LoadPermits;
+            var permits = new List<WorkPermit>();
+            using (var conn = _connectionFactory.GetConnection())
+            {
+                foreach (var permitType in new[] { FMS_PDFReportService.Models.Constants.StepHeading_WorkPermit, FMS_PDFReportService.Models.Constants.StepHeading_TestPermit })
+                    permits.AddRange(conn.Query<WorkPermit>(sql, new { p1 = cardId, p2 = permitType }));
+            }
+
+            // Protection moves: FMS_WorkPermitProtection links + the LoadProtectionMove cascade
+            // (cac_include_scripts.dmt). That port already exists, card-type independent, in FMSCardRepository;
+            // reuse it instead of duplicating it.
+            var protectionSource = new FMSCardRepository(_connectionFactory);
+            foreach (var p in permits)
+                p.Protections = protectionSource.LoadProtections(p.Job, archiveFlag).ToList();
+
+            return permits;
+        }
+
+        // ItemCategory_ASE.LoadEquip. Caller must only use it for an active, non-archived card.
+        public Dictionary<int, int?> LoadInfoItemEquipSeverity(int cardId)
+        {
+            using (var conn = _connectionFactory.GetConnection())
+            {
+                var rows = conn.Query<InfoItemEquipSeverity>(TFMSQueries.LoadInfoItemEquipSeverity, new { p1 = cardId }).ToList();
+                return TfmsRowRules.FirstSeverityPerEquip(rows);
+            }
+        }
     }
 }
 
```

#### `FMS_PDFReportService.Engine\Rendering\TelerikReportRenderer.cs`

**Action:** REPLACE (full file)  
**Type of change:** Renderer — 1 new public method `PrependHeaderAtCardStart` (company logo + card title at the start of each card, identity line on the card's other pages; works with continuous page numbers). Existing methods unchanged.  
**Shared:** used by TLS and TOMS (same file as in TLS_Fix.md)  
**Lines:** +61 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -180,6 +180,67 @@
             }
         }
 
+        // TLS / TOMS cards. Page numbers run on over the whole ReportBook, so "PageNumber = 1" only means
+        // "first page of the whole PDF". Instead this relies on PageHeaderSection.PrintOnFirstPage = False,
+        // which Telerik applies to the first page of EACH report (= each card):
+        //   first page of a card : company header + the template's report header (card title + card box)
+        //   other pages of a card: company header + the template's page header (card identity line)
+        // So the company header is put in BOTH the report header and the page header, and the page header
+        // keeps PrintOnFirstPage = False. Reports whose page header prints on the first page (log, permits)
+        // get exactly the old PrependHeader behaviour.
+        public void PrependHeaderAtCardStart(IEnumerable<ReportSource> sources, string headerTemplatePath)
+        {
+            foreach (var source in sources)
+            {
+                if (!(source is InstanceReportSource instance) || !(instance.ReportDocument is Telerik.Reporting.Report report))
+                    continue;
+
+                var pageHeader = report.Items.OfType<Telerik.Reporting.PageHeaderSection>().FirstOrDefault();
+                var reportHeader = report.Items.OfType<Telerik.Reporting.ReportHeaderSection>().FirstOrDefault();
+                if (pageHeader == null || pageHeader.PrintOnFirstPage || reportHeader == null)
+                {
+                    PrependHeader(new[] { source }, headerTemplatePath);
+                    continue;
+                }
+
+                var width = report.Width;
+
+                // Same margin rule as PrependHeader.
+                var margins = report.PageSettings.Margins;
+                var maxTop = Telerik.Reporting.Drawing.Unit.Inch(0.25);
+                if (margins.Top > maxTop)
+                    report.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(margins.Left, margins.Right, maxTop, margins.Bottom);
+
+                // Pages 2+ of the card: company header above the card identity line. PrintOnFirstPage stays False.
+                var forPageHeader = DeserializeReport(headerTemplatePath).Items.OfType<Telerik.Reporting.DetailSection>().First();
+                var pageHeight = forPageHeader.Height;
+                foreach (var item in pageHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
+                    item.Top = item.Top + pageHeight;
+                pageHeader.Height = pageHeader.Height + pageHeight;
+                foreach (var item in forPageHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
+                {
+                    if (item.Left + item.Width > width)
+                        item.Width = width - item.Left;
+                    forPageHeader.Items.Remove(item);
+                    pageHeader.Items.Add(item);
+                }
+
+                // First page of the card: company header above the card title and card box (own copy of the items).
+                var forReportHeader = DeserializeReport(headerTemplatePath).Items.OfType<Telerik.Reporting.DetailSection>().First();
+                var reportHeight = forReportHeader.Height;
+                foreach (var item in reportHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
+                    item.Top = item.Top + reportHeight;
+                reportHeader.Height = reportHeader.Height + reportHeight;
+                foreach (var item in forReportHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
+                {
+                    if (item.Left + item.Width > width)
+                        item.Width = width - item.Left;
+                    forReportHeader.Items.Remove(item);
+                    reportHeader.Items.Add(item);
+                }
+            }
+        }
+
         private static IEnumerable<Telerik.Reporting.SubReport> CollectSubReports(Telerik.Reporting.Report report)
         {
             foreach (var section in report.Items)
```

#### `FMS_PDFReportService.Engine\Groupers\ReportGroupers.cs`

**Action:** REPLACE (full file)  
**Type of change:** Grouper — `TFMSGrouper.ComposeCard` rewritten (card + log + permits, rows coloured, spare blank rows via `CardRowSpacer` like FMS `GroupSpacer`, header as parameters, logo via `PrependHeaderAtCardStart`); 3 new methods `BuildHeaderParameters`, `HeaderDate`, `ClosedLabel`. Only the TOMS part is shown here.  
**Shared:** the same file also contains the TLS change (TLS_Fix.md); copy the file once  
**Lines:** +60 / -11 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -168,23 +168,72 @@
 
         public List<ReportSource> ComposeCard(int cardId, ReportRequest request)
         {
-            var sources = new List<ReportSource>();
-
-            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TFMS/TFMSCardHeader.trdx"),
-                _repo.LoadCardHeader(cardId, request.ArchiveFlag)));
+            // Same layout as the DOS TOMS card: TFMSCard.trdx = card header + job grid (like FeederCard.trdx),
+            // then (ReportType 1) the card log and "Permits and Protections".
+            var archived = request.ArchiveFlag == 1;
+            var header = _repo.LoadCardHeader(cardId, request.ArchiveFlag);
+            var jobs = _repo.LoadJobs(cardId, request.ArchiveFlag).ToList();
+
+            // Information-item severity is only looked up for an active, non-archived card (SOA_Main 'MoveColors').
+            var severity = (!archived && header != null && header.Status == FMS_PDFReportService.Models.Constants.Card_Active)
+                ? _repo.LoadInfoItemEquipSeverity(cardId)
+                : new Dictionary<int, int?>();
+            TfmsRowRules.Apply(jobs, cardId, archived, severity);
+            jobs = CardRowSpacer.AddBlankRows(jobs, request.SpareLines);   // same as FMS GroupSpacer; keep after the colour rules
+
+            var sources = new List<ReportSource>();
             sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TFMS/TFMSCard.trdx"),
-                _repo.LoadJobs(cardId, request.ArchiveFlag)));
+                jobs, BuildHeaderParameters(header)));
 
             if (request.ReportType == 1)
             {
+                var feederNames = new Dictionary<string, object> { { "FeederNames", header?.FeederNames ?? string.Empty } };
+
                 sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TFMS/TFMSCardLog.trdx"),
-                    _repo.LoadCardLog(cardId, request.ArchiveFlag)));
+                    _repo.LoadCardLog(cardId, request.ArchiveFlag).ToList(), feederNames));
+
+                var permitRows = TomsPermitRow.Build(_repo.LoadPermitsWithProtections(cardId, request.ArchiveFlag));
                 sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TFMS/TOMSWorkPermit.trdx"),
-                    _repo.LoadWorkPermits(cardId, request.ArchiveFlag)));
-            }
-
-            _renderer.PrependHeader(sources, _templatePath.Resolve("Common/PageHeader.trdx"));
-            return sources;
+                    permitRows, feederNames));
+            }
+
+            // Company header + card title at the start of each card, identity line on its other pages.
+            _renderer.PrependHeaderAtCardStart(sources, _templatePath.Resolve("Common/PageHeader.trdx"));
+            return sources;
+        }
+
+        // All header values are passed as display strings (formatting tested in C#, not in the .trdx).
+        private static Dictionary<string, object> BuildHeaderParameters(TfmsCardHeader header)
+        {
+            if (header == null)
+                return new Dictionary<string, object>();
+
+            return new Dictionary<string, object>
+            {
+                { "CardText", header.Card.ToString(System.Globalization.CultureInfo.InvariantCulture) },
+                { "CardClassName", header.CardClassName ?? string.Empty },
+                { "FeederNames", header.FeederNames ?? string.Empty },
+                { "Description", header.Description ?? string.Empty },
+                { "CutOutText", HeaderDate(header.CutOut) },
+                { "CutInText", HeaderDate(header.CutIn) },
+                { "ClosedLabel", ClosedLabel(header.Closed) },
+                { "ClosedText", HeaderDate(header.Closed) },
+                { "NoteText", header.Note ?? string.Empty }
+            };
+        }
+
+        // MM/dd/yy HH:mm as on the DOS card; NULL and the Ingres empty date print blank.
+        internal static string HeaderDate(System.DateTime? d)
+        {
+            return FmsColorCalculator.HasValue(d)
+                ? d.Value.ToString("MM/dd/yy HH:mm", System.Globalization.CultureInfo.InvariantCulture)
+                : string.Empty;
+        }
+
+        // "Card Closed:" is printed only on a closed card (tfmscard.js / tlscard.js card header).
+        internal static string ClosedLabel(System.DateTime? closed)
+        {
+            return FmsColorCalculator.HasValue(closed) ? "Card Closed:" : string.Empty;
         }
     }
 
```

<!-- CSHARP-CHANGES END -->

## 4. Tests run

Run: `PROJ=<Telerik-proj> bash Tests/runtests.sh` → `PASSED 1412 FAILED 0`. Then `PROJ=<Telerik-proj> python Tests/mutate.py` → `24/24 mutations caught`.

| Pass | What | Result |
|---|---|---|
| 1 — build + template integrity | `Models` (58 files), `Data` (55), groupers and renderer compile against Telerik stubs. Every `Fields.X` exists on `TfmsJob`; every parameter declared and used; non-colour parameters sent by the grouper, colour parameters **not** sent; grid tiles with no gap/overlap; landscape/margins; continuous page numbers; title; CanGrow/Anchoring; permit fonts | pass |
| 2 — rules | 20 rows rebuilt from benchmark pp. 172-176 (+ p1/p13/p158 colours): every band, navy/red headings, gray equipment, S severity 1/2/3, gray dates, red ground vs black Hi-Pot G=3, green move; ground needs ''/NIS and wins over MoveFGColor; **padded Status `'   '` / `'NIS '` → red, GroundOn NULL → black**; shadow-link green; test letter; archived/inactive card; unknown codes; nulls; permits; spare rows; SQL parameter count/order | pass |
| 3 — colour parameters | Template defaults = `DosColors.TomsPalette` both ways (41). Over 500 generated rows (all codes 0-39 × heading/job/test letter × ground × category) plus benchmark and blank rows: every key has a parameter, the hex equals the palette, and the template shows the same colour as the rules. Editing `ColorGround` changes only ground G + Move (not the red EN - DE - EN heading, not a normal move); editing a band colour changes only the band; an unknown key falls back to the application colour | pass |
| 4 — visual | Emulator (`simrender.py`) draws the templates with the C# rows. **Previous template vs this template, default values: pixel-identical** (card, permits). `Evidence\TOMS_simulated_card_372937.png` vs `TOMS_benchmark_p172.png`; `TOMS_simulated_card_372937_ColorGround_blue.png` shows the effect of an edited `ColorGround` (only the applied-ground row changes) | match |
| Guardrail | 24 deliberate faults, one at a time, incl. Status no longer trimmed, ground mapped to the normal-text colour, database key misspelt, `ColorGround` default black, G cell mapped to the wrong parameter, grouper overwriting a colour parameter, plus the 17 earlier ones | **24/24 caught** |

Total (shared with TLS): 1412 checks, 0 failures.

## 5. What I could NOT verify — be aware

1. **No Telerik runtime here.** The templates were validated by tests and the emulator, not rendered by Telerik. The colour expressions use the same `IIf(..., Parameters.X.Value, ...)` form as `FeederCard1.trdx`; the longest chain has 34 levels. **Render once before release.**
2. **No database.** SQL checked against OpenROAD and statically, not executed. The Status fix follows Ingres comparison rules, but whether `SOA_Job.Status` arrives padded is confirmed only by the query in 6.1.
3. The emulator doesn't grow rows, so wrapped text overlaps in the PNGs; Telerik grows them.
4. In a ReportBook, `PrintOnFirstPage="False"` must hide the page header on the first page of *each* card. Confirm with **2-3 cards in one PDF**.

## 6. Open items for the SME

1. **Ground rows of 34125M — run before release:**
   ```sql
   SELECT column_name, column_datatype, column_length
   FROM   iicolumns
   WHERE  table_name = 'soa_job' AND column_name IN ('status','grounds','groundon');

   SELECT J.Job, J.TOMove, J.Grounds, J.GroundOn, hex(J.Status) AS status_hex
   FROM   SOA_Job J, SOA_JobControl SJ
   WHERE  SJ.Card = 371044 AND SJ.Job = J.Job AND J.Grounds > 0;
   ```
   - Red rows show `status_hex` = `202020` (padded) → fix A is the cure; re-print 34125M, the 3 rows must be red.
   - Red rows have GroundOn NULL, or a Status other than ''/NIS → the DOS print uses another rule (e.g. the single-row refresh at soa.dmt 37581, which does not test Status). **Do not release; send the output.** Changing the rule without that data would also turn the black Hi-Pot rows (G = 3) in toms-dos.pdf red.
2. **Two versions of the ground rule in OpenROAD:** full load `MoveColors` (soa.dmt 36148) tests Status; single-row refresh `SOA_ReloadJob` (37581) does not. The report uses the full-load version, as does the web card. The DOS print program is not in the provided sources.
3. **Switching item filter on permits.** OpenROAD filters `JC.SwitchingItem = :SwitchingItem`; the value the TFMS print passes isn't in the source, so the filter is **not** applied. 372937 gives exactly the benchmark's 9 permits.
4. **Protection de-duplication**: reused from FMS ("D6" grouping); confirm it is wanted for TOMS.
5. **`GroundOn IS NOT NULL`** is OpenROAD's test, so an empty date (`''`) also counts as "ground on".
6. **Green for switching items with a shadow link** comes from the web screen only (not SOA_Main).
7. **"S" hidden on archived cards** follows the web screen and FeederCard Fix 2; no archived TOMS benchmark.
8. **Permit ID** prints `PrintID` (blank in the benchmark).
9. Bands are drawn only for colour codes in `SOA_Job.MoveBGColor`; 0 = no band (as OpenROAD).
10. **Colour parameters are editable by anyone who can save the template.** Restrict write access to the deployed `.trdx` files and get operations approval for the safety colours (2.3).
11. **Where the rules come from:** the DOS report program (called by PrintReport.ps1) is not in the provided files. Rules come from the OpenROAD and web screens and are checked against toms-dos.pdf and 34125M-dos.pdf. Not confirmed by a benchmark: test letter gold, shadow-link green, S hidden on archived cards.

## 7. How to test with real data (UAT)

1. Print **372937** (report type 1) and compare with `toms-dos.pdf` pp. 172-180: logo + "Transmission Feeder Card for 99153" + card box on the first page, logo + identity line later; bands, gray `Bkr 2S`, yellow/turquoise S, gray dates, Hi-Pot G=3 black; no `12/31 23:59`; Op and ID blank; log page with 3 entries; 8 Work Permits + 1 Test Permit with protections.
2. Print **34125M** (card 371044) and compare with `34125M-dos.pdf`: the 6G and 4G rows of 05/05 07:53 and the Grd-SwFdr 76 row have **red G + Move**; the 6G/4G rows with a restore time stay black; PT-Fdr row green; 11 bands, 36 gray cells.
3. Print **369707** and **370851**: Gold / LightPink / LightSkyBlue bands, red ground moves on p7 and p13, green moves on p4.
4. Print one archived card (ARCH=1): no S, no severity colours, nothing gray in Type/Equipment.
5. **Colour parameter check:** open `TFMSCard.trdx` in the Report Designer, set `ColorGround` to `#0000FF`, save, print 34125M → only the 3 applied-ground rows are blue (G + Move); EN - DE - EN stays red. Set it back to `#FF0000`.
6. `PROJ=<Telerik-proj> bash Tests/runtests.sh` → `PASSED 1412 FAILED 0`.
