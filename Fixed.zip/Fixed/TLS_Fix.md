# TLS card — final logic (`tls-rpt` = replica of `tls-dos`)

**Benchmark:** `issues\v2\Issues_2\tls-dos.pdf` (cards 96DHZA425413, 96PRNA410029, 96PRNA410945)
**Our report:** `tls-rpt.pdf` (cards 96DHZA425414, 96PRNA410944)

> The two PDFs were printed from **different cards**, so cell values can't be compared one to one.
> Everything below compares structure, colour rules and formatting, which are the same for every card.

**This folder (`issues\v2\Issues_3\Fixed\`) is the complete, final delivery** for TLS and TOMS. It replaces `issues\v2\Fixed\`.

| Folder | What |
|---|---|
| `Code\...` | Full replacement C# files, same relative paths as `Telerik-proj` (shared with TOMS) |
| `Templates\TLS\TLSCard.trdx` | Card header + job grid in one report (FeederCard1 layout), **with support-editable colour parameters** |
| `Tests\` | Template generator, build, 1412 checks, fault injection, visual emulator (section 4) |
| `Evidence\` | Benchmark page vs simulated page from the delivered template |
| `Color_Parameters.md` | Guide for the support team: how to change a colour in the Telerik Report Designer |

---

## 0. What is new in this final version

| # | Change | Why |
|---|---|---|
| A | **Colours are report parameters.** Support can change any TLS card colour in the Telerik Report Designer, without a code change. | Support requirement, same approach as `FeederCard1.trdx`. With the default values the card prints exactly as before (pixel-identical in the emulator). |

The TLS row rules themselves did not change.

---

## 1. What was wrong (and is fixed)

| # | Benchmark (`tls-dos.pdf`) | Our report (before) | Cause |
|---|---|---|---|
| 1 | Landscape. Card header box at the top of page 1, then the job grid on the same page | Portrait header page (`TLSCardHeader.trdx`), grid starts on page 2 | Two separate reports in a ReportBook |
| 2 | Header shows Line # / Line type, Route, Carrier, **Type of Work**, **Fdrs / Nwks**, **Stations**, Note, Circuit Note, Reason For Failure | Labels and values don't line up; **Feeders / Stations tables empty** | Feeders/Stations never loaded; "Type of Work" never derived |
| 3 | Empty date cells that don't apply are **gray** (`#DCDCDC`) and **blank** | Prints **`12/31 23:59`**, white | Ingres empty date (`''`) arrives as 12/31 23:59; not handled |
| 4 | Op columns **blank** | Prints operator ids | Template bound `TOOperator` / `RSOperator` |
| 5 | Column headers: Station, Circuit, Move, Results, *(blank)* | Substation, Line, Move, Results, **St** | Template |
| 6 | Status column shows **T** only for transferred moves | Raw status | `TLSJob_ASE.LoadJobs` maps `'Xfr'` → `T`; not ported |
| 7 | Step headings **navy**, inside the Move cell, other cells empty | Full-width bold row | Template |
| 8 | Page 2+ repeats the line number at the top | No card identity on later pages | No page header |
| 9 | — | Colours could only be changed by a developer | Requirement (change A) |

**Row order is not a bug.** The C# job query equals OpenROAD `TLSJob_ASE.LoadJobs` (same table, filters and `ORDER BY steppair, seq, job`). Rows sharing times are the data of card 96PRNA410944, not a join fan-out.

## 2. The rules (with sources)

Sources: `openrd\TLS_telephonecard\...\cac.dmt` (TLSJob_ASE / TLSCard_ASE), `online\tls\tlscard.js`, `fms-online\database.js` + `fms.css`.

### 2.1 Row colours and text — `TlsRowRules.ApplyRow`

The colour key column is the report parameter that support can edit (section 2.2).

| Cell | Rule | Colour key | Source |
|---|---|---|---|
| Heading row (JobClass = 0) | Only the Move cell has text. All other cells empty and white | `ColorCellBg` | tlscard.js `card_IsStepHeading`; every heading in tls-dos.pdf |
| Heading text colour | Navy `#000080` if CircuitClass = -99, else black. Not bold. Leading spaces kept (DOS indents with them) | `ColorStepHeading` / `ColorText` | cac.dmt 228771; measured Arial 8, 0x000080 |
| TO/RS Issued/Complete text | `MM/dd HH:mm`. NULL and empty date print nothing | — | — |
| TO/RS Issued/Complete background | **Empty date (`''`) → gray `#DCDCDC`**; NULL → white | `ColorDateGrayOut` / `ColorCellBg` | cac.dmt 228775-228787; measured (220,220,220) |
| Op (both) | Always blank | — | benchmark; FMS Fix 3 |
| Station / Circuit / Results | `SubstationName` / `Linenumber` / `Results` | — | tlscard.js `card_LoadJob` |
| Status (unlabelled column) | `T` if Status = `Xfr`, else blank | — | cac.dmt 228559 |
| Move text (job rows) | Black | `ColorText` | benchmark |
| Move background | Pale red `#FFB6C1` when MoveType = `COOP` **and** `TC_WorkPermit.VendorTicketNumber = 'PENDING'`, else white | `ColorCoopPending` / `ColorCellBg` | cac.dmt 228816-228826 |
| Transferred move on a closed card | NULL dates also gray; ported exactly, see open item 1 | `ColorDateGrayOut` | cac.dmt 228792-228810 |
| Spare blank rows | Empty, white | `ColorCellBg`, `ColorText` | `CardRowSpacer` |

**Deliberately not ported:** OpenROAD dims completed / pending-confirmation moves with light-gray text (cac.dmt 228756). `tls-dos.pdf` has **no gray text at all**, although it has moves completed on both sides (e.g. Check Alarm Status 01/05 10:13 → 01/16 10:15). So the DOS report does not apply it, and neither do we.

### 2.2 Support-editable colours — `TLSCard.trdx` parameters

How it works (same mechanism as TOMS):
1. The rules choose a **colour key** for each coloured cell (`TlsJob.TOIssuedBgKey`, `TOCompleteBgKey`, `RSIssuedBgKey`, `RSCompleteBgKey`, `MoveFgKey`, `MoveBgKey`). `TlsRowRules.Resolve()` derives the hex from the key through `DosColors.TlsPalette`, so key and hex can never disagree.
2. The template maps the key to the **report parameter with the same name**, e.g.
   `= IIf(Fields.MoveFgKey = "ColorText", Parameters.ColorText.Value, IIf(Fields.MoveFgKey = "ColorStepHeading", Parameters.ColorStepHeading.Value, Fields.MoveFg))`
3. The parameter **default value = the benchmark colour**. Support changes the value in the Telerik Report Designer.
4. A key with no parameter falls back to the hex sent by the application. A cell never goes blank or white.
5. The grouper never sends colour parameters (test-enforced). The renderer loads the `.trdx` on every print, so an edit applies to the next card printed.

| Parameter | Default | Colours |
|---|---|---|
| `ColorText` | #000000 | normal text, non-step headings / notes |
| `ColorCellBg` | #FFFFFF | normal cell background, spare blank rows |
| `ColorDateGrayOut` | #DCDCDC | Issued/Complete when the step is not used |
| `ColorStepHeading` | #000080 | step headings (Alarms, Switching Operations, …) |
| `ColorCoopPending` | #FFB6C1 | Move background while a Co-Op test is pending |

**Safety colours** (`ColorDateGrayOut`, `ColorCoopPending`) should be changed only with operations approval. Full list and steps: `Color_Parameters.md`.

TLS uses its own gray (`#DCDCDC`); TOMS uses `#808080`. Both are `CC_PALE_GRAY` in OpenROAD, but the two DOS reports draw it differently. The parameters are per template, so they can be changed independently.

### 2.3 Header — `TLSCard_ASE.LoadCard` / `LoadFeedersAndStations`

| Box | Value |
|---|---|
| Top left | `Linenumber` · `LineTypeName` |
| Route / Carrier | `RouteName` / `CarrierName` |
| Type of Work | CardType 0 → `TROUBLE`, otherwise `SCHEDULED` (cac.dmt 227800-227804) |
| Fdrs / Nwks | Active card: `Udb_Object`/`Udb_Grouping` members of the circuit, supertypes Feeder 40, Network 10136, Line 10, DivisionWorkstation 15016, relationship MemberOf 52, names `SQUEEZE`d. Archived card: `TC_ArchiveCard.FeederNames` split on commas. Printed `A, B, C` |
| Stations | Same, supertypes Substation 5, TelCircuitTerminal 15017 / `TC_ArchiveCard.SubstationNames` |
| Card Closed | Label and date only when the card has a Closed date |
| Note | `TC_CardNote.Note` |
| Circuit Note | `TC_Card.Notes` |
| Reason For Failure | `ReasonForFailure` |

Mapping proof: tls-rpt.pdf page 3 printed "Montefiore contact Vasile…" under *Card Note* and "ONLY 1 LINE OF PROTECTION…" under *Notes*. The benchmark prints the Montefiore text under **Note:** and the circuit text under **Circuit Note:**.

### 2.4 Layout — `TLSCard.trdx` (FeederCard1 format)

- Letter **landscape**, margins L/R 0.15in, T/B 0.5in, width 10.7in.
- **Card start (first page of each card):** company logo, centered title **"Telephone Line Feeder Card for {Linenumber}"** (12pt bold), card box. The title is in the report header, so each card in a multi-card PDF starts with its own title.
- **Other pages of the card:** logo, then the line number (9pt bold). This is the page header with `PrintOnFirstPage="False"`, applied by Telerik to the first page of *each* report (= each card).
- The logo is placed by the renderer method `PrependHeaderAtCardStart` (TLS/TOMS cards only), without the `PageNumber > 1` rule of the old `PrependHeader`.
- Column header repeats on every page; footer = print time + "Page *n* of *N*". **Page numbers run continuously over the whole PDF.**
- **Spare blank rows** (query string `LINE` → `ReportRequest.SpareLines`, default 2), same algorithm as FMS `GroupSpacer`. Added at the end of every step-heading group, except after a last group with no rows. Clamped 0–10. Runs after the colour rules.
- Grid (inches): Op 0.35 · Issued 0.75 · Complete 0.75 · Station 1.10 · Circuit 1.10 · Move 3.50 · Results 1.10 · status 0.25 · Op 0.35 · Issued 0.72 · Complete 0.72 = 10.69. Row 0.27in, Arial 8.
- Every cell `CanGrow="True"`; every grid cell `Anchoring="Top, Bottom"`. Enforced by tests.
- 6 colour bindings (4 dates, Move text, Move background), all key → parameter with application fallback.
- The template is generated by `Tests\gen_trdx.py`. **Edit the generator, not the XML**, then run `runtests.sh`. Support edits a parameter **value** in the deployed `.trdx`; that does not need the generator.

## 3. Steps

> **Replace whole files, do not copy methods.** Every file in `Code\` is the complete file: your original plus the change. Copy it over the file with the same path in `Telerik-proj` (or add it, if new). This is only safe if your `Telerik-proj` file is still the same as the copy in `issues\v2\Issues_2\Telerik-proj` (snapshot of 2026-09-30). Otherwise merge that file by hand.

| # | File | Change |
|---|---|---|
| 1 | `Models\Jobs\TlsJob.cs` | + 23 properties: display texts/colours, `IsBlankRow`, 6 colour keys. Existing properties unchanged (TLS Excel unaffected) |
| 2 | `Models\Cards\TlsCardModels.cs` | `TlsCardHeader`: + `FeederNames`, `SubstationNames`, `CardTypeName`, `FeedersText`, `StationsText`, `Squeeze()`, `SplitNames()` |
| 3 | **New** `Models\Jobs\Colors\DosColors.cs` | Palette, colour keys, TOMS/TLS palettes, `KeyFromCode` (shared with TOMS) |
| 4 | **New** `Models\Jobs\Colors\TlsRowRules.cs` | Rules of section 2.1 (keys + `Resolve`) |
| 5 | **New** `Models\Jobs\Colors\CardRowSpacer.cs` | Spare blank rows for TLS and TOMS (shared) |
| 6 | `Models\FMS_PDFReportService.Models.csproj` | + `<Compile Include>` for the new files (shared) |
| 7 | `Data\Queries\TLSQueries.cs` | + `LoadFeeders`, `LoadStations`, `LoadFeederStationNamesArchive`, `FindCoopPending` |
| 8 | `Data\Repositories\ITLSCardRepository.cs` | + `HashSet<int> LoadCoopPendingJobs(IEnumerable<TlsJob> jobs)` |
| 9 | `Data\Repositories\TLSCardRepository.cs` | `LoadCardHeader` loads Feeders/Stations (active and archive); new `LoadCoopPendingJobs` |
| 10 | `Engine\Rendering\TelerikReportRenderer.cs` | + `PrependHeaderAtCardStart` (shared). Existing `PrependHeader` unchanged |
| 11 | `Engine\Groupers\ReportGroupers.cs` | `TLSGrouper.ComposeCard`: one source `TLS/TLSCard.trdx`. Same file has the TOMS change; copy once |
| 12 | `Engine\Templates\TLS\TLSCard.trdx` | Replace with the delivered file |

`TLSCardHeader.trdx` is no longer used (left as is). No DI / constructor change.

Core of the grouper:

```csharp
var header = _repo.LoadCardHeader(cardId, request.ArchiveFlag);
var jobs = _repo.LoadJobs(cardId, request.ArchiveFlag).ToList();
TlsRowRules.Apply(jobs, header?.Status ?? 0, _repo.LoadCoopPendingJobs(jobs));   // sets colour keys + hex
jobs = CardRowSpacer.AddBlankRows(jobs, request.SpareLines);
sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TLS/TLSCard.trdx"),
    jobs, BuildHeaderParameters(header)));                                       // no colour parameters sent
```

Deploy the C# and the template **together**: the template binds the new `...Key` fields.

<!-- CSHARP-CHANGES START -->

## 3A. C# changes — every file, every change

Generated from your original `Telerik-proj` files compared with `Issues_3\Fixed\Code\`. **Copy the complete file from `Issues_3\Fixed\Code\`; do not paste these diffs by hand.** They are here so you (and a reviewer) can see exactly what is different.

| # | File | Action | Type of change |
|---|---|---|---|
| 1 | `FMS_PDFReportService.Models\Jobs\TlsJob.cs` | REPLACE | Model |
| 2 | `FMS_PDFReportService.Models\Cards\TlsCardModels.cs` | REPLACE | Model |
| 3 | `FMS_PDFReportService.Models\Jobs\Colors\DosColors.cs` | ADD | New static class (shared with TOMS) |
| 4 | `FMS_PDFReportService.Models\Jobs\Colors\TlsRowRules.cs` | ADD | New static class |
| 5 | `FMS_PDFReportService.Models\Jobs\Colors\CardRowSpacer.cs` | ADD | New static class (shared with TOMS) |
| 6 | `FMS_PDFReportService.Models\FMS_PDFReportService.Models.csproj` | REPLACE | Project file (shared with TOMS) |
| 7 | `FMS_PDFReportService.Data\Queries\TLSQueries.cs` | REPLACE | SQL |
| 8 | `FMS_PDFReportService.Data\Repositories\ITLSCardRepository.cs` | REPLACE | Interface |
| 9 | `FMS_PDFReportService.Data\Repositories\TLSCardRepository.cs` | REPLACE | Repository |
| 10 | `FMS_PDFReportService.Engine\Rendering\TelerikReportRenderer.cs` | REPLACE | Renderer (shared with TOMS) |
| 11 | `FMS_PDFReportService.Engine\Groupers\ReportGroupers.cs` | REPLACE | Grouper (shared with TOMS) |

Change types: **Model** = data class the template binds to; **SQL** = query text; **Interface** / **Repository** = data access; **Grouper** = which templates are printed and with what data; **New class** = new logic file; **Project file** = list of files to compile.

#### `FMS_PDFReportService.Models\Jobs\TlsJob.cs`

**Action:** REPLACE (full file)  
**Type of change:** Model — 23 new properties added at the end of the class: display text and colours for the grid, `IsBlankRow` for spare rows, and 6 colour keys (`...BgKey` / `...FgKey`, = TLSCard.trdx colour parameter names). No existing property changed or removed.  
**Lines:** +27 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -41,6 +41,33 @@
         public string FinalSwitchPos { get; set; }
         public DateTime? InService { get; set; }
         public DateTime? OutService { get; set; }
+
+        // Display values for TLSCard.trdx. Not database columns; set only by TlsRowRules.Apply.
+        public bool IsHeading { get; set; }
+        public bool IsBlankRow { get; set; }   // spare blank row added by CardRowSpacer
+        public string TOIssuedText { get; set; }
+        public string TOCompleteText { get; set; }
+        public string RSIssuedText { get; set; }
+        public string RSCompleteText { get; set; }
+        public string TOIssuedBg { get; set; }
+        public string TOCompleteBg { get; set; }
+        public string RSIssuedBg { get; set; }
+        public string RSCompleteBg { get; set; }
+        public string StationText { get; set; }
+        public string CircuitText { get; set; }
+        public string MoveText { get; set; }
+        public string MoveFg { get; set; }
+        public string MoveBg { get; set; }
+        public string ResultsText { get; set; }
+        public string StatusText { get; set; }
+
+        // Colour keys (= TLSCard.trdx parameter names) for the colours above; see DosColors.
+        public string TOIssuedBgKey { get; set; }
+        public string TOCompleteBgKey { get; set; }
+        public string RSIssuedBgKey { get; set; }
+        public string RSCompleteBgKey { get; set; }
+        public string MoveFgKey { get; set; }
+        public string MoveBgKey { get; set; }
     }
 }
 
```

#### `FMS_PDFReportService.Models\Cards\TlsCardModels.cs`

**Action:** REPLACE (full file)  
**Type of change:** Model — `TlsCardHeader`: 2 new data properties (`FeederNames`, `SubstationNames`), 3 new read-only properties (`CardTypeName`, `FeedersText`, `StationsText`), 3 new helper methods (`JoinNames`, `Squeeze`, `SplitNames`).  
**Lines:** +38 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -38,6 +38,44 @@
         public string CardNote { get; set; }
         public List<TlsFeeder> Feeders { get; set; } = new List<TlsFeeder>();
         public List<TlsStation> Stations { get; set; } = new List<TlsStation>();
+
+        // Archive card only: comma-separated names stored on TC_ArchiveCard (TLSCard_ASE.LoadFeedersAndStations).
+        public string FeederNames { get; set; }
+        public string SubstationNames { get; set; }
+
+        // TLSCard_ASE.LoadCard: CardType 0 = TROUBLE, anything else = SCHEDULED ("Type of Work").
+        public string CardTypeName { get { return CardType == 0 ? "TROUBLE" : "SCHEDULED"; } }
+
+        // "Fdrs / Nwks:" and "Stations:" lines, joined the way the DOS card prints them.
+        public string FeedersText { get { return JoinNames(Feeders == null ? null : Feeders.ConvertAll(f => f.Name)); } }
+        public string StationsText { get { return JoinNames(Stations == null ? null : Stations.ConvertAll(s => s.Name)); } }
+
+        private static string JoinNames(List<string> names)
+        {
+            if (names == null) return string.Empty;
+            var kept = names.ConvertAll(n => (n ?? string.Empty).Trim()).FindAll(n => n.Length > 0);
+            return string.Join(", ", kept);
+        }
+
+        // OpenROAD SQUEEZE(): trim, and collapse runs of white space to one blank.
+        public static string Squeeze(string s)
+        {
+            if (string.IsNullOrEmpty(s)) return string.Empty;
+            return System.Text.RegularExpressions.Regex.Replace(s.Trim(), @"\s+", " ");
+        }
+
+        // Archive cards keep names as "A, B, C" (TLSCard_ASE.LoadFeedersAndStations ELSE branch).
+        public static List<string> SplitNames(string commaSeparated)
+        {
+            var result = new List<string>();
+            if (string.IsNullOrEmpty(commaSeparated)) return result;
+            foreach (var part in commaSeparated.Split(','))
+            {
+                var name = Squeeze(part);
+                if (name.Length > 0) result.Add(name);
+            }
+            return result;
+        }
     }
 
     public class TlsFeeder
```

#### `FMS_PDFReportService.Models\Jobs\Colors\DosColors.cs`

**Action:** ADD (new file)  
**Type of change:** New static class — colour palette as the DOS PDFs draw it (OpenROAD colour code → hex), colour keys (= report parameter names), TOMS/TLS palettes (key → default hex) and `KeyFromCode`.  
**Shared:** also used by TOMS  
**Size:** 132 lines (complete file below)

```csharp
using System.Collections.Generic;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // Colours as the DOS (benchmark) PDFs draw them, for the TLS and TOMS card grids.
    // Codes are OpenROAD CC_* values (Constants.cs). The hex values come from fms-online database.js
    // db_GetMappedColor and fms.css, except CC_BLUE (DOS draws step headings Navy, not #0000ff).
    // "Seen" = measured in tls-dos.pdf / toms-dos.pdf. Do NOT use Engine ColorMappingService for these
    // reports: its palette does not match the benchmark (e.g. code 33 there is not Gold).
    //
    // Support-editable colours: each coloured cell gets a colour KEY (TfmsJob/TlsJob ...Key) plus the hex
    // below. The key is the name of a report parameter in TFMSCard.trdx / TLSCard.trdx whose default value
    // is the same hex, so support can change a colour in the Telerik Report Designer without a code change.
    // A key with no parameter in the template falls back to the hex sent by the application.
    public static class DosColors
    {
        public const string White = "#FFFFFF";
        public const string Black = "#000000";
        public const string Navy = "#000080";           // seen: TLS + TOMS step headings
        public const string Red = "#FF0000";            // seen: TOMS ground moves, G column
        public const string Green = "#008000";          // seen: TOMS move text
        public const string Gray = "#808080";           // seen: TOMS Type/Equipment text (CC_LIGHT_GRAY)

        // Ingres empty date ('' = step not used). Both are CC_PALE_GRAY in OpenROAD,
        // but the two DOS reports draw it differently.
        public const string TlsGrayOut = "#DCDCDC";     // seen: tls-dos.pdf (220,220,220)
        public const string TomsGrayOut = "#808080";    // seen: toms-dos.pdf (128,128,128)

        // Origin ("S") cell, information-item severity (fms.css .Info_1/.Info_2/.Info_3)
        public const string InfoSeverity1 = "#FFFF00";  // seen: yellow
        public const string InfoSeverity2 = "#00CED1";  // seen: darkturquoise
        public const string InfoSeverity3 = "#3CB371";  // seen: mediumseagreen

        // ---- Colour keys = report parameter names (roles decided by the row rules) -----------------------
        public const string KeyText = "ColorText";                       // normal text (TOMS + TLS)
        public const string KeyCellBg = "ColorCellBg";                   // normal cell background (TOMS + TLS)
        public const string KeyDateGrayOut = "ColorDateGrayOut";         // empty Ingres date (TOMS + TLS, different defaults)
        public const string KeyEquipNoControl = "ColorEquipNoControl";   // TOMS Type/Equipment when card has no control
        public const string KeyGround = "ColorGround";                   // TOMS ground still applied: G + Move text
        public const string KeyShadowLink = "ColorShadowLink";           // TOMS switching item with shadow link
        public const string KeyTestLetter = "ColorTestLetter";           // TOMS outstanding test letter (Move background)
        public const string KeyInfoSeverity1 = "ColorInfoSeverity1";     // TOMS origin cell, info item severity 1
        public const string KeyInfoSeverity2 = "ColorInfoSeverity2";
        public const string KeyInfoSeverity3 = "ColorInfoSeverity3";
        public const string KeyStepHeading = "ColorStepHeading";         // TLS step heading text (CircuitClass -99)
        public const string KeyCoopPending = "ColorCoopPending";         // TLS Co-Op test pending (Move background)

        // OpenROAD colour codes stored in the database (SOA_Job.MoveFGColor / MoveBGColor): key "DbColor" + name.
        private static readonly (int Code, string Name, string Hex)[] Codes =
        {
            (Constants.CC_BLACK, "Black", Black),
            (Constants.CC_RED, "Red", Red),
            (Constants.CC_GREEN, "Green", Green),
            (Constants.CC_BLUE, "Blue", Navy),
            (Constants.CC_YELLOW, "Yellow", "#FFFF00"),
            (Constants.CC_CYAN, "Cyan", "#00FFFF"),
            (Constants.CC_PINK, "Pink", "#FFC0C0"),
            (Constants.CC_BROWN, "Brown", "#8B4513"),
            (Constants.CC_ORANGE, "Orange", "#FF8C00"),
            (Constants.CC_PURPLE, "Purple", "#800080"),
            (Constants.CC_GRAY, "Gray", "#696969"),
            (Constants.CC_LIGHT_RED, "LightRed", "#FF4500"),
            (Constants.CC_LIGHT_GREEN, "LightGreen", "#3CB371"),
            (Constants.CC_LIGHT_BLUE, "LightBlue", "#6495ED"),
            (Constants.CC_LIGHT_YELLOW, "LightYellow", "#F0E68C"),
            (Constants.CC_LIGHT_CYAN, "LightCyan", "#B0E0E6"),
            (Constants.CC_LIGHT_PINK, "LightPink", "#EE82EE"),
            (Constants.CC_LIGHT_BROWN, "LightBrown", "#D2B48C"),
            (Constants.CC_LIGHT_ORANGE, "LightOrange", "#FFA500"),
            (Constants.CC_LIGHT_PURPLE, "LightPurple", "#8A2BE2"),
            (Constants.CC_LIGHT_GRAY, "LightGray", Gray),
            (Constants.CC_PALE_RED, "PaleRed", "#FFB6C1"),      // seen: LightPink band
            (Constants.CC_PALE_GREEN, "PaleGreen", "#90EE90"),
            (Constants.CC_PALE_BLUE, "PaleBlue", "#87CEFA"),    // seen: LightSkyBlue band
            (Constants.PALE_YELLOW, "PaleYellow", "#FAFAD2"),
            (Constants.CC_PALE_CYAN, "PaleCyan", "#E0FFFF"),
            (Constants.CC_PALE_PINK, "PalePink", "#D8BFD8"),    // seen: Thistle band
            (Constants.CC_PALE_BROWN, "PaleBrown", "#DEB887"),  // seen: BurlyWood band
            (Constants.CC_PALE_ORANGE, "PaleOrange", "#FFD700"),// seen: Gold band
            (Constants.CC_PALE_PURPLE, "PalePurple", "#E6E6FA"),
            (Constants.CC_PALE_GRAY, "PaleGray", "#A9A9A9"),
        };

        // Maps an OpenROAD colour code to hex. Returns null for 0 (not set) and for codes
        // with no mapping, so the caller keeps its default.
        public static string FromCode(int code)
        {
            foreach (var c in Codes) if (c.Code == code) return c.Hex;
            return null;
        }

        // Colour key for an OpenROAD colour code; null when FromCode is null.
        public static string KeyFromCode(int code)
        {
            foreach (var c in Codes) if (c.Code == code) return "DbColor" + c.Name;
            return null;
        }

        // Key -> default hex, per report. These are the report parameters' default values.
        public static readonly IReadOnlyDictionary<string, string> TomsPalette = BuildToms();
        public static readonly IReadOnlyDictionary<string, string> TlsPalette = new Dictionary<string, string>
        {
            { KeyText, Black },
            { KeyCellBg, White },
            { KeyDateGrayOut, TlsGrayOut },
            { KeyStepHeading, Navy },
            { KeyCoopPending, "#FFB6C1" },   // CC_PALE_RED
        };

        private static Dictionary<string, string> BuildToms()
        {
            var p = new Dictionary<string, string>
            {
                { KeyText, Black },
                { KeyCellBg, White },
                { KeyDateGrayOut, TomsGrayOut },
                { KeyEquipNoControl, Gray },
                { KeyGround, Red },
                { KeyShadowLink, Green },
                { KeyTestLetter, "#FFD700" },   // CC_PALE_ORANGE
                { KeyInfoSeverity1, InfoSeverity1 },
                { KeyInfoSeverity2, InfoSeverity2 },
                { KeyInfoSeverity3, InfoSeverity3 },
            };
            foreach (var c in Codes) p.Add("DbColor" + c.Name, c.Hex);
            return p;
        }

        public static string Toms(string key) { return TomsPalette[key]; }
        public static string Tls(string key) { return TlsPalette[key]; }
    }
}
```

#### `FMS_PDFReportService.Models\Jobs\Colors\TlsRowRules.cs`

**Action:** ADD (new file)  
**Type of change:** New static class — row rules: texts, date gray-out, heading colour, status T, Co-Op pale red. Rules set colour keys; `Resolve()` derives every hex from the key.  
**Size:** 105 lines (complete file below)

```csharp
using System;
using System.Collections.Generic;
using System.Globalization;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // Display values and colours for one TLS card row (TLSCard.trdx).
    // Port of cac.dmt TLSJob_ASE.LoadJobs (Status -> 'T') and TLSJob_ASE.SetMoveColors,
    // limited to what the DOS benchmark (tls-dos.pdf) draws:
    //   - background colours ARE drawn (empty-date gray, Co-Op pending pale red)
    //   - foreground dimming of completed / pending-confirmation moves (CC_LIGHT_GRAY text) is NOT drawn:
    //     tls-dos.pdf has no gray text at all, although it contains moves completed on both sides.
    public static class TlsRowRules
    {
        public static void Apply(IEnumerable<TlsJob> jobs, int cardStatus, ICollection<int> coopPendingJobs)
        {
            if (jobs == null) return;
            foreach (var j in jobs)
                ApplyRow(j, cardStatus, coopPendingJobs);
        }

        public static void ApplyRow(TlsJob j, int cardStatus, ICollection<int> coopPendingJobs)
        {
            // LoadJobs: 'Xfr' (transferred) prints as T, every other status prints blank.
            j.StatusText = j.Status == "Xfr" ? "T" : string.Empty;
            j.MoveText = j.TOMove ?? string.Empty;   // leading spaces kept: the DOS card indents with them
            // Every colour below is a key (= TLSCard.trdx parameter name); Resolve() turns keys into hex.
            j.MoveBgKey = DosColors.KeyCellBg;

            if (j.JobClass == 0)
            {
                // Step heading / note row (tlscard.js card_IsStepHeading). Only the Move cell has text.
                // SetMoveColors: JobClass 0 AND CircuitClass -99 -> CC_BLUE (DOS draws Navy); other rows black.
                // Every other cell is empty and white (all heading rows in tls-dos.pdf).
                j.IsHeading = true;
                j.MoveFgKey = j.CircuitClass == -99 ? DosColors.KeyStepHeading : DosColors.KeyText;
                j.StationText = j.CircuitText = j.ResultsText = j.StatusText = string.Empty;
                j.TOIssuedText = j.TOCompleteText = j.RSIssuedText = j.RSCompleteText = string.Empty;
                j.TOIssuedBgKey = j.TOCompleteBgKey = j.RSIssuedBgKey = j.RSCompleteBgKey = DosColors.KeyCellBg;
                Resolve(j);
                return;
            }

            j.IsHeading = false;
            j.MoveFgKey = DosColors.KeyText;
            j.StationText = j.SubstationName ?? string.Empty;
            j.CircuitText = j.Linenumber ?? string.Empty;
            j.ResultsText = j.Results ?? string.Empty;

            j.TOIssuedText = DateText(j.TOIssued);
            j.TOCompleteText = DateText(j.TOComplete);
            j.RSIssuedText = DateText(j.RSIssued);
            j.RSCompleteText = DateText(j.RSComplete);

            // "Gray out move performance if not available": Ingres empty date ('') only, never NULL.
            j.TOIssuedBgKey = GrayIfBlank(j.TOIssued);
            j.TOCompleteBgKey = GrayIfBlank(j.TOComplete);
            j.RSIssuedBgKey = GrayIfBlank(j.RSIssued);
            j.RSCompleteBgKey = GrayIfBlank(j.RSComplete);

            // "Handle Transferred moves for closed cards": NULL dates also gray.
            // Ported exactly: OpenROAD compares the TC card status (1..4) with Card$Closed (50),
            // so in production this branch never fires. See TLS_Fix.md, open item.
            if (j.StatusText == "T" && cardStatus == Constants.Card_Closed)
            {
                if (j.TOIssued == null) j.TOIssuedBgKey = DosColors.KeyDateGrayOut;
                if (j.TOComplete == null) j.TOCompleteBgKey = DosColors.KeyDateGrayOut;
                if (j.RSIssued == null) j.RSIssuedBgKey = DosColors.KeyDateGrayOut;
                if (j.RSComplete == null) j.RSCompleteBgKey = DosColors.KeyDateGrayOut;
            }

            // "Highlight move if Co-Op test is PENDING ticketnumber"
            if (string.Equals((j.MoveType ?? string.Empty).Trim(), Constants.MoveType_COOP, StringComparison.Ordinal)
                && coopPendingJobs != null && coopPendingJobs.Contains(j.Job))
            {
                j.MoveBgKey = DosColors.KeyCoopPending;
            }
            Resolve(j);
        }

        // Hex sent with each key = the TLSCard.trdx parameter default; used by the template only when
        // the template has no parameter for that key.
        public static void Resolve(TlsJob j)
        {
            j.TOIssuedBg = DosColors.Tls(j.TOIssuedBgKey);
            j.TOCompleteBg = DosColors.Tls(j.TOCompleteBgKey);
            j.RSIssuedBg = DosColors.Tls(j.RSIssuedBgKey);
            j.RSCompleteBg = DosColors.Tls(j.RSCompleteBgKey);
            j.MoveFg = DosColors.Tls(j.MoveFgKey);
            j.MoveBg = DosColors.Tls(j.MoveBgKey);
        }

        private static string GrayIfBlank(DateTime? d)
        {
            return FmsColorCalculator.IsBlank(d) ? DosColors.KeyDateGrayOut : DosColors.KeyCellBg;
        }

        // NULL and the empty-date value both print as nothing; anything else as MM/dd HH:mm.
        public static string DateText(DateTime? d)
        {
            if (!FmsColorCalculator.HasValue(d)) return string.Empty;
            return d.Value.ToString("MM/dd HH:mm", CultureInfo.InvariantCulture);
        }
    }
}
```

#### `FMS_PDFReportService.Models\Jobs\Colors\CardRowSpacer.cs`

**Action:** ADD (new file)  
**Type of change:** New static class — spare blank rows (query string LINE / `request.SpareLines`) for TLS and TOMS, same algorithm as FMS `GroupSpacer`; FMS file not touched.  
**Shared:** also used by TOMS (same file as in TOMS_Fix.md)  
**Size:** 110 lines (complete file below)

```csharp
using System;
using System.Collections.Generic;

namespace FMS_PDFReportService.Models.Jobs.Colors
{
    // Spare blank rows for the TLS and TOMS cards (query string LINE -> ReportRequest.SpareLines),
    // same algorithm as GroupSpacer (FMS card):
    //   - a group starts at a step heading row;
    //   - LINE blank rows (clamped 0..GroupSpacer.MaxLines) are added at the end of every group,
    //     including a group that has only its heading,
    //   - EXCEPT the last group when it has no data rows;
    //   - every other row (notes, substation headings, moves) is a data row; rows above the first heading form a group.
    // Must run AFTER TlsRowRules / TfmsRowRules: blank rows are created already "coloured" (empty and white).
    public static class CardRowSpacer
    {
        // TLS step heading = the navy rows (Alarms, Switching Operations, ...): JobClass 0 AND CircuitClass -99
        // (TLSJob_ASE.SetMoveColors). Other JobClass 0 rows are notes = data rows.
        public static bool IsTlsStepHeading(TlsJob j)
        {
            return j.JobClass == 0 && j.CircuitClass == -99;
        }

        // TOMS step heading = De-Energize, Disconnects, Work Permits, Test, EN - DE - EN ...:
        // JobClass 0 AND (blue text like FMS, or MoveCategory StepHeading / EN-DE-EN).
        // Substation headings (coloured bands) and FIELD WORK are sub-headings inside a group = data rows.
        public static bool IsTfmsStepHeading(TfmsJob j)
        {
            return j.JobClass == 0 &&
                   (j.MoveFGColor == Constants.CC_BLUE ||
                    j.MoveCategory == Constants.MoveCategory_StepHeading ||
                    j.MoveCategory == Constants.MoveCategory_EnDeEn);
        }

        public static List<TlsJob> AddBlankRows(IEnumerable<TlsJob> jobs, int lines)
        {
            return AddBlankRows(jobs, lines, IsTlsStepHeading, BlankTls);
        }

        public static List<TfmsJob> AddBlankRows(IEnumerable<TfmsJob> jobs, int lines)
        {
            return AddBlankRows(jobs, lines, IsTfmsStepHeading, BlankTfms);
        }

        public static List<T> AddBlankRows<T>(IEnumerable<T> rows, int lines, Func<T, bool> isStepHeading, Func<T> makeBlank)
        {
            if (lines < 0) lines = 0;
            if (lines > GroupSpacer.MaxLines) lines = GroupSpacer.MaxLines;

            var result = new List<T>();
            if (rows == null) return result;
            bool lastGroupHasData = false;

            foreach (var r in rows)
            {
                if (isStepHeading(r))
                {
                    // A new heading closes the previous group (if there is one)
                    if (result.Count > 0) AddBlanks(result, lines, makeBlank);
                    lastGroupHasData = false;
                }
                else
                {
                    lastGroupHasData = true;
                }
                result.Add(r);
            }

            // Close the last group only if it has at least one data row
            if (lastGroupHasData) AddBlanks(result, lines, makeBlank);
            return result;
        }

        private static void AddBlanks<T>(List<T> list, int lines, Func<T> makeBlank)
        {
            for (int i = 0; i < lines; i++)
                list.Add(makeBlank());
        }

        // An empty grid row: all cells blank and white, normal (not bold) Move cell.
        public static TlsJob BlankTls()
        {
            string w = DosColors.KeyCellBg;
            var j = new TlsJob
            {
                IsBlankRow = true, IsHeading = false,
                TOIssuedText = "", TOCompleteText = "", RSIssuedText = "", RSCompleteText = "",
                TOIssuedBgKey = w, TOCompleteBgKey = w, RSIssuedBgKey = w, RSCompleteBgKey = w,
                StationText = "", CircuitText = "", MoveText = "", MoveFgKey = DosColors.KeyText, MoveBgKey = w,
                ResultsText = "", StatusText = ""
            };
            TlsRowRules.Resolve(j);
            return j;
        }

        public static TfmsJob BlankTfms()
        {
            string w = DosColors.KeyCellBg, t = DosColors.KeyText;
            var j = new TfmsJob
            {
                IsBlankRow = true, IsHeading = false, MoveBold = false,
                TOIssuedText = "", TOCompleteText = "", RSIssuedText = "", RSCompleteText = "",
                TOIssuedBgKey = w, TOCompleteBgKey = w, RSIssuedBgKey = w, RSCompleteBgKey = w,
                TypeText = "", EquipText = "", EquipFgKey = t, GText = "", GFgKey = t,
                MoveText = "", MoveFgKey = t, MoveBgKey = w, OriginText = "", OriginBgKey = w, ResponseText = ""
            };
            TfmsRowRules.Resolve(j);
            return j;
        }
    }
}
```

#### `FMS_PDFReportService.Models\FMS_PDFReportService.Models.csproj`

**Action:** REPLACE (full file)  
**Type of change:** Project file — 5 `<Compile Include>` lines for the new .cs files.  
**Shared:** same file as in TOMS_Fix.md  
**Lines:** +5 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -85,6 +85,10 @@
     <Compile Include="Jobs\Colors\GroupSpacer.cs" />
     <Compile Include="Jobs\Colors\PhaseCheckEquipRow.cs" />
     <Compile Include="Jobs\Colors\PhaseCheckRules.cs" />
+    <Compile Include="Jobs\Colors\DosColors.cs" />
+    <Compile Include="Jobs\Colors\TlsRowRules.cs" />
+    <Compile Include="Jobs\Colors\TfmsRowRules.cs" />
+    <Compile Include="Jobs\Colors\CardRowSpacer.cs" />
     <Compile Include="Jobs\LocationTags\LocationTagFeederCard.cs" />
     <Compile Include="Jobs\PhaseChecks\PhaseCheckFeederCard.cs" />
     <Compile Include="Jobs\Protection\ProtectionLinkFeederCard.cs" />
@@ -101,6 +105,7 @@
     <Compile Include="Cards\TfmsCardModels.cs" />
     <Compile Include="Cards\SlcCardModels.cs" />
     <Compile Include="Cards\TlsCardModels.cs" />
+    <Compile Include="Cards\TomsPermitRow.cs" />
     <Compile Include="Cards\DsoCardModels.cs" />
     <Compile Include="Cards\SteamCardModels.cs" />
     <Compile Include="Jobs\FmsJob.cs" />
```

#### `FMS_PDFReportService.Data\Queries\TLSQueries.cs`

**Action:** REPLACE (full file)  
**Type of change:** SQL — 4 new queries: `LoadFeeders`, `LoadStations`, `LoadFeederStationNamesArchive`, `FindCoopPending`. Existing queries unchanged.  
**Lines:** +44 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -34,6 +34,50 @@
             SELECT Note AS CardNote
             FROM   TC_CardNote
             WHERE  Card = ?";
+
+        // TLSCard_ASE.LoadFeedersAndStations (cac.dmt), active card. Parameter: the card's Circuit.
+        // No ORDER BY, same as OpenROAD.
+        public static readonly string LoadFeeders = @"
+            SELECT SQUEEZE(O.Name) AS Name,
+                   O.Object AS Object
+            FROM   Udb_Object O,
+                   Udb_Grouping G
+            WHERE  G.Grouping = O.Object
+            AND    G.GroupingType IN ( SELECT Type
+                                       FROM   Udb_ExtendedType
+                                       WHERE  Supertype IN (" + FMS_PDFReportService.Models.Constants.Type_Feeder + ", "
+                                                              + FMS_PDFReportService.Models.Constants.Type_Network + ", "
+                                                              + FMS_PDFReportService.Models.Constants.Type_Line + ", "
+                                                              + FMS_PDFReportService.Models.Constants.Type_DivisionWorkstation + @") )
+            AND    G.Relationship = " + FMS_PDFReportService.Models.Constants.Interaction_MemberOf + @"
+            AND    G.Member = ?";
+
+        public static readonly string LoadStations = @"
+            SELECT O.Name AS Name,
+                   O.Object AS Object
+            FROM   Udb_Object O,
+                   Udb_Grouping G
+            WHERE  G.Grouping = O.Object
+            AND    G.GroupingType IN ( SELECT Type
+                                       FROM   Udb_ExtendedType
+                                       WHERE  Supertype IN (" + FMS_PDFReportService.Models.Constants.Type_Substation + ", "
+                                                              + FMS_PDFReportService.Models.Constants.Type_TelCircuitTerminal + @") )
+            AND    G.Relationship = " + FMS_PDFReportService.Models.Constants.Interaction_MemberOf + @"
+            AND    G.Member = ?";
+
+        // Archive card: names are stored on the card (TLSCard_ASE.LoadFeedersAndStations ELSE branch).
+        public const string LoadFeederStationNamesArchive = @"
+            SELECT FeederNames, SubstationNames
+            FROM   TC_ArchiveCard
+            WHERE  Card = ?";
+
+        // TLSJob_ASE.SetMoveColors "Highlight move if Co-Op test is PENDING ticketnumber". Parameter: Job.
+        // Any row returned = pending (OpenROAD: SELECT :m = 1 ... ; IF m = 1).
+        public static readonly string FindCoopPending = @"
+            SELECT PermitJobID
+            FROM   TC_WorkPermit
+            WHERE  PermitJobID = ? AND
+                   VendorTicketNumber = '" + FMS_PDFReportService.Models.Constants.Pending_TicketNumber + "'";
 
         public const string LoadJobs = @"
             SELECT Job, Card, Status, Seq, JobClass, JobClassSeq,
```

#### `FMS_PDFReportService.Data\Repositories\ITLSCardRepository.cs`

**Action:** REPLACE (full file)  
**Type of change:** Interface — 1 new method signature `LoadCoopPendingJobs`.  
**Lines:** +1 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -8,6 +8,7 @@
     {
         TlsCardHeader LoadCardHeader(int cardId, int archiveFlag);
         IEnumerable<TlsJob> LoadJobs(int cardId, int archiveFlag);
+        HashSet<int> LoadCoopPendingJobs(IEnumerable<TlsJob> jobs);
         IEnumerable<TlsLineOOS> LoadLineOOS(string divisions, int status);
         IEnumerable<TlsCircuitChange> LoadCircuitChanges(string divisions, string startDate, string endDate);
         IEnumerable<TlsRevisionLogEntry> LoadRevisionLog(string divisions, string startDate, string endDate);
```

#### `FMS_PDFReportService.Data\Repositories\TLSCardRepository.cs`

**Action:** REPLACE (full file)  
**Type of change:** Repository — `LoadCardHeader` changed (now loads Feeders/Stations); 1 new method `LoadCoopPendingJobs`.  
**Lines:** +39 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -28,8 +28,47 @@
                 var note = conn.QueryFirstOrDefault<string>(TLSQueries.LoadCardNote, new { p1 = cardId });
                 header.CardNote = note;
 
+                // Feeders / Stations ("Fdrs / Nwks:" and "Stations:"), TLSCard_ASE.LoadFeedersAndStations.
+                if (archiveFlag == 1)
+                {
+                    var names = conn.QueryFirstOrDefault<TlsCardHeader>(TLSQueries.LoadFeederStationNamesArchive, new { p1 = cardId });
+                    header.FeederNames = names?.FeederNames;
+                    header.SubstationNames = names?.SubstationNames;
+                    header.Feeders = TlsCardHeader.SplitNames(header.FeederNames).ConvertAll(n => new TlsFeeder { Name = n });
+                    header.Stations = TlsCardHeader.SplitNames(header.SubstationNames).ConvertAll(n => new TlsStation { Name = n });
+                }
+                else
+                {
+                    header.Feeders = conn.Query<TlsFeeder>(TLSQueries.LoadFeeders, new { p1 = header.Circuit }).ToList();
+                    header.Stations = conn.Query<TlsStation>(TLSQueries.LoadStations, new { p1 = header.Circuit }).ToList();
+                }
+
                 return header;
             }
+        }
+
+        // Jobs on the card whose Co-Op test ticket is still PENDING (TLSJob_ASE.SetMoveColors).
+        // Same per-job check as OpenROAD, run only for MoveType = COOP rows.
+        public HashSet<int> LoadCoopPendingJobs(IEnumerable<TlsJob> jobs)
+        {
+            var result = new HashSet<int>();
+            if (jobs == null) return result;
+            var coopJobs = jobs
+                .Where(j => string.Equals((j.MoveType ?? string.Empty).Trim(), FMS_PDFReportService.Models.Constants.MoveType_COOP, System.StringComparison.Ordinal))
+                .Select(j => j.Job)
+                .Distinct()
+                .ToList();
+            if (coopJobs.Count == 0) return result;
+
+            using (var conn = _connectionFactory.GetConnection())
+            {
+                foreach (var job in coopJobs)
+                {
+                    if (conn.Query<int>(TLSQueries.FindCoopPending, new { p1 = job }).Any())
+                        result.Add(job);
+                }
+            }
+            return result;
         }
 
         public IEnumerable<TlsJob> LoadJobs(int cardId, int archiveFlag)
```

#### `FMS_PDFReportService.Engine\Rendering\TelerikReportRenderer.cs`

**Action:** REPLACE (full file)  
**Type of change:** Renderer — 1 new public method `PrependHeaderAtCardStart` (company logo + card title at the start of each card, identity line on the card's other pages; works with continuous page numbers). Existing methods unchanged.  
**Shared:** used by TLS and TOMS (same file as in TOMS_Fix.md)  
**Lines:** +61 / -0 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -180,6 +180,67 @@
             }
         }
 
+        // TLS / TOMS cards. Page numbers run on over the whole ReportBook, so "PageNumber = 1" only means
+        // "first page of the whole PDF". Instead this relies on PageHeaderSection.PrintOnFirstPage = False,
+        // which Telerik applies to the first page of EACH report (= each card):
+        //   first page of a card : company header + the template's report header (card title + card box)
+        //   other pages of a card: company header + the template's page header (card identity line)
+        // So the company header is put in BOTH the report header and the page header, and the page header
+        // keeps PrintOnFirstPage = False. Reports whose page header prints on the first page (log, permits)
+        // get exactly the old PrependHeader behaviour.
+        public void PrependHeaderAtCardStart(IEnumerable<ReportSource> sources, string headerTemplatePath)
+        {
+            foreach (var source in sources)
+            {
+                if (!(source is InstanceReportSource instance) || !(instance.ReportDocument is Telerik.Reporting.Report report))
+                    continue;
+
+                var pageHeader = report.Items.OfType<Telerik.Reporting.PageHeaderSection>().FirstOrDefault();
+                var reportHeader = report.Items.OfType<Telerik.Reporting.ReportHeaderSection>().FirstOrDefault();
+                if (pageHeader == null || pageHeader.PrintOnFirstPage || reportHeader == null)
+                {
+                    PrependHeader(new[] { source }, headerTemplatePath);
+                    continue;
+                }
+
+                var width = report.Width;
+
+                // Same margin rule as PrependHeader.
+                var margins = report.PageSettings.Margins;
+                var maxTop = Telerik.Reporting.Drawing.Unit.Inch(0.25);
+                if (margins.Top > maxTop)
+                    report.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(margins.Left, margins.Right, maxTop, margins.Bottom);
+
+                // Pages 2+ of the card: company header above the card identity line. PrintOnFirstPage stays False.
+                var forPageHeader = DeserializeReport(headerTemplatePath).Items.OfType<Telerik.Reporting.DetailSection>().First();
+                var pageHeight = forPageHeader.Height;
+                foreach (var item in pageHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
+                    item.Top = item.Top + pageHeight;
+                pageHeader.Height = pageHeader.Height + pageHeight;
+                foreach (var item in forPageHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
+                {
+                    if (item.Left + item.Width > width)
+                        item.Width = width - item.Left;
+                    forPageHeader.Items.Remove(item);
+                    pageHeader.Items.Add(item);
+                }
+
+                // First page of the card: company header above the card title and card box (own copy of the items).
+                var forReportHeader = DeserializeReport(headerTemplatePath).Items.OfType<Telerik.Reporting.DetailSection>().First();
+                var reportHeight = forReportHeader.Height;
+                foreach (var item in reportHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
+                    item.Top = item.Top + reportHeight;
+                reportHeader.Height = reportHeader.Height + reportHeight;
+                foreach (var item in forReportHeader.Items.OfType<Telerik.Reporting.ReportItem>().ToList())
+                {
+                    if (item.Left + item.Width > width)
+                        item.Width = width - item.Left;
+                    forReportHeader.Items.Remove(item);
+                    reportHeader.Items.Add(item);
+                }
+            }
+        }
+
         private static IEnumerable<Telerik.Reporting.SubReport> CollectSubReports(Telerik.Reporting.Report report)
         {
             foreach (var section in report.Items)
```

#### `FMS_PDFReportService.Engine\Groupers\ReportGroupers.cs`

**Action:** REPLACE (full file)  
**Type of change:** Grouper — `TLSGrouper.ComposeCard` rewritten (one template, rows coloured, spare blank rows via `CardRowSpacer` like FMS `GroupSpacer`, header as parameters, logo via `PrependHeaderAtCardStart`); 1 new private method `BuildHeaderParameters`. Only the TLS part is shown here.  
**Shared:** the same file also contains the TOMS change (TOMS_Fix.md); copy the file once  
**Lines:** +35 / -8 (diff below: `-` = removed from your file, `+` = added; other lines are unchanged context)

```diff
@@ -239,15 +288,42 @@
         public List<ReportSource> ComposeCard(int cardId, ReportRequest request)
         {
             // TLS ALWAYS generates card-only regardless of ReportType (BR-RPT-029)
-            var sources = new List<ReportSource>();
-
-            sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TLS/TLSCardHeader.trdx"),
-                _repo.LoadCardHeader(cardId, request.ArchiveFlag)));
+            // Same layout as the DOS TLS card: TLSCard.trdx = card header + job grid (like FeederCard.trdx).
+            var header = _repo.LoadCardHeader(cardId, request.ArchiveFlag);
+            var jobs = _repo.LoadJobs(cardId, request.ArchiveFlag).ToList();
+            TlsRowRules.Apply(jobs, header?.Status ?? 0, _repo.LoadCoopPendingJobs(jobs));
+            jobs = CardRowSpacer.AddBlankRows(jobs, request.SpareLines);   // same as FMS GroupSpacer; keep after the colour rules
+
+            var sources = new List<ReportSource>();
             sources.Add(_renderer.CreateReportSource(_templatePath.Resolve("TLS/TLSCard.trdx"),
-                _repo.LoadJobs(cardId, request.ArchiveFlag)));
-
-            _renderer.PrependHeader(sources, _templatePath.Resolve("Common/PageHeader.trdx"));
-            return sources;
+                jobs, BuildHeaderParameters(header)));
+
+            // Company header + card title at the start of each card, identity line on its other pages.
+            _renderer.PrependHeaderAtCardStart(sources, _templatePath.Resolve("Common/PageHeader.trdx"));
+            return sources;
+        }
+
+        // All header values are passed as display strings (formatting tested in C#, not in the .trdx).
+        private static Dictionary<string, object> BuildHeaderParameters(TlsCardHeader header)
+        {
+            if (header == null)
+                return new Dictionary<string, object>();
+
+            return new Dictionary<string, object>
+            {
+                { "Linenumber", header.Linenumber ?? string.Empty },
+                { "LineTypeName", header.LineTypeName ?? string.Empty },
+                { "RouteName", header.RouteName ?? string.Empty },
+                { "CarrierName", header.CarrierName ?? string.Empty },
+                { "CardTypeName", header.CardTypeName },
+                { "FeedersText", header.FeedersText },
+                { "StationsText", header.StationsText },
+                { "ClosedLabel", TFMSGrouper.ClosedLabel(header.Closed) },
+                { "ClosedText", TFMSGrouper.HeaderDate(header.Closed) },
+                { "CardNote", header.CardNote ?? string.Empty },
+                { "CircuitNote", header.Notes ?? string.Empty },
+                { "ReasonForFailure", header.ReasonForFailure ?? string.Empty }
+            };
         }
     }
 
```

<!-- CSHARP-CHANGES END -->

## 4. Tests run

Run: `PROJ=<Telerik-proj> bash Tests/runtests.sh` → `PASSED 1412 FAILED 0`. Then `PROJ=<Telerik-proj> python Tests/mutate.py` → `24/24 mutations caught`.

| Pass | What | Result |
|---|---|---|
| 1 — build + template integrity | Changed code compiles (`Models` 58 files, `Data` 55, groupers and renderer vs. Telerik stubs). Every `Fields.X` exists on `TlsJob`; every parameter declared and used; non-colour parameters sent by the grouper, colour parameters **not** sent; grid tiles 0 → 10.69in; header boxes line up; Op blank; landscape/margins; continuous page numbers; title; spare rows (group ends, empty groups, LINE 0 / 99→10 / −3→0) | pass |
| 2 — rules | Rows rebuilt from tls-dos.pdf page 1: all 13 data rows × 4 date cells match the benchmark's gray/white pattern; no `12/31 23:59`; headings navy, empty, white; `Xfr`→T; COOP pending / not pending; transferred-on-closed branch; null safety; header texts; grouper with fake repository incl. null header | pass |
| 3 — colour parameters | Template defaults = `DosColors.TlsPalette` both ways (5). Generated rows (heading/job × CircuitClass × COOP × closed/transferred) + benchmark + blank rows: every key has a parameter, the hex equals the palette, and the template shows the same colour as the rules. Editing `ColorStepHeading` recolours step headings | pass |
| 4 — visual | Emulator draws `TLSCard.trdx` with the C# rows. **Previous template vs this template, default values: pixel-identical.** `Evidence\TLS_simulated_card_96DHZA425413.png` vs `TLS_benchmark_p1.png`: 18 gray cells and 5 navy headings in the benchmark's positions | match |
| Guardrail | 24 deliberate faults (shared with TOMS), incl. TLS gray removed, gray on real dates, grid gap, page numbering, title, identity line, **TLS gray-out default changed to white** | **24/24 caught** |

Total (shared with TOMS): 1412 checks, 0 failures.

## 5. What I could NOT verify — be aware

1. **No Telerik runtime here.** The template was validated by tests and the emulator, not rendered by Telerik. The colour expressions use the same `IIf(..., Parameters.X.Value, ...)` form as `FeederCard1.trdx`. **Render once before release.**
2. **No database.** The 4 TLS SQL statements were checked against OpenROAD and statically, not executed. `SQUEEZE()` is an Ingres function, as in the OpenROAD query.
3. Leading spaces in headings: Telerik kept them in the old TOMS output; not seen with the new template yet.
4. The empty-date test is `FmsColorCalculator.IsBlank` (month 12, day 31, 23:59). A real time of 31-Dec 23:59 would also be treated as "not applicable", the same limitation as the FMS report.
5. In a ReportBook, `PrintOnFirstPage="False"` must hide the page header on the first page of *each* card. Confirm with **2-3 cards in one PDF**.

## 6. Open items for the SME

1. **Transferred moves on closed cards.** OpenROAD compares the TC card status (1-4) with `Card$Closed` (= 50), so this branch never fires in production. Ported exactly. If the intent was status 4 (CLOSED), change `Constants.Card_Closed` to `Constants.TC_Card_Closed` in `TlsRowRules`, only after confirming.
2. **Co-Op pending pale red**: from OpenROAD; no Co-Op row in the benchmark. Kept because hiding a pending Co-Op test is the riskier choice.
3. Feeders/Stations order: OpenROAD has no `ORDER BY`, so neither do we.
4. **Colour parameters are editable by anyone who can save the template.** Restrict write access to the deployed `.trdx` and get operations approval for the safety colours (2.2).
5. **Where the rules come from:** the DOS report program (called by PrintReport.ps1) is not in the provided files. Rules come from OpenROAD `TLSJob_ASE` and the web screen, checked against tls-dos.pdf. Confirmed by the benchmark: empty-date gray, navy headings, blank Op. Not confirmed: Co-Op pale red, `T` in the status column.

## 7. How to test with real data (UAT)

1. Print **96DHZA425413, 96PRNA410029, 96PRNA410945** and compare page by page with `tls-dos.pdf`:
   - gray cells exactly where the benchmark has them; no `12/31 23:59`;
   - Op columns blank; status column only `T`;
   - header: Route, Carrier, Type of Work, Fdrs / Nwks (e.g. `38M22, 38M23, 38M24, 38M25, 38M26`), Stations, Note, Circuit Note;
   - each card's first page: logo, "Telephone Line Feeder Card for <line>", card box; other pages: logo, line number, column header; page numbers run 1..N over the whole PDF;
   - with `LINE=2` there are 2 empty rows after Alarms, Switching Operations, In-Service Work Permits, Work Permits and Notifications/Access; with `LINE=0` none.
2. Print one **archived** card (ARCH=1): Fdrs / Nwks and Stations come from the stored names.
3. **Colour parameter check:** open `TLSCard.trdx` in the Report Designer, set `ColorStepHeading` to `#FF00FF`, save, print a card → only the step headings change. Set it back to `#000080`.
4. `PROJ=<Telerik-proj> bash Tests/runtests.sh` → `PASSED 1412 FAILED 0`.
