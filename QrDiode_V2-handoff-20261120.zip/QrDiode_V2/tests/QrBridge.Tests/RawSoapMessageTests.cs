using System.Text;
using QrBridge.Shared.Envelope;

namespace QrBridge.Tests;

public class RawSoapMessageTests
{
    private static RawSoapMessage Sample(byte[]? body = null) => new()
    {
        Service = "FC2FMS",
        Operation = "SendToFMS",
        Path = "/FMS_FC2FMSInterface/FC2FMSInterface.svc",
        SoapActionHeader = "\"http://tempuri.org/IFC2FMSInterface/SendToFMS\"",
        ContentType = "text/xml; charset=utf-8",
        BusinessType = "REQUEST_FOR_PERMIT",
        Body = body ?? Encoding.UTF8.GetBytes("<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"><s:Body/></s:Envelope>"),
    };

    [Fact]
    public void Round_trips_every_field_and_the_exact_body()
    {
        var original = Sample();
        var back = RawSoapMessage.FromBytes(original.ToBytes(), maxBodyBytes: 1_000_000);

        Assert.Equal(original.Service, back.Service);
        Assert.Equal(original.Operation, back.Operation);
        Assert.Equal(original.Path, back.Path);
        Assert.Equal(original.SoapActionHeader, back.SoapActionHeader);
        Assert.Equal(original.ContentType, back.ContentType);
        Assert.Equal(original.BusinessType, back.BusinessType);
        Assert.Equal(original.Body, back.Body);
    }

    [Fact]
    public void Null_optional_fields_stay_null()
    {
        var original = Sample() with { SoapActionHeader = null, BusinessType = null };
        var back = RawSoapMessage.FromBytes(original.ToBytes(), 1_000_000);
        Assert.Null(back.SoapActionHeader);
        Assert.Null(back.BusinessType);
    }

    [Fact]
    public void Body_bytes_are_not_reinterpreted()
    {
        // Not UTF-8, not XML: must still come back byte for byte.
        byte[] body = [0xFF, 0x00, 0xFE, 0x3C, 0x41];
        Assert.Equal(body, RawSoapMessage.FromBytes(Sample(body).ToBytes(), 1_000_000).Body);
    }

    [Fact]
    public void Body_over_the_limit_is_refused()
    {
        byte[] bytes = Sample(new byte[100]).ToBytes();
        Assert.Throws<InvalidDataException>(() => RawSoapMessage.FromBytes(bytes, maxBodyBytes: 99));
    }

    [Fact]
    public void Truncated_or_foreign_bytes_are_refused()
    {
        byte[] bytes = Sample().ToBytes();
        Assert.Throws<InvalidDataException>(() => RawSoapMessage.FromBytes(bytes[..^5], 1_000_000));
        Assert.Throws<InvalidDataException>(() => RawSoapMessage.FromBytes([1, 2, 3, 4, 5, 6], 1_000_000));
        Assert.Throws<InvalidDataException>(() => RawSoapMessage.FromBytes([.. bytes, 0], 1_000_000));
    }
}
