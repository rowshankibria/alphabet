using System.Security.Cryptography;
using QrBridge.Shared;
using QrBridge.Shared.Envelope;
using QrBridge.Shared.Security;

namespace QrBridge.Tests;

public class EnvelopeTests
{
    private static readonly byte[] KeyA = RandomNumberGenerator.GetBytes(32);
    private static readonly byte[] KeyB = RandomNumberGenerator.GetBytes(32);

    private static EnvelopeCodec Codec(byte[]? key = null, int max = 1_000_000) =>
        new(new InMemoryKeyProvider().Add("k1", key ?? KeyA), max);

    private static EnvelopeHeader Header(string keyId = "k1") => new()
    {
        MessageId = Guid.NewGuid(),
        CorrelationId = Guid.NewGuid(),
        MessageType = MessageType.Request,
        Direction = Direction.CorpToDmz,
        ServiceName = "FC2FMS",
        Operation = "SendToFMS",
        BusinessType = "REQUEST_FOR_PERMIT",
        PayloadFormat = PayloadFormat.RawSoap,
        Sequence = 42,
        CreatedUtc = new DateTime(2026, 11, 19, 12, 0, 0, DateTimeKind.Utc),
        KeyId = keyId,
    };

    [Fact]
    public void Seal_then_open_round_trips_header_and_payload()
    {
        var codec = Codec();
        var header = Header();
        byte[] payload = "hello bridge"u8.ToArray();

        var (opened, plain) = codec.Open(codec.Seal(header, payload));

        Assert.Equal(header, opened);
        Assert.Equal(payload, plain);
    }

    [Fact]
    public void Empty_business_type_round_trips()
    {
        var codec = Codec();
        var header = Header() with { BusinessType = "" };
        var (opened, _) = codec.Open(codec.Seal(header, [1]));
        Assert.Equal("", opened.BusinessType);
    }

    [Fact]
    public void Peek_reads_header_without_key()
    {
        var header = Header();
        byte[] envelope = Codec().Seal(header, [1, 2, 3]);
        Assert.Equal(header, EnvelopeCodec.PeekHeader(envelope));
    }

    [Fact]
    public void Payload_is_not_readable_in_envelope()
    {
        byte[] payload = "TOP-SECRET-FEEDER-10W85"u8.ToArray();
        byte[] envelope = Codec().Seal(Header(), payload);
        Assert.False(envelope.AsSpan().IndexOf(payload) >= 0);
    }

    [Fact]
    public void Tampered_header_fails_authentication()
    {
        var codec = Codec();
        byte[] envelope = codec.Seal(Header(), [1, 2, 3]);
        int seqOffset = 4 + 4 + 5 + 16 + 16; // magic, headerLen, 5 single bytes, two guids -> Sequence
        envelope[seqOffset] ^= 0x01;
        Assert.Throws<CryptographicException>(() => codec.Open(envelope));
    }

    [Fact]
    public void Tampered_ciphertext_fails_authentication()
    {
        var codec = Codec();
        byte[] envelope = codec.Seal(Header(), new byte[100]);
        envelope[^1] ^= 0x01;
        Assert.Throws<CryptographicException>(() => codec.Open(envelope));
    }

    [Fact]
    public void Wrong_key_fails()
    {
        byte[] envelope = Codec(KeyA).Seal(Header(), [1, 2, 3]);
        Assert.Throws<CryptographicException>(() => Codec(KeyB).Open(envelope));
    }

    [Fact]
    public void Unknown_key_id_fails_as_crypto_error()
    {
        byte[] envelope = Codec().Seal(Header(), [1]);
        var other = new EnvelopeCodec(new InMemoryKeyProvider().Add("other", KeyA));
        Assert.Throws<CryptographicException>(() => other.Open(envelope));
    }

    [Fact]
    public void Truncated_envelope_is_rejected()
    {
        byte[] envelope = Codec().Seal(Header(), new byte[50]);
        Assert.ThrowsAny<Exception>(() => Codec().Open(envelope[..^10]));
    }

    [Fact]
    public void Oversized_payload_is_refused()
    {
        Assert.Throws<ArgumentException>(() => Codec(max: 10).Seal(Header(), new byte[11]));
    }

    [Fact]
    public void Decompression_bomb_is_stopped()
    {
        // 5 MB of zeros compresses to almost nothing; the opener's limit is 1 MB.
        var big = Codec(max: 10_000_000).Seal(Header(), new byte[5_000_000]);
        Assert.Throws<InvalidDataException>(() => Codec(max: 1_000_000).Open(big));
    }

    [Fact]
    public void Compression_makes_soap_much_smaller()
    {
        string xml = string.Concat(Enumerable.Repeat("<MOVE><FMS_MOVE_ID>11467104</FMS_MOVE_ID><MOVE_STATUS>COMPLETE</MOVE_STATUS></MOVE>", 200));
        byte[] payload = System.Text.Encoding.UTF8.GetBytes(xml);
        byte[] envelope = Codec().Seal(Header(), payload);
        Assert.True(envelope.Length < payload.Length / 5, $"{envelope.Length} vs {payload.Length}");
    }
}
