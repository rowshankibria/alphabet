using System.Text;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Stores;
using QrBridge.Shared.Envelope;
using QrBridge.Shared.Signals;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Corp gateway -> (the QR link, simulated by copying the sealed envelope) -> DMZ gateway -> real service.
/// The QR apps move exactly these envelope bytes; everything else here is the real code.
/// </summary>
public sealed class EndToEndTests : IAsyncLifetime
{
    private readonly string _root = GatewayHost.NewRoot();
    private FakeSoapService _realService = null!;
    private GatewayHost _corp = null!;
    private GatewayHost _dmz = null!;
    private HttpClient _corpClient = null!;

    public async Task InitializeAsync()
    {
        _realService = await FakeSoapService.StartAsync();
        _corp = GatewayHost.Start(BridgeSide.Corp, _root);
        _dmz = GatewayHost.Start(BridgeSide.Dmz, _root, egressHandler: _realService.CreateHandler);
        _corpClient = _corp.CreateClient();
    }

    public async Task DisposeAsync()
    {
        _corpClient.Dispose();
        await _corp.DisposeAsync();
        await _dmz.DisposeAsync();
        await _realService.DisposeAsync();
        GatewayHost.DeleteRoot(_root);
    }

    private async Task<(Guid MessageId, byte[] Request)> CallCorpAsync(string sample)
    {
        byte[] request = SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample(sample));
        var (response, reply) = await SoapCalls.PostAsync(_corpClient, FmsEndpoint.FC2FMS, "SendToFMS", request);
        Assert.Equal(0, SoapCalls.ReturnCode(SoapCalls.Result(reply)));
        return (Guid.Parse(response.Headers.GetValues(IngressEndpoint.MessageIdHeader).Single()), request);
    }

    /// <summary>What the QR sender + receiver do: carry the sealed envelope, unchanged, into the other side's Inbox.</summary>
    private static async Task CarryAcrossAsync(GatewayHost from, GatewayHost to, Guid messageId)
    {
        var row = await from.Get<OutboxStore>().FindAsync(messageId, CancellationToken.None);
        var header = EnvelopeCodec.PeekHeader(row!.Envelope);
        Assert.True(await to.Get<InboxStore>().AddMessageAsync(header, row.Envelope, chunkCount: 1, CancellationToken.None));
        to.Get<BridgeSignals>().Inbox.Set();
    }

    private static async Task<InboxMessage> WaitForAsync(GatewayHost host, Guid messageId, Func<InboxMessage, bool> condition)
    {
        var inbox = host.Get<InboxStore>();
        var deadline = DateTime.UtcNow.AddSeconds(20);
        while (true)
        {
            var row = await inbox.FindAsync(messageId, CancellationToken.None);
            if (row is not null && condition(row)) return row;
            if (DateTime.UtcNow > deadline)
                throw new TimeoutException($"Inbox row {messageId} never reached the expected state (last: {row?.Status} {row?.LastError}).");
            await Task.Delay(100);
        }
    }

    [Fact]
    public async Task A_call_to_the_corp_gateway_reaches_the_real_service_byte_for_byte()
    {
        var (messageId, request) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        await CarryAcrossAsync(_corp, _dmz, messageId);

        var row = await WaitForAsync(_dmz, messageId, r => r.Status == InboxStatus.Done);
        Assert.Equal("RETURN_CODE=0", row.DownstreamResult);
        Assert.Equal("REQUEST_FOR_PERMIT", row.BusinessType);

        var received = Assert.Single(_realService.Requests);
        Assert.Equal(FmsEndpoint.FC2FMS.Path, received.Path);                              // same path as on the load balancer
        Assert.Equal("\"http://tempuri.org/IFC2FMSInterface/SendToFMS\"", received.SoapAction); // same SOAPAction
        Assert.StartsWith("text/xml", received.ContentType);
        Assert.Equal(request, received.Body);                                               // identical bytes
    }

    [Fact]
    public async Task A_refusal_from_the_real_service_is_dead_lettered_with_its_reason()
    {
        _realService.Responder = _ => (200, FakeSoapService.FmsReply("SendToFMS", 1501, "Card 129979 is not active"));
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        await CarryAcrossAsync(_corp, _dmz, messageId);

        var row = await WaitForAsync(_dmz, messageId, r => r.Status == InboxStatus.DeadLetter);
        Assert.Contains("1501", row.DownstreamResult);
        Assert.Contains("Card 129979 is not active", row.DownstreamResult);
        Assert.Single(_realService.Requests); // not retried
    }

    [Fact]
    public async Task An_unreachable_service_is_retried_until_it_accepts()
    {
        int calls = 0;
        _realService.Responder = _ => Interlocked.Increment(ref calls) == 1
            ? (503, "<html>Service Unavailable</html>")
            : (200, FakeSoapService.FmsReply("SendToFMS", 0));

        var (messageId, _) = await CallCorpAsync("LIFT_CAUTION.TXT");
        await CarryAcrossAsync(_corp, _dmz, messageId);

        var row = await WaitForAsync(_dmz, messageId, r => r.Status == InboxStatus.Done);
        Assert.Equal(2, row.Attempts);
        Assert.Equal(2, _realService.Requests.Count);
    }

    [Fact]
    public async Task A_message_carried_to_the_wrong_side_is_rejected_not_delivered()
    {
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        await CarryAcrossAsync(_corp, _corp, messageId); // Corp -> Corp: wrong direction

        var row = await WaitForAsync(_corp, messageId, r => r.Status == InboxStatus.Rejected);
        Assert.Contains("direction", row.LastError, StringComparison.OrdinalIgnoreCase);
        Assert.Empty(_realService.Requests);
    }

    [Fact]
    public async Task A_tampered_envelope_is_rejected_not_delivered()
    {
        var (messageId, _) = await CallCorpAsync("REQUEST_FOR_PERMIT.txt");
        var row = await _corp.Get<OutboxStore>().FindAsync(messageId, CancellationToken.None);
        byte[] tampered = row!.Envelope.ToArray();
        tampered[^1] ^= 0x01;

        await _dmz.Get<InboxStore>().AddMessageAsync(EnvelopeCodec.PeekHeader(tampered), tampered, 1, CancellationToken.None);
        _dmz.Get<BridgeSignals>().Inbox.Set();

        var rejected = await WaitForAsync(_dmz, messageId, r => r.Status == InboxStatus.Rejected);
        Assert.Contains("authentication", rejected.LastError, StringComparison.OrdinalIgnoreCase);
        Assert.Empty(_realService.Requests);
        // The header label (REQUEST_FOR_PERMIT) is plain by design; the business content never is.
        Assert.DoesNotContain("Garrett Chang", Encoding.UTF8.GetString(tampered));
    }
}
