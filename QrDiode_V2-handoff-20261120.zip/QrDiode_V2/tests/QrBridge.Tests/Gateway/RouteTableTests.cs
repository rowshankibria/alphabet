using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;

namespace QrBridge.Tests.Gateway;

public class RouteTableTests
{
    private static RouteTable Table(RoutingOptions routing, BridgeSide side = BridgeSide.Corp) =>
        new(Options.Create(routing), Options.Create(new BridgeOptions { Side = side }));

    private static RoutingOptions Sample(bool acceptUnlisted = false) => new()
    {
        AcceptUnlisted = acceptUnlisted,
        ReplyProfiles = { ["Fms"] = new ReplyProfile { ResultKind = ResultKind.FmsResponse, Ok = "ok" } },
        Services =
        {
            new ServiceRoute
            {
                Name = "FC2FMS",
                Paths = { "/FMS_FC2FMSInterface/FC2FMSInterface.svc" },
                Operations =
                {
                    ["SendToFMS"] = new OperationRoute { Mode = OperationMode.Bridge, Reply = "Fms" },
                    ["GetFromFMS"] = new OperationRoute { Mode = OperationMode.Unavailable, Reply = "Fms" },
                },
            },
        },
    };

    /// <summary>The catalogue that ships with the gateway (copied next to the tests at build time).</summary>
    private static RoutingOptions ShippedCatalogue()
    {
        var config = new ConfigurationBuilder()
            .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "routes.json"), optional: false)
            .Build();
        return config.GetSection(RoutingOptions.SectionName).Get<RoutingOptions>()!;
    }

    [Theory]
    [InlineData(null, "/")]
    [InlineData("", "/")]
    [InlineData("/FMS_FC2FMSInterface/FC2FMSInterface.svc", "/FMS_FC2FMSInterface/FC2FMSInterface.svc")]
    [InlineData("/FMS_FC2FMSInterface//FC2FMSInterface.svc/", "/FMS_FC2FMSInterface/FC2FMSInterface.svc")]
    [InlineData("/x.svc?wsdl", "/x.svc")]
    public void Paths_are_normalized(string? input, string expected) => Assert.Equal(expected, RouteTable.NormalizePath(input));

    [Fact]
    public void Listed_operation_resolves_with_its_reply_profile()
    {
        var d = Table(Sample()).Resolve("/fms_fc2fmsinterface/FC2FMSINTERFACE.svc", "SendToFMS"); // case-insensitive path
        Assert.Equal(OperationMode.Bridge, d.Mode);
        Assert.Equal("FC2FMS", d.ServiceName);
        Assert.Equal("ok", d.Profile!.Ok);
    }

    [Fact]
    public void Unlisted_operation_on_a_listed_service_is_refused()
    {
        var d = Table(Sample()).Resolve("/FMS_FC2FMSInterface/FC2FMSInterface.svc", "DropTables");
        Assert.Equal(OperationMode.Reject, d.Mode);
        Assert.Contains("not bridged", d.Problem);
    }

    [Fact]
    public void Unlisted_path_is_refused_unless_explicitly_allowed()
    {
        Assert.Equal(OperationMode.Reject, Table(Sample()).Resolve("/Other/Service.svc", "DoWork").Mode);

        var open = Table(Sample(acceptUnlisted: true)).Resolve("/Other/Service.svc", "DoWork");
        Assert.Equal(OperationMode.Bridge, open.Mode);
        Assert.Equal("/Other/Service.svc", open.ServiceName);
        Assert.Null(open.Service);
    }

    [Fact]
    public void A_gateway_does_not_accept_services_whose_callers_are_on_the_other_side()
    {
        var d = Table(Sample(), BridgeSide.Dmz).Resolve("/FMS_FC2FMSInterface/FC2FMSInterface.svc", "SendToFMS");
        Assert.Equal(OperationMode.Reject, d.Mode);
    }

    [Fact]
    public void Invalid_catalogues_fail_at_startup()
    {
        var duplicate = Sample();
        duplicate.Services.Add(new ServiceRoute { Name = "Other", Paths = { "/FMS_FC2FMSInterface/FC2FMSInterface.svc" } });
        Assert.Throws<InvalidOperationException>(() => Table(duplicate));

        var badProfile = Sample();
        badProfile.Services[0].Operations["SendToFMS"].Reply = "Typo";
        Assert.Throws<InvalidOperationException>(() => Table(badProfile));
    }

    [Fact]
    public void Shipped_catalogue_is_valid_and_covers_the_fms_interfaces()
    {
        var table = Table(ShippedCatalogue());

        Assert.False(table.Options.AcceptUnlisted); // production default: allow-list
        foreach (var (path, operation) in new[]
                 {
                     ("/FMS_FC2FMSInterface/FC2FMSInterface.svc", "SendToFMS"),
                     ("/FMS_FOD2FMSInterface/FOD2FMSInterface.svc", "SendToFMS"),
                     ("/FMS_SSO2FMSInterface/SSO2FMSInterface.svc", "SendToFMS"),
                     ("/FMS_SSO2TOMSInterface/SSO2TOMSInterface.svc", "SendToTOMS"),
                     ("/FMS_SSO2TLSInterface/SSO2TLSInterface.svc", "SendToTLS"),
                     ("/FMS_SSO2DSOInterface/SSO2DSOInterface.svc", "SendToDSO"),
                     ("/FMS_FTC2FMSInterface/FTC2FMSInterface.svc", "SendToFMS"),
                     ("/VZ2TLSWebService/VZ2TLSInterface.asmx", "SendToTLS"),
                     ("/FMSInterface/RR_DSSFMSService.wsdl", "SendToFMS"),
                     ("/FMSInterface/RR_SSOFMSService.WSDL", "SendToFMS"),
                 })
        {
            Assert.Equal(OperationMode.Bridge, table.Resolve(path, operation).Mode);
        }

        // Queries cannot cross the air gap
        Assert.Equal(OperationMode.Unavailable, table.Resolve("/FMS_FC2FMSInterface/FC2FMSInterface.svc", "GetFromFMS").Mode);
        Assert.Equal(OperationMode.Unavailable, table.Resolve("/FMSWebService/ECC_XAFMSService.asmx", "ProcessMessage").Mode);
    }
}
