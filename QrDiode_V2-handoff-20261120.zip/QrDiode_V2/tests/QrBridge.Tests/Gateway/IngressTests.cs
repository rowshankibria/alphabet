using System.Net;
using System.Text;
using System.Xml.Linq;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data.Stores;
using QrBridge.Shared.Envelope;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

public sealed class CorpGatewayFixture : IAsyncLifetime
{
    private readonly string _root = GatewayHost.NewRoot();
    public GatewayHost Host { get; private set; } = null!;
    public HttpClient Client { get; private set; } = null!;

    public Task InitializeAsync()
    {
        Host = GatewayHost.Start(BridgeSide.Corp, _root);
        Client = Host.CreateClient();
        return Task.CompletedTask;
    }

    public async Task DisposeAsync()
    {
        Client.Dispose();
        await Host.DisposeAsync();
        GatewayHost.DeleteRoot(_root);
    }
}

/// <summary>
/// The Corp gateway, receiving exactly what the corporate apps send today. Every message template of the
/// fms-interface-simulator goes to its real interface, and must get the answer that caller expects.
/// </summary>
public sealed class IngressTests(CorpGatewayFixture fixture) : IClassFixture<CorpGatewayFixture>
{
    public enum Expect { Accepted, Unavailable, Refused, Fault, Echo }

    /// <param name="Numeric">The operation returns a number (ASMX long / SOAP Toolkit int), not an FMS &lt;RESPONSE&gt;.</param>
    public sealed record Case(FmsEndpoint Endpoint, string Operation, Expect Expect, bool Numeric = false, string? Parameter = null);

    private static readonly Dictionary<string, Case> Cases = new(StringComparer.OrdinalIgnoreCase)
    {
        // FCR -> FMS
        ["REQUEST_FOR_PERMIT.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.Accepted),
        ["RFP_FCR_RESPONSE.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.Accepted),
        ["WP_FCR_RESPONSE.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.Accepted),
        ["RETURN_PERMITS.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.Accepted),
        ["FIELD_GROUNDS_ONLY.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.Accepted),
        ["FGO_FCR_RESPONSE.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.Accepted),
        ["LIFT_CAUTION.TXT"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.Accepted),
        ["FAULT_RESPONSE.TXT"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.Accepted),
        ["WP_ETC_UPDATE.TXT"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.Accepted),
        ["FEEDER_ETC_UPDATE.TXT"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.Accepted),
        ["AUTHORIZE_USERS.txt"] = new(FmsEndpoint.FC2FMS, "GetFromFMS", Expect.Unavailable),
        ["GET_FEEDER_INFO.txt"] = new(FmsEndpoint.FC2FMS, "GetFromFMS", Expect.Unavailable),
        ["WITHDRAW_RFP.txt"] = new(FmsEndpoint.FC2FMS, "GetFromFMS", Expect.Unavailable),
        ["Echo_String.txt"] = new(FmsEndpoint.FC2FMS, "EchoString", Expect.Echo, Parameter: "sValue"),
        // FOD -> FMS
        ["FOD_MOVE_RESPONSE.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.Accepted),
        ["RETURN_MOVE.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.Accepted),
        ["RETURN_FAULT.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.Accepted),
        ["FOD_FAULT_RESPONSE.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.Accepted),
        ["RETURN_TAGS.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.Accepted),
        ["FOD_TAG_RESPONSE.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.Accepted),
        // DSS / No. 9 -> FMS (legacy SOAP Toolkit, RPC/encoded, int reply)
        ["NO9_MOVE_RESPONSE.txt"] = new(FmsEndpoint.DSS2FMS, "SendToFMS", Expect.Accepted, Numeric: true),
        // SSO -> FMS / TOMS / TLS / DSO
        ["SSO_RESPONSE.txt"] = new(FmsEndpoint.SSO2FMS, "SendToFMS", Expect.Accepted),
        ["RETURN_ORDER.txt"] = new(FmsEndpoint.SSO2FMS, "SendToFMS", Expect.Accepted),
        ["TOMS_SSO_RESPONSE.txt"] = new(FmsEndpoint.SSO2TOMS, "SendToTOMS", Expect.Accepted),
        ["TOMS_RETURN_ORDER.txt"] = new(FmsEndpoint.SSO2TOMS, "SendToTOMS", Expect.Accepted),
        ["VOLTAGE_REDUCTION_REQUEST.txt"] = new(FmsEndpoint.SSO2TOMS, "SendToTOMS", Expect.Accepted),
        ["TLS_SSO_RESPONSE.txt"] = new(FmsEndpoint.SSO2TLS, "SendToTLS", Expect.Accepted),
        ["TLS_RETURN_ORDER.txt"] = new(FmsEndpoint.SSO2TLS, "SendToTLS", Expect.Accepted),
        ["DSO_SSO_RESPONSE.txt"] = new(FmsEndpoint.SSO2DSO, "SendToDSO", Expect.Accepted),
        ["DSO_RETURN_ORDER.txt"] = new(FmsEndpoint.SSO2DSO, "SendToDSO", Expect.Accepted),
        // FTC -> FMS
        ["FAULT_CORRELATION.txt"] = new(FmsEndpoint.FTC2FMS, "SendToFMS", Expect.Accepted),
        ["GET_RELAY_TARGET.txt"] = new(FmsEndpoint.FTC2FMS, "GetFromFMS", Expect.Unavailable),
        // Verizon -> TLS (ASMX, long reply). The real handler accepts only the two eBonding SOAP replies.
        ["CreateTicketResponse.txt"] = new(FmsEndpoint.VZ2TLS, "SendToTLS", Expect.Accepted, Numeric: true),
        ["GetTicketResponse.txt"] = new(FmsEndpoint.VZ2TLS, "SendToTLS", Expect.Accepted, Numeric: true),
        ["CancelTroubleReportResponse.txt"] = new(FmsEndpoint.VZ2TLS, "SendToTLS", Expect.Refused, Numeric: true),
        ["RequestTroubleReportCreationResponse.txt"] = new(FmsEndpoint.VZ2TLS, "SendToTLS", Expect.Refused, Numeric: true),
        ["RetrieveAttributesByTroubleReportIdResponse.txt"] = new(FmsEndpoint.VZ2TLS, "SendToTLS", Expect.Refused, Numeric: true),
        // XA/21 and BFC: request/reply only — cannot be answered across the air gap
        ["DISPLAY_POLL.txt"] = new(FmsEndpoint.XA2FMS, "ProcessMessage", Expect.Fault),
        ["DISPLAY_ERROR.txt"] = new(FmsEndpoint.XA2FMS, "ProcessMessage", Expect.Fault),
        ["DEVICE_STATUS_CHANGE.txt"] = new(FmsEndpoint.XA2FMS, "ProcessMessage", Expect.Fault),
        ["BUS_FAULT_OUTAGE_REQUEST.txt"] = new(FmsEndpoint.IR2BFC, "ProcessMessage", Expect.Fault),
        ["BUS_FAULT_CORRELATION_REQUEST.txt"] = new(FmsEndpoint.IR2BFC, "ProcessMessage", Expect.Fault),
    };

    /// <summary>Plain HTTP GET interface, tested separately.</summary>
    private static readonly string[] NotSoap = ["REGISTERED_TAG_REQUEST.txt"];

    public static TheoryData<string> SampleFiles()
    {
        var data = new TheoryData<string>();
        foreach (string file in Cases.Keys) data.Add(file);
        return data;
    }

    private GatewayHost Host => fixture.Host;
    private HttpClient Client => fixture.Client;

    [Fact]
    public void Every_simulator_template_is_covered()
    {
        var files = Directory.GetFiles(Path.Combine(AppContext.BaseDirectory, "Samples")).Select(Path.GetFileName).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var covered = Cases.Keys.Concat(NotSoap).ToHashSet(StringComparer.OrdinalIgnoreCase);
        Assert.Equal(43, files.Count);
        Assert.True(files.SetEquals(covered), "Uncovered: " + string.Join(", ", files.Except(covered)));
    }

    [Theory]
    [MemberData(nameof(SampleFiles))]
    public async Task Every_simulator_message_gets_the_answer_its_caller_expects(string file)
    {
        var c = Cases[file];
        string payload = SoapCalls.Sample(file);
        byte[] request = SoapCalls.Build(c.Endpoint, c.Operation, payload, c.Parameter);

        var (response, reply) = await SoapCalls.PostAsync(Client, c.Endpoint, c.Operation, request);

        if (c.Expect == Expect.Fault)
        {
            Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);
            Assert.True(SoapCalls.IsFault(reply));
            Assert.False(response.Headers.Contains(IngressEndpoint.MessageIdHeader)); // nothing queued
            return;
        }

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        string? result = SoapCalls.Result(reply);

        if (c.Expect == Expect.Echo)
        {
            Assert.Equal(payload.TrimEnd(), result!.TrimEnd());
            return;
        }

        int code = c.Numeric ? int.Parse(result!) : SoapCalls.ReturnCode(result);
        switch (c.Expect)
        {
            case Expect.Accepted:
                Assert.Equal(0, code);
                await AssertStoredVerbatimAsync(response, request, c);
                break;
            case Expect.Unavailable:
                Assert.Equal(1599, code);
                Assert.False(response.Headers.Contains(IngressEndpoint.MessageIdHeader));
                break;
            case Expect.Refused:
                Assert.Equal(1597, code);
                Assert.False(response.Headers.Contains(IngressEndpoint.MessageIdHeader));
                break;
        }
    }

    private async Task AssertStoredVerbatimAsync(HttpResponseMessage response, byte[] request, Case c)
    {
        var messageId = Guid.Parse(response.Headers.GetValues(IngressEndpoint.MessageIdHeader).Single());
        var row = await Host.Get<OutboxStore>().FindAsync(messageId, CancellationToken.None);
        Assert.NotNull(row);
        Assert.Equal(PayloadFormat.RawSoap, row!.PayloadFormat);

        // The envelope is encrypted at rest, and opens back to the caller's exact bytes.
        Assert.True(row.Envelope.AsSpan().IndexOf(request.AsSpan(0, 60)) < 0);
        var (header, plain) = Host.Get<EnvelopeCodec>().Open(row.Envelope);
        var stored = RawSoapMessage.FromBytes(plain, 1_000_000);
        Assert.Equal(request, stored.Body);
        Assert.Equal(c.Endpoint.Path, stored.Path, ignoreCase: true);
        Assert.Equal($"\"{c.Endpoint.ActionPrefix}{c.Operation}\"", stored.SoapActionHeader);
        Assert.Equal(c.Operation, header.Operation);
        Assert.Equal(Direction.CorpToDmz, header.Direction);
        Assert.Equal(row.BusinessType, string.IsNullOrEmpty(header.BusinessType) ? null : header.BusinessType);
        Assert.NotNull(row.BusinessType);
    }

    [Fact]
    public async Task The_fms_reply_echoes_the_message_type_and_id()
    {
        var (_, reply) = await SoapCalls.PostAsync(Client, FmsEndpoint.FC2FMS, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("REQUEST_FOR_PERMIT.txt")));
        var response = XDocument.Parse(SoapCalls.Result(reply)!).Root!;
        Assert.Equal("REQUEST_FOR_PERMIT", response.Attribute("MSG_TYPE")!.Value);
        Assert.Equal("679", response.Attribute("MSG_ID")!.Value);
    }

    [Fact]
    public async Task The_same_message_sent_twice_is_queued_twice()
    {
        // MSG_ID is a static template value ("456") in the callers: it is a label, never an identity.
        byte[] request = SoapCalls.Build(FmsEndpoint.SSO2FMS, "SendToFMS", SoapCalls.Sample("SSO_RESPONSE.txt"));
        var (first, _) = await SoapCalls.PostAsync(Client, FmsEndpoint.SSO2FMS, "SendToFMS", request);
        var (second, _) = await SoapCalls.PostAsync(Client, FmsEndpoint.SSO2FMS, "SendToFMS", request);
        Assert.NotEqual(first.Headers.GetValues(IngressEndpoint.MessageIdHeader).Single(),
                        second.Headers.GetValues(IngressEndpoint.MessageIdHeader).Single());
    }

    [Fact]
    public async Task A_message_type_the_interface_does_not_take_is_refused_like_fms_would()
    {
        // RETURN_ORDER belongs to SSO2FMS, not FC2FMS
        var (response, reply) = await SoapCalls.PostAsync(Client, FmsEndpoint.FC2FMS, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("RETURN_ORDER.txt")));
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal(1597, SoapCalls.ReturnCode(SoapCalls.Result(reply)));
    }

    [Fact]
    public async Task A_malformed_payload_is_refused()
    {
        var (_, reply) = await SoapCalls.PostAsync(Client, FmsEndpoint.FC2FMS, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", "<MESSAGE TYPE=\"REQUEST_FOR_PERMIT\"><MSG_DATA></MESSAGE>"));
        Assert.Equal(1597, SoapCalls.ReturnCode(SoapCalls.Result(reply)));
    }

    [Fact]
    public async Task Legacy_soap_toolkit_endpoint_is_bridged_with_an_int_reply()
    {
        var (response, reply) = await SoapCalls.PostAsync(Client, FmsEndpoint.SSO2FMSLegacy, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.SSO2FMSLegacy, "SendToFMS", SoapCalls.Sample("RETURN_ORDER.txt")));
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        // RPC shape: <m:SendToFMSResponse xmlns:m="http://tempuri.org/message/"><Result>0</Result>
        var wrapper = XDocument.Parse(Encoding.UTF8.GetString(reply)).Root!.Element(SoapCalls.Soap11 + "Body")!.Elements().Single();
        Assert.Equal(XName.Get("SendToFMSResponse", "http://tempuri.org/message/"), wrapper.Name);
        Assert.Equal("0", wrapper.Element("Result")!.Value);
        Assert.True(response.Headers.Contains(IngressEndpoint.MessageIdHeader));
    }

    [Fact]
    public async Task Unknown_service_and_unknown_operation_are_refused_with_a_fault()
    {
        var unknownService = FmsEndpoint.FC2FMS with { Path = "/Somewhere/Else.svc" };
        var (r1, b1) = await SoapCalls.PostAsync(Client, unknownService, "SendToFMS",
            SoapCalls.Build(unknownService, "SendToFMS", SoapCalls.Sample("REQUEST_FOR_PERMIT.txt")));
        Assert.Equal(HttpStatusCode.InternalServerError, r1.StatusCode);
        Assert.True(SoapCalls.IsFault(b1));

        var (r2, b2) = await SoapCalls.PostAsync(Client, FmsEndpoint.FC2FMS, "DeleteEverything",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "DeleteEverything", "x"));
        Assert.Equal(HttpStatusCode.InternalServerError, r2.StatusCode);
        Assert.True(SoapCalls.IsFault(b2));
    }

    [Fact]
    public async Task Requests_that_are_not_soap_or_too_large_are_refused()
    {
        var notSoap = await Client.PostAsync(FmsEndpoint.FC2FMS.Path, new StringContent("hello", Encoding.UTF8, "text/xml"));
        Assert.Equal(HttpStatusCode.BadRequest, notSoap.StatusCode);

        var huge = await Client.PostAsync(FmsEndpoint.FC2FMS.Path, new ByteArrayContent(new byte[1_000_001]));
        Assert.Equal(HttpStatusCode.RequestEntityTooLarge, huge.StatusCode);
    }

    [Fact]
    public async Task Wsdl_is_served_with_the_callers_address()
    {
        string wsdl = await Client.GetStringAsync(FmsEndpoint.FC2FMS.Path + "?wsdl");
        var doc = XDocument.Parse(wsdl);
        XNamespace soap = "http://schemas.xmlsoap.org/wsdl/soap/";
        XNamespace xsd = "http://www.w3.org/2001/XMLSchema";
        Assert.Equal("http://localhost/FMS_FC2FMSInterface/FC2FMSInterface.svc",
            doc.Descendants(soap + "address").Single().Attribute("location")!.Value);
        Assert.All(doc.Descendants(xsd + "import"),
            i => Assert.StartsWith("http://localhost/FMS_FC2FMSInterface/FC2FMSInterface.svc?xsd=xsd", i.Attribute("schemaLocation")!.Value));

        string xsd0 = await Client.GetStringAsync(FmsEndpoint.FC2FMS.Path + "?xsd=xsd0");
        Assert.Contains("SendToFMSResult", xsd0);
    }

    [Fact]
    public async Task Legacy_endpoints_return_their_wsdl_on_a_plain_get()
    {
        string wsdl = await Client.GetStringAsync(FmsEndpoint.DSS2FMS.Path);
        Assert.Contains("RR_DSSFMSService", wsdl);
        Assert.Contains("http://localhost/FMSInterface/RR_DSSFMSService.wsdl", wsdl);
    }

    [Fact]
    public async Task Probes_and_get_only_interfaces()
    {
        var page = await Client.GetAsync(FmsEndpoint.SSO2FMS.Path); // load balancer health probe
        Assert.Equal(HttpStatusCode.OK, page.StatusCode);

        var tags = await Client.GetAsync("/FMS_ReportService/RegisteredTags.asmx/GetData");
        Assert.Equal(HttpStatusCode.ServiceUnavailable, tags.StatusCode);

        var unknown = await Client.GetAsync("/nothing/here.svc");
        Assert.Equal(HttpStatusCode.NotFound, unknown.StatusCode);

        var health = await Client.GetStringAsync("/health");
        Assert.Contains("\"side\":\"Corp\"", health);
    }

    [Fact]
    public async Task A_full_backlog_refuses_new_calls_instead_of_queueing_them()
    {
        string root = GatewayHost.NewRoot();
        await using (var host = GatewayHost.Start(BridgeSide.Corp, root, new Dictionary<string, string?> { ["Gateway:MaxBacklog"] = "1" }))
        {
            var client = host.CreateClient();
            byte[] request = SoapCalls.Build(FmsEndpoint.SSO2FMS, "SendToFMS", SoapCalls.Sample("SSO_RESPONSE.txt"));

            var (_, first) = await SoapCalls.PostAsync(client, FmsEndpoint.SSO2FMS, "SendToFMS", request);
            var (secondResponse, second) = await SoapCalls.PostAsync(client, FmsEndpoint.SSO2FMS, "SendToFMS", request);

            Assert.Equal(0, SoapCalls.ReturnCode(SoapCalls.Result(first)));
            Assert.Equal(1598, SoapCalls.ReturnCode(SoapCalls.Result(second)));
            Assert.False(secondResponse.Headers.Contains(IngressEndpoint.MessageIdHeader));
        }
        GatewayHost.DeleteRoot(root);
    }
}
