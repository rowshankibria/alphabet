using System.Security;
using System.Text;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Routing;

namespace QrBridge.Tests.Gateway;

public class DeliveryClassificationTests
{
    private static byte[] Wrapped(string result) => Encoding.UTF8.GetBytes(
        $"""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><SendToFMSResponse xmlns="http://tempuri.org/"><SendToFMSResult>{SecurityElement.Escape(result)}</SendToFMSResult></SendToFMSResponse></s:Body></s:Envelope>""");

    private static byte[] FmsResponse(int code, string message = "") =>
        Wrapped($"<RESPONSE><STATUS><RETURN_CODE>{code}</RETURN_CODE><ERROR_MESSAGE>{message}</ERROR_MESSAGE></STATUS></RESPONSE>");

    [Fact]
    public void Return_code_zero_is_delivered()
    {
        var r = SoapForwarder.Classify(200, FmsResponse(0), ResultKind.FmsResponse);
        Assert.Equal(DeliveryVerdict.Delivered, r.Verdict);
        Assert.Equal("RETURN_CODE=0", r.DownstreamResult);
    }

    [Fact]
    public void Non_zero_return_code_is_refused_with_the_reason()
    {
        var r = SoapForwarder.Classify(200, FmsResponse(1501, "Invalid card id"), ResultKind.FmsResponse);
        Assert.Equal(DeliveryVerdict.Refused, r.Verdict);
        Assert.Contains("1501", r.DownstreamResult);
        Assert.Contains("Invalid card id", r.DownstreamResult);
    }

    [Theory]
    [InlineData("0", DeliveryVerdict.Delivered)]
    [InlineData("1500", DeliveryVerdict.Refused)]
    public void Numeric_return_codes(string code, DeliveryVerdict expected) =>
        Assert.Equal(expected, SoapForwarder.Classify(200, Wrapped(code), ResultKind.ReturnCode).Verdict);

    [Fact]
    public void Soap_fault_is_permanent()
    {
        byte[] fault = Encoding.UTF8.GetBytes("""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><s:Fault><faultcode>s:Server</faultcode><faultstring>Object reference not set</faultstring></s:Fault></s:Body></s:Envelope>""");
        var r = SoapForwarder.Classify(500, fault, ResultKind.FmsResponse);
        Assert.Equal(DeliveryVerdict.Permanent, r.Verdict);
        Assert.Contains("Object reference not set", r.DownstreamResult);
    }

    [Theory]
    [InlineData(503)]
    [InlineData(502)]
    [InlineData(504)]
    [InlineData(429)]
    [InlineData(500)] // an IIS error page, not a SOAP fault
    public void Server_trouble_without_a_fault_is_retried(int status) =>
        Assert.Equal(DeliveryVerdict.Transient,
            SoapForwarder.Classify(status, Encoding.UTF8.GetBytes("<html>Service Unavailable</html>"), ResultKind.FmsResponse).Verdict);

    [Theory]
    [InlineData(404)]
    [InlineData(401)]
    [InlineData(415)]
    public void Configuration_problems_are_permanent(int status) =>
        Assert.Equal(DeliveryVerdict.Permanent, SoapForwarder.Classify(status, [], ResultKind.FmsResponse).Verdict);

    [Fact]
    public void Accepted_one_way_and_unknown_shapes_are_delivered()
    {
        Assert.Equal(DeliveryVerdict.Delivered, SoapForwarder.Classify(202, [], ResultKind.FmsResponse).Verdict);
        Assert.Equal(DeliveryVerdict.Delivered, SoapForwarder.Classify(200, "not soap"u8.ToArray(), ResultKind.None).Verdict);
        // 2xx but no RETURN_CODE: processed, and the result says so
        var odd = SoapForwarder.Classify(200, Wrapped("OK"), ResultKind.FmsResponse);
        Assert.Equal(DeliveryVerdict.Delivered, odd.Verdict);
        Assert.Contains("unrecognized", odd.DownstreamResult);
    }
}
