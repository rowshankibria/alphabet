using System.Security.Cryptography;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using QrBridge.Gateway.Egress;
using QrBridge.Shared;
using QrBridge.Shared.Security;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>
/// One real gateway (the actual Program, routes.json, EF/SQLite, DPAPI keys, workers) running in memory,
/// with its data and keys in a temp folder. Two hosts sharing a root = a Corp and a DMZ gateway.
/// </summary>
public sealed class GatewayHost : IAsyncDisposable
{
    public const string CorpKeyId = "c2d-test";
    public const string DmzKeyId = "d2c-test";

    private GatewayHost(WebApplicationFactory<Program> factory, BridgeSide side)
    {
        Factory = factory;
        Side = side;
    }

    public WebApplicationFactory<Program> Factory { get; }
    public BridgeSide Side { get; }

    /// <param name="root">Folder for keys and both sides' databases (share it between a Corp and a DMZ host).</param>
    /// <param name="settings">Extra configuration, e.g. "Routing:AcceptUnlisted" = "true".</param>
    /// <param name="egressHandler">Stand-in for the real services this gateway delivers to.</param>
    public static GatewayHost Start(BridgeSide side, string root, IDictionary<string, string?>? settings = null,
                                    Func<HttpMessageHandler>? egressHandler = null)
    {
        EnsureKeys(Path.Combine(root, "Keys"));

        var config = new Dictionary<string, string?>
        {
            ["Bridge:Side"] = side.ToString(),
            ["Bridge:DataFolder"] = Path.Combine(root, side.ToString(), "Data"),
            ["Gateway:KeyFolder"] = Path.Combine(root, "Keys"),
            ["Gateway:OutboundKeyId"] = side == BridgeSide.Corp ? CorpKeyId : DmzKeyId,
            ["Gateway:InboxPollSeconds"] = "1",
            ["Gateway:BackoffBaseSeconds"] = "1",
            ["Gateway:MaintenanceIntervalSeconds"] = "3600",
            ["Gateway:Egress:DefaultBaseUrl"] = "http://real-service.test",
            ["Gateway:Egress:TimeoutSeconds"] = "10",
        };
        foreach (var (key, value) in settings ?? new Dictionary<string, string?>()) config[key] = value;

        var factory = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
        {
            builder.UseEnvironment(side.ToString()); // appsettings.Corp.json / appsettings.Dmz.json, as in IIS
            builder.ConfigureAppConfiguration((_, c) => c.AddInMemoryCollection(config));
            if (egressHandler is not null)
                builder.ConfigureTestServices(services => services
                    .AddHttpClient(SoapForwarder.HttpClientName)
                    .ConfigurePrimaryHttpMessageHandler(egressHandler));
        });

        var host = new GatewayHost(factory, side);
        _ = factory.Server; // start now: runs the startup checks and creates the databases
        return host;
    }

    public HttpClient CreateClient() =>
        Factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });

    /// <summary>An HTTP handler that talks to this gateway in memory (for WCF clients).</summary>
    public HttpMessageHandler CreateHandler() => Factory.Server.CreateHandler();

    public T Get<T>() where T : notnull => Factory.Services.GetRequiredService<T>();

    public async ValueTask DisposeAsync()
    {
        await Factory.DisposeAsync();
        SqliteConnection.ClearAllPools();
    }

    private static readonly object KeyLock = new();

    private static void EnsureKeys(string folder)
    {
        lock (KeyLock)
        {
            var store = new DpapiKeyStore(folder);
            foreach (string id in new[] { CorpKeyId, DmzKeyId })
                if (!File.Exists(Path.Combine(folder, id + ".key")))
                    store.Save(id, RandomNumberGenerator.GetBytes(32));
        }
    }

    public static string NewRoot() => Path.Combine(Path.GetTempPath(), "qrbridge-gw-" + Guid.NewGuid().ToString("N"));

    public static void DeleteRoot(string root)
    {
        SqliteConnection.ClearAllPools();
        try { Directory.Delete(root, recursive: true); } catch { /* best effort: SQLite may still hold a handle */ }
    }
}
