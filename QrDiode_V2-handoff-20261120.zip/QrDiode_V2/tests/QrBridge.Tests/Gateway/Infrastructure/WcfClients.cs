using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

namespace QrBridge.Tests.Gateway.Infrastructure;

// Client contracts exactly as the simulator's generated proxies describe the real services.

[ServiceContract(Namespace = "http://tempuri.org/", Name = "IFC2FMSInterface")]
public interface IFC2FMSInterface
{
    [OperationContract(Name = "SendToFMS", Action = "http://tempuri.org/IFC2FMSInterface/SendToFMS",
        ReplyAction = "http://tempuri.org/IFC2FMSInterface/SendToFMSResponse")]
    Task<string> SendToFMSAsync(string sXML);

    [OperationContract(Name = "GetFromFMS", Action = "http://tempuri.org/IFC2FMSInterface/GetFromFMS",
        ReplyAction = "http://tempuri.org/IFC2FMSInterface/GetFromFMSResponse")]
    Task<string> GetFromFMSAsync(string sXML);

    [OperationContract(Name = "EchoString", Action = "http://tempuri.org/IFC2FMSInterface/EchoString",
        ReplyAction = "http://tempuri.org/IFC2FMSInterface/EchoStringResponse")]
    Task<string> EchoStringAsync(string sValue);
}

/// <summary>The ASMX service VZ2TLSInterface.asmx, as an XmlSerializer (ASMX-style) client sees it.</summary>
[ServiceContract(Namespace = "http://tempuri.org/", Name = "TLSInterfaceSoapPort")]
[XmlSerializerFormat]
public interface IVZ2TLSInterface
{
    [OperationContract(Name = "SendToTLS", Action = "http://tempuri.org/SendToTLS", ReplyAction = "*")]
    Task<long> SendToTLSAsync(string XMLMsg);
}

/// <summary>A service the catalogue has never heard of, called over SOAP 1.2 + WS-Addressing (WSHttpBinding).</summary>
[ServiceContract(Namespace = "urn:qrbridge:test", Name = "INewService")]
public interface INewService
{
    [OperationContract(Name = "DoWork")]
    Task<string> DoWorkAsync(string input);
}

/// <summary>Creates real WCF client channels that talk to an in-memory gateway.</summary>
public static class Wcf
{
    public static (T Channel, ChannelFactory<T> Factory) Create<T>(GatewayHost host, Binding binding, string path)
    {
        var factory = new ChannelFactory<T>(binding, new EndpointAddress("http://localhost" + path));
        factory.Endpoint.EndpointBehaviors.Add(new InMemoryTransport(host.CreateHandler));
        return (factory.CreateChannel(), factory);
    }

    /// <summary>WCF's HTTP transport lets a binding parameter replace its HttpMessageHandler.</summary>
    private sealed class InMemoryTransport(Func<HttpMessageHandler> createHandler) : IEndpointBehavior
    {
        public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters) =>
            bindingParameters.Add(new Func<HttpClientHandler, HttpMessageHandler>(_ => createHandler()));

        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime) { }
        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher) { }
        public void Validate(ServiceEndpoint endpoint) { }
    }
}
