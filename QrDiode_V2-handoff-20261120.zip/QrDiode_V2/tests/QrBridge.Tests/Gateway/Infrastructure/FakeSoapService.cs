using System.Collections.Concurrent;
using System.Security;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.TestHost;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>What the "real service" received.</summary>
public sealed record CapturedRequest(string Path, string? SoapAction, string? ContentType, byte[] Body);

/// <summary>
/// Stands in for a real FMS/RR service (e.g. FC2FMSInterface.svc on the DMZ RR server): records exactly what
/// it receives and answers with whatever <see cref="Responder"/> returns.
/// </summary>
public sealed class FakeSoapService : IAsyncDisposable
{
    private readonly WebApplication _app;

    private FakeSoapService(WebApplication app) => _app = app;

    public ConcurrentQueue<CapturedRequest> Requests { get; } = new();

    /// <summary>Status code + SOAP reply. Defaults to an FMS RETURN_CODE 0 for SendToFMS.</summary>
    public Func<CapturedRequest, (int Status, string Body)> Responder { get; set; } = _ => (200, FmsReply("SendToFMS", 0));

    public static async Task<FakeSoapService> StartAsync()
    {
        var builder = WebApplication.CreateSlimBuilder();
        builder.WebHost.UseTestServer();
        var app = builder.Build();
        var fake = new FakeSoapService(app);

        app.MapPost("/{**path}", async (HttpContext context) =>
        {
            using var ms = new MemoryStream();
            await context.Request.Body.CopyToAsync(ms);
            var captured = new CapturedRequest(
                context.Request.Path.Value ?? "",
                context.Request.Headers.TryGetValue("SOAPAction", out var a) ? a.ToString() : null,
                context.Request.ContentType,
                ms.ToArray());
            fake.Requests.Enqueue(captured);

            var (status, body) = fake.Responder(captured);
            context.Response.StatusCode = status;
            context.Response.ContentType = "text/xml; charset=utf-8";
            await context.Response.WriteAsync(body);
        });

        await app.StartAsync();
        return fake;
    }

    public HttpMessageHandler CreateHandler() => _app.GetTestServer().CreateHandler();

    /// <summary>The reply FMS gives: &lt;RESPONSE&gt; with a RETURN_CODE, as the string result of the operation.</summary>
    public static string FmsReply(string operation, int returnCode, string errorMessage = "") =>
        $"""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><{operation}Response xmlns="http://tempuri.org/"><{operation}Result>{SecurityElement.Escape(
            $"<RESPONSE><STATUS><RETURN_CODE>{returnCode}</RETURN_CODE><ERROR_MESSAGE>{errorMessage}</ERROR_MESSAGE></STATUS></RESPONSE>")}</{operation}Result></{operation}Response></s:Body></s:Envelope>""";

    public async ValueTask DisposeAsync() => await _app.DisposeAsync();
}
