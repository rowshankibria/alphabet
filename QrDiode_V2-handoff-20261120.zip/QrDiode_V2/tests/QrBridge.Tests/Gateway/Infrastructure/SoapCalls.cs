using System.Net.Http.Headers;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>One bridged interface as its callers see it (from the simulator's WSDLs and Configuration.xml).</summary>
public sealed record FmsEndpoint(string Path, string Namespace, string ActionPrefix, string Parameter, bool Rpc = false)
{
    public static readonly FmsEndpoint FC2FMS = Svc("FMS_FC2FMSInterface", "FC2FMSInterface");
    public static readonly FmsEndpoint FOD2FMS = Svc("FMS_FOD2FMSInterface", "FOD2FMSInterface");
    public static readonly FmsEndpoint SSO2FMS = Svc("FMS_SSO2FMSInterface", "SSO2FMSInterface");
    public static readonly FmsEndpoint SSO2TOMS = Svc("FMS_SSO2TOMSInterface", "SSO2TOMSInterface");
    public static readonly FmsEndpoint SSO2TLS = Svc("FMS_SSO2TLSInterface", "SSO2TLSInterface");
    public static readonly FmsEndpoint SSO2DSO = Svc("FMS_SSO2DSOInterface", "SSO2DSOInterface");
    public static readonly FmsEndpoint FTC2FMS = Svc("FMS_FTC2FMSInterface", "FTC2FMSInterface");
    public static readonly FmsEndpoint VZ2TLS = new("/VZ2TLSWebService/VZ2TLSInterface.asmx", "http://tempuri.org/", "http://tempuri.org/", "XMLMsg");
    public static readonly FmsEndpoint DSS2FMS = new("/FMSInterface/RR_DSSFMSService.wsdl", "http://tempuri.org/message/",
        "http://tempuri.org/action/FMSInterface.", "XMLMsg", Rpc: true);
    public static readonly FmsEndpoint SSO2FMSLegacy = new("/FMSInterface/RR_SSOFMSService.WSDL", "http://tempuri.org/message/",
        "http://tempuri.org/action/FMSInterface.", "XMLMsg", Rpc: true);
    public static readonly FmsEndpoint XA2FMS = new("/FMSWebService/ECC_XAFMSService.asmx", "http://www.coned.com/FMSWebService",
        "http://www.coned.com/FMSWebService/", "XMLMsg");
    public static readonly FmsEndpoint IR2BFC = new("/ECC_BFCWebService/ECC_BFCWebService.asmx", "http://www.coned.com/FMSWebService",
        "http://www.coned.com/FMSWebService/", "XMLMsg");

    private static FmsEndpoint Svc(string folder, string service) =>
        new($"/{folder}/{service}.svc", "http://tempuri.org/", $"http://tempuri.org/I{service}/", "sXML");
}

/// <summary>Builds the exact SOAP 1.1 requests the existing clients send, and reads the replies.</summary>
public static class SoapCalls
{
    public static readonly XNamespace Soap11 = "http://schemas.xmlsoap.org/soap/envelope/";

    public static byte[] Build(FmsEndpoint endpoint, string operation, string value, string? parameter = null)
    {
        var settings = new XmlWriterSettings { Encoding = new UTF8Encoding(false), OmitXmlDeclaration = true };
        using var ms = new MemoryStream();
        using (var w = XmlWriter.Create(ms, settings))
        {
            if (endpoint.Rpc)
            {
                // SOAP Toolkit client: RPC/encoded, unqualified part
                w.WriteStartElement("SOAP-ENV", "Envelope", Soap11.NamespaceName);
                w.WriteAttributeString("SOAP-ENV", "encodingStyle", Soap11.NamespaceName, "http://schemas.xmlsoap.org/soap/encoding/");
                w.WriteStartElement("SOAP-ENV", "Body", Soap11.NamespaceName);
                w.WriteStartElement("SOAPSDK4", operation, endpoint.Namespace);
                w.WriteElementString(parameter ?? endpoint.Parameter, "", value);
            }
            else
            {
                // WCF / ASMX client: document/literal wrapped
                w.WriteStartElement("s", "Envelope", Soap11.NamespaceName);
                w.WriteStartElement("s", "Body", Soap11.NamespaceName);
                w.WriteStartElement(operation, endpoint.Namespace);
                w.WriteElementString(parameter ?? endpoint.Parameter, endpoint.Namespace, value);
            }
            w.WriteEndElement();
            w.WriteEndElement();
            w.WriteEndElement();
        }
        return ms.ToArray();
    }

    public static async Task<(HttpResponseMessage Response, byte[] Body)> PostAsync(
        HttpClient client, FmsEndpoint endpoint, string operation, byte[] body)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, endpoint.Path) { Content = new ByteArrayContent(body) };
        request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("text/xml; charset=utf-8");
        request.Headers.TryAddWithoutValidation("SOAPAction", $"\"{endpoint.ActionPrefix}{operation}\"");
        var response = await client.SendAsync(request);
        return (response, await response.Content.ReadAsByteArrayAsync());
    }

    /// <summary>The text of the first element inside the reply wrapper (OpResult / Result).</summary>
    public static string? Result(byte[] reply)
    {
        var body = XDocument.Parse(Encoding.UTF8.GetString(reply)).Root!.Element(Soap11 + "Body")!;
        var wrapper = body.Elements().First();
        return wrapper.Elements().FirstOrDefault()?.Value;
    }

    public static bool IsFault(byte[] reply) =>
        XDocument.Parse(Encoding.UTF8.GetString(reply)).Root!.Element(Soap11 + "Body")!.Element(Soap11 + "Fault") is not null;

    /// <summary>RETURN_CODE of an FMS &lt;RESPONSE&gt; document.</summary>
    public static int ReturnCode(string? responseXml) =>
        int.Parse(XDocument.Parse(responseXml!).Descendants("RETURN_CODE").Single().Value);

    public static string Sample(string file) =>
        File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "Samples", file));
}
