using System.Text;
using QrBridge.Gateway.Soap;

namespace QrBridge.Tests.Gateway;

public class SoapParsingTests
{
    private const long Max = 2_000_000;
    private static byte[] B(string s) => Encoding.UTF8.GetBytes(s);

    [Fact]
    public void Soap11_document_literal_wrapped_request()
    {
        string body = """
            <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
              <s:Body><SendToFMS xmlns="http://tempuri.org/"><sXML>&lt;MESSAGE TYPE="RETURN_ORDER" MSG_ID="456"/&gt;</sXML></SendToFMS></s:Body>
            </s:Envelope>
            """;
        Assert.True(SoapRequest.TryParse(B(body), "text/xml; charset=utf-8", "\"http://tempuri.org/IFC2FMSInterface/SendToFMS\"",
            Max, out var r, out _));

        Assert.Equal(SoapVersion.Soap11, r!.Version);
        Assert.Equal("SendToFMS", r.Operation);
        Assert.Equal("http://tempuri.org/", r.OperationNamespace);
        Assert.False(r.ParametersUnqualified);
        Assert.Equal("<MESSAGE TYPE=\"RETURN_ORDER\" MSG_ID=\"456\"/>", r.FirstParameterText);
        Assert.Equal("http://tempuri.org/IFC2FMSInterface/SendToFMS", r.Action);
        Assert.Equal("\"http://tempuri.org/IFC2FMSInterface/SendToFMS\"", r.SoapActionHeader); // kept as received
        Assert.Null(r.Addressing);
    }

    [Fact]
    public void Soap12_with_ws_addressing()
    {
        string body = """
            <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://www.w3.org/2005/08/addressing">
              <s:Header>
                <a:Action s:mustUnderstand="1">urn:test/INewService/DoWork</a:Action>
                <a:MessageID>urn:uuid:5b1f2b5e-0000-0000-0000-000000000001</a:MessageID>
                <a:To s:mustUnderstand="1">http://lb/Test/NewService.svc</a:To>
              </s:Header>
              <s:Body><DoWork xmlns="urn:test"><input>hi</input></DoWork></s:Body>
            </s:Envelope>
            """;
        Assert.True(SoapRequest.TryParse(B(body), "application/soap+xml; charset=utf-8; action=\"urn:test/INewService/DoWork\"",
            null, Max, out var r, out _));

        Assert.Equal(SoapVersion.Soap12, r!.Version);
        Assert.Equal("DoWork", r.Operation);
        Assert.Equal("urn:test/INewService/DoWork", r.Action);
        Assert.NotNull(r.Addressing);
        Assert.Equal("http://www.w3.org/2005/08/addressing", r.Addressing!.Namespace);
        Assert.Equal("urn:uuid:5b1f2b5e-0000-0000-0000-000000000001", r.Addressing.MessageId);
        Assert.Equal("http://lb/Test/NewService.svc", r.Addressing.To);
    }

    [Fact]
    public void Soap12_action_comes_from_the_content_type_when_there_is_no_addressing()
    {
        string body = """<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body><ProcessMessage xmlns="http://www.coned.com/FMSWebService"><XMLMsg>x</XMLMsg></ProcessMessage></s:Body></s:Envelope>""";
        Assert.True(SoapRequest.TryParse(B(body), "application/soap+xml; charset=utf-8; action=\"http://www.coned.com/FMSWebService/ProcessMessage\"",
            null, Max, out var r, out _));
        Assert.Equal("http://www.coned.com/FMSWebService/ProcessMessage", r!.Action);
    }

    [Fact]
    public void Rpc_encoded_request_has_unqualified_parameters()
    {
        // What a SOAP Toolkit client sends to RR_DSSFMSService.wsdl
        string body = """
            <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
              <SOAP-ENV:Body>
                <SOAPSDK4:SendToFMS xmlns:SOAPSDK4="http://tempuri.org/message/"><XMLMsg>&lt;MESSAGE TYPE="RETURN_MOVE"/&gt;</XMLMsg></SOAPSDK4:SendToFMS>
              </SOAP-ENV:Body>
            </SOAP-ENV:Envelope>
            """;
        Assert.True(SoapRequest.TryParse(B(body), "text/xml", "\"http://tempuri.org/action/FMSInterface.SendToFMS\"", Max, out var r, out _));
        Assert.True(r!.ParametersUnqualified);
        Assert.Equal("http://tempuri.org/message/", r.OperationNamespace);
        Assert.Equal("<MESSAGE TYPE=\"RETURN_MOVE\"/>", r.FirstParameterText);
    }

    [Theory]
    [InlineData("hello")]                                                                       // not XML
    [InlineData("<foo/>")]                                                                      // not SOAP
    [InlineData("""<!DOCTYPE x [<!ENTITY a "aa">]><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><A>&a;</A></s:Body></s:Envelope>""")] // DTD
    [InlineData("""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"/>""")]       // no Body
    [InlineData("""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body/></s:Envelope>""")] // empty Body
    [InlineData("""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><s:Fault/></s:Body></s:Envelope>""")] // a fault
    public void Bad_requests_are_refused_without_throwing(string body)
    {
        Assert.False(SoapRequest.TryParse(B(body), "text/xml", null, Max, out var r, out string error));
        Assert.Null(r);
        Assert.False(string.IsNullOrWhiteSpace(error));
    }

    [Fact]
    public void Inspector_reads_the_fms_message_type_and_id()
    {
        var info = PayloadInspector.Inspect("""<MESSAGE TYPE="REQUEST_FOR_PERMIT" MSG_ID="679"><MSG_DATA/></MESSAGE>""", Max);
        Assert.Equal("REQUEST_FOR_PERMIT", info.Type);
        Assert.Equal("679", info.MsgId);
        Assert.True(info.WellFormed);
    }

    [Fact]
    public void Inspector_names_a_nested_soap_envelope_after_its_body()
    {
        var info = PayloadInspector.Inspect("""
            <env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"><env:Body>
              <m:createTicketResponse xmlns:m="java:com.verizonbusiness.ebonding.repair"/></env:Body></env:Envelope>
            """, Max);
        Assert.Equal("createTicketResponse", info.Type);
    }

    [Theory]
    [InlineData("""<CancelTroubleReportResponse xmlns="http://www.ansi.org/tML/TA/tML-TA"/>""", "CancelTroubleReportResponse", true)]
    [InlineData("<MESSAGE TYPE=\"X\"><unclosed></MESSAGE>", null, false)]
    [InlineData("""<!DOCTYPE MESSAGE [<!ENTITY a "aa">]><MESSAGE TYPE="X"/>""", null, false)]
    public void Inspector_handles_other_and_bad_payloads(string text, string? type, bool wellFormed)
    {
        var info = PayloadInspector.Inspect(text, Max);
        Assert.Equal(type, info.Type);
        Assert.Equal(wellFormed, info.WellFormed);
        Assert.True(info.IsXml);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("Send messages to FMS using soap")]
    public void Inspector_ignores_non_xml_values(string? text)
    {
        var info = PayloadInspector.Inspect(text, Max);
        Assert.Null(info.Type);
        Assert.False(info.IsXml);
    }
}
