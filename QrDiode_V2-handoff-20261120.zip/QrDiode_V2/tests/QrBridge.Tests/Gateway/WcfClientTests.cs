using System.ServiceModel;
using Microsoft.EntityFrameworkCore;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Real WCF client stacks (the same System.ServiceModel the callers' proxies use) talking to the generic
/// gateway. If these pass, an existing client cannot tell the gateway from the real service.
/// </summary>
public sealed class WcfClientTests : IAsyncLifetime
{
    private readonly string _root = GatewayHost.NewRoot();
    private GatewayHost _host = null!;

    public Task InitializeAsync()
    {
        // Unlisted services are accepted here so a brand-new SOAP 1.2 service can be shown working too.
        _host = GatewayHost.Start(BridgeSide.Corp, _root, new Dictionary<string, string?> { ["Routing:AcceptUnlisted"] = "true" });
        return Task.CompletedTask;
    }

    public async Task DisposeAsync()
    {
        await _host.DisposeAsync();
        GatewayHost.DeleteRoot(_root);
    }

    [Fact]
    public async Task BasicHttp_wcf_client_gets_the_fms_response_it_expects()
    {
        var (client, factory) = Wcf.Create<IFC2FMSInterface>(_host, new BasicHttpBinding(), FmsEndpoint.FC2FMS.Path);
        try
        {
            string sent = await client.SendToFMSAsync(SoapCalls.Sample("REQUEST_FOR_PERMIT.txt"));
            Assert.Equal(0, SoapCalls.ReturnCode(sent));

            string query = await client.GetFromFMSAsync(SoapCalls.Sample("GET_FEEDER_INFO.txt"));
            Assert.Equal(1599, SoapCalls.ReturnCode(query)); // a clean "not available", not a hang

            Assert.Equal("ping", await client.EchoStringAsync("ping"));
        }
        finally
        {
            factory.Abort();
        }
    }

    [Fact]
    public async Task Asmx_style_xml_serializer_client_gets_its_long_return_code()
    {
        var (client, factory) = Wcf.Create<IVZ2TLSInterface>(_host, new BasicHttpBinding(), FmsEndpoint.VZ2TLS.Path);
        try
        {
            Assert.Equal(0L, await client.SendToTLSAsync(SoapCalls.Sample("CreateTicketResponse.txt")));
            Assert.Equal(1597L, await client.SendToTLSAsync(SoapCalls.Sample("CancelTroubleReportResponse.txt")));
        }
        finally
        {
            factory.Abort();
        }
    }

    [Fact]
    public async Task Soap12_ws_addressing_client_of_an_unlisted_service_works()
    {
        var binding = new WSHttpBinding(SecurityMode.None); // SOAP 1.2 + WS-Addressing 1.0
        var (client, factory) = Wcf.Create<INewService>(_host, binding, "/Test/NewService.svc");
        try
        {
            string? result = await client.DoWorkAsync("hello");
            Assert.Null(result); // automatic empty reply: the contract is unknown to the gateway
        }
        finally
        {
            factory.Abort();
        }

        // ...and the call was stored for the other side, under its path and operation.
        var outbound = _host.Get<IDbContextFactory<OutboundDbContext>>();
        await using var db = await outbound.CreateDbContextAsync();
        var row = await db.Outbox.SingleAsync(m => m.ServiceName == "/Test/NewService.svc");
        Assert.Equal("DoWork", row.Operation);
    }
}
