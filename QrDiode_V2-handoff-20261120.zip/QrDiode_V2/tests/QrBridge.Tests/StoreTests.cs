using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Stores;
using QrBridge.Shared.Envelope;
using QrBridge.Shared.Security;

namespace QrBridge.Tests;

/// <summary>Real SQLite files in a temp folder: exercises EF mapping, CHECK constraints and the queue operations.</summary>
public sealed class StoreTests : IAsyncLifetime
{
    private readonly string _folder = Path.Combine(Path.GetTempPath(), "qrbridge-tests-" + Guid.NewGuid().ToString("N"));
    private ServiceProvider _sp = null!;

    public async Task InitializeAsync()
    {
        var services = new ServiceCollection();
        services.AddBridgeData(new BridgeOptions { DataFolder = _folder });
        _sp = services.BuildServiceProvider();
        await DatabaseInitializer.InitializeAsync(_sp, NullLogger.Instance);
    }

    public async Task DisposeAsync()
    {
        await _sp.DisposeAsync();
        Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
        try { Directory.Delete(_folder, recursive: true); } catch { /* best effort */ }
    }

    private async Task<OutboxMessage> InsertOutboxAsync(Guid? id = null)
    {
        var factory = _sp.GetRequiredService<IDbContextFactory<OutboundDbContext>>();
        await using var db = await factory.CreateDbContextAsync();
        var row = new OutboxMessage
        {
            MessageId = id ?? Guid.NewGuid(),
            MessageType = MessageType.Request,
            Direction = Direction.CorpToDmz,
            ServiceName = "FC2FMS",
            Operation = "SendToFMS",
            BusinessType = "RETURN_ORDER",
            Sequence = 1,
            PayloadFormat = PayloadFormat.RawSoap,
            KeyId = "k1",
            PayloadSize = 3,
            Envelope = [1, 2, 3],
            EnvelopeHash = Hashing.Sha256Hex([1, 2, 3]),
            Status = OutboxStatus.Pending,
            CreatedUtc = DateTime.UtcNow,
        };
        db.Outbox.Add(row);
        await db.SaveChangesAsync();
        return row;
    }

    private static EnvelopeHeader Header(string businessType = "RETURN_ORDER") => new()
    {
        MessageId = Guid.NewGuid(), MessageType = MessageType.Request, Direction = Direction.CorpToDmz,
        ServiceName = "SSO2FMS", Operation = "SendToFMS", BusinessType = businessType, Sequence = 7, KeyId = "k1",
    };

    [Fact]
    public async Task Sequence_counters_are_seeded()
    {
        var factory = _sp.GetRequiredService<IDbContextFactory<OutboundDbContext>>();
        await using var db = await factory.CreateDbContextAsync();
        Assert.Equal(2, await db.SequenceCounters.CountAsync());
    }

    [Fact]
    public async Task Claim_gives_each_row_to_exactly_one_claimer()
    {
        for (int i = 0; i < 20; i++) await InsertOutboxAsync();
        var store = _sp.GetRequiredService<OutboxStore>();

        var claims = await Task.WhenAll(Enumerable.Range(0, 40).Select(_ => store.ClaimNextAsync(CancellationToken.None)));
        var ids = claims.Where(c => c is not null).Select(c => c!.Id).ToList();

        Assert.Equal(20, ids.Count);
        Assert.Equal(20, ids.Distinct().Count());
        Assert.All(claims.Where(c => c is not null), c => Assert.Equal(OutboxStatus.Sending, c!.Status));
    }

    [Fact]
    public async Task Ack_marks_row_acked_and_release_requeues()
    {
        var store = _sp.GetRequiredService<OutboxStore>();
        var a = await InsertOutboxAsync();
        await InsertOutboxAsync();
        await store.ClaimNextAsync(CancellationToken.None);
        var cb = await store.ClaimNextAsync(CancellationToken.None);

        Assert.Equal(1, await store.MarkAckedAsync([a.MessageId], CancellationToken.None));
        await store.ReleaseAsync(cb!.Id, "test", maxAttempts: 5, TimeSpan.Zero, CancellationToken.None);

        var counts = await store.GetCountsAsync(CancellationToken.None);
        Assert.Equal(1, counts.Acked);
        Assert.Equal(1, counts.Pending);
    }

    [Fact]
    public async Task Duplicate_message_id_is_rejected_by_unique_index()
    {
        var id = Guid.NewGuid();
        await InsertOutboxAsync(id);
        await Assert.ThrowsAsync<DbUpdateException>(() => InsertOutboxAsync(id));
    }

    [Fact]
    public async Task Inbox_insert_is_idempotent_and_the_worker_can_open_what_the_receiver_stored()
    {
        var codec = new EnvelopeCodec(new InMemoryKeyProvider().Add("k1", RandomNumberGenerator.GetBytes(32)));
        var header = Header();
        byte[] envelope = codec.Seal(header, RandomNumberGenerator.GetBytes(5000));

        var inbox = _sp.GetRequiredService<InboxStore>();
        var peeked = EnvelopeCodec.PeekHeader(envelope);
        Assert.True(await inbox.AddMessageAsync(peeked, envelope, chunkCount: 12, CancellationToken.None));
        Assert.False(await inbox.AddMessageAsync(peeked, envelope, chunkCount: 12, CancellationToken.None)); // duplicate ignored

        var row = await inbox.ClaimNextAsync(CancellationToken.None);
        Assert.NotNull(row);
        Assert.Equal(InboxStatus.Processing, row!.Status);
        Assert.Equal(envelope, row.Envelope);
        Assert.Equal(7, row.Sequence);
        Assert.Equal("RETURN_ORDER", row.BusinessType);
        Assert.Equal(12, row.ChunkCount);

        var (opened, _) = codec.Open(row.Envelope);
        Assert.Equal(header.MessageId, opened.MessageId);

        await inbox.MarkDoneAsync(row.Id, "RETURN_CODE=0", CancellationToken.None);
        var done = await inbox.FindAsync(header.MessageId, CancellationToken.None);
        Assert.Equal(InboxStatus.Done, done!.Status);
        Assert.Equal("RETURN_CODE=0", done.DownstreamResult);
        Assert.True(done.Verified);
    }

    [Fact]
    public async Task Refused_messages_go_to_dead_letter_with_the_service_answer()
    {
        var inbox = _sp.GetRequiredService<InboxStore>();
        var header = Header();
        await inbox.AddMessageAsync(header, [1, 2, 3], 1, CancellationToken.None);
        var row = await inbox.ClaimNextAsync(CancellationToken.None);

        await inbox.MarkDeadLetterAsync(row!.Id, "The service refused the message", "RETURN_CODE=1501; ERROR_MESSAGE=Invalid card", CancellationToken.None);

        var dead = await inbox.FindAsync(header.MessageId, CancellationToken.None);
        Assert.Equal(InboxStatus.DeadLetter, dead!.Status);
        Assert.Contains("1501", dead.DownstreamResult);
        Assert.Null(await inbox.ClaimNextAsync(CancellationToken.None)); // never retried on its own

        Assert.Equal(1, await inbox.RequeueDeadLetterAsync(header.MessageId, CancellationToken.None));
        Assert.NotNull(await inbox.ClaimNextAsync(CancellationToken.None)); // operator requeue works
    }

    [Fact]
    public async Task Failed_rows_are_retried_after_backoff()
    {
        var inbox = _sp.GetRequiredService<InboxStore>();
        await inbox.AddMessageAsync(Header(), [1, 2, 3], 1, CancellationToken.None);

        var first = await inbox.ClaimNextAsync(CancellationToken.None);
        await inbox.MarkFailedAsync(first!.Id, first.Attempts, "transient", maxAttempts: 5, TimeSpan.FromHours(1), CancellationToken.None);
        Assert.Null(await inbox.ClaimNextAsync(CancellationToken.None)); // still backing off

        await inbox.MarkFailedAsync(first.Id, first.Attempts, "transient", maxAttempts: 5, TimeSpan.Zero, CancellationToken.None);
        var second = await inbox.ClaimNextAsync(CancellationToken.None);
        Assert.Equal(2, second!.Attempts);
    }

    [Fact]
    public async Task Heartbeats_upsert()
    {
        var hb = _sp.GetRequiredService<HeartbeatStore>();
        await hb.BeatAsync("X", "one", CancellationToken.None);
        await hb.BeatAsync("X", "two", CancellationToken.None);
        var all = await hb.GetAllAsync(CancellationToken.None);
        Assert.Single(all);
        Assert.Equal("two", all[0].Info);
        Assert.Equal(DateTimeKind.Utc, all[0].LastSeenUtc.Kind);
    }
}
