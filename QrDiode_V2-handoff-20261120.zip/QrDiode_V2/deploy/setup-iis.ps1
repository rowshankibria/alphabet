#Requires -RunAsAdministrator
<#
.SYNOPSIS
  Creates the IIS site + app pool for the QrBridge Gateway, configured so the background workers keep running.

.DESCRIPTION
  The InboxWorker and MaintenanceWorker live inside the Gateway's app pool, so IIS must behave like a service:
    - Start Mode AlwaysRunning + Preload Enabled + Application Initialization  -> starts at boot, no request needed
    - Idle Time-out 0                                                           -> never shuts down when quiet
    - No periodic (29h) recycle; one scheduled recycle at a quiet time instead
    - Max worker processes 1                                                    -> no web garden
    - Generous shutdown time so a worker can finish the current message

  Prerequisite: the ASP.NET Core 10 Hosting Bundle (installs the ASP.NET Core Module). Run 'iisreset' after installing it.

.EXAMPLE
  .\setup-iis.ps1 -Side Corp -PhysicalPath C:\inetpub\QrBridgeGateway -Port 80
#>
param(
    [ValidateSet("Corp", "Dmz")]
    [string]$Side = "Corp",
    [string]$SiteName = "QrBridgeGateway",
    [string]$AppPoolName = "QrBridgeGateway",
    [string]$PhysicalPath = "C:\inetpub\QrBridgeGateway",
    [int]$Port = 80,
    [string]$RecycleTime = "03:00:00"
)

$ErrorActionPreference = "Stop"

# ---- 1. IIS + Application Initialization feature ----
if (Get-Command Install-WindowsFeature -ErrorAction SilentlyContinue) {
    Install-WindowsFeature Web-Server, Web-AppInit, Web-Mgmt-Console | Out-Null          # Windows Server
} else {
    Enable-WindowsOptionalFeature -Online -All -NoRestart `
        -FeatureName IIS-WebServerRole, IIS-WebServer, IIS-ApplicationInit, IIS-ManagementConsole | Out-Null   # Windows client
}

# ---- 2. ASP.NET Core Module present? ----
$ancm = Join-Path $env:ProgramFiles "IIS\Asp.Net Core Module\V2\aspnetcorev2.dll"
if (-not (Test-Path $ancm)) {
    Write-Warning "ASP.NET Core Module not found. Install the .NET 10 'Hosting Bundle', then run 'iisreset' and re-run this script."
}

# ---- 2b. WCF HTTP Activation must NOT be installed ----
# The gateway answers the same *.svc / *.asmx / *.wsdl paths the real services used. With WCF HTTP Activation
# installed, IIS hands *.svc requests to .NET Framework WCF and they never reach the gateway.
$wcfFeatures = @()
if (Get-Command Get-WindowsFeature -ErrorAction SilentlyContinue) {
    $wcfFeatures = Get-WindowsFeature NET-WCF-HTTP-Activation45, NET-HTTP-Activation -ErrorAction SilentlyContinue | Where-Object Installed
} else {
    $wcfFeatures = Get-WindowsOptionalFeature -Online -ErrorAction SilentlyContinue |
        Where-Object { $_.FeatureName -in "WCF-HTTP-Activation45", "WCF-HTTP-Activation" -and $_.State -eq "Enabled" }
}
if ($wcfFeatures) {
    Write-Warning ("WCF HTTP Activation is installed ({0}). Remove it on this server, or *.svc calls will not reach the gateway." -f
        (($wcfFeatures | ForEach-Object { if ($_.Name) { $_.Name } else { $_.FeatureName } }) -join ", "))
}

Import-Module WebAdministration

# ---- 3. App pool ----
$poolPath = "IIS:\AppPools\$AppPoolName"
if (-not (Test-Path $poolPath)) { New-WebAppPool -Name $AppPoolName | Out-Null }

Set-ItemProperty $poolPath -Name managedRuntimeVersion -Value ""                        # No Managed Code (ASP.NET Core)
Set-ItemProperty $poolPath -Name startMode -Value "AlwaysRunning"
Set-ItemProperty $poolPath -Name processModel.identityType -Value "ApplicationPoolIdentity"
Set-ItemProperty $poolPath -Name processModel.idleTimeout -Value ([TimeSpan]::Zero)
Set-ItemProperty $poolPath -Name processModel.shutdownTimeLimit -Value ([TimeSpan]::FromSeconds(90))
Set-ItemProperty $poolPath -Name processModel.maxProcesses -Value 1
Set-ItemProperty $poolPath -Name recycling.periodicRestart.time -Value ([TimeSpan]::Zero)  # no 29-hour recycle
Clear-ItemProperty $poolPath -Name recycling.periodicRestart.schedule
Set-ItemProperty $poolPath -Name recycling.periodicRestart.schedule -Value @{ value = $RecycleTime }
Set-ItemProperty $poolPath -Name failure.rapidFailProtection -Value $true

# ---- 4. Site ----
New-Item -ItemType Directory -Force -Path $PhysicalPath | Out-Null
if (-not (Test-Path "IIS:\Sites\$SiteName")) {
    New-Website -Name $SiteName -Port $Port -PhysicalPath $PhysicalPath -ApplicationPool $AppPoolName | Out-Null
}
Set-ItemProperty "IIS:\Sites\$SiteName" -Name applicationPool -Value $AppPoolName
Set-ItemProperty "IIS:\Sites\$SiteName" -Name applicationDefaults.preloadEnabled -Value $true

# ---- 5. Point web.config at the right side (Corp/Dmz) if the app is already published there ----
$webConfig = Join-Path $PhysicalPath "web.config"
if (Test-Path $webConfig) {
    [xml]$xml = Get-Content $webConfig
    $env = $xml.SelectSingleNode("//aspNetCore/environmentVariables/environmentVariable[@name='ASPNETCORE_ENVIRONMENT']")
    if ($env) {
        $env.value = $Side
        $xml.Save($webConfig)
        Write-Host "web.config: ASPNETCORE_ENVIRONMENT=$Side"
    }
} else {
    Write-Host "No web.config yet in $PhysicalPath. Publish the Gateway there, then re-run (or edit ASPNETCORE_ENVIRONMENT by hand)."
}

Restart-WebAppPool -Name $AppPoolName -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "IIS ready: site '$SiteName' on port $Port, pool '$AppPoolName' (AlwaysRunning, idle 0, recycle at $RecycleTime)." -ForegroundColor Green
Write-Host "Check: http://localhost:$Port/health" -ForegroundColor Green
