#Requires -RunAsAdministrator
<#
.SYNOPSIS
  Creates the QrBridge folders and locks them down. Run once per machine (Corp and DMZ), as Administrator.

.DESCRIPTION
  Data folder : outbound.db + inbound.db. Both the Gateway (IIS app pool) and the Station (kiosk user) need Modify.
  Keys folder : DPAPI-protected *.key files. Only the Gateway app pool (Read) and Administrators/SYSTEM (Full).
                The Station never needs keys.

.EXAMPLE
  .\setup-folders.ps1 -KioskUser "MACHINE\qrkiosk"
#>
param(
    [string]$Root        = "C:\ProgramData\QrBridge",
    [string]$AppPoolName = "QrBridgeGateway",
    [Parameter(Mandatory = $true)]
    [string]$KioskUser
)

$ErrorActionPreference = "Stop"

$data = Join-Path $Root "Data"
$keys = Join-Path $Root "Keys"
New-Item -ItemType Directory -Force -Path $data, $keys | Out-Null

$pool = "IIS AppPool\$AppPoolName"

# Well-known SIDs so this works on non-English Windows: *S-1-5-18 = SYSTEM, *S-1-5-32-544 = Administrators
Write-Host "Data folder: $data"
icacls $data /inheritance:r `
    /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" `
    "${pool}:(OI)(CI)M" "${KioskUser}:(OI)(CI)M" | Out-Host

Write-Host "Keys folder: $keys"
icacls $keys /inheritance:r `
    /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "${pool}:(OI)(CI)R" | Out-Host

Write-Host ""
Write-Host "Done. If the app pool doesn't exist yet, run setup-iis.ps1 first and re-run this script." -ForegroundColor Green
Write-Host "Keep these folders on a LOCAL disk. Never point DataFolder at a network share." -ForegroundColor Yellow
