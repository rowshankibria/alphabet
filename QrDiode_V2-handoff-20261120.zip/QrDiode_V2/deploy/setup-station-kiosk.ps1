#Requires -RunAsAdministrator
<#
.SYNOPSIS
  Prepares a machine to run the QrBridge Station unattended (kiosk-style). Run once per machine as Administrator.

.DESCRIPTION
  - Power plan: never sleep, never turn the display off, no hibernate (the camera must always see the screen)
  - Screensaver off for the kiosk user
  - Starts the Station automatically when the kiosk user logs on, and restarts it if it exits (scheduled task)

  NOT done here (do it deliberately, per your security policy):
  - Automatic logon for the kiosk account (e.g. Sysinternals Autologon) — needs a stored credential
  - Windows Update active hours / maintenance window
  - Physically fixing the screen and camera, and controlling the lighting

.EXAMPLE
  .\setup-station-kiosk.ps1 -KioskUser "MACHINE\qrkiosk" -StationExe "C:\QrBridge\Station\QrBridge.Station.exe" -Side Corp
#>
param(
    [Parameter(Mandatory = $true)] [string]$KioskUser,
    [Parameter(Mandatory = $true)] [string]$StationExe,
    [ValidateSet("Corp", "Dmz")] [string]$Side = "Corp"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $StationExe)) { throw "Station executable not found: $StationExe" }

# ---- Power ----
powercfg /change standby-timeout-ac 0
powercfg /change monitor-timeout-ac 0
powercfg /change hibernate-timeout-ac 0
powercfg /hibernate off
Write-Host "Power: sleep/display-off/hibernate disabled on AC power."

# ---- Screensaver off (machine-wide policy) ----
$policy = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Control Panel\Desktop"
New-Item -Path $policy -Force | Out-Null
Set-ItemProperty -Path $policy -Name ScreenSaveActive -Value "0"
Write-Host "Screensaver disabled by policy."

# ---- Auto-start + auto-restart via Task Scheduler ----
$taskName = "QrBridge Station ($Side)"
$action   = New-ScheduledTaskAction -Execute $StationExe -Argument "--environment $Side" -WorkingDirectory (Split-Path $StationExe)
$trigger  = New-ScheduledTaskTrigger -AtLogOn -User $KioskUser
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
            -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) `
            -MultipleInstances IgnoreNew
$principal = New-ScheduledTaskPrincipal -UserId $KioskUser -LogonType Interactive -RunLevel Limited

Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings `
    -Principal $principal -Force | Out-Null
Write-Host "Scheduled task '$taskName' registered: starts at logon of $KioskUser, restarts on failure."

Write-Host ""
Write-Host "Done. Also: set up auto-logon for $KioskUser per your policy, and run setup-folders.ps1 with -KioskUser $KioskUser." -ForegroundColor Green
