<#
.SYNOPSIS
  Builds the deployables of the QR air-gap bridge from this one solution.

.DESCRIPTION
  publish\gateway\   QrBridge.Gateway  -> copy to the IIS site folder (setup-iis.ps1), one per side (Corp, DMZ)
  publish\sender\    QrDiode.Sender    -> self-contained single-file exe for the kiosk PC (no .NET install needed)
  publish\receiver\  QrDiode.Receiver  -> self-contained single-file exe for the kiosk PC
  publish\keys\      QrDiode.KeyCeremony -> console exe for the key ceremony

  The gateway is framework-dependent: the IIS server needs the .NET 10 Hosting Bundle anyway (for the
  ASP.NET Core Module). QrBridge.Shared is compiled into the gateway and the WPF apps; it is not deployed alone.

.EXAMPLE
  .\deploy\publish.ps1
  .\deploy\publish.ps1 -Configuration Release -Output D:\drop
#>
param(
    [string]$Configuration = "Release",
    [string]$Output = (Join-Path $PSScriptRoot "..\publish"),
    [string]$Runtime = "win-x64"
)

$ErrorActionPreference = "Stop"
$root = Resolve-Path (Join-Path $PSScriptRoot "..")
New-Item -ItemType Directory -Force -Path $Output | Out-Null
$Output = Resolve-Path $Output

function Publish([string]$project, [string]$target, [string[]]$extra) {
    Write-Host "Publishing $project -> $target" -ForegroundColor Cyan
    # dotnet may write to stderr; with "Stop" Windows PowerShell 5.1 would abort on it. Check the exit code instead.
    $ErrorActionPreference = "Continue"
    & dotnet publish (Join-Path $root $project) -c $Configuration -o (Join-Path $Output $target) -nologo @extra
    $ErrorActionPreference = "Stop"
    if ($LASTEXITCODE -ne 0) { throw "Publishing $project failed." }
}

$singleFile = @("-r", $Runtime, "--self-contained", "true",
                "-p:PublishSingleFile=true", "-p:IncludeNativeLibrariesForSelfExtract=true")

Publish "src\QrBridge.Gateway\QrBridge.Gateway.csproj" "gateway" @()
Publish "src\QrDiode.Sender\QrDiode.Sender.csproj" "sender" $singleFile
Publish "src\QrDiode.Receiver\QrDiode.Receiver.csproj" "receiver" $singleFile
Publish "src\QrDiode.KeyCeremony\QrDiode.KeyCeremony.csproj" "keys" $singleFile

Write-Host ""
Write-Host "Done: $Output" -ForegroundColor Green
Write-Host "Note: the next normal build of the WPF projects may fail ONCE with BG1002/CS2001 (missing .baml/.g.cs in obj)." -ForegroundColor Yellow
Write-Host "      That is a WPF incremental-build quirk after a RID-specific publish; build again (scripts\verify.ps1 retries)." -ForegroundColor Yellow
Write-Host "  gateway\   -> IIS site folder; set ASPNETCORE_ENVIRONMENT (Corp/Dmz) with deploy\setup-iis.ps1" -ForegroundColor Green
Write-Host "  sender\, receiver\, keys\ -> kiosk PC (run as the kiosk user)" -ForegroundColor Green
