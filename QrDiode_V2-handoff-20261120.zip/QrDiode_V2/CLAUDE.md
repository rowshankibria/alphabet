# CLAUDE.md

The agent instructions for this solution are in **[.github/copilot-instructions.md](.github/copilot-instructions.md)**.
That file is the single source of truth for GitHub Copilot (the assistant on the project machine) and for Claude Code.
Next to it:
- path-specific rules in `.github/instructions/`;
- reusable task prompts in `.github/prompts/`;
- custom agents in `.github/agents/`.

Then read:
- [docs/HANDOFF.md](docs/HANDOFF.md): state, decisions, known issues, next steps;
- [docs/bridge/Integration-Plan.md](docs/bridge/Integration-Plan.md): the design of the remaining work.

@.github/copilot-instructions.md
