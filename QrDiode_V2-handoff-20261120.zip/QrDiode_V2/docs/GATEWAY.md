# QrBridge Gateway — generic SOAP stand-in

> One-page reference. The full explanation — why WCF calls are hard to carry across the air gap, how the gateway
> solves each issue, data, security, operations, deployment and status — is in
> [bridge/QR-Bridge-Guide.md](bridge/QR-Bridge-Guide.md).

The gateway sits where the real services used to be. In islanding mode the load balancer (Corp side) or the
FMS interface configuration (DMZ side) sends callers here, unchanged. The gateway:

1. **accepts any SOAP request** — SOAP 1.1 or 1.2, document/literal (WCF, ASMX) or RPC/encoded (SOAP Toolkit
   `*.WSDL` endpoints), with or without WS-Addressing — without knowing the service's contract;
2. **stores the request bytes exactly as received** in `outbound.db` (sealed with AES-256-GCM), then
3. **replies like the real service** (`<RESPONSE><RETURN_CODE>0…`, a `long`, an `int`, or an automatic reply);
4. on the other side, **replays** requests that arrived over the QR link to the real service — same bytes,
   same `SOAPAction`, same path — and records what the service answered.

Design background: the [design record PDF](reference/QR-AirGap-Bridge-Design-Record.pdf). The remaining work is
designed in [bridge/Integration-Plan.md](bridge/Integration-Plan.md). On a new machine, start with [HANDOFF.md](HANDOFF.md).

## Projects

| Project | Deployed as | Role |
|---|---|---|
| `src/QrBridge.Gateway` | IIS site | Ingress (callers → Outbox), egress worker (Inbox → real services), maintenance, `/health` |
| `src/QrBridge.Shared` | compiled into the gateway and the QrDiode apps | EF Core + SQLite (`outbound.db`, `inbound.db`), envelope crypto, DPAPI keys, named-event doorbells |
| `tests/QrBridge.Tests` | — | Unit + integration tests (real WCF clients, the simulator's 43 message templates, end-to-end) |

`deploy/publish.ps1` builds everything: `publish/gateway` (IIS) and `publish/sender`, `publish/receiver`,
`publish/keys` (self-contained exe files for the kiosk PC).

## How a call is handled

```
POST /FMS_SSO2FMSInterface/SSO2FMSInterface.svc   SOAPAction: "http://tempuri.org/ISSO2FMSInterface/SendToFMS"
  1. body read (max Bridge:MaxPayloadBytes)                       too big          -> 413 + SOAP fault
  2. SOAP envelope parsed (DTDs prohibited)                        not SOAP         -> 400 + SOAP fault
  3. route = path in routes.json; operation = SOAP body element    not listed      -> SOAP fault (allow-list)
  4. Mode:
       Echo         -> reply with the request value (EchoString)
       Unavailable  -> reply "not available while islanded" (RETURN_CODE 1599) — queries can't cross the gap
       Bridge       -> MESSAGE/@TYPE on the allow-list?           no               -> RETURN_CODE 1597
                       backlog below Gateway:MaxBacklog?          no               -> RETURN_CODE 1598
                       store in Outbox, commit, ring the doorbell, THEN reply RETURN_CODE 0
```

The reply carries the response header `X-QrBridge-MessageId` (the bridge's id for the stored message).

## The route catalogue: `src/QrBridge.Gateway/routes.json`

One file, deployed to both sides. Each service lists the paths callers use, its style, and its operations:

```json
{ "Name": "SSO2FMS", "IngressSide": "Corp",
  "Paths": [ "/FMS_SSO2FMSInterface/SSO2FMSInterface.svc" ],
  "Style": "Document", "Wsdl": "SSO2FMS",
  "Operations": {
    "SendToFMS":  { "Mode": "Bridge", "Reply": "FmsResponse", "AllowedTypes": [ "SSO_RESPONSE", "RETURN_ORDER" ] },
    "GetFromFMS": { "Mode": "Unavailable", "Reply": "FmsResponse" },
    "EchoString": { "Mode": "Echo" } } }
```

**Adding a service needs no code:** add an entry, copy its WSDL to `Wsdl/<Name>/service.wsdl` (plus
`xsd0.xsd`, `xsd1.xsd`… for WCF), and set its egress target on the delivering side. Reply profiles
(`FmsResponse`, `ReturnCode`) are defined once at the top of the file.

`Routing:AcceptUnlisted = true` makes the gateway accept **any** SOAP service not in the catalogue, with an
automatic reply (`<OpResponse/>` — WCF reads it as null / default / void). Use it to test or discover a new
service; keep it `false` in production so only listed services pass.

Shipped catalogue (from the fms-interface-simulator): FC2FMS, FOD2FMS, SSO2FMS, SSO2TOMS, SSO2TLS, SSO2DSO,
FTC2FMS (WCF), VZ2TLS (ASMX), DSS2FMS and the six legacy `RR_*.WSDL` endpoints (SOAP Toolkit), plus XA2FMS,
IR2BFC and RegisteredTags as "Unavailable" (they need live answers). The DMZ → Corp services are not in the
simulator repository yet.

## Delivery on the other side (`Gateway:Egress`)

The target URL comes from **this side's configuration only**, never from the message:
`Egress:Targets:<Service>:Url`, else `Egress:DefaultBaseUrl` + the caller's original path. On the DMZ the RR
servers host the same paths as before, so one `DefaultBaseUrl` covers every service.

| Real service answers | Inbox status |
|---|---|
| RETURN_CODE 0 / return code 0 / HTTP 202 | Done (`DownstreamResult` keeps the answer) |
| RETURN_CODE ≠ 0, return code ≠ 0, SOAP fault | DeadLetter — refused; never retried automatically |
| 404 / 401 / 403 / 415… | DeadLetter — configuration problem |
| timeout, network error, 5xx without fault, 429 | Failed → retried with backoff (`MaxAttempts`, then DeadLetter) |
| bad signature, wrong direction, not in catalogue | Rejected |

## Run it locally

```powershell
dotnet build QrDiode.slnx
dotnet test tests\QrBridge.Tests                      # 136 tests, ~3 s
# a real gateway on http://localhost:5080 (dev data under C:\QrBridgeDev):
src\QrBridge.Gateway\bin\Debug\net10.0-windows\QrBridge.Gateway.exe keys generate --id c2d-2026-11 --dir C:\QrBridgeDev\Keys
dotnet run --project src\QrBridge.Gateway --launch-profile "Gateway (Corp)"
```

## Limits (true of any generic proxy)

- **Message-level security** (WS-Security signing/encryption, secure conversation), reliable sessions and duplex
  callbacks cannot be replayed. None of the FMS services in the simulator use them.
- **Replies that carry live data** (queries) cannot cross the air gap: those operations are `Unavailable`.
- **Unlisted operations** get an empty reply; a caller that reads a result needs a catalogue entry with a reply profile.
- Behind a load balancer that terminates TLS, `?wsdl` addresses show `http://` (forwarded headers are not applied yet).
