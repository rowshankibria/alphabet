# Handoff — QR Air-Gap Bridge, 20 Nov 2026

This file carries everything from the working sessions that is not obvious from the code: how the project got here,
what was decided and why, the exact verification state, known issues, next steps and how to get going on a new
machine. On the new machine the AI assistant is **GitHub Copilot**, which knows nothing of the working sessions.
**This file and [../.github/copilot-instructions.md](../.github/copilot-instructions.md) are that memory.**

## 1. Read in this order

1. [../.github/copilot-instructions.md](../.github/copilot-instructions.md): rules, settled decisions, map, known
   issues (short). Copilot loads it on every request; the rest of the Copilot set-up is described in §6.
2. This file: the detail.
3. [bridge/QR-Bridge-Guide.md](bridge/QR-Bridge-Guide.md): how the gateway and the whole project work.
4. [bridge/Integration-Plan.md](bridge/Integration-Plan.md): the design of the work that remains (connecting QrDiode,
   islanding operations, remaining gateway items) and the order to do it in.
5. When you need the inputs: [reference/README.md](reference/README.md), which lists the design record PDF, the
   architecture diagram notes and the fms-interface-simulator. The simulator is a local copy that is not in the
   repository (§6).
6. For WPF work (Rowshan is new to WPF): [WPF-Tutorial.md](WPF-Tutorial.md), QrDiode's [ARCHITECTURE.md](ARCHITECTURE.md)
   and [USER_GUIDE.md](USER_GUIDE.md).

## 2. How this folder came about

| When | Where | What happened |
|---|---|---|
| 19 Nov 2026 | claude.ai | Design conversation → [design record PDF](reference/QR-AirGap-Bridge-Design-Record.pdf): constraints, decisions D1–D14, schema, envelope, IIS settings, a review of QrDiode V2 (one critical receiver bug, fixed there in a separate zip). Deliverables: `QrBridge.zip` (CoreWCF prototype, never compiled) and `QrDiode_V2_reviewed.zip`. |
| 19 Nov | Claude Code, machine 1 | Read the PDF. Found that the QrDiode copy in the workspace is the **original** V2 — the reviewed receiver fix is not in it. |
| 19 Nov | Claude Code | Read the [fms-interface-simulator docs](reference/fms-interface-simulator/docs/README.md): every bridged operation is "one XML string in, one value out" over SOAP; some operations are queries that need a live answer; there are WCF, ASMX and SOAP Toolkit (RPC/encoded) services. |
| 19 Nov | Rowshan | Both directions go through a gateway + QR: Corp → DMZ = load balancer → gateway → QR; DMZ → Corp = gateway → QR → camera. Callers call load-balancer URLs (e.g. `https://a/doservice.svc` → LB `https://di/`) and **cannot be changed**. Shared the architecture diagram ([transcription](reference/fms-bidirectional-qr-proxy-architecture.md)): islanding mode, LB switch, ECC/AECC. |
| 19 Nov | Claude Code | Wrote a design proposal for the gateway and the QrDiode changes. The gateway was then built differently: routing by path + body element instead of SOAPAction, the raw SOAP bytes instead of a JSON payload, no ACK files. On 20 Nov the proposal was retired, and its still-valid parts moved into [bridge/Integration-Plan.md](bridge/Integration-Plan.md). |
| 20 Nov | Rowshan | Decided: generic gateway that handles **any** WCF request; one solution in `QrDiode_V2` with Gateway + Shared + QrDiode; keep the QrDiode project structure but implement the features (EF SQLite) inside; gateway → IIS, WPF → exe. Installed the released .NET 10 SDK (10.0.404). |
| 20 Nov | Claude Code | Copied the reusable parts of the QrBridge prototype in, replaced CoreWCF with the generic gateway, built the delivery side, the route catalogue, WSDL serving, 136 tests, publish/verify/smoke/pack scripts and the docs; made this folder self-contained for the move to another machine. |
| 20 Nov | Rowshan, Claude Code | The new machine has **GitHub Copilot only**. The agent instructions moved to `.github/`: repository instructions, path-specific rules, a prompt for each next step and two custom agents. `CLAUDE.md` now only points there. Reviewed the workspace docs: the WPF tutorial is kept and updated ([WPF-Tutorial.md](WPF-Tutorial.md)), and the design proposal is retired (row above). Added `scripts/check-links.ps1`. |

## 3. Decisions log

| # | Decision | By | Why |
|---|---|---|---|
| 1 | The gateway impersonates the existing endpoints exactly (paths, SOAPActions, reply shapes) | Rowshan (constraint) | Callers are not ours and only go through the corporate LB |
| 2 | **Generic SOAP gateway**, no CoreWCF; it must handle any WCF request | Rowshan | No per-service code; works for RPC/encoded (DSS); payload passes through verbatim; new services are configuration |
| 3 | One solution `QrDiode.slnx`; keep QrDiode project structure; implement EF SQLite features inside the QrDiode apps | Rowshan | One codebase; QrDiode stays recognisable |
| 4 | Deployables: gateway → IIS, WPF → exe; `QrBridge.Shared` compiled into both | Rowshan | Matches the two-programs-per-machine constraint |
| 5 | Stay on .NET 10 LTS (packages 10.0.15) although .NET 11 is out; `global.json` pins 10.0 | agent | LTS, and QrDiode was built on 10 |
| 6 | Copy (not move) the prototype parts; the original `QrBridge/` folder stays as history | agent | Nothing lost |
| 7 | Service is found by **path**, operation by the **SOAP body element** (not by SOAPAction) | agent | Five legacy endpoints share one SOAPAction; body element works for every style |
| 8 | Store the request as `RawSoapMessage` (exact bytes + SOAPAction + Content-Type) inside the existing AES-GCM envelope | agent | Verbatim replay; encryption at rest and in transit unchanged (D8) |
| 9 | Envelope header gained a plain (authenticated) `BusinessType` label | agent | Operators and the QR receiver can see what a row is without decrypting; it is not business data |
| 10 | Queries → **Unavailable** mode (`RETURN_CODE 1599` for FMS, SOAP fault for XA/BFC, 503 for Registered Tags) | agent, recommended; Q3 open | A live answer cannot cross the gap; a clean error beats a hang |
| 11 | Backlog full → `RETURN_CODE 1598` (not a SOAP fault); message type not allowed → `1597` | agent, recommended; codes to confirm | Callers already show `ERROR_MESSAGE` for non-zero codes |
| 12 | Allow-list per operation (`AllowedTypes`) mirroring what each real service accepts | agent | Refuse at once, while the caller is on the line, instead of a dead letter an hour later |
| 13 | Real-service refusals (non-zero code, fault) → **DeadLetter** with `DownstreamResult`; never retried automatically | agent; Q4 open | Retrying a business refusal cannot succeed and could duplicate side effects |
| 14 | Egress target only from configuration: `Targets[service]` or `DefaultBaseUrl` + original path | agent | A message can never choose where it is sent |
| 15 | Removed from the prototype: CoreWCF samples, typed clients/handlers, `PayloadSerializer`, `FrameCodec`, the `InboundChunk` table, `QrBridge.Station` | agent | Superseded by the generic gateway and by QrDiode (D12) |
| 16 | Unlisted services refused by default; `Routing:AcceptUnlisted` for test/discovery | agent | Allow-list in production (D7); "any WCF request" when needed |
| 17 | Agent instructions live in `.github/` (`copilot-instructions.md`, `instructions/`, `prompts/`, `agents/`); `CLAUDE.md` only points there | Rowshan (the new machine has Copilot only) | One source of truth, whichever assistant is used |
| 18 | The project moves through GitHub. Build output and the fms-interface-simulator copy stay out of the repository (`.gitignore`), and the handoff zip matches | Rowshan (the new machine already has the simulator) | A small repository; the simulator stays in its own project; the code uses its own copies (`tests/QrBridge.Tests/Samples`, `src/QrBridge.Gateway/Wsdl`) |

The design record's D1–D14 still stand; how each was implemented or changed is in
[the guide, Appendix B](bridge/QR-Bridge-Guide.md#appendix-b-design-record-decisions-and-what-changed).

## 4. What was built (summary)

- **`src/QrBridge.Gateway`** — generic SOAP ingress (SOAP 1.1/1.2, WS-Addressing, document/literal, RPC/encoded),
  route catalogue `routes.json` (18 entries from the simulator), reply profiles, allow-lists, backpressure, WSDL/XSD
  serving with address rewriting, health page; egress worker that replays byte for byte and classifies the real
  service's answer (Done / Failed+retry / DeadLetter / Rejected); maintenance; `/health`; key tool.
- **`src/QrBridge.Shared`** — EF Core + SQLite (`outbound.db`, `inbound.db`), the sealed envelope, `RawSoapMessage`,
  DPAPI key store, named-event doorbells. Data registration reads options lazily (testable).
- **`tests/QrBridge.Tests`** — 136 tests: every simulator message template through the real gateway, real WCF client
  stacks (BasicHttp, XmlSerializer, WSHttp SOAP 1.2 + WS-Addressing), end-to-end Corp → DMZ → fake real service.
- **`deploy/publish.ps1`**, `setup-iis.ps1` (now warns about WCF HTTP Activation), `setup-folders.ps1`,
  `setup-station-kiosk.ps1`; **`scripts/verify.ps1`, `smoke-gateway.ps1`, `check-links.ps1`, `pack-handoff.ps1`**;
  `global.json`; `.gitignore`.
- **Docs**: the guide, the [Integration Plan](bridge/Integration-Plan.md), GATEWAY.md, this file, the WPF tutorial and
  `docs/reference/`. The **Copilot set-up** is in `.github/` (§6).
- **Not touched:** the QrDiode projects' code (Core, Sender, Receiver, KeyCeremony) — identical to the original V2.

## 5. Verification state at handoff

On machine 1 (Windows, SDK 10.0.404), 20 Nov 2026:

| Check | Result |
|---|---|
| `dotnet build QrDiode.slnx` | succeeded, 0 warnings, 0 errors |
| `tests/QrBridge.Tests` | **136/136 passed**, stable over repeated runs (~2–3 s) |
| `tests/QrDiode.Core.Tests` | **75/75 passed** (including the optical loopback tests) |
| `scripts/verify.ps1` | passed |
| `scripts/smoke-gateway.ps1` | passed: HTTP 200, `RETURN_CODE 0`, WSDL address rewritten, `/health` healthy, 1 message queued |
| `deploy/publish.ps1` | gateway folder (23 files incl. `routes.json`, `web.config`, `Wsdl/`), Sender ~134 MB, Receiver ~139 MB, KeyCeremony ~70 MB single-file exe |
| **Clean copy** — the handoff zip (`QrDiode_V2-handoff-20261120.zip`, 566 files, 2.1 MB) extracted into an empty folder and checked from scratch | `scripts/verify.ps1`: build 0 warnings / 0 errors, **136 + 75 passed**; `scripts/smoke-gateway.ps1`: passed. Nothing outside the folder is needed. |
| Re-pack after the Copilot set-up, without the simulator copy (same zip name, 252 files, 1.6 MB), checked again as a **clean copy** | Unzipped with `Expand-Archive` into an empty short folder: `scripts/verify.ps1` gave build 0 warnings / 0 errors and **136 + 75 passed**, and `scripts/smoke-gateway.ps1` passed. `git add .` would take the same 252 files (3.1 MB). `scripts/check-links.ps1` finds 0 broken links whether or not the simulator copy is present (the 4 links into it are skipped when it is absent). |

The first clean-copy attempt, at a ~180-character path, failed one QrDiode test (`ZXing.dll` path over Windows'
260-character limit) — hence the short-path rule in §6. It also exposed a script bug (Windows PowerShell 5.1 turning a
test's stderr line into a terminating error), which is fixed in `verify.ps1`, `smoke-gateway.ps1` and `publish.ps1`.

Not verified yet: IIS hosting on a real server, the load balancer in front, the fms-interface-simulator application
itself pointed at the gateway, anything involving a camera and screen.

## 6. Setting up a new machine

**Prerequisites**

- Windows 10/11 or Windows Server; PowerShell 5.1+.
- A released **.NET 10 SDK** (`dotnet --list-sdks` shows `10.0.x`). `global.json` refuses other majors on purpose.
- Internet access to nuget.org for the first restore (or a configured offline feed).
- VS Code with the C# Dev Kit and **GitHub Copilot** (Chat) extensions, or Visual Studio 2022/2026 (it has the XAML
  designer, and Copilot works there too).
- Later: IIS + Application Initialization + .NET 10 Hosting Bundle to test hosting; a webcam and a second screen for
  the QR apps.

**Steps**

1. Put the folder at a **short path**, e.g. `C:\src\QrDiode_V2`: `git clone` the repository there, or unzip the
   handoff package. Never copy `bin`/`obj` (~650 MB of build output). Deep paths break native DLL loading: Windows
   refuses to load `ZXing.dll` from a build folder whose path passes ~260 characters (seen in the clean-copy check,
   see §7).
   - Unzipping: Windows' built-in zip is enough. If the zip was downloaded in a browser, first right-click it →
     Properties → tick **Unblock** → OK, then **Extract All…** to `C:\src`. Otherwise every file is marked as
     downloaded from the internet, and PowerShell refuses to run the scripts.
   - The fms-interface-simulator copy is not in the repository or the zip. If you want the doc links to it to work,
     copy your simulator folder (the one that contains `docs\` and `simulator\`) to
     `docs\reference\fms-interface-simulator\`. The build and the tests don't need it.
2. In the `QrDiode_V2` folder: `.\scripts\verify.ps1` → expect 0 warnings, 136 + 75 passed.
3. `.\scripts\smoke-gateway.ps1` → expect "Smoke test passed".
4. Open the `QrDiode_V2` folder **itself** in VS Code, as the workspace root, so Copilot finds `.github/`. In Copilot
   Chat, choose **Agent** mode and run `/verify-solution`.

**Working with GitHub Copilot.** Everything an assistant needs is in the folder:

| File | What Copilot does with it |
|---|---|
| `.github/copilot-instructions.md` | Loaded on every chat request: settled decisions, rules, map, known issues, next steps |
| `.github/instructions/*.instructions.md` | Loaded when the files you work on match: gateway + shared data, QrDiode WPF, tests, scripts, docs |
| `.github/prompts/*.prompt.md` | Reusable tasks; type `/` in Chat: `/verify-solution`, `/fix-receive-engine-bug`, `/add-bundles-and-outbox-status`, `/connect-sender-to-outbox`, `/connect-receiver-to-inbox`, `/add-bridged-service`, `/update-handoff` |
| `.github/agents/*.agent.md` | Custom agents in the Chat agent picker: `bridge-architect` (design and review), `wpf-mentor` (WPF explained with Angular analogies) |

Steps 1–4 in §9 each have a matching prompt. Run them in order, check each result, then run `/update-handoff`. If
`/` doesn't list the prompts, or the agents are missing, update VS Code and the Copilot Chat extension.

**What does not travel:** the AI session memory from machine 1 (this file and `.github/` replace it), and the local
databases and keys (`C:\ProgramData\QrBridge`,
`C:\QrBridgeDev`) — recreate dev keys with `QrBridge.Gateway.exe keys generate --id c2d-2026-11 --dir C:\QrBridgeDev\Keys`
(and `d2c-2026-11`); production keys are made in the key ceremony, never copied.

## 7. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `A compatible .NET SDK was not found` | `global.json` wants a 10.0 SDK. Install the .NET 10 SDK. |
| `… cannot be loaded because running scripts is disabled on this system` | Windows' default script policy. Run once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`. Alternatively, start a script with `powershell -ExecutionPolicy Bypass -File …`. |
| `… is not digitally signed`, or other "downloaded from the internet" warnings | The files carry the downloaded-from-the-internet mark. In the solution folder run `Unblock-File -Path (Get-ChildItem -Recurse -File).FullName`. Next time, unblock the zip before extracting it (§6). |
| `DllNotFoundException: Unable to load DLL 'ZXing' … The filename or extension is too long (0x800700CE)` (QrDiode optical loopback test, Receiver) | The folder is too deep: the native DLL path passes Windows' 260-character limit. Move the solution to a short path such as `C:\src\QrDiode_V2`. (`verify.ps1` warns when the folder path is over 100 characters.) |
| Restore fails (NU1301 etc.) | No access to nuget.org: check proxy/firewall; `dotnet nuget list source`. |
| `BG1002 …baml cannot be found` or `CS2001 …g.cs could not be found` in `src/QrDiode.*/obj` | WPF incremental-build quirk right after `deploy\publish.ps1` (a RID-specific publish). Build again; `verify.ps1` retries once automatically. If it persists, delete that project's `obj` folder. |
| NU1605 "detected package downgrade" when the Receiver/Sender reference `QrBridge.Shared` | Align `Microsoft.Data.Sqlite` / `SQLitePCLRaw.*` versions (Known issue 4). |
| Gateway won't start: "Outbound key … cannot be loaded" | Key file missing or created under another machine's DPAPI. Generate/import it on this machine. |
| Gateway won't start: "Invalid route catalogue" | `routes.json` error; the message lists each problem. |
| Gateway won't start: "LockTimeoutMinutes must be longer than every egress timeout" | Raise `Gateway:LockTimeoutMinutes` or lower `Egress:TimeoutSeconds`. |
| Log warning "Signal … unavailable; falling back to polling only" | Named event could not be created/opened (permissions). Harmless: polling every 2 s still works. |
| `SQLite Error 14: unable to open database file` | Data folder missing or no Modify permission (`deploy\setup-folders.ps1`). |
| Schema errors after changing an entity | `EnsureCreated` does not upgrade: delete the dev `outbound.db`/`inbound.db` (no migrations yet). |
| `smoke-gateway.ps1`: "did not start" | Port in use (`-Port 5190`), or read the logs it names. Long output lines may wrap in Windows PowerShell logs — that is cosmetic. |
| In IIS, `*.svc` calls never reach the gateway | WCF HTTP Activation is installed, or the app pool is not "No Managed Code" (`deploy\setup-iis.ps1` warns). |
| Tests: integration tests can't start the gateway | They need Windows (DPAPI, named events). Rebuild the test project so `Microsoft.AspNetCore.Mvc.Testing` regenerates its content-root manifest. |
| Copilot ignores the project rules, or `/` shows no prompts | The workspace root must be the `QrDiode_V2` folder (not a parent folder). Update VS Code and the Copilot Chat extension. |

## 8. Known issues (detail)

| # | Issue | Where | Notes |
|---|---|---|---|
| 1 | One partly received QR session blocks every later session until restart | `src/QrDiode.Core/Pipeline/ReceiveEngine.cs`, `FeedManifest` (`if (_manifest is not null) return FeedResult.Ignored;`) | Fix per design record §10, refined in [Integration-Plan.md](bridge/Integration-Plan.md) §2.1 (prompt `/fix-receive-engine-bug`). Repeats of the current session are still ignored. A *different* manifest that passes parse + signature + addressed-to-us + not-settled + anti-replay abandons the partial session (`SessionAbandoned` event / `AbandonedSession` record) and locks onto the new one. While locked, a different manifest that fails a check is `Ignored`, not `Rejected`, because the Receiver resets the engine on every rejection. Receiver UI: an "Incomplete … NOT received — must be re-sent" row and a `receive.abandoned` audit event. Add `SessionAbandonTests`. |
| 2 | Sender drops the oldest queued items beyond 14 | `src/QrDiode.Sender/Transmit/TransmitEngine.cs` (`MaxQueueDepth`, `TrimQueue`) | For Outbox items: claim only when the engine queue is empty; never drop. |
| 3 | Anti-replay watermark committed before the payload is stored | `ReceiveEngine.FinishTransfer` → `_replayGuard.Commit` | Return the transfer uncommitted; the host commits after the Inbox transaction. |
| 4 | SQLite package mismatch | Receiver: `Microsoft.Data.Sqlite` 10.0.10, `SQLitePCLRaw.bundle_e_sqlite3` 3.0.5; Shared: EF Core 10.0.15 → SQLitePCLRaw 2.1.13 | Align when wiring EF into the Receiver. |
| 5 | Outbox rows never leave `Pending` yet | no QR sender integration | Add `Aired` (and later `Confirmed`) status; retention then purges them. |
| 6 | No EF migrations | `DatabaseInitializer` uses `EnsureCreated` | Create migrations (Shared has design-time factories) before go-live. |
| 7 | FOD WCF WSDL missing; DSS WSDL derived | `src/QrBridge.Gateway/Wsdl/` | Capture the real files. |
| 8 | `?wsdl` shows `http://` behind TLS termination | `MetadataEndpoint` | Add forwarded-headers handling once the LB setup is known. |
| 9 | Kiosk script assumes one "Station" app | `deploy/setup-station-kiosk.ps1` | Adapt for Sender and Receiver (two scheduled tasks). |
| 10 | DMZ → Corp services not in the catalogue | `routes.json` | Capture the corporate endpoints the FMS clients call (record mode would help). |

## 9. Next steps, with "done when"

| # | Step | Done when |
|---|---|---|
| 1 | Fix Known issue 1 + tests | 75 + the new `SessionAbandonTests` pass; a partial session followed by a new one is received; a forged or replayed manifest cannot force an abandon |
| 2 | Shared: bundle codec (`QBB1`: magic, version, count, firstSeq, lastSeq, length-prefixed envelopes; bounded parser), Outbox `Aired` + `BundleId`, `QrSessionId`, `AiredUtc`; store methods (claim bundle, mark aired, release, reset sending); first EF migrations, with a baseline for databases made by `EnsureCreated` | codec tests incl. malformed input; migration applies to fresh and existing DBs |
| 3 | Sender: `Sender:Source = Outbox`; claim only when the stage queue is empty; bundle (≤ 50 messages / 128 KB); a new `ItemFinished` event for every final state → Aired / release (`SessionEnded` fires only for items that went on air); startup Sending → Pending; wait on the Outbox doorbell; unattended start; `SenderLoop` heartbeat | a gateway call appears on the stage within ~1 s and ends Aired; killing the sender mid-session re-airs after restart; 200 concurrent calls air as bundles; nothing dropped |
| 4 | Receiver: `.qbb` → parse → `PeekHeader` → direction check → Inbox insert for all (one transaction, idempotent) → Inbox doorbell; deferred anti-replay commit (`CommitReplay()` after the Inbox commit; `Reset(settle: false)` if the write fails); `ReceiverLoop` heartbeat; package alignment | end to end on one PC (screen + webcam, or an optical loopback test): the DMZ worker reaches Done; a duplicate bundle is not reprocessed |
| 5 | Islanding operations: `/status` (per-route depth, oldest age, drained flag), stop-accepting switch, switch-back procedure | scripted switch-in/switch-back drill with zero lost or reordered messages |
| 6 | Record mode (transparent proxy that saves requests, replies, WSDLs) | one run against a test service produces the files |
| 7 | DMZ → Corp catalogue; FOD WSDL; forwarded headers; per-order head-of-line blocking; dual-site; receipts (after sign-off) | per item |

The detailed design of these steps is in [bridge/Integration-Plan.md](bridge/Integration-Plan.md). Steps 1–4 each have a
ready Copilot prompt: `/fix-receive-engine-bug`, `/add-bundles-and-outbox-status`, `/connect-sender-to-outbox` and
`/connect-receiver-to-inbox`.

## 10. Open questions for Rowshan

1. Queries in islanding mode: keep "Unavailable" (1599), or build snapshot caching later?
2. Are the bridge's codes 1597 / 1598 / 1599 acceptable to the Rapid Restore team?
3. Do XA/21, BFC and the Registered Tags report cross the CorpNet/DMZ gap at all?
4. Load balancer: does it forward the path unchanged? Where is TLS terminated? Health-probe URL? How many servers
   behind it (it must send everything to one gateway; a second only as standby)?
5. Payloads and endpoints for MAXIMO, OSS, NRI, Feeder Status (on the architecture diagram, not in the simulator).
6. Dual site (ECC/AECC): move queued rows on failover? Deduplicate across sites? AECC warm or cold?
7. Security sign-off for a two-way optical link (and for delivery receipts).
8. Confirm bundling (many messages per QR session) and the ordering rule (head-of-line blocking per order/card).

## 11. Original machine (for reference only)

- Workspace: `D:\Workstations\Developments\Con-Edison\Applications\qrcode-gateway\`
  - `qrcode-gateway-nexus\QrDiode_V2\` — this folder
  - `qrcode-gateway-nexus\QrBridge\`, `qrcode-gateway-nexus\Bridge.Core\` — superseded prototypes (not needed)
  - `qrcode-gateway-nexus\fms-interface-simulator\`: copied into `docs/reference/fms-interface-simulator/` on this
    machine. It is local only: `.gitignore` and the handoff zip leave it out.
  - `docs\referencces\*.pdf`: copied into `docs/reference/`
  - `docs\WPF-Tutorial.md`: moved to `docs/WPF-Tutorial.md` (updated); `docs\design\gateway-and-qrdiode-design.md`:
    retired, with its valid parts in `docs/bridge/Integration-Plan.md`. Both originals were sent to the Recycle Bin on
    20 Nov.
- Handoff package: `qrcode-gateway-nexus\QrDiode_V2-handoff-<date>.zip`, made by `scripts\pack-handoff.ps1`.
