# QR Air-Gap Bridge — Project Guide

How the generic SOAP gateway carries **unchanged WCF/SOAP calls** across a light-only air gap, and how the whole
project fits together: components, message flow, storage, security, configuration, deployment, testing and status.

| | |
|---|---|
| **Status** | 20 Nov 2026. Gateway and shared data layer: built and tested (136 tests). Connecting the QR apps to the databases: not built yet ([§14](#14-status-open-decisions-and-next-steps)). |
| **Solution** | `QrDiode_V2/QrDiode.slnx` |
| **Quick reference** | [../GATEWAY.md](../GATEWAY.md) (one page: how a call is handled, catalogue, egress, limits) |
| **Background** | [Design record PDF](../reference/QR-AirGap-Bridge-Design-Record.pdf) · [Integration plan (remaining work)](Integration-Plan.md) · [Architecture diagram](../reference/fms-bidirectional-qr-proxy-architecture.md) · [QrDiode architecture](../ARCHITECTURE.md) |
| **Payload source** | [fms-interface-simulator docs](../reference/fms-interface-simulator/docs/README.md) — the interfaces, contracts and message templates |
| **Handoff** | [../HANDOFF.md](../HANDOFF.md) — decisions, verification state, known issues and next steps (start here on a new machine) |

Read [§1](#1-the-problem)–[§5](#5-a-messages-journey-step-by-step) for the idea. The rest is reference.

## Contents

1. [The problem](#1-the-problem)
2. [Why WCF calls are hard to carry across an air gap](#2-why-wcf-calls-are-hard-to-carry-across-an-air-gap)
3. [The solution at a glance](#3-the-solution-at-a-glance)
4. [How the generic gateway solves each WCF issue](#4-how-the-generic-gateway-solves-each-wcf-issue)
5. [A message's journey, step by step](#5-a-messages-journey-step-by-step)
6. [Data and storage](#6-data-and-storage)
7. [Security](#7-security)
8. [Reliability and operations](#8-reliability-and-operations)
9. [The QrDiode side (the light link)](#9-the-qrdiode-side-the-light-link)
10. [Solution layout and code map](#10-solution-layout-and-code-map)
11. [Configuration reference](#11-configuration-reference)
12. [Build, test, publish and deploy](#12-build-test-publish-and-deploy)
13. [How to add or change a service](#13-how-to-add-or-change-a-service)
14. [Status, open decisions and next steps](#14-status-open-decisions-and-next-steps)
15. [Glossary](#15-glossary)
- [Appendix A. Wire examples](#appendix-a-wire-examples)
- [Appendix B. Design record decisions and what changed](#appendix-b-design-record-decisions-and-what-changed)

---

## 1. The problem

### 1.1 Islanding mode

The corporate network (**CorpNet**) and the FMS side (**ECC / AECC DMZ**, also called OpNet) are normally connected
through firewalls. In **islanding mode** those firewalls are cut: no copper, no fiber. The only link left is light — a
screen showing QR codes on one side, a camera reading them on the other. There are two one-way optical lanes:

| Lane | Screen | Camera | Carries |
|---|---|---|---|
| 1 (outbound) | DMZ | CorpNet | FMS updates to the corporate systems |
| 2 (inbound) | CorpNet | DMZ | corporate apps' calls to the FMS-side services |

ECC is the primary site (active optical pair); AECC is the standby pair. In normal operation none of the bridge is in
the path: the corporate load balancer routes straight to the DMZ RR servers.

### 1.2 The rules we work under

| Rule | What it forces |
|---|---|
| The callers cannot change. Rapid Restore, MAXIMO and the other corporate apps are not our project. | The gateway must be indistinguishable from the services they call today. |
| Corporate apps reach the services only through the corporate **load balancer** (e.g. `https://a/...svc` → LB). | In islanding mode the LB is pointed at the Corp gateway. That is the only change on CorpNet. |
| The FMS-side outbound services may be re-pointed **by configuration only**. | The DMZ gateway stands in for the corporate systems they call. |
| Only two programs per machine: the gateway (IIS) and the QR app (WPF). No extra Windows service. | Background work lives inside those two programs. |
| .NET 10, WPF, SQLite (EF Core). | |

### 1.3 Who calls what

From the fms-interface-simulator (`Configuration.xml`, WSDLs, message templates):

**CorpNet → DMZ** (corporate apps calling FMS-side services — in the gateway catalogue today)

| Caller | Endpoint path | Kind | Fire-and-forget operation | Messages |
|---|---|---|---|---|
| Rapid Restore FCR | `/FMS_FC2FMSInterface/FC2FMSInterface.svc` | WCF | `SendToFMS` | REQUEST_FOR_PERMIT, RFP_FCR_RESPONSE, WP_FCR_RESPONSE, FIELD_GROUNDS_ONLY, FGO_FCR_RESPONSE, RETURN_PERMITS, LIFT_CAUTION, FAULT_RESPONSE, WP_ETC_UPDATE, FEEDER_ETC_UPDATE |
| Rapid Restore FOD | `/FMS_FOD2FMSInterface/FOD2FMSInterface.svc` | WCF | `SendToFMS` | FOD_MOVE_RESPONSE, RETURN_MOVE, RETURN_FAULT, FOD_FAULT_RESPONSE, RETURN_TAGS, FOD_TAG_RESPONSE, CREW_ASSIGNMENT, FOD_CREW_RESPONSE |
| Rapid Restore SSO | `/FMS_SSO2FMSInterface/SSO2FMSInterface.svc` | WCF | `SendToFMS` | SSO_RESPONSE, RETURN_ORDER |
| Rapid Restore SSO | `/FMS_SSO2TOMSInterface/SSO2TOMSInterface.svc` | WCF | `SendToTOMS` | TOMS_SSO_RESPONSE, TOMS_RETURN_ORDER, VOLTAGE_REDUCTION_REQUEST |
| Rapid Restore SSO | `/FMS_SSO2TLSInterface/SSO2TLSInterface.svc` | WCF | `SendToTLS` | TLS_SSO_RESPONSE, TLS_RETURN_ORDER |
| Rapid Restore SSO | `/FMS_SSO2DSOInterface/SSO2DSOInterface.svc` | WCF | `SendToDSO` | DSO_SSO_RESPONSE, DSO_RETURN_ORDER |
| Fault Correlation (FTC) | `/FMS_FTC2FMSInterface/FTC2FMSInterface.svc` | WCF | `SendToFMS` | FAULT_CORRELATION |
| Verizon eBonding | `/VZ2TLSWebService/VZ2TLSInterface.asmx` | ASMX | `SendToTLS` (returns `long`) | createTicketResponse, getTicketResponse |
| DSS / No. 9 | `/FMSInterface/RR_DSSFMSService.wsdl` | SOAP Toolkit (RPC/encoded) | `SendToFMS` (returns `int`) | FOD_MOVE_RESPONSE, NO9_MOVE_RESPONSE, RETURN_MOVE |
| Legacy endpoints of FCR, FOD, SSO→FMS/TOMS/TLS, FTC | `/FMSInterface/RR_*Service.WSDL` | SOAP Toolkit | `SendTo*` | as above |

Plus operations that need a **live answer** and so cannot be bridged: `GetFromFMS` / `GetFromTOMS` / `GetFromTLS`
(AUTHORIZE_USERS, GET_FEEDER_INFO, WITHDRAW_RFP, GET_RELAY_TARGET), XA/21 `ProcessMessage`, BFC `ProcessMessage` and the
Registered Tags `GET` report.

**DMZ → CorpNet** (FMS/TOMS/TLS/DSO interface clients calling corporate systems): CARD_CREATE / CARD_ACTIVATION /
CARD_CUTOUT, RFP_DO_RESPONSE, ISSUE_WORK_PERMIT, ISSUE_ORDER, TOMS/TLS/DSO_ISSUE_ORDER, DO_FAULT_RESPONSE,
REPLACE_CERTIFIED_TAG, GET_FAULT_CORRELATION, Verizon ticket requests, and MAXIMO / OSS / NRI. The endpoints those
clients call on the corporate side are **not in the simulator repository**, so they are not in the catalogue yet.

---

## 2. Why WCF calls are hard to carry across an air gap

1. **The caller waits for an answer.** Every interface is HTTP request/reply. The caller sends a request and blocks
   until a reply arrives (the simulator waits up to 5 minutes). The light link is one-way per lane and has no
   real-time return path, so the real service's answer cannot come back in time.
2. **The caller reads the answer.** A WCF FMS service returns a string such as
   `<RESPONSE><STATUS><RETURN_CODE>0</RETURN_CODE><ERROR_MESSAGE/></STATUS></RESPONSE>`. A non-zero code means
   "refused" and the operator's form stays open. The ASMX Verizon service returns a `long`; the SOAP Toolkit services
   return an `int`. A reply without the right value is a failure to the caller.
3. **WCF clients are strict about the reply's shape.** A generated WCF proxy only accepts a reply with the exact wrapper
   element, namespace, result element and type it expects, in the same SOAP version, with matching WS-Addressing
   headers where used, and HTTP 202 with no body for one-way operations. "Almost right" is an exception in the caller.
4. **Many service styles behind one load balancer.** WCF `.svc` (document/literal), ASMX `.asmx` (also exposing SOAP
   1.2 bindings), old SOAP Toolkit `*.WSDL` endpoints using RPC/encoded SOAP, and a plain HTTP `GET` report. The five
   legacy FMS endpoints (FCR, FOD, SSO, FTC, DSS) all share the **same** `SOAPAction`
   (`http://tempuri.org/action/FMSInterface.SendToFMS`), so the action alone cannot tell them apart.
5. **The callers cannot be changed.** Same URL, same path, same `SOAPAction`, same reply. The load balancer's health
   probe must keep getting HTTP 200. Old SOAP Toolkit clients may download the WSDL from the endpoint URL at runtime.
6. **Payloads must arrive unchanged.** The business XML travels as a string inside the SOAP body and has quirks:
   `MSG_ID` is a static template value (`"456"`), many headers say `SOURCE_APPLICAION` (a typo the receivers expect),
   Verizon replies are whole SOAP envelopes inside the string, cancellations are ANSI tML-TA documents. Rebuilding the
   XML from objects risks changing any of this.
7. **Some calls are queries.** `GetFromFMS` and friends exist to *read* data. An instant "OK" is not an answer to them.
8. **A per-contract approach doesn't scale.** Hosting each contract with CoreWCF means a hosted contract, a client
   contract and a handler per service — about nine on the Corp side alone, more on the DMZ side, more for every new
   service — plus redeploys. And CoreWCF does not host the RPC/encoded style that DSS and the legacy endpoints use.

---

## 3. The solution at a glance

### 3.1 The picture

```
 CORPNET                                                            ECC / AECC DMZ (OpNet)
 ───────                                                            ──────────────────────
 Corporate apps (Rapid Restore, FTC, Verizon...)                    FMS / TOMS / TLS / DSO outbound clients
   │ unchanged URL                                                    │ URL re-pointed by configuration
   ▼                                                                  ▼
 Corporate load balancer ──(islanding)──► CORP GATEWAY             DMZ GATEWAY
                                          (IIS)                     (IIS)
                                            │ store, then reply       │ store, then reply
                                            ▼ like the real service   ▼ like the real service
                                       outbound.db                outbound.db
                                            │                         │
                               QR SENDER (screen) ═══ lane 2 ════► QR RECEIVER (camera)
                               QR RECEIVER (camera) ◄═══ lane 1 ═══ QR SENDER (screen)
                                            │                         │
                                       inbound.db                 inbound.db
                                            │                         │
                               CORP GATEWAY delivery worker      DMZ GATEWAY delivery worker
                                            ▼                         ▼
                               corporate systems                 DMZ RR servers (the real .svc)
                               (DMZ → Corp messages)              → Core FMS
```

### 3.2 What runs on each machine

The same software runs on both sides; the setting `Bridge:Side` (`Corp` or `Dmz`) picks the role.

| Program | Deployed as | Job |
|---|---|---|
| **QrBridge.Gateway** | IIS site | **Ingress:** stands in for the services on the other side — reads the call, stores it, replies. **Egress:** replays calls that arrived over the light to the real services on its own side. **Maintenance:** recovery, retention, heartbeats, `/health`. |
| **QrDiode.Sender** | WPF exe (kiosk user) | Shows queued messages as a QR stream on the screen facing the other side. *(Database connection: planned.)* |
| **QrDiode.Receiver** | WPF exe (kiosk user) | Reads the other side's QR stream with a camera, verifies it, stores the messages for the gateway. *(Database connection: planned.)* |

The programs never call each other. On one machine they meet only at the folder `C:\ProgramData\QrBridge\Data`
(`outbound.db`, `inbound.db`) and two named Windows events used as doorbells.

### 3.3 Why a generic SOAP gateway

Every bridged operation has the same shape: **one XML string in, one value out**, over SOAP. So the gateway does not
need to understand any contract. It needs to:

1. **recognise** the call (which service, which operation),
2. **store** it exactly as received,
3. **answer** in the shape the caller expects, and
4. **replay** it, unchanged, on the other side.

| | CoreWCF with typed contracts (original plan) | Generic SOAP gateway (built) |
|---|---|---|
| Code per service | hosted contract, data contracts, client, handler, registration | none — one entry in `routes.json` |
| SOAP 1.1, 1.2, WS-Addressing | per binding configuration | all handled by one parser and reply writer |
| RPC/encoded (DSS, legacy `*.WSDL`) | not supported | handled |
| Payload | rebuilt from objects | the caller's bytes, unchanged |
| New service | code + build + deploy | config + WSDL file + app pool recycle |
| Unknown service | impossible | possible (`Routing:AcceptUnlisted`) |

---

## 4. How the generic gateway solves each WCF issue

### 4.1 Summary

| # | Issue ([§2](#2-why-wcf-calls-are-hard-to-carry-across-an-air-gap)) | How the gateway solves it | Code |
|---|---|---|---|
| 1 | The caller waits | Store the call durably, then reply at once (milliseconds). Deliver later. | `Ingress/IngressEndpoint.cs`, `Bridge/OutboxWriter.cs` |
| 2 | The caller reads the answer | Reply profiles hold the exact success value the real service gives (`RETURN_CODE 0`, `0`). | `routes.json` → `ReplyProfiles` |
| 3 | Strict reply shape | The reply is built from the request: same SOAP version, namespace, wrapper/result naming, WS-Addressing `Action`/`RelatesTo`, 202 for one-way. | `Soap/SoapReplyWriter.cs` |
| 4 | Many styles | One parser for SOAP 1.1/1.2, document/literal and RPC/encoded. The service is found by **path**, the operation by the **SOAP body element**. | `Soap/SoapRequest.cs`, `Routing/RouteTable.cs` |
| 5 | Callers cannot change | The original paths and actions; the original WSDLs served with the gateway's address; a 200 page for health probes. | `routes.json`, `Ingress/MetadataEndpoint.cs`, `Wsdl/` |
| 6 | Payloads unchanged | The request body is stored and replayed byte for byte. The gateway only *reads* labels from it. | `QrBridge.Shared/Envelope/RawSoapMessage.cs`, `Egress/SoapForwarder.cs` |
| 7 | Queries | An explicit **Unavailable** mode answers with a clean, readable error (`RETURN_CODE 1599`) instead of a hang. | `OperationMode.Unavailable` |
| 8 | Scale | Services are configuration. With `AcceptUnlisted` the gateway bridges any SOAP service it has never seen. | `Routing/RouteTable.cs` |

### 4.2 One endpoint for every service

`Program.cs` maps three things:

| Route | Handler | Purpose |
|---|---|---|
| `GET /health` | inline | queue depths and heartbeats (JSON) |
| `POST /{**path}` | `IngressEndpoint` | every SOAP call, whatever the path |
| `GET`/`HEAD /{**path}` | `MetadataEndpoint` | `?wsdl`, `?xsd=…`, help page, health probes |

The path *is* the service. IIS must hand every request to the gateway — including `*.svc`, `*.asmx` and `*.wsdl`. That
needs an app pool with **No Managed Code** and **no WCF HTTP Activation** feature on the server (with it installed,
IIS gives `*.svc` to .NET Framework WCF). `deploy/setup-iis.ps1` sets the first and warns about the second.

### 4.3 Reading any SOAP request without its contract

`SoapRequest.TryParse` reads only what the gateway needs, from any SOAP request:

| Read | From | Example |
|---|---|---|
| SOAP version | the Envelope's namespace | 1.1 = `http://schemas.xmlsoap.org/soap/envelope/`, 1.2 = `http://www.w3.org/2003/05/soap-envelope` |
| Operation | local name of the first element in `Body` | `SendToFMS` |
| Operation namespace | that element's namespace | `http://tempuri.org/` (WCF), `http://tempuri.org/message/` (SOAP Toolkit) |
| Style | first parameter has **no** namespace → RPC/encoded | DSS: `<XMLMsg>` is unqualified |
| Parameter value | text of the operation's first child element | the `<MESSAGE TYPE="…">` string in `sXML` / `XMLMsg` |
| Action | `wsa:Action` header, else the `SOAPAction` HTTP header, else the SOAP 1.2 Content-Type `action=` parameter | `http://tempuri.org/IFC2FMSInterface/SendToFMS` |
| WS-Addressing | `Action`, `MessageID`, `To` headers (2005/08 or 2004/08) | from WCF `WSHttpBinding` clients |

All XML is read with DTDs prohibited and no external resolution (no XXE, no entity expansion), and with a size cap.
Anything that is not a SOAP envelope is refused with HTTP 400.

`PayloadInspector` then reads a **label** from the parameter value: the FMS `MESSAGE/@TYPE` and `MSG_ID`; for a SOAP
envelope carried as a string (Verizon), the name of its Body element (`createTicketResponse`); otherwise the root
element name (`CancelTroubleReportResponse`). The label is used for the allow-list, logs and a database column — the
payload itself is never modified.

### 4.4 Deciding what to do: the route catalogue

`routes.json` lists every service the gateway stands in for. A call is resolved like this:

```
path (case-insensitive, normalised)  ──► service entry?        no ──► AcceptUnlisted? no ──► SOAP fault (allow-list)
                                                                                       yes ──► Bridge, automatic reply
                                          │ yes
                                          ▼
service.IngressSide == this side?      no ──► SOAP fault ("delivered here, not accepted here")
                                          │ yes
                                          ▼
body element = listed operation?       no ──► service.OtherOperations (default: Reject)
                                          │ yes
                                          ▼
operation Mode:  Bridge │ Echo │ Unavailable │ Reject
```

| Mode | What happens | Stored? |
|---|---|---|
| **Bridge** | Allow-list check, backlog check, store, then reply OK | yes |
| **Echo** | Reply with the request's value (the `EchoString` connectivity checks) | no |
| **Unavailable** | Reply "not available while islanded" — for operations that need a live answer | no |
| **Reject** | SOAP fault | no |

The shipped catalogue (18 entries):

| Group | Services | Notes |
|---|---|---|
| WCF `.svc` | FC2FMS, FOD2FMS, SSO2FMS, SSO2TOMS, SSO2TLS, SSO2DSO, FTC2FMS | `SendTo*` bridged; `GetFrom*` Unavailable; `EchoString` Echo |
| ASMX | VZ2TLS | `SendToTLS` bridged for `createTicketResponse` / `getTicketResponse` only — what the real handler accepts |
| SOAP Toolkit `*.WSDL` | DSS2FMS, FC2FMS-Legacy, FOD2FMS-Legacy, SSO2FMS-Legacy, SSO2TOMS-Legacy, SSO2TLS-Legacy, FTC2FMS-Legacy | RPC style, numeric replies; WSDL returned on a plain GET |
| Live answers only | XA2FMS, IR2BFC, RegisteredTags | Unavailable (whether they cross the gap at all is still open) |

Each bridged operation has an **allow-list** of message types (`AllowedTypes`) mirroring what the real service
accepts, so a payload the real service would refuse is refused at once — while the caller is still on the line — not
an hour later on the other side.

### 4.5 Answering exactly like the real service

The reply is built from the request, following the conventions WCF and ASMX use themselves:

| Caller style | Reply body |
|---|---|
| WCF / ASMX, document/literal | `<{Op}Response xmlns="{ns}"><{Op}Result>{value}</{Op}Result></{Op}Response>` |
| SOAP Toolkit, RPC/encoded | `<m:{Op}Response xmlns:m="{ns}"><Result>{value}</Result></m:{Op}Response>` (part unqualified) |
| SOAP 1.2 | the same body in a SOAP 1.2 envelope, `Content-Type: application/soap+xml; charset=utf-8` |
| WS-Addressing | adds `<a:Action>{request action}Response</a:Action>` and `<a:RelatesTo>{request MessageID}</a:RelatesTo>` |
| One-way (`"OneWay": true`) | HTTP 202, empty body |
| Unknown contract (unlisted) | `<{Op}Response xmlns="{ns}"/>` with no result — WCF reads null (strings), the default (numbers) or a normal completion (void) |
| Refusal | SOAP fault: 1.1 `faultcode`/`faultstring`, 1.2 `Code`/`Reason`; HTTP 500 (503 when busy without a profile) |

The **value** comes from the operation's reply profile in `routes.json`:

| Profile | Ok | Busy | Unavailable | Rejected |
|---|---|---|---|---|
| `FmsResponse` | `<RESPONSE MSG_TYPE="{BusinessType}" MSG_ID="{MsgId}"><STATUS><RETURN_CODE>0</RETURN_CODE><ERROR_MESSAGE></ERROR_MESSAGE></STATUS></RESPONSE>` | same with `1598` + "backlog is full … retry later" | `1599` + "not available while FMS is islanded" | `1597` + "Invalid XML MESSAGE TYPE for this interface" |
| `ReturnCode` | `0` | `1598` | `1599` | `1597` |

`{BusinessType}`, `{MsgId}` (from the caller's message) and `{MessageId}` (the bridge's id) are filled in and
XML-escaped. **1597–1599 are the bridge's own codes**; FMS uses 1500–1999 for its errors and callers show
`ERROR_MESSAGE` to the operator. They are configurable and still need confirming with the Rapid Restore team.

Real WCF client stacks were run against the gateway in the tests ([§12.2](#122-what-the-tests-prove)): BasicHttp
(DataContract), ASMX-style (XmlSerializer, `long` result) and WSHttp (SOAP 1.2 + WS-Addressing). All accept these
replies unchanged.

### 4.6 Storing the call: byte for byte, then reply

For a **Bridge** call, in this order:

1. Allow-list check (`AllowedTypes`). Fail → `Rejected` reply (1597). Nothing stored.
2. Backlog check: Pending + Sending Outbox rows ≥ `Gateway:MaxBacklog` → `Busy` reply (1598). Nothing stored.
3. Build a `RawSoapMessage`: service, operation, path, `SOAPAction` header **as received** (quotes included),
   Content-Type **as received**, label, and the **exact request body**.
4. In one SQLite transaction: take the next per-direction sequence number, seal the message into an encrypted
   envelope ([§7.2](#72-the-envelope-format)), insert the Outbox row, **commit**.
5. Ring the Outbox doorbell (wakes the QR sender).
6. **Only now** reply OK. The reply carries the header `X-QrBridge-MessageId` (the bridge's id for the stored message).

If anything fails before the commit, the caller gets a SOAP fault ("NOT accepted, please retry"): a call is never
half-stored, and never acknowledged without being stored.

### 4.7 Calls that need a live answer

`GetFromFMS`, `GetFromTOMS`, `GetFromTLS` (AUTHORIZE_USERS, GET_FEEDER_INFO, WITHDRAW_RFP, GET_RELAY_TARGET), XA/21 and
BFC `ProcessMessage`, and the Registered Tags report return **data**. No reply the gateway could invent is correct.
They are **Unavailable**:

| Interface | What the caller gets |
|---|---|
| FMS query with a reply profile | HTTP 200, `RETURN_CODE 1599` + readable message — the caller's normal error path |
| XA/21, BFC (`ProcessMessage`) | SOAP fault "not available while the network is islanded" |
| Registered Tags (`GET …/GetData`) | HTTP 503 with a plain-text message |

A later option, which needs its own decision: the far side periodically sends snapshots (authorised users, feeder
list, registered tags) over the light, and the gateway answers queries from them.

### 4.8 Bad, unknown and too many calls

| Situation | HTTP | Reply |
|---|---|---|
| Body over `Bridge:MaxPayloadBytes` (1 MB) | 413 | SOAP 1.1 fault |
| Not XML / not a SOAP envelope / DTD present | 400 | SOAP 1.1 fault |
| Path not in the catalogue (`AcceptUnlisted` off) | 500 | SOAP fault "not a bridged service" |
| Operation not listed for the service | 500 | SOAP fault "not bridged" |
| Service whose callers are on the other side | 500 | SOAP fault |
| Message type not allowed, or payload not well-formed | 200 | profile `Rejected` (1597), else SOAP fault |
| Backlog full | 200 | profile `Busy` (1598), else SOAP fault with 503 |
| Database error while storing | 500 | SOAP fault "NOT accepted, please retry" |

### 4.9 WSDL, help pages and health probes

| Request | Answer |
|---|---|
| `GET /` | `QrBridge Gateway (Corp)` — plain text |
| `GET {path}?wsdl` or `?singleWsdl` | the service's original WSDL from `Wsdl/{Service}/service.wsdl`, with `soap:address` and the schema imports rewritten to the URL the caller used |
| `GET {path}?xsd=xsd0` | the schema file `xsd0.xsd` |
| plain `GET` on a legacy `*.WSDL` endpoint | the WSDL (SOAP Toolkit clients load it from the endpoint URL) |
| plain `GET` on any other service path | small HTML page, HTTP 200 (load balancer health probes) |
| `GET` on the Registered Tags report | 503 (needs a live answer) |
| `GET` on a path that is not a service of this side | 404 |
| `GET /health` | JSON: side, machine, queue counts, heartbeats, overall `healthy` flag |

The WSDLs come from the simulator's service references. Two gaps: the WCF WSDL of `FOD2FMSInterface.svc` is not
available (so `?wsdl` returns 404 there), and the DSS WSDL is **derived** from the FOD one (DSS reuses the FOD
proxy; only the service name differs). See `src/QrBridge.Gateway/Wsdl/README.md`.

### 4.10 Delivering on the other side

The receiving side's gateway runs `InboxWorker`, a single background loop inside IIS:

1. **Claim** the oldest Inbox row that is Pending (or Failed with its retry time reached).
2. **Open** the envelope: decrypt and authenticate. Check that the row's columns match the authenticated header, the
   direction is right for this side, the payload is a `RawSoapMessage`, it is less than 7 days old and not dated more
   than an hour in the future.
3. **Plan**: the service must be in this side's catalogue with its *callers on the other side*, and the operation must
   be a Bridge operation (unlisted services only when `AcceptUnlisted` is on).
4. **Target**: `Gateway:Egress:Targets:{Service}:Url`, else `Gateway:Egress:DefaultBaseUrl` + the caller's original
   path. **The URL never comes from the message** — a forged or replayed message cannot send the gateway anywhere.
5. **Replay**: POST the stored body unchanged, with the original `SOAPAction` and `Content-Type`. Redirects are not
   followed. Optionally authenticate as the app pool identity (`UseDefaultCredentials`). If the request uses
   WS-Addressing, its `wsa:To` is pointed at the real service (otherwise the bytes are not touched).
6. **Classify** the real service's answer and set the row's status:

| Real service answers | Verdict | Inbox status |
|---|---|---|
| `RETURN_CODE 0` / return code `0` / HTTP 202 / any 2xx for operations without a result kind | Delivered | **Done** (`DownstreamResult` keeps e.g. `RETURN_CODE=0`) |
| `RETURN_CODE ≠ 0` / return code `≠ 0` | Refused | **DeadLetter** with the code and `ERROR_MESSAGE` — never retried automatically |
| SOAP fault | Permanent | **DeadLetter** with the fault reason |
| 404, 401, 403, 415 and other 4xx | Permanent | **DeadLetter** — a configuration problem |
| timeout, network error, 5xx without a fault, 408, 429 | Transient | **Failed**, retried with backoff |
| 2xx but no recognisable result | Delivered | **Done**, `DownstreamResult` says "unrecognized reply" |

Retry schedule (defaults): waits of 30 s, 1, 2, 4, 8, 16 and 30 minutes between attempts — about one hour in total.
After the 8th failed attempt the row goes to DeadLetter.

### 4.11 "Any WCF request": what is covered and where it stops

Covered:

- SOAP 1.1 and SOAP 1.2; WS-Addressing 1.0 and August 2004.
- Document/literal (WCF `BasicHttpBinding`, ASMX, `WSHttpBinding` without message security) and RPC/encoded (SOAP Toolkit).
- Services the catalogue has never seen (`Routing:AcceptUnlisted`), with an automatic reply.
- Any payload, byte for byte; any `SOAPAction`, including shared and empty ones.

Not covered — true of any proxy that replies on the real service's behalf:

| Not covered | Why |
|---|---|
| Message-level security (WS-Security signatures/encryption, secure conversation) | a signed request cannot be answered by a third party, or replayed later |
| Reliable sessions, duplex callbacks | they need a live two-way connection |
| The caller's Windows identity reaching the real service | the call is replayed later by the gateway's identity |
| Replies that carry live data | see [§4.7](#47-calls-that-need-a-live-answer) |
| Unlisted operations whose caller reads a result | they get an empty reply; add a catalogue entry with a reply profile |
| Document/literal **bare** (non-wrapped) unlisted operations | the automatic reply assumes the wrapped convention |

None of the FMS services in the simulator use message security, reliable sessions or duplex.

---

## 5. A message's journey, step by step

An SSO operator returns a completed switching order. Steps 6–9 are the QR apps' part, which is designed but not built
yet ([§9.2](#92-what-changes-to-connect-it-to-the-bridge-planned)); everything else exists today.

| # | Where | What happens | State afterwards |
|---|---|---|---|
| 1 | Rapid Restore SSO (CorpNet) | Calls `SendToFMS(<MESSAGE TYPE="RETURN_ORDER" …>)` on `https://…/FMS_SSO2FMSInterface/SSO2FMSInterface.svc`, unchanged. | |
| 2 | Corporate load balancer | In islanding mode, forwards to the Corp gateway. | |
| 3 | Corp gateway — ingress | Parses the SOAP call; route SSO2FMS, operation SendToFMS, Mode Bridge; label `RETURN_ORDER` is on the allow-list. | |
| 4 | Corp gateway — store | Seals the exact request into an envelope (key `c2d-…`), inserts it, commits, rings the Outbox doorbell. | Corp Outbox: **Pending**, sequence n |
| 5 | Corp gateway — reply | Replies `RETURN_CODE 0` with `MSG_TYPE="RETURN_ORDER"`. Rapid Restore continues as usual. | |
| 6 | Corp QR sender *(planned)* | Wakes on the doorbell, claims waiting rows, bundles them into one QR session (signed, encrypted again), shows the QR stream. | Corp Outbox: **Sending**, then **Aired** |
| 7 | Light, lane 2 | The DMZ camera films the CorpNet screen. | |
| 8 | DMZ QR receiver *(planned)* | Verifies the QR session, unpacks the bundle, inserts each envelope into the Inbox (duplicates ignored by MessageId), rings the Inbox doorbell. | DMZ Inbox: **Pending** |
| 9 | DMZ gateway — worker | Claims the row; decrypts and authenticates it (key `c2d-…`); checks direction, age, catalogue. | DMZ Inbox: **Processing** |
| 10 | DMZ gateway — replay | POSTs the identical bytes, same `SOAPAction`, to `DefaultBaseUrl` + `/FMS_SSO2FMSInterface/SSO2FMSInterface.svc` (the DMZ RR server). | |
| 11 | DMZ RR server → Core FMS | Processes it exactly as a direct call; answers `RETURN_CODE 0`. | |
| 12 | DMZ gateway — record | Stores the answer. | DMZ Inbox: **Done**, `DownstreamResult = RETURN_CODE=0` |

If FMS refuses the order (say `RETURN_CODE 1501`), step 12 sets **DeadLetter** with the code and FMS's error message.
Today an operator sees it on the DMZ side; sending such refusals back to the caller's side is a planned improvement.

The **DMZ → CorpNet** direction is the same path mirrored: an FMS interface client calls the DMZ gateway (its URL
re-pointed by configuration), lane 1 carries the envelope, and the Corp gateway replays it to the corporate system.
This needs the corporate systems' endpoints in the catalogue (`"IngressSide": "Dmz"`), which are not captured yet.

---

## 6. Data and storage

### 6.1 Two databases per machine

Both live in `Bridge:DataFolder` (default `C:\ProgramData\QrBridge\Data`) on a **local disk** — never a network share.
The gateway's app pool identity and the kiosk user both need Modify on the folder (`deploy/setup-folders.ps1`).

| File | Written by | Read by | Holds |
|---|---|---|---|
| `outbound.db` | gateway (ingress) | QR sender | Outbox, SequenceCounter |
| `inbound.db` | QR receiver | gateway (worker) | Inbox, Heartbeat, InboxPayloadDebug |

One main writer per file keeps lock contention low. EF Core is the only way the code touches them
(`QrBridge.Shared/Data`): entities, `IEntityTypeConfiguration` classes, short-lived contexts from a
`IDbContextFactory`, and the stores (`OutboxStore`, `InboxStore`, `HeartbeatStore`).

### 6.2 Tables

**Outbox** — messages waiting to cross, or crossing.

| Column | Meaning |
|---|---|
| `Id` | local row id (queue order) |
| `MessageId` | end-to-end id (unique), the same in the other side's Inbox |
| `Direction`, `Sequence` | `CorpToDmz` / `DmzToCorp`, and the per-direction sequence number |
| `ServiceName`, `Operation`, `BusinessType` | route, SOAP operation, label (e.g. `SSO2FMS`, `SendToFMS`, `RETURN_ORDER`) |
| `PayloadFormat`, `KeyId`, `PayloadSize` | `RawSoap`, key that sealed it, payload size before compression |
| `Envelope`, `EnvelopeHash` | the sealed bytes (immutable) and their SHA-256 |
| `ChunkCount` | QR frames per loop (filled by the QR sender; 1 until then) |
| `Status`, `Attempts`, `LockedUtc`, `NextAttemptUtc`, `AckedUtc`, `LastError` | queue state |

**Inbox** — complete messages from the other side. The same identity and label columns as the Outbox, plus `Verified`
(set once the gateway has authenticated it), `ReceivedUtc`, `ProcessedUtc` and **`DownstreamResult`** (what the real
service answered).

**SequenceCounter** (one row per direction), **Heartbeat** (one row per component: `GatewayApi`, `InboxWorker`,
`MaintenanceWorker`, later `SenderLoop`, `ReceiverLoop`), **InboxPayloadDebug** (plain-text payloads, only when
`Gateway:DebugPayloadCapture` is on — off in production).

Status lifecycles:

```
Outbox: Pending ──► Sending ──► Acked                     (Aired / Confirmed planned with the QR sender)
                       └──────► Failed (operator)
Inbox:  Pending ──► Processing ──► Done
                       ├──► Failed ──(backoff)──► Processing ... ──► DeadLetter (after MaxAttempts)
                       ├──► DeadLetter   (refused by the real service, or not deliverable as configured)
                       └──► Rejected     (failed authentication / direction / catalogue / payload checks)
```

Enums are stored as their names, Guids as lower-case text, all times in UTC — readable with any SQLite tool.

### 6.3 Queue mechanics

| Mechanism | How |
|---|---|
| Claim | Find the oldest eligible id, then `UPDATE … SET Status='Processing' WHERE Id=@id AND Status='Pending'`. One affected row = you own it; two claimers can never get the same row. |
| Sequence | `UPDATE SequenceCounter SET LastValue = LastValue + 1 WHERE Direction=@d RETURNING LastValue`, in the same transaction as the Outbox insert. |
| Duplicates | `MessageId` has a unique index in both tables; the Inbox insert is idempotent (a duplicate returns "already there"). |
| Recovery | Inbox rows stuck in Processing longer than `LockTimeoutMinutes` (5) go back to Pending. A shutdown mid-delivery puts the row back without counting the attempt. |
| Retention | Done Inbox rows and Acked Outbox rows are deleted after `RetentionDays` (7); debug payloads after 24 h. Until the QR sender marks rows, Outbox rows stay Pending. |
| Ordering | One worker processes rows in arrival order. A retried row can be overtaken by a later one; per-order head-of-line blocking is a planned improvement. |

### 6.4 SQLite settings

Every connection runs `PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;`; `journal_mode = WAL` is set once
(it is stored in the file). WAL lets readers and the single writer work at the same time; `busy_timeout` makes a
writer wait for the lock instead of failing. At this volume — bounded by a few KB/s of light — SQLite is nowhere near
its limits.

The schema is created from the EF model at startup (`EnsureCreated`), retrying because the gateway and the QR apps may
start together. EF migrations must replace this before go-live (the code already applies migrations when they exist).

### 6.5 Doorbells

SQLite has no notifications, so each side uses two named Windows events:

| Event | Rung by | Wakes |
|---|---|---|
| `Global\QrBridge.{Side}.Outbox` | gateway, after an Outbox commit | QR sender |
| `Global\QrBridge.{Side}.Inbox` | QR receiver, after an Inbox insert | gateway worker |

`Global\` is needed because IIS runs in session 0 and the kiosk app in the user's session. The events are created
with an ACL for Authenticated Users, IIS_IUSRS, SYSTEM and Administrators. They only speed things up: every waiter
also polls (`InboxPollSeconds`, 2 s), so a missed signal delays a message by one poll at most.

---

## 7. Security

### 7.1 Two layers

| Layer | Protects | Keys |
|---|---|---|
| **Bridge envelope** (gateway to gateway) | The message from the moment the gateway stores it until the other gateway opens it: in both databases, on the QR screens, in transit. Authenticated header, encrypted payload. | One AES-256 key per direction (`c2d-…`, `d2c-…`), DPAPI-protected files |
| **QrDiode session** (screen to camera) | Each QR session: signed manifest (ECDSA P-256) checked before any payload byte is used, per-session key (ECDH P-256 + HKDF + AES-256-GCM), anti-replay (session id, counter watermark, time window), strict fail-closed receive order. | Per-endpoint keys in Windows CNG, exchanged in a key ceremony |

Business payloads are therefore never plain text on the QR machines, on the wire or in either database (design
decision D13: double layer).

### 7.2 The envelope format

```
magic        uint32   "BRG1"
headerLen    int32
header       version · MessageType · Direction · PayloadFormat · Compression · MessageId (16) · CorrelationId (16)
             · Sequence (int64) · CreatedUtc (ticks) · ServiceName · Operation · KeyId · BusinessType
             (plain text, AUTHENTICATED: it is the AES-GCM associated data)
nonce        12 bytes (random)
tag          16 bytes
cipherLen    int32
cipher       AES-256-GCM( Brotli( RawSoapMessage ) )
```

The header is readable without a key (the QR receiver uses it to fill the Inbox columns) but any change to it makes
decryption fail. It holds no business data — `BusinessType` is a label such as `RETURN_ORDER`. Header strings are
capped at 256 characters; key ids must match `[A-Za-z0-9_-]{1,64}` before they are used to find a key file.
Decompression is capped (zip-bomb guard).

The `RawSoapMessage` inside: magic `RSM1`, version, six length-prefixed fields (service, operation, path,
`SOAPAction` header, Content-Type, label; each ≤ 4 KB) and the request body (≤ `Bridge:MaxPayloadBytes`).

### 7.3 Keys and the key tool

Each side holds **its own outbound key** (to seal what it sends) and **the other side's outbound key** (to open what it
receives). Keys are 32 random bytes in `{KeyId}.key` files, protected with DPAPI (LocalMachine scope plus entropy) —
a copied file is useless on another machine. Lock the key folder to the app pool identity (Read) and Administrators.

```powershell
# On CORP, in the published gateway folder (elevated):
QrBridge.Gateway.exe keys generate --id c2d-2026-11 --transfer-out E:\c2d.transfer
# carry E:\c2d.transfer to the DMZ on approved media, then on the DMZ:
QrBridge.Gateway.exe keys import --id c2d-2026-11 --transfer-file E:\c2d.transfer
# ...and the same the other way for d2c-2026-11. Compare fingerprints, then DESTROY the transfer files.
QrBridge.Gateway.exe keys list
QrBridge.Gateway.exe keys verify --id c2d-2026-11      # prints the fingerprint
```

The `KeyId` in every envelope allows rotation: a new key is added beside the old one and both work during the overlap.

### 7.4 Trust rules in the code

- **Destinations come from configuration only.** The replay URL is never read from a message.
- **Direction is checked.** A message sealed for Corp → DMZ is rejected if it turns up anywhere else.
- **The catalogue is checked on both sides**: at ingress (allow-list) and again at egress.
- **Replays are bounded**: messages older than `ReplayWindowDays` (7) or more than `MaxClockSkewMinutes` (60) in the
  future are rejected. QrDiode adds its own stricter anti-replay. Both need NTP on both networks.
- **Tampering is rejected, never delivered** (AES-GCM authentication), and shows as `Rejected` with the reason.
- **Untrusted XML** is always read with DTDs prohibited, no external resolution and size caps.
- **Payloads are never logged.** Logs contain service, operation, label, ids and sizes.

### 7.5 What the security does not cover

The header label is visible on the QR screen (inside QrDiode's own encryption, so only to whoever can decrypt the QR
session). Traffic analysis (sizes, timing) is accepted. The key ceremony is a procedure that must be followed.
**A security sign-off for a two-way optical link is still required before go-live.**

---

## 8. Reliability and operations

### 8.1 Guarantees

| Guarantee | Because |
|---|---|
| An acknowledged call is never lost | The reply is sent only after the Outbox commit. |
| A refused call is never acknowledged | Every failure before the commit returns a SOAP fault. |
| Delivery is at least once; processing is idempotent on our side | Unique MessageId in both tables; replays of the same envelope are deduplicated. Downstream services should tolerate a rare repeat. |
| Nothing refused by the real service is silently retried | Refusals and faults go to DeadLetter with the service's answer. |
| Crashes and recycles do not strand messages | Stuck Processing rows are reset; a shutdown releases the current row. |

### 8.2 What operators see

| Status | Where | Meaning | Action |
|---|---|---|---|
| Inbox **Failed** | receiving side | temporary problem reaching the real service; retrying | watch; fix the network/service if it persists |
| Inbox **DeadLetter** | receiving side | refused by the real service (see `DownstreamResult`), or out of attempts, or no egress target | read the reason; fix; requeue |
| Inbox **Rejected** | receiving side | failed authentication / direction / catalogue / payload checks | investigate (misconfiguration or tampering); never requeue blindly |
| Outbox **Failed** | sending side | marked by the QR sender (planned) | requeue |
| Reply 1597 / 1598 / 1599 | caller | not accepted (type) / backlog full / needs a live answer | caller's normal error handling |

### 8.3 Monitoring

- `GET /health` on each gateway: side, machine, Outbox and Inbox counts, heartbeats, and `healthy` (false if any
  heartbeat is older than 2 minutes, any Outbox row Failed or any Inbox row DeadLetter).
- Heartbeats: the worker every 30 s, maintenance every minute; the QR apps will add theirs.
- Logs: the Windows Event Log (warnings and above; `QrBridge` categories at Information). Maintenance logs warnings
  for Failed, DeadLetter and Rejected rows and for old undelivered messages.
- Each side is monitored on its own network; nothing crosses the gap for monitoring.

### 8.4 Operator SQL

Open the databases with DB Browser for SQLite or `sqlite3`; prefer read-only queries while the apps run.

```sql
-- Queue depth by status (inbound.db / outbound.db)
SELECT Status, COUNT(*) FROM Inbox  GROUP BY Status;
SELECT Status, COUNT(*) FROM Outbox GROUP BY Status;

-- What needs attention, with the real service's answer
SELECT MessageId, ServiceName, Operation, BusinessType, Attempts, LastError, DownstreamResult
FROM Inbox WHERE Status IN ('DeadLetter','Rejected') ORDER BY Id DESC;

-- Transit time across the gap (received - created), last 100
SELECT MessageId, ServiceName, BusinessType,
       ROUND((julianday(ReceivedUtc) - julianday(CreatedUtc)) * 86400, 1) AS Seconds
FROM Inbox ORDER BY Id DESC LIMIT 100;

-- Requeue one dead letter after fixing the cause (the worker picks it up within seconds)
UPDATE Inbox SET Status = 'Pending', Attempts = 0, NextAttemptUtc = NULL
WHERE Status = 'DeadLetter' AND MessageId = '...';

-- Reconciliation: compare both sides by MessageId + EnvelopeHash
SELECT MessageId, EnvelopeHash, Status FROM Outbox WHERE CreatedUtc >= '2026-11-01';   -- sender
SELECT MessageId, EnvelopeHash, Status FROM Inbox  WHERE CreatedUtc >= '2026-11-01';   -- receiver
```

### 8.5 Switching into and out of islanding mode

- **In:** point the corporate load balancer at the Corp gateway and the FMS outbound clients at the DMZ gateway. The
  gateways and QR apps are already running (IIS AlwaysRunning, kiosk auto-start), so nothing has to start.
- **Back:** queued messages must not arrive *after* newer ones sent over the restored network:
  1. stop accepting new calls on both gateways;
  2. wait until both sides are drained (no Pending/Sending Outbox rows, no Pending/Processing/Failed Inbox rows);
  3. flip the load balancer and the DMZ configuration back;
  4. deal with any DeadLetter/Rejected rows by hand.

  The "stop accepting" switch and a `/status` page with a drained flag are planned.

---

## 9. The QrDiode side (the light link)

### 9.1 What QrDiode V2 already does

| Part | Does |
|---|---|
| `QrDiode.Core` | Wire protocol: LT fountain coding (no acknowledgements needed to survive lost frames), frame format with CRC-32, signed manifest, ECDH/HKDF/AES-GCM per session, anti-replay, content gate. UI-free and unit-tested (75 tests, including optical loopback through real QR images). |
| `QrDiode.Sender` | WPF: queue, resizable QR stage window, frame pump. One payload per QR session, aired for N loops and at least 6 s, then a 1.5 s gap. |
| `QrDiode.Receiver` | WPF: camera capture (FlashCap + ZXingCpp), the verification chain, its own SQLite journal, payload archive, hash-chained audit log. |
| `QrDiode.KeyCeremony` | Console: generate CNG keys, export/import public bundles, compare fingerprints. |

Today the Sender takes payloads from a simulator or a file and the Receiver writes files. Neither talks to the bridge
databases yet.

### 9.2 What changes to connect it to the bridge (planned)

The project structure stays as it is: the features are added inside the existing projects. The detailed design and
the order of work are in [Integration-Plan.md](Integration-Plan.md).

| Change | Where | Why |
|---|---|---|
| Fix: a partly received session blocks every later session until restart | `QrDiode.Core` `ReceiveEngine` | Critical bug found in the review: the receiver ignores new manifests while locked on a partial session. |
| Read the Outbox through EF (`OutboxStore`) instead of the simulator | `QrDiode.Sender` | The Outbox is the queue; claim rows only when the stage has room; never drop (today the queue drops the oldest beyond 14). |
| **Bundles**: many Outbox envelopes per QR session | Sender + `QrBridge.Shared` | One message per session costs ≥ 7.5 s — about 8 messages per minute per lane, too slow for bursts. |
| Mark rows Aired / release them on failure; reset Sending at startup | Sender | Crash safety; "sent" means "aired" without receipts. |
| Unpack bundles into the Inbox through EF, in one transaction; ring the doorbell | `QrDiode.Receiver` | Delivery to the gateway worker. |
| Save the anti-replay mark only after the Inbox commit | Core + Receiver | Today it is saved first, so a crash in between loses the session silently. |
| Start unattended (keys, stage, camera from configuration); heartbeats | Sender + Receiver | Kiosk operation. |
| Align SQLite packages (Receiver pins SQLitePCLRaw 3.0.5; EF Core 10.0.15 uses 2.1.13) | Receiver | One native SQLite in the process. |
| Optional: delivery receipts over the reverse lane | both | Closes the "aired but never seen" gap; needs security sign-off (D14). |

### 9.3 Capacity

| Figure | Value |
|---|---|
| Typical payload | 0.4–9.3 KB (simulator templates); requests ≤ 1 MB accepted |
| Optical throughput (QrDiode estimate, one lane, ordinary webcam) | ~25–70 KB/s |
| Without bundling | ~8 messages per minute per lane (≥ 6 s air time + 1.5 s gap each) |
| With bundling (planned: up to 50 messages / 128 KB per session) | hundreds of messages per minute |
| Gateway backlog limit | 5,000 undelivered messages, then callers get "busy" (1598) |

---

## 10. Solution layout and code map

### 10.1 Projects

```
QrDiode_V2/
├─ QrDiode.slnx
├─ src/
│  ├─ QrBridge.Gateway/          IIS: ingress, egress worker, maintenance           (net10.0-windows, ASP.NET Core)
│  ├─ QrBridge.Shared/           EF Core + SQLite, envelope, keys, doorbells       (net10.0-windows library)
│  ├─ QrDiode.Core/              QR wire protocol, crypto, fountain codes          (net10.0 library)
│  ├─ QrDiode.Sender/            WPF exe: QR stage                                  (net10.0-windows)
│  ├─ QrDiode.Receiver/          WPF exe: camera, verification                      (net10.0-windows)
│  ├─ QrDiode.KeyCeremony/       console exe: QrDiode keys
│  └─ Shared/                    source file linked into both WPF apps (payload colouring)
├─ tests/
│  ├─ QrBridge.Tests/            136 tests (+ Samples/: the simulator's 43 message templates)
│  ├─ QrDiode.Core.Tests/        75 tests
│  └─ QrDiode.Bench/             throughput bench
├─ deploy/                       publish.ps1, setup-iis.ps1, setup-folders.ps1, setup-station-kiosk.ps1
└─ docs/                         this guide, GATEWAY.md, ARCHITECTURE.md, USER_GUIDE.md, design notes
```

### 10.2 Key files

| File | What it does |
|---|---|
| `src/QrBridge.Gateway/Program.cs` | Composition root: options, data, keys, endpoints, workers, startup checks |
| `src/QrBridge.Gateway/routes.json` | The route catalogue and reply profiles (same file on both sides) |
| `src/QrBridge.Gateway/Ingress/IngressEndpoint.cs` | Every SOAP POST: read, parse, resolve, decide, store, reply |
| `src/QrBridge.Gateway/Ingress/MetadataEndpoint.cs` | GET/HEAD: WSDL/XSD with rewritten addresses, help page, probes |
| `src/QrBridge.Gateway/Soap/SoapRequest.cs` | Reads any SOAP request; `SafeXml` (the one way untrusted XML is loaded) |
| `src/QrBridge.Gateway/Soap/PayloadInspector.cs` | Reads the message label (`MESSAGE/@TYPE`, root element) |
| `src/QrBridge.Gateway/Soap/SoapReplyWriter.cs` | Builds replies and faults the callers accept |
| `src/QrBridge.Gateway/Soap/SoapResponse.cs` | Reads the real service's reply (fault or result) |
| `src/QrBridge.Gateway/Routing/RoutingOptions.cs`, `RouteTable.cs` | Catalogue model; validation and lookup |
| `src/QrBridge.Gateway/Bridge/OutboxWriter.cs` | The one place messages enter the bridge |
| `src/QrBridge.Gateway/Egress/SoapForwarder.cs` | Replay to the real service; classify its answer; WS-Addressing `To` rewrite |
| `src/QrBridge.Gateway/Workers/InboxWorker.cs`, `MaintenanceWorker.cs` | Delivery loop; recovery, retention, heartbeats |
| `src/QrBridge.Gateway/KeyTool.cs` | `QrBridge.Gateway.exe keys …` |
| `src/QrBridge.Gateway/Wsdl/` | The original services' WSDLs and schemas |
| `src/QrBridge.Shared/Envelope/EnvelopeCodec.cs`, `EnvelopeHeader.cs`, `RawSoapMessage.cs` | Seal/open; header; the stored request |
| `src/QrBridge.Shared/Data/…` | Entities, EF configurations, DbContexts, stores, SQLite setup |
| `src/QrBridge.Shared/Security/DpapiKeyStore.cs` | Key files |
| `src/QrBridge.Shared/Signals/BridgeSignal.cs` | Named-event doorbells |

### 10.3 Design rules in the code

- `QrDiode.Core` stays independent of the bridge: no EF, no SQLite, no knowledge of SOAP. Bridge code lives in
  `QrBridge.*` and is referenced by the WPF apps.
- One way in (`OutboxWriter`), one way to read untrusted XML (`SafeXml`), one place for routes (`routes.json`).
- Options are read only after the host is built, so environment variables, command-line values and tests always
  override the files.
- The gateway refuses to start rather than accept messages nobody could decrypt or deliver: missing outbound key,
  invalid catalogue, or a lock timeout shorter than the delivery timeout.

---

## 11. Configuration reference

Configuration is layered: `appsettings.json` → `appsettings.{Corp|Dmz}.json` (chosen by `ASPNETCORE_ENVIRONMENT`, set
in `web.config`) → `routes.json` → environment variables (e.g. `Gateway__Egress__DefaultBaseUrl`) → command line.

**`Bridge`** — shared with the QR apps on the same machine; `Side` and `DataFolder` must match theirs.

| Key | Default | Meaning |
|---|---|---|
| `Side` | `Corp` | `Corp` or `Dmz` |
| `DataFolder` | `C:\ProgramData\QrBridge\Data` | where `outbound.db` and `inbound.db` live (local disk) |
| `MaxPayloadBytes` | `1000000` | largest request accepted / payload decoded |

**`Gateway`**

| Key | Default | Meaning |
|---|---|---|
| `KeyFolder` | `C:\ProgramData\QrBridge\Keys` | DPAPI key files |
| `OutboundKeyId` | `c2d-2026-11` (Corp), `d2c-2026-11` (Dmz) | key that seals what this side sends |
| `MaxBacklog` | `5000` | above this many undelivered Outbox rows, new calls get "busy" |
| `InboxPollSeconds` | `2` | worker poll interval (the doorbell usually wakes it sooner) |
| `MaxAttempts`, `BackoffBaseSeconds`, `BackoffMaxMinutes` | `8`, `30`, `30` | retry policy for transient delivery failures |
| `ReplayWindowDays`, `MaxClockSkewMinutes` | `7`, `60` | message age limits |
| `MaintenanceIntervalSeconds`, `LockTimeoutMinutes`, `RetentionDays` | `60`, `5`, `7` | housekeeping |
| `DebugPayloadCapture`, `DebugRetentionHours` | `false`, `24` | plain-text payload table — never in production |

**`Gateway:Egress`** — delivery to the real services on this side.

| Key | Default | Meaning |
|---|---|---|
| `DefaultBaseUrl` | empty (Corp); `http://dmz-rr-server` placeholder (Dmz) | the caller's original path is appended |
| `Targets:{Service}:Url`, `:TimeoutSeconds` | none | per-service override |
| `TimeoutSeconds` | `120` | per call; must stay below `LockTimeoutMinutes` |
| `UseDefaultCredentials` | `false` | authenticate as the app pool identity |
| `RewriteAddressingTo` | `true` | point `wsa:To` at the real service |
| `MaxResponseBytes` | `4000000` | largest reply read back |

**`Routing`** (in `routes.json`)

| Key | Meaning |
|---|---|
| `AcceptUnlisted` | accept SOAP calls to services not in the catalogue (test/discovery; `false` in production) |
| `UnlistedOneWay` | for unlisted calls, reply HTTP 202 instead of an empty SOAP reply |
| `ReplyProfiles:{Name}` | `ResultKind` (`FmsResponse`, `ReturnCode`, `None`) and the values `Ok`, `Busy`, `Unavailable`, `Rejected` |
| `Services[]` | `Name`, `Description`, `IngressSide`, `Paths[]`, `Style` (`Document`/`Rpc`), `ResultElement`, `Wsdl`, `WsdlAtPath`, `OtherOperations`, `Operations` |
| `Services[].Operations:{Op}` | `Mode` (`Bridge`/`Echo`/`Unavailable`/`Reject`), `Reply` (profile name), `OneWay`, `AllowedTypes[]`; the key `GET` describes plain HTTP GET calls |

`routes.json` is read at startup; after changing it, recycle the app pool. A catalogue error stops the start with a
list of the problems.

---

## 12. Build, test, publish and deploy

### 12.1 Build and test

```powershell
cd QrDiode_V2
dotnet build QrDiode.slnx                  # whole solution, 0 warnings
dotnet test  tests\QrBridge.Tests          # 136 tests, a few seconds
dotnet test  tests\QrDiode.Core.Tests      # 75 tests
```

Requires a released .NET 10 SDK (developed with 10.0.404) on Windows; the tests use DPAPI and Windows named events.
`.\scripts\verify.ps1` does all of the above in one go. Keep the solution at a short path (e.g. `C:\src\QrDiode_V2`):
from a very deep folder Windows refuses to load the native `ZXing.dll` ("filename or extension is too long").

### 12.2 What the tests prove

| Test class | Tests | Proves |
|---|---|---|
| `IngressTests` | 54 | **Every one of the simulator's 43 message templates**, sent to its real interface, gets the answer its caller expects (accepted with RETURN_CODE 0 / `0`, Unavailable 1599, Refused 1597, fault, or echo); accepted ones are stored encrypted and open back to the **exact request bytes** with the original path and `SOAPAction`. Also: duplicates, wrong message type, malformed payload, legacy RPC endpoint, unknown service/operation, non-SOAP and oversized requests, WSDL/XSD/legacy WSDL, probes, `/health`, backlog full. |
| `WcfClientTests` | 3 | **Real WCF client stacks** accept the gateway as the real service: BasicHttp (FC2FMS `SendToFMS`/`GetFromFMS`/`EchoString`), ASMX-style XmlSerializer (VZ2TLS, `long`), WSHttp SOAP 1.2 + WS-Addressing to a service the catalogue has never seen. |
| `EndToEndTests` | 5 | Corp gateway → sealed envelope carried across → DMZ gateway → fake real service: **identical bytes, path, `SOAPAction`**; a refusal ends in DeadLetter with the service's reason; a 503 is retried then delivered; a wrong-direction or tampered envelope is Rejected and never delivered. |
| `SoapParsingTests` | 18 | SOAP 1.1/1.2, WS-Addressing, RPC detection, action sources; DTDs and non-SOAP refused; labels from FMS, Verizon, tML-TA and malformed payloads. |
| `SoapReplyWriterTests` | 6 | Reply shapes: document/literal, RPC, SOAP 1.2 + addressing, faults 1.1/1.2, 202. |
| `RouteTableTests` | 11 | Path normalisation, resolution rules, side check, invalid catalogues fail, and the **shipped `routes.json`** is valid and covers the FMS interfaces. |
| `DeliveryClassificationTests` | 14 | How every kind of real-service answer is classified. |
| `EnvelopeTests` | 12 | Seal/open, header authentication, tamper and wrong-key detection, size and zip-bomb limits. |
| `RawSoapMessageTests` | 5 | The stored request round-trips byte for byte; bad input refused. |
| `StoreTests` | 8 | EF/SQLite mapping, atomic claims under concurrency, idempotent Inbox, dead letters and requeue, backoff, heartbeats. |

The published gateway was also run as a real process: it accepted a real SOAP call, replied `RETURN_CODE 0` with
`MSG_TYPE`/`MSG_ID`, served the WSDL with its own address and reported healthy.

### 12.3 Publish

```powershell
.\deploy\publish.ps1                       # -> QrDiode_V2\publish\
```

| Folder | Contents | Goes to |
|---|---|---|
| `publish\gateway\` | framework-dependent ASP.NET Core app, `web.config`, `routes.json`, `Wsdl\` | the IIS site folder, each side |
| `publish\sender\` | `QrDiode.Sender.exe`, self-contained single file (~134 MB) | kiosk PC |
| `publish\receiver\` | `QrDiode.Receiver.exe`, self-contained single file (~139 MB) | kiosk PC |
| `publish\keys\` | `QrDiode.KeyCeremony.exe`, self-contained single file | kiosk PC, key ceremony |

`QrBridge.Shared` is compiled into the gateway and the WPF apps; it is never deployed on its own.

### 12.4 Deploy, per side

1. Windows: IIS with Application Initialization, and the **.NET 10 Hosting Bundle**. Do **not** install WCF HTTP Activation.
2. Copy `publish\gateway\` to the site folder, then run `deploy\setup-iis.ps1 -Side Corp|Dmz` (app pool: No Managed
   Code, AlwaysRunning, idle time-out 0, no periodic recycle (one scheduled at 03:00), one worker process, generous
   shutdown time; site preload; `ASPNETCORE_ENVIRONMENT` in `web.config`).
3. `deploy\setup-folders.ps1 -KioskUser MACHINE\qrkiosk`: Data folder Modify for the app pool and the kiosk user; Keys
   folder Read for the app pool only.
4. Keys ([§7.3](#73-keys-and-the-key-tool)): generate this side's outbound key, import the other side's, compare
   fingerprints, destroy the transfer files.
5. `appsettings.{Side}.json`: `OutboundKeyId`; on the DMZ, `Egress:DefaultBaseUrl` = the RR servers (or per-service
   `Targets`).
6. Check `http://<server>/health` and `http://<server>/FMS_FC2FMSInterface/FC2FMSInterface.svc?wsdl`.
7. Kiosk PC: QR apps and `deploy\setup-station-kiosk.ps1` (power, screensaver, auto-start) — with the planned QR integration.
8. Islanding: re-point the load balancer (Corp) and the FMS outbound configuration (DMZ) — [§8.5](#85-switching-into-and-out-of-islanding-mode).

To confirm with the network team: does the load balancer forward the path unchanged, where is TLS terminated, what is
its health-probe URL, and how many servers sit behind it (it must send everything to one gateway, with any second
one only as standby). Behind TLS termination the `?wsdl` addresses currently show `http://`.

### 12.5 Try it on one PC

```powershell
src\QrBridge.Gateway\bin\Debug\net10.0-windows\QrBridge.Gateway.exe keys generate --id c2d-2026-11 --dir C:\QrBridgeDev\Keys
dotnet run --project src\QrBridge.Gateway --launch-profile "Gateway (Corp)"      # http://localhost:5080
```

Then send it the simulator's messages, for example with PowerShell (escape the template into the `sXML` element and
POST it with the `SOAPAction` header), or point the **fms-interface-simulator** at it by editing its
`Configuration.xml`, e.g. `<SSO_FMS_URL>http://localhost:5080/FMS_SSO2FMSInterface/SSO2FMSInterface.svc</SSO_FMS_URL>`.
For `.svc` URLs leave out `?wsdl` — the simulator treats any URL containing `.WSDL` as a legacy SOAP Toolkit endpoint.
(The tests use the simulator's templates and the same WCF client stack; the simulator application itself has not been
run against the gateway yet.)

---

## 13. How to add or change a service

**A new CorpNet → DMZ service** (e.g. MAXIMO calling an FMS-side service):

1. Find the path the caller uses as the load balancer forwards it, and its WSDL (style, namespaces, operations).
2. Add an entry to `routes.json`: `Name`, `IngressSide: "Corp"`, `Paths`, `Style`, `Wsdl`, and per operation a `Mode`,
   a reply profile and the `AllowedTypes`.
3. Copy its WSDL to `src/QrBridge.Gateway/Wsdl/<Name>/service.wsdl`; for WCF, its schemas as `xsd0.xsd`, `xsd1.xsd`…
   matched by the namespace each `?xsd=xsdN` import names.
4. On the delivering side: nothing if the real service lives under `DefaultBaseUrl` with the same path, otherwise
   `Gateway:Egress:Targets:<Name>:Url`.
5. Test: add a sample message and a case to `IngressTests`, run the tests.
6. Deploy `routes.json` and the `Wsdl` folder to **both** gateways; recycle the app pools.

**A DMZ → CorpNet service**: the same with `IngressSide: "Dmz"`; its delivery target is configured on the Corp gateway.

**Discovering an unknown service**: in a test environment set `Routing:AcceptUnlisted = true`; calls are bridged with
an automatic empty reply and stored under their path, so you can see exactly what arrives — then write the real entry.

**Changing the bridge's reply codes or texts**: edit `ReplyProfiles` in `routes.json`.

---

## 14. Status, open decisions and next steps

### 14.1 Built and verified

- Generic SOAP gateway: ingress for any SOAP request, route catalogue with allow-lists, reply profiles, metadata/WSDL
  serving, backpressure.
- Delivery worker: replay, answer classification, retries, dead letters, recovery, retention, heartbeats, `/health`.
- Shared data layer (EF Core + SQLite), sealed envelope with header label, DPAPI keys and key tool, doorbells.
- Catalogue for all CorpNet → DMZ interfaces in the simulator, with their WSDLs.
- 136 bridge tests + 75 QrDiode tests; publish script; IIS script check for WCF HTTP Activation.

### 14.2 Not built yet

| Item | Notes |
|---|---|
| QrDiode ↔ bridge: Core fix, Sender reads the Outbox + bundles, Receiver writes the Inbox, deferred anti-replay commit, unattended start, heartbeats | next step ([§9.2](#92-what-changes-to-connect-it-to-the-bridge-planned)) |
| Outbox statuses `Aired` (and `Confirmed` with receipts) | with the Sender work |
| EF migrations instead of `EnsureCreated` | before go-live |
| Islanding operations: stop-accepting switch, `/status` with a drained flag | before go-live |
| Per-order head-of-line blocking for retries | improves ordering |
| Sending refusals back to the caller's side as a response message | today refusals are visible on the receiving side only |
| DMZ → CorpNet catalogue entries | needs the corporate systems' endpoints (capture them first) |
| Record mode (transparent proxy that captures real requests/replies/WSDLs) | the easiest way to capture the above |
| FOD WCF WSDL; real DSS WSDL | replace the gap / the derived file |
| Forwarded headers (`X-Forwarded-Proto`) | only affects `?wsdl` addresses behind TLS termination |
| Dual-site (ECC/AECC) configuration and failover procedure | |
| Delivery receipts (D14) | needs security sign-off |

### 14.3 Decisions still open

| Question | Current state |
|---|---|
| Queries in islanding mode | answered "Unavailable" (1599); snapshot caching would need its own approval |
| Bridge reply codes 1597 / 1598 / 1599 | configurable; confirm with the Rapid Restore team that they don't clash |
| Do XA/21, BFC and Registered Tags cross the gap at all? | listed as Unavailable until confirmed |
| Load balancer details (path forwarding, TLS, probe URL, pool size) | needed from the network team |
| MAXIMO, OSS, NRI, Feeder Status payloads and endpoints | not in the simulator; capture them |
| Dual site: move queued rows on failover? dedupe across sites? AECC warm or cold? | open |
| Security sign-off for a two-way optical link | required before go-live |
| Bundling, ordering rule | designed in [Integration-Plan.md](Integration-Plan.md) §2.3 and §4; to be confirmed with the QrDiode work |

---

## 15. Glossary

| Term | Meaning |
|---|---|
| **FMS** | Feeder Management System (outages, work permits, tags, faults) — OpenROAD screens on Ingres, on the DMZ/OpNet side |
| **TOMS** | Transmission Operations Management System |
| **TLS** | Telephone Line System (also Trouble & Telecom Lease System) |
| **DSO** | Dielectric System Operation (also Distribution System Operations) |
| **RR** | Rapid Restore — the corporate application family whose roles call FMS |
| **FCR / FOD / SSO** | Feeder Control Representative / Field Operations Department / Substation Operator — Rapid Restore roles |
| **DSS / No. 9** | the application handling No. 9 orders; uses the legacy SOAP Toolkit endpoint |
| **FTC** | Fault Correlation |
| **BFC / IR2BFC** | Bus Fault Correlation |
| **XA/21** | the EMS (Energy Management System) SCADA platform |
| **VZN** | Verizon trouble reporting (eBonding) |
| **RT** | Registered Tags report |
| **ECC / AECC** | the primary control center site / the backup site |
| **CorpNet / DMZ / OpNet** | the corporate network / the FMS-side network zone |
| **Islanding mode** | the firewalls between CorpNet and the DMZ are cut; only light crosses |
| **Load balancer (LB)** | the corporate entry point the callers use; re-pointed to the gateway in islanding mode |
| **Gateway** | `QrBridge.Gateway`, one per side, in IIS |
| **Ingress / egress** | receiving callers' requests / delivering requests to the real services |
| **Outbox / Inbox** | the queue tables in `outbound.db` / `inbound.db` |
| **Envelope** | the sealed (AES-256-GCM) form of a message, identical in both sides' tables |
| **RawSoapMessage** | the caller's SOAP request bytes plus the headers needed to replay it |
| **Label / BusinessType** | `MESSAGE/@TYPE` or the payload's root element name, e.g. `RETURN_ORDER` |
| **Route catalogue** | `routes.json`: which services the gateway stands in for, and how it answers |
| **Reply profile** | the result values a gateway reply carries (Ok, Busy, Unavailable, Rejected) |
| **Allow-list** | the catalogue (services, operations) and each operation's `AllowedTypes` |
| **Doorbell** | a named Windows event one program sets to wake another |
| **DeadLetter** | a message that will not be retried automatically; needs an operator |
| **Bundle** | (planned) many envelopes in one QR session |
| **SOAP 1.1 / 1.2** | the two SOAP envelope versions (namespaces `…xmlsoap.org/soap/envelope/` / `…w3.org/2003/05/soap-envelope`) |
| **Document/literal (wrapped)** | the WCF/ASMX SOAP style: body element named after the operation, parameters as child elements |
| **RPC/encoded** | the old SOAP Toolkit style: unqualified parts, SOAP encoding |
| **SOAPAction** | the HTTP header (SOAP 1.1) naming the operation; in SOAP 1.2 an `action` Content-Type parameter |
| **WS-Addressing** | SOAP headers (`Action`, `MessageID`, `To`, `RelatesTo`) used by `WSHttpBinding` |
| **WSDL / XSD** | a service's contract description / its schemas |
| **DPAPI** | Windows Data Protection API; protects the key files |
| **AES-GCM** | authenticated encryption: decrypting also proves nothing was changed |
| **LT fountain code** | the coding QrDiode uses so the camera can miss frames without a back-channel |

---

## Appendix A. Wire examples

Formatted for reading; the real bytes have no extra whitespace.

### A.1 WCF caller, accepted (FCR → `FC2FMSInterface.svc`)

```http
POST /FMS_FC2FMSInterface/FC2FMSInterface.svc HTTP/1.1
Content-Type: text/xml; charset=utf-8
SOAPAction: "http://tempuri.org/IFC2FMSInterface/SendToFMS"

<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body>
    <SendToFMS xmlns="http://tempuri.org/">
      <sXML>&lt;MESSAGE TYPE="REQUEST_FOR_PERMIT" MSG_ID="679" GMT_TIME_SENT="08/09/2002 14:00:10"&gt; ... &lt;/MESSAGE&gt;</sXML>
    </SendToFMS>
  </s:Body>
</s:Envelope>
```

```http
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8
X-QrBridge-MessageId: cd3948ab-c001-488a-9913-f320af3e457d

<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body>
    <SendToFMSResponse xmlns="http://tempuri.org/">
      <SendToFMSResult>&lt;RESPONSE MSG_TYPE="REQUEST_FOR_PERMIT" MSG_ID="679"&gt;&lt;STATUS&gt;&lt;RETURN_CODE&gt;0&lt;/RETURN_CODE&gt;&lt;ERROR_MESSAGE&gt;&lt;/ERROR_MESSAGE&gt;&lt;/STATUS&gt;&lt;/RESPONSE&gt;</SendToFMSResult>
    </SendToFMSResponse>
  </s:Body>
</s:Envelope>
```

### A.2 WCF caller, query (Unavailable)

`GetFromFMS(<MESSAGE TYPE="GET_FEEDER_INFO" …>)` → HTTP 200, `GetFromFMSResult` =

```xml
<RESPONSE MSG_TYPE="GET_FEEDER_INFO" MSG_ID="456"><STATUS><RETURN_CODE>1599</RETURN_CODE>
<ERROR_MESSAGE>Not available while FMS is islanded (QR bridge mode): this request needs a live answer.</ERROR_MESSAGE></STATUS></RESPONSE>
```

### A.3 SOAP Toolkit caller, RPC/encoded (DSS → `RR_DSSFMSService.wsdl`)

```http
POST /FMSInterface/RR_DSSFMSService.wsdl HTTP/1.1
Content-Type: text/xml; charset=utf-8
SOAPAction: "http://tempuri.org/action/FMSInterface.SendToFMS"

<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                   SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
  <SOAP-ENV:Body>
    <SOAPSDK4:SendToFMS xmlns:SOAPSDK4="http://tempuri.org/message/">
      <XMLMsg>&lt;MESSAGE TYPE="NO9_MOVE_RESPONSE" MSG_ID="456" ...&gt; ... &lt;/MESSAGE&gt;</XMLMsg>
    </SOAPSDK4:SendToFMS>
  </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
```

```xml
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body>
    <m:SendToFMSResponse xmlns:m="http://tempuri.org/message/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
      <Result>0</Result>
    </m:SendToFMSResponse>
  </s:Body>
</s:Envelope>
```

### A.4 SOAP 1.2 + WS-Addressing caller, unlisted service (`AcceptUnlisted` on)

```http
POST /Test/NewService.svc HTTP/1.1
Content-Type: application/soap+xml; charset=utf-8; action="urn:qrbridge:test/INewService/DoWork"

<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://www.w3.org/2005/08/addressing">
  <s:Header>
    <a:Action s:mustUnderstand="1">urn:qrbridge:test/INewService/DoWork</a:Action>
    <a:MessageID>urn:uuid:7f6c...</a:MessageID>
    <a:To s:mustUnderstand="1">http://lb/Test/NewService.svc</a:To>
  </s:Header>
  <s:Body><DoWork xmlns="urn:qrbridge:test"><input>hello</input></DoWork></s:Body>
</s:Envelope>
```

```xml
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">
  <s:Header>
    <a:Action s:mustUnderstand="1" xmlns:a="http://www.w3.org/2005/08/addressing">urn:qrbridge:test/INewService/DoWorkResponse</a:Action>
    <a:RelatesTo xmlns:a="http://www.w3.org/2005/08/addressing">urn:uuid:7f6c...</a:RelatesTo>
  </s:Header>
  <s:Body><DoWorkResponse xmlns="urn:qrbridge:test" /></s:Body>
</s:Envelope>
```

The WCF client reads the result as `null`. On the delivering side the `wsa:To` header is pointed at the real service
before the replay.

### A.5 Refusals

```xml
<!-- Unknown path (SOAP 1.1), HTTP 500 -->
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body>
    <s:Fault>
      <faultcode>s:Client</faultcode>
      <faultstring xml:lang="en-US">'/Somewhere/Else.svc' is not a bridged service.</faultstring>
    </s:Fault>
  </s:Body>
</s:Envelope>
```

A message type the interface does not take (e.g. `RETURN_ORDER` sent to `FC2FMSInterface.svc`) gets HTTP 200 with
`RETURN_CODE 1597` and "Invalid XML MESSAGE TYPE for this interface (refused by the QR bridge)."

---

## Appendix B. Design record decisions and what changed

From the [design record PDF](../reference/QR-AirGap-Bridge-Design-Record.pdf) (19 Nov 2026):

| # | Decision | Status |
|---|---|---|
| D1 | WPF for the desktop app | unchanged |
| D2 | SQLite on a local folder, WAL, busy_timeout, synchronous=NORMAL | implemented |
| D3 | Two DB files per machine (outbound.db, inbound.db) | implemented |
| D4 | Outbox/Inbox tables are the queue; atomic claim; unique MessageId | implemented |
| D5 | Gateway replies only after the Outbox commit | implemented |
| D6 | Only fire-and-forget operations are bridged | implemented as the **Unavailable** mode for queries |
| D7 | One common envelope; contracts only in the gateways; registry = allow-list | **changed in form**: no contracts at all; the payload is the caller's raw SOAP request; `routes.json` is the allow-list |
| D8 | Authenticated header + Brotli + AES-256-GCM; one key per direction; KeyId; DPAPI | implemented; the header gained the `BusinessType` label |
| D9 | Named-event doorbells with polling fallback | implemented |
| D10 | No Windows service; workers inside the gateway in IIS | implemented |
| D11 | Heartbeat table; `/health` | implemented (QR apps' heartbeats planned) |
| D12 | QrDiode as the optical transport; retire QrBridge.Station | done: Station, its frame codec and ACK tracker were not carried over |
| D13 | Bridge envelope inside QrDiode's encryption (double layer) | by design; takes effect with the QR integration |
| D14 | Delivery receipts over the reverse lane | open — needs security sign-off |

Changed from the record's sections 8, 9 and 11:

- **CoreWCF hosted contracts → one generic SOAP endpoint** driven by `routes.json` (handles every style, including
  RPC/encoded, with no per-service code).
- **Typed downstream clients and handlers → `SoapForwarder`**, which replays the exact bytes and classifies the answer
  by the operation's reply profile.
- **`PayloadSerializer`, `FrameCodec`, the `InboundChunk` table → removed**: payloads are not re-serialized, and QrDiode
  reassembles QR sessions itself.
- **Integration plan reordered**: gateway first (done), then the QrDiode connection, then islanding operations and
  hardening — see [Integration-Plan.md](Integration-Plan.md).
