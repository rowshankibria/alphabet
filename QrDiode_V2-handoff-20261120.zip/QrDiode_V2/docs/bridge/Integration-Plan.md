# Integration plan — the work that remains

The design for everything **not built yet**, written against the code as it is on 20 Nov 2026. It replaces the
19 Nov design proposal: the gateway half of that proposal is now built (see [QR-Bridge-Guide.md](QR-Bridge-Guide.md)),
and its still-valid parts — connecting QrDiode, islanding operations, the remaining gateway items — are here.

Status per item, the verification state and the questions for Rowshan are in [../HANDOFF.md](../HANDOFF.md).
Settled decisions are in [../../.github/copilot-instructions.md](../../.github/copilot-instructions.md); don't reverse
them without asking.

## Contents

1. [Where we are](#1-where-we-are)
2. [Connecting QrDiode to the bridge](#2-connecting-qrdiode-to-the-bridge)
3. [Islanding operations](#3-islanding-operations)
4. [Remaining gateway items](#4-remaining-gateway-items)
5. [Order of work](#5-order-of-work)

---

## 1. Where we are

| Area | State |
|---|---|
| Gateway ingress (any SOAP request → Outbox, reply like the real service) | built, tested |
| Gateway egress (Inbox → replay to the real service, classify the answer) | built, tested |
| Route catalogue, WSDL serving, health, key tool, publish script | built |
| Shared data layer (EF Core + SQLite), envelope, keys, doorbells | built, tested |
| QrDiode apps reading the Outbox / writing the Inbox | **not built** — §2 |
| Islanding switch-in / switch-back tooling | **not built** — §3 |
| Ordering, record mode, refusals back to the caller, DMZ → Corp catalogue | **not built** — §4 |

Today the QR apps run on their own: the Sender airs simulator payloads or a file, the Receiver stores files under
`%LocalAppData%\QrDiode\` (`QrDiode.Core/QrDiodePaths.cs`). Neither knows about `outbound.db` / `inbound.db`.

---

## 2. Connecting QrDiode to the bridge

Rules that stay in force: the QrDiode **project structure stays as it is** (features are added inside the existing
projects), and **`QrDiode.Core` stays bridge-agnostic** — no EF, SQLite or SOAP in it. Bridge knowledge lives in
`QrBridge.Shared`, which the Sender and Receiver will reference.

### 2.1 Fix the receiver's stuck-session bug — first

`src/QrDiode.Core/Pipeline/ReceiveEngine.cs`, `FeedManifest`:

```csharp
// Already locked onto a session? Ignore repeats of it, and ignore other sessions.
if (_manifest is not null)
    return FeedResult.Ignored;
```

If the camera misses part of session A and the sender moves on, sessions B, C, D… are ignored forever, silently.
Fix (from the design record PDF, §10):

- repeats of the **current** session are still ignored (cheap session-tag comparison);
- a **different** manifest that passes parse + signature + addressed-to-us + not-already-settled + anti-replay
  (`Fresh`) **abandons** the partial session: mark it settled, raise a `SessionAbandoned` event carrying an
  `AbandonedSession` record, and lock onto the new one. A forged frame cannot force this, because the signature is
  checked first. Nor can a replayed recording, because the anti-replay check comes before the abandon;
- while locked, a different manifest that fails any check returns `Ignored`, **not** `Rejected`. The Receiver calls
  `engine.Reset()` after every rejection (`HandleRejection`), so a `Rejected` would drop the session after all;
- `SessionAbandoned` is raised outside the engine's lock, and the Receiver handles it with `Dispatcher.BeginInvoke`;
- the Receiver UI adds an "Incomplete … NOT received — must be re-sent" inbox row and a `receive.abandoned` audit
  event, without resetting the engine.

**Done when:** the new regression tests in `tests/QrDiode.Core.Tests/SessionAbandonTests.cs` pass, and all 75 existing
tests still pass. The new tests cover: a partial session followed by a new one → the new one completes; a forged or a
replayed manifest while locked → ignored, no abandon. Copilot prompt: `/fix-receive-engine-bug`.

### 2.2 Data model additions (`QrBridge.Shared`)

| Table | Add | Why |
|---|---|---|
| `Outbox` | statuses `Aired` (and later `Confirmed`, with receipts); columns `BundleId` (TEXT NULL), `QrSessionId` (TEXT NULL), `AiredUtc` (TEXT NULL) | QrDiode is one-way, so "sent" means "aired"; trace a row to its QR session |
| `Inbox` | `BundleId`, `QrSessionId` | trace a row to the QR session that carried it |

Store methods to add:

- `OutboxStore.ClaimBundleAsync(maxMessages, maxBytes)` — in one transaction, `UPDATE Outbox SET Status='Sending',
  BundleId=@b, LockedUtc=now WHERE Id IN (oldest Pending rows within the limits) AND Status='Pending'`, returning the
  claimed rows in `Id` order.
- `OutboxStore.MarkAiredAsync(bundleId, qrSessionId)`.
- `OutboxStore.ReleaseBundleAsync(bundleId, reason, retryDelay)`: back to `Pending`, due again after `retryDelay`.
  Use zero after a stage close or an operator skip, and about 30 s after an encode error, so a broken bundle cannot
  spin.
- `ResetSendingAsync` already exists: call it at Sender startup, and make it also clear `BundleId`.
- `InboxStore.AddMessagesAsync(envelopes, bundleId, qrSessionId, chunkCount)` — **one** transaction, idempotent on
  `MessageId` (duplicates skipped, not failed).
- Retention: purge `Aired` rows after `RetentionDays` (today only `Acked` rows are purged).

The CHECK constraints are generated from the enums (`SqlIn(..., Enum.GetNames<OutboxStatus>())`), so adding a status
changes the schema. Create the **first EF migrations** here, for each context (`dotnet ef migrations add …`; the
design-time factories exist in `Data/DatabaseSetup.cs`):
1. `Initial`, from the current model **before** changing it;
2. then one migration for the new columns.

`DatabaseInitializer` already applies migrations when they exist. But a database made by `EnsureCreated` has the
tables and no migration history, so `Initial` would fail on it. Add a baseline step that records `Initial` as
applied when the tables already exist.

**Done when:** store tests cover claim/aired/release/idempotent insert; the migration applies to a fresh database and
to one created by the current `EnsureCreated`.

### 2.3 Bundles — many messages per QR session

Why: one message per QR session costs at least 6 s of air time plus a 1.5 s gap (`TransmitEngine.MinAirSeconds`,
`GapSeconds`) — about 8 messages per minute per lane, too slow for a burst of FMS events.

New `QrBridge.Shared/Bundles/BundleCodec.cs`:

```
magic "QBB1" (4) · version (1) · count (uint16) · firstSeq (int64) · lastSeq (int64)
repeat count × { length (int32) · envelope bytes }
```

- The parser is bounded: `count ≤ MaxBundleMessages`, each `length ≤ MaxPayloadBytes + RawSoapMessage.MaxOverheadBytes`,
  the lengths must add up exactly to the remaining bytes. Any mismatch rejects the whole bundle, without throwing
  anything but `InvalidDataException`.
- The QrDiode session's filename is `bundle-{firstSeq}-{lastSeq}.qbb`, content kind `File`.
- Limits (Sender settings): `MaxBundleMessages` 50, `MaxBundleBytes` 128 KB. A lone message still goes out at once;
  bundling only happens when several rows are waiting.

**Done when:** round-trip tests pass, and malformed, truncated or oversized input is rejected cleanly. Copilot prompt
for §2.2 + §2.3: `/add-bundles-and-outbox-status`.

### 2.4 Sender: read the Outbox

The Sender is a plain WPF app (no generic host). Give it a small composition root: a `ServiceCollection` with
`AddBridgeData(options)`, logging and `BridgeSignals`; read `Bridge:Side` and `Bridge:DataFolder` from an
`appsettings.json` next to the exe (new; `CopyToOutputDirectory`), and run `DatabaseInitializer.InitializeAsync` at
startup. Keep the existing QrDiode settings and keys under `%LocalAppData%\QrDiode\` as they are.

- **Source switch:** `Sender:Source = Outbox | Simulator`. An `OutboxSource` replaces `LiveSource` when `Outbox`;
  the simulator stays for demos and the bench.
- **Claiming:** claim a bundle (§2.2) **only when the `TransmitEngine` queue is empty**, so at most one bundle waits
  behind the one on air. Check `QueuedCount == 0` on the UI thread: the engine and its queue belong to it. Enqueue it with `TransmitEngine.Enqueue(type, "bundle-….qbb", bundleBytes)`.
- **`TransmitEngine`:** never drop Outbox items (today `TrimQueue` skips the oldest beyond `MaxQueueDepth` = 14).
  `SessionEnded` fires only for items that went on air. So add an `ItemFinished` event raised for **every** final
  state, including an encode failure and a stage closed during encoding. On it:
  - `Sent` → `MarkAiredAsync(bundleId, sessionId)`;
  - `Skipped` → `ReleaseBundleAsync(…, TimeSpan.Zero)`;
  - `Failed` → `ReleaseBundleAsync(…, ~30 s)`.
- **Startup:** `ResetSendingAsync` (rows left in `Sending` by a crash go back to `Pending`).
- **Wake-up:** wait on the Outbox doorbell (`BridgeSignals.Outbox`), with a 2 s poll as fallback.
- **Heartbeat:** `Components.SenderLoop` every 30 s (shown by the gateway's `/health`).
- **Never block the UI thread:** all database work is `async`; UI updates go through the Dispatcher
  (see [../WPF-Tutorial.md](../WPF-Tutorial.md) §4).

**Done when:** a SOAP call to the gateway shows on the stage within about a second and its row ends `Aired`; killing
the Sender mid-session re-airs the bundle after restart; 200 concurrent calls air as bundles; nothing is dropped.
Copilot prompt: `/connect-sender-to-outbox`.

### 2.5 Receiver: write the Inbox

In `src/QrDiode.Receiver/MainWindow.xaml.cs`, `HandleCompletion`, before the existing journal/archive code:

```
if filename ends with ".qbb":
    bundle = BundleCodec.Parse(plaintext)                    -- fail → rejection row + audit event
    for each envelope: header = EnvelopeCodec.PeekHeader(envelope)   (no key needed)
                       require header.Direction == this side's inbound direction
    InboxStore.AddMessagesAsync(all, bundleId, sessionId)    -- ONE transaction, idempotent
    BridgeSignals.Inbox.Set()                                -- wake the gateway worker
    journal + audit + inbox UI row ("bundle 1042–1061, 20 messages")
    do NOT write the payload store: the Inbox is the store, and payloads stay encrypted (D13)
```

**Anti-replay commit order:** today `ReceiveEngine.FinishTransfer` calls `_replayGuard.Commit(...)` *before* the host
stores anything, so a crash in between loses the session silently. Change it to return the completed transfer
**without** committing and add an `engine.CommitReplay()` that the host calls after the Inbox transaction (or, for
non-bundle payloads, after the payload store write). The Inbox insert is idempotent, so the worst case after a crash
is a re-aired bundle whose rows are skipped as duplicates. If the Inbox write fails, don't commit. Reset the engine
**without** settling the session (`Reset(settle: false)`), so the session can still be received while the sender is
airing it.

Also: same composition root as the Sender; heartbeat `Components.ReceiverLoop`; **align packages** — the Receiver pins
`Microsoft.Data.Sqlite` 10.0.10 and `SQLitePCLRaw.bundle_e_sqlite3` 3.0.5, while EF Core 10.0.15 brings SQLitePCLRaw
2.1.13. One native SQLite per process: move the Receiver to the same `Microsoft.Data.Sqlite` as EF and let EF's
SQLitePCLRaw win (check the Receiver's own journal still works).

**Done when:** end to end on one PC (screen + webcam, or an optical loopback test): a call to the Corp gateway reaches
`Done` on the DMZ gateway; a duplicate bundle is not processed twice. Copilot prompt: `/connect-receiver-to-inbox`.

### 2.6 Unattended (kiosk) operation

- Both apps start without clicks: keys and peer from configuration, the stage on the configured monitor at the saved
  size, the saved camera.
- `deploy/setup-station-kiosk.ps1` assumes one "Station" exe: change it to register two tasks (Sender, Receiver) for
  the kiosk user.
- Run the apps **as the kiosk user**: QrDiode's keys and state are per Windows user (`%LocalAppData%`, CNG user store).

### 2.7 Later: one QR Station app per machine

Each machine has a screen facing out and a camera facing in, so a single WPF "QR Station" running both engines would
make it exactly two programs per machine (gateway + station). Both apps are thin shells over `QrDiode.Core`, so this
is a merge of UI and wiring, not of protocol. Not needed for the first end-to-end test.

---

## 3. Islanding operations

### 3.1 Switch in

Point the corporate load balancer at the Corp gateway, and the FMS outbound clients at the DMZ gateway. Everything is
already running (IIS AlwaysRunning, kiosk auto-start), so nothing has to start.

### 3.2 Switch back — without reordering

Queued messages must not arrive *after* newer ones sent over the restored network:

1. **Stop accepting** on both gateways (new admin endpoint, e.g. `POST /admin/stop-accepting`, protected): ingress
   then answers with the `Busy` reply profile.
2. Wait until **both** sides are drained: Outbox has no `Pending`/`Sending` rows (and the last bundle has been aired),
   Inbox has no `Pending`/`Processing`/`Failed` rows.
3. Flip the load balancer and the DMZ configuration back.
4. Handle any `DeadLetter` / `Rejected` rows by hand.

### 3.3 `/status`

Per side: queue depth per route, oldest undelivered age, DeadLetter/Rejected counts with the real service's
`ERROR_MESSAGE`, heartbeat staleness of gateway, sender and receiver, and a `drained` flag for step 2 above. Each side
is monitored on its own network; nothing crosses the gap for monitoring.

### 3.4 Two sites (ECC primary, AECC standby)

Each site's gateway and QR apps have their own databases and keys, and appear in the peers' trust stores. Open: do
queued rows move on failover (recommended: no — they go out when ECC returns); must Inbox deduplication span both
sites (yes, if both deliver into the same RR servers); is AECC warm or cold (recommended: warm).

**Done when:** a scripted switch-in / switch-back drill on test servers loses and reorders nothing.

---

## 4. Remaining gateway items

| Item | Design |
|---|---|
| **Ordering** | One worker processes the Inbox in arrival order, but a row in retry can be overtaken by a later one for the same order. Add an optional `OrderingKey` per operation in `routes.json` (e.g. the XPath `//FMS_ORDER_NUMBER \| //FMS_CARD_ID`, evaluated on the payload) and skip rows whose key matches a row still waiting to retry — head-of-line blocking per key, so one stuck order doesn't stall the others. |
| **Record mode** | `Gateway:Mode = Record` turns ingress into a transparent proxy to `Record:UpstreamUrl`: forwards the request, returns the real reply, and saves request + reply (path, headers, body) and `?wsdl` documents under the data folder. Never writes the Outbox; refused while islanded. The easiest way to capture the DMZ → Corp contracts, real reply texts and the missing WSDLs. |
| **Refusals back to the caller's side** | Today a refusal from the real service (`RETURN_CODE ≠ 0`) is a DeadLetter on the receiving side. Optionally send it back as a `MessageType.Response` with `CorrelationId` = the original `MessageId`, so the calling side can show it. |
| **Answers for queries** | Optional `LocalCache`: the far side periodically sends snapshots (authorised users, feeder list, registered tags) over the light, and the gateway answers queries from them. Needs its own approval. |
| **DMZ → Corp catalogue** | Add the corporate endpoints the FMS clients call, with `"IngressSide": "Dmz"` (capture them first — record mode). |
| **Missing / derived WSDLs** | `FOD2FMSInterface.svc` (missing), `RR_DSSFMSService.wsdl` (derived from FOD's). |
| **Forwarded headers** | Behind a TLS-terminating load balancer `?wsdl` addresses show `http://`; apply `X-Forwarded-Proto/Host` once the LB setup is known. |
| **Delivery receipts (D14)** | Small signed QrDiode sessions on the reverse lane confirming stored MessageIds; unconfirmed Aired rows re-air. Only after security sign-off. |

---

## 5. Order of work

| # | Step | Done when |
|---|---|---|
| 1 | §2.1 receiver fix | 75 + the new `SessionAbandonTests` pass |
| 2 | §2.2 data model + migrations, §2.3 bundle codec | store and codec tests pass; migration applies to fresh and existing DBs |
| 3 | §2.4 Sender | gateway call on the stage within ~1 s, row Aired; crash re-airs; nothing dropped |
| 4 | §2.5 Receiver | end to end on one PC reaches Done on the far gateway; duplicates skipped |
| 5 | §2.6 kiosk, §3 islanding operations | switch-in / switch-back drill clean |
| 6 | §4 items | per item |
| 7 | Hardening and rollout | load test (2–3× peak), 48–72 h soak, failure tests (camera blocked, app killed mid-message, IIS recycle under load, wrong key, oversized payload, real service down), reconciliation, one service at a time behind the LB |

After each step:
1. run `.\scripts\verify.ps1`;
2. update [../HANDOFF.md](../HANDOFF.md) (state, known issues, next steps) and the known-issues list in
   `.github/copilot-instructions.md`. The Copilot prompt `/update-handoff` does this.
