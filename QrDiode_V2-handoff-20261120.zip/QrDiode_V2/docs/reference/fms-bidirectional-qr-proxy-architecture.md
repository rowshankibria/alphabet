# FMS • Bidirectional QR Proxy — architecture diagram (transcription)

Transcribed from the one-page architecture diagram Rowshan shared on 20 Nov 2026 (file `2.pdf`). If you have the
original PDF, put it in this folder next to this file. Wording below follows the diagram; notes in *italics* map it to
this solution.

**Subtitle:** High-level overview • ECC / AECC DMZ & CorpNET • Zero code changes to existing applications
(configuration changes only).
**Banner:** Islanding mode • Zero app changes • Load-balancer switch • Light-only air-gap.

```
 ZONE 1: ECC & AECC DMZ                     AIR-GAP: QR stream           ZONE 2: CORPNET
 (existing FMS DMZ RR servers,              (light only, zero wire)      (unchanged corporate systems,
  local QR stream proxy)                                                  corporate load balancer, QR stream proxy)

 LANE 1 - OUTBOUND                                                       LANE 1 - DELIVERY
 [DMZ Outbound] --FMS update--> [DMZ QR Stream Sender] ==light==> [CorpNET QR Stream Listener] --verified update--> [Corporate Systems]
               <--instant OK--                    (HD camera in CorpNET)

 LANE 2 - INBOUND                                                        LANE 2 - INBOUND PROXY
 [DMZ Inbound] <--verified update-- [DMZ QR Stream Listener] <==light== [CorpNET QR Stream Sender] <--LB switch-- [Load Balancer] <--app update-- [Corporate Apps]
                                    (HD camera in ECC/AECC DMZ)                        --local OK--> ......................... --instant OK-->
```

## Lane 1 — Outbound (DMZ → CorpNET)

| Step | Box | Text on the diagram |
|---|---|---|
| 1 — Unchanged | **DMZ Outbound** — existing FMS DMZ RR services: Feeder (FCR) & Field (FOD), Substation (SSO) & Logs | FMS sends switching & outage updates just like normal days. Zero software or screen changes for control room operators. Outbound traffic points locally to the DMZ QR Sender. |
| 2 — Local proxy | **DMZ QR Stream Sender** — outbound proxy in ECC / AECC DMZ. Tags: Local Proxy Stand-In, Instant 'OK' Reply, Tamper-Proof Seal, Live QR Stream | Stands in locally for corporate apps so FMS runs untouched. Replies 'OK' immediately so FMS never waits or stalls. Locks and seals each update so nothing can be altered. Displays live QR codes on the local DMZ screen. |
| 3 — Optical receiver | **CorpNET QR Stream Listener** — optical camera receiver & forwarder in CorpNET. Tags: HD Camera Capture, Automatic Message Rebuild, Authenticity & Seal Check, Duplicate Filter | Watches the DMZ screen across the air-gap via a dedicated HD camera. Automatically pieces every multi-part QR message back together. Verifies each update is authentic, complete, and never duplicated. Delivers verified updates to the right corporate system with zero return wire. |
| 4 — Unchanged | **Corporate Systems** — enterprise portals & databases receiving FMS data: Rapid Restore (RR), MAXIMO, Feeder Status, Connected Systems | Corporate integrated systems (Rapid Restore) receive FMS updates in existing format. Crews and leadership keep live outage & switching visibility. Zero code, database, or workflow changes needed. |

*In this solution: step 2 = DMZ `QrBridge.Gateway` (ingress) + `QrDiode.Sender`; step 3 = Corp `QrDiode.Receiver` +
Corp `QrBridge.Gateway` (egress worker).*

## Lane 2 — Inbound (CorpNET → DMZ)

| Step | Box | Text on the diagram |
|---|---|---|
| 1 — Unchanged | **Corporate Apps** — inbound callers to FMS: Rapid Restore / MAXIMO, Fault Corr., OSS & NRI | Crew & field apps send updates just like normal. Still call the existing Corporate Load Balancer. Zero changes in any corporate app. |
| LB | **Load Balancer** — points to DMZ RR servers. Normal: → DMZ RR (cut). Islanding: → QR Sender | Normally routes traffic to our DMZ RR Servers. In an Islanding scenario, switched to CorpNET QR Sender. Redirects all inbound apps in one place. |
| 2 — Local proxy | **CorpNET QR Stream Sender** — inbound proxy in CorpNET. Tags: Stands in for DMZ RR, Instant 'OK' Reply, Tamper-Proof Seal, Live QR Code Stream | Receives redirected requests from the Corporate Load Balancer. Replies 'OK' right away so corporate apps never time out. Locks and seals each message against tampering. Streams live QR codes on the CorpNET screen toward the DMZ. |
| 3 — Optical receiver | **DMZ QR Stream Listener** — optical camera receiver in ECC / AECC DMZ. Tags: HD Camera Capture, Message Rebuild, Safety & Seal Check, Duplicate Filter | Reads the CorpNET QR screen from inside the DMZ via camera. Rebuilds each inbound message and checks its safety seal. Automatically filters out any duplicate or partial frames. Hands verified requests locally to existing DMZ RR servers. |
| 4 — Unchanged | **DMZ Inbound** — existing FMS DMZ RR servers: Substation, Field & Fault Updates. Delivers → Core FMS (OpNET) | Existing DMZ RR servers receive requests in normal format. Runs all standard FMS safety & validation rules. Delivers approved updates into Core FMS (OpNET). |

*In this solution: step 2 = Corp `QrBridge.Gateway` (ingress) + `QrDiode.Sender`; step 3 = DMZ `QrDiode.Receiver` + DMZ
`QrBridge.Gateway` (egress worker, delivering to the DMZ RR servers).*

## Air-gap column

- **True physical air-gap:** zero copper or fiber; dual one-way optical lanes.
- **Outbound • DMZ → CorpNET:** HD camera (CorpNET), light only.
- **ECC & AECC OpNET FWs — northbound cut / isolated:** no DMZ ↔ CorpNET wire. Firewalls disconnected from CorpNET in
  islanding mode.
- **Inbound • DMZ ← CorpNET:** HD camera (ECC/AECC DMZ), light only.
- **Dual-site optical deployment:** ECC primary — active optical pair; AECC backup — standby optical pair; paired with
  ECC & AECC DMZ.

## Legend

DMZ server traffic · optical QR stream (light only) · corporate app traffic · load balancer / core FMS ·
instant local 'OK' reply · disconnected OpNET FW · QR stream proxy · load balancer.

## What the diagram settled (see the guide for details)

- The bridge is an **islanding mode**, switched in by re-pointing the load balancer (Corp) and the FMS outbound
  configuration (DMZ) — zero code changes to existing applications.
- The RR WCF services run on the **DMZ RR servers**; the DMZ side delivers to them locally.
- Two sites (ECC active, AECC standby) — failover behaviour is still an open question.
- Corporate systems named on the diagram but not in the simulator: **MAXIMO, OSS, NRI, Feeder Status** — their
  payloads and endpoints still have to be captured.
