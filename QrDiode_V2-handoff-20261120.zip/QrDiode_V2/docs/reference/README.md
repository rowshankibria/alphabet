# Reference material

Everything the project was designed from, kept with the solution. The one exception is the fms-interface-simulator
copy: it is local only and is not in the repository or the handoff zip (see the table).
These files are **inputs**, not the current state — for that read [../bridge/QR-Bridge-Guide.md](../bridge/QR-Bridge-Guide.md)
and [../HANDOFF.md](../HANDOFF.md).

| File / folder | What it is | Use it for |
|---|---|---|
| [QR-AirGap-Bridge-Design-Record.pdf](QR-AirGap-Bridge-Design-Record.pdf) | The original design conversation (claude.ai, 19 Nov 2026): constraints, Q&A, decisions D1–D14, SQLite schema, envelope, IIS settings, QrDiode V2 review, open risks | Why things are the way they are. Ask Rowshan before reversing a D-decision. |
| [fms-bidirectional-qr-proxy-architecture.md](fms-bidirectional-qr-proxy-architecture.md) | Transcription of the one-page architecture diagram | Islanding mode, the two lanes, ECC/AECC |
| [fms-interface-simulator/](fms-interface-simulator/) | Copy of the `fms-interface-simulator` repository (VB.NET WinForms test harness). **Local only**: `.gitignore` and the handoff zip leave it out, because it is its own project. On a new machine, copy your simulator folder (the one that contains `docs\` and `simulator\`) here if you want these links to work. The build and the tests don't need it. | The real interfaces and payloads. Start at [fms-interface-simulator/docs/README.md](fms-interface-simulator/docs/README.md); per-interface workflows in `docs/integrations/`; message templates in `simulator/Application/templates/`; WSDLs and WCF client config in `simulator/FMSServiceProxies/` |

Where these were copied from on the original machine (`D:\Workstations\Developments\Con-Edison\Applications\qrcode-gateway\`):

- `docs\referencces\QR-AirGap-Bridge-Design-Record.pdf`
- `qrcode-gateway-nexus\fms-interface-simulator\fms-interface-simulator\`

The 19 Nov design proposal (`docs\design\gateway-and-qrdiode-design.md`) is no longer here. Its gateway half was built
differently, so it was retired on 20 Nov, and its still-valid parts moved into
[../bridge/Integration-Plan.md](../bridge/Integration-Plan.md).

Not copied, on purpose: `QrBridge.zip`, `Bridge.Core.zip` (the earlier CoreWCF-based design — superseded; the parts
still useful were moved into `src/QrBridge.Shared` and `src/QrBridge.Gateway`) and `QrDiode_V2.zip` (the original
QrDiode V2 download; the QrDiode projects in this solution are still unchanged from it).

Notes:

- The simulator's 43 message templates are also in `tests/QrBridge.Tests/Samples/` (test data), and its WSDLs in
  `src/QrBridge.Gateway/Wsdl/` (served by the gateway). Those copies are the ones the code uses.
- The simulator's WCF client config (`fms-interface-simulator/simulator/FMSServiceProxies/app.config`) has 16
  `basicHttpBinding`s with no `<security>` element, i.e. security mode None — no message-level security, which is what
  lets the gateway replay requests byte for byte.
- The simulator projects (`*.vbproj`) are .NET Framework 4.0 and are **not** part of `QrDiode.slnx`.
