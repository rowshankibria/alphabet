<#
.SYNOPSIS
  Packs this solution into one zip for moving it to another machine: source, docs, reference material and scripts —
  WITHOUT build output (bin/obj, several hundred MB), publish output, IDE caches, local databases and keys, or the
  local fms-interface-simulator copy (its own project). The same things .gitignore leaves out.

.DESCRIPTION
  On the other machine: unzip to a short path, open the QrDiode_V2 folder in VS Code, run .\scripts\verify.ps1.
  GitHub Copilot picks up .github\copilot-instructions.md; docs\HANDOFF.md has the current state.

.EXAMPLE
  .\scripts\pack-handoff.ps1                      # -> QrDiode_V2-handoff-<date>.zip next to the solution folder
  .\scripts\pack-handoff.ps1 -Output E:\QrDiode_V2.zip -Force
#>
param(
    [string]$Output,
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
if (-not $Output) {
    $Output = Join-Path (Split-Path $root -Parent) ("QrDiode_V2-handoff-" + (Get-Date -Format "yyyyMMdd") + ".zip")
}
if (Test-Path $Output) {
    if (-not $Force) { throw "$Output already exists. Use -Force to replace it." }
    Remove-Item $Output
}

# Same exclusions as .gitignore
$excludedFolders = @("bin", "obj", "publish", ".vs", "TestResults", ".git")
$excludedPaths = @("docs\reference\fms-interface-simulator")
$excludedExtensions = @(".key", ".transfer", ".db", ".db-wal", ".db-shm", ".user", ".suo")

$files = Get-ChildItem $root -Recurse -File -Force | Where-Object {
    $relative = $_.FullName.Substring($root.Length + 1)
    $folder = Split-Path $relative -Parent
    $folders = if ($folder) { $folder.Split('\') } else { @() }
    $inExcludedPath = $excludedPaths | Where-Object { $relative.StartsWith($_ + '\', [StringComparison]::OrdinalIgnoreCase) }
    -not $inExcludedPath -and
        -not ($folders | Where-Object { $excludedFolders -contains $_ }) -and
        ($excludedExtensions -notcontains $_.Extension)
}

Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::Open($Output, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($file in $files) {
        $entry = "QrDiode_V2/" + $file.FullName.Substring($root.Length + 1).Replace('\', '/')
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
            $zip, $file.FullName, $entry, [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
}
finally {
    $zip.Dispose()
}

Write-Host ("{0} files, {1:N1} MB -> {2}" -f $files.Count, ((Get-Item $Output).Length / 1MB), $Output) -ForegroundColor Green
