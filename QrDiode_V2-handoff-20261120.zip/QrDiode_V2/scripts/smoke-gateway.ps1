<#
.SYNOPSIS
  Runs the real gateway executable (no IIS) on a local port with throw-away keys and data, sends it one SOAP call
  built from a simulator message template, checks the reply, fetches the WSDL and /health, then stops it.

.DESCRIPTION
  Proves the built gateway works as a real process, outside the test harness. Everything it creates goes to a temp
  folder that is deleted afterwards (unless -Keep). Builds the gateway first if it has not been built.

.EXAMPLE
  .\scripts\smoke-gateway.ps1
  .\scripts\smoke-gateway.ps1 -Sample REQUEST_FOR_PERMIT.txt -Path /FMS_FC2FMSInterface/FC2FMSInterface.svc `
      -SoapAction http://tempuri.org/IFC2FMSInterface/SendToFMS
#>
param(
    [string]$Sample = "RETURN_ORDER.txt",
    [string]$Path = "/FMS_SSO2FMSInterface/SSO2FMSInterface.svc",
    [string]$Operation = "SendToFMS",
    [string]$SoapAction = "http://tempuri.org/ISSO2FMSInterface/SendToFMS",
    [int]$Port = 5181,
    [string]$Configuration = "Debug",
    [switch]$Keep
)

$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$exeDir = Join-Path $root "src\QrBridge.Gateway\bin\$Configuration\net10.0-windows"
$exe = Join-Path $exeDir "QrBridge.Gateway.exe"
if (-not (Test-Path $exe)) {
    # Native tools may write to stderr; with "Stop" Windows PowerShell 5.1 would treat that as a failure.
    $ErrorActionPreference = "Continue"
    & dotnet build (Join-Path $root "src\QrBridge.Gateway\QrBridge.Gateway.csproj") -c $Configuration -nologo
    $ErrorActionPreference = "Stop"
    if ($LASTEXITCODE -ne 0) { throw "Gateway build failed." }
}

$work = Join-Path ([IO.Path]::GetTempPath()) ("qrbridge-smoke-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path "$work\Keys", "$work\Data" | Out-Null
& $exe keys generate --id c2d-smoke --dir "$work\Keys" | Out-Host

# One argument string, quoted, so paths with spaces survive.
$arguments = "--urls http://localhost:$Port --environment Corp " +
             "`"--Bridge:DataFolder=$work\Data`" `"--Gateway:KeyFolder=$work\Keys`" --Gateway:OutboundKeyId=c2d-smoke"
$process = Start-Process -FilePath $exe -WorkingDirectory $exeDir -ArgumentList $arguments -PassThru -WindowStyle Hidden `
    -RedirectStandardOutput "$work\gateway.out.log" -RedirectStandardError "$work\gateway.err.log"

$failed = $false
try {
    $base = "http://localhost:$Port"
    $up = $false
    foreach ($i in 1..60) {
        try { Invoke-WebRequest "$base/health" -UseBasicParsing -TimeoutSec 2 | Out-Null; $up = $true; break }
        catch { if ($process.HasExited) { break }; Start-Sleep -Milliseconds 500 }
    }
    if (-not $up) { throw "The gateway did not start. See $work\gateway.out.log and gateway.err.log" }
    Write-Host "Gateway is up on $base" -ForegroundColor Cyan

    $payload = Get-Content (Join-Path $root "tests\QrBridge.Tests\Samples\$Sample") -Raw
    $escaped = [System.Security.SecurityElement]::Escape($payload)
    $body = "<s:Envelope xmlns:s=`"http://schemas.xmlsoap.org/soap/envelope/`"><s:Body>" +
            "<$Operation xmlns=`"http://tempuri.org/`"><sXML>$escaped</sXML></$Operation></s:Body></s:Envelope>"
    $response = Invoke-WebRequest -Uri "$base$Path" -Method Post -UseBasicParsing `
        -Body ([Text.Encoding]::UTF8.GetBytes($body)) -ContentType "text/xml; charset=utf-8" `
        -Headers @{ SOAPAction = "`"$SoapAction`"" }

    [xml]$reply = $response.Content
    $result = $reply.DocumentElement.LastChild.FirstChild.FirstChild.InnerText   # Envelope/Body/<Op>Response/<Op>Result
    [xml]$fms = $result
    $code = $fms.RESPONSE.STATUS.RETURN_CODE
    Write-Host "POST $Path ($Sample) -> HTTP $($response.StatusCode), RETURN_CODE $code, MessageId $($response.Headers['X-QrBridge-MessageId'])"
    if ($code -ne "0") { $failed = $true; Write-Host "Expected RETURN_CODE 0." -ForegroundColor Red }

    $wsdl = Invoke-WebRequest "$base$Path`?wsdl" -UseBasicParsing
    $addressOk = $wsdl.Content -match [regex]::Escape("location=`"$base$Path`"")
    Write-Host "GET ?wsdl -> HTTP $($wsdl.StatusCode), address points at this gateway: $addressOk"
    if (-not $addressOk) { $failed = $true }

    $health = Invoke-WebRequest "$base/health" -UseBasicParsing | ConvertFrom-Json
    Write-Host "GET /health -> side=$($health.side) healthy=$($health.healthy) outbox.pending=$($health.outbox.pending)"
    if ($health.outbox.pending -lt 1) { $failed = $true; Write-Host "Expected the call to be queued." -ForegroundColor Red }
}
finally {
    Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
    $process.WaitForExit(5000) | Out-Null
    if ($Keep) { Write-Host "Kept: $work" } else { Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue }
}

if ($failed) { throw "Smoke test FAILED." }
Write-Host "Smoke test passed." -ForegroundColor Green
