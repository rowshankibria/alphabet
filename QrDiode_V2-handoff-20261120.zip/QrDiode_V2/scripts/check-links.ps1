<#
.SYNOPSIS
    Checks that every relative Markdown link in the bridge documentation points to an existing file.

.DESCRIPTION
    Scans the *.md files in the solution root, docs\ and .github\ (docs\reference\fms-interface-simulator is a copy of
    another project and is skipped). Web links, mail links and pure #anchors are not checked; links inside fenced
    code blocks are ignored. Links into the simulator copy are checked only when that local copy exists: it is not in
    the repository. Exits with code 1 if any link is broken.

.EXAMPLE
    .\scripts\check-links.ps1
#>
$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$skip = Join-Path $root "docs\reference\fms-interface-simulator"
$simulatorPresent = Test-Path -LiteralPath $skip

$files = @(Get-ChildItem -LiteralPath $root -Filter *.md -File) +
         @(Get-ChildItem -LiteralPath (Join-Path $root "docs"), (Join-Path $root ".github") -Filter *.md -File -Recurse -Force |
           Where-Object { -not $_.FullName.StartsWith($skip, [StringComparison]::OrdinalIgnoreCase) })

$checked = 0
$broken = 0
$optional = 0
foreach ($file in $files) {
    $text = Get-Content -Raw -LiteralPath $file.FullName
    # Links inside fenced code blocks are examples, not links.
    $text = [regex]::Replace($text, '(?ms)^\s*```.*?^\s*```', '')

    foreach ($match in [regex]::Matches($text, '\[[^\]]*\]\(([^)\s]+)(?:\s+"[^"]*")?\)')) {
        $target = $match.Groups[1].Value
        if ($target -match '^(https?:|mailto:|#)') { continue }

        $path = [Uri]::UnescapeDataString(($target -split '#')[0])
        if ($path -eq '') { continue }

        try { $full = [IO.Path]::GetFullPath((Join-Path $file.DirectoryName $path)) }
        catch { $full = $null } # not a valid path at all: reported as broken below
        if ($full -and -not $simulatorPresent -and $full.StartsWith($skip, [StringComparison]::OrdinalIgnoreCase)) {
            $optional++
            continue
        }

        $checked++
        if (-not $full -or -not (Test-Path -LiteralPath $full)) {
            $broken++
            Write-Host ("BROKEN  {0}  ->  {1}" -f $file.FullName.Substring($root.Length + 1), $target) -ForegroundColor Red
        }
    }
}

Write-Host ("Checked {0} links in {1} files: {2} broken." -f $checked, $files.Count, $broken)
if ($optional -gt 0) {
    $message = "Skipped {0} links into docs\reference\fms-interface-simulator: that local copy is not here " +
               "(it is not in the repository; see docs\reference\README.md)."
    Write-Host ($message -f $optional) -ForegroundColor Yellow
}
if ($broken -gt 0) { exit 1 }
exit 0
