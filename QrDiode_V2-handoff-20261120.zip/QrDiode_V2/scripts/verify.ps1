<#
.SYNOPSIS
  Checks this solution on the current machine in one go: .NET SDK, restore, build, and every test project.
  Run it first on a new machine, and after any change.

.DESCRIPTION
  Expected result (handoff, 20 Nov 2026): build with 0 warnings / 0 errors, QrBridge.Tests 136 passed,
  QrDiode.Core.Tests 75 passed. Exit code 0 only if everything passed.

.EXAMPLE
  .\scripts\verify.ps1
  .\scripts\verify.ps1 -BridgeOnly
#>
param(
    [switch]$BridgeOnly   # skip the QrDiode.Core tests
)

# "Continue", not "Stop": in Windows PowerShell 5.1 a native tool's stderr output (e.g. a failing test's [FAIL] line)
# becomes an error record when output is captured, and "Stop" would abort the script there instead of reporting.
# Every dotnet call is checked through $LASTEXITCODE instead.
$ErrorActionPreference = "Continue"
$root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
if ($root.Length -gt 100) {
    Write-Host "Warning: this folder's path is $($root.Length) characters long. Deep paths can exceed Windows' 260-character" -ForegroundColor Yellow
    Write-Host "         limit for native DLLs (ZXing: 'filename or extension is too long'). Prefer e.g. C:\src\QrDiode_V2." -ForegroundColor Yellow
}
Push-Location $root
try {
    Write-Host "== .NET SDKs" -ForegroundColor Cyan
    $sdks = & dotnet --list-sdks
    $sdks | ForEach-Object { Write-Host "   $_" }
    if (-not ($sdks | Where-Object { $_ -match '^10\.0\.\d+ ' })) {
        throw "A released .NET 10 SDK is required (global.json pins 10.0.x). Install it from https://dotnet.microsoft.com/download/dotnet/10.0"
    }
    Write-Host "   using: $(& dotnet --version)"

    Write-Host "== Build QrDiode.slnx" -ForegroundColor Cyan
    & dotnet build QrDiode.slnx -nologo
    if ($LASTEXITCODE -ne 0) {
        # Known WPF tooling quirk: right after a RID-specific publish (deploy\publish.ps1), the next build of the WPF
        # projects can fail once with BG1002 "...baml cannot be found" or CS2001 "...g.cs could not be found" in obj\.
        # The build after that succeeds. Retry once; a second failure is a real error.
        Write-Host "== Build failed; retrying once (WPF incremental-build quirk after publish)" -ForegroundColor Yellow
        & dotnet build QrDiode.slnx -nologo
        if ($LASTEXITCODE -ne 0) { throw "Build failed." }
    }

    $projects = @("tests\QrBridge.Tests\QrBridge.Tests.csproj")
    if (-not $BridgeOnly) { $projects += "tests\QrDiode.Core.Tests\QrDiode.Core.Tests.csproj" }

    $results = foreach ($project in $projects) {
        Write-Host "== Test $project" -ForegroundColor Cyan
        & dotnet test $project --no-build -nologo
        [pscustomobject]@{ Project = $project; Result = if ($LASTEXITCODE -eq 0) { "passed" } else { "FAILED" } }
    }

    $results | Format-Table -AutoSize | Out-Host
    if ($results.Result -contains "FAILED") { throw "Some tests failed - see the output above." }
    Write-Host "Everything passed." -ForegroundColor Green
}
finally {
    Pop-Location
}
