---
description: 'PowerShell scripts for verify, smoke test, packaging, publishing and server setup'
applyTo: 'scripts/**,deploy/**'
---

# PowerShell scripts

- Target **Windows PowerShell 5.1** as well as PowerShell 7 (servers and kiosk PCs may only have 5.1).
- **Native commands (`dotnet`, `subst`, `icacls`…):** don't run them under `$ErrorActionPreference = "Stop"` while
  output may be captured — in 5.1 their stderr lines become terminating errors. Set `"Continue"` around the call and
  check `$LASTEXITCODE` (see `scripts/verify.ps1`, `deploy/publish.ps1`).
- `Start-Process -ArgumentList`: pass **one** string and quote values that may contain spaces
  (`"`"--Bridge:DataFolder=$path`""`) — 5.1 does not quote array elements.
- Resolve paths from `$PSScriptRoot`; never assume the current directory or a drive letter.
- Scripts that change a machine (`setup-iis.ps1`, `setup-folders.ps1`, `setup-station-kiosk.ps1`) start with
  `#Requires -RunAsAdministrator`, explain themselves in the comment help, and are safe to run twice.
- Never write keys, databases or payloads into the repository folder.
- `deploy/publish.ps1` is followed by a one-time WPF build quirk (BG1002/CS2001); keep the note it prints.
- `scripts/pack-handoff.ps1` excludes the same things as `.gitignore` (bin, obj, publish, keys, databases).
