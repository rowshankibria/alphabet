---
description: 'Test conventions for QrBridge.Tests and QrDiode.Core.Tests'
applyTo: 'tests/**'
---

# Tests

- xUnit 2.9. Run everything with `.\scripts\verify.ps1`; one project with `dotnet test tests\QrBridge.Tests`.
  Expected at handoff: QrBridge.Tests 136 passed, QrDiode.Core.Tests 75 passed.
- **Gateway integration tests** use `Gateway/Infrastructure/GatewayHost.cs`: the real `Program` (routes.json, EF/SQLite,
  DPAPI keys, workers) in memory with data and keys in a temp folder. Two hosts sharing a root = a Corp and a DMZ
  gateway. Override settings through the `settings` dictionary (e.g. `"Routing:AcceptUnlisted" = "true"`).
- **The real downstream service** is `FakeSoapService` (records requests, answers with `Responder`); pass
  `fake.CreateHandler` as the DMZ host's `egressHandler`.
- **Real WCF clients** (`WcfClients.cs`) talk to the in-memory gateway through a binding parameter that swaps WCF's
  HTTP handler — use them to prove caller compatibility.
- **Payloads** come from `Samples/` (the fms-interface-simulator's 43 templates). `IngressTests.Cases` maps every
  template to its interface and expected answer, and `Every_simulator_template_is_covered` fails if a template is not
  mapped — add a case for every new sample **and** update the file count it asserts (43).
- The QR link is simulated in `EndToEndTests.CarryAcrossAsync` by copying the sealed envelope from one host's Outbox to
  the other's Inbox — exactly what the QR apps will do.
- Tests must not depend on the network, a camera or IIS; they need Windows (DPAPI, named events).
- Assert behaviour callers depend on (reply shape and values, bytes passed verbatim), not implementation details.
