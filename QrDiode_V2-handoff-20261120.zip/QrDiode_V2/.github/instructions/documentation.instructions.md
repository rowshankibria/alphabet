---
description: 'Keeping the bridge documentation accurate, self-contained and in plain English'
applyTo: 'docs/**/*.md,*.md,.github/**/*.md'
---

# Documentation conventions

- **Self-contained:** this folder is moved between machines. Link only to files inside it, with relative links.
  Design inputs live in `docs/reference/` (design record PDF, architecture diagram notes). The fms-interface-simulator
  copy there is local only (`.gitignore`): link to it, but never commit it.
- **Plain, direct English** for Rowshan: short sentences, concrete examples, tables for comparisons. Explain WPF with
  Angular analogies.
- **Keep the living documents current** after every change:
  - `docs/HANDOFF.md` — state, verification results, known issues, next steps, open questions;
  - `.github/copilot-instructions.md` — known-issues list and next steps (keep its first ~4,000 characters for the
    most important rules: Copilot code review reads only that much);
  - `docs/bridge/QR-Bridge-Guide.md` — when behaviour, configuration or the catalogue changes;
  - `docs/bridge/Integration-Plan.md` — mark steps done, adjust the design to what was built;
  - `docs/GATEWAY.md` — one-page reference.
- Say what is **built and verified**, what is **planned**, and what was **not tried** — never present a plan as done.
- After editing docs run `.\scripts\check-links.ps1` (every relative link must resolve).
- Don't edit files under `docs/reference/` except `docs/reference/README.md`: they are inputs, kept as received.
