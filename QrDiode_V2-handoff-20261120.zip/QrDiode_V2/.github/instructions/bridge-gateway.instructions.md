---
description: 'Generic SOAP gateway (IIS) and shared bridge data layer: ingress, egress, route catalogue, envelope, SQLite'
applyTo: 'src/QrBridge.Gateway/**,src/QrBridge.Shared/**'
---

# QrBridge.Gateway and QrBridge.Shared

How it works: `docs/bridge/QR-Bridge-Guide.md` (§4 = how each WCF problem is solved). Quick reference: `docs/GATEWAY.md`.

## Invariants — keep them

- **Ingress order** (`Ingress/IngressEndpoint.cs`): body cap (413) → `SoapRequest.TryParse` (400) →
  `RouteTable.Resolve(path, operation)` → mode (Reject / Echo / Unavailable answer locally) → allow-list →
  `OutboxWriter.EnqueueAsync` (backlog check + commit) → **then** reply. Never reply OK before the commit; a failure
  before it must return a SOAP fault ("NOT accepted") or the profile's Busy/Rejected value.
- **Routing:** service by request **path** (case-insensitive, normalized), operation by the **first SOAP Body element**
  — not by SOAPAction (five legacy endpoints share one SOAPAction).
- **Verbatim:** `RawSoapMessage` keeps the exact body, the SOAPAction header as received (quotes included) and the
  Content-Type. The egress replays them unchanged; only a WS-Addressing `To` header may be rewritten.
- **Replies** (`Soap/SoapReplyWriter.cs`) follow WCF/ASMX conventions: `{Op}Response` / `{Op}Result` in the operation
  namespace (document), unqualified `Result` (RPC), same SOAP version, WS-Addressing `Action` = request action +
  "Response" and `RelatesTo`. Values come from reply profiles in `routes.json` — don't hard-code reply XML in C#.
- **Egress** (`Egress/SoapForwarder.cs`): target = `Gateway:Egress:Targets[service].Url` or `DefaultBaseUrl` + original
  path; never from the message; no redirects. `Classify`: SOAP fault (any status) → DeadLetter; 202 → Done; 2xx →
  Done when the return code is 0, DeadLetter (Refused) when it is not; timeout, network error or HTTP
  408/429/500/502/503/504 → Failed + backoff (DeadLetter after `MaxAttempts`); any other status → DeadLetter.
  Dead letters are never retried automatically.
- **Worker checks** (`Workers/InboxWorker.cs`): envelope authenticates; MessageId/service/operation/type columns match
  the header; direction is this side's inbound; payload is `RawSoap`; created within `ReplayWindowDays` and not more
  than `MaxClockSkewMinutes` in the future; a listed service has its `IngressSide` on the **other** side and the
  operation is in Bridge mode; an unlisted service needs `Routing:AcceptUnlisted`.
- **Untrusted XML** only via `SafeXml`. **Never log payloads.**
- The gateway refuses to start on a missing outbound key, an invalid catalogue, or `LockTimeoutMinutes` not longer
  than every egress timeout (+30 s). Keep those checks.

## Data layer (`QrBridge.Shared/Data`)

- EF Core with short-lived contexts from `IDbContextFactory`; stores are singletons. Enums stored as names, Guids as
  lower-case text, times UTC (`SqliteConventions`). CHECK constraints are generated from the enums.
- Queue pattern: atomic claim (`UPDATE … WHERE Id=@id AND Status='Pending'`), unique `MessageId`, idempotent Inbox
  insert, per-direction sequence via `UPDATE … RETURNING` in the insert's transaction.
- Schema is `EnsureCreated` today; any entity/enum change needs an EF migration once migrations exist
  (`docs/bridge/Integration-Plan.md` §2.2). Delete dev databases after changing entities until then.
- `outbound.db` is written by the gateway and read by the QR sender; `inbound.db` is written by the QR receiver and
  read by the gateway worker. Keep that ownership.

## Changing behaviour

- New or changed interface → `routes.json` (+ `Wsdl/<Name>/service.wsdl`, `xsdN.xsd` matched by namespace) + a case in
  `tests/QrBridge.Tests/Gateway/IngressTests.cs`. See the `add-bridged-service` prompt.
- Reply codes 1597/1598/1599 are reply-profile values in `routes.json`; changing them changes what callers see — ask first.
- Run `.\scripts\verify.ps1` after every change; for hosting changes also `.\scripts\smoke-gateway.ps1`.
