---
description: 'Build and test the whole solution, smoke-test the gateway exe, and explain any failure in plain English'
agent: 'agent'
---

Check that the solution is healthy on this machine and report back.

1. In a PowerShell terminal at the solution root, run `.\scripts\verify.ps1`.
   Expected: a .NET 10 SDK is found, the build has 0 warnings, `QrBridge.Tests` 136 passed, `QrDiode.Core.Tests`
   75 passed, last line `Everything passed.` Later steps of the
   [Integration Plan](../../docs/bridge/Integration-Plan.md) add tests; [HANDOFF §5](../../docs/HANDOFF.md) has the
   current counts.
2. Run `.\scripts\smoke-gateway.ps1` (the real gateway exe on port 5181: one SOAP call, the WSDL, `/health`).
   Expected last line: `Smoke test passed.`
3. If something fails, find the cause before touching code. Check the known environment traps first
   ([HANDOFF §7](../../docs/HANDOFF.md)):

   | Symptom | Cause | Fix |
   |---|---|---|
   | `DllNotFoundException` for ZXing, "filename or extension is too long" (0x800700CE) | the folder path is too deep | move the solution to a short path such as `C:\src\QrDiode_V2` (or map one with `subst`) |
   | `BG1002` / `CS2001` (missing `.baml` / `.g.cs`) right after `deploy\publish.ps1` | WPF incremental-build quirk | build again (`verify.ps1` retries once) |
   | a script stops at the first line a tool writes to stderr | Windows PowerShell 5.1 with `$ErrorActionPreference = "Stop"` | see `.github/instructions/scripts.instructions.md` |
   | SDK error that mentions `global.json` | no .NET 10 SDK installed | install the .NET 10 SDK; don't change `global.json` |
   | "running scripts is disabled" or "is not digitally signed" | Windows' script policy, or files marked as downloaded from the internet | run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` once, and `Unblock-File -Path (Get-ChildItem -Recurse -File).FullName` in the solution folder |
   | the smoke test cannot bind its port | something else uses 5181 | `.\scripts\smoke-gateway.ps1 -Port 5199` |

4. Change code only for a real bug: keep the fix minimal, add a test that fails without it, and run step 1 again.
5. Report in plain English: a table (step · result · counts), what you changed and why, and anything still failing
   with the exact error lines. Don't commit.
