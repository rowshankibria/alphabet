---
description: 'Bring HANDOFF.md, the Copilot instructions and the plan up to date after a change'
agent: 'agent'
---

Update the living documents, so the next person (or agent) starts from the truth. First look at what changed
(`git status` and `git diff`, or the files touched in this chat). Then:

1. Run `.\scripts\verify.ps1` and note the exact test counts.
2. `docs/HANDOFF.md`:
   - §2 history: add one row (date, what was done);
   - §3 decisions log: any new decision, with its reason;
   - §4 what was built and §5 verification: new features, test counts, which manual checks were run and their
     results;
   - §8 known issues: mark fixed ones as fixed (keep the number and say how) and add new ones;
   - §9 next steps and §10 open questions.
3. `.github/copilot-instructions.md`: update the "Known issues" list and "Next steps" (same numbering as HANDOFF §8),
   and the expected counts in the `verify.ps1` comment. Keep the top part short: Copilot code review reads only the
   first ~4,000 characters.
4. `.github/instructions/*.instructions.md`: remove known-issue bullets that are now fixed, and update the test
   counts.
5. `docs/bridge/Integration-Plan.md`: mark finished steps in §1 and §5, and correct the design text wherever the code
   now differs.
6. `docs/bridge/QR-Bridge-Guide.md` and `docs/GATEWAY.md`: update them when behaviour, configuration or the
   catalogue changed.
7. Run `.\scripts\check-links.ps1`: every relative link in the docs must resolve.

Write plainly. Say what is built and verified, what is planned, and what was not tried. Show Rowshan a short summary
of the doc changes. Don't commit.
