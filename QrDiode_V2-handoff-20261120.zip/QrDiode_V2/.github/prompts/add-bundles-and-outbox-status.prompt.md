---
description: 'Add the Outbox Aired status, bundle columns and store methods, the first EF migrations and the bundle codec (Integration Plan step 2)'
agent: 'agent'
---

Implement step 2 of the [Integration Plan](../../docs/bridge/Integration-Plan.md): §2.2 (data model) and §2.3
(bundle codec). The code goes in `src/QrBridge.Shared`, the tests in `tests/QrBridge.Tests`. Nothing in `QrDiode.*`
changes in this step.

## 1. Baseline migrations first, before changing any entity

Today the schema is created with `EnsureCreated`. Make the current model the first migration, so later changes are
upgrades:

```powershell
dotnet new tool-manifest                      # once; keep .config/dotnet-tools.json in the repo
dotnet tool install dotnet-ef --version 10.0.15
dotnet ef migrations add Initial --project src\QrBridge.Shared --startup-project src\QrBridge.Shared --context OutboundDbContext --output-dir Data\Migrations\Outbound
dotnet ef migrations add Initial --project src\QrBridge.Shared --startup-project src\QrBridge.Shared --context InboundDbContext --output-dir Data\Migrations\Inbound
```

The design-time factories are in `Data/DatabaseSetup.cs`. `DatabaseInitializer` already calls `MigrateAsync` once
migrations exist. But a database made by `EnsureCreated` has the tables and no `__EFMigrationsHistory`, so `Initial`
would fail with "table already exists". Add a **baseline** step to `InitializeOneAsync`: if no migration is applied
and the context's main table (`Outbox` / `Inbox`) exists, create the history table and record the first migration
(`db.Database.GetMigrations().First()`) as applied, using `IHistoryRepository.GetCreateIfNotExistsScript()` and
`GetInsertScript(new HistoryRow(id, ProductInfo.GetVersion()))`. Then run `MigrateAsync`.

From now on every entity or enum change needs `dotnet ef migrations add <Name>` for the affected context. EF refuses
to migrate when the model has pending changes.

## 2. Data model (§2.2)

- `OutboxStatus`: add `Aired`. Keep the existing names: they are stored as text and used in CHECK constraints.
- `OutboxMessage`: `BundleId` (Guid?), `QrSessionId` (Guid?), `AiredUtc` (DateTime?); add an index on `BundleId`.
- `InboxMessage`: `BundleId` (Guid?), `QrSessionId` (Guid?).
- Then `dotnet ef migrations add AiredAndBundles` for each context. The CHECK constraint on `Status` changes, so
  the SQLite provider rebuilds the table: check that the generated migration keeps all rows and indexes.

## 3. Store methods

`OutboxStore` (follow `ClaimNextAsync`: a short-lived context and an optimistic claim):

- `ClaimBundleAsync(int maxMessages, int maxBytes, CancellationToken ct)` returns the claimed rows in `Id` order
  plus a new `BundleId`, or null. In one transaction:
  1. pick the oldest due `Pending` rows (`NextAttemptUtc` null or past) whose bundle size fits `maxBytes`, always
     at least one row;
  2. run `UPDATE … SET Status='Sending', BundleId=@b, LockedUtc=now, Attempts=Attempts+1 WHERE Id IN (…) AND Status='Pending'`;
  3. return only the rows that were actually claimed.
- `MarkAiredAsync(Guid bundleId, Guid qrSessionId, CancellationToken ct)`: `Sending` → `Aired`; set `QrSessionId`
  and `AiredUtc`; clear `LockedUtc`.
- `ReleaseBundleAsync(Guid bundleId, string reason, TimeSpan retryDelay, CancellationToken ct)`: `Sending` →
  `Pending`, with `NextAttemptUtc = now + retryDelay`. Clear `BundleId` and `LockedUtc`, and set `LastError`. Not a
  failure: nothing was aired. The Sender passes zero after a stage close or operator skip, and about 30 s after an
  encode error, so a broken bundle cannot spin.
- `ResetSendingAsync`: also clear `BundleId`.
- `GetCountsAsync` / `OutboxCounts`: add `Aired`, and keep `/health` and the tests that read the counts in step.
- Retention: purge `Aired` rows older than the retention period, like `PurgeAckedAsync` (which `MaintenanceWorker`
  calls).

`InboxStore.AddMessagesAsync(IReadOnlyList<(EnvelopeHeader Header, byte[] Envelope)> messages, Guid bundleId, Guid qrSessionId, int chunkCount, CancellationToken ct)`
returns `(int Added, int Duplicates)`. Use **one** transaction. Skip MessageIds that are already present, and also
duplicates inside the batch. Map rows the same way `AddMessageAsync` does.

## 4. Bundle codec (§2.3): `src/QrBridge.Shared/Bundles/BundleCodec.cs`

Little-endian (`BinaryPrimitives`), in the style of `Envelope/EnvelopeCodec.cs`:
`"QBB1"` · version (1 byte) · count (uint16) · firstSeq (int64) · lastSeq (int64) · count × { length (int32) · envelope bytes }.

- `byte[] Build(IReadOnlyList<(long Sequence, byte[] Envelope)> items)` and
  `Bundle Parse(ReadOnlySpan<byte> data, int maxMessages, int maxEnvelopeBytes)`.
- The parser is bounded:
  - count is 1..`maxMessages`;
  - each length is 1..`maxEnvelopeBytes` (`BridgeOptions.MaxPayloadBytes + RawSoapMessage.MaxOverheadBytes`);
  - the lengths add up exactly to the remaining bytes;
  - `firstSeq ≤ lastSeq`.

  Any problem → `InvalidDataException`; no other exception type may escape.
- `BundleCodec.FileName(firstSeq, lastSeq)` → `bundle-{firstSeq}-{lastSeq}.qbb`.

## Tests

- `StoreTests`:
  - the claim respects `maxMessages`, `maxBytes`, order and `NextAttemptUtc`, and a row is never in two bundles;
  - the aired and release transitions;
  - `ResetSendingAsync` clears bundles;
  - the bulk insert is idempotent (on re-insert, and with duplicates within one batch).
- New `BundleCodecTests`:
  - round trip with one message and with many;
  - wrong magic or version, truncated input, extra bytes, a count of 0 or above the limit, and a negative or
    oversized length all throw `InvalidDataException`.
- Migrations:
  - a fresh database ends on the latest migration;
  - a database in the **old EnsureCreated state** also ends on the latest migration, with its data kept. Simulate
    that state by applying only `Initial` (`IMigrator.MigrateAsync("<Initial id>")`), inserting a row, then dropping
    `__EFMigrationsHistory` (and `__EFMigrationsLock` if present). Then run `DatabaseInitializer.InitializeAsync`.

## Done when

`.\scripts\verify.ps1` passes. Then run [update-handoff](update-handoff.prompt.md) (known issues 5 and 6, test
counts, Integration Plan step 2) and explain to Rowshan what changed in the databases. Don't commit.
