---
description: 'Make the QrDiode Sender air bundles from the Outbox (Integration Plan step 3)'
agent: 'agent'
---

Implement [Integration Plan §2.4](../../docs/bridge/Integration-Plan.md). This needs step 2 (bundles, the `Aired`
status and the store methods). Check that `OutboxStore.ClaimBundleAsync` and `BundleCodec` exist; if they don't,
stop and say so. Rowshan is new to WPF: explain the WPF parts of the change with Angular analogies (see
[the WPF tutorial](../../docs/WPF-Tutorial.md)).

Read these first:
- `src/QrDiode.Sender/MainWindow.xaml.cs` (creates `TransmitEngine` and `LiveSource`, handles `SessionEnded`);
- `Transmit/TransmitEngine.cs`;
- `Transmit/QueueItem.cs`;
- `App.xaml.cs`.

## Steps

1. **References and settings.** Reference `src/QrBridge.Shared` from `QrDiode.Sender.csproj` (not from
   `QrDiode.Core`). Add `appsettings.json` next to the exe (`CopyToOutputDirectory=PreserveNewest`; check it also
   lands next to the single-file exe from `deploy\publish.ps1`) with these keys:
   - `Bridge:Side`;
   - `Bridge:DataFolder`;
   - `Sender:Source`: `Outbox` or `Simulator`, default `Simulator` so demos keep working;
   - `Sender:MaxBundleMessages` (50);
   - `Sender:MaxBundleBytes` (131072).

   Pin any new `Microsoft.Extensions.*` packages to the version `QrBridge.Shared` uses. QrDiode keys and settings
   stay in `%LocalAppData%\QrDiode\` as today.
2. **Composition root** in `App.xaml.cs`: a `ServiceCollection` with configuration, logging, `AddBridgeData()`
   (options bound from `Bridge`) and `BridgeSignals`.
   - Run `DatabaseInitializer.InitializeAsync` at startup **without blocking the UI thread**.
   - If the database can't be opened, show the error and stay in Simulator mode. Don't crash.
3. **`TransmitEngine` changes** (small, in place):
   - Never trim Outbox items. Add `Guid? BundleId` to `QueueItem`, and make `TrimQueue` skip items that carry one.
   - Add an `ItemFinished` event, raised once for **every** item that reaches a final state (Sent, Skipped or
     Failed). Include the encode-failure path and the "stage closed during encode" path. Today `SessionEnded` fires
     only for items that went on air, so a bundle that fails to encode would stay `Sending` forever.
4. **`OutboxSource`** (new file `Transmit/OutboxSource.cs`), used instead of `LiveSource` when
   `Sender:Source=Outbox`:
   - At start, call `OutboxStore.ResetSendingAsync`: rows a crash left in `Sending` go back to `Pending`.
   - Run a background loop with a `CancellationToken`. Each pass waits on the Outbox doorbell
     (`BridgeSignals.Outbox`) or a 2 s timeout.
   - `TransmitEngine` and its queue belong to the UI thread, so check `QueuedCount == 0` there
     (`Dispatcher.InvokeAsync`). Only then call `ClaimBundleAsync(max…)`. At most one bundle waits behind the one on
     air.
   - Build the bytes with `BundleCodec.Build`, and the `PayloadType` the way `EnqueueFile` does
     (`PayloadCatalogue.ForFilename(name, ContentKind.File)`).
   - Enqueue on the UI thread with `TransmitEngine.Enqueue(type, BundleCodec.FileName(first, last), bytes)`, and set
     the item's `BundleId`.
   - On `ItemFinished`:
     - `Sent` → `MarkAiredAsync(bundleId, item.SessionId)`;
     - `Skipped` → `ReleaseBundleAsync(bundleId, reason, TimeSpan.Zero)`;
     - `Failed` → `ReleaseBundleAsync(bundleId, item.Error, 30 s)`, and show the error.
   - Every 30 s, call `HeartbeatStore.BeatAsync(Components.SenderLoop, info)`, where info is the queue depth and the
     last bundle.
   - When the window closes, stop the loop and release any bundle that is still queued (not on air).
5. **UI:** show the source (Outbox or Simulator), the Outbox backlog (`GetCountsAsync`) and the current bundle's
   sequence range. Keep the simulator controls, but disable them in Outbox mode.
6. Never block the UI thread and never use `.Result` / `.Wait()`. Database calls are `async`, and UI objects are
   touched only on the UI thread.

## Check

The Sender has no test project. Keep logic that can be tested without WPF in `QrBridge.Shared`, and test it in
`QrBridge.Tests`. Then check by hand:

1. Create the dev key once:
   `dotnet run --project src\QrBridge.Gateway -- keys generate --id c2d-2026-11 --dir C:\QrBridgeDev\Keys`.
   Then start the Corp gateway: `dotnet run --project src\QrBridge.Gateway --launch-profile "Gateway (Corp)"` (port
   5080, data in `C:\QrBridgeDev\Corp\Data`).
2. Start the Sender with `Bridge:Side=Corp`, `Bridge:DataFolder=C:\QrBridgeDev\Corp\Data` and
   `Sender:Source=Outbox`.
3. POST a sample to `http://localhost:5080` the way `scripts/smoke-gateway.ps1` does. It should appear on the stage
   within about a second, and its Outbox row should end `Aired`.
4. Kill the Sender while a bundle is on air. After a restart, the same rows go out again.
5. Send 200 calls quickly. They should air as bundles of up to 50, and none may be dropped: the Outbox counts must
   add up.

## Done when

The manual checks pass, `.\scripts\verify.ps1` passes, and `deploy\publish.ps1` still produces a working Sender exe
with its `appsettings.json`. Then run [update-handoff](update-handoff.prompt.md) (known issues 2 and 5, Integration
Plan step 3, HANDOFF verification). Don't commit.
