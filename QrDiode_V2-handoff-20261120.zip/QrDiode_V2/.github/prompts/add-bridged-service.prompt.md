---
description: 'Add or change a bridged SOAP/WCF interface: routes.json, WSDL, egress target, sample, tests and docs'
agent: 'agent'
---

Add or change one interface that the gateway stands in for. Services are **configuration, not code**: don't add C#
per service. The user's message names the service. Ask for anything on this list that is missing:

- the caller and the real service, the **path** the caller uses (as the load balancer forwards it), and which side
  the callers are on;
- the operations (SOAP Body element names), and for each one: Bridge, Echo, Unavailable (it needs a live answer) or
  Reject;
- the reply shape: an FMS `<RESPONSE>` document, a number, or nothing (one-way);
- for bridged operations, the accepted message types (`MESSAGE/@TYPE` or the root element);
- a real request sample, and the WSDL (`?wsdl` and `?xsd=…`) if there is one;
- the real service's URL on the delivering side.

Background:
- [QR-Bridge-Guide §4.4 and §13](../../docs/bridge/QR-Bridge-Guide.md) (route catalogue, reply profiles, how to
  add a service);
- [GATEWAY.md](../../docs/GATEWAY.md);
- the contracts of the existing interfaces in `docs/reference/fms-interface-simulator/docs/integrations/`. This is a
  local copy and not in the repository: if it is missing, ask Rowshan where the simulator is.

## Steps

1. **`src/QrBridge.Gateway/routes.json`**: add or change the entry under `Routing:Services`, following the existing
   ones.
   - Service fields:
     - `Name`: short and stable, because it is stored in every message;
     - `Description`, `IngressSide`, `Paths`;
     - `Style`: `Document` or `Rpc`;
     - `Wsdl`, and `WsdlAtPath` for legacy SOAP Toolkit endpoints;
     - `ResultElement`: only when the reply element is not `{Op}Result` / `Result`;
     - `OtherOperations`.
   - Each operation: `Mode`, `Reply` (`FmsResponse` or `ReturnCode`), `OneWay`, `AllowedTypes`.

   The same file is deployed on both sides.
2. **WSDL** (if there is one): `src/QrBridge.Gateway/Wsdl/<Name>/service.wsdl` plus `xsd0.xsd`, `xsd1.xsd`…, exactly
   as the real service serves them. The gateway rewrites the addresses, and imports are matched by namespace. Update
   `Wsdl/README.md`.
3. **Delivering side:** `Gateway:Egress:DefaultBaseUrl` plus the same path already covers services on that host.
   Otherwise add `Gateway:Egress:Targets:<Name>:Url` (and `TimeoutSeconds` if needed) in `appsettings.Dmz.json` or
   `appsettings.Corp.json`. `LockTimeoutMinutes` must stay longer than every timeout plus 30 s, or the gateway refuses
   to start.
4. **Tests** (`tests/QrBridge.Tests`):
   - Add the sample to `Samples/`.
   - For a new endpoint, add a static `FmsEndpoint` in `Gateway/Infrastructure/SoapCalls.cs`, for example
     `Svc("FMS_X2YInterface", "X2YInterface")`.
   - Add a case in `IngressTests.Cases`, and update the file count asserted in
     `Every_simulator_template_is_covered`.
   - If a WCF client calls the service, add a real-WCF-client test like those in `WcfClientTests`.
   - If you added a WSDL, add a WSDL test (address rewritten, `?xsd=` served).
5. Run `.\scripts\verify.ps1`.
6. **Docs:** update the catalogue in `docs/bridge/QR-Bridge-Guide.md`, `docs/GATEWAY.md` if it lists services, and
   `docs/HANDOFF.md` (what changed, and any open question it answers or raises).

Never route by SOAPAction alone, and never re-serialize the caller's request. Ask Rowshan before changing reply codes
or anything existing callers already depend on. Don't commit.
