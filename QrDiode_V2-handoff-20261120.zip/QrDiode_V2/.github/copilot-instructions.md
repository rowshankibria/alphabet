# GitHub Copilot Instructions — QR Air-Gap Bridge (`QrDiode_V2`)

Con Edison FMS **islanding mode**: when the firewalls between CorpNet and the FMS DMZ (ECC/AECC) are cut, SOAP/WCF
calls between the corporate apps (Rapid Restore FCR/FOD/SSO, DSS, FTC, Verizon) and the FMS-side services cross a
**light-only air gap** — QR codes on a screen, read by a camera, one lane per direction. Per side: **`QrBridge.Gateway`**
(IIS) stands in for the services on the other side and replays arrived calls to the real ones; **`QrDiode.Sender` /
`QrDiode.Receiver`** (WPF exe) carry sealed messages over the light. They meet only through
`C:\ProgramData\QrBridge\Data\{outbound,inbound}.db` (EF Core + SQLite) and two named events.

## Settled decisions — never reverse without asking Rowshan

1. **Callers cannot change** (not Con Ed's project). Corp callers reach services only via the **corporate load
   balancer**; islanding = LB re-pointed to the Corp gateway; DMZ side = configuration changes only. The gateway must
   be indistinguishable from the real service: same paths, SOAPActions, reply shapes and return types.
2. **Generic SOAP gateway that handles ANY WCF request** (SOAP 1.1/1.2, WS-Addressing, document/literal, RPC/encoded),
   driven by `src/QrBridge.Gateway/routes.json`. **No CoreWCF, no per-service contract classes.**
3. **One solution** `QrDiode.slnx`. **Keep the QrDiode project structure** (Core, KeyCeremony, Sender, Receiver: same
   folders and names) **but implement features inside them** — notably EF Core SQLite access.
4. **Deployables:** gateway → IIS site; Sender/Receiver/KeyCeremony → self-contained single-file exe;
   `QrBridge.Shared` compiled into both. Two programs per machine, no Windows service.
5. **.NET 10 LTS**, Windows only (`global.json` pins 10.0; bridge packages 10.0.15). Do not move to .NET 11.

## Rules in the code

- **One way into the bridge:** `OutboxWriter`. Reply to the caller **only after the Outbox commit**.
- **Never re-serialize a caller's request:** `RawSoapMessage.Body` passes through byte for byte (legacy quirks like
  `<SOURCE_APPLICAION>` and static `MSG_ID="456"` must survive; never dedupe on `MSG_ID`).
- **Untrusted XML only through `SafeXml`** (DTDs prohibited, no resolver, size caps).
- **Egress URLs only from configuration** (`Gateway:Egress`), never from a message.
- **Services are configuration:** new/changed interfaces = `routes.json` + `Wsdl/<Name>/` + a test — not code.
- **`QrDiode.Core` stays bridge-agnostic** (no EF, SQLite or SOAP). Bridge code lives in `QrBridge.*`.
- **Never log payloads** — only service, operation, label, ids and sizes.
- Options are read after `Build()` through `IOptions<T>`. Pin package versions; no wildcards.
- Match the surrounding code: naming, comment density, "why" comments. Keep changes small and tested.

## Working with Rowshan

- Owns the project; **new to WPF, comes from Angular** — explain WPF/XAML with Angular analogies.
- Wants **direct, plain English** and practical answers; when there are options, recommend one.
- Ask before restructuring projects or changing anything callers depend on. Don't commit or push unless asked.

## Build and check (Copilot agent mode can run these)

```powershell
.\scripts\verify.ps1          # SDK check + build + all tests — expected: 0 warnings, 136 + 75 passed
.\scripts\smoke-gateway.ps1   # real gateway exe on localhost:5181, one SOAP call, WSDL, /health
.\deploy\publish.ps1          # publish\gateway (IIS) + sender/receiver/keys single-file exe
.\scripts\check-links.ps1     # every relative link in the docs resolves
dotnet test tests\QrBridge.Tests --filter "FullyQualifiedName~EndToEnd"
```

Environment traps (details in `docs/HANDOFF.md` §7):

- Keep the solution at a **short path** (e.g. `C:\src\QrDiode_V2`): deep paths make Windows refuse to load the native
  `ZXing.dll` ("filename or extension is too long", 0x800700CE).
- Right after `deploy\publish.ps1` the next build of the WPF projects can fail **once** (BG1002/CS2001: missing
  `.baml`/`.g.cs` in `obj`) — build again (`verify.ps1` retries).
- Windows PowerShell 5.1: don't run `dotnet` under `$ErrorActionPreference = "Stop"` while capturing output (stderr
  lines become terminating errors); check `$LASTEXITCODE`.

## Map

| Path | What |
|---|---|
| `src/QrBridge.Gateway/` | IIS app: `Program.cs` (composition, startup checks), `Ingress/` (SOAP in; WSDL/health), `Soap/` (parse any SOAP, build replies, read replies), `Routing/` (catalogue + `RouteTable`), `Bridge/OutboxWriter.cs`, `Egress/SoapForwarder.cs`, `Workers/` (InboxWorker, MaintenanceWorker), `routes.json`, `Wsdl/` |
| `src/QrBridge.Shared/` | `Data/` (entities, EF configs, DbContexts, stores), `Envelope/` (EnvelopeCodec, RawSoapMessage), `Security/` (DPAPI keys), `Signals/` (doorbells) |
| `src/QrDiode.Core/` | QR wire protocol, LT fountain codes, crypto; `Pipeline/ReceiveEngine.cs` |
| `src/QrDiode.Sender/`, `src/QrDiode.Receiver/` | WPF apps (`Transmit/TransmitEngine.cs`; `MainWindow.xaml.cs` → `HandleCompletion`) |
| `tests/QrBridge.Tests/` | `Gateway/Infrastructure/GatewayHost.cs` (real gateway in memory), `FakeSoapService.cs`, `Samples/` (simulator templates) |
| `tests/QrDiode.Core.Tests/` | QrDiode protocol tests |
| `deploy/`, `scripts/` | publish/IIS/folders/kiosk; verify/smoke/check-links/pack |
| `docs/` | `HANDOFF.md`, `bridge/QR-Bridge-Guide.md`, `bridge/Integration-Plan.md`, `GATEWAY.md`, `WPF-Tutorial.md`, `reference/` |

## Known issues (as of 20 Nov 2026)

1. `ReceiveEngine.FeedManifest` ignores every manifest while locked on a session: one partly received QR session
   silences the receiver until restart. **Fix first** (`docs/bridge/Integration-Plan.md` §2.1).
2. `TransmitEngine` drops queued items beyond 14 — wrong once the Outbox is the source.
3. `ReceiveEngine` commits the anti-replay watermark before the host stores the payload (crash window).
4. Receiver pins `Microsoft.Data.Sqlite` 10.0.10 + `SQLitePCLRaw` 3.0.5; EF Core 10.0.15 uses SQLitePCLRaw 2.1.13 —
   align when wiring EF into the Receiver.
5. Outbox rows stay `Pending` until the QR sender exists (no `Aired` status yet).
6. Schema via `EnsureCreated` (no migrations): after an entity change delete dev databases; add migrations before go-live.
7. `FOD2FMSInterface.svc` WSDL missing; DSS WSDL derived from FOD's.
8. `?wsdl` shows `http://` behind TLS termination (no forwarded headers).
9. `deploy/setup-station-kiosk.ps1` still assumes one "Station" app.
10. No DMZ → Corp services in `routes.json` (corporate endpoints never captured).

## Next steps

Follow `docs/bridge/Integration-Plan.md` §5: receiver fix → data model + bundles + migrations → Sender reads the Outbox
→ Receiver writes the Inbox → kiosk + islanding operations. After each step run `.\scripts\verify.ps1` and update
`docs/HANDOFF.md` and the known-issues list above.

## Reusable prompts and agents

Prompts in `.github/prompts/` (type `/` in Copilot Chat): `verify-solution`, `fix-receive-engine-bug`,
`add-bundles-and-outbox-status`, `connect-sender-to-outbox`, `connect-receiver-to-inbox`, `add-bridged-service`,
`update-handoff`. Custom agents in `.github/agents/`: `bridge-architect`, `wpf-mentor`.
Path-specific rules in `.github/instructions/` apply automatically to matching files.

## Open questions — ask Rowshan, don't decide alone

Queries in islanding (currently "Unavailable", 1599) · bridge codes 1597/1598/1599 OK with the Rapid Restore team? ·
do XA/21, BFC, Registered Tags cross the gap? · load balancer details · MAXIMO/OSS/NRI payloads · dual-site behaviour ·
security sign-off · bundling and ordering rules (`docs/HANDOFF.md` §10).
