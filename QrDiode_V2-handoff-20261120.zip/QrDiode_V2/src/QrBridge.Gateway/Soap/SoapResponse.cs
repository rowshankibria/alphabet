using System.Xml;

namespace QrBridge.Gateway.Soap;

/// <summary>The parts of a real service's SOAP reply the egress side needs: fault or result text.</summary>
public sealed class SoapResponse
{
    public bool IsFault { get; private init; }
    public string? FaultReason { get; private init; }

    /// <summary>Text of the first element inside the response wrapper (e.g. SendToFMSResult), or null.</summary>
    public string? ResultText { get; private init; }

    /// <summary>Returns null when the bytes are not a SOAP envelope.</summary>
    public static SoapResponse? TryParse(byte[] body, long maxCharacters)
    {
        if (body.Length == 0) return null;
        XmlDocument doc;
        try
        {
            doc = SafeXml.Load(body, maxCharacters);
        }
        catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
        {
            return null;
        }

        var envelope = doc.DocumentElement;
        if (envelope is null || envelope.LocalName != "Envelope" ||
            envelope.NamespaceURI is not (SoapNamespaces.Soap11 or SoapNamespaces.Soap12))
            return null;

        string env = envelope.NamespaceURI;
        var bodyElement = SoapRequest.ChildElement(envelope, "Body", env);
        var first = bodyElement is null ? null : SoapRequest.FirstChildElement(bodyElement);
        if (first is null) return new SoapResponse();

        if (first.LocalName == "Fault" && first.NamespaceURI == env)
        {
            string? reason = env == SoapNamespaces.Soap11
                ? FindDescendant(first, "faultstring")?.InnerText
                : FindDescendant(first, "Text")?.InnerText;
            return new SoapResponse { IsFault = true, FaultReason = reason?.Trim() };
        }

        var result = SoapRequest.FirstChildElement(first);
        return new SoapResponse { ResultText = result?.InnerText };
    }

    private static XmlElement? FindDescendant(XmlElement parent, string localName) =>
        parent.GetElementsByTagName("*").OfType<XmlElement>().FirstOrDefault(e => e.LocalName == localName);
}
