using System.Net.Http.Headers;
using System.Xml;

namespace QrBridge.Gateway.Soap;

public enum SoapVersion { Soap11, Soap12 }

public static class SoapNamespaces
{
    public const string Soap11 = "http://schemas.xmlsoap.org/soap/envelope/";
    public const string Soap12 = "http://www.w3.org/2003/05/soap-envelope";
    public const string SoapEncoding = "http://schemas.xmlsoap.org/soap/encoding/";
    /// <summary>WS-Addressing 1.0 (WCF WSHttpBinding, Soap12WSAddressing10).</summary>
    public const string Addressing10 = "http://www.w3.org/2005/08/addressing";
    /// <summary>WS-Addressing August 2004 (older WCF/WSE stacks).</summary>
    public const string Addressing200408 = "http://schemas.xmlsoap.org/ws/2004/08/addressing";

    public static string Envelope(SoapVersion version) => version == SoapVersion.Soap12 ? Soap12 : Soap11;

    public static string ContentType(SoapVersion version) =>
        version == SoapVersion.Soap12 ? "application/soap+xml; charset=utf-8" : "text/xml; charset=utf-8";

    public static bool IsAddressing(string ns) => ns is Addressing10 or Addressing200408;
}

/// <summary>The WS-Addressing headers of a request, needed to correlate the reply.</summary>
public sealed record AddressingInfo(string Namespace, string? Action, string? MessageId, string? To);

/// <summary>
/// What the gateway needs to know about any SOAP request — SOAP 1.1 or 1.2, document/literal or RPC/encoded,
/// with or without WS-Addressing — without knowing the service's contract.
/// </summary>
public sealed class SoapRequest
{
    public required SoapVersion Version { get; init; }

    /// <summary>Local name of the first element in the Body, e.g. "SendToFMS". Used as the operation name.</summary>
    public required string Operation { get; init; }

    /// <summary>Namespace of that element (the reply wrapper uses the same namespace).</summary>
    public required string OperationNamespace { get; init; }

    /// <summary>True when the operation's parameters are unqualified — the RPC/encoded shape.</summary>
    public required bool ParametersUnqualified { get; init; }

    /// <summary>Text of the first parameter (sXML, XMLMsg, sValue...), or null if it has element content.</summary>
    public string? FirstParameterText { get; init; }

    /// <summary>The SOAPAction header exactly as received (quotes included), or null.</summary>
    public string? SoapActionHeader { get; init; }

    /// <summary>The action, unquoted: wsa:Action, else SOAPAction header, else the Content-Type action parameter.</summary>
    public string? Action { get; init; }

    public AddressingInfo? Addressing { get; init; }

    /// <summary>
    /// Parses a request body. Never throws for bad input: returns false with a reason that is safe to show
    /// to the caller. DTDs are prohibited (XXE / entity expansion) and nothing external is resolved.
    /// </summary>
    public static bool TryParse(byte[] body, string? contentType, string? soapActionHeader, long maxCharacters,
                                out SoapRequest? request, out string error)
    {
        request = null;
        XmlDocument doc;
        try
        {
            doc = SafeXml.Load(body, maxCharacters);
        }
        catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
        {
            error = "The request is not well-formed XML: " + ex.Message;
            return false;
        }

        var envelope = doc.DocumentElement;
        if (envelope is null || envelope.LocalName != "Envelope" ||
            envelope.NamespaceURI is not (SoapNamespaces.Soap11 or SoapNamespaces.Soap12))
        {
            error = "The request is not a SOAP 1.1 or SOAP 1.2 envelope.";
            return false;
        }

        var version = envelope.NamespaceURI == SoapNamespaces.Soap12 ? SoapVersion.Soap12 : SoapVersion.Soap11;
        string envNs = envelope.NamespaceURI;

        var header = ChildElement(envelope, "Header", envNs);
        var bodyElement = ChildElement(envelope, "Body", envNs);
        if (bodyElement is null)
        {
            error = "The SOAP envelope has no Body.";
            return false;
        }

        var operation = FirstChildElement(bodyElement);
        if (operation is null)
        {
            error = "The SOAP Body is empty.";
            return false;
        }
        if (operation.LocalName == "Fault" && operation.NamespaceURI == envNs)
        {
            error = "A SOAP Fault is not a request.";
            return false;
        }

        var parameter = FirstChildElement(operation);
        string? parameterText = parameter is null ? null
            : HasElementChildren(parameter) ? null
            : parameter.InnerText;

        var addressing = ReadAddressing(header);
        string? httpAction = Unquote(soapActionHeader);
        if (string.IsNullOrEmpty(httpAction)) httpAction = ContentTypeAction(contentType);

        request = new SoapRequest
        {
            Version = version,
            Operation = operation.LocalName,
            OperationNamespace = operation.NamespaceURI,
            ParametersUnqualified = parameter is not null && parameter.NamespaceURI.Length == 0,
            FirstParameterText = parameterText,
            SoapActionHeader = soapActionHeader,
            Action = addressing?.Action is { Length: > 0 } wsaAction ? wsaAction : NullIfEmpty(httpAction),
            Addressing = addressing,
        };
        error = "";
        return true;
    }

    private static AddressingInfo? ReadAddressing(XmlElement? header)
    {
        if (header is null) return null;
        string? ns = null, action = null, messageId = null, to = null;
        foreach (XmlNode node in header.ChildNodes)
        {
            if (node is not XmlElement e || !SoapNamespaces.IsAddressing(e.NamespaceURI)) continue;
            ns = e.NamespaceURI;
            switch (e.LocalName)
            {
                case "Action": action = e.InnerText.Trim(); break;
                case "MessageID": messageId = e.InnerText.Trim(); break;
                case "To": to = e.InnerText.Trim(); break;
            }
        }
        return ns is null ? null : new AddressingInfo(ns, action, messageId, to);
    }

    /// <summary>SOAP 1.2 carries the action as a Content-Type parameter: application/soap+xml; action="...".</summary>
    private static string? ContentTypeAction(string? contentType)
    {
        if (string.IsNullOrWhiteSpace(contentType) || !MediaTypeHeaderValue.TryParse(contentType, out var media))
            return null;
        var action = media.Parameters.FirstOrDefault(p => p.Name.Equals("action", StringComparison.OrdinalIgnoreCase));
        return Unquote(action?.Value);
    }

    private static string? Unquote(string? value)
    {
        if (value is null) return null;
        string v = value.Trim();
        return v.Length >= 2 && v[0] == '"' && v[^1] == '"' ? v[1..^1] : v;
    }

    private static string? NullIfEmpty(string? s) => string.IsNullOrWhiteSpace(s) ? null : s;

    internal static XmlElement? ChildElement(XmlElement parent, string localName, string ns)
    {
        foreach (XmlNode node in parent.ChildNodes)
            if (node is XmlElement e && e.LocalName == localName && e.NamespaceURI == ns)
                return e;
        return null;
    }

    internal static XmlElement? FirstChildElement(XmlElement parent)
    {
        foreach (XmlNode node in parent.ChildNodes)
            if (node is XmlElement e)
                return e;
        return null;
    }

    private static bool HasElementChildren(XmlElement element)
    {
        foreach (XmlNode node in element.ChildNodes)
            if (node is XmlElement)
                return true;
        return false;
    }
}

/// <summary>The one way this project loads untrusted XML.</summary>
public static class SafeXml
{
    public static XmlReaderSettings Settings(long maxCharacters) => new()
    {
        DtdProcessing = DtdProcessing.Prohibit, // no DOCTYPE at all: blocks XXE and entity expansion
        XmlResolver = null,
        MaxCharactersInDocument = maxCharacters,
        IgnoreComments = true,
        IgnoreProcessingInstructions = true,
    };

    public static XmlDocument Load(byte[] bytes, long maxCharacters)
    {
        using var reader = XmlReader.Create(new MemoryStream(bytes, writable: false), Settings(maxCharacters));
        return Load(reader);
    }

    public static XmlDocument LoadText(string text, long maxCharacters)
    {
        using var reader = XmlReader.Create(new StringReader(text), Settings(maxCharacters));
        return Load(reader);
    }

    private static XmlDocument Load(XmlReader reader)
    {
        var doc = new XmlDocument { XmlResolver = null, PreserveWhitespace = false };
        doc.Load(reader);
        return doc;
    }
}
