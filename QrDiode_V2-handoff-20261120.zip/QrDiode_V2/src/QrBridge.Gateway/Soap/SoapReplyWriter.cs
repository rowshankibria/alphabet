using System.Text;
using System.Xml;
using QrBridge.Gateway.Routing;

namespace QrBridge.Gateway.Soap;

/// <summary>An HTTP reply to a SOAP caller. ContentType is null for an empty 202.</summary>
public sealed record SoapReply(int StatusCode, byte[] Body, string? ContentType);

/// <summary>
/// Builds the replies a WCF/ASMX/SOAP Toolkit client accepts, following the standard conventions:
///   request  &lt;SendToFMS xmlns="X"&gt;            (document/literal wrapped)
///   reply    &lt;SendToFMSResponse xmlns="X"&gt;&lt;SendToFMSResult&gt;value&lt;/SendToFMSResult&gt;
///   rpc      &lt;m:SendToFMSResponse xmlns:m="X"&gt;&lt;Result&gt;value&lt;/Result&gt;
/// in the request's SOAP version, and with WS-Addressing Action/RelatesTo when the request used WS-Addressing.
/// </summary>
public static class SoapReplyWriter
{
    private const string XmlNamespace = "http://www.w3.org/XML/1998/namespace";

    private static readonly XmlWriterSettings WriterSettings = new()
    {
        Encoding = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false),
        OmitXmlDeclaration = true,
        Indent = false,
    };

    /// <summary>A reply carrying <paramref name="value"/> as the operation's result.</summary>
    public static SoapReply Result(SoapRequest request, MessageStyle style, string? resultElement, string value) =>
        Build(request.Version, request.Addressing, ReplyAction(request), 200, w =>
        {
            string env = SoapNamespaces.Envelope(request.Version);
            if (style == MessageStyle.Rpc)
            {
                w.WriteStartElement("m", request.Operation + "Response", request.OperationNamespace);
                if (request.Version == SoapVersion.Soap11)
                    w.WriteAttributeString("s", "encodingStyle", env, SoapNamespaces.SoapEncoding);
                w.WriteElementString(resultElement ?? "Result", "", value); // RPC parts are unqualified
            }
            else
            {
                w.WriteStartElement(request.Operation + "Response", request.OperationNamespace);
                w.WriteElementString(resultElement ?? request.Operation + "Result", request.OperationNamespace, value);
            }
            w.WriteEndElement();
        });

    /// <summary>
    /// A reply with no result element. Read by WCF as null (strings), the default value (numbers) or a
    /// normal completion (void) — the safest automatic reply when the contract is unknown.
    /// </summary>
    public static SoapReply EmptyResponse(SoapRequest request) =>
        Build(request.Version, request.Addressing, ReplyAction(request), 200, w =>
        {
            w.WriteStartElement(request.Operation + "Response", request.OperationNamespace);
            w.WriteEndElement();
        });

    /// <summary>One-way operations: HTTP 202, no body.</summary>
    public static SoapReply Accepted() => new(202, [], null);

    /// <summary>A SOAP fault in the given version. Sender faults blame the request, receiver faults the gateway.</summary>
    public static SoapReply Fault(SoapVersion version, AddressingInfo? addressing, bool senderFault, string reason,
                                  int statusCode = 500) =>
        Build(version, addressing, addressing is null ? null : FaultAction(addressing), statusCode, w =>
        {
            string env = SoapNamespaces.Envelope(version);
            w.WriteStartElement("s", "Fault", env);
            if (version == SoapVersion.Soap11)
            {
                w.WriteElementString("faultcode", "", senderFault ? "s:Client" : "s:Server");
                w.WriteStartElement("faultstring", "");
                w.WriteAttributeString("xml", "lang", XmlNamespace, "en-US");
                w.WriteString(reason);
                w.WriteEndElement();
            }
            else
            {
                w.WriteStartElement("s", "Code", env);
                w.WriteElementString("s", "Value", env, senderFault ? "s:Sender" : "s:Receiver");
                w.WriteEndElement();
                w.WriteStartElement("s", "Reason", env);
                w.WriteStartElement("s", "Text", env);
                w.WriteAttributeString("xml", "lang", XmlNamespace, "en-US");
                w.WriteString(reason);
                w.WriteEndElement();
                w.WriteEndElement();
            }
            w.WriteEndElement();
        });

    /// <summary>WCF's default reply action is the request action + "Response".</summary>
    private static string? ReplyAction(SoapRequest request) =>
        request.Addressing is null ? null
        : request.Action is { Length: > 0 } action ? action + "Response"
        : null;

    private static string FaultAction(AddressingInfo addressing) =>
        addressing.Namespace == SoapNamespaces.Addressing10
            ? "http://www.w3.org/2005/08/addressing/soap/fault"
            : "http://schemas.xmlsoap.org/ws/2004/08/addressing/fault";

    private static SoapReply Build(SoapVersion version, AddressingInfo? addressing, string? action, int status,
                                   Action<XmlWriter> writeBodyContent)
    {
        string env = SoapNamespaces.Envelope(version);
        using var ms = new MemoryStream();
        using (var w = XmlWriter.Create(ms, WriterSettings))
        {
            w.WriteStartElement("s", "Envelope", env);
            if (addressing is not null)
            {
                w.WriteStartElement("s", "Header", env);
                if (action is not null)
                {
                    w.WriteStartElement("a", "Action", addressing.Namespace);
                    w.WriteAttributeString("s", "mustUnderstand", env, "1");
                    w.WriteString(action);
                    w.WriteEndElement();
                }
                if (addressing.MessageId is { Length: > 0 } messageId)
                    w.WriteElementString("a", "RelatesTo", addressing.Namespace, messageId);
                w.WriteEndElement();
            }
            w.WriteStartElement("s", "Body", env);
            writeBodyContent(w);
            w.WriteEndElement();
            w.WriteEndElement();
        }
        return new SoapReply(status, ms.ToArray(), SoapNamespaces.ContentType(version));
    }
}
