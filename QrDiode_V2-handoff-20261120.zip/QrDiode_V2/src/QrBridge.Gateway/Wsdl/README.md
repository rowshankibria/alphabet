# Service metadata served by the gateway

One folder per route in `routes.json` (`"Wsdl": "<folder>"`). Each holds `service.wsdl` and, for WCF
services, the schemas it imports as `xsd0.xsd`, `xsd1.xsd`, ... (named by the `?xsd=xsdN` id in the WSDL).
When a caller asks for `?wsdl` or `?xsd=xsdN`, the gateway serves these files with every address rewritten to
the URL the caller used.

Source: `docs/reference/fms-interface-simulator/simulator/FMSServiceProxies/Service References/*` (the WSDLs the
simulator's proxies were generated from).

| Folder | Source | Note |
|---|---|---|
| FC2FMS, SSO2FMS, SSO2TOMS, SSO2TLS, SSO2DSO, FTC2FMS | `FMS_*Interface/*.wsdl` + `*.xsd` | WCF BasicHttpBinding |
| VZ2TLS, XA2FMS, IR2BFC | `*.wsdl` (ASMX, inline schema) | |
| *-Legacy | `RR_*Service.wsdl` | SOAP Toolkit RPC/encoded |
| DSS2FMS | **derived** from `RR_FODFMSService.wsdl` | Same contract (DSS reuses the FOD proxy); service name changed to `RR_DSSFMSService`. Replace with the real file when captured. |

Missing: the WCF WSDL of `FOD2FMSInterface.svc` (not in the simulator repository), so `?wsdl` on that path
returns 404. Capture it from the real service and add a `FOD2FMS` folder plus `"Wsdl": "FOD2FMS"` in `routes.json`.

The files are copied unchanged otherwise. The site folder is trusted, but they are still loaded with DTDs off.
