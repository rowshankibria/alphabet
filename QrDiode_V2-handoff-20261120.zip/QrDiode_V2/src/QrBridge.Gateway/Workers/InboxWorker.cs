using System.Security.Cryptography;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Bridge;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Stores;
using QrBridge.Shared.Envelope;
using QrBridge.Shared.Signals;

namespace QrBridge.Gateway.Workers;

/// <summary>
/// Runs inside the Gateway (IIS). Takes complete messages from the Inbox, verifies + decrypts them,
/// and replays the original SOAP request to the real service on this side.
///
/// Outcomes:
///   Done        the real service accepted it
///   Rejected    bad signature / wrong direction / not in the catalogue / bad payload (never retried)
///   Failed      transient error (network, timeout, 5xx), retried with exponential backoff
///   DeadLetter  out of attempts, or the real service refused it (fault, non-zero return code)
/// </summary>
public sealed class InboxWorker(
    InboxStore inbox,
    HeartbeatStore heartbeats,
    EnvelopeCodec codec,
    RouteTable routes,
    SoapForwarder forwarder,
    BridgeSignals signals,
    IOptions<BridgeOptions> bridgeOptions,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<InboxWorker> logger) : BackgroundService
{
    private readonly BridgeOptions _bridge = bridgeOptions.Value;
    private readonly GatewayOptions _gw = gatewayOptions.Value;
    private long _processed;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await Task.Yield(); // don't block host startup
        logger.LogInformation("Inbox worker started ({Side}, expects {Direction})", _bridge.Side, _bridge.InboundDirection);

        var pollInterval = TimeSpan.FromSeconds(Math.Max(1, _gw.InboxPollSeconds));
        var lastBeat = DateTime.MinValue;

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                if (DateTime.UtcNow - lastBeat > TimeSpan.FromSeconds(30))
                {
                    await heartbeats.BeatAsync(Components.InboxWorker, $"processed={_processed}", stoppingToken);
                    lastBeat = DateTime.UtcNow;
                }

                InboxMessage? row = await inbox.ClaimNextAsync(stoppingToken);
                if (row is null)
                {
                    // Sleep until the QR receiver rings the doorbell, or poll anyway after the interval.
                    await signals.Inbox.WaitAsync(pollInterval, stoppingToken);
                    continue;
                }

                await ProcessAsync(row, stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Inbox worker loop error; pausing 5s");
                try { await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken); }
                catch (OperationCanceledException) { break; }
            }
        }

        logger.LogInformation("Inbox worker stopped");
    }

    private async Task ProcessAsync(InboxMessage row, CancellationToken ct)
    {
        // ---- 1. Verify + decrypt + decide where it goes. Any failure here is permanent. ----
        EnvelopeHeader header;
        RawSoapMessage message;
        DeliveryPlan plan;
        try
        {
            (header, byte[] plain) = codec.Open(row.Envelope);
            Validate(header, row);
            message = RawSoapMessage.FromBytes(plain, _bridge.MaxPayloadBytes);
            if (message.Service != header.ServiceName || message.Operation != header.Operation)
                throw new BridgeRejectException("Service/operation in the payload does not match the envelope header.");

            plan = Plan(message);

            if (_gw.DebugPayloadCapture)
                await inbox.CaptureDebugPayloadAsync(header.MessageId, message.ToDebugText(), ct);
        }
        catch (Exception ex) when (ex is CryptographicException or InvalidDataException or BridgeRejectException)
        {
            logger.LogWarning("Rejected {MessageId}: {Reason}", row.MessageId, ex.Message);
            await inbox.MarkRejectedAsync(row.Id, $"{ex.GetType().Name}: {ex.Message}", CancellationToken.None);
            return;
        }
        catch (PermanentFailureException ex)
        {
            logger.LogError("{MessageId} cannot be delivered: {Reason}", row.MessageId, ex.Message);
            await inbox.MarkDeadLetterAsync(row.Id, ex.Message, null, CancellationToken.None);
            return;
        }

        await inbox.MarkVerifiedAsync(row.Id, ct);

        // ---- 2. Deliver. Transient failures are retried. ----
        DeliveryResult result;
        try
        {
            result = await forwarder.ForwardAsync(message, plan.Url, plan.TimeoutSeconds, plan.ResultKind, ct);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            // Shutting down (e.g. app pool recycle): put it back without counting the attempt.
            await inbox.ReleaseAsync(row.Id, CancellationToken.None);
            throw;
        }

        string label = $"{header.ServiceName}.{header.Operation} {header.BusinessType}".TrimEnd();
        switch (result.Verdict)
        {
            case DeliveryVerdict.Delivered:
                await inbox.MarkDoneAsync(row.Id, result.DownstreamResult, CancellationToken.None);
                Interlocked.Increment(ref _processed);
                logger.LogInformation("Delivered {Label} {MessageId} seq {Sequence}: {Result}",
                    label, header.MessageId, header.Sequence, result.Summary);
                break;

            case DeliveryVerdict.Refused:
            case DeliveryVerdict.Permanent:
                logger.LogError("{Label} {MessageId} dead-lettered: {Reason}", label, header.MessageId, result.Summary);
                await inbox.MarkDeadLetterAsync(row.Id, result.Summary, result.DownstreamResult, CancellationToken.None);
                break;

            default:
                var backoff = Backoff(row.Attempts);
                bool dead = row.Attempts >= _gw.MaxAttempts;
                logger.LogWarning("{Label} {MessageId} failed (attempt {Attempt}/{Max}): {Reason}; {Next}",
                    label, header.MessageId, row.Attempts, _gw.MaxAttempts, result.Summary,
                    dead ? "dead-lettered" : $"retry in {backoff}");
                await inbox.MarkFailedAsync(row.Id, row.Attempts, result.Summary, _gw.MaxAttempts, backoff, CancellationToken.None);
                break;
        }
    }

    private sealed record DeliveryPlan(Uri Url, int TimeoutSeconds, ResultKind ResultKind);

    /// <summary>Only messages for services this side delivers, and only to URLs from this side's configuration.</summary>
    private DeliveryPlan Plan(RawSoapMessage message)
    {
        var resultKind = ResultKind.None;
        var service = routes.FindByName(message.Service);
        if (service is not null)
        {
            if (service.IngressSide == _bridge.Side)
                throw new BridgeRejectException($"{service.Name} is received on this side; it cannot arrive from the other side.");

            service.Operations.TryGetValue(message.Operation, out var operation);
            var mode = operation?.Mode ?? service.OtherOperations;
            if (mode != OperationMode.Bridge)
                throw new BridgeRejectException($"{service.Name}.{message.Operation} is not a bridged operation.");
            resultKind = routes.Profile(operation?.Reply)?.ResultKind ?? ResultKind.None;
        }
        else if (!routes.Options.AcceptUnlisted)
        {
            throw new BridgeRejectException($"'{message.Service}' is not in this side's route catalogue.");
        }

        var target = forwarder.ResolveTarget(message)
            ?? throw new PermanentFailureException(
                $"No egress target for {message.Service}: set Gateway:Egress:Targets:{message.Service}:Url or Gateway:Egress:DefaultBaseUrl.");
        return new DeliveryPlan(target.Url, target.TimeoutSeconds, resultKind);
    }

    /// <summary>The columns the QR receiver filled in (unauthenticated) must match the authenticated header.</summary>
    private void Validate(EnvelopeHeader header, InboxMessage row)
    {
        if (header.MessageId != row.MessageId)
            throw new BridgeRejectException("MessageId in envelope does not match the Inbox row.");
        if (header.ServiceName != row.ServiceName || header.Operation != row.Operation || header.MessageType != row.MessageType)
            throw new BridgeRejectException("Service/operation in envelope does not match the Inbox row.");
        if (header.Direction != _bridge.InboundDirection)
            throw new BridgeRejectException($"Wrong direction {header.Direction}; this side accepts {_bridge.InboundDirection}.");
        if (header.PayloadFormat != PayloadFormat.RawSoap)
            throw new BridgeRejectException($"Unsupported payload format {header.PayloadFormat}.");

        var now = DateTime.UtcNow;
        if (header.CreatedUtc < now - TimeSpan.FromDays(_gw.ReplayWindowDays))
            throw new BridgeRejectException($"Message is older than the {_gw.ReplayWindowDays}-day replay window.");
        if (header.CreatedUtc > now + TimeSpan.FromMinutes(_gw.MaxClockSkewMinutes))
            throw new BridgeRejectException("Message is dated in the future (check NTP on both sides).");
    }

    private TimeSpan Backoff(int attempts)
    {
        double seconds = _gw.BackoffBaseSeconds * Math.Pow(2, Math.Max(0, attempts - 1));
        return TimeSpan.FromSeconds(Math.Min(seconds, _gw.BackoffMaxMinutes * 60));
    }
}
