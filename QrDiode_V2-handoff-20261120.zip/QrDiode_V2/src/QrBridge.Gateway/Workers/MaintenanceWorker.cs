using Microsoft.Extensions.Options;
using QrBridge.Shared.Data.Stores;

namespace QrBridge.Gateway.Workers;

/// <summary>
/// Housekeeping, once a minute:
///   - put Inbox rows stuck in Processing back to Pending (worker crashed / app pool recycled)
///   - retention: delete delivered/processed rows and debug payloads
///   - heartbeat + warnings when something needs an operator
/// Outbox rows stuck in Sending are the QR sender's responsibility (it owns them).
/// </summary>
public sealed class MaintenanceWorker(
    InboxStore inbox,
    OutboxStore outbox,
    HeartbeatStore heartbeats,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<MaintenanceWorker> logger) : BackgroundService
{
    private readonly GatewayOptions _gw = gatewayOptions.Value;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await Task.Yield();
        var interval = TimeSpan.FromSeconds(Math.Max(10, _gw.MaintenanceIntervalSeconds));

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await RunOnceAsync(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Maintenance run failed");
            }

            try { await Task.Delay(interval, stoppingToken); }
            catch (OperationCanceledException) { break; }
        }
    }

    private async Task RunOnceAsync(CancellationToken ct)
    {
        int reset = await inbox.ResetStuckAsync(TimeSpan.FromMinutes(_gw.LockTimeoutMinutes), ct);
        if (reset > 0) logger.LogWarning("Reset {Count} Inbox message(s) stuck in Processing", reset);

        var (done, debug) = await inbox.PurgeAsync(
            TimeSpan.FromDays(_gw.RetentionDays),
            TimeSpan.FromHours(_gw.DebugRetentionHours), ct);
        int acked = await outbox.PurgeAckedAsync(TimeSpan.FromDays(_gw.RetentionDays), ct);
        if (done + debug + acked > 0)
            logger.LogInformation("Purged inbox={Done} debug={Debug} outbox={Acked}", done, debug, acked);

        var oc = await outbox.GetCountsAsync(ct);
        var ic = await inbox.GetCountsAsync(ct);

        if (oc.Failed > 0) logger.LogWarning("{Count} Outbox message(s) Failed (never acknowledged) — operator action needed", oc.Failed);
        if (ic.DeadLetter > 0) logger.LogWarning("{Count} Inbox message(s) in DeadLetter — operator action needed", ic.DeadLetter);
        if (ic.Rejected > 0) logger.LogWarning("{Count} Inbox message(s) Rejected — check for tampering or misconfiguration", ic.Rejected);
        if (oc.OldestUnackedUtc is { } oldest && DateTime.UtcNow - oldest > TimeSpan.FromMinutes(30))
            logger.LogWarning("Oldest undelivered Outbox message is from {Oldest:u} — is the link down?", oldest);

        await heartbeats.BeatAsync(Components.MaintenanceWorker,
            $"outbox p={oc.Pending} s={oc.Sending} f={oc.Failed}; inbox p={ic.Pending} f={ic.Failed} dl={ic.DeadLetter} rej={ic.Rejected}", ct);
        await heartbeats.BeatAsync(Components.GatewayApi, Environment.MachineName, ct);
    }
}
