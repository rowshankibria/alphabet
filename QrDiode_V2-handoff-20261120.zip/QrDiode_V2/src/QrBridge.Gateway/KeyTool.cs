using System.Security.Cryptography;
using QrBridge.Shared.Security;

namespace QrBridge.Gateway;

/// <summary>
/// Key management, run from an elevated command prompt in the Gateway's folder:
///
///   QrBridge.Gateway.exe keys generate --id c2d-2026-11 [--dir C:\ProgramData\QrBridge\Keys] [--transfer-out D:\c2d.transfer]
///   QrBridge.Gateway.exe keys import   --id c2d-2026-11 --transfer-file E:\c2d.transfer [--dir ...]
///   QrBridge.Gateway.exe keys list     [--dir ...]
///   QrBridge.Gateway.exe keys verify   --id c2d-2026-11 [--dir ...]
///
/// The *.transfer file holds the RAW key (base64). It is the only way to get the same key onto the
/// other side of the air gap. Carry it on approved removable media, import it, then destroy it.
/// Use one key per direction (e.g. c2d-... for Corp->DMZ, d2c-... for DMZ->Corp).
/// </summary>
public static class KeyTool
{
    private const string DefaultDir = @"C:\ProgramData\QrBridge\Keys";

    public static int Run(string[] args)
    {
        if (!OperatingSystem.IsWindows())
        {
            Console.Error.WriteLine("Key tool requires Windows (DPAPI).");
            return 1;
        }

        try
        {
            string command = args.Length > 0 ? args[0].ToLowerInvariant() : "help";
            var opts = ParseOptions(args.Skip(1).ToArray());
            var store = new DpapiKeyStore(opts.GetValueOrDefault("dir", DefaultDir));

            switch (command)
            {
                case "generate":
                {
                    string id = Required(opts, "id");
                    byte[] key = RandomNumberGenerator.GetBytes(32);
                    store.Save(id, key);
                    Console.WriteLine($"Key '{id}' saved (DPAPI) to {opts.GetValueOrDefault("dir", DefaultDir)}");
                    Console.WriteLine($"Fingerprint: {Fingerprint(key)}");

                    if (opts.TryGetValue("transfer-out", out var transferPath))
                    {
                        File.WriteAllText(transferPath, Convert.ToBase64String(key));
                        Console.WriteLine($"TRANSFER FILE written: {transferPath}");
                        Console.WriteLine("  It contains the raw key. Carry it to the other side, import it, then destroy it.");
                    }
                    CryptographicOperations.ZeroMemory(key);
                    return 0;
                }
                case "import":
                {
                    string id = Required(opts, "id");
                    string file = Required(opts, "transfer-file");
                    byte[] key = Convert.FromBase64String(File.ReadAllText(file).Trim());
                    if (key.Length != 32) throw new InvalidOperationException("Transfer file does not contain a 32-byte key.");
                    store.Save(id, key);
                    Console.WriteLine($"Key '{id}' imported. Fingerprint: {Fingerprint(key)}");
                    Console.WriteLine("Compare the fingerprint with the other side, then DESTROY the transfer file.");
                    CryptographicOperations.ZeroMemory(key);
                    return 0;
                }
                case "list":
                    foreach (var id in store.ListKeyIds()) Console.WriteLine(id);
                    return 0;
                case "verify":
                {
                    string id = Required(opts, "id");
                    Console.WriteLine($"Key '{id}' fingerprint: {Fingerprint(store.GetKey(id))}");
                    return 0;
                }
                default:
                    Console.WriteLine("Usage: keys generate|import|list|verify --id <keyId> [--dir <folder>] [--transfer-out <file>] [--transfer-file <file>]");
                    return command == "help" ? 0 : 1;
            }
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Error: {ex.Message}");
            return 1;
        }
    }

    /// <summary>Short, non-secret identifier so both sides can confirm they hold the same key.</summary>
    private static string Fingerprint(byte[] key) =>
        Convert.ToHexString(SHA256.HashData(key).AsSpan(0, 8));

    private static Dictionary<string, string> ParseOptions(string[] args)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        for (int i = 0; i < args.Length; i++)
        {
            if (!args[i].StartsWith("--")) continue;
            string name = args[i][2..];
            result[name] = i + 1 < args.Length && !args[i + 1].StartsWith("--") ? args[++i] : "true";
        }
        return result;
    }

    private static string Required(Dictionary<string, string> opts, string name) =>
        opts.TryGetValue(name, out var v) && !string.IsNullOrWhiteSpace(v)
            ? v
            : throw new ArgumentException($"--{name} is required.");
}
