using System.Text;
using System.Xml;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Routing;
using QrBridge.Gateway.Soap;
using QrBridge.Shared.Envelope;

namespace QrBridge.Gateway.Egress;

public enum DeliveryVerdict
{
    /// <summary>The real service accepted it.</summary>
    Delivered,
    /// <summary>The real service answered and refused it (RETURN_CODE / return code not 0). Not retried.</summary>
    Refused,
    /// <summary>SOAP fault or a configuration problem (404, 401...). Not retried.</summary>
    Permanent,
    /// <summary>Network error, timeout, 5xx without a fault, 429: retried with backoff.</summary>
    Transient,
}

/// <param name="Summary">One line for LastError / logs. Never contains the request payload.</param>
/// <param name="DownstreamResult">What the service said (return code, error message, fault reason).</param>
public sealed record DeliveryResult(DeliveryVerdict Verdict, string Summary, string? DownstreamResult);

/// <summary>
/// Replays a caller's request to the real service on this side: same bytes, same SOAPAction and
/// Content-Type. Only the target URL differs, and it always comes from this side's configuration.
/// </summary>
public sealed class SoapForwarder(
    IHttpClientFactory httpClientFactory,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<SoapForwarder> logger)
{
    public const string HttpClientName = "egress";

    private readonly EgressOptions _options = gatewayOptions.Value.Egress;

    /// <summary>Targets[service], else DefaultBaseUrl + the caller's path. Null when neither is configured.</summary>
    public (Uri Url, int TimeoutSeconds)? ResolveTarget(RawSoapMessage message)
    {
        if (_options.Targets.TryGetValue(message.Service, out var target) && !string.IsNullOrWhiteSpace(target.Url))
            return (new Uri(target.Url, UriKind.Absolute), target.TimeoutSeconds ?? _options.TimeoutSeconds);

        if (!string.IsNullOrWhiteSpace(_options.DefaultBaseUrl))
        {
            var baseUri = new Uri(_options.DefaultBaseUrl.TrimEnd('/') + "/", UriKind.Absolute);
            // The path was normalized by the sending gateway ("/a/b.svc"); make it relative so it cannot
            // replace the configured host.
            return (new Uri(baseUri, message.Path.TrimStart('/')), _options.TimeoutSeconds);
        }
        return null;
    }

    public async Task<DeliveryResult> ForwardAsync(RawSoapMessage message, Uri url, int timeoutSeconds,
                                                   ResultKind resultKind, CancellationToken ct)
    {
        byte[] body = _options.RewriteAddressingTo ? AddressingRewriter.RewriteTo(message.Body, url) : message.Body;

        using var request = new HttpRequestMessage(HttpMethod.Post, url) { Content = new ByteArrayContent(body) };
        request.Content.Headers.TryAddWithoutValidation("Content-Type", message.ContentType);
        if (message.SoapActionHeader is not null)
            request.Headers.TryAddWithoutValidation("SOAPAction", message.SoapActionHeader);

        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(Math.Max(1, timeoutSeconds)));

        var client = httpClientFactory.CreateClient(HttpClientName);
        try
        {
            using var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, timeout.Token);
            byte[]? reply = await ReadLimitedAsync(response.Content, _options.MaxResponseBytes, timeout.Token);
            return Classify((int)response.StatusCode, reply ?? [], resultKind, replyTruncated: reply is null);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            return new DeliveryResult(DeliveryVerdict.Transient, $"No answer from {url.Host} within {timeoutSeconds}s.", null);
        }
        catch (HttpRequestException ex)
        {
            logger.LogDebug(ex, "Delivery to {Url} failed", url);
            return new DeliveryResult(DeliveryVerdict.Transient, $"Could not reach {url.Host}: {ex.Message}", null);
        }
    }

    /// <summary>Turns the real service's HTTP answer into a verdict. Public for tests.</summary>
    public static DeliveryResult Classify(int status, byte[] reply, ResultKind kind, bool replyTruncated = false)
    {
        var soap = replyTruncated ? null : SoapResponse.TryParse(reply, (long)reply.Length * 2 + 1024);

        if (soap is { IsFault: true })
        {
            string fault = $"SOAP fault: {soap.FaultReason ?? "(no reason)"}";
            return new DeliveryResult(DeliveryVerdict.Permanent, $"The service returned a fault (HTTP {status}). {fault}", fault);
        }

        if (status == 202)
            return new DeliveryResult(DeliveryVerdict.Delivered, "Accepted (HTTP 202).", "HTTP 202");

        if (status is >= 200 and < 300)
        {
            string? result = soap?.ResultText;
            switch (kind)
            {
                case ResultKind.FmsResponse when TryReadFmsStatus(result, out long code, out string? errorMessage):
                {
                    string summary = $"RETURN_CODE={code}" + (string.IsNullOrWhiteSpace(errorMessage) ? "" : $"; ERROR_MESSAGE={errorMessage}");
                    return code == 0
                        ? new DeliveryResult(DeliveryVerdict.Delivered, summary, summary)
                        : new DeliveryResult(DeliveryVerdict.Refused, $"The service refused the message: {summary}", summary);
                }
                case ResultKind.ReturnCode when long.TryParse(result?.Trim(), out long code):
                {
                    string summary = $"return code {code}";
                    return code == 0
                        ? new DeliveryResult(DeliveryVerdict.Delivered, summary, summary)
                        : new DeliveryResult(DeliveryVerdict.Refused, $"The service refused the message: {summary}", summary);
                }
                case ResultKind.None:
                    return new DeliveryResult(DeliveryVerdict.Delivered, $"HTTP {status}", $"HTTP {status}");
                default:
                    // 2xx but the reply is not in the expected shape: it was processed, but say so.
                    return new DeliveryResult(DeliveryVerdict.Delivered,
                        $"HTTP {status}; reply had no recognizable result", $"HTTP {status}; unrecognized reply");
            }
        }

        return status is 408 or 429 or 500 or 502 or 503 or 504
            ? new DeliveryResult(DeliveryVerdict.Transient, $"HTTP {status} from the service.", $"HTTP {status}")
            : new DeliveryResult(DeliveryVerdict.Permanent, $"HTTP {status} from the service (check the egress URL and credentials).", $"HTTP {status}");
    }

    /// <summary>Reads RETURN_CODE and ERROR_MESSAGE from an FMS &lt;RESPONSE&gt; document.</summary>
    private static bool TryReadFmsStatus(string? responseXml, out long code, out string? errorMessage)
    {
        code = 0;
        errorMessage = null;
        if (string.IsNullOrWhiteSpace(responseXml) || !responseXml.TrimStart().StartsWith('<')) return false;
        try
        {
            var doc = SafeXml.LoadText(responseXml, (long)responseXml.Length * 2 + 1024);
            var returnCode = doc.GetElementsByTagName("RETURN_CODE").OfType<XmlElement>().FirstOrDefault();
            if (returnCode is null || !long.TryParse(returnCode.InnerText.Trim(), out code)) return false;
            errorMessage = doc.GetElementsByTagName("ERROR_MESSAGE").OfType<XmlElement>().FirstOrDefault()?.InnerText.Trim();
            return true;
        }
        catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
        {
            return false;
        }
    }

    private static async Task<byte[]?> ReadLimitedAsync(HttpContent content, int max, CancellationToken ct)
    {
        await using var stream = await content.ReadAsStreamAsync(ct);
        using var buffer = new MemoryStream();
        var chunk = new byte[16 * 1024];
        int read;
        while ((read = await stream.ReadAsync(chunk, ct)) > 0)
        {
            if (buffer.Length + read > max) return null;
            buffer.Write(chunk, 0, read);
        }
        return buffer.ToArray();
    }
}

/// <summary>
/// WCF services with WS-Addressing check that wsa:To names them. The caller addressed the load balancer,
/// so the To header is pointed at the real service. Bodies without WS-Addressing are returned untouched.
/// </summary>
public static class AddressingRewriter
{
    public static byte[] RewriteTo(byte[] body, Uri target)
    {
        // Cheap pre-check: almost every FMS request has no WS-Addressing, and those must stay byte-identical.
        if (body.AsSpan().IndexOf("addressing"u8) < 0) return body;

        XmlDocument doc;
        try
        {
            var settings = SafeXml.Settings(body.LongLength * 2 + 1024);
            settings.IgnoreComments = false;
            using var reader = XmlReader.Create(new MemoryStream(body, writable: false), settings);
            doc = new XmlDocument { XmlResolver = null, PreserveWhitespace = true };
            doc.Load(reader);
        }
        catch (XmlException)
        {
            return body;
        }

        var envelope = doc.DocumentElement;
        if (envelope is null) return body;
        var header = SoapRequest.ChildElement(envelope, "Header", envelope.NamespaceURI);
        if (header is null) return body;

        XmlElement? to = null;
        foreach (XmlNode node in header.ChildNodes)
            if (node is XmlElement e && e.LocalName == "To" && SoapNamespaces.IsAddressing(e.NamespaceURI))
                to = e;
        if (to is null || to.InnerText.Trim() == target.AbsoluteUri) return body;

        to.InnerText = target.AbsoluteUri;
        using var ms = new MemoryStream();
        var writerSettings = new XmlWriterSettings
        {
            Encoding = new UTF8Encoding(false),
            OmitXmlDeclaration = doc.FirstChild is not XmlDeclaration,
        };
        using (var w = XmlWriter.Create(ms, writerSettings))
            doc.Save(w);
        return ms.ToArray();
    }
}
