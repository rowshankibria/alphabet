using Microsoft.Extensions.Options;
using QrBridge.Gateway;
using QrBridge.Gateway.Bridge;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Ingress;
using QrBridge.Gateway.Routing;
using QrBridge.Gateway.Workers;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Stores;
using QrBridge.Shared.Envelope;
using QrBridge.Shared.Security;
using QrBridge.Shared.Signals;

// ---------------------------------------------------------------------
// "QrBridge.Gateway.exe keys ..." runs the key tool and exits.
// ---------------------------------------------------------------------
if (args.Length > 0 && args[0].Equals("keys", StringComparison.OrdinalIgnoreCase))
    return KeyTool.Run(args[1..]);

var builder = WebApplication.CreateBuilder(args);

// The route catalogue: which services this gateway stands in for, and how it answers them.
builder.Configuration.AddJsonFile("routes.json", optional: false, reloadOnChange: false);

// ---------- options (read only after Build, so environment/test overrides always apply) ----------
builder.Services.AddOptions<BridgeOptions>().BindConfiguration(BridgeOptions.SectionName);
builder.Services.AddOptions<GatewayOptions>().BindConfiguration(GatewayOptions.SectionName);
builder.Services.AddOptions<RoutingOptions>().BindConfiguration(RoutingOptions.SectionName);

// ---------- data (EF Core + SQLite) ----------
builder.Services.AddBridgeData();

// ---------- crypto ----------
builder.Services.AddSingleton<IKeyProvider>(sp =>
    new DpapiKeyStore(sp.GetRequiredService<IOptions<GatewayOptions>>().Value.KeyFolder));
builder.Services.AddSingleton(sp => new EnvelopeCodec(
    sp.GetRequiredService<IKeyProvider>(),
    sp.GetRequiredService<IOptions<BridgeOptions>>().Value.MaxPayloadBytes + RawSoapMessage.MaxOverheadBytes));

// ---------- bridge: ingress (callers -> Outbox) and egress (Inbox -> real services) ----------
builder.Services.AddSingleton<BridgeSignals>();
builder.Services.AddSingleton<RouteTable>();
builder.Services.AddSingleton<OutboxWriter>();
builder.Services.AddSingleton<IngressEndpoint>();
builder.Services.AddSingleton<MetadataEndpoint>();
builder.Services.AddSingleton<SoapForwarder>();
builder.Services.AddHttpClient(SoapForwarder.HttpClientName, client => client.Timeout = Timeout.InfiniteTimeSpan)
    .ConfigurePrimaryHttpMessageHandler(sp => new HttpClientHandler
    {
        UseDefaultCredentials = sp.GetRequiredService<IOptions<GatewayOptions>>().Value.Egress.UseDefaultCredentials,
        AllowAutoRedirect = false, // a redirect would replay the payload somewhere we did not configure
    });

// ---------- background workers (run inside IIS; see deploy/setup-iis.ps1 for the app pool settings) ----------
builder.Services.AddHostedService<InboxWorker>();
builder.Services.AddHostedService<MaintenanceWorker>();
builder.Services.Configure<HostOptions>(o =>
{
    o.ShutdownTimeout = TimeSpan.FromSeconds(45);
    // A worker bug must not take the endpoints down with it; workers log and keep going.
    o.BackgroundServiceExceptionBehavior = BackgroundServiceExceptionBehavior.Ignore;
});

var app = builder.Build();
var log = app.Services.GetRequiredService<ILoggerFactory>().CreateLogger("QrBridge.Gateway");
var bridgeOptions = app.Services.GetRequiredService<IOptions<BridgeOptions>>().Value;
var gatewayOptions = app.Services.GetRequiredService<IOptions<GatewayOptions>>().Value;

// ---------- startup checks: fail loudly instead of accepting messages nobody can decrypt or deliver ----------
if (string.IsNullOrWhiteSpace(gatewayOptions.OutboundKeyId))
    throw new InvalidOperationException("Gateway:OutboundKeyId is not configured.");
try
{
    app.Services.GetRequiredService<IKeyProvider>().GetKey(gatewayOptions.OutboundKeyId);
}
catch (Exception ex)
{
    throw new InvalidOperationException(
        $"Outbound key '{gatewayOptions.OutboundKeyId}' cannot be loaded from {gatewayOptions.KeyFolder}. " +
        "Run 'QrBridge.Gateway.exe keys generate/import' and check folder permissions.", ex);
}

int longestEgressSeconds = gatewayOptions.Egress.Targets.Values
    .Select(t => t.TimeoutSeconds ?? gatewayOptions.Egress.TimeoutSeconds)
    .DefaultIfEmpty(gatewayOptions.Egress.TimeoutSeconds)
    .Max();
if (gatewayOptions.LockTimeoutMinutes * 60 <= Math.Max(longestEgressSeconds, gatewayOptions.Egress.TimeoutSeconds) + 30)
    throw new InvalidOperationException(
        "Gateway:LockTimeoutMinutes must be longer than every egress timeout (plus 30 s), " +
        "or a slow delivery could be reset and sent twice.");

var routes = app.Services.GetRequiredService<RouteTable>(); // validates the catalogue
await DatabaseInitializer.InitializeAsync(app.Services, log);
log.LogInformation("QrBridge Gateway starting. Side={Side} Data={Data} OutboundKey={Key} Services={Services} AcceptUnlisted={Unlisted}",
    bridgeOptions.Side, bridgeOptions.DataFolder, gatewayOptions.OutboundKeyId,
    routes.Services.Count(s => s.IngressSide == bridgeOptions.Side), routes.Options.AcceptUnlisted);

// ---------- endpoints ----------
// Health/monitoring: queue depths + heartbeats of all components on this machine.
app.MapGet("/health", async (OutboxStore outbox, InboxStore inbox, HeartbeatStore heartbeats, CancellationToken ct) =>
{
    var oc = await outbox.GetCountsAsync(ct);
    var ic = await inbox.GetCountsAsync(ct);
    var beats = await heartbeats.GetAllAsync(ct);
    var now = DateTime.UtcNow;
    var stale = beats.Where(b => now - b.LastSeenUtc > TimeSpan.FromMinutes(2)).Select(b => b.Component).ToList();

    return Results.Json(new
    {
        side = bridgeOptions.Side.ToString(),
        machine = Environment.MachineName,
        utc = now,
        healthy = stale.Count == 0 && oc.Failed == 0 && ic.DeadLetter == 0,
        outbox = oc,
        inbox = ic,
        staleComponents = stale,
        heartbeats = beats.Select(b => new { b.Component, b.LastSeenUtc, b.Info }),
    });
});

// Everything else is a stand-in service endpoint: GET/HEAD for metadata, POST for SOAP calls.
app.MapMethods("/{**path}", [HttpMethods.Get, HttpMethods.Head],
    (HttpContext context, MetadataEndpoint endpoint) => endpoint.HandleAsync(context));
app.MapPost("/{**path}",
    (HttpContext context, IngressEndpoint endpoint) => endpoint.HandleAsync(context));

await app.RunAsync();
return 0;

/// <summary>Exposed for the integration tests (WebApplicationFactory).</summary>
public partial class Program { }
