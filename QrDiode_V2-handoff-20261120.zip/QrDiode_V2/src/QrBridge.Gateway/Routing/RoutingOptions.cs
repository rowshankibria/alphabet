using QrBridge.Shared;

namespace QrBridge.Gateway.Routing;

/// <summary>What the gateway does with a call to an operation.</summary>
public enum OperationMode
{
    /// <summary>Store it, reply OK at once, deliver it to the real service on the other side.</summary>
    Bridge,
    /// <summary>Answer locally with the request value (EchoString connectivity checks). Nothing is stored.</summary>
    Echo,
    /// <summary>The caller needs real data back, which cannot cross the air gap: reply "not available".</summary>
    Unavailable,
    /// <summary>Refuse with a SOAP fault.</summary>
    Reject,
}

/// <summary>How the SOAP body of an operation is shaped (decides the reply's result element).</summary>
public enum MessageStyle
{
    /// <summary>Document/literal wrapped (WCF, ASMX): reply &lt;OpResponse xmlns="ns"&gt;&lt;OpResult&gt;.</summary>
    Document,
    /// <summary>RPC/encoded (SOAP Toolkit, *.WSDL endpoints): reply &lt;m:OpResponse&gt;&lt;Result&gt; (unqualified).</summary>
    Rpc,
}

/// <summary>How to read the real service's reply when the message is delivered.</summary>
public enum ResultKind
{
    /// <summary>Any 2xx reply that is not a SOAP fault counts as delivered.</summary>
    None,
    /// <summary>The result is an FMS &lt;RESPONSE&gt; document: RETURN_CODE 0 = accepted, anything else = refused.</summary>
    FmsResponse,
    /// <summary>The result is a number: 0 = accepted, anything else = refused.</summary>
    ReturnCode,
}

/// <summary>The route catalogue ("Routing" section, normally in routes.json). The same file is used on both sides.</summary>
public sealed class RoutingOptions
{
    public const string SectionName = "Routing";

    /// <summary>
    /// Accept SOAP calls to services/paths that are not in the catalogue, bridging them with an automatic
    /// empty reply. Useful in test and discovery; keep it OFF in production so only listed services pass (allow-list).
    /// </summary>
    public bool AcceptUnlisted { get; set; }

    /// <summary>For unlisted calls: reply HTTP 202 with no body (one-way operations) instead of an empty SOAP reply.</summary>
    public bool UnlistedOneWay { get; set; }

    /// <summary>Reply values shared by operations, by name (e.g. "FmsResponse", "ReturnCode").</summary>
    public Dictionary<string, ReplyProfile> ReplyProfiles { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    public List<ServiceRoute> Services { get; set; } = [];
}

/// <summary>
/// The result values the gateway puts in its replies for one kind of operation. Values are the text of the
/// result element (an FMS &lt;RESPONSE&gt; document, or a number); null means "no value" (empty reply or fault).
/// Placeholders: {BusinessType} (MESSAGE/@TYPE), {MsgId} (MESSAGE/@MSG_ID), {MessageId} (bridge id). All escaped.
/// </summary>
public sealed class ReplyProfile
{
    /// <summary>How the egress side reads the real service's answer.</summary>
    public ResultKind ResultKind { get; set; } = ResultKind.None;

    /// <summary>Message accepted and queued.</summary>
    public string? Ok { get; set; }

    /// <summary>Backlog full: message NOT accepted, caller should retry.</summary>
    public string? Busy { get; set; }

    /// <summary>Operation cannot be served across the air gap (queries).</summary>
    public string? Unavailable { get; set; }

    /// <summary>Payload refused (MESSAGE TYPE not allowed, or not well-formed XML).</summary>
    public string? Rejected { get; set; }
}

/// <summary>One service the gateway stands in for, as its callers see it.</summary>
public sealed class ServiceRoute
{
    /// <summary>Short stable name, e.g. "FC2FMS". Stored in every message; used for egress targets.</summary>
    public string Name { get; set; } = "";

    public string? Description { get; set; }

    /// <summary>Which gateway receives the calls (the side the callers are on). The other side delivers them.</summary>
    public BridgeSide IngressSide { get; set; } = BridgeSide.Corp;

    /// <summary>The path(s) callers use, as forwarded by the load balancer. Case-insensitive.</summary>
    public List<string> Paths { get; set; } = [];

    public MessageStyle Style { get; set; } = MessageStyle.Document;

    /// <summary>Overrides the reply's result element name (default: OpResult for Document, Result for Rpc).</summary>
    public string? ResultElement { get; set; }

    /// <summary>Folder under Wsdl/ with service.wsdl (+ xsd0.xsd, xsd1.xsd, ...). Null: no metadata served.</summary>
    public string? Wsdl { get; set; }

    /// <summary>Legacy SOAP Toolkit endpoints: a plain GET on the endpoint URL returns the WSDL.</summary>
    public bool WsdlAtPath { get; set; }

    /// <summary>What happens to operations not listed in <see cref="Operations"/>.</summary>
    public OperationMode OtherOperations { get; set; } = OperationMode.Reject;

    /// <summary>
    /// Operations by SOAP body element name (e.g. "SendToFMS"). The special key "GET" describes plain
    /// HTTP GET calls to the path (only Unavailable is meaningful there).
    /// </summary>
    public Dictionary<string, OperationRoute> Operations { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class OperationRoute
{
    public OperationMode Mode { get; set; } = OperationMode.Bridge;

    /// <summary>Name of a <see cref="ReplyProfile"/>. Null: automatic empty reply / SOAP faults.</summary>
    public string? Reply { get; set; }

    /// <summary>One-way operation: reply HTTP 202 with no body.</summary>
    public bool OneWay { get; set; }

    /// <summary>
    /// If not empty, only payloads whose MESSAGE/@TYPE (or root element name) is in this list are accepted.
    /// Mirrors what the real service accepts, so bad payloads are refused at once instead of failing later.
    /// </summary>
    public List<string> AllowedTypes { get; set; } = [];
}
