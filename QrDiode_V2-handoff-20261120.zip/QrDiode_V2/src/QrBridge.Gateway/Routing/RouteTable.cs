using Microsoft.Extensions.Options;
using QrBridge.Shared;

namespace QrBridge.Gateway.Routing;

/// <summary>How the gateway will treat one incoming call.</summary>
/// <param name="ServiceName">Name stored in the message: the route name, or the path for unlisted calls.</param>
/// <param name="Service">The catalogue entry; null for unlisted calls.</param>
/// <param name="Operation">The operation entry; null when the operation is not listed.</param>
/// <param name="Problem">Why the call is refused (Mode = Reject).</param>
public sealed record RouteDecision(
    string ServiceName,
    ServiceRoute? Service,
    OperationRoute? Operation,
    OperationMode Mode,
    ReplyProfile? Profile,
    bool OneWay,
    string? Problem);

/// <summary>
/// The route catalogue, validated and indexed once at startup. Invalid configuration fails the start
/// (better than discovering a typo when the first message is refused).
/// </summary>
public sealed class RouteTable
{
    private const int MaxServiceNameLength = 256;

    private readonly Dictionary<string, ServiceRoute> _byPath = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, ServiceRoute> _byName = new(StringComparer.OrdinalIgnoreCase);
    private readonly BridgeSide _side;

    public RouteTable(IOptions<RoutingOptions> routing, IOptions<BridgeOptions> bridge)
    {
        Options = routing.Value;
        _side = bridge.Value.Side;

        var problems = new List<string>();
        foreach (var service in Options.Services)
        {
            if (string.IsNullOrWhiteSpace(service.Name) || service.Name.Length > 64)
            {
                problems.Add($"A service has an empty or too long Name (max 64): '{service.Name}'.");
                continue;
            }
            if (!_byName.TryAdd(service.Name, service))
                problems.Add($"Service name '{service.Name}' is used twice.");
            if (service.Paths.Count == 0)
                problems.Add($"Service '{service.Name}' has no Paths.");

            foreach (string raw in service.Paths)
            {
                string path = NormalizePath(raw);
                if (_byPath.TryGetValue(path, out var other))
                    problems.Add($"Path '{path}' is claimed by both '{other.Name}' and '{service.Name}'.");
                else
                    _byPath[path] = service;
            }

            foreach (var (operation, route) in service.Operations)
            {
                if (route.Reply is { } profile && !Options.ReplyProfiles.ContainsKey(profile))
                    problems.Add($"{service.Name}.{operation} uses unknown reply profile '{profile}'.");
            }
        }

        if (problems.Count > 0)
            throw new InvalidOperationException("Invalid route catalogue (Routing section):" + Environment.NewLine +
                                                string.Join(Environment.NewLine, problems.Select(p => " - " + p)));
    }

    public RoutingOptions Options { get; }

    public IReadOnlyCollection<ServiceRoute> Services => _byName.Values;

    /// <summary>Case-insensitive path without query, trailing slash or duplicate slashes; "/" for empty.</summary>
    public static string NormalizePath(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return "/";
        string p = path.Trim();
        int q = p.IndexOfAny(['?', '#']);
        if (q >= 0) p = p[..q];
        p = "/" + string.Join('/', p.Split('/', StringSplitOptions.RemoveEmptyEntries));
        return p;
    }

    public ServiceRoute? FindByPath(string path) => _byPath.GetValueOrDefault(NormalizePath(path));

    public ServiceRoute? FindByName(string name) => _byName.GetValueOrDefault(name);

    public ReplyProfile? Profile(string? name) =>
        name is not null && Options.ReplyProfiles.TryGetValue(name, out var profile) ? profile : null;

    /// <summary>Decides what to do with a call to <paramref name="path"/> for SOAP operation <paramref name="operation"/>.</summary>
    public RouteDecision Resolve(string path, string operation)
    {
        string normalized = NormalizePath(path);
        var service = FindByPath(normalized);

        if (service is null)
        {
            if (!Options.AcceptUnlisted)
                return Refuse(normalized, null, $"'{normalized}' is not a bridged service.");
            if (normalized.Length > MaxServiceNameLength)
                return Refuse(normalized, null, "Path too long to bridge.");
            return new RouteDecision(normalized, null, null, OperationMode.Bridge, null, Options.UnlistedOneWay, null);
        }

        if (service.IngressSide != _side)
            return Refuse(service.Name, service,
                $"{service.Name} is delivered by this gateway ({_side}); its callers are on the {service.IngressSide} side.");

        if (service.Operations.TryGetValue(operation, out var route))
        {
            if (route.Mode == OperationMode.Reject)
                return Refuse(service.Name, service, $"{service.Name}.{operation} is not bridged.");
            return new RouteDecision(service.Name, service, route, route.Mode, Profile(route.Reply), route.OneWay, null);
        }

        return service.OtherOperations == OperationMode.Reject
            ? Refuse(service.Name, service, $"{service.Name}.{operation} is not bridged.")
            : new RouteDecision(service.Name, service, null, service.OtherOperations, null, false, null);
    }

    private static RouteDecision Refuse(string name, ServiceRoute? service, string problem) =>
        new(name, service, null, OperationMode.Reject, null, false, problem);
}
