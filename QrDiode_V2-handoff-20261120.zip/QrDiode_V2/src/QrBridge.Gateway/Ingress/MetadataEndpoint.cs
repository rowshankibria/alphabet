using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Routing;
using QrBridge.Gateway.Soap;
using QrBridge.Shared;

namespace QrBridge.Gateway.Ingress;

/// <summary>
/// Answers GET/HEAD on a bridged service's path the way the original service did:
///   ?wsdl / ?singleWsdl      the original WSDL, with its addresses pointing at this gateway
///   ?xsd=xsd0                the schemas the WSDL imports
///   plain GET                the WSDL for legacy SOAP Toolkit endpoints (*.WSDL), otherwise a small
///                            service page with HTTP 200 (load balancer health probes)
/// Nothing here crosses the air gap.
/// </summary>
public sealed partial class MetadataEndpoint(
    RouteTable routes,
    IWebHostEnvironment environment,
    IOptions<BridgeOptions> bridgeOptions)
{
    private const string WsdlNs = "http://schemas.xmlsoap.org/wsdl/";
    private const string WsdlSoap11Ns = "http://schemas.xmlsoap.org/wsdl/soap/";
    private const string WsdlSoap12Ns = "http://schemas.xmlsoap.org/wsdl/soap12/";
    private const string XsdNs = "http://www.w3.org/2001/XMLSchema";

    private readonly BridgeSide _side = bridgeOptions.Value.Side;

    [GeneratedRegex("^(xsd|wsdl)[0-9]{1,2}$")]
    private static partial Regex DocumentId();

    public async Task HandleAsync(HttpContext context)
    {
        string path = RouteTable.NormalizePath(context.Request.Path.Value);
        if (path == "/")
        {
            await TextAsync(context, 200, "text/plain", $"QrBridge Gateway ({_side})");
            return;
        }

        var service = routes.FindByPath(path);
        if (service is null || service.IngressSide != _side)
        {
            await TextAsync(context, 404, "text/plain", "Not a bridged service.");
            return;
        }

        // Plain HTTP GET operations (e.g. RegisteredTags.asmx/GetData) need a live answer from the other side.
        if (service.Operations.TryGetValue("GET", out var get) && get.Mode == OperationMode.Unavailable)
        {
            await TextAsync(context, 503, "text/plain",
                $"{service.Name} is not available while the network is islanded: it needs a live answer from the other side.");
            return;
        }

        var query = context.Request.Query;
        string? xsd = query.TryGetValue("xsd", out var x) ? x.ToString() : null;
        bool wantsWsdl = query.ContainsKey("wsdl") || query.ContainsKey("singleWsdl") ||
                         (service.WsdlAtPath && query.Count == 0);

        if (xsd is not null || wantsWsdl)
        {
            string? file = xsd is null ? "service.wsdl" : DocumentId().IsMatch(xsd) ? xsd + ".xsd" : null;
            string? full = file is null || service.Wsdl is null
                ? null
                : Path.Combine(environment.ContentRootPath, "Wsdl", service.Wsdl, file);

            if (full is null || !File.Exists(full))
            {
                await TextAsync(context, 404, "text/plain", "No metadata is published for this service.");
                return;
            }

            string selfUrl = $"{context.Request.Scheme}://{context.Request.Host}{context.Request.PathBase}{context.Request.Path}";
            byte[] document = RewriteAddresses(await File.ReadAllBytesAsync(full, context.RequestAborted), selfUrl);
            context.Response.StatusCode = 200;
            context.Response.ContentType = "text/xml; charset=utf-8";
            if (!HttpMethods.IsHead(context.Request.Method))
                await context.Response.Body.WriteAsync(document, context.RequestAborted);
            return;
        }

        string name = WebUtility.HtmlEncode(service.Name);
        string description = WebUtility.HtmlEncode(service.Description ?? "");
        await TextAsync(context, 200, "text/html; charset=utf-8",
            $"<html><head><title>{name}</title></head><body><h1>{name}</h1><p>{description}</p>" +
            $"<p>This endpoint is served by the QR air-gap bridge ({_side} gateway).</p></body></html>");
    }

    /// <summary>
    /// Points soap:address and the schema imports at the URL the caller used, as the original service did.
    /// The file comes from the site folder (trusted), but is still loaded with DTDs off.
    /// </summary>
    private static byte[] RewriteAddresses(byte[] wsdl, string selfUrl)
    {
        var doc = SafeXml.Load(wsdl, wsdl.LongLength * 2 + 1024);
        var ns = new XmlNamespaceManager(doc.NameTable);
        ns.AddNamespace("wsdl", WsdlNs);
        ns.AddNamespace("soap", WsdlSoap11Ns);
        ns.AddNamespace("soap12", WsdlSoap12Ns);
        ns.AddNamespace("xsd", XsdNs);

        foreach (XmlAttribute location in doc.SelectNodes("//soap:address/@location | //soap12:address/@location", ns)!)
            location.Value = selfUrl;

        foreach (XmlAttribute schemaLocation in doc.SelectNodes("//xsd:import/@schemaLocation", ns)!)
        {
            int i = schemaLocation.Value.IndexOf("?xsd=", StringComparison.OrdinalIgnoreCase);
            if (i >= 0) schemaLocation.Value = selfUrl + schemaLocation.Value[i..];
        }

        using var ms = new MemoryStream();
        using (var w = XmlWriter.Create(ms, new XmlWriterSettings { Encoding = new UTF8Encoding(false), Indent = true }))
            doc.Save(w);
        return ms.ToArray();
    }

    private static async Task TextAsync(HttpContext context, int status, string contentType, string text)
    {
        context.Response.StatusCode = status;
        context.Response.ContentType = contentType;
        if (!HttpMethods.IsHead(context.Request.Method))
            await context.Response.WriteAsync(text, context.RequestAborted);
    }
}
