using System.Security;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Bridge;
using QrBridge.Gateway.Routing;
using QrBridge.Gateway.Soap;
using QrBridge.Shared;
using QrBridge.Shared.Envelope;

namespace QrBridge.Gateway.Ingress;

/// <summary>
/// Receives every SOAP POST, whatever the service: the load balancer sends the callers' unchanged
/// requests here instead of to the real service.
///
///   read body (size-capped) -> parse the SOAP envelope (any version/style) -> look up the route
///   -> Bridge: check the allow-list, store the exact bytes in the Outbox, THEN reply like the real service
///   -> Echo / Unavailable / Reject: answer locally, store nothing
/// </summary>
public sealed class IngressEndpoint(
    RouteTable routes,
    OutboxWriter outbox,
    IOptions<BridgeOptions> bridgeOptions,
    ILogger<IngressEndpoint> logger)
{
    public const string MessageIdHeader = "X-QrBridge-MessageId";

    private readonly int _maxBodyBytes = bridgeOptions.Value.MaxPayloadBytes;

    public async Task HandleAsync(HttpContext context)
    {
        var ct = context.RequestAborted;
        string path = RouteTable.NormalizePath(context.Request.Path.Value);

        byte[]? body = await ReadBodyAsync(context.Request, _maxBodyBytes, ct);
        if (body is null)
        {
            logger.LogWarning("Refused {Path}: request larger than {Max} bytes", path, _maxBodyBytes);
            await WriteAsync(context, SoapReplyWriter.Fault(SoapVersion.Soap11, null, senderFault: true,
                $"The request is larger than the bridge limit of {_maxBodyBytes} bytes.", statusCode: 413));
            return;
        }

        string contentType = context.Request.ContentType ?? "";
        string? soapActionHeader = context.Request.Headers.TryGetValue("SOAPAction", out var h) ? h.ToString() : null;

        if (!SoapRequest.TryParse(body, contentType, soapActionHeader, (long)_maxBodyBytes * 2, out var request, out string parseError))
        {
            logger.LogWarning("Refused {Path}: {Error}", path, parseError);
            await WriteAsync(context, SoapReplyWriter.Fault(SoapVersion.Soap11, null, senderFault: true, parseError, statusCode: 400));
            return;
        }

        var decision = routes.Resolve(path, request!.Operation);
        var business = PayloadInspector.Inspect(request.FirstParameterText, (long)_maxBodyBytes * 2);
        var reply = await DecideAsync(context, path, request, decision, business, body, contentType, ct);
        await WriteAsync(context, reply);
    }

    private async Task<SoapReply> DecideAsync(HttpContext context, string path, SoapRequest request, RouteDecision decision,
                                              BusinessInfo business, byte[] body, string contentType, CancellationToken ct)
    {
        string label = $"{decision.ServiceName}.{request.Operation}";
        var style = StyleFor(decision, request);
        string? resultElement = decision.Service?.ResultElement;

        switch (decision.Mode)
        {
            case OperationMode.Reject:
                logger.LogWarning("Refused {Label} on {Path}: {Problem}", label, path, decision.Problem);
                return SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: true, decision.Problem ?? "Not bridged.");

            case OperationMode.Echo:
                return SoapReplyWriter.Result(request, style, resultElement, request.FirstParameterText ?? "");

            case OperationMode.Unavailable:
                logger.LogInformation("Answered {Label} as unavailable (it needs data from the other side)", label);
                return decision.Profile?.Unavailable is { } unavailable
                    ? SoapReplyWriter.Result(request, style, resultElement, Fill(unavailable, business, null))
                    : SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: false,
                        $"{label} is not available while the network is islanded: it needs a live answer from the other side.");
        }

        // ---- Bridge ----
        var allowed = decision.Operation?.AllowedTypes;
        if (allowed is { Count: > 0 } && (business.Type is null || !allowed.Contains(business.Type, StringComparer.Ordinal)))
        {
            string reason = !business.WellFormed
                ? $"{label}: the XML payload is not well-formed."
                : $"{label}: message type '{business.Type ?? "(none)"}' is not accepted by this interface.";
            logger.LogWarning("Refused {Reason}", reason);
            return decision.Profile?.Rejected is { } rejected
                ? SoapReplyWriter.Result(request, style, resultElement, Fill(rejected, business, null))
                : SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: true, reason);
        }

        var message = new RawSoapMessage
        {
            Service = decision.ServiceName,
            Operation = request.Operation,
            Path = path,
            SoapActionHeader = request.SoapActionHeader,
            ContentType = contentType.Length > 0 ? contentType : SoapNamespaces.ContentType(request.Version),
            BusinessType = business.Type,
            Body = body,
        };

        Guid messageId;
        try
        {
            messageId = await outbox.EnqueueAsync(message, ct);
        }
        catch (BridgeBacklogFullException ex)
        {
            logger.LogWarning("Refused {Label}: {Reason}", label, ex.Message);
            return decision.Profile?.Busy is { } busy
                ? SoapReplyWriter.Result(request, style, resultElement, Fill(busy, business, null))
                : SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: false, ex.Message, statusCode: 503);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            // Nothing was committed, so the caller must know the call was NOT accepted.
            logger.LogError(ex, "Could not store {Label}", label);
            return SoapReplyWriter.Fault(request.Version, request.Addressing, senderFault: false,
                "The bridge could not store the message; it was NOT accepted. Please retry.");
        }

        context.Response.Headers[MessageIdHeader] = messageId.ToString("D");

        if (decision.OneWay) return SoapReplyWriter.Accepted();
        return decision.Profile?.Ok is { } ok
            ? SoapReplyWriter.Result(request, style, resultElement, Fill(ok, business, messageId))
            : SoapReplyWriter.EmptyResponse(request);
    }

    /// <summary>Catalogue style when listed; otherwise inferred from the request (unqualified parameters = RPC).</summary>
    private static MessageStyle StyleFor(RouteDecision decision, SoapRequest request) =>
        decision.Service?.Style ?? (request.ParametersUnqualified ? MessageStyle.Rpc : MessageStyle.Document);

    /// <summary>Fills the reply placeholders. Values come from the request, so they are XML-escaped.</summary>
    internal static string Fill(string template, BusinessInfo business, Guid? messageId) =>
        template
            .Replace("{BusinessType}", Escape(business.Type), StringComparison.Ordinal)
            .Replace("{MsgId}", Escape(business.MsgId), StringComparison.Ordinal)
            .Replace("{MessageId}", messageId?.ToString("D") ?? "", StringComparison.Ordinal);

    private static string Escape(string? value) => SecurityElement.Escape(value ?? "");

    /// <summary>Reads the body, or returns null if it is larger than <paramref name="max"/>.</summary>
    private static async Task<byte[]?> ReadBodyAsync(HttpRequest request, int max, CancellationToken ct)
    {
        if (request.ContentLength > max) return null;

        using var buffer = new MemoryStream(request.ContentLength is > 0 and var len ? (int)len : 4096);
        var chunk = new byte[16 * 1024];
        int read;
        while ((read = await request.Body.ReadAsync(chunk, ct)) > 0)
        {
            if (buffer.Length + read > max) return null;
            buffer.Write(chunk, 0, read);
        }
        return buffer.ToArray();
    }

    private static async Task WriteAsync(HttpContext context, SoapReply reply)
    {
        context.Response.StatusCode = reply.StatusCode;
        if (reply.ContentType is not null) context.Response.ContentType = reply.ContentType;
        if (reply.Body.Length > 0) await context.Response.Body.WriteAsync(reply.Body, context.RequestAborted);
    }
}
