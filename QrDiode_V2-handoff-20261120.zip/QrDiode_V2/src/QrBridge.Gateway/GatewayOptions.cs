namespace QrBridge.Gateway;

/// <summary>Gateway-only settings. Bound from the "Gateway" section of appsettings.</summary>
public sealed class GatewayOptions
{
    public const string SectionName = "Gateway";

    /// <summary>Folder of DPAPI-protected *.key files. Lock it to the app pool identity + Administrators.</summary>
    public string KeyFolder { get; set; } = @"C:\ProgramData\QrBridge\Keys";

    /// <summary>Key used to encrypt everything this side SENDS. The other side must have the same key file.</summary>
    public string OutboundKeyId { get; set; } = "";

    /// <summary>
    /// Above this many Pending+Sending Outbox rows, new calls are refused with the route's "Busy" reply
    /// instead of being queued — the caller sees it at once and can retry, rather than a silent pile-up.
    /// </summary>
    public int MaxBacklog { get; set; } = 5000;

    // ----- Inbox worker -----
    public int InboxPollSeconds { get; set; } = 2;
    public int MaxAttempts { get; set; } = 8;
    public int BackoffBaseSeconds { get; set; } = 30;
    public int BackoffMaxMinutes { get; set; } = 30;
    /// <summary>Messages older than this (by sender's CreatedUtc) are rejected as possible replays.</summary>
    public int ReplayWindowDays { get; set; } = 7;
    /// <summary>Messages dated further than this in the future are rejected (clock skew guard).</summary>
    public int MaxClockSkewMinutes { get; set; } = 60;

    // ----- Maintenance -----
    public int MaintenanceIntervalSeconds { get; set; } = 60;
    /// <summary>
    /// Inbox rows in Processing longer than this are assumed abandoned (crash, recycle) and retried.
    /// Must be longer than any egress timeout, or a slow delivery could be sent twice.
    /// </summary>
    public int LockTimeoutMinutes { get; set; } = 5;
    public int RetentionDays { get; set; } = 7;

    // ----- Debug (off in production) -----
    public bool DebugPayloadCapture { get; set; }
    public int DebugRetentionHours { get; set; } = 24;

    /// <summary>Where requests that arrive over the QR link are delivered on this side.</summary>
    public EgressOptions Egress { get; set; } = new();
}

/// <summary>
/// Delivery to the real services on this side. The target for a message is, in order:
/// <c>Targets[service].Url</c>, else <c>DefaultBaseUrl</c> + the path the original caller used.
/// The URL is never taken from the message itself.
/// </summary>
public sealed class EgressOptions
{
    /// <summary>
    /// e.g. "http://dmz-rr-server". The caller's original path is appended, so services hosted under the same
    /// paths as on the load balancer need no per-service entry.
    /// </summary>
    public string? DefaultBaseUrl { get; set; }

    /// <summary>Per-call timeout. Must stay below Gateway:LockTimeoutMinutes.</summary>
    public int TimeoutSeconds { get; set; } = 120;

    /// <summary>Authenticate to the real services as the app pool identity (Windows/NTLM/Kerberos).</summary>
    public bool UseDefaultCredentials { get; set; }

    /// <summary>For WS-Addressing requests: point the wsa:To header at the real service instead of the gateway.</summary>
    public bool RewriteAddressingTo { get; set; } = true;

    /// <summary>Largest reply read back from a real service (only its status is kept).</summary>
    public int MaxResponseBytes { get; set; } = 4_000_000;

    /// <summary>Per-service overrides, keyed by route service name (e.g. "FC2FMS").</summary>
    public Dictionary<string, EgressTarget> Targets { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class EgressTarget
{
    public string Url { get; set; } = "";
    public int? TimeoutSeconds { get; set; }
}
