namespace QrBridge.Gateway.Bridge;

/// <summary>The outbox has too many undelivered messages; the caller gets the route's Busy reply.</summary>
public sealed class BridgeBacklogFullException(int backlog, int max)
    : Exception($"Bridge backlog is full ({backlog} undelivered, limit {max}). Try again later.");

/// <summary>A message that must never be retried (bad signature, wrong direction, not allowed, bad payload).</summary>
public sealed class BridgeRejectException(string reason) : Exception(reason);

/// <summary>A message that can never be delivered as configured (e.g. no egress target). Goes straight to DeadLetter.</summary>
public sealed class PermanentFailureException(string message, Exception? inner = null) : Exception(message, inner);
