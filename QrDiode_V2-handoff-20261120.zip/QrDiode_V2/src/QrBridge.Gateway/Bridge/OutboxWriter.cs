using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Options;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Stores;
using QrBridge.Shared.Envelope;
using QrBridge.Shared.Signals;

namespace QrBridge.Gateway.Bridge;

/// <summary>
/// The ONE place where messages enter the bridge.
///
/// next sequence -> seal (encrypt) -> insert into Outbox -> commit -> ring the Outbox doorbell.
/// The caller only gets its reply after the commit, so an accepted call is never lost.
/// </summary>
public sealed class OutboxWriter(
    IDbContextFactory<OutboundDbContext> factory,
    OutboxStore outboxStore,
    EnvelopeCodec codec,
    BridgeSignals signals,
    IOptions<BridgeOptions> bridgeOptions,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<OutboxWriter> logger)
{
    private const int MaxBusinessTypeLength = 256;

    private readonly BridgeOptions _bridge = bridgeOptions.Value;
    private readonly GatewayOptions _gw = gatewayOptions.Value;

    /// <summary>Queues one caller request. Throws <see cref="BridgeBacklogFullException"/> when the Outbox is full.</summary>
    public async Task<Guid> EnqueueAsync(RawSoapMessage message, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(message);

        int backlog = await outboxStore.CountBacklogAsync(ct);
        if (backlog >= _gw.MaxBacklog) throw new BridgeBacklogFullException(backlog, _gw.MaxBacklog);

        byte[] payload = message.ToBytes();
        var messageId = Guid.NewGuid();
        var direction = _bridge.OutboundDirection;
        string businessType = message.BusinessType is { Length: > MaxBusinessTypeLength } tooLong
            ? tooLong[..MaxBusinessTypeLength]
            : message.BusinessType ?? "";

        await using var db = await factory.CreateDbContextAsync(ct);
        await using var tx = await db.Database.BeginTransactionAsync(ct);

        long sequence = await NextSequenceAsync(db, direction, ct);

        var header = new EnvelopeHeader
        {
            MessageId = messageId,
            MessageType = MessageType.Request,
            Direction = direction,
            ServiceName = message.Service,
            Operation = message.Operation,
            BusinessType = businessType,
            PayloadFormat = PayloadFormat.RawSoap,
            Compression = Compression.Brotli,
            Sequence = sequence,
            CreatedUtc = DateTime.UtcNow,
            KeyId = _gw.OutboundKeyId,
        };

        byte[] envelope = codec.Seal(header, payload);

        db.Outbox.Add(new OutboxMessage
        {
            MessageId = messageId,
            MessageType = MessageType.Request,
            Direction = direction,
            ServiceName = message.Service,
            Operation = message.Operation,
            BusinessType = businessType.Length == 0 ? null : businessType,
            Sequence = sequence,
            PayloadFormat = PayloadFormat.RawSoap,
            KeyId = header.KeyId,
            PayloadSize = payload.Length,
            Envelope = envelope,
            EnvelopeHash = Hashing.Sha256Hex(envelope),
            ChunkCount = 1,
            Status = OutboxStatus.Pending,
            CreatedUtc = header.CreatedUtc,
        });

        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);

        signals.Outbox.Set();
        logger.LogInformation("Queued {Service}.{Operation} {BusinessType} as {MessageId} seq {Sequence} ({Bytes} bytes sealed)",
            message.Service, message.Operation, businessType, messageId, sequence, envelope.Length);
        return messageId;
    }

    /// <summary>Atomic increment inside the caller's transaction (UPDATE ... RETURNING).</summary>
    private static async Task<long> NextSequenceAsync(OutboundDbContext db, Direction direction, CancellationToken ct)
    {
        var connection = db.Database.GetDbConnection();
        var transaction = db.Database.CurrentTransaction!.GetDbTransaction();

        await using (var update = connection.CreateCommand())
        {
            update.Transaction = transaction;
            update.CommandText = "UPDATE SequenceCounter SET LastValue = LastValue + 1 WHERE Direction = $d RETURNING LastValue;";
            var p = update.CreateParameter();
            p.ParameterName = "$d";
            p.Value = direction.ToString();
            update.Parameters.Add(p);

            object? result = await update.ExecuteScalarAsync(ct);
            if (result is not null and not DBNull) return Convert.ToInt64(result);
        }

        // Row missing (shouldn't happen: it is seeded) — create it.
        await using var insert = connection.CreateCommand();
        insert.Transaction = transaction;
        insert.CommandText = "INSERT INTO SequenceCounter (Direction, LastValue) VALUES ($d, 1);";
        var p2 = insert.CreateParameter();
        p2.ParameterName = "$d";
        p2.Value = direction.ToString();
        insert.Parameters.Add(p2);
        await insert.ExecuteNonQueryAsync(ct);
        return 1;
    }
}
