namespace QrBridge.Shared;

/// <summary>Which network this installation runs in. Set in appsettings ("Bridge:Side").</summary>
public enum BridgeSide { Corp = 1, Dmz = 2 }

public enum Direction : byte { CorpToDmz = 1, DmzToCorp = 2 }

/// <summary>What the envelope carries.</summary>
public enum MessageType : byte { Request = 1, Response = 2 }

public enum PayloadFormat : byte
{
    /// <summary>DataContractSerializer XML of a contract object. Not produced by the generic gateway.</summary>
    DataContractXml = 1,
    /// <summary>System.Text.Json of a contract object. Not produced by the generic gateway.</summary>
    Json = 2,
    /// <summary>
    /// A <see cref="Envelope.RawSoapMessage"/>: the caller's SOAP request bytes, untouched, plus the
    /// headers needed to replay it. This is what the generic gateway stores.
    /// </summary>
    RawSoap = 3
}

public enum Compression : byte { None = 0, Brotli = 1 }

public enum OutboxStatus { Pending, Sending, Acked, Failed }

public enum InboxStatus { Pending, Processing, Done, Failed, DeadLetter, Rejected }

public static class BridgeSideExtensions
{
    /// <summary>Direction of messages this side SENDS.</summary>
    public static Direction Outbound(this BridgeSide side) =>
        side == BridgeSide.Corp ? Direction.CorpToDmz : Direction.DmzToCorp;

    /// <summary>Direction of messages this side RECEIVES.</summary>
    public static Direction Inbound(this BridgeSide side) =>
        side == BridgeSide.Corp ? Direction.DmzToCorp : Direction.CorpToDmz;

    /// <summary>The other network.</summary>
    public static BridgeSide Other(this BridgeSide side) =>
        side == BridgeSide.Corp ? BridgeSide.Dmz : BridgeSide.Corp;
}
