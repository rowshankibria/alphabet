using System.Text;

namespace QrBridge.Shared.Envelope;

/// <summary>
/// One caller's SOAP request, exactly as it arrived at the gateway, plus the HTTP details needed to
/// replay it to the real service on the other side. This is the payload sealed into the envelope
/// (<see cref="PayloadFormat.RawSoap"/>), so all of it is encrypted on the wire and at rest.
///
/// The body is never re-serialized: typos in legacy headers (SOURCE_APPLICAION), Verizon envelopes,
/// RPC/Encoded bodies and WS-Addressing headers all reach the real service byte for byte.
///
/// Binary layout (integers little-endian):
///   magic "RSM1" (uint32) · version (byte)
///   Service · Operation · Path · SoapActionHeader · ContentType · BusinessType   (int32 length + UTF-8; -1 = null)
///   body length (int32) · body bytes
/// </summary>
public sealed record RawSoapMessage
{
    private const uint Magic = 0x314D5352; // "RSM1"
    private const byte Version = 1;
    private const int MaxStringBytes = 4096;

    /// <summary>
    /// Upper bound of everything except the body (6 fields of at most 4 KB, plus framing). Envelope limits are
    /// set to MaxPayloadBytes + this, so a body of exactly MaxPayloadBytes still fits.
    /// </summary>
    public const int MaxOverheadBytes = 64 * 1024;

    /// <summary>Route service name (e.g. "FC2FMS"), or the request path when the call was not in the catalogue.</summary>
    public required string Service { get; init; }

    /// <summary>The operation, taken from the SOAP body element (e.g. "SendToFMS").</summary>
    public required string Operation { get; init; }

    /// <summary>The path the caller used, e.g. "/FMS_FC2FMSInterface/FC2FMSInterface.svc".</summary>
    public required string Path { get; init; }

    /// <summary>The SOAPAction HTTP header exactly as received (quotes included); null when absent (SOAP 1.2).</summary>
    public string? SoapActionHeader { get; init; }

    /// <summary>The Content-Type header exactly as received (carries the action for SOAP 1.2).</summary>
    public required string ContentType { get; init; }

    /// <summary>Operator label: MESSAGE/@TYPE or the payload's root element name. May be null.</summary>
    public string? BusinessType { get; init; }

    /// <summary>The HTTP request body: the full SOAP envelope.</summary>
    public required byte[] Body { get; init; }

    public byte[] ToBytes()
    {
        using var ms = new MemoryStream(Body.Length + 512);
        using (var w = new BinaryWriter(ms, Encoding.UTF8, leaveOpen: true))
        {
            w.Write(Magic);
            w.Write(Version);
            WriteString(w, Service);
            WriteString(w, Operation);
            WriteString(w, Path);
            WriteString(w, SoapActionHeader);
            WriteString(w, ContentType);
            WriteString(w, BusinessType);
            w.Write(Body.Length);
            w.Write(Body);
        }
        return ms.ToArray();
    }

    /// <summary>Parses bytes produced by <see cref="ToBytes"/>. Throws <see cref="InvalidDataException"/> on anything else.</summary>
    public static RawSoapMessage FromBytes(byte[] data, int maxBodyBytes)
    {
        using var r = new BinaryReader(new MemoryStream(data, writable: false), Encoding.UTF8);
        try
        {
            if (r.ReadUInt32() != Magic) throw new InvalidDataException("Not a RawSoapMessage.");
            byte version = r.ReadByte();
            if (version != Version) throw new InvalidDataException($"Unsupported RawSoapMessage version {version}.");

            var message = new RawSoapMessage
            {
                Service = ReadRequiredString(r, "Service"),
                Operation = ReadRequiredString(r, "Operation"),
                Path = ReadRequiredString(r, "Path"),
                SoapActionHeader = ReadString(r),
                ContentType = ReadRequiredString(r, "ContentType"),
                BusinessType = ReadString(r),
                Body = ReadBody(r, maxBodyBytes),
            };

            if (r.BaseStream.Position != r.BaseStream.Length)
                throw new InvalidDataException("Trailing bytes after RawSoapMessage.");
            return message;
        }
        catch (EndOfStreamException ex)
        {
            throw new InvalidDataException("RawSoapMessage truncated.", ex);
        }
    }

    private static void WriteString(BinaryWriter w, string? value)
    {
        if (value is null)
        {
            w.Write(-1);
            return;
        }
        byte[] bytes = Encoding.UTF8.GetBytes(value);
        if (bytes.Length > MaxStringBytes)
            throw new ArgumentException($"RawSoapMessage field is longer than {MaxStringBytes} bytes.");
        w.Write(bytes.Length);
        w.Write(bytes);
    }

    private static string? ReadString(BinaryReader r)
    {
        int length = r.ReadInt32();
        if (length == -1) return null;
        if (length < 0 || length > MaxStringBytes) throw new InvalidDataException($"Invalid field length {length}.");
        byte[] bytes = r.ReadBytes(length);
        if (bytes.Length != length) throw new InvalidDataException("RawSoapMessage truncated.");
        return Encoding.UTF8.GetString(bytes);
    }

    private static string ReadRequiredString(BinaryReader r, string name) =>
        ReadString(r) is { Length: > 0 } value ? value : throw new InvalidDataException($"RawSoapMessage {name} is missing.");

    private static byte[] ReadBody(BinaryReader r, int maxBodyBytes)
    {
        int length = r.ReadInt32();
        if (length < 0 || length > maxBodyBytes) throw new InvalidDataException($"Invalid body length {length}.");
        byte[] body = r.ReadBytes(length);
        if (body.Length != length) throw new InvalidDataException("RawSoapMessage truncated.");
        return body;
    }

    /// <summary>Readable text for the optional debug table. Contains the payload — never log it.</summary>
    public string ToDebugText() =>
        $"Service: {Service}\nOperation: {Operation}\nPath: {Path}\nSOAPAction: {SoapActionHeader}\n" +
        $"Content-Type: {ContentType}\nBusinessType: {BusinessType}\n\n{Encoding.UTF8.GetString(Body)}";
}
