using System.Security.Cryptography;

namespace QrBridge.Shared.Envelope;

public static class Hashing
{
    /// <summary>Lower-case hex SHA-256. Stored as EnvelopeHash on both sides for audit/reconciliation.</summary>
    public static string Sha256Hex(byte[] data) => Convert.ToHexStringLower(SHA256.HashData(data));
}
