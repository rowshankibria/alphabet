namespace QrBridge.Shared.Envelope;

/// <summary>
/// Plain-text metadata carried by every message, whatever the service.
/// It is NOT encrypted, but it IS authenticated: it is fed to AES-GCM as associated data,
/// so any change to it makes decryption fail. Never put sensitive data here.
/// </summary>
public sealed record EnvelopeHeader
{
    public const byte CurrentVersion = 1;

    public byte Version { get; init; } = CurrentVersion;

    /// <summary>End-to-end id. Same value in the sender's Outbox and the receiver's Inbox.</summary>
    public required Guid MessageId { get; init; }

    /// <summary>For a Response: the MessageId of the original Request. Guid.Empty otherwise.</summary>
    public Guid CorrelationId { get; init; }

    public required MessageType MessageType { get; init; }
    public required Direction Direction { get; init; }

    /// <summary>Route service name from the gateway's catalogue, e.g. "FC2FMS".</summary>
    public required string ServiceName { get; init; }

    /// <summary>SOAP operation, e.g. "SendToFMS".</summary>
    public required string Operation { get; init; }

    /// <summary>
    /// What the caller's payload says it is, for operators: the FMS MESSAGE/@TYPE (e.g. "RETURN_ORDER")
    /// or the root element name of other payloads (e.g. "createTicketResponse"). Empty when unknown.
    /// It is a label, not data — callers decide nothing based on it.
    /// </summary>
    public string BusinessType { get; init; } = "";

    public PayloadFormat PayloadFormat { get; init; } = PayloadFormat.RawSoap;
    public Compression Compression { get; init; } = Compression.Brotli;

    /// <summary>Per-direction sequence number, for ordering and gap detection.</summary>
    public long Sequence { get; init; }

    public DateTime CreatedUtc { get; init; } = DateTime.UtcNow;

    /// <summary>Which key encrypted this message (enables rotation).</summary>
    public required string KeyId { get; init; }
}
