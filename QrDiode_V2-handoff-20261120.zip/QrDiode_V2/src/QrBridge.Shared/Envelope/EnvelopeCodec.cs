using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using QrBridge.Shared.Security;

namespace QrBridge.Shared.Envelope;

/// <summary>
/// Seals any payload into one common binary envelope and opens it again.
///
/// Wire format (integers little-endian):
///   magic      uint32   "BRG1"
///   headerLen  int32
///   header     bytes    EnvelopeHeader, binary; authenticated as AES-GCM associated data
///   nonce      12 bytes
///   tag        16 bytes
///   cipherLen  int32
///   cipher     bytes    compressed payload, AES-256-GCM encrypted
///
/// Pipeline: payload -> Brotli -> AES-256-GCM(header as AAD) -> envelope bytes.
/// </summary>
public sealed class EnvelopeCodec
{
    private const uint Magic = 0x31475242; // "BRG1"
    private const int NonceSize = 12;
    private const int TagSize = 16;
    private const int MaxHeaderBytes = 4096;
    private const int MaxStringLength = 256;

    private readonly IKeyProvider _keys;
    private readonly int _maxPayloadBytes;

    public EnvelopeCodec(IKeyProvider keys, int maxPayloadBytes = 1_000_000)
    {
        _keys = keys;
        _maxPayloadBytes = maxPayloadBytes;
    }

    public byte[] Seal(EnvelopeHeader header, ReadOnlySpan<byte> payload)
    {
        if (payload.Length > _maxPayloadBytes)
            throw new ArgumentException($"Payload {payload.Length} bytes exceeds limit {_maxPayloadBytes}.");

        byte[] headerBytes = WriteHeader(header);
        byte[] plain = header.Compression == Compression.Brotli ? Compress(payload) : payload.ToArray();

        byte[] nonce = RandomNumberGenerator.GetBytes(NonceSize);
        byte[] tag = new byte[TagSize];
        byte[] cipher = new byte[plain.Length];

        using (var aes = new AesGcm(_keys.GetKey(header.KeyId), TagSize))
            aes.Encrypt(nonce, plain, cipher, tag, headerBytes);

        using var ms = new MemoryStream();
        using (var w = new BinaryWriter(ms, Encoding.UTF8, leaveOpen: true))
        {
            w.Write(Magic);
            w.Write(headerBytes.Length);
            w.Write(headerBytes);
            w.Write(nonce);
            w.Write(tag);
            w.Write(cipher.Length);
            w.Write(cipher);
        }
        return ms.ToArray();
    }

    /// <summary>
    /// Reads the header WITHOUT decrypting and without a key. Used by the QR receiver to fill
    /// the Inbox columns. The result is not yet authenticated — the Gateway verifies it on Open.
    /// </summary>
    public static EnvelopeHeader PeekHeader(byte[] envelope)
    {
        using var r = new BinaryReader(new MemoryStream(envelope, writable: false));
        ReadMagic(r);
        return ReadHeader(ReadExact(r, ReadLength(r, MaxHeaderBytes)));
    }

    /// <summary>Verifies and decrypts. Throws <see cref="CryptographicException"/> or
    /// <see cref="InvalidDataException"/> if the envelope is tampered, corrupt, or uses an unknown key.</summary>
    public (EnvelopeHeader Header, byte[] Payload) Open(byte[] envelope)
    {
        using var r = new BinaryReader(new MemoryStream(envelope, writable: false));
        ReadMagic(r);

        byte[] headerBytes = ReadExact(r, ReadLength(r, MaxHeaderBytes));
        EnvelopeHeader header = ReadHeader(headerBytes);

        byte[] nonce = ReadExact(r, NonceSize);
        byte[] tag = ReadExact(r, TagSize);
        byte[] cipher = ReadExact(r, ReadLength(r, _maxPayloadBytes + 1024));

        if (r.BaseStream.Position != r.BaseStream.Length)
            throw new InvalidDataException("Trailing bytes after envelope.");

        byte[] key;
        try { key = _keys.GetKey(header.KeyId); }
        catch (KeyNotFoundException ex) { throw new CryptographicException(ex.Message, ex); }

        byte[] plain = new byte[cipher.Length];
        try
        {
            using var aes = new AesGcm(key, TagSize);
            aes.Decrypt(nonce, cipher, tag, plain, headerBytes); // also authenticates the header
        }
        catch (AuthenticationTagMismatchException ex)
        {
            throw new CryptographicException("Envelope failed authentication (tampered, corrupted, or wrong key).", ex);
        }

        byte[] payload = header.Compression == Compression.Brotli ? Decompress(plain) : plain;
        return (header, payload);
    }

    // ---------------- header ----------------

    private static byte[] WriteHeader(EnvelopeHeader h)
    {
        CheckString(h.ServiceName, nameof(h.ServiceName));
        CheckString(h.Operation, nameof(h.Operation));
        CheckString(h.KeyId, nameof(h.KeyId));
        CheckOptionalString(h.BusinessType, nameof(h.BusinessType));

        using var ms = new MemoryStream();
        using (var w = new BinaryWriter(ms, Encoding.UTF8, leaveOpen: true))
        {
            w.Write(h.Version);
            w.Write((byte)h.MessageType);
            w.Write((byte)h.Direction);
            w.Write((byte)h.PayloadFormat);
            w.Write((byte)h.Compression);
            w.Write(h.MessageId.ToByteArray());
            w.Write(h.CorrelationId.ToByteArray());
            w.Write(h.Sequence);
            w.Write(h.CreatedUtc.ToUniversalTime().Ticks);
            w.Write(h.ServiceName);
            w.Write(h.Operation);
            w.Write(h.KeyId);
            w.Write(h.BusinessType);
        }
        return ms.ToArray();
    }

    private static EnvelopeHeader ReadHeader(byte[] bytes)
    {
        using var r = new BinaryReader(new MemoryStream(bytes, writable: false), Encoding.UTF8);

        byte version = r.ReadByte();
        if (version != EnvelopeHeader.CurrentVersion)
            throw new InvalidDataException($"Unsupported envelope version {version}.");

        var header = new EnvelopeHeader
        {
            Version = version,
            MessageType = CheckEnum<MessageType>(r.ReadByte()),
            Direction = CheckEnum<Direction>(r.ReadByte()),
            PayloadFormat = CheckEnum<PayloadFormat>(r.ReadByte()),
            Compression = CheckEnum<Compression>(r.ReadByte()),
            MessageId = new Guid(ReadExact(r, 16)),
            CorrelationId = new Guid(ReadExact(r, 16)),
            Sequence = r.ReadInt64(),
            CreatedUtc = ReadTicks(r.ReadInt64()),
            ServiceName = CheckString(r.ReadString(), "ServiceName"),
            Operation = CheckString(r.ReadString(), "Operation"),
            KeyId = CheckString(r.ReadString(), "KeyId"),
            BusinessType = CheckOptionalString(r.ReadString(), "BusinessType"),
        };

        if (r.BaseStream.Position != r.BaseStream.Length)
            throw new InvalidDataException("Trailing bytes in header.");
        return header;
    }

    private static DateTime ReadTicks(long ticks) =>
        ticks is >= 0 and <= 3155378975999999999 // DateTime.MaxValue.Ticks
            ? new DateTime(ticks, DateTimeKind.Utc)
            : throw new InvalidDataException("Invalid timestamp.");

    private static T CheckEnum<T>(byte value) where T : struct, Enum
    {
        var e = (T)Enum.ToObject(typeof(T), value);
        return Enum.IsDefined(e) ? e : throw new InvalidDataException($"Invalid {typeof(T).Name} value {value}.");
    }

    private static string CheckString(string value, string name) =>
        !string.IsNullOrWhiteSpace(value) && value.Length <= MaxStringLength
            ? value
            : throw new InvalidDataException($"Header field {name} is empty or too long.");

    private static string CheckOptionalString(string? value, string name) =>
        value is null ? throw new InvalidDataException($"Header field {name} is missing.")
        : value.Length <= MaxStringLength ? value
        : throw new InvalidDataException($"Header field {name} is too long.");

    // ---------------- compression ----------------

    private static byte[] Compress(ReadOnlySpan<byte> data)
    {
        using var output = new MemoryStream();
        using (var brotli = new BrotliStream(output, CompressionLevel.SmallestSize, leaveOpen: true))
            brotli.Write(data);
        return output.ToArray();
    }

    /// <summary>Decompresses with a hard size cap so a hostile "zip bomb" can't exhaust memory.</summary>
    private byte[] Decompress(byte[] data)
    {
        using var input = new BrotliStream(new MemoryStream(data, writable: false), CompressionMode.Decompress);
        using var output = new MemoryStream();
        var buffer = new byte[81920];
        int read;
        while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
        {
            if (output.Length + read > _maxPayloadBytes)
                throw new InvalidDataException("Decompressed payload exceeds limit.");
            output.Write(buffer, 0, read);
        }
        return output.ToArray();
    }

    // ---------------- helpers ----------------

    private static void ReadMagic(BinaryReader r)
    {
        if (r.BaseStream.Length < 4 || r.ReadUInt32() != Magic)
            throw new InvalidDataException("Not a bridge envelope.");
    }

    private static int ReadLength(BinaryReader r, int max)
    {
        int len = r.ReadInt32();
        if (len < 0 || len > max) throw new InvalidDataException($"Invalid length {len}.");
        return len;
    }

    private static byte[] ReadExact(BinaryReader r, int count)
    {
        byte[] b = r.ReadBytes(count);
        if (b.Length != count) throw new InvalidDataException("Envelope truncated.");
        return b;
    }
}
