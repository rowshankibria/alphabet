using Microsoft.EntityFrameworkCore;
using QrBridge.Shared.Data.Configurations;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data;

/// <summary>outbound.db — Gateway writes, QR sender reads.</summary>
public sealed class OutboundDbContext(DbContextOptions<OutboundDbContext> options) : DbContext(options)
{
    public DbSet<OutboxMessage> Outbox => Set<OutboxMessage>();
    public DbSet<SequenceCounter> SequenceCounters => Set<SequenceCounter>();

    protected override void ConfigureConventions(ModelConfigurationBuilder builder) =>
        SqliteConventions.Apply(builder);

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfiguration(new OutboxMessageConfiguration());
        modelBuilder.ApplyConfiguration(new SequenceCounterConfiguration());
    }
}

/// <summary>inbound.db — QR receiver writes, Gateway worker reads. Also holds heartbeats.</summary>
public sealed class InboundDbContext(DbContextOptions<InboundDbContext> options) : DbContext(options)
{
    public DbSet<InboxMessage> Inbox => Set<InboxMessage>();
    public DbSet<Heartbeat> Heartbeats => Set<Heartbeat>();
    public DbSet<InboxPayloadDebug> InboxPayloadDebug => Set<InboxPayloadDebug>();

    protected override void ConfigureConventions(ModelConfigurationBuilder builder) =>
        SqliteConventions.Apply(builder);

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfiguration(new InboxMessageConfiguration());
        modelBuilder.ApplyConfiguration(new HeartbeatConfiguration());
        modelBuilder.ApplyConfiguration(new InboxPayloadDebugConfiguration());
    }
}
