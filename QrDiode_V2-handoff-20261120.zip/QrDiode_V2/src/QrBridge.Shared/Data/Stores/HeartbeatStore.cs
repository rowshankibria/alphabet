using Microsoft.EntityFrameworkCore;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Stores;

public static class Components
{
    public const string GatewayApi = "GatewayApi";
    public const string InboxWorker = "InboxWorker";
    public const string MaintenanceWorker = "MaintenanceWorker";
    public const string SenderLoop = "SenderLoop";
    public const string ReceiverLoop = "ReceiverLoop";
}

/// <summary>Liveness rows in inbound.db, written by every component every ~30 seconds.</summary>
public sealed class HeartbeatStore(IDbContextFactory<InboundDbContext> factory)
{
    public async Task BeatAsync(string component, string? info, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        info = info is { Length: > 1024 } ? info[..1024] : info;

        int updated = await db.Heartbeats.Where(h => h.Component == component)
            .ExecuteUpdateAsync(s => s.SetProperty(h => h.LastSeenUtc, now).SetProperty(h => h.Info, info), ct);
        if (updated == 0)
        {
            db.Heartbeats.Add(new Heartbeat { Component = component, LastSeenUtc = now, Info = info });
            try { await db.SaveChangesAsync(ct); }
            catch (DbUpdateException) { /* another process inserted it first; next beat updates */ }
        }
    }

    public async Task<IReadOnlyList<Heartbeat>> GetAllAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Heartbeats.AsNoTracking().OrderBy(h => h.Component).ToListAsync(ct);
    }
}
