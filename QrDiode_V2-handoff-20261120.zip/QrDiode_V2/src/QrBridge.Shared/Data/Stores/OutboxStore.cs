using Microsoft.EntityFrameworkCore;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Stores;

public sealed record OutboxCounts(int Pending, int Sending, int Acked, int Failed, DateTime? OldestUnackedUtc);

/// <summary>
/// Queue operations on outbound.db. Each method uses its own short-lived DbContext.
/// Writing new rows is done by the Gateway's OutboxWriter (it needs the sequence + envelope in one transaction);
/// claiming and marking rows is done by the QR sender.
/// </summary>
public sealed class OutboxStore(IDbContextFactory<OutboundDbContext> factory)
{
    /// <summary>
    /// Atomically claims the oldest Pending row (Pending -> Sending). Returns null if none.
    /// Optimistic claim: the UPDATE only succeeds if the row is still Pending, so two claimers can never get the same row.
    /// </summary>
    public async Task<OutboxMessage?> ClaimNextAsync(CancellationToken ct)
    {
        for (int attempt = 0; attempt < 5; attempt++)
        {
            await using var db = await factory.CreateDbContextAsync(ct);
            var now = DateTime.UtcNow;

            long? id = await db.Outbox
                .Where(m => m.Status == OutboxStatus.Pending && (m.NextAttemptUtc == null || m.NextAttemptUtc <= now))
                .OrderBy(m => m.Id)
                .Select(m => (long?)m.Id)
                .FirstOrDefaultAsync(ct);
            if (id is null) return null;

            int claimed = await db.Outbox
                .Where(m => m.Id == id && m.Status == OutboxStatus.Pending)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.Status, OutboxStatus.Sending)
                    .SetProperty(m => m.LockedUtc, now)
                    .SetProperty(m => m.Attempts, m => m.Attempts + 1), ct);

            if (claimed == 1)
                return await db.Outbox.AsNoTracking().FirstAsync(m => m.Id == id, ct);
        }
        return null;
    }

    /// <summary>Marks messages as delivered. Ids that don't exist or are already Acked are ignored.</summary>
    public async Task<int> MarkAckedAsync(IReadOnlyCollection<Guid> messageIds, CancellationToken ct)
    {
        if (messageIds.Count == 0) return 0;
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        int total = 0;
        // One small UPDATE per id (an ACK frame carries at most 120) — simple and index-friendly.
        foreach (Guid id in messageIds.Distinct())
        {
            total += await db.Outbox
                .Where(m => m.MessageId == id && m.Status != OutboxStatus.Acked)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.Status, OutboxStatus.Acked)
                    .SetProperty(m => m.AckedUtc, now)
                    .SetProperty(m => m.LockedUtc, (DateTime?)null)
                    .SetProperty(m => m.LastError, (string?)null), ct);
        }
        return total;
    }

    /// <summary>
    /// Gives a message back to the queue after it was shown for too long without an ACK
    /// (lets other messages through). After maxAttempts it is marked Failed for an operator to look at.
    /// </summary>
    public async Task ReleaseAsync(long id, string reason, int maxAttempts, TimeSpan retryDelay, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var row = await db.Outbox.FirstOrDefaultAsync(m => m.Id == id, ct);
        if (row is null || row.Status != OutboxStatus.Sending) return;

        row.LockedUtc = null;
        row.LastError = reason;
        if (row.Attempts >= maxAttempts)
        {
            row.Status = OutboxStatus.Failed;
        }
        else
        {
            row.Status = OutboxStatus.Pending;
            row.NextAttemptUtc = DateTime.UtcNow + retryDelay;
        }
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Called by the QR sender at startup: anything it was showing when it stopped goes back to Pending.</summary>
    public async Task<int> ResetSendingAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox
            .Where(m => m.Status == OutboxStatus.Sending)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.Status, OutboxStatus.Pending)
                .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
    }

    /// <summary>Operator action: put a Failed message back in the queue.</summary>
    public async Task<int> RequeueFailedAsync(Guid? messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var q = db.Outbox.Where(m => m.Status == OutboxStatus.Failed);
        if (messageId is { } id) q = q.Where(m => m.MessageId == id);
        return await q.ExecuteUpdateAsync(s => s
            .SetProperty(m => m.Status, OutboxStatus.Pending)
            .SetProperty(m => m.Attempts, 0)
            .SetProperty(m => m.NextAttemptUtc, (DateTime?)null), ct);
    }

    public async Task<OutboxMessage?> FindAsync(Guid messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.AsNoTracking().FirstOrDefaultAsync(m => m.MessageId == messageId, ct);
    }

    public async Task<int> CountBacklogAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Outbox.CountAsync(m => m.Status == OutboxStatus.Pending || m.Status == OutboxStatus.Sending, ct);
    }

    public async Task<OutboxCounts> GetCountsAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var groups = await db.Outbox.GroupBy(m => m.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToListAsync(ct);
        DateTime? oldest = await db.Outbox
            .Where(m => m.Status == OutboxStatus.Pending || m.Status == OutboxStatus.Sending)
            .OrderBy(m => m.Id)
            .Select(m => (DateTime?)m.CreatedUtc)
            .FirstOrDefaultAsync(ct);

        int Get(OutboxStatus s) => groups.FirstOrDefault(g => g.Status == s)?.Count ?? 0;
        return new OutboxCounts(Get(OutboxStatus.Pending), Get(OutboxStatus.Sending),
                                Get(OutboxStatus.Acked), Get(OutboxStatus.Failed), oldest);
    }

    /// <summary>Retention: delete delivered rows older than the cutoff.</summary>
    public async Task<int> PurgeAckedAsync(TimeSpan olderThan, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var cutoff = DateTime.UtcNow - olderThan;
        return await db.Outbox
            .Where(m => m.Status == OutboxStatus.Acked && m.AckedUtc < cutoff)
            .ExecuteDeleteAsync(ct);
    }
}
