using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Envelope;

namespace QrBridge.Shared.Data.Stores;

public sealed record InboxCounts(int Pending, int Processing, int Done, int Failed, int DeadLetter, int Rejected);

/// <summary>Queue operations on inbound.db. Each method uses its own short-lived DbContext.</summary>
public sealed class InboxStore(IDbContextFactory<InboundDbContext> factory)
{
    private const int SqliteConstraint = 19; // SQLITE_CONSTRAINT
    private const int MaxErrorLength = 2000;
    private const int MaxResultLength = 4000;

    // =================== QR receiver side ===================

    /// <summary>
    /// Inserts a complete message (header read without a key). Idempotent on MessageId:
    /// returns false if the message was already in the Inbox (the duplicate is ignored).
    /// </summary>
    public async Task<bool> AddMessageAsync(EnvelopeHeader header, byte[] envelope, int chunkCount, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        if (await db.Inbox.AnyAsync(m => m.MessageId == header.MessageId, ct))
            return false;

        db.Inbox.Add(new InboxMessage
        {
            MessageId = header.MessageId,
            CorrelationId = header.CorrelationId == Guid.Empty ? null : header.CorrelationId,
            MessageType = header.MessageType,
            Direction = header.Direction,
            ServiceName = header.ServiceName,
            Operation = header.Operation,
            BusinessType = string.IsNullOrEmpty(header.BusinessType) ? null : header.BusinessType,
            Sequence = header.Sequence,
            PayloadFormat = header.PayloadFormat,
            KeyId = header.KeyId,
            Envelope = envelope,
            EnvelopeHash = Hashing.Sha256Hex(envelope),
            ChunkCount = Math.Max(1, chunkCount),
            Status = InboxStatus.Pending,
            CreatedUtc = header.CreatedUtc,
            ReceivedUtc = DateTime.UtcNow,
        });

        try
        {
            await db.SaveChangesAsync(ct);
            return true;
        }
        catch (DbUpdateException ex) when (ex.InnerException is SqliteException { SqliteErrorCode: SqliteConstraint })
        {
            return false; // inserted by someone else between the check and the insert
        }
    }

    // =================== Gateway side (worker) ===================

    /// <summary>
    /// Atomically claims the next message ready to process: Pending, or Failed whose backoff has expired.
    /// </summary>
    public async Task<InboxMessage?> ClaimNextAsync(CancellationToken ct)
    {
        for (int attempt = 0; attempt < 5; attempt++)
        {
            await using var db = await factory.CreateDbContextAsync(ct);
            var now = DateTime.UtcNow;

            long? id = await db.Inbox
                .Where(m => m.Status == InboxStatus.Pending ||
                            (m.Status == InboxStatus.Failed && m.NextAttemptUtc != null && m.NextAttemptUtc <= now))
                .OrderBy(m => m.Id)
                .Select(m => (long?)m.Id)
                .FirstOrDefaultAsync(ct);
            if (id is null) return null;

            int claimed = await db.Inbox
                .Where(m => m.Id == id && (m.Status == InboxStatus.Pending || m.Status == InboxStatus.Failed))
                .ExecuteUpdateAsync(s => s
                    .SetProperty(m => m.Status, InboxStatus.Processing)
                    .SetProperty(m => m.LockedUtc, now)
                    .SetProperty(m => m.Attempts, m => m.Attempts + 1), ct);

            if (claimed == 1)
                return await db.Inbox.AsNoTracking().FirstAsync(m => m.Id == id, ct);
        }
        return null;
    }

    /// <summary>The real service accepted it.</summary>
    public async Task MarkDoneAsync(long id, string? downstreamResult, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        string? result = Truncate(downstreamResult, MaxResultLength);
        await db.Inbox.Where(m => m.Id == id).ExecuteUpdateAsync(s => s
            .SetProperty(m => m.Status, InboxStatus.Done)
            .SetProperty(m => m.Verified, true)
            .SetProperty(m => m.ProcessedUtc, now)
            .SetProperty(m => m.LockedUtc, (DateTime?)null)
            .SetProperty(m => m.NextAttemptUtc, (DateTime?)null)
            .SetProperty(m => m.LastError, (string?)null)
            .SetProperty(m => m.DownstreamResult, result), ct);
    }

    public async Task MarkVerifiedAsync(long id, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        await db.Inbox.Where(m => m.Id == id).ExecuteUpdateAsync(s => s.SetProperty(m => m.Verified, true), ct);
    }

    /// <summary>Permanent failure before delivery (bad signature, not allowed, bad payload). Never retried.</summary>
    public async Task MarkRejectedAsync(long id, string reason, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        string error = Truncate(reason, MaxErrorLength)!;
        await db.Inbox.Where(m => m.Id == id).ExecuteUpdateAsync(s => s
            .SetProperty(m => m.Status, InboxStatus.Rejected)
            .SetProperty(m => m.ProcessedUtc, now)
            .SetProperty(m => m.LockedUtc, (DateTime?)null)
            .SetProperty(m => m.LastError, error), ct);
    }

    /// <summary>
    /// The real service refused it (SOAP fault or a business error code), or it can never be delivered as
    /// configured. Retrying won't help; an operator decides (requeue after fixing the cause).
    /// </summary>
    public async Task MarkDeadLetterAsync(long id, string error, string? downstreamResult, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        string message = Truncate(error, MaxErrorLength)!;
        string? result = Truncate(downstreamResult, MaxResultLength);
        await db.Inbox.Where(m => m.Id == id).ExecuteUpdateAsync(s => s
            .SetProperty(m => m.Status, InboxStatus.DeadLetter)
            .SetProperty(m => m.ProcessedUtc, now)
            .SetProperty(m => m.NextAttemptUtc, (DateTime?)null)
            .SetProperty(m => m.LockedUtc, (DateTime?)null)
            .SetProperty(m => m.LastError, message)
            .SetProperty(m => m.DownstreamResult, result), ct);
    }

    /// <summary>Transient failure: retry with backoff, or DeadLetter after maxAttempts.</summary>
    public async Task MarkFailedAsync(long id, int attempts, string error, int maxAttempts, TimeSpan backoff, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        bool dead = attempts >= maxAttempts;
        DateTime? next = dead ? null : DateTime.UtcNow + backoff;
        string message = Truncate(error, MaxErrorLength)!;
        await db.Inbox.Where(m => m.Id == id).ExecuteUpdateAsync(s => s
            .SetProperty(m => m.Status, dead ? InboxStatus.DeadLetter : InboxStatus.Failed)
            .SetProperty(m => m.NextAttemptUtc, next)
            .SetProperty(m => m.LockedUtc, (DateTime?)null)
            .SetProperty(m => m.LastError, message), ct);
    }

    /// <summary>Shutdown in the middle of a message: put it back without counting the attempt.</summary>
    public async Task ReleaseAsync(long id, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        await db.Inbox.Where(m => m.Id == id && m.Status == InboxStatus.Processing).ExecuteUpdateAsync(s => s
            .SetProperty(m => m.Status, InboxStatus.Pending)
            .SetProperty(m => m.Attempts, m => m.Attempts > 0 ? m.Attempts - 1 : 0)
            .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
    }

    /// <summary>Recovers messages stuck in Processing (worker crashed or app pool recycled).</summary>
    public async Task<int> ResetStuckAsync(TimeSpan lockTimeout, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var cutoff = DateTime.UtcNow - lockTimeout;
        return await db.Inbox
            .Where(m => m.Status == InboxStatus.Processing && m.LockedUtc < cutoff)
            .ExecuteUpdateAsync(s => s
                .SetProperty(m => m.Status, InboxStatus.Pending)
                .SetProperty(m => m.LockedUtc, (DateTime?)null), ct);
    }

    /// <summary>Operator action: give a DeadLetter message another try.</summary>
    public async Task<int> RequeueDeadLetterAsync(Guid? messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var q = db.Inbox.Where(m => m.Status == InboxStatus.DeadLetter);
        if (messageId is { } id) q = q.Where(m => m.MessageId == id);
        return await q.ExecuteUpdateAsync(s => s
            .SetProperty(m => m.Status, InboxStatus.Pending)
            .SetProperty(m => m.Attempts, 0)
            .SetProperty(m => m.NextAttemptUtc, (DateTime?)null), ct);
    }

    public async Task CaptureDebugPayloadAsync(Guid messageId, string text, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        if (await db.InboxPayloadDebug.AnyAsync(d => d.MessageId == messageId, ct)) return;
        db.InboxPayloadDebug.Add(new InboxPayloadDebug { MessageId = messageId, PayloadText = text, CreatedUtc = DateTime.UtcNow });
        await db.SaveChangesAsync(ct);
    }

    public async Task<InboxMessage?> FindAsync(Guid messageId, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Inbox.AsNoTracking().FirstOrDefaultAsync(m => m.MessageId == messageId, ct);
    }

    public async Task<InboxCounts> GetCountsAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var groups = await db.Inbox.GroupBy(m => m.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToListAsync(ct);

        int Get(InboxStatus s) => groups.FirstOrDefault(g => g.Status == s)?.Count ?? 0;
        return new InboxCounts(Get(InboxStatus.Pending), Get(InboxStatus.Processing), Get(InboxStatus.Done),
                               Get(InboxStatus.Failed), Get(InboxStatus.DeadLetter), Get(InboxStatus.Rejected));
    }

    /// <summary>Retention cleanup. Run on a schedule by the Gateway.</summary>
    public async Task<(int Done, int Debug)> PurgeAsync(TimeSpan doneOlderThan, TimeSpan debugOlderThan, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        var doneCutoff = now - doneOlderThan;
        var debugCutoff = now - debugOlderThan;

        int done = await db.Inbox.Where(m => m.Status == InboxStatus.Done && m.ProcessedUtc < doneCutoff).ExecuteDeleteAsync(ct);
        int debug = await db.InboxPayloadDebug.Where(d => d.CreatedUtc < debugCutoff).ExecuteDeleteAsync(ct);
        return (done, debug);
    }

    private static string? Truncate(string? s, int max) => s is null || s.Length <= max ? s : s[..max];
}
