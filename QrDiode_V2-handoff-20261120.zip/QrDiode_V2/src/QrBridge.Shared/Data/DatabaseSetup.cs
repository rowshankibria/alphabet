using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using QrBridge.Shared.Data.Stores;

namespace QrBridge.Shared.Data;

public static class DataServiceCollectionExtensions
{
    /// <summary>
    /// Registers both DbContext factories and the stores. Call from both apps.
    /// The database paths are read from <see cref="IOptions{BridgeOptions}"/> when the first context is
    /// created, so configure <see cref="BridgeOptions"/> (e.g. BindConfiguration("Bridge")) before resolving.
    /// </summary>
    public static IServiceCollection AddBridgeData(this IServiceCollection services)
    {
        services.AddDbContextFactory<OutboundDbContext>((sp, o) =>
            DatabaseSetup.Configure(o, sp.GetRequiredService<IOptions<BridgeOptions>>().Value.OutboundDbPath));
        services.AddDbContextFactory<InboundDbContext>((sp, o) =>
            DatabaseSetup.Configure(o, sp.GetRequiredService<IOptions<BridgeOptions>>().Value.InboundDbPath));

        services.AddSingleton<OutboxStore>();
        services.AddSingleton<InboxStore>();
        services.AddSingleton<HeartbeatStore>();
        return services;
    }

    /// <summary>Same as <see cref="AddBridgeData(IServiceCollection)"/> with fixed options (tests, tools).</summary>
    public static IServiceCollection AddBridgeData(this IServiceCollection services, BridgeOptions options)
    {
        services.AddSingleton(Options.Create(options));
        return services.AddBridgeData();
    }
}

public static class DatabaseSetup
{
    public static string ConnectionString(string path) => new SqliteConnectionStringBuilder
    {
        DataSource = path,
        Mode = SqliteOpenMode.ReadWriteCreate,
        Cache = SqliteCacheMode.Private,
        Pooling = true,
        DefaultTimeout = 30, // seconds; Microsoft.Data.Sqlite also retries SQLITE_BUSY up to this
    }.ToString();

    public static void Configure(DbContextOptionsBuilder o, string path) =>
        o.UseSqlite(ConnectionString(path))
         .AddInterceptors(new SqlitePragmaInterceptor());
}

/// <summary>
/// Creates or upgrades both databases. Safe to call from both apps at startup, in any order.
///
/// - Creates the data folder if it does not exist.
/// - If EF migrations exist in this assembly, they are applied (use this once you go to production).
/// - Otherwise the schema is created from the model (EnsureCreated).
/// - Turns on WAL mode (persistent in the file).
/// - Retries, because the Gateway and the QR apps may all try to create the files at the same moment.
/// </summary>
public static class DatabaseInitializer
{
    public static async Task InitializeAsync(IServiceProvider services, ILogger logger, CancellationToken ct = default)
    {
        var options = services.GetRequiredService<IOptions<BridgeOptions>>().Value;
        Directory.CreateDirectory(options.DataFolder);

        await InitializeOneAsync(services.GetRequiredService<IDbContextFactory<OutboundDbContext>>(), "outbound.db", logger, ct);
        await InitializeOneAsync(services.GetRequiredService<IDbContextFactory<InboundDbContext>>(), "inbound.db", logger, ct);
    }

    private static async Task InitializeOneAsync<TContext>(
        IDbContextFactory<TContext> factory, string name, ILogger logger, CancellationToken ct)
        where TContext : DbContext
    {
        for (int attempt = 1; ; attempt++)
        {
            try
            {
                await using var db = await factory.CreateDbContextAsync(ct);

                if (db.Database.GetMigrations().Any())
                    await db.Database.MigrateAsync(ct);
                else
                    await db.Database.EnsureCreatedAsync(ct);

                await db.Database.ExecuteSqlRawAsync("PRAGMA journal_mode = WAL;", ct);
                logger.LogInformation("Database {Name} ready", name);
                return;
            }
            catch (Exception ex) when (attempt < 5 && ex is SqliteException or InvalidOperationException or DbUpdateException)
            {
                logger.LogWarning(ex, "Initializing {Name} failed (attempt {Attempt}); retrying", name, attempt);
                await Task.Delay(TimeSpan.FromSeconds(attempt), ct);
            }
        }
    }
}

// ----- Design-time factories: used only by "dotnet ef migrations ..." -----

public sealed class OutboundDesignTimeFactory : IDesignTimeDbContextFactory<OutboundDbContext>
{
    public OutboundDbContext CreateDbContext(string[] args)
    {
        var o = new DbContextOptionsBuilder<OutboundDbContext>();
        DatabaseSetup.Configure(o, Path.Combine(Path.GetTempPath(), "qrbridge-design-outbound.db"));
        return new OutboundDbContext(o.Options);
    }
}

public sealed class InboundDesignTimeFactory : IDesignTimeDbContextFactory<InboundDbContext>
{
    public InboundDbContext CreateDbContext(string[] args)
    {
        var o = new DbContextOptionsBuilder<InboundDbContext>();
        DatabaseSetup.Configure(o, Path.Combine(Path.GetTempPath(), "qrbridge-design-inbound.db"));
        return new InboundDbContext(o.Options);
    }
}
