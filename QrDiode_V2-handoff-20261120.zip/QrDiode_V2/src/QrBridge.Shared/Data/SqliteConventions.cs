using System.Data.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace QrBridge.Shared.Data;

/// <summary>
/// Storage rules applied to every entity in both databases:
/// - enums stored as their names (readable, matches the CHECK constraints)
/// - Guids stored as lower-case "D" text (readable, stable for raw SQL and tooling)
/// - DateTimes always UTC (SQLite has no time zone; this restores Kind=Utc on read)
/// </summary>
public static class SqliteConventions
{
    public static void Apply(ModelConfigurationBuilder b)
    {
        b.Properties<Enum>().HaveConversion<string>().HaveMaxLength(32);
        b.Properties<Guid>().HaveConversion<GuidStringConverter>().HaveMaxLength(36);
        b.Properties<Guid?>().HaveConversion<GuidStringConverter>().HaveMaxLength(36);
        b.Properties<DateTime>().HaveConversion<UtcDateTimeConverter>();
        b.Properties<DateTime?>().HaveConversion<UtcDateTimeConverter>();
    }
}

public sealed class GuidStringConverter() : ValueConverter<Guid, string>(
    v => v.ToString("D"),
    v => Guid.Parse(v));

public sealed class UtcDateTimeConverter() : ValueConverter<DateTime, DateTime>(
    v => v.Kind == DateTimeKind.Utc ? v : v.ToUniversalTime(),
    v => DateTime.SpecifyKind(v, DateTimeKind.Utc));

/// <summary>
/// Runs on every connection open, in both processes:
/// busy_timeout lets a writer wait for the lock instead of failing at once;
/// synchronous=NORMAL is safe with WAL and much faster than FULL.
/// (journal_mode=WAL is persistent in the file and is set once by <see cref="DatabaseInitializer"/>.)
/// </summary>
public sealed class SqlitePragmaInterceptor : DbConnectionInterceptor
{
    private const string Pragmas = "PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;";

    public override void ConnectionOpened(DbConnection connection, ConnectionEndEventData eventData)
    {
        using var cmd = connection.CreateCommand();
        cmd.CommandText = Pragmas;
        cmd.ExecuteNonQuery();
    }

    public override async Task ConnectionOpenedAsync(
        DbConnection connection, ConnectionEndEventData eventData, CancellationToken cancellationToken = default)
    {
        await using var cmd = connection.CreateCommand();
        cmd.CommandText = Pragmas;
        await cmd.ExecuteNonQueryAsync(cancellationToken);
    }
}
