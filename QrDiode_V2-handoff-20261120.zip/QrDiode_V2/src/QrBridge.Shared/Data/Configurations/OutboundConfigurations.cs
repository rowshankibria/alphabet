using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Configurations;

public sealed class OutboxMessageConfiguration : IEntityTypeConfiguration<OutboxMessage>
{
    public void Configure(EntityTypeBuilder<OutboxMessage> b)
    {
        b.ToTable("Outbox", t =>
        {
            t.HasCheckConstraint("CK_Outbox_MessageType", SqlIn("MessageType", Enum.GetNames<MessageType>()));
            t.HasCheckConstraint("CK_Outbox_Direction", SqlIn("Direction", Enum.GetNames<Direction>()));
            t.HasCheckConstraint("CK_Outbox_PayloadFormat", SqlIn("PayloadFormat", Enum.GetNames<PayloadFormat>()));
            t.HasCheckConstraint("CK_Outbox_Status", SqlIn("Status", Enum.GetNames<OutboxStatus>()));
            t.HasCheckConstraint("CK_Outbox_ChunkCount", "ChunkCount > 0");
        });

        b.HasKey(x => x.Id);
        b.Property(x => x.Id).ValueGeneratedOnAdd();

        b.Property(x => x.MessageId).IsRequired();
        b.HasIndex(x => x.MessageId).IsUnique();

        b.Property(x => x.ServiceName).IsRequired().HasMaxLength(256);
        b.Property(x => x.Operation).IsRequired().HasMaxLength(256);
        b.Property(x => x.BusinessType).HasMaxLength(256);
        b.Property(x => x.KeyId).IsRequired().HasMaxLength(64);
        b.Property(x => x.LastError).HasMaxLength(2000);
        b.Property(x => x.Envelope).IsRequired();
        b.Property(x => x.EnvelopeHash).IsRequired().HasMaxLength(64);

        b.HasIndex(x => new { x.Status, x.Id }).HasDatabaseName("IX_Outbox_Status");
        b.HasIndex(x => x.CreatedUtc).HasDatabaseName("IX_Outbox_Created");
    }

    internal static string SqlIn(string column, IEnumerable<string> values) =>
        $"{column} IN ({string.Join(",", values.Select(v => $"'{v}'"))})";
}

public sealed class SequenceCounterConfiguration : IEntityTypeConfiguration<SequenceCounter>
{
    public void Configure(EntityTypeBuilder<SequenceCounter> b)
    {
        b.ToTable("SequenceCounter", t =>
            t.HasCheckConstraint("CK_SequenceCounter_Direction",
                OutboxMessageConfiguration.SqlIn("Direction", Enum.GetNames<Direction>())));

        b.HasKey(x => x.Direction);

        // One row per direction, created with the database
        b.HasData(
            new SequenceCounter { Direction = Direction.CorpToDmz, LastValue = 0 },
            new SequenceCounter { Direction = Direction.DmzToCorp, LastValue = 0 });
    }
}
