using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using QrBridge.Shared.Data.Entities;
using static QrBridge.Shared.Data.Configurations.OutboxMessageConfiguration;

namespace QrBridge.Shared.Data.Configurations;

public sealed class InboxMessageConfiguration : IEntityTypeConfiguration<InboxMessage>
{
    public void Configure(EntityTypeBuilder<InboxMessage> b)
    {
        b.ToTable("Inbox", t =>
        {
            t.HasCheckConstraint("CK_Inbox_MessageType", SqlIn("MessageType", Enum.GetNames<MessageType>()));
            t.HasCheckConstraint("CK_Inbox_Direction", SqlIn("Direction", Enum.GetNames<Direction>()));
            t.HasCheckConstraint("CK_Inbox_PayloadFormat", SqlIn("PayloadFormat", Enum.GetNames<PayloadFormat>()));
            t.HasCheckConstraint("CK_Inbox_Status", SqlIn("Status", Enum.GetNames<InboxStatus>()));
            t.HasCheckConstraint("CK_Inbox_ChunkCount", "ChunkCount > 0");
        });

        b.HasKey(x => x.Id);
        b.Property(x => x.Id).ValueGeneratedOnAdd();

        b.Property(x => x.MessageId).IsRequired();
        b.HasIndex(x => x.MessageId).IsUnique(); // duplicate messages rejected

        b.Property(x => x.ServiceName).IsRequired().HasMaxLength(256);
        b.Property(x => x.Operation).IsRequired().HasMaxLength(256);
        b.Property(x => x.BusinessType).HasMaxLength(256);
        b.Property(x => x.KeyId).IsRequired().HasMaxLength(64);
        b.Property(x => x.Envelope).IsRequired();
        b.Property(x => x.EnvelopeHash).IsRequired().HasMaxLength(64);
        b.Property(x => x.LastError).HasMaxLength(2000);
        b.Property(x => x.DownstreamResult).HasMaxLength(4000);

        b.HasIndex(x => new { x.Status, x.Id }).HasDatabaseName("IX_Inbox_Status");
        b.HasIndex(x => new { x.Direction, x.Sequence }).HasDatabaseName("IX_Inbox_Sequence");
    }
}

public sealed class HeartbeatConfiguration : IEntityTypeConfiguration<Heartbeat>
{
    public void Configure(EntityTypeBuilder<Heartbeat> b)
    {
        b.ToTable("Heartbeat");
        b.HasKey(x => x.Component);
        b.Property(x => x.Component).HasMaxLength(64);
        b.Property(x => x.Info).HasMaxLength(1024);
    }
}

public sealed class InboxPayloadDebugConfiguration : IEntityTypeConfiguration<InboxPayloadDebug>
{
    public void Configure(EntityTypeBuilder<InboxPayloadDebug> b)
    {
        b.ToTable("InboxPayloadDebug");
        b.HasKey(x => x.MessageId);
        b.Property(x => x.PayloadText).IsRequired();
    }
}
