namespace QrBridge.Shared.Data.Entities;

// ===================================================================
// outbound.db
// ===================================================================

/// <summary>A message waiting to cross (or crossing) the air gap. Written by the Gateway, aired by the QR sender.</summary>
public class OutboxMessage
{
    public long Id { get; set; }
    public Guid MessageId { get; set; }
    public Guid? CorrelationId { get; set; }
    public MessageType MessageType { get; set; }
    public Direction Direction { get; set; }
    public string ServiceName { get; set; } = "";
    public string Operation { get; set; } = "";
    /// <summary>Operator label from the payload (FMS MESSAGE/@TYPE or root element). Copied from the envelope header.</summary>
    public string? BusinessType { get; set; }
    public long Sequence { get; set; }
    public PayloadFormat PayloadFormat { get; set; }
    public string KeyId { get; set; } = "";
    /// <summary>Payload bytes before compression/encryption (monitoring only).</summary>
    public int PayloadSize { get; set; }
    /// <summary>Sealed bytes: header + nonce + tag + ciphertext. Immutable after insert.</summary>
    public byte[] Envelope { get; set; } = [];
    public string EnvelopeHash { get; set; } = "";
    /// <summary>QR frames per loop for this message (filled by the QR sender; 1 until then).</summary>
    public int ChunkCount { get; set; } = 1;
    public OutboxStatus Status { get; set; } = OutboxStatus.Pending;
    public int Attempts { get; set; }
    public DateTime CreatedUtc { get; set; }
    /// <summary>When the QR sender claimed it.</summary>
    public DateTime? LockedUtc { get; set; }
    /// <summary>Earliest time the sender may pick it up again after a release.</summary>
    public DateTime? NextAttemptUtc { get; set; }
    public DateTime? AckedUtc { get; set; }
    public string? LastError { get; set; }
}

/// <summary>One row per direction; source of per-direction Sequence numbers.</summary>
public class SequenceCounter
{
    public Direction Direction { get; set; }
    public long LastValue { get; set; }
}

// ===================================================================
// inbound.db
// ===================================================================

/// <summary>A complete message from the other side. Written by the QR receiver, processed by the Gateway worker.</summary>
public class InboxMessage
{
    public long Id { get; set; }
    public Guid MessageId { get; set; }
    public Guid? CorrelationId { get; set; }
    public MessageType MessageType { get; set; }
    public Direction Direction { get; set; }
    public string ServiceName { get; set; } = "";
    public string Operation { get; set; } = "";
    /// <summary>Operator label from the envelope header (unauthenticated until the worker opens the envelope).</summary>
    public string? BusinessType { get; set; }
    public long Sequence { get; set; }
    public PayloadFormat PayloadFormat { get; set; }
    public string KeyId { get; set; } = "";
    /// <summary>Same sealed bytes as the sender's Outbox row. Still encrypted.</summary>
    public byte[] Envelope { get; set; } = [];
    public string EnvelopeHash { get; set; } = "";
    /// <summary>QR frames per loop of the session that carried it (monitoring only).</summary>
    public int ChunkCount { get; set; } = 1;
    /// <summary>True once the Gateway has decrypted and authenticated it.</summary>
    public bool Verified { get; set; }
    public InboxStatus Status { get; set; } = InboxStatus.Pending;
    public int Attempts { get; set; }
    /// <summary>From the header: when the sender created it.</summary>
    public DateTime CreatedUtc { get; set; }
    /// <summary>When the QR receiver stored it.</summary>
    public DateTime ReceivedUtc { get; set; }
    public DateTime? LockedUtc { get; set; }
    /// <summary>Earliest retry time after a transient failure (backoff).</summary>
    public DateTime? NextAttemptUtc { get; set; }
    public DateTime? ProcessedUtc { get; set; }
    public string? LastError { get; set; }
    /// <summary>
    /// What the real service answered (e.g. its RETURN_CODE and ERROR_MESSAGE), so an operator can see
    /// why a message was refused. Never the request payload.
    /// </summary>
    public string? DownstreamResult { get; set; }
}

/// <summary>Liveness of each component, shown in the QR apps and /health.</summary>
public class Heartbeat
{
    public string Component { get; set; } = "";
    public DateTime LastSeenUtc { get; set; }
    public string? Info { get; set; }
}

/// <summary>OPTIONAL troubleshooting table: decrypted payload in plain text. Off by default.</summary>
public class InboxPayloadDebug
{
    public Guid MessageId { get; set; }
    public string PayloadText { get; set; } = "";
    public DateTime CreatedUtc { get; set; }
}
