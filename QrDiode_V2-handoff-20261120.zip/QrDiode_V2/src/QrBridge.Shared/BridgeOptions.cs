namespace QrBridge.Shared;

/// <summary>
/// Settings shared by the Gateway and the QrDiode apps. Bound from the "Bridge" section of appsettings.json.
/// Both apps on the same machine MUST use the same Side and DataFolder.
/// </summary>
public sealed class BridgeOptions
{
    public const string SectionName = "Bridge";

    /// <summary>Corp or Dmz.</summary>
    public BridgeSide Side { get; set; } = BridgeSide.Corp;

    /// <summary>Folder holding outbound.db and inbound.db. Local disk only — never a network share.</summary>
    public string DataFolder { get; set; } = @"C:\ProgramData\QrBridge\Data";

    /// <summary>
    /// Largest message payload (before compression) the bridge accepts or decodes. For the gateway this
    /// bounds the caller's SOAP request: anything bigger is refused before it is queued.
    /// </summary>
    public int MaxPayloadBytes { get; set; } = 1_000_000;

    public Direction OutboundDirection => Side.Outbound();
    public Direction InboundDirection => Side.Inbound();

    public string OutboundDbPath => Path.Combine(DataFolder, "outbound.db");
    public string InboundDbPath => Path.Combine(DataFolder, "inbound.db");
}
