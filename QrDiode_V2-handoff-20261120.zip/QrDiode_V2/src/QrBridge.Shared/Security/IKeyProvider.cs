namespace QrBridge.Shared.Security;

/// <summary>Supplies 32-byte AES-256 keys by id.</summary>
public interface IKeyProvider
{
    /// <summary>Returns the key, or throws <see cref="KeyNotFoundException"/> if unknown.</summary>
    byte[] GetKey(string keyId);
}

/// <summary>For tests and local experiments only. Never use in production.</summary>
public sealed class InMemoryKeyProvider : IKeyProvider
{
    private readonly Dictionary<string, byte[]> _keys = new(StringComparer.Ordinal);

    public InMemoryKeyProvider Add(string keyId, byte[] key)
    {
        if (key.Length != 32) throw new ArgumentException("Key must be 32 bytes (AES-256).");
        _keys[keyId] = key;
        return this;
    }

    public byte[] GetKey(string keyId) =>
        _keys.TryGetValue(keyId, out var key) ? key : throw new KeyNotFoundException($"Unknown key '{keyId}'.");
}
