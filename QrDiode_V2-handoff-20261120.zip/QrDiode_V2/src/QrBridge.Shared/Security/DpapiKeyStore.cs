using System.Collections.Concurrent;
using System.Runtime.Versioning;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace QrBridge.Shared.Security;

/// <summary>
/// Keys stored on disk as "{keyId}.key", protected with Windows DPAPI (LocalMachine scope).
///
/// - DPAPI ties the file to this machine: a copied .key file is useless elsewhere.
/// - LocalMachine scope means any process on the machine *could* unprotect it, so lock the
///   key folder with NTFS ACLs to the Gateway app pool identity + Administrators only.
/// - The QR apps (WPF) never need these keys.
///
/// Key ids arrive inside envelope headers from the other network, so they are validated
/// strictly before being used to build a file path (no path traversal).
/// </summary>
[SupportedOSPlatform("windows")]
public sealed partial class DpapiKeyStore : IKeyProvider
{
    // Extra entropy mixed into DPAPI so other apps using DPAPI can't trivially unprotect our files.
    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("QrBridge.KeyStore.v1");

    private readonly string _folder;
    private readonly ConcurrentDictionary<string, byte[]> _cache = new(StringComparer.Ordinal);

    public DpapiKeyStore(string folder) => _folder = folder;

    [GeneratedRegex("^[A-Za-z0-9_-]{1,64}$")]
    private static partial Regex KeyIdPattern();

    public static bool IsValidKeyId(string keyId) => KeyIdPattern().IsMatch(keyId);

    public byte[] GetKey(string keyId)
    {
        if (!IsValidKeyId(keyId)) throw new KeyNotFoundException($"Invalid key id '{keyId}'.");
        return _cache.GetOrAdd(keyId, Load);
    }

    private byte[] Load(string keyId)
    {
        string path = PathFor(keyId);
        if (!File.Exists(path)) throw new KeyNotFoundException($"Key '{keyId}' not found in {_folder}.");

        byte[] key = ProtectedData.Unprotect(File.ReadAllBytes(path), Entropy, DataProtectionScope.LocalMachine);
        if (key.Length != 32) throw new CryptographicException($"Key '{keyId}' is not 32 bytes.");
        return key;
    }

    /// <summary>Writes a key to disk, DPAPI-protected. Used by the key tool.</summary>
    public void Save(string keyId, byte[] key, bool overwrite = false)
    {
        if (!IsValidKeyId(keyId)) throw new ArgumentException($"Invalid key id '{keyId}'. Use letters, digits, '-' or '_'.");
        if (key.Length != 32) throw new ArgumentException("Key must be 32 bytes (AES-256).");

        Directory.CreateDirectory(_folder);
        string path = PathFor(keyId);
        if (File.Exists(path) && !overwrite) throw new IOException($"Key file already exists: {path}");

        File.WriteAllBytes(path, ProtectedData.Protect(key, Entropy, DataProtectionScope.LocalMachine));
        _cache[keyId] = key;
    }

    public IEnumerable<string> ListKeyIds() =>
        Directory.Exists(_folder)
            ? Directory.EnumerateFiles(_folder, "*.key").Select(Path.GetFileNameWithoutExtension).OfType<string>()
            : [];

    private string PathFor(string keyId) => Path.Combine(_folder, keyId + ".key");
}
