using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;

namespace QrBridge.Shared.Serialization;

/// <summary>
/// Turns a message (its <see cref="MessageHeader"/> + the caller's SOAP body) into one byte array, and back.
/// These bytes are what the Outbox and Inbox tables of qrbridge.db store and what the QR link carries.
///
/// Byte format (integers little-endian):
///   magic      uint32   "BRG7"
///   headerLen  int32
///   header     bytes    MessageHeader, binary (readable without unpacking: see PeekHeader)
///   checksum   32 bytes SHA-256 over header + body
///   bodyLen    int32
///   body       bytes    the caller's SOAP body (Request) or the real service's answer (Reply), exactly as received,
///                       Brotli-compressed when the header says so; empty for a Receipt and a Heartbeat
///
/// The header's version-4 fields (Kind … CallerHost) come after the version-3 fields, the version-5 fields
/// (Outcome, ServiceHttpStatus, ServiceComment) after those, and the version-6 Priority last, so every earlier offset
/// is unchanged. Version 7 adds no field: Kind may be Heartbeat. Older formats are refused, never half-read.
///
/// The bytes are NOT encrypted: confidentiality and authenticity across the air gap come from QrDiode's session
/// encryption. The checksum only detects corruption; it does not stop deliberate tampering.
/// </summary>
public sealed class MessageSerializer
{
    private const uint Magic = 0x37475242; // "BRG7"
    private const uint Version6Magic = 0x36475242; // "BRG6", before 25 Nov 2026 (V6 review fix, step 17)
    private const uint Version5Magic = 0x35475242; // "BRG5", before 25 Nov 2026 (V6 review fix, step 14)
    private const uint Version4Magic = 0x34475242; // "BRG4", before 24 Nov 2026 (V6 review fix, step 9b)
    private const uint Version3Magic = 0x33475242; // "BRG3", before 24 Nov 2026 (V6 review fix, step 4)
    private const int ChecksumSize = 32;
    private const int FingerprintSize = 32; // SHA-256
    private const int MaxHeaderBytes = 64 * 1024;
    private const int MaxStringLength = 256;
    private const int MaxHttpFieldLength = 4096; // Path, SOAPAction, Content-Type
    public const int MaxServiceCommentLength = 1024;

    private readonly int _maxPayloadBytes;

    public MessageSerializer(int maxPayloadBytes = 1_000_000) => _maxPayloadBytes = maxPayloadBytes;

    public byte[] Serialize(MessageHeader header, ReadOnlySpan<byte> body)
    {
        if (body.Length > _maxPayloadBytes)
            throw new ArgumentException($"Body {body.Length} bytes exceeds limit {_maxPayloadBytes}.");
        if (header.PayloadFormat == PayloadFormat.HttpGet && body.Length > 0)
            throw new InvalidDataException("An HTTP GET Request has no body.");
        if (header.Kind == MessageKind.Heartbeat && body.Length > 0)
            throw new InvalidDataException("A Heartbeat has no body.");

        byte[] headerBytes = WriteHeader(header);
        byte[] packed = header.Compression == Compression.Brotli ? Compress(body) : body.ToArray();

        using var ms = new MemoryStream();
        using (var w = new BinaryWriter(ms, Encoding.UTF8, leaveOpen: true))
        {
            w.Write(Magic);
            w.Write(headerBytes.Length);
            w.Write(headerBytes);
            w.Write(Checksum(headerBytes, packed));
            w.Write(packed.Length);
            w.Write(packed);
        }
        return ms.ToArray();
    }

    /// <summary>
    /// Reads the header without checking the checksum or unpacking the body. Used by the QR receiver to fill
    /// the Inbox columns; the Gateway checks everything on Deserialize.
    /// </summary>
    public static MessageHeader PeekHeader(byte[] messageBytes)
    {
        using var r = new BinaryReader(new MemoryStream(messageBytes, writable: false));
        ReadMagic(r);
        return ReadHeader(ReadExact(r, ReadLength(r, MaxHeaderBytes)));
    }

    /// <summary>Checks and unpacks. Throws <see cref="InvalidDataException"/> if the bytes are corrupt.</summary>
    public (MessageHeader Header, byte[] Body) Deserialize(byte[] messageBytes)
    {
        using var r = new BinaryReader(new MemoryStream(messageBytes, writable: false));
        ReadMagic(r);

        byte[] headerBytes = ReadExact(r, ReadLength(r, MaxHeaderBytes));
        MessageHeader header = ReadHeader(headerBytes);

        byte[] checksum = ReadExact(r, ChecksumSize);
        byte[] body = ReadExact(r, ReadLength(r, _maxPayloadBytes + 1024));

        if (r.BaseStream.Position != r.BaseStream.Length)
            throw new InvalidDataException("Trailing bytes after the message.");

        if (!CryptographicOperations.FixedTimeEquals(checksum, Checksum(headerBytes, body)))
            throw new InvalidDataException("Message checksum mismatch (corrupted).");

        byte[] payload = header.Compression == Compression.Brotli ? Decompress(body) : body;
        if (header.PayloadFormat == PayloadFormat.HttpGet && payload.Length > 0)
            throw new InvalidDataException("An HTTP GET Request has no body.");
        if (header.Kind == MessageKind.Heartbeat && payload.Length > 0)
            throw new InvalidDataException("A Heartbeat has no body.");
        return (header, payload);
    }

    private static byte[] Checksum(byte[] headerBytes, byte[] body)
    {
        using var sha = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        sha.AppendData(headerBytes);
        sha.AppendData(body);
        return sha.GetHashAndReset();
    }

    // ---------------- header ----------------

    private static byte[] WriteHeader(MessageHeader h)
    {
        if (h.MessageId == Guid.Empty) throw new ArgumentException("Header MessageId is not set.");
        if (!Enum.IsDefined(h.Direction)) throw new ArgumentException("Header Direction is not set.");
        if (!Enum.IsDefined(h.Kind)) throw new ArgumentException("Header Kind is not set.");
        CheckString(h.ServiceName, nameof(h.ServiceName));
        CheckString(h.Operation, nameof(h.Operation));
        CheckOptionalString(h.BusinessType, nameof(h.BusinessType));
        CheckHttpField(h.Path, nameof(h.Path));
        CheckHttpField(h.ContentType, nameof(h.ContentType));
        if (h.SoapActionHeader is { Length: > MaxHttpFieldLength })
            throw new InvalidDataException("Header field SoapActionHeader is too long.");
        byte[]? contentFingerprint = FingerprintBytes(h.ContentFingerprint, nameof(h.ContentFingerprint));
        byte[]? catalogFingerprint = FingerprintBytes(h.CatalogFingerprint, nameof(h.CatalogFingerprint));
        CheckCallerHost(h.CallerHost);
        CheckServiceComment(h.ServiceComment);
        CheckConsistency(h);

        using var ms = new MemoryStream();
        using (var w = new BinaryWriter(ms, Encoding.UTF8, leaveOpen: true))
        {
            w.Write(h.Version);
            w.Write((byte)h.Direction);
            w.Write((byte)h.PayloadFormat);
            w.Write((byte)h.Compression);
            w.Write(h.MessageId.ToByteArray());
            w.Write(h.Sequence);
            w.Write(h.CreatedUtc.ToUniversalTime().Ticks);
            w.Write(h.ServiceName);
            w.Write(h.Operation);
            w.Write(h.BusinessType);
            w.Write(h.Path);
            w.Write(h.SoapActionHeader is not null);
            w.Write(h.SoapActionHeader ?? "");
            w.Write(h.ContentType);

            // Version 4. Optional values: a presence byte, then the value only when present.
            w.Write((byte)h.Kind);
            WriteOptional(w, h.CorrelationId?.ToByteArray());
            WriteOptional(w, contentFingerprint);
            w.Write(h.ExpiresUtc is not null);
            if (h.ExpiresUtc is { } expires) w.Write(expires.ToUniversalTime().Ticks);
            w.Write(h.SequenceRunId.ToByteArray());
            WriteOptional(w, catalogFingerprint);
            w.Write(h.CallerHost is not null);
            if (h.CallerHost is not null) w.Write(h.CallerHost);

            // Version 5 (decision D43): what a Reply says the far side did.
            w.Write(h.Outcome is not null);
            if (h.Outcome is { } outcome) w.Write((byte)outcome);
            w.Write(h.ServiceHttpStatus is not null);
            if (h.ServiceHttpStatus is { } status) w.Write((short)status);
            w.Write(h.ServiceComment is not null);
            if (h.ServiceComment is not null) w.Write(h.ServiceComment);

            // Version 6 (decision D73): which messages go first.
            w.Write((byte)h.Priority);
        }
        return ms.ToArray();
    }

    private static MessageHeader ReadHeader(byte[] bytes)
    {
        using var r = new BinaryReader(new MemoryStream(bytes, writable: false), Encoding.UTF8);

        byte version = r.ReadByte();
        if (version != MessageHeader.CurrentVersion)
            throw new InvalidDataException($"Unsupported message format version {version}.");

        var header = new MessageHeader
        {
            Version = version,
            Direction = CheckEnum<Direction>(r.ReadByte()),
            PayloadFormat = CheckEnum<PayloadFormat>(r.ReadByte()),
            Compression = CheckEnum<Compression>(r.ReadByte()),
            MessageId = new Guid(ReadExact(r, 16)),
            Sequence = r.ReadInt64(),
            CreatedUtc = ReadTicks(r.ReadInt64()),
            ServiceName = CheckString(r.ReadString(), "ServiceName"),
            Operation = CheckString(r.ReadString(), "Operation"),
            BusinessType = CheckOptionalString(r.ReadString(), "BusinessType"),
            Path = CheckHttpField(r.ReadString(), "Path"),
            SoapActionHeader = ReadOptionalHttpField(r, "SoapActionHeader"),
            ContentType = CheckHttpField(r.ReadString(), "ContentType"),
            Kind = CheckEnum<MessageKind>(r.ReadByte()),
            CorrelationId = ReadOptional(r, 16) is { } correlation ? new Guid(correlation) : null,
            ContentFingerprint = ReadOptional(r, FingerprintSize) is { } content ? Convert.ToHexStringLower(content) : null,
            ExpiresUtc = ReadPresence(r) ? ReadTicks(r.ReadInt64()) : null,
            SequenceRunId = new Guid(ReadExact(r, 16)),
            CatalogFingerprint = ReadOptional(r, FingerprintSize) is { } catalog ? Convert.ToHexStringLower(catalog) : null,
            CallerHost = ReadPresence(r) ? CheckCallerHost(r.ReadString()) : null,
            Outcome = ReadPresence(r) ? CheckEnum<ServiceOutcome>(r.ReadByte()) : null,
            ServiceHttpStatus = ReadPresence(r) ? r.ReadInt16() : null,
            ServiceComment = ReadPresence(r) ? CheckServiceComment(r.ReadString()) : null,
            Priority = CheckEnum<MessagePriority>(r.ReadByte()),
        };

        if (r.BaseStream.Position != r.BaseStream.Length)
            throw new InvalidDataException("Trailing bytes in header.");
        CheckConsistency(header);
        return header;
    }

    /// <summary>
    /// Rules that link fields: a Request carries the HTTP details to replay it and names no other message; a Receipt
    /// and a Reply name the message they are about; a Heartbeat names nothing and goes first; only a Reply carries an
    /// outcome (required there); expiry after creation.
    /// </summary>
    private static void CheckConsistency(MessageHeader h)
    {
        if (h.Kind == MessageKind.Request)
        {
            if (h.CorrelationId is not null)
                throw new InvalidDataException("A Request carries no CorrelationId.");
            if (string.IsNullOrWhiteSpace(h.Path))
                throw new InvalidDataException("A Request must carry the Path to replay it.");
            if (h.PayloadFormat == PayloadFormat.HttpGet)
            {
                if (h.ContentType.Length > 0 || h.SoapActionHeader is not null)
                    throw new InvalidDataException("An HTTP GET Request carries no Content-Type or SOAPAction.");
            }
            else if (string.IsNullOrWhiteSpace(h.ContentType))
            {
                throw new InvalidDataException("A Request must carry the Path and Content-Type to replay it.");
            }
        }
        else if (h.PayloadFormat != PayloadFormat.RawSoap)
        {
            throw new InvalidDataException($"A {h.Kind} is never an HTTP GET.");
        }
        else if (h.Kind == MessageKind.Heartbeat)
        {
            if (h.CorrelationId is not null || h.ContentFingerprint is not null || h.ExpiresUtc is not null || h.Priority != MessagePriority.Answer)
                throw new InvalidDataException("A Heartbeat names no message, carries no content fingerprint or expiry, and has priority Answer.");
        }
        else if ((h.CorrelationId ?? Guid.Empty) == Guid.Empty)
        {
            throw new InvalidDataException($"A {h.Kind} must carry the CorrelationId of the message it is about.");
        }

        if (h.Kind == MessageKind.Reply && h.Outcome is null)
            throw new InvalidDataException("A Reply must carry the Outcome.");
        if (!Enum.IsDefined(h.Priority) || (h.Kind == MessageKind.Request && h.Priority == MessagePriority.Answer))
            throw new InvalidDataException("Header Priority is not valid (a Request is High, Normal or Low; Answer is for Receipts, Replies and Heartbeats).");
        if (h.Kind != MessageKind.Reply && (h.Outcome is not null || h.ServiceHttpStatus is not null || h.ServiceComment is not null))
            throw new InvalidDataException($"A {h.Kind} carries no Outcome, ServiceHttpStatus or ServiceComment.");
        if (h.Outcome is { } outcome && !Enum.IsDefined(outcome))
            throw new InvalidDataException("Header Outcome is not valid.");
        if (h.ServiceHttpStatus is < 100 or > 599)
            throw new InvalidDataException("Header ServiceHttpStatus must be an HTTP status (100-599).");
        if (h.ExpiresUtc is { } expires && expires.ToUniversalTime() <= h.CreatedUtc.ToUniversalTime())
            throw new InvalidDataException("Header ExpiresUtc must be after CreatedUtc.");
    }

    /// <summary>Lower-case hex SHA-256 (64 characters) → 32 bytes; null stays null.</summary>
    private static byte[]? FingerprintBytes(string? hex, string name)
    {
        if (hex is null) return null;
        if (hex.Length != FingerprintSize * 2 || hex.Any(c => c is not (>= '0' and <= '9' or >= 'a' and <= 'f')))
            throw new InvalidDataException($"Header field {name} must be a lower-case hex SHA-256.");
        return Convert.FromHexString(hex);
    }

    /// <summary>Bounded, and no control characters: it is written to logs.</summary>
    private static string? CheckCallerHost(string? value) =>
        value is null || (value.Length is > 0 and <= MaxStringLength && !value.Any(char.IsControl))
            ? value
            : throw new InvalidDataException("Header field CallerHost is empty, too long or has control characters.");

    /// <summary>Bounded, and no control characters: it is shown to operators and written to logs.</summary>
    private static string? CheckServiceComment(string? value) =>
        value is null || (value.Length <= MaxServiceCommentLength && !value.Any(char.IsControl))
            ? value
            : throw new InvalidDataException($"Header field ServiceComment is longer than {MaxServiceCommentLength} characters or has control characters.");

    /// <summary>May be empty (a Receipt has no path or Content-Type); bounded. A Request's are required: CheckConsistency.</summary>
    private static string CheckHttpField(string? value, string name) =>
        value is not null && value.Length <= MaxHttpFieldLength
            ? value
            : throw new InvalidDataException($"Header field {name} is missing or too long.");

    private static void WriteOptional(BinaryWriter w, byte[]? value)
    {
        w.Write(value is not null);
        if (value is not null) w.Write(value);
    }

    private static byte[]? ReadOptional(BinaryReader r, int size) => ReadPresence(r) ? ReadExact(r, size) : null;

    private static bool ReadPresence(BinaryReader r) => r.ReadByte() switch
    {
        0 => false,
        1 => true,
        var b => throw new InvalidDataException($"Invalid presence flag {b} in header."),
    };

    private static DateTime ReadTicks(long ticks) =>
        ticks is >= 0 and <= 3155378975999999999 // DateTime.MaxValue.Ticks
            ? new DateTime(ticks, DateTimeKind.Utc)
            : throw new InvalidDataException("Invalid timestamp.");

    private static T CheckEnum<T>(byte value) where T : struct, Enum
    {
        var e = (T)Enum.ToObject(typeof(T), value);
        return Enum.IsDefined(e) ? e : throw new InvalidDataException($"Invalid {typeof(T).Name} value {value}.");
    }

    private static string CheckString(string value, string name, int maxLength = MaxStringLength) =>
        !string.IsNullOrWhiteSpace(value) && value.Length <= maxLength
            ? value
            : throw new InvalidDataException($"Header field {name} is empty or too long.");

    private static string? ReadOptionalHttpField(BinaryReader r, string name)
    {
        bool present = r.ReadBoolean();
        string value = r.ReadString();
        if (!present) return value.Length == 0 ? null : throw new InvalidDataException($"Header field {name} is malformed.");
        return value.Length <= MaxHttpFieldLength ? value : throw new InvalidDataException($"Header field {name} is too long.");
    }

    private static string CheckOptionalString(string? value, string name) =>
        value is null ? throw new InvalidDataException($"Header field {name} is missing.")
        : value.Length <= MaxStringLength ? value
        : throw new InvalidDataException($"Header field {name} is too long.");

    // ---------------- compression ----------------

    private static byte[] Compress(ReadOnlySpan<byte> data)
    {
        using var output = new MemoryStream();
        using (var brotli = new BrotliStream(output, CompressionLevel.SmallestSize, leaveOpen: true))
            brotli.Write(data);
        return output.ToArray();
    }

    /// <summary>Decompresses with a hard size cap so a hostile "zip bomb" can't exhaust memory.</summary>
    private byte[] Decompress(byte[] data)
    {
        using var input = new BrotliStream(new MemoryStream(data, writable: false), CompressionMode.Decompress);
        using var output = new MemoryStream();
        var buffer = new byte[81920];
        int read;
        while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
        {
            if (output.Length + read > _maxPayloadBytes)
                throw new InvalidDataException("Decompressed payload exceeds limit.");
            output.Write(buffer, 0, read);
        }
        return output.ToArray();
    }

    // ---------------- helpers ----------------

    private static void ReadMagic(BinaryReader r)
    {
        uint magic = r.BaseStream.Length < 4 ? 0 : r.ReadUInt32();
        if (magic is Version3Magic or Version4Magic or Version5Magic or Version6Magic)
        {
            string old = magic switch { Version3Magic => "BRG3", Version4Magic => "BRG4", Version5Magic => "BRG5", _ => "BRG6" };
            throw new InvalidDataException(
                $"Message in a previous format {old} (before header version {MessageHeader.CurrentVersion}): not supported. Delete old dev databases.");
        }
        if (magic != Magic)
            throw new InvalidDataException("Not a bridge message.");
    }

    private static int ReadLength(BinaryReader r, int max)
    {
        int len = r.ReadInt32();
        if (len < 0 || len > max) throw new InvalidDataException($"Invalid length {len}.");
        return len;
    }

    private static byte[] ReadExact(BinaryReader r, int count)
    {
        byte[] b = r.ReadBytes(count);
        if (b.Length != count) throw new InvalidDataException("Message truncated.");
        return b;
    }
}
