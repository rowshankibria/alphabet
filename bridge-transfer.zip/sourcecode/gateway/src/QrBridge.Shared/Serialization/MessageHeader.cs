namespace QrBridge.Shared.Serialization;

/// <summary>
/// Everything about a message except its SOAP body: who it is for (service, operation, direction), its id and
/// sequence, and the HTTP details the other side needs to replay the call byte for byte (path, SOAPAction,
/// Content-Type). Stored uncompressed in front of the body, so <see cref="MessageSerializer.PeekHeader"/> can read it
/// without unpacking. Covered by the checksum. Never put sensitive data here.
/// </summary>
public sealed record MessageHeader
{
    public const byte CurrentVersion = 7;

    /// <summary>ServiceName and Operation of a Heartbeat (decision D80): not a route, never looked up in the catalogue.</summary>
    public const string HeartbeatServiceName = "QrBridge";
    public const string HeartbeatOperation = "Heartbeat";

    public byte Version { get; init; } = CurrentVersion;

    /// <summary>Request (a caller's call), Receipt, Reply or Heartbeat. See <see cref="MessageKind"/>.</summary>
    public MessageKind Kind { get; init; } = MessageKind.Request;

    /// <summary>End-to-end id. Same value in the sender's Outbox and the receiver's Inbox. Set by OutboxWriter.</summary>
    public Guid MessageId { get; init; }

    /// <summary>Set by OutboxWriter from this side (Corp sends CorpToDmz, Dmz sends DmzToCorp).</summary>
    public Direction Direction { get; init; }

    /// <summary>Route service name from the gateway's catalogue (e.g. "FC2FMS"), or the request path for unlisted calls.</summary>
    public required string ServiceName { get; init; }

    /// <summary>SOAP operation, taken from the SOAP body element (e.g. "SendToFMS").</summary>
    public required string Operation { get; init; }

    /// <summary>
    /// What the caller's payload says it is, for operators: the FMS MESSAGE/@TYPE (e.g. "RETURN_ORDER")
    /// or the root element name of other payloads (e.g. "createTicketResponse"). Empty when unknown.
    /// It is a label, not data — callers decide nothing based on it.
    /// </summary>
    public string BusinessType { get; init; } = "";

    /// <summary>The path the caller used, e.g. "/FMS_FC2FMSInterface/FC2FMSInterface.svc". Required for a Request; empty for a Receipt.</summary>
    public required string Path { get; init; }

    /// <summary>The SOAPAction HTTP header exactly as received (quotes included); null when absent (SOAP 1.2).</summary>
    public string? SoapActionHeader { get; init; }

    /// <summary>
    /// Request: the Content-Type header exactly as received (carries the action for SOAP 1.2), required. Reply: the real
    /// service's answer's Content-Type, empty when there was no answer. Receipt: empty.
    /// </summary>
    public required string ContentType { get; init; }

    public PayloadFormat PayloadFormat { get; init; } = PayloadFormat.RawSoap;
    public Compression Compression { get; init; } = Compression.Brotli;

    /// <summary>Per-direction sequence number, for ordering and gap detection.</summary>
    public long Sequence { get; init; }

    public DateTime CreatedUtc { get; init; } = DateTime.UtcNow;

    // ----- Added in version 4 (V6 review fix): used by the round trip, re-airing and arrival checks. -----

    /// <summary>Reply: the MessageId of the request it answers (required). Receipt: the MessageId that arrived (required). Request: always null.</summary>
    public Guid? CorrelationId { get; init; }

    /// <summary>
    /// Lower-case hex SHA-256 of the business payload without the fields that change on every send: how a caller's
    /// retry is recognised (never MSG_ID or RRMsgID alone). Null when not computed.
    /// </summary>
    public string? ContentFingerprint { get; init; }

    /// <summary>After this time (sender's clock, UTC) the request is not delivered any more. Null = no expiry.</summary>
    public DateTime? ExpiresUtc { get; init; }

    /// <summary>
    /// Which run of the sending gateway's sequence counter <see cref="Sequence"/> belongs to. A new run starts whenever
    /// the counter starts again at 1: a new or deleted qrbridge.db. (A qrbridge.db restored from a backup keeps the run it
    /// had.)
    /// Why: the receiving gateway finds lost messages by looking for missing numbers. Example: it has numbers 1–40 of
    /// run A when the DMZ machine is rebuilt, and the next messages are 1, 2, 3 of run B. Without the run id, "1" would
    /// look like a duplicate and 41… like a gap that never fills. With it, run A ends at 40 and run B starts at 1.
    /// Set by OutboxWriter from SequenceCounter.RunId; Guid.Empty = unknown.
    /// </summary>
    public Guid SequenceRunId { get; init; }

    /// <summary>Lower-case hex SHA-256 of the sender's route catalogue, so the receiver can refuse a mismatch. Null when not set.</summary>
    public string? CatalogFingerprint { get; init; }

    /// <summary>The original caller's address (as the load balancer forwards it), for operators. Not business data. Null when unknown.</summary>
    public string? CallerHost { get; init; }

    // ----- Added in version 5 (V6 review fix, step 9b, decision D43): a Reply says what the far side did. -----

    /// <summary>Reply only (required there): what happened to the request on the far side.</summary>
    public ServiceOutcome? Outcome { get; init; }

    /// <summary>Reply only: the real service's HTTP status (100–599); null when there was no HTTP answer.</summary>
    public int? ServiceHttpStatus { get; init; }

    /// <summary>Reply only: the probable reason in plain words (≤ 1,024 characters, no control characters). Never the payload.</summary>
    public string? ServiceComment { get; init; }

    // ----- Added in version 6 (V6 review fix, step 14, decision D73): which messages go first. -----

    /// <summary>
    /// Receipt, Reply and Heartbeat: Answer (OutboxWriter sets it). Request: High, Normal or Low from the route
    /// (RouteTable), never Answer, so both the QR sender and the far side's delivery loops can order by it without the catalogue.
    /// </summary>
    public MessagePriority Priority { get; init; } = MessagePriority.Normal;

    // ----- Version 7 (V6 review fix, step 17, decision D80): Kind may be Heartbeat. No field added. -----
}