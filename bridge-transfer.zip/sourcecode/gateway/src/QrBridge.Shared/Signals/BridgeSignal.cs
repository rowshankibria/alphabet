using System.Runtime.Versioning;
using System.Security.AccessControl;
using System.Security.Principal;
using Microsoft.Extensions.Logging;

namespace QrBridge.Shared.Signals;

/// <summary>
/// A cross-process "doorbell" built on a named Windows event.
///
/// - The Global\ prefix is required: IIS (session 0) and the desktop app (session 1+) live in
///   different sessions and would not see each other's events otherwise.
/// - The event is created with an ACL that lets Authenticated Users, IIS_IUSRS, SYSTEM and
///   Administrators wait on it and signal it, so the app pool identity and the kiosk user can both use it.
/// - It is only a speed-up. Every waiter also wakes on a timeout and polls the database, so a
///   missed or failed signal can delay a message by at most one poll interval — never lose it.
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class BridgeSignal : IDisposable
{
    private const EventWaitHandleRights Rights = EventWaitHandleRights.Synchronize | EventWaitHandleRights.Modify;

    private readonly EventWaitHandle? _handle;
    private readonly ILogger _logger;
    private readonly string _name;

    public BridgeSignal(string name, ILogger logger)
    {
        _name = name;
        _logger = logger;
        _handle = OpenOrCreate(name);
    }

    public bool IsAvailable => _handle is not null;

    /// <summary>Wake the other process. Never throws.</summary>
    public void Set()
    {
        try { _handle?.Set(); }
        catch (Exception ex) { _logger.LogWarning(ex, "Could not signal {Signal}", _name); }
    }

    /// <summary>Waits until signalled or the timeout elapses (whichever first). Throws only on cancellation.</summary>
    public async Task WaitAsync(TimeSpan timeout, CancellationToken ct)
    {
        if (_handle is null)
        {
            await Task.Delay(timeout, ct);
            return;
        }

        var tcs = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        RegisteredWaitHandle registration = ThreadPool.RegisterWaitForSingleObject(
            _handle, (_, _) => tcs.TrySetResult(), null, timeout, executeOnlyOnce: true);
        try
        {
            await using (ct.Register(() => tcs.TrySetCanceled(ct)))
                await tcs.Task;
        }
        finally
        {
            registration.Unregister(null);
        }
    }

    private EventWaitHandle? OpenOrCreate(string name)
    {
        try
        {
            return EventWaitHandleAcl.Create(false, EventResetMode.AutoReset, name, out _, BuildSecurity());
        }
        catch (UnauthorizedAccessException)
        {
            // Already created by the other process with an ACL that doesn't let us "create"; just open it.
            if (EventWaitHandleAcl.TryOpenExisting(name, Rights, out var existing))
                return existing;
            _logger.LogWarning("Signal {Signal} exists but cannot be opened; falling back to polling only.", name);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Signal {Signal} unavailable; falling back to polling only.", name);
        }
        return null;
    }

    private static EventWaitHandleSecurity BuildSecurity()
    {
        var security = new EventWaitHandleSecurity();
        void Allow(SecurityIdentifier sid, EventWaitHandleRights rights) =>
            security.AddAccessRule(new EventWaitHandleAccessRule(sid, rights, AccessControlType.Allow));

        Allow(new SecurityIdentifier(WellKnownSidType.AuthenticatedUserSid, null), Rights);
        Allow(new SecurityIdentifier("S-1-5-32-568"), Rights); // IIS_IUSRS
        Allow(new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), EventWaitHandleRights.FullControl);
        Allow(new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null), EventWaitHandleRights.FullControl);
        return security;
    }

    public void Dispose() => _handle?.Dispose();
}
