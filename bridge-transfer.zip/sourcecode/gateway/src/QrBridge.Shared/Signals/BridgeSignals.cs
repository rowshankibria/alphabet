using System.Runtime.Versioning;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace QrBridge.Shared.Signals;

/// <summary>Both doorbells, registered once as a singleton in each app.</summary>
[SupportedOSPlatform("windows")]
public sealed class BridgeSignals : IDisposable
{
    public BridgeSignals(IOptions<BridgeOptions> options, ILoggerFactory loggerFactory)
    {
        var logger = loggerFactory.CreateLogger<BridgeSignals>();
        var side = options.Value.Side;
        Outbox = new BridgeSignal(SignalNames.Outbox(side), logger);
        Inbox = new BridgeSignal(SignalNames.Inbox(side), logger);
    }

    /// <summary>Rung by the Gateway after an Outbox insert; waited on by the QR sender.</summary>
    public BridgeSignal Outbox { get; }

    /// <summary>Rung by the QR receiver after an Inbox insert; waited on by the Gateway worker.</summary>
    public BridgeSignal Inbox { get; }

    public void Dispose()
    {
        Outbox.Dispose();
        Inbox.Dispose();
    }
}
