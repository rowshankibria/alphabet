using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace QrBridge.Shared.Data;

/// <summary>Design-time factory: used only by "dotnet ef migrations ..." for <see cref="BridgeDbContext"/>.</summary>
public sealed class BridgeDesignTimeFactory : IDesignTimeDbContextFactory<BridgeDbContext>
{
    public BridgeDbContext CreateDbContext(string[] args)
    {
        var o = new DbContextOptionsBuilder<BridgeDbContext>();
        DatabaseSetup.Configure(o, Path.Combine(Path.GetTempPath(), "qrbridge-design.db"));
        return new BridgeDbContext(o.Options);
    }
}
