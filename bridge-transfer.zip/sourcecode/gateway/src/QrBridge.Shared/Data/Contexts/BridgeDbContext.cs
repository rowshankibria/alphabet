using Microsoft.EntityFrameworkCore;
using QrBridge.Shared.Data.Configurations;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data;

/// <summary>
/// qrbridge.db — the one bridge database on each machine, shared by the Gateway and the QR apps through the data folder.
/// Outbox and SequenceCounter: what this side sends (the Gateway writes, the QR sender airs). Inbox: what arrived from the
/// other side (the QR receiver writes, the Gateway delivers or uses it). Heartbeat, AcknowledgedGap and
/// SequenceWatermark: liveness, gaps an operator has dealt with, and how far each run of the other side's counter is
/// complete.
/// </summary>
public sealed class BridgeDbContext(DbContextOptions<BridgeDbContext> options) : DbContext(options)
{
    public DbSet<OutboxMessage> Outbox => Set<OutboxMessage>();
    public DbSet<SequenceCounter> SequenceCounters => Set<SequenceCounter>();
    public DbSet<InboxMessage> Inbox => Set<InboxMessage>();
    public DbSet<Heartbeat> Heartbeats => Set<Heartbeat>();
    public DbSet<AcknowledgedGap> AcknowledgedGaps => Set<AcknowledgedGap>();
    public DbSet<SequenceWatermark> SequenceWatermarks => Set<SequenceWatermark>();

    protected override void ConfigureConventions(ModelConfigurationBuilder builder) =>
        SqliteConventions.Apply(builder);

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfiguration(new OutboxMessageConfiguration());
        modelBuilder.ApplyConfiguration(new SequenceCounterConfiguration());
        modelBuilder.ApplyConfiguration(new InboxMessageConfiguration());
        modelBuilder.ApplyConfiguration(new HeartbeatConfiguration());
        modelBuilder.ApplyConfiguration(new AcknowledgedGapConfiguration());
        modelBuilder.ApplyConfiguration(new SequenceWatermarkConfiguration());
    }
}
