using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using QrBridge.Shared.Data.Entities;
using static QrBridge.Shared.Data.Configurations.CheckConstraints;

namespace QrBridge.Shared.Data.Configurations;

public sealed class OutboxMessageConfiguration : IEntityTypeConfiguration<OutboxMessage>
{
    public void Configure(EntityTypeBuilder<OutboxMessage> b)
    {
        b.ToTable("Outbox", t =>
        {
            t.HasCheckConstraint("CK_Outbox_Direction", SqlIn("Direction", Enum.GetNames<Direction>()));
            t.HasCheckConstraint("CK_Outbox_PayloadFormat", SqlIn("PayloadFormat", Enum.GetNames<PayloadFormat>()));
            t.HasCheckConstraint("CK_Outbox_LightStatus", SqlIn("LightStatus", Enum.GetNames<OutboxLightStatus>()));
            t.HasCheckConstraint("CK_Outbox_ServiceStatus", SqlIn("ServiceStatus", Enum.GetNames<OutboxServiceStatus>()));
            t.HasCheckConstraint("CK_Outbox_ServiceHttpStatus", HttpStatusRange("ServiceHttpStatus"));
            t.HasCheckConstraint("CK_Outbox_Kind", SqlIn("Kind", Enum.GetNames<MessageKind>()));
            t.HasCheckConstraint("CK_Outbox_Priority", PriorityRange("Priority"));
        });

        b.HasKey(x => x.MessageId); // also stops the same message being stored twice
        b.Property(x => x.MessageId).ValueGeneratedNever(); // always set by the sending gateway
        b.Property(x => x.Priority).HasConversion<byte>(); // a number, so the QR sender can air answers first

        b.Property(x => x.ServiceName).IsRequired().HasMaxLength(256);
        b.Property(x => x.Operation).IsRequired().HasMaxLength(256);
        b.Property(x => x.BusinessType).HasMaxLength(256);
        b.Property(x => x.LightComment).HasMaxLength(2000);
        b.Property(x => x.ServiceComment).HasMaxLength(2000);
        b.Property(x => x.MessageBytes).IsRequired();
        b.Property(x => x.MessageHash).IsRequired().HasMaxLength(64);
        b.Property(x => x.ContentFingerprint).HasMaxLength(64);
        b.Property(x => x.ReplyContentType).HasMaxLength(4096);

        b.HasIndex(x => new { x.LightStatus, x.Priority, x.Sequence }).HasDatabaseName("IX_Outbox_LightStatus");
        // A caller's retry is matched by content within a time window (round trip, step 8).
        b.HasIndex(x => new { x.ContentFingerprint, x.CreatedUtc }).HasDatabaseName("IX_Outbox_ContentFingerprint");
        // A Reply already sent for a request is looked up before posting again (round trip, step 9).
        b.HasIndex(x => x.CorrelationId).HasDatabaseName("IX_Outbox_CorrelationId");
        b.HasIndex(x => new { x.Direction, x.Sequence }).IsUnique().HasDatabaseName("IX_Outbox_Sequence");
        b.HasIndex(x => x.CreatedUtc).HasDatabaseName("IX_Outbox_Created");
    }
}
