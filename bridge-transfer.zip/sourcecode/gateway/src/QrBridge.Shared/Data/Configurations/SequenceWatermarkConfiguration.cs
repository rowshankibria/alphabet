using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using QrBridge.Shared.Data.Entities;
using static QrBridge.Shared.Data.Configurations.CheckConstraints;

namespace QrBridge.Shared.Data.Configurations;

public sealed class SequenceWatermarkConfiguration : IEntityTypeConfiguration<SequenceWatermark>
{
    public void Configure(EntityTypeBuilder<SequenceWatermark> b)
    {
        b.ToTable("SequenceWatermark", t =>
        {
            t.HasCheckConstraint("CK_SequenceWatermark_Direction", SqlIn("Direction", Enum.GetNames<Direction>()));
            t.HasCheckConstraint("CK_SequenceWatermark_ContiguousTo", "ContiguousTo >= 0");
        });

        b.HasKey(x => new { x.Direction, x.SequenceRunId });
    }
}
