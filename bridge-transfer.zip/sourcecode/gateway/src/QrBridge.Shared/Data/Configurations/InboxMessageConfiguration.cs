using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using QrBridge.Shared.Data.Entities;
using static QrBridge.Shared.Data.Configurations.CheckConstraints;

namespace QrBridge.Shared.Data.Configurations;

public sealed class InboxMessageConfiguration : IEntityTypeConfiguration<InboxMessage>
{
    public void Configure(EntityTypeBuilder<InboxMessage> b)
    {
        b.ToTable("Inbox", t =>
        {
            t.HasCheckConstraint("CK_Inbox_Direction", SqlIn("Direction", Enum.GetNames<Direction>()));
            t.HasCheckConstraint("CK_Inbox_PayloadFormat", SqlIn("PayloadFormat", Enum.GetNames<PayloadFormat>()));
            t.HasCheckConstraint("CK_Inbox_LightStatus", SqlIn("LightStatus", Enum.GetNames<InboxLightStatus>()));
            t.HasCheckConstraint("CK_Inbox_ServiceStatus", SqlIn("ServiceStatus", Enum.GetNames<InboxServiceStatus>()));
            t.HasCheckConstraint("CK_Inbox_ServiceHttpStatus", HttpStatusRange("ServiceHttpStatus"));
            t.HasCheckConstraint("CK_Inbox_Kind", SqlIn("Kind", Enum.GetNames<MessageKind>()));
            t.HasCheckConstraint("CK_Inbox_Priority", PriorityRange("Priority"));
        });

        b.HasKey(x => x.MessageId); // also stops the same message being stored twice
        b.Property(x => x.MessageId).ValueGeneratedNever(); // always set by the sending gateway
        b.Property(x => x.Priority).HasConversion<byte>(); // a number, so the delivery loops can order by it

        b.Property(x => x.ServiceName).IsRequired().HasMaxLength(256);
        b.Property(x => x.Operation).IsRequired().HasMaxLength(256);
        b.Property(x => x.BusinessType).HasMaxLength(256);
        b.Property(x => x.MessageBytes).IsRequired();
        b.Property(x => x.MessageHash).IsRequired().HasMaxLength(64);
        b.Property(x => x.ContentFingerprint).HasMaxLength(64);
        b.Property(x => x.LightComment).HasMaxLength(2000);
        b.Property(x => x.ServiceComment).HasMaxLength(2000);
        b.Property(x => x.DownstreamResult).HasMaxLength(4000);

        b.HasIndex(x => new { x.LightStatus, x.ServiceStatus, x.Kind, x.Priority, x.CreatedUtc }).HasDatabaseName("IX_Inbox_Status");
        b.HasIndex(x => new { x.Direction, x.SequenceRunId, x.Sequence }).HasDatabaseName("IX_Inbox_Sequence"); // gap check, per run
        b.HasIndex(x => x.ReceiptDueUtc).HasDatabaseName("IX_Inbox_ReceiptDue").HasFilter("ReceiptDueUtc IS NOT NULL");
        // "Far side last seen" on /health (decision D83): the newest acceptable arrival, read per probe.
        b.HasIndex(x => new { x.Direction, x.LightStatus, x.ReceivedUtc }).HasDatabaseName("IX_Inbox_Arrived");
        // The same content already handled within the retry window is not posted twice (round trip, decision D58).
        b.HasIndex(x => new { x.ContentFingerprint, x.ReceivedUtc }).HasDatabaseName("IX_Inbox_ContentFingerprint")
            .HasFilter("ContentFingerprint IS NOT NULL");
    }
}
