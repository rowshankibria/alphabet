using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Configurations;

public sealed class HeartbeatConfiguration : IEntityTypeConfiguration<Heartbeat>
{
    public void Configure(EntityTypeBuilder<Heartbeat> b)
    {
        b.ToTable("Heartbeat");
        b.HasKey(x => x.Component);
        b.Property(x => x.Component).HasMaxLength(64);
        b.Property(x => x.Info).HasMaxLength(1024);
    }
}
