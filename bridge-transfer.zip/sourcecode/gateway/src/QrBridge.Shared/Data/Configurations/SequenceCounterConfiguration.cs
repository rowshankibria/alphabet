using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using QrBridge.Shared.Data.Entities;
using static QrBridge.Shared.Data.Configurations.CheckConstraints;

namespace QrBridge.Shared.Data.Configurations;

public sealed class SequenceCounterConfiguration : IEntityTypeConfiguration<SequenceCounter>
{
    public void Configure(EntityTypeBuilder<SequenceCounter> b)
    {
        b.ToTable("SequenceCounter", t =>
            t.HasCheckConstraint("CK_SequenceCounter_Direction", SqlIn("Direction", Enum.GetNames<Direction>())));

        b.HasKey(x => x.Direction);

        // One row per direction, created with the database
        b.HasData(
            new SequenceCounter { Direction = Direction.CorpToDmz, LastValue = 0 },
            new SequenceCounter { Direction = Direction.DmzToCorp, LastValue = 0 });
    }
}
