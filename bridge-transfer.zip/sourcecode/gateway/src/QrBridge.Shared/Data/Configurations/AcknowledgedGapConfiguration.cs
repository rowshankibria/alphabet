using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using QrBridge.Shared.Data.Entities;
using static QrBridge.Shared.Data.Configurations.CheckConstraints;

namespace QrBridge.Shared.Data.Configurations;

public sealed class AcknowledgedGapConfiguration : IEntityTypeConfiguration<AcknowledgedGap>
{
    public void Configure(EntityTypeBuilder<AcknowledgedGap> b)
    {
        b.ToTable("AcknowledgedGap", t =>
        {
            t.HasCheckConstraint("CK_AcknowledgedGap_Direction", SqlIn("Direction", Enum.GetNames<Direction>()));
            t.HasCheckConstraint("CK_AcknowledgedGap_Range", "FromSequence >= 1 AND ToSequence >= FromSequence");
        });

        b.HasKey(x => new { x.Direction, x.SequenceRunId, x.FromSequence });
        b.Property(x => x.AcknowledgedBy).IsRequired().HasMaxLength(256);
        b.Property(x => x.Reason).IsRequired().HasMaxLength(2000);
    }
}
