namespace QrBridge.Shared.Data.Configurations;

internal static class CheckConstraints
{
    /// <summary>SQL for "column IN ('a','b',...)", used to generate CHECK constraints from enum names.</summary>
    internal static string SqlIn(string column, IEnumerable<string> values) =>
        $"{column} IN ({string.Join(",", values.Select(v => $"'{v}'"))})";

    /// <summary>An optional HTTP status code: null, or 100–599.</summary>
    internal static string HttpStatusRange(string column) => $"{column} IS NULL OR {column} BETWEEN 100 AND 599";

    /// <summary>A MessagePriority stored as its number (the one enum not stored by name, so it can be ordered).</summary>
    internal static string PriorityRange(string column) =>
        $"{column} BETWEEN {(int)MessagePriority.Answer} AND {(int)MessagePriority.Low}";
}
