using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace QrBridge.Shared.Data;

public sealed class GuidStringConverter() : ValueConverter<Guid, string>(
    v => v.ToString("D"),
    v => Guid.Parse(v));
