using Microsoft.EntityFrameworkCore;
using QrBridge.Shared.Data.Entities;

namespace QrBridge.Shared.Data.Repositories;

/// <summary>Liveness rows in the Heartbeat table of qrbridge.db, written by every component every ~30 seconds.</summary>
public sealed class HeartbeatRepository(IDbContextFactory<BridgeDbContext> factory)
{
    public async Task BeatAsync(string component, string? info, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var now = DateTime.UtcNow;
        info = info is { Length: > 1024 } ? info[..1024] : info;

        int updated = await db.Heartbeats.Where(h => h.Component == component)
            .ExecuteUpdateAsync(s => s.SetProperty(h => h.LastSeenUtc, now).SetProperty(h => h.Info, info), ct);
        if (updated == 0)
        {
            db.Heartbeats.Add(new Heartbeat { Component = component, LastSeenUtc = now, Info = info });
            try { await db.SaveChangesAsync(ct); }
            catch (DbUpdateException) { /* another process inserted it first; next beat updates */ }
        }
    }

    public async Task<IReadOnlyList<Heartbeat>> GetAllAsync(CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.Heartbeats.AsNoTracking().OrderBy(h => h.Component).ToListAsync(ct);
    }
}
