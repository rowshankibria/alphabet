namespace QrBridge.Shared.Data.Entities;

/// <summary>A message waiting to cross (or crossing) the air gap. Written by the Gateway, aired by the QR sender. Table Outbox in qrbridge.db.</summary>
public class OutboxMessage : BaseMessage
{
    /// <summary>Pending → Sending (QR sender) → Aired → Received (the far side's Receipt), or Failed (operator action).</summary>
    public OutboxLightStatus LightStatus { get; set; } = OutboxLightStatus.Pending;

    /// <summary>When LightStatus last changed (UTC). Rows are never deleted automatically (decision D28): archive manually.</summary>
    public DateTime? LightUpdatedUtc { get; set; }

    /// <summary>Waiting until the far side's Reply says what the real service did.</summary>
    public OutboxServiceStatus ServiceStatus { get; set; } = OutboxServiceStatus.Waiting;

    /// <summary>SOAP body size in bytes before compression (monitoring only).</summary>
    public int PayloadSize { get; set; }

    // ----- The real service's answer, from the far side's Reply (round trip). Null until it arrives. -----

    /// <summary>The real service's Content-Type, exactly as it answered (its HTTP status is ServiceHttpStatus).</summary>
    public string? ReplyContentType { get; set; }

    /// <summary>The real service's reply body, byte for byte, at most Bridge:MaxPayloadBytes. Handed to the waiting caller unchanged.</summary>
    public byte[]? ReplyBody { get; set; }

    /// <summary>
    /// When the far side created the Reply whose answer is stored (its clock). A later Reply, after an operator requeued
    /// the request there, replaces an answer that is not Answered; an older one arriving late never does (decision D59).
    /// </summary>
    public DateTime? ReplyCreatedUtc { get; set; }
}
