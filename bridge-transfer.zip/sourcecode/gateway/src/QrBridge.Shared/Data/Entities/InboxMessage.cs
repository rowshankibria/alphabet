namespace QrBridge.Shared.Data.Entities;

/// <summary>A complete message from the other side. Written by the QR receiver, processed by the Gateway worker. Table Inbox in qrbridge.db.</summary>
public class InboxMessage : BaseMessage
{
    /// <summary>Received when stored; Rejected when an arrival check fails (reason in LightComment). Rejected rows are never delivered.</summary>
    public InboxLightStatus LightStatus { get; set; } = InboxLightStatus.Received;

    /// <summary>
    /// Pending → Delivering (InboxWorker) → Done, or Retrying (backoff), Unknown / Refused / NotDelivered (operator
    /// action), Expired. Only rows whose LightStatus is Received are delivered.
    /// </summary>
    public InboxServiceStatus ServiceStatus { get; set; } = InboxServiceStatus.Pending;

    /// <summary>True once the Gateway has opened it and its checks passed.</summary>
    public bool Verified { get; set; }

    /// <summary>When the QR receiver stored it (UTC).</summary>
    public DateTime ReceivedUtc { get; set; }

    /// <summary>
    /// A Receipt for this message is owed to the sender (decision D44): set when it arrives and again when the same
    /// MessageId arrives a second time (a re-aired session, because the first Receipt was lost); cleared once the
    /// gateway has queued the Receipt. Never set for a Receipt.
    /// </summary>
    public DateTime? ReceiptDueUtc { get; set; }

    /// <summary>
    /// What the real service answered (e.g. its RETURN_CODE and ERROR_MESSAGE), so an operator can see
    /// why a message was refused. Never the request payload.
    /// </summary>
    public string? DownstreamResult { get; set; }
}
