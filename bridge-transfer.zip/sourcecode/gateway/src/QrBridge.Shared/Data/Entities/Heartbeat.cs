namespace QrBridge.Shared.Data.Entities;

/// <summary>Liveness of each component, shown in the QR apps and /health. Table Heartbeat in qrbridge.db.</summary>
public class Heartbeat
{
    public string Component { get; set; } = "";
    public DateTime LastSeenUtc { get; set; }
    public string? Info { get; set; }
}
