using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace QrBridge.Shared.Data;

/// <summary>
/// Creates or upgrades the bridge database (qrbridge.db). Safe to call from both apps at startup, in any order.
///
/// - Refuses to start while a database of the former two-file layout (send.db, received.db) is in the data folder.
/// - Creates the data folder if it does not exist.
/// - If EF migrations exist in this assembly, they are applied (use this once you go to production).
/// - Otherwise the schema is created from the model (EnsureCreated).
/// - Turns on WAL mode (persistent in the file).
/// - Retries, because the Gateway and the QR apps may all try to create the file at the same moment.
/// </summary>
public static class DatabaseInitializer
{
    /// <summary>The databases of the former layout (until 25 Nov 2026): one for what is sent, one for what arrived.</summary>
    public static readonly IReadOnlyList<string> FormerDatabaseFileNames = ["send.db", "received.db"];

    public static async Task InitializeAsync(IServiceProvider services, ILogger logger, CancellationToken ct = default)
    {
        var options = services.GetRequiredService<IOptions<BridgeOptions>>().Value;

        // A former file may hold messages a caller was told were accepted but that were never carried or delivered.
        // Starting on a new, empty qrbridge.db would drop them without a trace, so an operator must deal with them first.
        if (FormerDatabaseProblem(options.DataFolder) is { } problem)
            throw new InvalidOperationException(problem);

        Directory.CreateDirectory(options.DataFolder);
        var factory = services.GetRequiredService<IDbContextFactory<BridgeDbContext>>();

        for (int attempt = 1; ; attempt++)
        {
            try
            {
                await using var db = await factory.CreateDbContextAsync(ct);

                if (db.Database.GetMigrations().Any())
                    await db.Database.MigrateAsync(ct);
                else
                    await db.Database.EnsureCreatedAsync(ct);

                await db.Database.ExecuteSqlRawAsync("PRAGMA journal_mode = WAL;", ct);
                logger.LogInformation("Database {Name} ready", BridgeOptions.DatabaseFileName);
                return;
            }
            catch (Exception ex) when (attempt < 5 && ex is SqliteException or InvalidOperationException or DbUpdateException)
            {
                logger.LogWarning(ex, "Initializing {Name} failed (attempt {Attempt}); retrying", BridgeOptions.DatabaseFileName, attempt);
                await Task.Delay(TimeSpan.FromSeconds(attempt), ct);
            }
        }
    }

    /// <summary>Why the start must stop because a former database file is in <paramref name="dataFolder"/>; null when none is.</summary>
    public static string? FormerDatabaseProblem(string dataFolder)
    {
        var found = FormerDatabaseFileNames.Where(name => File.Exists(Path.Combine(dataFolder, name))).ToList();
        if (found.Count == 0) return null;
        return $"{string.Join(" and ", found)} found in {dataFolder}. The bridge now keeps everything in one database, " +
               $"{BridgeOptions.DatabaseFileName}, and does not read the former files. They may still hold messages that were " +
               "accepted but not yet carried over the light or delivered. Check them (Outbox rows not yet Received or still " +
               "Waiting for a Reply, Inbox rows not yet Done), deal with those messages, then move the former files (with their -wal and -shm files) out of the data " +
               "folder and start again.";
    }
}
