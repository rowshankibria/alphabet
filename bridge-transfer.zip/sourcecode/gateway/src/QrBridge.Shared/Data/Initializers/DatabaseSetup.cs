using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace QrBridge.Shared.Data;

public static class DatabaseSetup
{
    public static string ConnectionString(string path) => new SqliteConnectionStringBuilder
    {
        DataSource = path,
        Mode = SqliteOpenMode.ReadWriteCreate,
        Cache = SqliteCacheMode.Private,
        Pooling = true,
        DefaultTimeout = 30, // seconds; Microsoft.Data.Sqlite also retries SQLITE_BUSY up to this
    }.ToString();

    public static void Configure(DbContextOptionsBuilder o, string path) =>
        o.UseSqlite(ConnectionString(path))
         .AddInterceptors(new SqlitePragmaInterceptor());
}
