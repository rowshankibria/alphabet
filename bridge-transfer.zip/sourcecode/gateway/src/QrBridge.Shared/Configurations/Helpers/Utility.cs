using System.Security.Cryptography;
using System.Xml;

namespace QrBridge.Shared;

/// <summary>
/// The one way the bridge loads untrusted XML: callers' requests and payloads, the real services' replies, the WSDLs
/// (gateway), and every message the gateway's read-only UI shows (QrBridge.Gateway/Ui).
/// </summary>
public static class SafeXml
{
    public static XmlReaderSettings Settings(long maxCharacters) => new()
    {
        DtdProcessing = DtdProcessing.Prohibit, // no DOCTYPE at all: blocks XXE and entity expansion
        XmlResolver = null,
        MaxCharactersInDocument = maxCharacters,
        IgnoreComments = true,
        IgnoreProcessingInstructions = true,
    };

    public static XmlDocument Load(byte[] bytes, long maxCharacters, bool preserveWhitespace = false)
    {
        using var reader = XmlReader.Create(new MemoryStream(bytes, writable: false), Settings(maxCharacters));
        return Load(reader, preserveWhitespace);
    }

    public static XmlDocument LoadText(string text, long maxCharacters, bool preserveWhitespace = false)
    {
        using var reader = XmlReader.Create(new StringReader(text), Settings(maxCharacters));
        return Load(reader, preserveWhitespace);
    }

    private static XmlDocument Load(XmlReader reader, bool preserveWhitespace)
    {
        var doc = new XmlDocument { XmlResolver = null, PreserveWhitespace = preserveWhitespace };
        doc.Load(reader);
        return doc;
    }
}

public static class BridgeSideExtensions
{
    /// <summary>Direction of messages this side SENDS.</summary>
    public static Direction SendDirection(this BridgeSide side) =>
        side == BridgeSide.Corp ? Direction.CorpToDmz : Direction.DmzToCorp;

    /// <summary>Direction of messages this side RECEIVES.</summary>
    public static Direction ReceiveDirection(this BridgeSide side) =>
        side == BridgeSide.Corp ? Direction.DmzToCorp : Direction.CorpToDmz;

    /// <summary>The other network.</summary>
    public static BridgeSide Other(this BridgeSide side) =>
        side == BridgeSide.Corp ? BridgeSide.Dmz : BridgeSide.Corp;
}

public static class Hashing
{
    /// <summary>Lower-case hex SHA-256. Stored as MessageHash on both sides for audit/reconciliation.</summary>
    public static string Sha256Hex(byte[] data) => Convert.ToHexStringLower(SHA256.HashData(data));
}

public static class StatusCounts
{
    /// <summary>A count for every value of <typeparamref name="T"/> (0 when none), so /health always shows each status.</summary>
    public static IReadOnlyDictionary<T, int> ForAll<T>(IEnumerable<KeyValuePair<T, int>> counts) where T : struct, Enum
    {
        var result = Enum.GetValues<T>().ToDictionary(v => v, _ => 0);
        foreach (var (status, count) in counts) result[status] = count;
        return result;
    }
}

public static class SignalNames
{
    // The side is part of the name so a Corp and a Dmz install can run side by side on one dev machine.

    /// <summary>Gateway rings this after inserting into Outbox. QR sender waits on it.</summary>
    public static string Outbox(BridgeSide side) => $@"Global\QrBridge.{side}.Outbox";

    /// <summary>QR receiver rings this after inserting into Inbox. Gateway worker waits on it.</summary>
    public static string Inbox(BridgeSide side) => $@"Global\QrBridge.{side}.Inbox";
}

public static class Components
{
    public const string GatewayApi = "GatewayApi";
    public const string InboxWorker = "InboxWorker";
    public const string MaintenanceWorker = "MaintenanceWorker";
    public const string SenderLoop = "SenderLoop";
    public const string ReceiverLoop = "ReceiverLoop";
}
