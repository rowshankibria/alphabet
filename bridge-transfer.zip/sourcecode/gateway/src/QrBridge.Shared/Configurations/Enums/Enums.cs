namespace QrBridge.Shared;

/// <summary>Which network this installation runs in. Set in appsettings ("Bridge:Side").</summary>
public enum BridgeSide { Corp = 1, Dmz = 2 }

/// <summary>
/// Stored in the message header and the queues. In the interface docs' words: CorpToDmz = Inbound, DmzToCorp = Outbound.
/// </summary>
public enum Direction : byte { CorpToDmz = 1, DmzToCorp = 2 }

public enum PayloadFormat : byte
{
    /// <summary>
    /// The body is the caller's SOAP request body, untouched; the <see cref="Serialization.MessageHeader"/> carries the
    /// path, SOAPAction and Content-Type needed to replay it.
    /// </summary>
    RawSoap = 1,

    /// <summary>
    /// A plain HTTP GET (Registered Tags, decision D18): no body, no Content-Type and no SOAPAction; replayed as a GET to
    /// the configured target + Path. Only for a route marked HttpGet in routes.json.
    /// </summary>
    HttpGet = 2,
}

public enum Compression : byte { None = 0, Brotli = 1 }

/// <summary>
/// What a message is (header field Kind). Request: a caller's call, carried to the real service. Receipt: "these
/// messages crossed the light" (stops re-airing). Reply: the real service's answer, CorrelationId = the request's
/// MessageId. Heartbeat (decision D80): "this side is alive", sent when it has had nothing else to send for
/// Gateway:HeartbeatMinutes; empty, names no message, gets no Receipt and is never aired again. It takes a sequence
/// number like every message, so a lost last message shows as a gap once the heartbeat after it arrives.
/// Receipts, Replies and Heartbeats are consumed by the gateway on the other side, never posted to a service.
/// </summary>
public enum MessageKind : byte { Request = 1, Receipt = 2, Reply = 3, Heartbeat = 4 }

/// <summary>
/// Which messages go first (header field Priority, decision D73), lowest value first: on the light (the QR sender's
/// claim order) and in the far side's delivery (one loop per Request class). Answer = Receipts and Replies, always
/// first ("answers jump the queue"). Requests: High = state-changing round trips (1596 on timeout), Normal = queries
/// (a caller is held), Low = Bridge feeds. Stored as its number, so the database orders it.
/// </summary>
public enum MessagePriority : byte { Answer = 0, High = 1, Normal = 2, Low = 3 }

/// <summary>
/// What the far side did with a Request, as its Reply says (header field Outcome, decision D43). The same words as the
/// receiving side's Inbox status, plus Rejected (failed an arrival check, never delivered).
/// </summary>
public enum ServiceOutcome : byte
{
    /// <summary>The real service accepted it.</summary>
    Done = 1,
    /// <summary>The real service refused it, or it was not processed (fault, non-zero code, 4xx, 3xx, 501, 505).</summary>
    Refused = 2,
    /// <summary>It may have been processed; nobody knows (D9). An operator checks.</summary>
    Unknown = 3,
    /// <summary>Not posted: it arrived after its ExpiresUtc.</summary>
    Expired = 4,
    /// <summary>It surely never reached the real service (no target, or out of tries where nothing was sent).</summary>
    NotDelivered = 5,
    /// <summary>It failed an arrival check on the far side (checksum, catalogue, direction, replay window…): never delivered.</summary>
    Rejected = 6,
}

// ---- Status of a stored message: two groups per row (decision D24), so an operator sees at once whether a problem
// ---- is on the light (screens, cameras, QR apps) or at the service end (the real service's answer).

/// <summary>Outbox, the light: has the message crossed?</summary>
public enum OutboxLightStatus
{
    /// <summary>Waiting to be shown.</summary>
    Pending,
    /// <summary>Claimed by the QR sender, on screen now.</summary>
    Sending,
    /// <summary>Shown; no Receipt from the far side yet.</summary>
    Aired,
    /// <summary>The far side's Receipt arrived: it is stored in the far Inbox.</summary>
    Received,
    /// <summary>Out of re-air tries: operator alarm (reason in LightComment).</summary>
    Failed,
}

/// <summary>Outbox, the service end: what the far side's real service did (from its Reply, the same words as its Outcome).</summary>
public enum OutboxServiceStatus
{
    /// <summary>No Reply yet.</summary>
    Waiting,
    /// <summary>The real service accepted it (far side Done).</summary>
    Answered,
    /// <summary>It may have been processed; nobody knows. An operator checks.</summary>
    Unknown,
    /// <summary>The real service refused it, or it was not processed.</summary>
    Refused,
    /// <summary>Not posted: it reached the far side after its ExpiresUtc.</summary>
    Expired,
    NotAvailable,
    /// <summary>It surely never reached the real service (decision D51): an operator may send it again.</summary>
    NotDelivered,
    /// <summary>It failed an arrival check on the far side and was never delivered (decision D51).</summary>
    Rejected,
}

/// <summary>Inbox, the light: did the message arrive intact and acceptable?</summary>
public enum InboxLightStatus
{
    Received,
    /// <summary>Failed an arrival check (checksum, direction, catalogue, replay window). Never delivered.</summary>
    Rejected,
}

/// <summary>Inbox, the service end: delivery to the real service on this side.</summary>
public enum InboxServiceStatus
{
    /// <summary>Waiting for delivery.</summary>
    Pending,
    /// <summary>Claimed by the InboxWorker, being posted.</summary>
    Delivering,
    /// <summary>The real service accepted it.</summary>
    Done,
    /// <summary>Will be posted again after a backoff.</summary>
    Retrying,
    /// <summary>It may have reached the service, but the outcome is not known: operator alarm, never re-posted on its own.</summary>
    Unknown,
    /// <summary>The service refused it (fault, non-zero code, 4xx): operator action.</summary>
    Refused,
    /// <summary>Arrived after its expiry: not posted.</summary>
    Expired,
    /// <summary>Surely never reached the service and will not be tried again (e.g. no target configured): operator may resend.</summary>
    NotDelivered,
}
