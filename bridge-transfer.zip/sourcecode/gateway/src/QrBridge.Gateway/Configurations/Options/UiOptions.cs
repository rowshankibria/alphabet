namespace QrBridge.Gateway;

/// <summary>
/// The read-only web UI under /qrbridge-ui. Bound from the "Ui" section of the gateway's appsettings. Read after Build
/// (Initializer/UiRegistration.MapGatewayUi), so environment and test overrides always apply.
/// </summary>
public sealed class UiOptions
{
    public const string SectionName = "Ui";

    /// <summary>Serve the UI. False: its paths answer like any other unknown path (GET 405, POST a SOAP fault).</summary>
    public bool Enabled { get; set; } = true;

    /// <summary>
    /// The one login (handoff decision 48: admin / admin by default, agreed with Rowshan). Change it per site in
    /// appsettings.{Side}.json; it is never logged. A start with the default logs a warning.
    /// </summary>
    public string Username { get; set; } = "admin";

    public string Password { get; set; } = "admin";

    /// <summary>Minutes a login lasts; each page view extends it (sliding).</summary>
    public int SessionMinutes { get; set; } = 480;

    /// <summary>Rows per page in the Outbox and Inbox lists until a viewer picks another size (10, 25, 50, 100 or 200).</summary>
    public int PageSize { get; set; } = 50;

    /// <summary>
    /// The zone every time is shown in (Windows or IANA id). The database keeps UTC; only the pages convert. US Eastern
    /// by default: EST in winter, EDT in summer.
    /// </summary>
    public string TimeZone { get; set; } = "Eastern Standard Time";

    /// <summary>Seconds between reloads when a viewer turns auto-refresh on (overview and lists).</summary>
    public int RefreshSeconds { get; set; } = 10;
}
