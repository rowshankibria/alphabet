using QrBridge.Shared;

namespace QrBridge.Gateway;

/// <summary>The route catalogue ("Routing" section, normally in routes.json). The same file is used on both sides.</summary>
public sealed class RoutingOptions
{
    public const string SectionName = "Routing";

    /// <summary>
    /// Accept SOAP calls to services/paths that are not in the catalogue, bridging them with an automatic
    /// empty reply. Useful in test and discovery; keep it OFF in production so only listed services pass (allow-list).
    /// </summary>
    public bool AcceptUnlisted { get; set; }

    /// <summary>For unlisted calls: reply HTTP 202 with no body (one-way operations) instead of an empty SOAP reply.</summary>
    public bool UnlistedOneWay { get; set; }

    /// <summary>Reply values shared by operations, by name (e.g. "FmsResponse", "ReturnCode").</summary>
    public Dictionary<string, ReplyProfile> ReplyProfiles { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// Payload fields (element or attribute names) left out of the content fingerprint of every route, because they
    /// change on every send (decision D5): e.g. MSG_ID, GMT_TIME_SENT, RRMsgID. Routes and message types can add more
    /// (<see cref="OperationRoute.FingerprintIgnore"/>). Used by the Sender part's retry check (tracker step 8).
    /// </summary>
    public List<string> FingerprintIgnore { get; set; } = [];

    public List<ServiceRoute> Services { get; set; } = [];
}

/// <summary>One service the gateway stands in for, as its callers see it.</summary>
public sealed class ServiceRoute
{
    /// <summary>Short stable name, e.g. "FC2FMS". Stored in every message; used for Receiver targets.</summary>
    public string Name { get; set; } = "";

    public string? Description { get; set; }

    /// <summary>
    /// The Sender machine: the gateway that receives the calls (the side the callers are on) and sends them over the
    /// QR link. The other side is the Receiver and delivers them. Corp = Inbound (Corp → DMZ), Dmz = Outbound (DMZ → Corp).
    /// </summary>
    public BridgeSide SenderSide { get; set; } = BridgeSide.Corp;

    /// <summary>The path(s) callers use, as forwarded by the load balancer. Case-insensitive.</summary>
    public List<string> Paths { get; set; } = [];

    /// <summary>
    /// A plain HTTP GET interface, not SOAP (Registered Tags, decision D18): exactly one path and one operation named
    /// "GET" in RoundTrip mode with OnHoldTimeout Unavailable; no Contract, reply profile or message types. Its caller
    /// gets the real answer byte for byte, or HTTP 504 when none comes back in time (D69). A query string is refused (D71).
    /// </summary>
    public bool HttpGet { get; set; }

    /// <summary>
    /// Largest request body this service accepts, in bytes (decision D78); bigger calls get HTTP 413 before anything is
    /// parsed or queued. Null: Bridge:MaxPayloadBytes, which also stays the upper limit (the smaller of the two applies,
    /// so the shared catalogue does not depend on one side's setting). Must be positive.
    /// </summary>
    public int? MaxRequestBytes { get; set; }

    /// <summary>
    /// Most Requests of this service waiting to cross (Pending, Sending, Aired) before new calls get the Busy answer
    /// (decision D78), so one flooded service cannot fill the Outbox. Null: only Gateway:MaxBacklog applies.
    /// </summary>
    public int? MaxBacklog { get; set; }

    public MessageStyle Style { get; set; } = MessageStyle.Document;

    /// <summary>
    /// Folder under Contracts/ holding this service's WSDL (service.wsdl + *.xsd). Calls to Bridge operations must
    /// match it before they are queued. Null: no WSDL check (the allow-list still applies).
    /// </summary>
    public string? Contract { get; set; }

    /// <summary>Overrides the reply's result element name (default: OpResult for Document, Result for Rpc).</summary>
    public string? ResultElement { get; set; }

    /// <summary>What happens to operations not listed in <see cref="Operations"/>.</summary>
    public OperationMode OtherOperations { get; set; } = OperationMode.Reject;

    /// <summary>Operations by SOAP body element name (e.g. "SendToFMS").</summary>
    public Dictionary<string, OperationRoute> Operations { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class OperationRoute
{
    public OperationMode Mode { get; set; } = OperationMode.Bridge;

    /// <summary>Name of a <see cref="ReplyProfile"/>. Null: automatic empty reply / SOAP faults.</summary>
    public string? Reply { get; set; }

    /// <summary>One-way operation: reply HTTP 202 with no body.</summary>
    public bool OneWay { get; set; }

    /// <summary>
    /// If not empty, only payloads whose MESSAGE/@TYPE (or root element name) is in this list are accepted.
    /// Mirrors what the real service accepts, so bad payloads are refused at once instead of failing later.
    /// </summary>
    public List<string> AllowedTypes { get; set; } = [];

    /// <summary>For <see cref="OperationMode.RoundTrip"/>: the answer when the hold runs out. Default: 1596 (state-changing rules).</summary>
    public HoldTimeoutAnswer OnHoldTimeout { get; set; } = HoldTimeoutAnswer.Pending;

    /// <summary>Fields left out of the content fingerprint, in addition to <see cref="RoutingOptions.FingerprintIgnore"/>.</summary>
    public List<string> FingerprintIgnore { get; set; } = [];

    /// <summary>
    /// Attach a caller's retry (same content within Gateway:RetryWindowMinutes) to the first message instead of queuing
    /// it again (decision D37). Null: on for RoundTrip calls whose hold-timeout answer is Pending (1596), off for the
    /// others (D56) — a Bridge caller already got RETURN_CODE 0, and a read-only query must ask the real service again
    /// rather than get an earlier (or expired) answer.
    /// </summary>
    public bool? RecogniseRetries { get; set; }

    /// <summary>
    /// Which class this operation's messages travel in (decision D73). Null: High for RoundTrip calls answering 1596
    /// (state-changing), Normal for RoundTrip queries, Low for Bridge feeds. Answer is reserved for Receipts and Replies.
    /// </summary>
    public MessagePriority? Priority { get; set; }

    /// <summary>
    /// Per MESSAGE/@TYPE settings inside this operation (exact, case-sensitive), for operations that carry several
    /// kinds of message (GetFromFMS: queries and WITHDRAW_RFP; ProcessMessage: polls and pushes). A type not listed
    /// here follows the operation.
    /// </summary>
    public Dictionary<string, TypeRoute> Types { get; set; } = new(StringComparer.Ordinal);
}

/// <summary>Settings for one MESSAGE/@TYPE inside an operation. Null values follow the operation.</summary>
public sealed class TypeRoute
{
    /// <summary>Bridge, RoundTrip or Unavailable. To refuse a type, leave it out of <see cref="OperationRoute.AllowedTypes"/>.</summary>
    public OperationMode? Mode { get; set; }

    public HoldTimeoutAnswer? OnHoldTimeout { get; set; }

    /// <summary>Fields left out of the content fingerprint, in addition to the operation's.</summary>
    public List<string> FingerprintIgnore { get; set; } = [];

    public bool? RecogniseRetries { get; set; }

    public MessagePriority? Priority { get; set; }
}

/// <summary>
/// The result values the gateway puts in its replies for one kind of operation. Values are the text of the
/// result element (an FMS &lt;RESPONSE&gt; document, or a number); null means "no value" (empty reply or fault).
/// Placeholders: {BusinessType} (MESSAGE/@TYPE), {MsgId} (MESSAGE/@MSG_ID), {MessageId} (bridge id). All escaped.
/// </summary>
public sealed class ReplyProfile
{
    /// <summary>How the Receiver side reads the real service's answer.</summary>
    public ResultKind ResultKind { get; set; } = ResultKind.None;

    /// <summary>Message accepted and queued.</summary>
    public string? Ok { get; set; }

    /// <summary>Backlog full: message NOT accepted, caller should retry.</summary>
    public string? Busy { get; set; }

    /// <summary>Operation cannot be served across the air gap (queries).</summary>
    public string? Unavailable { get; set; }

    /// <summary>
    /// A held RoundTrip call whose answer did not come back in time (OnHoldTimeout = Pending): "sent over the QR bridge,
    /// confirmation not yet received" (RETURN_CODE 1596, decision D8). Never a success value.
    /// </summary>
    public string? Pending { get; set; }

    /// <summary>Payload refused (MESSAGE TYPE not allowed, or not well-formed XML).</summary>
    public string? Rejected { get; set; }
}
