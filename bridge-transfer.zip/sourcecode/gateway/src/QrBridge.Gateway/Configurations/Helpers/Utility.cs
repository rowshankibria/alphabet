using System.Xml;

namespace QrBridge.Gateway;

public static class SoapNamespaces
{
    public const string Soap11 = "http://schemas.xmlsoap.org/soap/envelope/";
    public const string Soap12 = "http://www.w3.org/2003/05/soap-envelope";
    public const string SoapEncoding = "http://schemas.xmlsoap.org/soap/encoding/";
    /// <summary>WS-Addressing 1.0 (WCF WSHttpBinding, Soap12WSAddressing10).</summary>
    public const string Addressing10 = "http://www.w3.org/2005/08/addressing";
    /// <summary>WS-Addressing August 2004 (older WCF/WSE stacks).</summary>
    public const string Addressing200408 = "http://schemas.xmlsoap.org/ws/2004/08/addressing";

    public static string Envelope(SoapVersion version) => version == SoapVersion.Soap12 ? Soap12 : Soap11;

    public static string ContentType(SoapVersion version) =>
        version == SoapVersion.Soap12 ? "application/soap+xml; charset=utf-8" : "text/xml; charset=utf-8";

    public static bool IsAddressing(string ns) => ns is Addressing10 or Addressing200408;
}

// SafeXml, the one way untrusted XML is loaded, lives in QrBridge.Shared (Configurations/Helpers/Utility.cs), so the
// gateway and the QrDiode apps use the same settings; the read-only UI (Ui/) uses it too.

/// <summary>
/// The read-only UI's URLs. Everything it serves is under <see cref="Prefix"/> (handoff decision 48); the gateway refuses
/// to start when a route in routes.json uses a path there, and every other GET still gets 405.
/// </summary>
public static class UiPaths
{
    public const string Prefix = "/qrbridge-ui";
    public const string Login = Prefix + "/login";
    public const string Logout = Prefix + "/logout";

    /// <summary>The prefix itself or anything below it, ignoring case (paths are matched case-insensitively).</summary>
    public static bool IsUiPath(string? path) =>
        path is not null &&
        (path.Equals(Prefix, StringComparison.OrdinalIgnoreCase) || path.StartsWith(Prefix + "/", StringComparison.OrdinalIgnoreCase));

    public static string Name(MessageBox box) => box == MessageBox.Outbox ? "outbox" : "inbox";

    public static string Box(MessageBox box) => $"{Prefix}/{Name(box)}";

    public static string Message(MessageBox box, Guid id) => $"{Box(box)}/{id:D}";

    /// <summary>A return URL after login: only a local page of the UI, never another site or another path of the gateway.</summary>
    public static bool IsSafeReturnUrl(string? url) =>
        !string.IsNullOrEmpty(url) && url[0] == '/' && !url.StartsWith("//", StringComparison.Ordinal) &&
        !url.StartsWith("/\\", StringComparison.Ordinal) && IsUiPath(url.Split('?', '#')[0]);
}

/// <summary>Small XML lookups used when reading SOAP envelopes (requests, payloads and the real services' replies).</summary>
public static class XmlHelpers
{
    /// <summary>The first child element with this local name and namespace, or null.</summary>
    public static XmlElement? ChildElement(XmlElement parent, string localName, string ns)
    {
        foreach (XmlNode node in parent.ChildNodes)
            if (node is XmlElement e && e.LocalName == localName && e.NamespaceURI == ns)
                return e;
        return null;
    }

    /// <summary>The first child element, whatever its name, or null.</summary>
    public static XmlElement? FirstChildElement(XmlElement parent)
    {
        foreach (XmlNode node in parent.ChildNodes)
            if (node is XmlElement e)
                return e;
        return null;
    }
}
