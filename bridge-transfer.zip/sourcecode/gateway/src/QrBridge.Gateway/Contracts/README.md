# Service contracts (WSDL / XSD) — used to check requests, never served

## What a contract is, in plain words

Every interface here is a SOAP web service. A SOAP call is an XML **envelope**; inside its `<Body>` is one element
named after the **operation** (e.g. `SendToFMS`, `CreateCard`), and inside that the **parameters** (almost always one
string, `sXML`, `XMLMsg` or `msgData`). That string carries the **business message**, e.g.
`<MESSAGE TYPE="CARD_CREATE" MSG_ID="…"><MSG_HEADER>…</MSG_HEADER><MSG_DATA>…</MSG_DATA></MESSAGE>`.

```
<s:Envelope>                         SOAP version (1.1 / 1.2)            ┐
  <s:Body>                                                               │ checked against
    <CreateCard xmlns="http://tempuri.org/">   operation + namespace     │ the WSDL / XSD
      <sXML>                                   parameter name and type   ┘ (this folder)
        <MESSAGE TYPE="CARD_CREATE" …>         business message type     ← checked by AllowedTypes
          …                                    business data             ← passed through unchanged
```

- **WSDL** (`service.wsdl`) — the service's menu: its operations, their parameters, the SOAP version and style.
- **XSD** (`xsd0.xsd`, `xsd1.xsd`, or inline in the WSDL) — the exact XML shape of each operation's parameters.
- **WCF `.svc`** and **ASMX `.asmx`** services use *document/literal*: the Body element is checked against the XSD.
  Old **SOAP Toolkit `*.WSDL`** endpoints use *RPC/encoded*: the parameters are checked by name against the WSDL parts.

The business `<MESSAGE>` is just `xs:string` in every WSDL, so the WSDL cannot check it. The route's `AllowedTypes`
in `routes.json` does: only the `MESSAGE/@TYPE` values the real caller sends with that operation are accepted.

## Layout: one folder per direction, one folder per route

| Folder | Direction | Who calls | Sender (checks the call) on | Receiver (delivers) on |
|---|---|---|---|---|
| `Inbound/` | CorpNet → DMZ (`SenderSide: Corp`) | Rapid Restore FCR/FOD/SSO, FTC, DSS, Verizon, XA/21, BFC call FMS/TOMS/TLS/DSO | Corp gateway | DMZ gateway |
| `Outbound/` | DMZ → CorpNet (`SenderSide: Dmz`) | the DMZ interface services (FMS/TOMS/TLS/DSO) call the corporate systems | DMZ gateway | Corp gateway |

The folder names follow the fms-interface-simulator docs: **Inbound** = Corp → DMZ, **Outbound** = DMZ → Corp.

Each route folder holds `service.wsdl` (+ the `*.xsd` a WCF WSDL imports). `routes.json` names only the route
folder (`"Contract": "FC2FMS"`); the gateway takes the direction folder from the route's `SenderSide`, so a
contract cannot be used for the wrong direction.

## When the checks run

Both directions are checked by the gateway that **receives the caller's call, before anything is written to
SQLite** (the Outbox of `qrbridge.db`): the Corp gateway checks `Inbound`, the DMZ gateway checks `Outbound`. For a `Bridge`
operation, in this order:

1. SOAP version — one the WSDL has a binding for (WCF `basicHttpBinding` = SOAP 1.1 only).
2. SOAPAction — when the caller sends one (`SOAPAction` header for SOAP 1.1, Content-Type `action` for SOAP 1.2)
   and the WSDL's binding gives one, they must be equal (quotes ignored, case-sensitive). The real WCF/ASMX service
   dispatches on it, so a different action would fail there too. → mismatch: SOAP fault, **not queued**.
3. Operation and parameters — document/literal: the Body element is the operation's input element (name **and**
   namespace) and is valid against the XSD; RPC/encoded: the operation element is in the `soap:body` namespace and
   its children are exactly the WSDL parts, unqualified, simple values. → mismatch: SOAP fault, **not queued**.
4. Business message type — `MESSAGE/@TYPE` must be in the operation's `AllowedTypes`. → otherwise the profile's
   `Rejected` reply (`RETURN_CODE 1597` / `"1597"`), **not queued**.

At startup the gateway loads every contract (`Ingress/Validation/ContractCatalog.cs`) and refuses to start if a contract is
missing or invalid, or a route lists an operation its WSDL does not have. Decision 21 still holds: the gateway serves
no WSDL, XSD or help page; these files are read from disk only, with DTDs off and nothing external resolved (the
`schemaLocation` URLs in the WCF WSDLs are never fetched; the `*.xsd` files next to them are used instead).

## `Inbound/` — CorpNet → DMZ

Source: the fms-interface-simulator, `simulator/FMSServiceProxies/Service References/*` (the WSDLs its proxies were
generated from), copied unchanged except where noted. Allowed message types: the simulator's templates and its
`docs/integrations/*.md` "Inbound" lists.

| Folder | Source | Note |
|---|---|---|
| FC2FMS, SSO2FMS, SSO2TOMS, SSO2TLS, SSO2DSO, FTC2FMS | `FMS_*Interface/*.wsdl` + `*.xsd` | WCF BasicHttpBinding (SOAP 1.1) |
| VZ2TLS | `VZN2TLSService/VZ2TLSInterface.wsdl` | ASMX, inline schema, SOAP 1.1 |
| XA2FMS, IR2BFC | `XA2FMSService/ECC_XAFMSService.wsdl`, `IR2BFCService/ECC_BFCWebService.wsdl` | ASMX, inline schema, SOAP 1.1 and 1.2 |
| *-Legacy | `*Service/RR_*Service.wsdl` | SOAP Toolkit RPC/encoded |
| DSS2FMS | **derived** from `RR_FODFMSService.wsdl` | Same contract (DSS reuses the FOD proxy); service name changed to `RR_DSSFMSService`. Replace with the real file when captured. |

Missing: the WCF WSDL of `FOD2FMSInterface.svc` is not in the simulator repository, so the `FOD2FMS` route has no
`Contract` and its calls are not checked against a WSDL (the allow-list still applies). Capture it from the real
service, add `Inbound/FOD2FMS/` and set `"Contract": "FOD2FMS"` in `routes.json`.

## `Outbound/` — DMZ → CorpNet

The fms-interface-simulator has no contracts for this direction (it only *calls* FMS; its docs list the Outbound
message types it reads from the logs). Source: workspace-master-v2 `source-code/6-dmz-outbound-interfaces` — the
DMZ Windows services and the `wsdl.exe` client proxies they were built with. Every derived file starts with a comment
naming its proxy and the URL it came from.

| Folder | Source | Note |
|---|---|---|
| FMS2FC | **derived** from `FMS_FMS2PDService/.../FC_FMS2FCInterface.vb` (`FMS2RRFCInterface.svc?wsdl`) | The PD copy of the FCR proxy: the 13 operations of `FMS_FMS2FCService` plus `PortalSyncRequest`, `PortalMoveDownload` |
| FMS2FOD | **derived** from `FMS_FMS2FODService/.../FOD_FMS2FODInterface.vb` (`FMSRRFODInterface.svc?wsdl`) | |
| FMS2SSO, TLS2SSO, TOMS2SSO, DSO2SSO | **derived** from `SSO_*Interface.vb` in each service (`FMSRRInterface/*.svc?wsdl`) | |
| FMS2FSS | **derived** from `FMS_FMS2FSSService/.../FMS2FSSInterface.vb` | The captured `document/fms2fssinterface.wsdl` predates `fms2fssHighVoltage`; for `fms2fss` the derived file matches it element for element |
| FMS2Dashboard | `FMS_FMS2FSSService/document/fms2dashboard.wsdl` | **Captured**, copied unchanged |
| FMS2FTC, FMS2VR, FMS2SSLog | **derived** from `FMS2FTCInterface.vb`, `SSO_FMS2VRInterface.vb`, `FMS2SSLogInterface.vb` | |

Derived files are document/literal wrapped, SOAP 1.1 only (what the proxies send), with the exact operation and
parameter names, namespaces and SOAPActions from the proxy attributes. Replace each with the real WSDL
(`GET <url>?wsdl` on the corporate service) when it is captured.

Allowed message types were traced in each DMZ service's code: a COM method (e.g. `CreateCard`) builds
`<MESSAGE TYPE="CARD_CREATE">` and `SendTo<X>` picks the proxy operation; the `DownloadXML` entry points map the
same types to the same operations. They agree with the Outbound lists in the simulator's `docs/integrations/*.md`
(e.g. `CARD_CREATE`, `RFP_DO_RESPONSE`, `ISSUE_WORK_PERMIT`, `DO_FAULT_RESPONSE`, `REPLACE_CERTIFIED_TAG`,
`TLS_ISSUE_ORDER`, `TOMS_ISSUE_ORDER`, `DSO_ISSUE_ORDER`, `GET_FAULT_CORRELATION`), with one difference: the docs list
`CARD_CUTOUT`, but the FCR service sends a cut-out as `CARD_ACTIVATION` ("activate and cutout card"), so only
`CARD_ACTIVATION` is accepted. Never sent, so not listed: FOD `RequestCrew` (its case is commented out) and DSO
`SendPage` (no operation on the DSO proxy).

Not covered: RTF `GetPQForFeeders` (no proxy or WSDL anywhere), Maximo (not SOAP), Verizon (internet, not CorpNet).