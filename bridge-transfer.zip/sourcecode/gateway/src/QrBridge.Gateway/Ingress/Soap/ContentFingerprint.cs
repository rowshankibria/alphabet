using System.Text;
using System.Xml;
using QrBridge.Shared;

namespace QrBridge.Gateway.Ingress.Soap;

/// <summary>
/// The content fingerprint that recognises a caller's retry (decision D5, D38): a retry is a new HTTP call whose
/// per-send fields (MSG_ID, GMT_TIME_SENT, RRMsgID…) differ, but whose business content is the same.
///
/// SHA-256 of: service, operation, MESSAGE TYPE, the SOAP operation element as received, and its first parameter's
/// payload, with the route's FingerprintIgnore names removed wherever they are an attribute or element. Whitespace is
/// kept (PreserveWhitespace), so it errs on "too wide" (a retry missed) rather than "too narrow" (two real messages
/// taken for one). SOAP headers are left out: a WCF caller's WS-Addressing MessageID changes on every call.
/// Read-only: it parses its own copy of the body and never changes it.
/// </summary>
public static class ContentFingerprint
{
    private const string FormatTag = "QrBridge content fingerprint v1";

    /// <returns>Lower-case hex SHA-256, or null when the body or its payload cannot be read safely (never attached).</returns>
    public static string? Compute(string service, string? businessType, byte[] body, IReadOnlyCollection<string> ignore,
                                  long maxCharacters)
    {
        var ignored = new HashSet<string>(ignore, StringComparer.Ordinal);
        XmlElement? operation;
        try
        {
            var envelope = SafeXml.Load(body, maxCharacters, preserveWhitespace: true).DocumentElement;
            var soapBody = envelope is null ? null : XmlHelpers.ChildElement(envelope, "Body", envelope.NamespaceURI);
            operation = soapBody is null ? null : XmlHelpers.FirstChildElement(soapBody);
        }
        catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
        {
            return null;
        }
        if (operation is null) return null;

        // The FMS payload is XML text inside the first parameter: count it once, in its cleaned form.
        string payload = "";
        var parameter = XmlHelpers.FirstChildElement(operation);
        if (parameter is not null && !HasElementChildren(parameter))
        {
            if (Payload(parameter.InnerText, ignored, maxCharacters) is not { } cleaned) return null;
            payload = cleaned;
            parameter.InnerText = "";
        }
        RemoveIgnored(operation, ignored);

        var text = new StringBuilder();
        foreach (string part in new[] { FormatTag, service, operation.LocalName, businessType ?? "", operation.OuterXml, payload })
            text.Append(part.Length).Append(':').Append(part).Append('\n'); // length-prefixed: parts cannot run into each other
        return Hashing.Sha256Hex(Encoding.UTF8.GetBytes(text.ToString()));
    }

    /// <summary>The payload with the ignored names removed; plain text as is; null when it looks like XML but is not.</summary>
    private static string? Payload(string text, HashSet<string> ignored, long maxCharacters)
    {
        if (!text.TrimStart().TrimStart('﻿').StartsWith('<')) return text;
        try
        {
            var root = SafeXml.LoadText(text.Trim().TrimStart('﻿'), maxCharacters, preserveWhitespace: true).DocumentElement;
            if (root is null) return null;
            RemoveIgnored(root, ignored);
            return root.OuterXml;
        }
        catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
        {
            return null;
        }
    }

    private static void RemoveIgnored(XmlElement root, HashSet<string> ignored)
    {
        if (ignored.Count == 0) return;
        foreach (var element in root.GetElementsByTagName("*").Cast<XmlElement>().Prepend(root).ToList())
        {
            if (element != root && ignored.Contains(element.LocalName))
            {
                element.ParentNode?.RemoveChild(element);
                continue;
            }
            foreach (var attribute in element.Attributes.Cast<XmlAttribute>().Where(a => ignored.Contains(a.LocalName)).ToList())
                element.Attributes.Remove(attribute);
        }
    }

    private static bool HasElementChildren(XmlElement element)
    {
        foreach (XmlNode node in element.ChildNodes)
            if (node is XmlElement)
                return true;
        return false;
    }
}
