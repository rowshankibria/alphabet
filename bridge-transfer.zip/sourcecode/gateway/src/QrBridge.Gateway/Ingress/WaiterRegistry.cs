namespace QrBridge.Gateway.Ingress;

/// <summary>
/// The held RoundTrip callers on this gateway, by the MessageId they wait for (several when a retry is attached to
/// the same message). Only a speed-up: a held caller also re-reads the Outbox every few seconds, so a missed wake-up
/// delays an answer, never loses it. In memory, so IIS must run one worker process for the gateway (no web garden).
/// </summary>
public sealed class WaiterRegistry
{
    private readonly Dictionary<Guid, HashSet<Waiter>> _waiters = [];
    private readonly Lock _lock = new();

    /// <summary>Held callers right now.</summary>
    public int Count
    {
        get { lock (_lock) return _waiters.Values.Sum(w => w.Count); }
    }

    /// <summary>Waits for <paramref name="messageId"/> until disposed. Register before reading the Outbox, then wait.</summary>
    public Waiter Register(Guid messageId)
    {
        var waiter = new Waiter(messageId, Remove);
        lock (_lock)
        {
            if (!_waiters.TryGetValue(messageId, out var set)) _waiters[messageId] = set = [];
            set.Add(waiter);
        }
        return waiter;
    }

    /// <summary>An answer for <paramref name="messageId"/> was stored: every caller waiting for it reads the Outbox again.</summary>
    public void Wake(Guid messageId)
    {
        Waiter[] woken;
        lock (_lock) woken = _waiters.TryGetValue(messageId, out var set) ? [.. set] : [];
        foreach (var waiter in woken) waiter.Signal();
    }

    private void Remove(Waiter waiter)
    {
        lock (_lock)
        {
            if (_waiters.TryGetValue(waiter.MessageId, out var set) && set.Remove(waiter) && set.Count == 0)
                _waiters.Remove(waiter.MessageId);
        }
    }
}
