using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Exceptions;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;

namespace QrBridge.Gateway.Ingress;

/// <summary>
/// The ONE place where messages enter the bridge: callers' Requests (SenderEndpoint) and this side's Receipts and
/// Replies (AnswerWriter).
///
/// Request: same content in the retry window? (attach, or count) -> backlog check. Then, for every kind: next sequence
/// -> serialize the message -> insert into Outbox -> commit -> ring the Outbox doorbell (all but the doorbell in one
/// transaction). The caller only gets its reply after the commit, so an accepted call is never lost.
/// </summary>
public sealed class OutboxWriter(
    IDbContextFactory<BridgeDbContext> factory,
    MessageSerializer serializer,
    RouteTable routes,
    BridgeSignals signals,
    RetryCounters retries,
    IOptions<BridgeOptions> bridgeOptions,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<OutboxWriter> logger)
{
    private const int MaxBusinessTypeLength = 256;

    private readonly BridgeOptions _bridge = bridgeOptions.Value;
    private readonly GatewayOptions _gw = gatewayOptions.Value;

    /// <summary>
    /// Queues one caller request: <paramref name="header"/> describes it (service, operation, path, SOAPAction,
    /// Content-Type, label, content fingerprint) and <paramref name="body"/> is the SOAP body exactly as received. The
    /// id, direction, sequence and time are set here. Throws <see cref="BridgeBacklogFullException"/> when the Outbox
    /// is full.
    /// </summary>
    /// <param name="attachRetries">
    /// When a Request with the same <see cref="MessageHeader.ContentFingerprint"/> was queued within
    /// Gateway:RetryWindowMinutes, return that message instead of queuing a second one (decision D37). The check and the
    /// insert share one write transaction (SQLite allows one at a time), so identical calls at the same moment make
    /// one row.
    /// </param>
    public async Task<EnqueueResult> EnqueueAsync(MessageHeader header, byte[] body, bool attachRetries = false,
                                                  CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(header);
        ArgumentNullException.ThrowIfNull(body);

        var messageId = Guid.NewGuid();
        var direction = _bridge.SendDirection;
        string businessType = header.BusinessType.Length > MaxBusinessTypeLength
            ? header.BusinessType[..MaxBusinessTypeLength]
            : header.BusinessType;

        await using var db = await factory.CreateDbContextAsync(ct);
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        bool request = header.Kind == MessageKind.Request;

        Guid? sameContent = null;
        if (request && header.ContentFingerprint is { } fingerprint)
        {
            var since = DateTime.UtcNow.AddMinutes(-_gw.RetryWindowMinutes);
            // D63: a message the far side surely did not carry out (Expired, NotDelivered, Rejected) is not a retry target:
            // the caller still wants it, so it is queued again with a fresh expiry.
            sameContent = (await db.Outbox
                .Where(m => m.ContentFingerprint == fingerprint && m.Kind == MessageKind.Request &&
                            m.Direction == direction && m.CreatedUtc >= since &&
                            m.ServiceStatus != OutboxServiceStatus.Expired && m.ServiceStatus != OutboxServiceStatus.NotDelivered &&
                            m.ServiceStatus != OutboxServiceStatus.Rejected)
                .OrderBy(m => m.CreatedUtc).ThenBy(m => m.Sequence)
                .Select(m => new { m.MessageId })
                .FirstOrDefaultAsync(ct))?.MessageId;

            // Before the backlog check: a retry of a message already queued adds nothing to the backlog.
            if (sameContent is { } firstId && attachRetries)
            {
                retries.CountAttached();
                logger.LogInformation("Attached a retry of {Service}.{Operation} {BusinessType} to {MessageId} (same content within {Window} min)",
                    header.ServiceName, header.Operation, businessType, firstId, _gw.RetryWindowMinutes);
                return new EnqueueResult(firstId, Attached: true);
            }
        }

        // Counted inside the write transaction (BEGIN IMMEDIATE: one writer at a time), so concurrent calls
        // cannot all see room and overfill the queue. Only Requests count, and only Requests are refused (decision D47):
        // a Receipt or a Reply is never lost to a full Outbox, and answers never make this side refuse its callers.
        if (request)
        {
            int backlog = await db.Outbox.CountAsync(m => m.Kind == MessageKind.Request &&
                                                          (m.LightStatus == OutboxLightStatus.Pending ||
                                                           m.LightStatus == OutboxLightStatus.Sending ||
                                                           m.LightStatus == OutboxLightStatus.Aired), ct);
            if (backlog >= _gw.MaxBacklog) throw new BridgeBacklogFullException(backlog, _gw.MaxBacklog);

            // D78: a route may also have its own, smaller backlog, so one flooded service cannot fill the Outbox.
            if (routes.FindByName(header.ServiceName)?.MaxBacklog is { } routeMax)
            {
                int routeBacklog = await db.Outbox.CountAsync(m => m.Kind == MessageKind.Request && m.ServiceName == header.ServiceName &&
                                                                   (m.LightStatus == OutboxLightStatus.Pending ||
                                                                    m.LightStatus == OutboxLightStatus.Sending ||
                                                                    m.LightStatus == OutboxLightStatus.Aired), ct);
                if (routeBacklog >= routeMax) throw new BridgeBacklogFullException(routeBacklog, routeMax);
            }
        }

        var (sequence, runId) = await NextSequenceAsync(db, direction, ct);

        header = header with
        {
            MessageId = messageId,
            Direction = direction,
            BusinessType = businessType,
            PayloadFormat = request ? header.PayloadFormat : PayloadFormat.RawSoap,
            // D73: answers always go on the light first; a Request keeps its route's class.
            Priority = request ? header.Priority : MessagePriority.Answer,
            Compression = Compression.Brotli,
            Sequence = sequence,
            SequenceRunId = runId,
            CatalogFingerprint = routes.CatalogFingerprint,
            CreatedUtc = DateTime.UtcNow,
        };

        byte[] messageBytes = serializer.Serialize(header, body);

        db.Outbox.Add(new OutboxMessage
        {
            MessageId = messageId,
            Direction = direction,
            ServiceName = header.ServiceName,
            Operation = header.Operation,
            BusinessType = businessType.Length == 0 ? null : businessType,
            Sequence = sequence,
            SequenceRunId = runId,
            PayloadFormat = header.PayloadFormat,
            Priority = header.Priority,
            Kind = header.Kind,
            CorrelationId = header.CorrelationId,
            ContentFingerprint = header.ContentFingerprint,
            ExpiresUtc = header.ExpiresUtc,
            PayloadSize = body.Length,
            MessageBytes = messageBytes,
            MessageHash = Hashing.Sha256Hex(messageBytes),
            LightStatus = OutboxLightStatus.Pending,
            LightUpdatedUtc = header.CreatedUtc,
            ServiceStatus = OutboxServiceStatus.Waiting,
            ServiceUpdatedUtc = header.CreatedUtc,
            CreatedUtc = header.CreatedUtc,
        });

        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);

        signals.Outbox.Set();
        logger.LogInformation("Queued {Kind} {Service}.{Operation} {BusinessType} as {MessageId} seq {Sequence} ({Bytes} bytes packed)",
            header.Kind, header.ServiceName, header.Operation, businessType, messageId, sequence, messageBytes.Length);
        if (sameContent is { } earlier)
        {
            retries.CountSameContentQueued();
            logger.LogInformation("{MessageId} has the same content as {Earlier} (within {Window} min); queued again because {Service}.{Operation} does not recognise retries",
                messageId, earlier, _gw.RetryWindowMinutes, header.ServiceName, header.Operation);
        }
        return new EnqueueResult(messageId, Attached: false);
    }

    /// <summary>
    /// Atomic increment inside the caller's transaction (UPDATE ... RETURNING). The counter's run id is set on its
    /// first use and then never changes (see <see cref="SequenceCounter.RunId"/>).
    /// </summary>
    private static async Task<(long Sequence, Guid RunId)> NextSequenceAsync(BridgeDbContext db, Direction direction, CancellationToken ct)
    {
        var connection = db.Database.GetDbConnection();
        var transaction = db.Database.CurrentTransaction!.GetDbTransaction();
        string newRunId = Guid.NewGuid().ToString("D"); // stored as lower-case text, like every Guid (SqliteConventions)

        await using (var update = connection.CreateCommand())
        {
            update.Transaction = transaction;
            update.CommandText = "UPDATE SequenceCounter SET LastValue = LastValue + 1, RunId = COALESCE(RunId, $run) " +
                                 "WHERE Direction = $d RETURNING LastValue, RunId;";
            AddParameter(update, "$d", direction.ToString());
            AddParameter(update, "$run", newRunId);

            await using var reader = await update.ExecuteReaderAsync(ct);
            if (await reader.ReadAsync(ct))
                return (reader.GetInt64(0), Guid.Parse(reader.GetString(1)));
        }

        // Row missing (shouldn't happen: it is seeded) — create it, starting a new run.
        await using var insert = connection.CreateCommand();
        insert.Transaction = transaction;
        insert.CommandText = "INSERT INTO SequenceCounter (Direction, LastValue, RunId) VALUES ($d, 1, $run);";
        AddParameter(insert, "$d", direction.ToString());
        AddParameter(insert, "$run", newRunId);
        await insert.ExecuteNonQueryAsync(ct);
        return (1, Guid.Parse(newRunId));
    }

    private static void AddParameter(System.Data.Common.DbCommand command, string name, object value)
    {
        var p = command.CreateParameter();
        p.ParameterName = name;
        p.Value = value;
        command.Parameters.Add(p);
    }
}

/// <summary>The message a call is now part of.</summary>
/// <param name="MessageId">The new message, or the first message with the same content when <paramref name="Attached"/>.</param>
/// <param name="Attached">A caller's retry: nothing was queued, the call belongs to an existing message.</param>
public sealed record EnqueueResult(Guid MessageId, bool Attached);
