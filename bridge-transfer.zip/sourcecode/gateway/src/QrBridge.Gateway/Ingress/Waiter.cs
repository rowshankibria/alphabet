namespace QrBridge.Gateway.Ingress;

/// <summary>One held caller in the <see cref="WaiterRegistry"/>. Dispose it when the call ends, however it ends.</summary>
public sealed class Waiter : IDisposable
{
    private readonly SemaphoreSlim _signal = new(0, 1);
    private readonly Action<Waiter> _onDispose;

    internal Waiter(Guid messageId, Action<Waiter> onDispose)
    {
        MessageId = messageId;
        _onDispose = onDispose;
    }

    public Guid MessageId { get; }

    /// <summary>Returns true when woken (a wake-up since the last wait counts), false after <paramref name="timeout"/>.</summary>
    public Task<bool> WaitAsync(TimeSpan timeout, CancellationToken ct) => _signal.WaitAsync(timeout, ct);

    internal void Signal()
    {
        try { _signal.Release(); }
        catch (SemaphoreFullException) { /* already woken and not yet read: one wake-up is enough */ }
        catch (ObjectDisposedException) { /* the call just ended */ }
    }

    public void Dispose()
    {
        _onDispose(this);
        _signal.Dispose();
    }
}
