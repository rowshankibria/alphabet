namespace QrBridge.Gateway.Ingress;

/// <summary>
/// How often the Sender part saw a caller's retry since start-up, for /health (decision D37). An attach leaves no
/// Outbox row, so these counts and the log lines are its only trace. Evidence for the gate "fingerprint checked against
/// real retries": a Bridge route's repeats are counted, never attached.
/// </summary>
public sealed class RetryCounters
{
    private long _attached;
    private long _sameContentQueued;

    public DateTime SinceUtc { get; } = DateTime.UtcNow;

    /// <summary>Retries attached to the first message (no new row).</summary>
    public long Attached => Interlocked.Read(ref _attached);

    /// <summary>Calls with the content of a message in the window, queued again because their route does not recognise retries.</summary>
    public long SameContentQueued => Interlocked.Read(ref _sameContentQueued);

    internal void CountAttached() => Interlocked.Increment(ref _attached);

    internal void CountSameContentQueued() => Interlocked.Increment(ref _sameContentQueued);
}
