using QrBridge.Gateway.Ingress.Soap;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;

namespace QrBridge.Gateway.Ingress.Validation;

/// <summary>
/// The WSDL contracts of the listed services, loaded and cross-checked against the route catalogue once at startup.
/// A route's contract lives in Contracts/{direction}/{ServiceRoute.Contract}/, where the direction folder follows
/// its SenderSide: Inbound (Corp → DMZ, callers on CorpNet) or Outbound (DMZ → Corp, callers in the DMZ).
/// An invalid or missing contract fails the start, like an invalid catalogue.
/// </summary>
public sealed class ContractCatalog
{
    public const string FolderName = "Contracts";

    private readonly Dictionary<string, ServiceContract> _byService = new(StringComparer.OrdinalIgnoreCase);

    /// <param name="root">The Contracts folder (normally {content root}/Contracts).</param>
    public ContractCatalog(RouteTable routes, string root)
    {
        var problems = new List<string>();
        var loaded = new Dictionary<string, ServiceContract>(StringComparer.OrdinalIgnoreCase);

        foreach (var service in routes.Services)
        {
            if (string.IsNullOrWhiteSpace(service.Contract)) continue;

            string direction = DirectionFolder(service.SenderSide);
            string relative = $"{direction}/{service.Contract}";
            if (!loaded.TryGetValue(relative, out var contract))
            {
                try
                {
                    contract = ServiceContract.Load(Path.Combine(root, direction, service.Contract), relative);
                    loaded[relative] = contract;
                }
                catch (InvalidDataException ex)
                {
                    problems.Add($"{service.Name}: {ex.Message}");
                    continue;
                }
            }

            foreach (var (operation, route) in service.Operations)
            {
                if (route.Mode == OperationMode.Reject) continue;
                if (!contract.Operations.TryGetValue(operation, out var op))
                    problems.Add($"{service.Name}.{operation} is not an operation of contract '{contract.Name}'.");
                else if (op.Style != service.Style)
                    problems.Add($"{service.Name} has Style {service.Style} but contract '{contract.Name}' says {operation} is {op.Style}.");
            }

            _byService[service.Name] = contract;
        }

        if (problems.Count > 0)
            throw new InvalidOperationException("Invalid service contracts (Contracts folder / routes.json):" + Environment.NewLine +
                                                string.Join(Environment.NewLine, problems.Select(p => " - " + p)));
    }

    /// <summary>Contract of a listed service, or null when it has none (it is then not checked against a WSDL).</summary>
    public ServiceContract? For(ServiceRoute? service) =>
        service is not null && _byService.TryGetValue(service.Name, out var contract) ? contract : null;

    /// <summary>"Inbound" (Corp → DMZ) for services whose callers are on CorpNet, "Outbound" (DMZ → Corp) for callers in the DMZ.</summary>
    public static string DirectionFolder(BridgeSide senderSide) => senderSide == BridgeSide.Corp ? "Inbound" : "Outbound";

    public int Count => _byService.Count;

    /// <summary>Null when the request matches the service's WSDL, or the service has no contract; else the reason.</summary>
    public string? Check(ServiceRoute? service, SoapRequest request) => For(service)?.Check(request);
}
