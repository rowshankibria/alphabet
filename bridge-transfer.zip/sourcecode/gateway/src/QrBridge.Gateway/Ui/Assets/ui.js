// QrBridge read-only UI: theme switch, local times, copy, wrap, XML colouring, clickable rows, filters, auto-refresh.
// Plain JavaScript, no framework, nothing from another site (the content security policy allows only this file).
// It never builds HTML from text: payloads are only ever set with textContent, so they cannot become markup.
(function () {
  'use strict';

  var root = document.documentElement;

  function save(key, value) {
    try {
      if (value === null) window.localStorage.removeItem(key); else window.localStorage.setItem(key, value);
    } catch (e) { /* storage blocked: the choice lasts for this page only */ }
  }

  function read(key) {
    try { return window.localStorage.getItem(key); } catch (e) { return null; }
  }

  // ---- Light / dark theme (theme.js picked the first one) ----
  document.querySelectorAll('[data-theme-toggle]').forEach(function (button) {
    button.addEventListener('click', function () {
      var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', next);
      save('qrbridge-ui-theme', next);
    });
  });

  // ---- Times: the server writes them exactly, in Ui:TimeZone (Eastern); the tooltip adds UTC and "3 minutes ago" ----
  var relative = window.Intl && Intl.RelativeTimeFormat ? new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' }) : null;

  function ago(date) {
    if (!relative) return '';
    var seconds = Math.round((date.getTime() - Date.now()) / 1000);
    var abs = Math.abs(seconds);
    if (abs < 60) return relative.format(seconds, 'second');
    if (abs < 3600) return relative.format(Math.round(seconds / 60), 'minute');
    if (abs < 86400) return relative.format(Math.round(seconds / 3600), 'hour');
    return relative.format(Math.round(seconds / 86400), 'day');
  }

  function showTimes() {
    document.querySelectorAll('time[datetime]').forEach(function (el) {
      var date = new Date(el.getAttribute('datetime'));
      if (isNaN(date.getTime())) return;
      if (!el.hasAttribute('data-utc')) el.setAttribute('data-utc', el.getAttribute('title') || '');
      var since = ago(date);
      el.title = el.getAttribute('data-utc') + (since ? ' · ' + since : '');
    });
  }

  showTimes();
  window.setInterval(showTimes, 30000);

  // ---- Copy, wrap, clickable rows ----
  function copyFallback(text) {
    var area = document.createElement('textarea');
    area.value = text;
    area.setAttribute('readonly', '');
    area.className = 'offscreen';
    document.body.appendChild(area);
    area.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(area);
    return ok;
  }

  function copy(text, button) {
    var label = button.getAttribute('data-label') || button.textContent;
    button.setAttribute('data-label', label);
    function done(ok) {
      button.textContent = ok ? 'Copied' : 'Copy failed';
      window.setTimeout(function () { button.textContent = label; }, 1500);
    }
    // The clipboard API needs https (or localhost); plain http on the intranet falls back to execCommand.
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(copyFallback(text)); });
    } else {
      done(copyFallback(text));
    }
  }

  document.addEventListener('click', function (event) {
    var target = event.target;
    if (!(target instanceof Element)) return;

    var copyButton = target.closest('[data-copy]');
    if (copyButton) {
      var source = document.getElementById(copyButton.getAttribute('data-copy'));
      if (source) copy(source.textContent, copyButton);
      return;
    }

    var wrapButton = target.closest('[data-wrap]');
    if (wrapButton) {
      var code = document.getElementById(wrapButton.getAttribute('data-wrap'));
      var pre = code && code.closest('pre');
      if (pre) {
        pre.classList.toggle('wrap');
        wrapButton.setAttribute('aria-pressed', pre.classList.contains('wrap') ? 'true' : 'false');
      }
      return;
    }

    var row = target.closest('tr[data-href]');
    if (row && !target.closest('a, button, input, select, label, summary')) {
      if (window.getSelection && String(window.getSelection()).length > 0) return; // the viewer is selecting text
      window.location.href = row.getAttribute('data-href');
    }
  });

  // ---- Filters and page size: a changed choice applies at once (a new page size starts again at page 1) ----
  document.querySelectorAll('select[data-autosubmit]').forEach(function (select) {
    select.addEventListener('change', function () {
      if (!select.form) return;
      if (select.hasAttribute('data-reset-page')) {
        var page = select.form.querySelector('input[name="p"]');
        if (page) page.value = '1';
      }
      select.form.submit();
    });
  });

  // ---- XML colouring (tags, attribute names and values, comments), built from text nodes only ----
  var TOKEN = /<!--[\s\S]*?-->|<!\[CDATA\[[\s\S]*?\]\]>|<\/?[A-Za-z_][\w:.\-]*(?:\s+[\w:.\-]+\s*=\s*(?:"[^"]*"|'[^']*'))*\s*\/?>/g;
  var ATTRIBUTE = /(\s+)([\w:.\-]+)(\s*=\s*)("[^"]*"|'[^']*')/g;
  var MAX_COLOURED = 500000; // characters; longer texts stay plain so the page stays quick

  function add(parent, cssClass, text) {
    if (!text) return;
    if (!cssClass) { parent.appendChild(document.createTextNode(text)); return; }
    var span = document.createElement('span');
    span.className = cssClass;
    span.textContent = text;
    parent.appendChild(span);
  }

  function colourTag(fragment, token) {
    if (token.lastIndexOf('<!--', 0) === 0) { add(fragment, 'x-com', token); return; }
    if (token.lastIndexOf('<![CDATA[', 0) === 0) { add(fragment, 'x-cdata', token); return; }
    var parts = /^(<\/?)([^\s\/>]+)([\s\S]*?)(\s*\/?>)$/.exec(token);
    if (!parts) { add(fragment, null, token); return; }
    add(fragment, 'x-punc', parts[1]);
    add(fragment, 'x-tag', parts[2]);
    var attributes = parts[3];
    var last = 0;
    var match;
    ATTRIBUTE.lastIndex = 0;
    while ((match = ATTRIBUTE.exec(attributes))) {
      add(fragment, null, match[1]);
      add(fragment, 'x-attr', match[2]);
      add(fragment, 'x-punc', match[3]);
      add(fragment, 'x-val', match[4]);
      last = ATTRIBUTE.lastIndex;
    }
    add(fragment, null, attributes.slice(last));
    add(fragment, 'x-punc', parts[4]);
  }

  function colour(code) {
    var text = code.textContent;
    if (text.length > MAX_COLOURED) return;
    var fragment = document.createDocumentFragment();
    var last = 0;
    var match;
    TOKEN.lastIndex = 0;
    while ((match = TOKEN.exec(text))) {
      add(fragment, null, text.slice(last, match.index));
      colourTag(fragment, match[0]);
      last = TOKEN.lastIndex;
    }
    add(fragment, null, text.slice(last));
    code.textContent = '';
    code.appendChild(fragment);
  }

  document.querySelectorAll('code.lang-xml').forEach(colour);

  // ---- Auto-refresh (overview and lists): off by default, remembered per page; keeps the scroll position ----
  var scrollKey = 'qrbridge-ui-scroll:' + window.location.href;
  try {
    var y = window.sessionStorage.getItem(scrollKey);
    if (y !== null) {
      window.sessionStorage.removeItem(scrollKey);
      window.scrollTo(0, parseInt(y, 10) || 0);
    }
  } catch (e) { /* storage blocked */ }

  var refresh = document.querySelector('input[data-autorefresh]');
  if (refresh) {
    var key = 'qrbridge-ui-refresh:' + window.location.pathname;
    var seconds = Math.max(2, parseInt(refresh.getAttribute('data-autorefresh'), 10) || 10);
    var timer = null;

    var schedule = function () {
      window.clearTimeout(timer);
      if (refresh.checked) timer = window.setTimeout(tick, seconds * 1000);
    };
    var tick = function () {
      var selecting = window.getSelection && String(window.getSelection()).length > 0;
      if (document.hidden || selecting) { schedule(); return; }
      try { window.sessionStorage.setItem(scrollKey, String(window.scrollY)); } catch (e) { /* storage blocked */ }
      window.location.reload();
    };

    refresh.checked = read(key) === 'on';
    refresh.addEventListener('change', function () {
      save(key, refresh.checked ? 'on' : null);
      schedule();
    });
    schedule();
  }
})();
