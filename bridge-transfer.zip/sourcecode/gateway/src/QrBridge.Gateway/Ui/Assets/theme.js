// QrBridge read-only UI: pick the theme before the page paints (loaded in <head>, not deferred), so there is no flash.
// The viewer's choice (ui.js toggle) wins; otherwise Windows' light/dark setting.
(function () {
  'use strict';
  var stored = null;
  try { stored = window.localStorage.getItem('qrbridge-ui-theme'); } catch (e) { /* storage blocked: follow the system */ }
  var dark = stored ? stored === 'dark'
    : !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
})();
