using System.Globalization;
using System.Text;
using QrBridge.Shared;

namespace QrBridge.Gateway.Ui;

/// <summary>How values are written on the pages: times, ids, sizes, directions, statuses and their colours.</summary>
public static class Display
{
    public const string None = "—";

    /// <summary>Every time on the pages is written this way (US format, 12-hour clock): 11/25/2026 05:05:39 PM.</summary>
    public const string UsDateTime = "MM/dd/yyyy hh:mm:ss tt";

    /// <summary>The time in UTC, for tooltips: "11/25/2026 10:05:39 PM UTC".</summary>
    public static string Utc(DateTime? time) =>
        time is { } t ? t.ToUniversalTime().ToString(UsDateTime, CultureInfo.InvariantCulture) + " UTC" : None;

    /// <summary>ISO 8601 with "Z", for &lt;time datetime&gt;: the browser shows it in the viewer's local time.</summary>
    public static string Iso(DateTime time) => DateTime.SpecifyKind(time.ToUniversalTime(), DateTimeKind.Utc).ToString("O", CultureInfo.InvariantCulture);

    public static string Short(Guid id) => id.ToString("D")[..8];

    public static string Bytes(long bytes) => bytes switch
    {
        < 1024 => $"{bytes:N0} bytes",
        < 1024 * 1024 => $"{bytes / 1024.0:N1} KB ({bytes:N0} bytes)",
        _ => $"{bytes / (1024.0 * 1024):N2} MB ({bytes:N0} bytes)",
    };

    public static string Direction(Direction direction) =>
        direction == QrBridge.Shared.Direction.CorpToDmz ? "Corp → DMZ (Inbound)" : "DMZ → Corp (Outbound)";

    public static string Side(BridgeSide side) => side == BridgeSide.Corp ? "Corp" : "DMZ";

    /// <summary>What a kind of message is, in business words (the kind chips' tooltip).</summary>
    public static string Meaning(MessageKind kind) => kind switch
    {
        MessageKind.Request => "Request: a caller's call to a service on the other side.",
        MessageKind.Receipt => "Receipt: it arrived safely. The message reached the other side and is saved there.",
        MessageKind.Reply => "Reply: what the real service did with a request (its answer), or why it was not sent to it.",
        _ => "Heartbeat: \"still here\", sent when there is nothing else to send.",
    };

    /// <summary>One line of at most <paramref name="max"/> characters: whitespace runs become one space.</summary>
    public static string Collapse(string? text, int max)
    {
        if (string.IsNullOrWhiteSpace(text)) return "";
        var sb = new StringBuilder(Math.Min(text.Length, max + 1));
        bool space = false;
        foreach (char c in text)
        {
            if (char.IsWhiteSpace(c) || char.IsControl(c)) { space = sb.Length > 0; continue; }
            if (space) { sb.Append(' '); space = false; }
            sb.Append(c);
            if (sb.Length > max) break;
        }
        return sb.Length > max ? sb.ToString(0, max) + "…" : sb.ToString();
    }

    // ---- Statuses: the two groups of each row (decision D24), with a colour and their meaning in plain words. ----

    public static StatusView Light(OutboxLightStatus status, string? comment, DateTime? updated) => status switch
    {
        OutboxLightStatus.Pending => new("Pending", Tone.Info, "Waiting to be shown on this side's screen.", comment, UpdatedUtc: updated),
        OutboxLightStatus.Sending => new("Sending", Tone.Info, "On the screen now (claimed by the QR sender).", comment, UpdatedUtc: updated),
        OutboxLightStatus.Aired => new("Aired", Tone.Info, "Shown on the screen; no Receipt (it arrived safely) from the far side yet. Sent again if none comes back in time.", comment, UpdatedUtc: updated),
        OutboxLightStatus.Received => new("Received", Tone.Good, "The far side's Receipt arrived: it is stored in the far Inbox.", comment, UpdatedUtc: updated),
        _ => new("Failed", Tone.Bad, "No Receipt (it arrived safely) from the far side after its last send, or it expired: an operator checks the screen, the camera and the QR apps.", comment, UpdatedUtc: updated),
    };

    /// <summary>Only a Request has a service outcome; this side's Receipts, Replies and Heartbeats never do.</summary>
    public static StatusView Service(MessageKind kind, OutboxServiceStatus status, int? http, string? comment, DateTime? updated)
    {
        if (kind != MessageKind.Request)
            return new(None, Tone.Neutral, "Not a Request: it is never posted to a service, so it has no service outcome.");
        return status switch
        {
            OutboxServiceStatus.Waiting => new("Waiting", Tone.Info, "No Reply from the far side yet.", comment, http, updated),
            OutboxServiceStatus.Answered => new("Answered", Tone.Good, "The real service on the far side accepted it.", comment, http, updated),
            OutboxServiceStatus.Unknown => new("Unknown", Tone.Warn, "It may have been processed on the far side; nobody knows. An operator checks.", comment, http, updated),
            OutboxServiceStatus.Refused => new("Refused", Tone.Bad, "The real service on the far side refused it, or did not process it.", comment, http, updated),
            OutboxServiceStatus.Expired => new("Expired", Tone.Warn, "It reached the far side after its expiry: not posted.", comment, http, updated),
            OutboxServiceStatus.NotDelivered => new("NotDelivered", Tone.Bad, "It surely never reached the real service: an operator may send it again.", comment, http, updated),
            OutboxServiceStatus.Rejected => new("Rejected", Tone.Bad, "It failed an arrival check on the far side: never delivered.", comment, http, updated),
            _ => new(status.ToString(), Tone.Neutral, "", comment, http, updated),
        };
    }

    public static StatusView Light(InboxLightStatus status, string? comment) => status == InboxLightStatus.Received
        ? new("Received", Tone.Good, "Arrived intact and acceptable.", comment)
        : new("Rejected", Tone.Bad, "Failed an arrival check (checksum, direction, catalogue, replay window, sequence number): never delivered.", comment);

    /// <summary>
    /// A Request's delivery to the real service on this side. Receipts, Replies and Heartbeats are read by this gateway
    /// instead (Pending = not read yet, Done = used); a Rejected row is never delivered.
    /// </summary>
    public static StatusView Service(MessageKind kind, InboxLightStatus light, InboxServiceStatus status, int? http, string? comment,
                                     DateTime? updated, string? result)
    {
        if (light == InboxLightStatus.Rejected)
            return new(None, Tone.Neutral, "Rejected on arrival: never delivered or used.");
        if (kind != MessageKind.Request)
            return status == InboxServiceStatus.Done
                ? new("Used", Tone.Good, "Read by this gateway (never posted to a service).", comment, http, updated, result)
                : new("Waiting to be read", Tone.Info, "Not read by this gateway yet.", comment, http, updated, result);
        return status switch
        {
            InboxServiceStatus.Pending => new("Pending", Tone.Info, "Waiting for delivery to the real service on this side.", comment, http, updated, result),
            InboxServiceStatus.Delivering => new("Delivering", Tone.Info, "Being posted to the real service now.", comment, http, updated, result),
            InboxServiceStatus.Done => new("Done", Tone.Good, "The real service accepted it.", comment, http, updated, result),
            InboxServiceStatus.Retrying => new("Retrying", Tone.Warn, "Nothing was sent (service unreachable); tried again after a backoff.", comment, http, updated, result),
            InboxServiceStatus.Unknown => new("Unknown", Tone.Warn, "It may have reached the service; the outcome is not known. An operator checks before any resend.", comment, http, updated, result),
            InboxServiceStatus.Refused => new("Refused", Tone.Bad, "The real service refused it (fault, non-zero return code, 4xx).", comment, http, updated, result),
            InboxServiceStatus.Expired => new("Expired", Tone.Warn, "It arrived after its expiry: not posted, the caller has given up.", comment, http, updated, result),
            _ => new("NotDelivered", Tone.Bad, "It surely never reached the service (no target, or out of tries).", comment, http, updated, result),
        };
    }

    /// <summary>The CSS class of a tone: tone-good, tone-bad…</summary>
    public static string Css(Tone tone) => "tone-" + tone.ToString().ToLowerInvariant();
}

/// <summary>One status of a row, as shown: its name, colour, plain-words meaning and what the row says about it.</summary>
/// <param name="Comment">LightComment or ServiceComment: why it is what it is. Never the payload.</param>
/// <param name="HttpStatus">The real service's HTTP status code, when there was one.</param>
/// <param name="Result">Inbox DownstreamResult: what the real service answered (RETURN_CODE, ERROR_MESSAGE, fault reason).</param>
public sealed record StatusView(string Name, Tone Tone, string Meaning, string? Comment = null, int? HttpStatus = null,
                                DateTime? UpdatedUtc = null, string? Result = null);
