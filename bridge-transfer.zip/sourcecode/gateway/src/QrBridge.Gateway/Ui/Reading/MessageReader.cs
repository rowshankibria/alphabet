using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Xml;
using Microsoft.Extensions.Options;
using QrBridge.Shared;
using QrBridge.Shared.Serialization;

namespace QrBridge.Gateway.Ui.Reading;

/// <summary>
/// Turns a stored message (MessageBytes: header + checksum + Brotli body) into something a person can read: the
/// header fields, the body as text, the same indented, and the business message inside the first SOAP parameter
/// (the FMS &lt;MESSAGE&gt; in sXML / XMLMsg, or the &lt;RESPONSE&gt; in SendToFMSResult) unescaped and indented.
/// Untrusted XML only through SafeXml (no DTD, no resolver, size cap). It never changes the bytes, and never logs them.
/// </summary>
public sealed class MessageReader(MessageSerializer serializer, IOptions<BridgeOptions> bridgeOptions)
{
    // Same bound the gateway uses when it reads a caller's request: twice the payload limit, in characters.
    private readonly long _maxCharacters = (long)bridgeOptions.Value.MaxPayloadBytes * 2 + 1024;

    /// <summary>Unpacks a stored message. An empty array (an Inbox row cleared after delivery, D77) gives no header and no body.</summary>
    public ReadableMessage Read(byte[]? messageBytes)
    {
        if (messageBytes is not { Length: > 0 }) return new ReadableMessage(null, null, null);
        try
        {
            var (header, body) = serializer.Deserialize(messageBytes);
            return new ReadableMessage(header, null, body.Length == 0 ? null : ReadContent(body));
        }
        catch (Exception ex) when (ex is InvalidDataException or IOException or ArgumentException or FormatException or OverflowException)
        {
            // Corrupt or of an older format: show what the header says, if it can be read at all.
            MessageHeader? header = null;
            try { header = MessageSerializer.PeekHeader(messageBytes); }
            catch (Exception peek) when (peek is InvalidDataException or IOException or ArgumentException or FormatException or OverflowException) { }
            return new ReadableMessage(header, $"The stored bytes cannot be unpacked: {ex.Message}", null);
        }
    }

    /// <summary>Any body as text: a SOAP envelope (with its first parameter read out), other XML, JSON or plain text.</summary>
    public ReadableContent ReadContent(byte[] bytes)
    {
        string text = Decode(bytes);
        string start = text.TrimStart('﻿', ' ', '\t', '\r', '\n');

        if (start.StartsWith('<'))
        {
            XmlDocument doc;
            try
            {
                doc = SafeXml.Load(bytes, _maxCharacters);
            }
            catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
            {
                return new ReadableContent(bytes.Length, text, null, null, null, $"Not shown as XML: {ex.Message}");
            }

            var (parameter, value) = FirstParameter(doc);
            var (payload, note) = value is null ? (null, null) : Payload(value);
            return new ReadableContent(bytes.Length, text, Indent(doc), parameter, payload, note);
        }

        if (start.StartsWith('{') || start.StartsWith('['))
        {
            try
            {
                var json = JsonNode.Parse(start, documentOptions: new JsonDocumentOptions { MaxDepth = 64 });
                return new ReadableContent(bytes.Length, text, json?.ToJsonString(new JsonSerializerOptions { WriteIndented = true }), null, null, null);
            }
            catch (JsonException) { /* plain text below */ }
        }

        return new ReadableContent(bytes.Length, text, null, null, null, null);
    }

    /// <summary>
    /// A SOAP envelope's Body → operation (or OpResponse) → its first parameter, when that holds text only: the FMS
    /// services carry their whole message as one escaped XML string there (sXML, XMLMsg, msgData, OpResult).
    /// </summary>
    private static (string? Name, string? Value) FirstParameter(XmlDocument doc)
    {
        var envelope = doc.DocumentElement;
        if (envelope is null || envelope.LocalName != "Envelope") return (null, null);
        var body = ChildElements(envelope).FirstOrDefault(e => e.LocalName == "Body" && e.NamespaceURI == envelope.NamespaceURI);
        var operation = body is null ? null : ChildElements(body).FirstOrDefault();
        var parameter = operation is null ? null : ChildElements(operation).FirstOrDefault();
        if (parameter is null || ChildElements(parameter).Any()) return (null, null);
        return (parameter.LocalName, parameter.InnerText);
    }

    /// <summary>The parameter's value: indented when it is XML; as it is otherwise (EchoString, a return code "0").</summary>
    private (string? Payload, string? Note) Payload(string value)
    {
        string trimmed = value.Trim().TrimStart('﻿');
        if (!trimmed.StartsWith('<')) return (value, null);
        try
        {
            return (Indent(SafeXml.LoadText(trimmed, _maxCharacters)), null);
        }
        catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
        {
            return (value, $"The message inside the parameter is not well-formed XML: {ex.Message}");
        }
    }

    private static IEnumerable<XmlElement> ChildElements(XmlElement parent) => parent.ChildNodes.OfType<XmlElement>();

    /// <summary>Indented copy for reading (comments and processing instructions are already dropped by SafeXml).</summary>
    private static string Indent(XmlDocument doc)
    {
        var settings = new XmlWriterSettings
        {
            Indent = true,
            IndentChars = "  ",
            NewLineChars = "\n",
            OmitXmlDeclaration = true,
            ConformanceLevel = ConformanceLevel.Fragment,
        };
        var sb = new StringBuilder();
        using (var writer = XmlWriter.Create(sb, settings))
        {
            foreach (XmlNode node in doc.ChildNodes)
                if (node is not XmlDeclaration) node.WriteTo(writer);
        }
        return sb.ToString();
    }

    /// <summary>UTF-8 unless a byte order mark says otherwise; invalid bytes show as �.</summary>
    private static string Decode(byte[] bytes)
    {
        using var reader = new StreamReader(new MemoryStream(bytes, writable: false), new UTF8Encoding(false), detectEncodingFromByteOrderMarks: true);
        return reader.ReadToEnd();
    }
}

/// <param name="Header">The message header; null when the bytes are empty (cleared after delivery) or unreadable.</param>
/// <param name="Problem">Why the bytes could not be unpacked; null when they could.</param>
/// <param name="Body">The body; null when there is none (Receipt, Heartbeat, HTTP GET, cleared, unreadable).</param>
public sealed record ReadableMessage(MessageHeader? Header, string? Problem, ReadableContent? Body);

/// <param name="Bytes">Size of the body before compression.</param>
/// <param name="Text">The body exactly as received, as text.</param>
/// <param name="Indented">The same, indented (XML or JSON); null when it is not well-formed.</param>
/// <param name="ParameterName">For a SOAP envelope: the operation's first parameter (sXML, XMLMsg, SendToFMSResult…).</param>
/// <param name="Payload">That parameter's value, unescaped, indented when it is XML: the business message.</param>
/// <param name="Note">Why something could not be shown as XML.</param>
public sealed record ReadableContent(int Bytes, string Text, string? Indented, string? ParameterName, string? Payload, string? Note)
{
    /// <summary>The most readable form: the business message, else the indented body, else the text.</summary>
    public string Best => Payload ?? Indented ?? Text;
}
