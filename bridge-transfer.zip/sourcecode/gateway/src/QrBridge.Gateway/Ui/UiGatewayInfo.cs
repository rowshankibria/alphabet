using Microsoft.Extensions.Options;
using QrBridge.Gateway.Controllers;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Egress.Workers;
using QrBridge.Gateway.Ingress;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Gateway.Ui.Data;

namespace QrBridge.Gateway.Ui;

/// <summary>
/// What the read-only UI may know about this gateway: its routes, where it delivers (the same
/// <see cref="SoapForwarderHttpClient.ResolveTarget"/> the InboxWorker uses), and the figures of GET /health (the same
/// rules as <see cref="HealthController"/>). The UI's only way to the rest of the gateway. Reads only: its repositories
/// run on the UI's read-only connection (<see cref="ReadOnlyBridgeDb"/>), so even a mistaken write would be refused, and
/// of <see cref="FarSideMonitor"/> it calls only <see cref="FarSideMonitor.GetAsync"/>.
/// </summary>
public sealed class UiGatewayInfo(
    RouteTable routes,
    SoapForwarderHttpClient forwarder,
    ReadOnlyBridgeDb db,
    SequenceGapMonitor gapMonitor,
    FarSideMonitor farSideMonitor,
    RetryCounters retries,
    WaiterRegistry waiters,
    IOptions<BridgeOptions> bridgeOptions)
{
    private readonly OutboxRepository _outbox = new(db, bridgeOptions);
    private readonly InboxRepository _inbox = new(db);
    private readonly HeartbeatRepository _heartbeats = new(db);

    /// <summary>This gateway's side (Bridge:Side).</summary>
    public BridgeSide Side => bridgeOptions.Value.Side;

    /// <summary>This gateway's route catalogue fingerprint; every message carries its sender's (decision D31).</summary>
    public string CatalogFingerprint => routes.CatalogFingerprint;

    /// <summary>The route of a message in routes.json, or null (an unlisted service, or a Heartbeat).</summary>
    public RouteView? FindRoute(string serviceName, string operation, string? businessType)
    {
        var service = routes.FindByName(serviceName);
        if (service is null) return null;
        string path = RouteTable.NormalizePath(service.Paths.FirstOrDefault());
        return new RouteView(service.Name, service.Description, service.SenderSide, path, service.HttpGet,
                             Behaviour(service, operation, businessType));
    }

    /// <summary>
    /// Where this gateway posts an arrived Request of <paramref name="serviceName"/> that its caller sent to
    /// <paramref name="path"/>: Gateway:Receiver:Targets[service].Url, else DefaultBaseUrl + path. Null when neither is set.
    /// </summary>
    public Uri? DeliveryUrl(string serviceName, string path) =>
        forwarder.ResolveTarget(new MessageHeader { ServiceName = serviceName, Operation = "", Path = path, ContentType = "" })?.Url;

    /// <summary>The same figures as GET /health, read now.</summary>
    public async Task<GatewayStatus> GetStatusAsync(CancellationToken ct)
    {
        var oc = await _outbox.GetCountsAsync(ct);
        var ic = await _inbox.GetCountsAsync(ct);
        var beats = await _heartbeats.GetAllAsync(ct);
        var gaps = gapMonitor.Current; // from the last maintenance run, as /health
        var now = DateTime.UtcNow;
        var far = await farSideMonitor.GetAsync(now, ct);

        var components = beats.Select(b => new ComponentView(b.Component, b.LastSeenUtc, b.Info, now - b.LastSeenUtc > HealthController.StaleAfter))
                              .ToList();
        long missing = gaps.Sum(g => g.Count);
        long lightProblems = oc.Light[OutboxLightStatus.Failed] + missing;
        int serviceProblems = MaintenanceWorker.OperatorServiceStatuses.Sum(s => ic.Service[s]);

        return new GatewayStatus(
            Side, Environment.MachineName, now,
            HealthController.IsHealthy(components.Count(c => c.Stale), lightProblems, serviceProblems, far.Silent),
            lightProblems, serviceProblems, missing, oc, ic,
            new FarSideView(far.LastHeardUtc, far.LastReceiptUtc, far.Silent, far.SilentAfterMinutes),
            gaps, gapMonitor.CheckedUtc, routes.CatalogFingerprint, waiters.Count,
            new RetryView(retries.Attached, retries.SameContentQueued, retries.SinceUtc),
            components);
    }

    /// <summary>What the gateway does with this operation and message type (<see cref="RouteTable.SettingsOf"/>), in plain words.</summary>
    private static string Behaviour(ServiceRoute service, string operation, string? businessType)
    {
        var settings = RouteTable.SettingsOf(service, operation, businessType);
        string mode = settings.Mode switch
        {
            OperationMode.RoundTrip when service.HttpGet =>
                "RoundTrip (plain HTTP GET): the caller is held for the real answer; HTTP 504 when it does not come back in time",
            OperationMode.RoundTrip when settings.OnHoldTimeout == HoldTimeoutAnswer.Pending =>
                "RoundTrip: the caller is held for the real answer; 1596 (confirmation not yet received) when it does not come back in time",
            OperationMode.RoundTrip =>
                "RoundTrip query: the caller is held for the real answer; \"not available\" when it does not come back in time",
            OperationMode.Bridge => "Bridge: the caller was answered at once; the message is delivered later",
            OperationMode.Echo => "Echo: answered by the gateway, never queued",
            OperationMode.Unavailable => "Unavailable: answered \"not available\" by the gateway, never queued",
            _ => "Reject: refused by the gateway, never queued",
        };
        return $"{mode} · priority {settings.Priority}{(settings.RecogniseRetries ? " · a caller's retry is attached to the first message" : "")}";
    }
}

/// <param name="Path">The path its callers use (every route has exactly one).</param>
/// <param name="HttpGet">A plain HTTP GET interface (Registered Tags), not SOAP.</param>
/// <param name="Behaviour">What the gateway does with this operation and message type, in plain words (mode, priority, retries).</param>
public sealed record RouteView(string ServiceName, string? Description, BridgeSide SenderSide, string Path, bool HttpGet, string Behaviour);

/// <summary>What GET /health shows, typed (<see cref="HealthController"/> and this record use the same rules).</summary>
public sealed record GatewayStatus(
    BridgeSide Side,
    string Machine,
    DateTime Utc,
    bool Healthy,
    long LightProblems,
    int ServiceProblems,
    long MissingMessages,
    OutboxCounts Outbox,
    InboxCounts Inbox,
    FarSideView FarSide,
    IReadOnlyList<SequenceGap> Gaps,
    DateTime? GapsCheckedUtc,
    string CatalogFingerprint,
    int HeldCallers,
    RetryView Retries,
    IReadOnlyList<ComponentView> Components);

/// <summary>Is the far side still there (decisions D80–D83)?</summary>
public sealed record FarSideView(DateTime? LastHeardUtc, DateTime? LastReceiptUtc, bool Silent, int SilentAfterMinutes);

/// <summary>Callers' retries since the gateway started (decision D37).</summary>
public sealed record RetryView(long Attached, long SameContentQueued, DateTime SinceUtc);

/// <summary>A component's heartbeat row (table Heartbeat): gateway loops now, QR apps later.</summary>
public sealed record ComponentView(string Component, DateTime LastSeenUtc, string? Info, bool Stale);
