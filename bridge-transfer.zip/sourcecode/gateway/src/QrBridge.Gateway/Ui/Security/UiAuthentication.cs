using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace QrBridge.Gateway.Ui.Security;

/// <summary>
/// The UI's login: one username and password from configuration (Ui:Username / Ui:Password, admin / admin by default,
/// handoff decision 48) and a cookie limited to /qrbridge-ui. Its own scheme and policy, and no default scheme, so the
/// gateway's SOAP endpoints and /health are not touched by it.
/// </summary>
public static class UiAuthentication
{
    public const string Scheme = "QrBridge.Ui";
    public const string Policy = "QrBridge.Ui";
    public const string CookieName = "QrBridge.Ui";

    /// <summary>Both must match exactly. Compared in constant time (hashed first, so the lengths do not show either).</summary>
    public static bool Matches(UiOptions ui, string? username, string? password) =>
        Same(username, ui.Username) & Same(password, ui.Password);

    public static ClaimsPrincipal Principal(string username) =>
        new(new ClaimsIdentity([new Claim(ClaimTypes.Name, username)], Scheme));

    private static bool Same(string? given, string expected) =>
        CryptographicOperations.FixedTimeEquals(
            SHA256.HashData(Encoding.UTF8.GetBytes(given ?? "")),
            SHA256.HashData(Encoding.UTF8.GetBytes(expected)));
}
