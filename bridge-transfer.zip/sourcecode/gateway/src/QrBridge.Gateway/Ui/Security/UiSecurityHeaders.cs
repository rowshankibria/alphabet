using Microsoft.AspNetCore.Http;

namespace QrBridge.Gateway.Ui.Security;

/// <summary>
/// Response headers for every UI path. The pages show payloads in clear (permits, orders: decision 23 keeps them
/// unencrypted at rest), so: nothing is cached by a browser or proxy, the page cannot be framed, and the content
/// security policy allows only the UI's own stylesheet and scripts (no inline script, no other site). A payload is
/// always HTML-encoded by Razor; the policy is the second line of defence.
/// </summary>
public static class UiSecurityHeaders
{
    public const string ContentSecurityPolicy =
        "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; " +
        "form-action 'self'; frame-ancestors 'none'; base-uri 'none'";

    public static void Apply(HttpResponse response)
    {
        var headers = response.Headers;
        headers.CacheControl = "no-store";
        headers.Pragma = "no-cache";
        headers.ContentSecurityPolicy = ContentSecurityPolicy;
        headers.XContentTypeOptions = "nosniff";
        headers.XFrameOptions = "DENY";
        headers["Referrer-Policy"] = "no-referrer";
        headers["X-Robots-Tag"] = "noindex, nofollow";
    }
}
