using System.Linq.Expressions;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Serialization;
using QrBridge.Gateway.Ui.Reading;

namespace QrBridge.Gateway.Ui.Data;

/// <summary>
/// Everything the pages show about the Outbox and the Inbox, read through <see cref="ReadOnlyBridgeDb"/> (read-only
/// connections: nothing here can change a row). Lists are paged in the database (filter and search in SQL, then a
/// count, then only the page's rows). Each message is unpacked by <see cref="MessageReader"/> so it reads in plain
/// words: the service URL (Outbox: the path the caller called on this gateway; Inbox: the URL this gateway posts to,
/// from Gateway:Receiver), the correlation id of its round trip, the request and the real service's response.
/// </summary>
public sealed partial class MessageQueries(ReadOnlyBridgeDb db, MessageReader reader, UiGatewayInfo gateway)
{
    private const int PreviewLength = 220;
    private const string LikeEscape = "\\";

    // =================== Lists ===================

    /// <summary>One page of a table, newest first, with the filter's choices (service names, counts per kind).</summary>
    public async Task<MessagePage> ListAsync(MessageBox box, MessageFilter filter, int page, int size, CancellationToken ct)
    {
        await using var context = await db.CreateDbContextAsync(ct);
        return await ListAsync(context, box, filter, Math.Max(1, page), Math.Clamp(size, 1, 500), withChoices: true, ct);
    }

    /// <summary>The newest <paramref name="count"/> Requests of a table (the overview).</summary>
    public async Task<IReadOnlyList<MessageRow>> LatestRequestsAsync(MessageBox box, int count, CancellationToken ct)
    {
        await using var context = await db.CreateDbContextAsync(ct);
        var filter = new MessageFilter(MessageKind.Request, null, null, null, null);
        return (await ListAsync(context, box, filter, 1, count, withChoices: false, ct)).Rows;
    }

    private async Task<MessagePage> ListAsync(BridgeDbContext context, MessageBox box, MessageFilter filter, int page, int size,
                                              bool withChoices, CancellationToken ct)
    {
        var idMatches = await IdPrefixMatchesAsync(context, box, filter.Search, ct);
        int total;
        List<MessageRow> rows;
        IReadOnlyList<string> services = [];
        IReadOnlyDictionary<MessageKind, int> kinds = StatusCounts.ForAll<MessageKind>([]);

        if (box == MessageBox.Outbox)
        {
            var q = Filter(context.Outbox, filter, idMatches);
            if (Parse<OutboxLightStatus>(filter.Light) is { } light) q = q.Where(m => m.LightStatus == light);
            if (Parse<OutboxServiceStatus>(filter.Service) is { } service) q = q.Where(m => m.ServiceStatus == service);
            total = await q.CountAsync(ct);
            page = Math.Min(page, Pages(total, size));
            var found = await q.OrderByDescending(m => m.CreatedUtc).ThenByDescending(m => m.Sequence).Skip((page - 1) * size).Take(size)
                .Select(m => new
                {
                    m.MessageId, m.Kind, m.ServiceName, m.Operation, m.BusinessType, m.CreatedUtc,
                    m.LightStatus, m.LightComment, m.LightUpdatedUtc, m.ServiceStatus, m.ServiceHttpStatus, m.ServiceComment,
                    m.ServiceUpdatedUtc, m.CorrelationId, m.MessageBytes,
                })
                .ToListAsync(ct);
            rows = found.Select(r =>
            {
                var message = reader.Read(r.MessageBytes);
                var (url, note) = OutboxUrl(r.Kind, r.ServiceName, r.Operation, r.BusinessType, message.Header);
                return new MessageRow(MessageBox.Outbox, r.MessageId, r.Kind, r.ServiceName, r.Operation, r.BusinessType, r.CreatedUtc,
                    Display.Light(r.LightStatus, r.LightComment, r.LightUpdatedUtc),
                    Display.Service(r.Kind, r.ServiceStatus, r.ServiceHttpStatus, r.ServiceComment, r.ServiceUpdatedUtc),
                    url, note, Preview(MessageBox.Outbox, r.Kind, r.CorrelationId, message, null),
                    RoundTripId(r.Kind, r.MessageId, r.CorrelationId), RequestHref(MessageBox.Outbox, r.Kind, r.MessageId, r.CorrelationId));
            }).ToList();
            if (withChoices)
            {
                services = await context.Outbox.Select(m => m.ServiceName).Distinct().OrderBy(n => n).ToListAsync(ct);
                kinds = await KindCountsAsync(context.Outbox, ct);
            }
        }
        else
        {
            var q = Filter(context.Inbox, filter, idMatches);
            if (Parse<InboxLightStatus>(filter.Light) is { } light) q = q.Where(m => m.LightStatus == light);
            if (Parse<InboxServiceStatus>(filter.Service) is { } service)
                q = q.Where(m => m.ServiceStatus == service && m.LightStatus == InboxLightStatus.Received);
            total = await q.CountAsync(ct);
            page = Math.Min(page, Pages(total, size));
            var found = await q.OrderByDescending(m => m.ReceivedUtc).ThenByDescending(m => m.Sequence).Skip((page - 1) * size).Take(size)
                .Select(m => new
                {
                    m.MessageId, m.Kind, m.ServiceName, m.Operation, m.BusinessType, m.ReceivedUtc,
                    m.LightStatus, m.LightComment, m.ServiceStatus, m.ServiceHttpStatus, m.ServiceComment, m.ServiceUpdatedUtc,
                    m.DownstreamResult, m.CorrelationId, m.MessageBytes,
                })
                .ToListAsync(ct);
            rows = found.Select(r =>
            {
                var message = reader.Read(r.MessageBytes);
                var (url, note) = InboxUrl(r.Kind, r.ServiceName, r.Operation, r.BusinessType, message.Header);
                return new MessageRow(MessageBox.Inbox, r.MessageId, r.Kind, r.ServiceName, r.Operation, r.BusinessType, r.ReceivedUtc,
                    Display.Light(r.LightStatus, r.LightComment),
                    Display.Service(r.Kind, r.LightStatus, r.ServiceStatus, r.ServiceHttpStatus, r.ServiceComment, r.ServiceUpdatedUtc, r.DownstreamResult),
                    url, note, Preview(MessageBox.Inbox, r.Kind, r.CorrelationId, message, r.DownstreamResult),
                    RoundTripId(r.Kind, r.MessageId, r.CorrelationId), RequestHref(MessageBox.Inbox, r.Kind, r.MessageId, r.CorrelationId));
            }).ToList();
            if (withChoices)
            {
                services = await context.Inbox.Select(m => m.ServiceName).Distinct().OrderBy(n => n).ToListAsync(ct);
                kinds = await KindCountsAsync(context.Inbox, ct);
            }
        }

        return new MessagePage(box, filter, rows, page, size, total, services, kinds);
    }

    private static int Pages(int total, int size) => Math.Max(1, (total + size - 1) / size);

    /// <summary>
    /// Kind, service name and search: a whole MessageId or correlation id; the start of one (the 8 characters the lists
    /// show), found by <see cref="IdPrefixMatchesAsync"/>; or text in the service, operation or business type.
    /// </summary>
    private static IQueryable<T> Filter<T>(IQueryable<T> q, MessageFilter filter, IReadOnlyList<Guid>? idMatches) where T : BaseMessage
    {
        if (filter.Kind is { } kind) q = q.Where(m => m.Kind == kind);
        if (!string.IsNullOrWhiteSpace(filter.ServiceName)) q = q.Where(m => m.ServiceName == filter.ServiceName);

        string text = filter.Search?.Trim() ?? "";
        if (text.Length == 0) return q;
        if (Guid.TryParse(text, out var id)) return q.Where(m => m.MessageId == id || m.CorrelationId == id);

        string pattern = "%" + text.Replace(@"\", @"\\").Replace("%", @"\%").Replace("_", @"\_") + "%";
        var ids = idMatches ?? [];
        return q.Where(m => ids.Contains(m.MessageId) ||
                            EF.Functions.Like(m.ServiceName, pattern, LikeEscape) ||
                            EF.Functions.Like(m.Operation, pattern, LikeEscape) ||
                            (m.BusinessType != null && EF.Functions.Like(m.BusinessType, pattern, LikeEscape)));
    }

    /// <summary>
    /// Rows whose MessageId or CorrelationId starts with <paramref name="search"/> (4 to 35 hex characters or dashes), or
    /// null when the search does not look like the start of an id. Ids are stored as lower-case text, so a LIKE on the
    /// column finds them; the table name is one of two constants, never input.
    /// </summary>
    private static async Task<IReadOnlyList<Guid>?> IdPrefixMatchesAsync(BridgeDbContext context, MessageBox box, string? search,
                                                                        CancellationToken ct)
    {
        string text = search?.Trim().ToLowerInvariant() ?? "";
        if (!IdPrefixPattern().IsMatch(text)) return null;
        string prefix = text + "%";
        var ids = box == MessageBox.Outbox
            ? await context.Database.SqlQuery<string>($"SELECT MessageId AS Value FROM Outbox WHERE MessageId LIKE {prefix} OR CorrelationId LIKE {prefix}").ToListAsync(ct)
            : await context.Database.SqlQuery<string>($"SELECT MessageId AS Value FROM Inbox WHERE MessageId LIKE {prefix} OR CorrelationId LIKE {prefix}").ToListAsync(ct);
        return ids.Select(Guid.Parse).ToList();
    }

    [GeneratedRegex("^[0-9a-f-]{4,35}$")]
    private static partial Regex IdPrefixPattern();

    private static async Task<IReadOnlyDictionary<MessageKind, int>> KindCountsAsync<T>(IQueryable<T> q, CancellationToken ct)
        where T : BaseMessage
    {
        var counts = await q.GroupBy(m => m.Kind).Select(g => new { g.Key, Count = g.Count() }).ToListAsync(ct);
        return StatusCounts.ForAll(counts.Select(c => KeyValuePair.Create(c.Key, c.Count)));
    }

    /// <summary>A status name from the query string; null when empty or not a name of <typeparamref name="T"/>.</summary>
    private static T? Parse<T>(string? name) where T : struct, Enum =>
        !string.IsNullOrWhiteSpace(name) && !char.IsDigit(name[0]) && Enum.TryParse<T>(name, ignoreCase: true, out var value) &&
        Enum.IsDefined(value) ? value : null;

    // =================== Correlation ===================

    /// <summary>
    /// The id of a message's round trip: a Request's own MessageId (its Receipts and Reply carry it as their
    /// CorrelationId, and the far gateway stores the Request under the same id), a Receipt's or Reply's CorrelationId.
    /// A Heartbeat answers nothing: null.
    /// </summary>
    private static Guid? RoundTripId(MessageKind kind, Guid messageId, Guid? correlationId) => kind switch
    {
        MessageKind.Request => messageId,
        MessageKind.Heartbeat => null,
        _ => correlationId,
    };

    /// <summary>
    /// Where the round trip's Request is on this gateway: a Request is itself; this side's Receipts and Replies answer a
    /// Request that arrived here (Inbox), and the ones that arrived answer a Request this side sent (Outbox).
    /// </summary>
    private static string? RequestHref(MessageBox box, MessageKind kind, Guid messageId, Guid? correlationId) => kind switch
    {
        MessageKind.Request => UiPaths.Message(box, messageId),
        MessageKind.Heartbeat => null,
        _ when correlationId is { } request => UiPaths.Message(box == MessageBox.Outbox ? MessageBox.Inbox : MessageBox.Outbox, request),
        _ => null,
    };

    // =================== Service URL and preview ===================

    /// <summary>
    /// Outbox: a Request shows the path its caller called on this gateway (the far side posts it to its own target +
    /// this path); a Reply shows where this side posted the Request it answers.
    /// </summary>
    private (string Url, string? Note) OutboxUrl(MessageKind kind, string service, string operation, string? type, MessageHeader? header)
    {
        var route = gateway.FindRoute(service, operation, type);
        string? path = header?.Path is { Length: > 0 } p ? p : null;
        string far = Display.Side(gateway.Side.Other());
        switch (kind)
        {
            case MessageKind.Request:
                return ($"{Method(header, route)} {path ?? route?.Path ?? Display.None}", $"called on this gateway; posted on the {far} side to its target + this path");
            case MessageKind.Reply when (path ?? route?.Path) is { } replyPath:
                return gateway.DeliveryUrl(service, replyPath) is { } url
                    ? ($"{Method(null, route)} {url}", "the call this side posted; this is its answer")
                    : ($"{Method(null, route)} {replyPath}", "the call this side posted; this is its answer");
            default:
                return (Display.None, kind == MessageKind.Heartbeat ? "no service: a sign of life" : "no service: a confirmation");
        }
    }

    /// <summary>
    /// Inbox: a Request shows the URL this gateway posts it to (Gateway:Receiver), from its own path, or from routes.json
    /// once its body was cleared after delivery (D77). Receipts, Replies and Heartbeats are never posted.
    /// </summary>
    private (string Url, string? Note) InboxUrl(MessageKind kind, string service, string operation, string? type, MessageHeader? header)
    {
        if (kind != MessageKind.Request) return (Display.None, "read by this gateway, never posted");
        var route = gateway.FindRoute(service, operation, type);
        string? path = header?.Path is { Length: > 0 } p ? p : route?.Path;
        if (path is null) return (Display.None, "path unknown");
        string method = Method(header, route);
        string? note = header is null ? "path from routes.json: the body was cleared after delivery" : null;
        return gateway.DeliveryUrl(service, path) is { } url
            ? ($"{method} {url}", note)
            : ($"{method} {path}", "no Gateway:Receiver target is configured for it on this side");
    }

    private static string Method(MessageHeader? header, RouteView? route) =>
        header is { Kind: MessageKind.Request } ? (header.PayloadFormat == PayloadFormat.HttpGet ? "GET" : "POST")
        : route?.HttpGet == true ? "GET" : "POST";

    /// <summary>One line of content: the business message (or the SOAP body), the outcome of a Reply, or what a row is.</summary>
    private static string Preview(MessageBox box, MessageKind kind, Guid? correlation, ReadableMessage message, string? downstreamResult)
    {
        string about = correlation is { } c ? Display.Short(c) : "?";
        switch (kind)
        {
            case MessageKind.Heartbeat:
                return box == MessageBox.Outbox ? "Heartbeat: tells the far side this side is alive." : "Heartbeat: the far side is alive.";
            case MessageKind.Receipt:
                return box == MessageBox.Outbox ? $"Receipt: {about} arrived here and is stored." : $"Receipt: the far side stored {about}.";
        }

        if (message.Problem is { } problem) return problem;
        var header = message.Header;
        if (header is null)
            return string.IsNullOrWhiteSpace(downstreamResult)
                ? "Body cleared after delivery (decision D77)."
                : $"Body cleared after delivery (decision D77). The service answered: {Display.Collapse(downstreamResult, PreviewLength)}";

        if (kind == MessageKind.Reply)
        {
            string outcome = $"{header.Outcome}{(header.ServiceHttpStatus is { } s ? $" · HTTP {s}" : "")}";
            return message.Body is { } answer
                ? $"{outcome} · {Display.Collapse(answer.Best, PreviewLength)}"
                : $"{outcome}{(string.IsNullOrWhiteSpace(header.ServiceComment) ? "" : " · " + Display.Collapse(header.ServiceComment, PreviewLength))}";
        }
        if (header.PayloadFormat == PayloadFormat.HttpGet) return "HTTP GET: no body.";
        return message.Body is { } body ? Display.Collapse(body.Best, PreviewLength) : "(empty body)";
    }

    // =================== One message ===================

    public async Task<MessageDetail?> FindAsync(MessageBox box, Guid id, CancellationToken ct)
    {
        await using var context = await db.CreateDbContextAsync(ct);
        return box == MessageBox.Outbox ? await OutboxDetailAsync(context, id, ct) : await InboxDetailAsync(context, id, ct);
    }

    private async Task<MessageDetail?> OutboxDetailAsync(BridgeDbContext context, Guid id, CancellationToken ct)
    {
        var row = await context.Outbox.FirstOrDefaultAsync(m => m.MessageId == id, ct);
        if (row is null) return null;

        var message = reader.Read(row.MessageBytes);
        var header = message.Header;
        var route = gateway.FindRoute(row.ServiceName, row.Operation, row.BusinessType);
        var page = new DetailParts();
        if (message.Problem is { } problem) page.Notes.Add(problem);
        string far = Display.Side(gateway.Side.Other());

        switch (row.Kind)
        {
            case MessageKind.Request:
                page.CallTitle = "The call as this gateway received it";
                page.Call = CallText(Method(header, route), header?.Path ?? route?.Path ?? Display.None, header);
                page.Notes.Add($"On the {far} side, its gateway posts it to its Gateway:Receiver target for {row.ServiceName}, " +
                               $"or to its DefaultBaseUrl + {header?.Path ?? route?.Path ?? "the path"}.");
                page.ContentTitle = "Request";
                AddContent(page.Content, "c", message.Body, "Request", open: true);
                if (header is { PayloadFormat: PayloadFormat.HttpGet }) page.Notes.Add("An HTTP GET carries no body.");
                if (row.ReplyBody is { Length: > 0 } answer)
                {
                    page.AnswerTitle = $"Response from the real service (carried back in the {far} side's Reply" +
                                       $"{(row.ServiceHttpStatus is { } s ? $", HTTP {s}" : "")}{(row.ReplyContentType is { Length: > 0 } t ? $", {t}" : "")})";
                    AddContent(page.Answer, "a", reader.ReadContent(answer), "Response", open: true, openEnvelope: true);
                }
                await AddArrivedAnswersAsync(context, row, page, far, ct);
                page.Related.AddRange(await InboxRelatedAsync(context, m => m.CorrelationId == id, ct));
                break;

            case MessageKind.Reply:
                string path = header?.Path is { Length: > 0 } p ? p : route?.Path ?? Display.None;
                page.CallTitle = "The call this side posted, which this Reply answers";
                page.Call = $"{Method(null, route)} {(gateway.DeliveryUrl(row.ServiceName, path)?.ToString() ?? path)}\n" +
                            $"Outcome: {header?.Outcome.ToString() ?? "?"}{(header?.ServiceHttpStatus is { } http ? $", HTTP {http}" : "")}" +
                            (header?.ServiceComment is { Length: > 0 } why ? $"\nReason: {why}" : "");
                page.AnswerTitle = "Response from the real service (sent back to the far side in this Reply)";
                AddContent(page.Answer, "a", message.Body, "Response", open: true, openEnvelope: true);
                if (message.Body is null && header is not null) page.ResponseNotes.Add("This Reply carries no response body (none came back, or it was too large).");
                if (row.CorrelationId is { } answered)
                {
                    await AddArrivedAnsweredAsync(context, MessageKind.Reply, answered, page, far, ct);
                    await AddArrivedAnswersAsync(context, row, page, far, ct); // the far side's Receipt for this Reply
                    page.Related.AddRange(await InboxRelatedAsync(context, m => m.MessageId == answered || m.CorrelationId == id, ct));
                }
                break;

            case MessageKind.Receipt:
                page.Notes.Add($"A Receipt says it arrived safely: it tells the {far} side that {Short(row.CorrelationId)} arrived here and is saved, so it stops sending it. There is nothing else in it.");
                if (row.CorrelationId is { } stored)
                {
                    await AddArrivedAnsweredAsync(context, MessageKind.Receipt, stored, page, far, ct);
                    page.Related.AddRange(await InboxRelatedAsync(context, m => m.MessageId == stored, ct));
                }
                break;

            default:
                page.Notes.Add("A Heartbeat tells the far side this side is alive while it has nothing else to send. It has no body.");
                break;
        }

        var facts = new List<FactGroup>
        {
            CorrelationFacts(MessageBox.Outbox, row),
            MessageFacts(row, route, $"Sent {row.Attempts} time(s) as QR codes", Display.Bytes(row.PayloadSize) + " body"),
            new("Times",
            [
                Time("Created (this side's clock)", row.CreatedUtc),
                Time("Expires", row.ExpiresUtc),
                Time("QrData status changed", row.LightUpdatedUtc),
                Time("Claimed by the QR sender", row.LockedUtc),
                Time("Not sent again before", row.NextAttemptUtc),
                Time("Service status changed", row.ServiceUpdatedUtc),
                Time("Far side's Reply written", row.ReplyCreatedUtc),
            ]),
            IntegrityFacts(row, header),
        };
        if (route is not null) facts.Insert(2, RouteFacts(route));

        return page.Build(MessageBox.Outbox, row, Display.Light(row.LightStatus, row.LightComment, row.LightUpdatedUtc),
            Display.Service(row.Kind, row.ServiceStatus, row.ServiceHttpStatus, row.ServiceComment, row.ServiceUpdatedUtc), facts);
    }

    private async Task<MessageDetail?> InboxDetailAsync(BridgeDbContext context, Guid id, CancellationToken ct)
    {
        var row = await context.Inbox.FirstOrDefaultAsync(m => m.MessageId == id, ct);
        if (row is null) return null;

        var message = reader.Read(row.MessageBytes);
        var header = message.Header;
        var route = gateway.FindRoute(row.ServiceName, row.Operation, row.BusinessType);
        var page = new DetailParts();
        if (message.Problem is { } problem) page.Notes.Add(problem);
        bool cleared = row.MessageBytes.Length == 0;
        string far = Display.Side(gateway.Side.Other());

        switch (row.Kind)
        {
            case MessageKind.Request:
                // The latest Reply this side wrote for it: the response, and the path once the body was cleared (D77).
                var replyRow = await context.Outbox
                    .Where(m => m.Kind == MessageKind.Reply && m.CorrelationId == id)
                    .OrderByDescending(m => m.CreatedUtc).ThenByDescending(m => m.Sequence)
                    .FirstOrDefaultAsync(ct);
                var reply = replyRow is null ? null : reader.Read(replyRow.MessageBytes);
                string? path = header?.Path is { Length: > 0 } hp ? hp
                    : reply?.Header?.Path is { Length: > 0 } rp ? rp
                    : route?.Path;
                string target = path is null ? Display.None : gateway.DeliveryUrl(row.ServiceName, path)?.ToString() ?? path;

                page.CallTitle = "The call this gateway posts to the real service";
                page.Call = CallText(Method(header, route), target, header);
                if (path is not null && gateway.DeliveryUrl(row.ServiceName, path) is null)
                    page.Notes.Add($"No Gateway:Receiver target is configured for {row.ServiceName} on this side: it cannot be delivered here.");
                page.ContentTitle = "Request";
                if (cleared)
                    page.Notes.Add("The request body was cleared once the real service accepted it (decision D77: payloads are not kept " +
                                   "at rest after delivery). The full request is still in the sending side's Outbox; the response is below.");
                AddContent(page.Content, "c", message.Body, "Request", open: true);
                if (reply?.Body is { } answer)
                {
                    page.AnswerTitle = $"Response from the real service ({reply.Header?.Outcome}" +
                                       $"{(reply.Header?.ServiceHttpStatus is { } s ? $", HTTP {s}" : "")}; sent back in this side's Reply)";
                    AddContent(page.Answer, "a", answer, "Response", open: true, openEnvelope: true);
                }
                await AddSentAnswersAsync(context, row, replyRow?.MessageId, page, far, ct);
                page.Related.AddRange(await OutboxRelatedAsync(context, m => m.CorrelationId == id, ct));
                break;

            case MessageKind.Reply:
                if (message.Body is { } own)
                {
                    page.AnswerTitle = $"Response from the far side's real service ({header?.Outcome}" +
                                       $"{(header?.ServiceHttpStatus is { } s ? $", HTTP {s}" : "")})";
                    AddContent(page.Answer, "a", own, "Response", open: true, openEnvelope: true);
                }
                else if (cleared && row.CorrelationId is { } requestId &&
                         await context.Outbox.Where(m => m.MessageId == requestId)
                             .Select(m => new { m.ReplyBody, m.ServiceStatus, m.ServiceHttpStatus, m.ReplyContentType })
                             .FirstOrDefaultAsync(ct) is { ReplyBody.Length: > 0 } request)
                {
                    // Used: its body was cleared (D77), and the response it carried is kept on the Request it answers.
                    page.AnswerTitle = $"Response from the far side's real service ({request.ServiceStatus}" +
                                       $"{(request.ServiceHttpStatus is { } s ? $", HTTP {s}" : "")}; kept on the Outbox Request it answers)";
                    AddContent(page.Answer, "a", reader.ReadContent(request.ReplyBody!), "Response", open: true, openEnvelope: true);
                }
                else if (cleared)
                    page.ResponseNotes.Add("Used by this gateway; its body was cleared and it carried no response body.");
                if (row.CorrelationId is { } answered)
                {
                    await AddSentAnsweredAsync(context, MessageKind.Reply, answered, page, ct);
                    await AddSentAnswersAsync(context, row, null, page, far, ct); // this side's Receipt for this Reply
                    page.Related.AddRange(await OutboxRelatedAsync(context, m => m.MessageId == answered || m.CorrelationId == id, ct));
                }
                break;

            case MessageKind.Receipt:
                page.Notes.Add($"The {far} side says it arrived safely: {Short(row.CorrelationId)} reached it and is saved there, so this side stops sending it. There is nothing else in it.");
                if (row.CorrelationId is { } stored)
                {
                    await AddSentAnsweredAsync(context, MessageKind.Receipt, stored, page, ct);
                    page.Related.AddRange(await OutboxRelatedAsync(context, m => m.MessageId == stored, ct));
                }
                break;

            default:
                page.Notes.Add("A Heartbeat from the far side: it is alive. It has no body.");
                break;
        }

        var facts = new List<FactGroup>
        {
            CorrelationFacts(MessageBox.Inbox, row),
            MessageFacts(row, route, $"Delivery attempts {row.Attempts}", cleared ? "cleared after delivery" : null),
            new("Times",
            [
                Time("Created (sender's clock)", row.CreatedUtc),
                Time("Arrived here", row.ReceivedUtc),
                Time("Expires", row.ExpiresUtc),
                Time("Claimed for delivery", row.LockedUtc),
                Time("Next attempt not before", row.NextAttemptUtc),
                Time("Service status changed", row.ServiceUpdatedUtc),
                Time("Receipt owed since", row.ReceiptDueUtc),
            ]),
            IntegrityFacts(row, header, row.Verified),
        };
        if (route is not null) facts.Insert(2, RouteFacts(route));

        return page.Build(MessageBox.Inbox, row, Display.Light(row.LightStatus, row.LightComment),
            Display.Service(row.Kind, row.LightStatus, row.ServiceStatus, row.ServiceHttpStatus, row.ServiceComment, row.ServiceUpdatedUtc,
                            row.DownstreamResult), facts);
    }

    // =================== The round trip on one page ===================

    /// <summary>
    /// A Request or Reply this side sent: the Receipts (and, for a Request, the Replies) that came back for it, in this
    /// side's Inbox, each as its own section. A used Reply's body is cleared (D77); what it said is kept on the Request,
    /// so its outcome is read there.
    /// </summary>
    private async Task AddArrivedAnswersAsync(BridgeDbContext context, OutboxMessage request, DetailParts page, string far,
                                              CancellationToken ct)
    {
        var answers = await context.Inbox.Where(m => m.CorrelationId == request.MessageId).OrderBy(m => m.ReceivedUtc).ToListAsync(ct);
        foreach (var answer in answers)
        {
            var header = reader.Read(answer.MessageBytes).Header;
            var facts = new List<Fact>
            {
                new("Message id", answer.MessageId.ToString("D"), UiPaths.Message(MessageBox.Inbox, answer.MessageId), Code: true),
                Time($"Written by the {far} side", answer.CreatedUtc),
                Time("Arrived here", answer.ReceivedUtc),
            };
            if (answer.Kind == MessageKind.Reply)
            {
                // The Reply whose answer is stored on the Request: in the words of this page's Service card.
                bool kept = request.ReplyCreatedUtc == answer.CreatedUtc;
                string? outcome = kept ? request.ServiceStatus.ToString() : header?.Outcome?.ToString();
                int? http = kept ? request.ServiceHttpStatus : header?.ServiceHttpStatus;
                string? reason = kept ? request.ServiceComment : header?.ServiceComment;
                facts.Add(new("Outcome", outcome is null ? Display.None : outcome + (http is { } s ? $" · HTTP {s}" : "")));
                if (!string.IsNullOrWhiteSpace(reason)) facts.Add(new("Reason", reason));
                facts.Add(new("Response",
                    answer.LightStatus == InboxLightStatus.Rejected ? "not used: this Reply was rejected on arrival (QrData note)"
                    : kept ? request.ReplyBody is { Length: > 0 } body ? $"{Display.Bytes(body.Length)}: shown above"
                           : "none: this Reply carried no response body"
                    : request.ReplyCreatedUtc is null ? "not read by this gateway yet"
                    : "not the one shown above: another Reply answers this Request"));
            }
            if (answer.LightComment is { Length: > 0 } why) facts.Add(new("QrData note", why));

            var (title, explain) = AnswerText(answer.Kind, request.Kind, cameBack: true, far);
            page.RoundTrip.Add(new RoundTripPart(MessageBox.Inbox, answer.MessageId, answer.Kind, title, explain,
                Display.Light(answer.LightStatus, answer.LightComment),
                Display.Service(answer.Kind, answer.LightStatus, answer.ServiceStatus, answer.ServiceHttpStatus, answer.ServiceComment,
                                answer.ServiceUpdatedUtc, null),
                facts));
        }
        if (request.Kind != MessageKind.Request || answers.Any(a => a.Kind == MessageKind.Reply)) return;
        if (request.ServiceStatus != OutboxServiceStatus.Waiting)
            page.ResponseNotes.Add($"The {far} side's Reply said {request.ServiceStatus}: {request.ServiceComment} (the Reply itself is no longer in this Inbox).");
        else if (answers.Count == 0)
            page.ResponseNotes.Add($"Nothing has come back from the {far} side yet: no Receipt (it arrived safely) and no Reply (what the real service did).");
        else
            page.ResponseNotes.Add($"No Reply (what the real service did) from the {far} side yet: it shows here when it comes back.");
    }

    /// <summary>
    /// A Request or Reply that arrived here: the Receipts (and, for a Request, the Replies) this side sent back for it,
    /// in this side's Outbox.
    /// </summary>
    private async Task AddSentAnswersAsync(BridgeDbContext context, InboxMessage arrived, Guid? latestReplyId, DetailParts page, string far,
                                           CancellationToken ct)
    {
        var answers = await context.Outbox.Where(m => m.CorrelationId == arrived.MessageId)
            .OrderBy(m => m.CreatedUtc).ThenBy(m => m.Sequence).ToListAsync(ct);
        foreach (var answer in answers)
        {
            var message = reader.Read(answer.MessageBytes);
            var facts = new List<Fact>
            {
                new("Message id", answer.MessageId.ToString("D"), UiPaths.Message(MessageBox.Outbox, answer.MessageId), Code: true),
                Time("Written by this side", answer.CreatedUtc),
                Time("QrData status changed", answer.LightUpdatedUtc),
            };
            if (answer.Kind == MessageKind.Reply)
            {
                var header = message.Header;
                facts.Add(new("Outcome", header?.Outcome is { } outcome
                    ? outcome + (header.ServiceHttpStatus is { } s ? $" · HTTP {s}" : "") : Display.None));
                if (header?.ServiceComment is { Length: > 0 } reason) facts.Add(new("Reason", reason));
                facts.Add(new("Response", message.Body is not { } body ? "none: this Reply carried no response body"
                    : answer.MessageId == latestReplyId ? $"{Display.Bytes(body.Bytes)}: shown above"
                    : $"{Display.Bytes(body.Bytes)}: an earlier Reply (open it to read its response)"));
            }
            if (answer.LightComment is { Length: > 0 } why) facts.Add(new("QrData note", why));

            var (title, explain) = AnswerText(answer.Kind, arrived.Kind, cameBack: false, far);
            page.RoundTrip.Add(new RoundTripPart(MessageBox.Outbox, answer.MessageId, answer.Kind, title, explain,
                Display.Light(answer.LightStatus, answer.LightComment, answer.LightUpdatedUtc),
                Display.Service(answer.Kind, answer.ServiceStatus, answer.ServiceHttpStatus, answer.ServiceComment, answer.ServiceUpdatedUtc),
                facts));
        }
    }

    /// <summary>
    /// A Receipt or Reply this side sent: the message it answers, which arrived here (Inbox). A Reply answers a Request;
    /// a Receipt confirms a Request or a Reply.
    /// </summary>
    private async Task AddArrivedAnsweredAsync(BridgeDbContext context, MessageKind by, Guid answeredId, DetailParts page, string far,
                                               CancellationToken ct)
    {
        var answered = await context.Inbox.Where(m => m.MessageId == answeredId)
            .Select(m => new
            {
                m.MessageId, m.Kind, m.ServiceName, m.Operation, m.BusinessType, m.CreatedUtc, m.ReceivedUtc, m.LightStatus, m.LightComment,
                m.ServiceStatus, m.ServiceHttpStatus, m.ServiceComment, m.ServiceUpdatedUtc, m.DownstreamResult,
            })
            .FirstOrDefaultAsync(ct);
        if (answered is null)
        {
            page.Notes.Add($"The message it answers ({answeredId}) is not in this gateway's Inbox (archived).");
            return;
        }
        var facts = new List<Fact>
        {
            new("Message id", answered.MessageId.ToString("D"), UiPaths.Message(MessageBox.Inbox, answered.MessageId), Code: true),
            new("Message", $"{answered.ServiceName}.{answered.Operation}{(answered.BusinessType is { } type ? $" · {type}" : "")}"),
            Time($"Created (the {far} side's clock)", answered.CreatedUtc),
            Time("Arrived here", answered.ReceivedUtc),
        };
        if (answered.Kind == MessageKind.Request)
            facts.Add(new("The real service answered", string.IsNullOrWhiteSpace(answered.DownstreamResult) ? Display.None : answered.DownstreamResult));
        page.RoundTrip.Add(new RoundTripPart(MessageBox.Inbox, answered.MessageId, answered.Kind,
            $"{AnsweredTitle(by, answered.Kind)} (arrived from the {far} side)", AnsweredText(by, answered.Kind),
            Display.Light(answered.LightStatus, answered.LightComment),
            Display.Service(answered.Kind, answered.LightStatus, answered.ServiceStatus, answered.ServiceHttpStatus, answered.ServiceComment,
                            answered.ServiceUpdatedUtc, answered.DownstreamResult),
            facts));
    }

    /// <summary>A Receipt or Reply that arrived here: the message it answers, which this side sent (Outbox).</summary>
    private async Task AddSentAnsweredAsync(BridgeDbContext context, MessageKind by, Guid answeredId, DetailParts page, CancellationToken ct)
    {
        var answered = await context.Outbox.Where(m => m.MessageId == answeredId)
            .Select(m => new
            {
                m.MessageId, m.Kind, m.ServiceName, m.Operation, m.BusinessType, m.CreatedUtc, m.LightStatus, m.LightComment, m.LightUpdatedUtc,
                m.ServiceStatus, m.ServiceHttpStatus, m.ServiceComment, m.ServiceUpdatedUtc,
            })
            .FirstOrDefaultAsync(ct);
        if (answered is null)
        {
            page.Notes.Add($"The message it answers ({answeredId}) is not in this gateway's Outbox: this side never sent it, or it was archived.");
            return;
        }
        var facts = new List<Fact>
        {
            new("Message id", answered.MessageId.ToString("D"), UiPaths.Message(MessageBox.Outbox, answered.MessageId), Code: true),
            new("Message", $"{answered.ServiceName}.{answered.Operation}{(answered.BusinessType is { } type ? $" · {type}" : "")}"),
            Time("Queued here", answered.CreatedUtc),
        };
        if (answered.Kind == MessageKind.Request)
            facts.Add(new("Outcome", answered.ServiceStatus + (answered.ServiceHttpStatus is { } s ? $" · HTTP {s}" : "")));
        page.RoundTrip.Add(new RoundTripPart(MessageBox.Outbox, answered.MessageId, answered.Kind,
            $"{AnsweredTitle(by, answered.Kind)} (sent by this side)", AnsweredText(by, answered.Kind),
            Display.Light(answered.LightStatus, answered.LightComment, answered.LightUpdatedUtc),
            Display.Service(answered.Kind, answered.ServiceStatus, answered.ServiceHttpStatus, answered.ServiceComment, answered.ServiceUpdatedUtc),
            facts));
    }

    /// <summary>
    /// A Receipt or Reply in a round-trip section, in business words (Rowshan, 26 Nov): a Receipt says "it arrived
    /// safely", a Reply says "what the real service did". <paramref name="about"/> is the kind of message it answers;
    /// <paramref name="cameBack"/>: it came from the far side (else this side sent it).
    /// </summary>
    private static (string Title, string Explain) AnswerText(MessageKind answer, MessageKind about, bool cameBack, string far)
    {
        string from = cameBack ? $"from the {far} side" : "sent back by this side";
        const string NotSent = "If it was never sent to the service (it arrived too late, or the service could not be reached), this says why.";
        if (answer == MessageKind.Reply)
            return ($"Reply {from}: what the real service did", cameBack
                ? $"The real service's answer (accepted, refused…). {NotSent}"
                : $"The real service's answer here (accepted, refused…), sent back to the {far} side. {NotSent}");
        string what = about == MessageKind.Request ? "request" : about.ToString();
        string notTheAnswer = about == MessageKind.Request ? " It does not say what the service did: see the Reply." : "";
        return ($"Receipt {from}: it arrived safely", cameBack
            ? $"The {far} gateway received this {what} and saved it, so this side stops sending it.{notTheAnswer}"
            : $"This gateway told the {far} side that the {what} arrived here and is saved, so it stops sending it.{notTheAnswer}");
    }

    /// <summary>The title of the section that shows the message a Reply answers or a Receipt confirms.</summary>
    private static string AnsweredTitle(MessageKind by, MessageKind answered) =>
        by == MessageKind.Reply ? $"The {answered} it answers" : $"The {answered} it confirms";

    private static string AnsweredText(MessageKind by, MessageKind answered) => by == MessageKind.Reply
        ? "The original request. This Reply tells what was done with it."
        : $"The {answered} this Receipt says arrived safely.";

    /// <summary>The request line and the headers that are replayed with it, as an HTTP request is written.</summary>
    private static string CallText(string method, string target, MessageHeader? header)
    {
        var sb = new StringBuilder($"{method} {target}");
        if (header is null)
            sb.Append("\n(SOAPAction and Content-Type unknown: the body was cleared after delivery)");
        else if (header.PayloadFormat == PayloadFormat.HttpGet)
            sb.Append("\n(no body, no SOAPAction, no Content-Type)");
        else
        {
            sb.Append($"\nSOAPAction: {header.SoapActionHeader ?? "(none: SOAP 1.2 carries the action in the Content-Type)"}");
            sb.Append($"\nContent-Type: {header.ContentType}");
        }
        return sb.ToString();
    }

    /// <summary>
    /// The business message (open), the SOAP envelope indented (open when <paramref name="openEnvelope"/>, as for a
    /// response, or when there is no business message), and the bytes exactly as stored.
    /// </summary>
    private static void AddContent(List<CodeBlock> blocks, string idPrefix, ReadableContent? content, string what, bool open,
                                   bool openEnvelope = false)
    {
        if (content is null) return;
        string Id() => $"{idPrefix}{blocks.Count + 1}";
        string it = what == "Response" ? "answer" : "message";
        if (content.Payload is { } payload)
            blocks.Add(new CodeBlock(Id(), $"{what}: the message in {content.ParameterName}", payload, IsXml(payload), open,
                Explain: $"The {it} itself, the part a person reads: taken out of the envelope below and laid out for reading."));
        if (content.Indented is { } indented)
            blocks.Add(new CodeBlock(Id(), content.ParameterName is null ? $"{what}: indented" : $"{what}: SOAP envelope, indented",
                                     indented, IsXml(indented), openEnvelope || (open && content.Payload is null),
                Explain: content.ParameterName is null
                    ? $"The {it} with line breaks added for reading. Nothing else is changed."
                    : $"The same {it} in the wrapper it travels in (the SOAP envelope), which names the function and its parameter " +
                      $"{content.ParameterName}. Inside it, < and > are written as &lt; and &gt;, which is why it looks messy."));
        blocks.Add(new CodeBlock(Id(), $"{what}: exactly as stored ({Display.Bytes(content.Bytes)})", content.Text, IsXml(content.Text),
                                 open && content.Payload is null && content.Indented is null,
            Explain: $"The exact bytes of the {it}, untouched, as this gateway stored them. Only needed to compare with logs or for an audit."));
        if (content.Note is { } note)
            blocks[^1] = blocks[^1] with { Note = note };
    }

    private static bool IsXml(string text) => text.TrimStart('﻿', ' ', '\t', '\r', '\n').StartsWith('<');

    /// <summary>The message id, the round trip's correlation id, and where to find every message of that round trip here.</summary>
    private static FactGroup CorrelationFacts(MessageBox box, BaseMessage row)
    {
        var facts = new List<Fact>
        {
            new("Message id", row.MessageId.ToString("D"), Code: true, Hint: "the same id on both gateways"),
        };
        string note;
        if (RoundTripId(row.Kind, row.MessageId, row.CorrelationId) is { } roundTrip)
        {
            string id = roundTrip.ToString("D");
            facts.Add(new("Correlation id", id, row.Kind == MessageKind.Request ? null : RequestHref(box, row.Kind, row.MessageId, row.CorrelationId),
                          Code: true, Hint: "the id of this round trip"));
            facts.Add(new("Find the round trip", "in this gateway's Outbox", $"{UiPaths.Box(MessageBox.Outbox)}?kind=all&q={id}"));
            facts.Add(new("", "in this gateway's Inbox", $"{UiPaths.Box(MessageBox.Inbox)}?kind=all&q={id}"));
            note = row.Kind == MessageKind.Request
                ? "A Request's correlation id is its own message id: its Receipts and its Reply carry it as their CorrelationId, and the far gateway stores this Request under the same id. Search for it on both gateways."
                : $"This {row.Kind} answers the Request with this id (its CorrelationId). Search for it on both gateways.";
        }
        else
        {
            facts.Add(new("Correlation id", "none"));
            note = "A Heartbeat answers no message, so it has no correlation id.";
        }
        return new FactGroup("Correlation", facts, note);
    }

    private static FactGroup MessageFacts(BaseMessage row, RouteView? route, string attempts, string? size)
    {
        var facts = new List<Fact>
        {
            new("Kind", row.Kind.ToString()),
            new("Direction", Display.Direction(row.Direction)),
            new("Service", route?.Description is { Length: > 0 } d ? $"{row.ServiceName} — {d}" : row.ServiceName),
            new("Operation", row.Operation),
            new("Business type", row.BusinessType ?? Display.None),
            new("Payload format", row.PayloadFormat.ToString()),
            new("Attempts", attempts),
        };
        if (size is not null) facts.Add(new("Size", size));
        return new FactGroup("Message", facts);
    }

    private static FactGroup RouteFacts(RouteView route) => new("Route (routes.json)",
    [
        new("Behaviour", route.Behaviour),
        new("Callers on", $"the {Display.Side(route.SenderSide)} side"),
        new("Path", route.Path, Code: true),
    ]);

    private FactGroup IntegrityFacts(BaseMessage row, MessageHeader? header, bool? verified = null)
    {
        var facts = new List<Fact>
        {
            new("Message hash (SHA-256)", row.MessageHash, Code: true, Hint: "the same on both sides when nothing was damaged"),
            row.ContentFingerprint is { } fingerprint
                ? new("Content fingerprint", fingerprint, Code: true, Hint: "how a caller's retry is recognised")
                : new("Content fingerprint", NoFingerprint(row)),
        };
        if (header?.CatalogFingerprint is { } catalogue)
            facts.Add(new("Route catalogue", catalogue == gateway.CatalogFingerprint
                ? "the same routes.json as this gateway"
                : $"differs from this gateway's routes.json ({catalogue[..12]}… here {gateway.CatalogFingerprint[..12]}…)"));
        if (verified is { } v) facts.Add(new("Arrival checks", v ? "passed" : "not checked yet, or failed"));
        return new FactGroup("Integrity", facts);
    }

    /// <summary>Why a row has no content fingerprint: only a caller's SOAP Request gets one (it recognises the caller's retries).</summary>
    private static string NoFingerprint(BaseMessage row) => row switch
    {
        { Kind: not MessageKind.Request } =>
            $"none: a {row.Kind} is never retried by a caller; only a caller's Request has one (it is how a caller's retry is recognised)",
        { PayloadFormat: PayloadFormat.HttpGet } => "none: a plain HTTP GET has no body to compare, and a query is never attached to an earlier call",
        _ => "none: its payload could not be read as XML when it was queued, so a retry of it is never attached",
    };

    private static Fact Time(string label, DateTime? time) => new(label, Display.Utc(time), Time: time);

    private static string Short(Guid? id) => id is { } g ? Display.Short(g) : "?";

    private static async Task<List<RelatedMessage>> InboxRelatedAsync(BridgeDbContext context, Expression<Func<InboxMessage, bool>> where,
                                                                      CancellationToken ct)
    {
        var rows = await context.Inbox.Where(where).OrderBy(m => m.ReceivedUtc)
            .Select(m => new
            {
                m.MessageId, m.Kind, m.ServiceName, m.Operation, m.ReceivedUtc, m.LightStatus, m.LightComment, m.ServiceStatus,
                m.ServiceHttpStatus, m.ServiceComment, m.ServiceUpdatedUtc, m.DownstreamResult,
            })
            .ToListAsync(ct);
        return rows.Select(r => new RelatedMessage(MessageBox.Inbox, r.MessageId, r.Kind,
            $"{r.Kind} in this side's Inbox: {r.ServiceName}.{r.Operation}", r.ReceivedUtc,
            Display.Light(r.LightStatus, r.LightComment),
            Display.Service(r.Kind, r.LightStatus, r.ServiceStatus, r.ServiceHttpStatus, r.ServiceComment, r.ServiceUpdatedUtc, r.DownstreamResult)))
            .ToList();
    }

    private static async Task<List<RelatedMessage>> OutboxRelatedAsync(BridgeDbContext context, Expression<Func<OutboxMessage, bool>> where,
                                                                       CancellationToken ct)
    {
        var rows = await context.Outbox.Where(where).OrderBy(m => m.CreatedUtc)
            .Select(m => new
            {
                m.MessageId, m.Kind, m.ServiceName, m.Operation, m.CreatedUtc, m.LightStatus, m.LightComment, m.LightUpdatedUtc,
                m.ServiceStatus, m.ServiceHttpStatus, m.ServiceComment, m.ServiceUpdatedUtc,
            })
            .ToListAsync(ct);
        return rows.Select(r => new RelatedMessage(MessageBox.Outbox, r.MessageId, r.Kind,
            $"{r.Kind} in this side's Outbox: {r.ServiceName}.{r.Operation}", r.CreatedUtc,
            Display.Light(r.LightStatus, r.LightComment, r.LightUpdatedUtc),
            Display.Service(r.Kind, r.ServiceStatus, r.ServiceHttpStatus, r.ServiceComment, r.ServiceUpdatedUtc)))
            .ToList();
    }

    /// <summary>The parts of a detail page, filled per kind, then built into a <see cref="MessageDetail"/>.</summary>
    private sealed class DetailParts
    {
        public string? CallTitle { get; set; }
        public string? Call { get; set; }
        public string? ContentTitle { get; set; }
        public List<CodeBlock> Content { get; } = [];
        public string? AnswerTitle { get; set; }
        public List<CodeBlock> Answer { get; } = [];
        public List<string> Notes { get; } = [];
        public List<string> ResponseNotes { get; } = [];
        public List<RoundTripPart> RoundTrip { get; } = [];
        public List<RelatedMessage> Related { get; } = [];

        public MessageDetail Build(MessageBox box, BaseMessage row, StatusView light, StatusView service, IReadOnlyList<FactGroup> facts) =>
            new(box, row.MessageId, RoundTripId(row.Kind, row.MessageId, row.CorrelationId), row.Kind,
                row.Kind == MessageKind.Heartbeat ? "Heartbeat" : $"{row.ServiceName}.{row.Operation}", row.BusinessType,
                light, service, CallTitle, Call, facts, ContentTitle, Content, AnswerTitle, Answer, Notes, ResponseNotes, RoundTrip, Related);
    }
}

/// <param name="Kind">Null: every kind.</param>
/// <param name="Light">A light status name (of the table's own enum); null or unknown: any.</param>
/// <param name="Service">A service status name; null or unknown: any.</param>
/// <param name="ServiceName">A route service name (exact); null: any.</param>
/// <param name="Search">A message or correlation id (whole, or its first characters), or text in the service, operation or business type.</param>
public sealed record MessageFilter(MessageKind? Kind, string? Light, string? Service, string? ServiceName, string? Search);

/// <summary>One page of a table, newest first, and the choices for its filter.</summary>
/// <param name="Page">The page shown (1-based; a page beyond the last shows the last).</param>
public sealed record MessagePage(MessageBox Box, MessageFilter Filter, IReadOnlyList<MessageRow> Rows, int Page, int PageSize, int Total,
                                 IReadOnlyList<string> ServiceNames, IReadOnlyDictionary<MessageKind, int> KindCounts)
{
    public int Pages => Math.Max(1, (Total + PageSize - 1) / PageSize);

    /// <summary>The 1-based number of the first row shown (0 when there is none).</summary>
    public int From => Total == 0 ? 0 : (Page - 1) * PageSize + 1;

    public int To => Math.Min(Total, Page * PageSize);
}

/// <summary>One row of a list, in plain words.</summary>
/// <param name="TimeUtc">Outbox: when this side queued it. Inbox: when it arrived here.</param>
/// <param name="ServiceUrl">Method and URL (Inbox: where this side posts it) or path (Outbox: what its caller called).</param>
/// <param name="Preview">One line of content: the FMS message, the SOAP body, the outcome of a Reply, or what the row is.</param>
/// <param name="CorrelationId">The round trip's id (a Request's own MessageId, a Receipt's or Reply's CorrelationId); null for a Heartbeat.</param>
/// <param name="RequestHref">The round trip's Request on this gateway.</param>
public sealed record MessageRow(MessageBox Box, Guid MessageId, MessageKind Kind, string ServiceName, string Operation, string? BusinessType,
                                DateTime TimeUtc, StatusView Light, StatusView Service, string ServiceUrl, string? ServiceUrlNote,
                                string Preview, Guid? CorrelationId, string? RequestHref)
{
    public string Href => UiPaths.Message(Box, MessageId);
}

/// <summary>Everything the detail page of one message shows.</summary>
/// <param name="Call">The request line and replayed headers (or, for a Reply, the call it answers and its outcome).</param>
/// <param name="CorrelationId">The round trip's id (see <see cref="MessageRow.CorrelationId"/>); null for a Heartbeat.</param>
/// <param name="Answer">The real service's response (SOAP envelope, the message in its result, the bytes as stored).</param>
public sealed record MessageDetail(MessageBox Box, Guid MessageId, Guid? CorrelationId, MessageKind Kind, string Title, string? Subtitle,
                                   StatusView Light, StatusView Service, string? CallTitle, string? Call,
                                   IReadOnlyList<FactGroup> Facts, string? ContentTitle, IReadOnlyList<CodeBlock> Content,
                                   string? AnswerTitle, IReadOnlyList<CodeBlock> Answer,
                                   IReadOnlyList<string> Notes, IReadOnlyList<string> ResponseNotes, IReadOnlyList<RoundTripPart> RoundTrip,
                                   IReadOnlyList<RelatedMessage> Related);

/// <summary>
/// Another message of the same round trip, shown as its own section of a detail page (a Request's Receipts and Reply, or
/// the Request a Receipt or Reply answers), so the whole round trip reads on one page.
/// </summary>
/// <param name="Explain">What this message means for the round trip, in one plain line.</param>
public sealed record RoundTripPart(MessageBox Box, Guid MessageId, MessageKind Kind, string Title, string Explain, StatusView QrData,
                                   StatusView Service, IReadOnlyList<Fact> Facts)
{
    public string Href => UiPaths.Message(Box, MessageId);
}

/// <param name="Note">One plain-words line under the group's facts.</param>
public sealed record FactGroup(string Title, IReadOnlyList<Fact> Facts, string? Note = null);

/// <param name="Href">A link (another message or a search of the UI).</param>
/// <param name="Code">Shown in a monospace font (ids, hashes, paths).</param>
/// <param name="Time">Shown in the UI's time zone (Ui:TimeZone), with UTC in its tooltip.</param>
public sealed record Fact(string Label, string Value, string? Href = null, bool Code = false, DateTime? Time = null, string? Hint = null);

/// <summary>A block of text the page shows in a collapsible, copyable box (XML is coloured by ui.js).</summary>
/// <param name="Note">A warning about this text, shown when the box is open.</param>
/// <param name="Explain">What this box is, in one plain line, shown under the title even when the box is closed.</param>
public sealed record CodeBlock(string Id, string Title, string Text, bool Xml, bool Open, string? Note = null, string? Explain = null);

public sealed record RelatedMessage(MessageBox Box, Guid MessageId, MessageKind Kind, string What, DateTime TimeUtc,
                                    StatusView Light, StatusView Service)
{
    public string Href => UiPaths.Message(Box, MessageId);
}
