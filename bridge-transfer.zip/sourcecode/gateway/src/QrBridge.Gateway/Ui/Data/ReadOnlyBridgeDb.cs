using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using QrBridge.Shared;
using QrBridge.Shared.Data;

namespace QrBridge.Gateway.Ui.Data;

/// <summary>
/// The UI's only way into qrbridge.db. Its connections are opened read-only, so SQLite itself refuses any write made
/// through them, whatever the code above does; queries are not tracked. The gateway and the QR apps keep their own
/// read-write connections (IDbContextFactory&lt;BridgeDbContext&gt;); this class is deliberately not registered as one.
/// </summary>
public sealed class ReadOnlyBridgeDb(IOptions<BridgeOptions> bridgeOptions) : IDbContextFactory<BridgeDbContext>
{
    private readonly DbContextOptions<BridgeDbContext> _options = new DbContextOptionsBuilder<BridgeDbContext>()
        .UseSqlite(ConnectionString(bridgeOptions.Value.DatabasePath))
        .AddInterceptors(new SqlitePragmaInterceptor()) // busy_timeout: wait for a writer instead of failing at once
        .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
        .Options;

    public BridgeDbContext CreateDbContext() => new(_options);

    public Task<BridgeDbContext> CreateDbContextAsync(CancellationToken ct = default) => Task.FromResult(CreateDbContext());

    /// <summary>The shared connection string, opened read-only (Mode=ReadOnly: never creates or changes the file).</summary>
    internal static string ConnectionString(string databasePath) =>
        new SqliteConnectionStringBuilder(DatabaseSetup.ConnectionString(databasePath)) { Mode = SqliteOpenMode.ReadOnly }.ToString();
}
