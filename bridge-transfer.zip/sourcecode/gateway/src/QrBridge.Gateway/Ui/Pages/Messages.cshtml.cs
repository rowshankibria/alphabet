using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Options;
using QrBridge.Shared;
using QrBridge.Gateway.Ui.Data;

namespace QrBridge.Gateway.Ui.Pages;

/// <summary>
/// /qrbridge-ui/outbox and /qrbridge-ui/inbox: one table, newest first, paged in the database and filtered by the
/// query string (kind, light, service, name, q; p = page number, size = rows per page). Only Requests by default:
/// Receipts, Replies and Heartbeats are one click away.
/// </summary>
public sealed class MessagesModel(MessageQueries queries, IOptions<UiOptions> uiOptions) : PageModel
{
    public const string AllKinds = "all";

    /// <summary>The page sizes a viewer can pick (Ui:PageSize is the default, and is added when it is not one of these).</summary>
    private static readonly int[] StandardSizes = [10, 25, 50, 100, 200];

    public MessageBox Box { get; private set; }
    public string Kind { get; private set; } = nameof(MessageKind.Request);
    public string? Light { get; private set; }
    public string? Service { get; private set; }
    public string? Name { get; private set; }
    public string? Search { get; private set; }
    public int Size { get; private set; }
    public MessagePage Result { get; private set; } = null!;

    public IReadOnlyList<int> PageSizes { get; } = StandardSizes.Append(uiOptions.Value.PageSize).Distinct().Order().ToList();

    public IReadOnlyList<string> LightNames => Box == MessageBox.Outbox
        ? Enum.GetNames<OutboxLightStatus>()
        : Enum.GetNames<InboxLightStatus>();

    public IReadOnlyList<string> ServiceNames => Box == MessageBox.Outbox
        ? Enum.GetNames<OutboxServiceStatus>().Where(n => n != nameof(OutboxServiceStatus.NotAvailable)).ToList()
        : Enum.GetNames<InboxServiceStatus>();

    /// <param name="p">The page number ("page" is taken: Razor Pages keeps the page's own name in that route value).</param>
    /// <param name="size">Rows per page, one of <see cref="PageSizes"/>; anything else gives Ui:PageSize.</param>
    public async Task<IActionResult> OnGetAsync(MessageBox box, string? kind, string? light, string? service, string? name, string? q,
                                                int p = 1, int? size = null, CancellationToken ct = default)
    {
        Box = box;
        MessageKind? kindFilter = MessageKind.Request;
        if (string.Equals(kind, AllKinds, StringComparison.OrdinalIgnoreCase))
        {
            Kind = AllKinds;
            kindFilter = null;
        }
        else if (Enum.TryParse<MessageKind>(kind, ignoreCase: true, out var parsed) && Enum.IsDefined(parsed) && !char.IsDigit(kind![0]))
        {
            Kind = parsed.ToString();
            kindFilter = parsed;
        }
        Light = Blank(light);
        Service = Blank(service);
        Name = Blank(name);
        Search = Blank(q);
        Size = size is { } s && PageSizes.Contains(s) ? s : uiOptions.Value.PageSize;
        try
        {
            Result = await queries.ListAsync(box, new MessageFilter(kindFilter, Light, Service, Name, Search), p, Size, ct);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            return new EmptyResult(); // the browser left (another click, a filter change, a refresh): nobody reads this page
        }
        return Page();
    }

    /// <summary>The URL of another page of this list, with the same filter and page size.</summary>
    public string PageUrl(int page)
    {
        var query = Query();
        if (page > 1) query["p"] = page.ToString();
        return query.Count == 0 ? UiPaths.Box(Box) : QueryHelpers.AddQueryString(UiPaths.Box(Box), query);
    }

    /// <summary>The filter and page size as query values (defaults left out), for links and the pager's hidden fields.</summary>
    public Dictionary<string, string?> Query()
    {
        var query = new Dictionary<string, string?>
        {
            ["kind"] = Kind == nameof(MessageKind.Request) ? null : Kind,
            ["light"] = Light,
            ["service"] = Service,
            ["name"] = Name,
            ["q"] = Search,
            ["size"] = Size == uiOptions.Value.PageSize ? null : Size.ToString(),
        };
        return query.Where(v => v.Value is not null).ToDictionary(v => v.Key, v => v.Value);
    }

    public string Title => Box == MessageBox.Outbox ? "Outbox" : "Inbox";

    private static string? Blank(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
