using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QrBridge.Shared;

namespace QrBridge.Gateway.Ui.Pages;

/// <summary>
/// The stylesheet and scripts (Ui/Assets/*.css, Ui/Assets/*.js, compiled into the gateway's assembly). Only those names are served,
/// nothing from disk, so no other file can be reached through this path. The URL carries a hash of the content
/// (?v=…), so a new version is fetched after a deployment while the old one may be cached for a day.
/// </summary>
public sealed class AssetsModel : PageModel
{
    private const string ResourcePrefix = "QrBridge.Gateway.Ui.Assets.";

    private static readonly IReadOnlyDictionary<string, Asset> Files = Load();

    /// <summary>The URL of an asset, with its version.</summary>
    public static string Href(string name) =>
        Files.TryGetValue(name, out var asset) ? $"{UiPaths.Prefix}/assets/{name}?v={asset.Version}" : $"{UiPaths.Prefix}/assets/{name}";

    public IActionResult OnGet(string name)
    {
        if (!Files.TryGetValue(name, out var asset)) return NotFound();
        Response.Headers.CacheControl = "private, max-age=86400";
        Response.Headers.Remove("Pragma");
        return File(asset.Bytes, asset.ContentType);
    }

    private static Dictionary<string, Asset> Load()
    {
        var assembly = typeof(AssetsModel).Assembly;
        var files = new Dictionary<string, Asset>(StringComparer.Ordinal);
        foreach (string resource in assembly.GetManifestResourceNames().Where(n => n.StartsWith(ResourcePrefix, StringComparison.Ordinal)))
        {
            using var stream = assembly.GetManifestResourceStream(resource)!;
            using var buffer = new MemoryStream();
            stream.CopyTo(buffer);
            byte[] bytes = buffer.ToArray();
            string name = resource[ResourcePrefix.Length..];
            string type = name.EndsWith(".css", StringComparison.Ordinal) ? "text/css; charset=utf-8" : "text/javascript; charset=utf-8";
            files[name] = new Asset(bytes, type, Hashing.Sha256Hex(bytes)[..12]);
        }
        return files;
    }

    private sealed record Asset(byte[] Bytes, string ContentType, string Version);
}
