using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Ui.Security;

namespace QrBridge.Gateway.Ui.Pages;

/// <summary>
/// The one login (Ui:Username / Ui:Password). A wrong one waits half a second before answering; neither the password
/// nor a payload is ever logged. After the login: back to the UI page asked for, never to another site or path.
/// </summary>
public sealed class LoginModel(IOptions<UiOptions> uiOptions, ILogger<LoginModel> logger) : PageModel
{
    private const int MaxLoggedNameLength = 64;

    [BindProperty]
    public string Username { get; set; } = "";

    [BindProperty]
    public string Password { get; set; } = "";

    [BindProperty(SupportsGet = true)]
    public string? ReturnUrl { get; set; }

    public string? Error { get; private set; }

    public void OnGet()
    {
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!UiAuthentication.Matches(uiOptions.Value, Username, Password))
        {
            logger.LogWarning("Read-only UI: login refused for user {User} from {Address}",
                Clean(Username), HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown");
            await Task.Delay(TimeSpan.FromMilliseconds(500), HttpContext.RequestAborted);
            Error = "Wrong username or password.";
            Password = "";
            return Page();
        }

        await HttpContext.SignInAsync(UiAuthentication.Scheme, UiAuthentication.Principal(Username));
        logger.LogInformation("Read-only UI: {User} signed in from {Address}",
            Clean(Username), HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown");
        return LocalRedirect(UiPaths.IsSafeReturnUrl(ReturnUrl) ? ReturnUrl! : UiPaths.Prefix);
    }

    /// <summary>The typed name, one line and short, so nothing a visitor types can forge or flood a log line.</summary>
    private static string Clean(string? name) =>
        Display.Collapse(name, MaxLoggedNameLength) is { Length: > 0 } clean ? clean : "(empty)";
}
