using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QrBridge.Gateway.Ui.Security;

namespace QrBridge.Gateway.Ui.Pages;

/// <summary>Sign out: a POST from the top bar's button (with its antiforgery token). A GET just goes back to the overview.</summary>
public sealed class LogoutModel : PageModel
{
    public IActionResult OnGet() => LocalRedirect(UiPaths.Prefix);

    public async Task<IActionResult> OnPostAsync()
    {
        await HttpContext.SignOutAsync(UiAuthentication.Scheme);
        return LocalRedirect(UiPaths.Login);
    }
}
