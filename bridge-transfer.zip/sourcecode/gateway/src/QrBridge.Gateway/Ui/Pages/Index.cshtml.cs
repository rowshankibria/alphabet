using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QrBridge.Shared;
using QrBridge.Gateway.Ui.Data;

namespace QrBridge.Gateway.Ui.Pages;

/// <summary>The overview: what GET /health says, in plain words, and the newest Requests sent and arrived.</summary>
public sealed class IndexModel(UiGatewayInfo gateway, MessageQueries queries) : PageModel
{
    private const int LatestCount = 8;

    public GatewayStatus Status { get; private set; } = null!;
    public IReadOnlyList<MessageRow> LatestSent { get; private set; } = [];
    public IReadOnlyList<MessageRow> LatestArrived { get; private set; } = [];

    /// <summary>Why the gateway is not healthy, one line each (empty when it is).</summary>
    public IReadOnlyList<string> Problems { get; private set; } = [];

    public async Task<IActionResult> OnGetAsync(CancellationToken ct)
    {
        try
        {
            Status = await gateway.GetStatusAsync(ct);
            LatestSent = await queries.LatestRequestsAsync(MessageBox.Outbox, LatestCount, ct);
            LatestArrived = await queries.LatestRequestsAsync(MessageBox.Inbox, LatestCount, ct);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            return new EmptyResult(); // the browser left (another click, a refresh): nobody reads this page
        }
        Problems = ProblemsOf(Status);
        return Page();
    }

    private static List<string> ProblemsOf(GatewayStatus s)
    {
        var problems = new List<string>();
        if (s.Outbox.Light[OutboxLightStatus.Failed] is > 0 and var failed)
            problems.Add($"{failed} Outbox message(s) Failed: the far side never confirmed them. Check the screen, the camera and the far QR Receiver.");
        if (s.MissingMessages > 0)
            problems.Add($"{s.MissingMessages} message(s) from the far side never arrived (missing sequence numbers, below).");
        var service = new[] { InboxServiceStatus.Unknown, InboxServiceStatus.Refused, InboxServiceStatus.NotDelivered }
            .Where(st => s.Inbox.Service[st] > 0).Select(st => $"{s.Inbox.Service[st]} {st}").ToList();
        if (service.Count > 0)
            problems.Add($"Inbox messages need an operator: {string.Join(", ", service)}.");
        if (s.FarSide.Silent)
            problems.Add($"Nothing heard from the far side for over {s.FarSide.SilentAfterMinutes} minutes: are the QR codes crossing, or is the far gateway down?");
        if (s.Components.Where(c => c.Stale).Select(c => c.Component).ToList() is { Count: > 0 } stale)
            problems.Add($"No recent heartbeat from: {string.Join(", ", stale)}.");
        return problems;
    }
}
