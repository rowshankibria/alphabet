using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QrBridge.Gateway.Ui.Data;

namespace QrBridge.Gateway.Ui.Pages;

/// <summary>/qrbridge-ui/{outbox|inbox}/{messageId}: one message in full — the call, its content, the answer, every field.</summary>
public sealed class MessageModel(MessageQueries queries) : PageModel
{
    public MessageBox Box { get; private set; }
    public Guid MessageId { get; private set; }

    /// <summary>Null when there is no such message (archived, or a wrong link): the page says so with HTTP 404.</summary>
    public MessageDetail? Detail { get; private set; }

    public async Task<IActionResult> OnGetAsync(MessageBox box, Guid id, CancellationToken ct)
    {
        Box = box;
        MessageId = id;
        try
        {
            Detail = await queries.FindAsync(box, id, ct);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            return new EmptyResult(); // the browser left (another click, a refresh): nobody reads this page
        }
        if (Detail is null) Response.StatusCode = StatusCodes.Status404NotFound;
        return Page();
    }
}
