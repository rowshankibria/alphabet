using System.Globalization;
using Microsoft.Extensions.Options;

namespace QrBridge.Gateway.Ui;

/// <summary>
/// Times as operators read them: exact to the second, on a 12-hour clock, in the configured zone (Ui:TimeZone, US Eastern by default), with
/// its label (EST in winter, EDT in summer). The database keeps UTC: one clock for both networks, no repeated hour
/// when the clocks go back, and SQLite has no type for a time with an offset (read-only-ui.md §7). UTC stays in each
/// time's tooltip.
/// </summary>
public sealed class UiTime(IOptions<UiOptions> uiOptions)
{
    public TimeZoneInfo Zone { get; } = Find(uiOptions.Value.TimeZone);

    /// <summary>US format, 12-hour clock: "11/25/2026 05:05:39 PM EST"; "—" for no time.</summary>
    public string Format(DateTime? utc)
    {
        if (utc is not { } time) return Display.None;
        var local = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(time.ToUniversalTime(), DateTimeKind.Utc), Zone);
        return local.ToString(Display.UsDateTime, CultureInfo.InvariantCulture) + " " + Label(local);
    }

    /// <summary>EST / EDT (the initials of the zone's name at that moment); UTC for UTC; else the offset.</summary>
    public string Label(DateTime local)
    {
        if (Zone.BaseUtcOffset == TimeSpan.Zero && !Zone.SupportsDaylightSavingTime) return "UTC";
        string name = Zone.IsDaylightSavingTime(local) ? Zone.DaylightName : Zone.StandardName;
        string initials = string.Concat(name.Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .Where(w => char.IsUpper(w[0])).Select(w => w[0]));
        if (initials.Length is >= 2 and <= 5) return initials;
        var offset = Zone.GetUtcOffset(local);
        return $"UTC{(offset < TimeSpan.Zero ? "−" : "+")}{offset.Duration():hh\\:mm}";
    }

    /// <summary>A Windows ("Eastern Standard Time") or IANA ("America/New_York") zone id; throws a clear error otherwise.</summary>
    public static TimeZoneInfo Find(string id)
    {
        try
        {
            return TimeZoneInfo.FindSystemTimeZoneById(id);
        }
        catch (Exception ex) when (ex is TimeZoneNotFoundException or InvalidTimeZoneException or ArgumentException)
        {
            throw new InvalidOperationException(
                $"Ui:TimeZone '{id}' is not a time zone of this machine (use e.g. \"Eastern Standard Time\").", ex);
        }
    }
}
