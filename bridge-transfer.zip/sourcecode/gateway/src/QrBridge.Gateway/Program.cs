using QrBridge.Gateway.Initializer;

// Start-up of the gateway. Each step is one call; the details are in Initializer/.
var builder = WebApplication.CreateBuilder(args);

builder.AddGatewayOptions();            // routes.json + the Bridge, Gateway and Routing settings
builder.Services
    .AddGatewayData()                   // qrbridge.db (EF Core + SQLite), message serializer, doorbells
    .AddRouteCatalog()                  // RouteTable + the WSDL contracts it names
    .AddGatewayEndpoints()              // controllers: POST {**path} and GET /health
    .AddSenderPart()                    // Ingress/: SenderEndpoint (incl. the hold), OutboxWriter, AnswerReader
    .AddReceiverPart()                  // Egress/: SoapForwarderHttpClient and its HttpClient
    .AddBackgroundWorkers()             // InboxWorker, MaintenanceWorker
    .AddGatewayUi();                    // Ui/: the read-only web UI under /qrbridge-ui (login)

var app = builder.Build();

await app.RunStartupChecksAsync();      // refuse to start on bad settings; create the database
app.MapGatewayEndpoints();
app.MapGatewayUi();                     // only when Ui:Enabled; every other GET still gets 405

await app.RunAsync();
return 0;

/// <summary>Exposed for the integration tests (WebApplicationFactory).</summary>
public partial class Program { }