using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Extensions.Options;
using QrBridge.Shared;

namespace QrBridge.Gateway.Routing;

/// <summary>
/// The route catalogue, validated and indexed once at startup. Invalid configuration fails the start
/// (better than discovering a typo when the first message is refused).
/// </summary>
public sealed class RouteTable
{
    private const int MaxServiceNameLength = 256;

    private readonly Dictionary<string, ServiceRoute> _byPath = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, ServiceRoute> _byName = new(StringComparer.OrdinalIgnoreCase);
    private readonly BridgeSide _side;

    public RouteTable(IOptions<RoutingOptions> routing, IOptions<BridgeOptions> bridge)
    {
        Options = routing.Value;
        _side = bridge.Value.Side;

        var problems = new List<string>();
        foreach (var service in Options.Services)
        {
            if (string.IsNullOrWhiteSpace(service.Name) || service.Name.Length > 64)
            {
                problems.Add($"A service has an empty or too long Name (max 64): '{service.Name}'.");
                continue;
            }
            if (!_byName.TryAdd(service.Name, service))
                problems.Add($"Service name '{service.Name}' is used twice.");
            if (service.Paths.Count == 0)
                problems.Add($"Service '{service.Name}' has no Paths.");

            foreach (string raw in service.Paths)
            {
                string path = NormalizePath(raw);
                if (_byPath.TryGetValue(path, out var other))
                    problems.Add($"Path '{path}' is claimed by both '{other.Name}' and '{service.Name}'.");
                else
                    _byPath[path] = service;
            }

            foreach (var (operation, route) in service.Operations)
            {
                if (route.Reply is { } profile && !Options.ReplyProfiles.ContainsKey(profile))
                    problems.Add($"{service.Name}.{operation} uses unknown reply profile '{profile}'.");
                CheckOperation($"{service.Name}.{operation}", route, problems);
            }
            if (service.OtherOperations == OperationMode.RoundTrip)
                problems.Add($"Service '{service.Name}': OtherOperations cannot be RoundTrip; list the operation with its reply profile.");
            if (service.HttpGet)
                CheckHttpGet(service, problems);
            if (service.MaxRequestBytes is <= 0)
                problems.Add($"Service '{service.Name}': MaxRequestBytes must be positive.");
            if (service.MaxBacklog is <= 0)
                problems.Add($"Service '{service.Name}': MaxBacklog must be positive.");
        }
        CheckFingerprintFields("Routing:FingerprintIgnore", Options.FingerprintIgnore, problems);

        if (problems.Count > 0)
            throw new InvalidOperationException("Invalid route catalogue (Routing section):" + Environment.NewLine +
                                                string.Join(Environment.NewLine, problems.Select(p => " - " + p)));

        CatalogFingerprint = ComputeFingerprint(Options);
    }

    public RoutingOptions Options { get; }

    /// <summary>The one operation of an <see cref="ServiceRoute.HttpGet"/> service (the HTTP method; there is no SOAP body).</summary>
    public const string HttpGetOperation = "GET";

    /// <summary>
    /// Decision D18: a plain GET is a read-only round trip for one configured path, nothing more. Anything else would be
    /// a way to fetch arbitrary pages across the gap, or a GET answered "accepted" without its real answer.
    /// </summary>
    private static void CheckHttpGet(ServiceRoute service, List<string> problems)
    {
        string label = $"HTTP GET service '{service.Name}'";
        if (service.Paths.Count != 1)
            problems.Add($"{label} must have exactly one path.");
        if (service.Contract is not null)
            problems.Add($"{label} has no WSDL contract.");
        if (service.OtherOperations != OperationMode.Reject)
            problems.Add($"{label}: OtherOperations must be Reject.");
        if (service.Operations.Count != 1 || !service.Operations.TryGetValue(HttpGetOperation, out var route))
        {
            problems.Add($"{label} must have exactly one operation, \"{HttpGetOperation}\".");
            return;
        }
        if (route.Mode is not (OperationMode.RoundTrip or OperationMode.Unavailable))
            problems.Add($"{label}: Mode must be RoundTrip or Unavailable.");
        if (route.OnHoldTimeout != HoldTimeoutAnswer.Unavailable || route.RecogniseRetries == true)
            problems.Add($"{label} is a read-only query: OnHoldTimeout must be Unavailable and RecogniseRetries off.");
        if (route.Reply is not null || route.OneWay || route.AllowedTypes.Count > 0 || route.Types.Count > 0)
            problems.Add($"{label}: no Reply profile, OneWay, AllowedTypes or Types (the answer is the real one, or HTTP 504).");
    }

    /// <summary>Round-trip and per-type settings that could not give the caller its agreed answer.</summary>
    private void CheckOperation(string label, OperationRoute route, List<string> problems)
    {
        var profile = Profile(route.Reply);
        CheckFingerprintFields(label, route.FingerprintIgnore, problems);
        if (route.Priority == MessagePriority.Answer || route.Types.Values.Any(t => t.Priority == MessagePriority.Answer))
            problems.Add($"{label}: Priority Answer is reserved for Receipts and Replies; use High, Normal or Low.");
        if (route.Mode == OperationMode.RoundTrip)
            CheckRoundTrip(label, route, route.OnHoldTimeout, profile, problems);

        if (route.Types.Count > 0 && route.Mode is OperationMode.Echo or OperationMode.Reject)
            problems.Add($"{label}: Types are only for Bridge, RoundTrip or Unavailable operations.");

        foreach (var (type, typeRoute) in route.Types)
        {
            string typeLabel = $"{label} type '{type}'";
            if (string.IsNullOrWhiteSpace(type))
                problems.Add($"{label} has an empty message type under Types.");
            if (typeRoute.Mode is OperationMode.Echo or OperationMode.Reject)
                problems.Add($"{typeLabel}: Mode {typeRoute.Mode} is not allowed for a message type (to refuse a type, leave it out of AllowedTypes).");
            if (route.AllowedTypes.Count > 0 && !route.AllowedTypes.Contains(type, StringComparer.Ordinal))
                problems.Add($"{typeLabel} is not in the operation's AllowedTypes, so its settings would never be used.");
            CheckFingerprintFields(typeLabel, typeRoute.FingerprintIgnore, problems);
            if ((typeRoute.Mode ?? route.Mode) == OperationMode.RoundTrip)
                CheckRoundTrip(typeLabel, route, typeRoute.OnHoldTimeout ?? route.OnHoldTimeout, profile, problems);
        }
    }

    private static void CheckRoundTrip(string label, OperationRoute route, HoldTimeoutAnswer onTimeout, ReplyProfile? profile,
                                       List<string> problems)
    {
        if (route.OneWay)
            problems.Add($"{label}: a RoundTrip operation cannot be OneWay (there is no answer to hold the caller for).");
        // Answering 1596 is the agreed hold-timeout answer for state-changing calls (D8); without it the caller would
        // get a SOAP fault that reads like "not sent", while the request may have been delivered.
        if (onTimeout == HoldTimeoutAnswer.Pending && string.IsNullOrEmpty(profile?.Pending))
            problems.Add($"{label}: OnHoldTimeout Pending needs a reply profile with a Pending value (RETURN_CODE 1596).");
    }

    private static void CheckFingerprintFields(string label, List<string> fields, List<string> problems)
    {
        if (fields.Any(string.IsNullOrWhiteSpace))
            problems.Add($"{label}: FingerprintIgnore has an empty field name.");
    }

    /// <summary>
    /// Lower-case hex SHA-256 of the service list, reply profiles and fingerprint field list (decision D31), the same on
    /// both sides when they run the same routes.json. Every message carries it; the receiving gateway rejects a message
    /// whose sender had another catalogue. The local test switches AcceptUnlisted / UnlistedOneWay are not part of it.
    /// </summary>
    public string CatalogFingerprint { get; }

    /// <summary>Canonical JSON (object properties sorted, array order kept) of the catalogue, hashed.</summary>
    private static string ComputeFingerprint(RoutingOptions options)
    {
        JsonNode? model = JsonSerializer.SerializeToNode(new { options.ReplyProfiles, options.Services, options.FingerprintIgnore });
        return Hashing.Sha256Hex(Encoding.UTF8.GetBytes(Canonical(model)?.ToJsonString() ?? "null"));
    }

    private static JsonNode? Canonical(JsonNode? node) => node switch
    {
        JsonObject obj => new JsonObject(obj.OrderBy(p => p.Key, StringComparer.Ordinal)
                                            .Select(p => KeyValuePair.Create(p.Key, Canonical(p.Value)))),
        JsonArray array => new JsonArray(array.Select(Canonical).ToArray()),
        _ => node?.DeepClone(),
    };

    public IReadOnlyCollection<ServiceRoute> Services => _byName.Values;

    /// <summary>Case-insensitive path without query, trailing slash or duplicate slashes; "/" for empty.</summary>
    public static string NormalizePath(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return "/";
        string p = path.Trim();
        int q = p.IndexOfAny(['?', '#']);
        if (q >= 0) p = p[..q];
        p = "/" + string.Join('/', p.Split('/', StringSplitOptions.RemoveEmptyEntries));
        return p;
    }

    public ServiceRoute? FindByPath(string path) => _byPath.GetValueOrDefault(NormalizePath(path));

    public ServiceRoute? FindByName(string name) => _byName.GetValueOrDefault(name);

    public ReplyProfile? Profile(string? name) =>
        name is not null && Options.ReplyProfiles.TryGetValue(name, out var profile) ? profile : null;

    /// <summary>
    /// Decides what to do with a call to <paramref name="path"/> for SOAP operation <paramref name="operation"/>, whose
    /// payload says it is a <paramref name="businessType"/> (MESSAGE/@TYPE; null when it has none).
    /// </summary>
    public RouteDecision Resolve(string path, string operation, string? businessType)
    {
        string normalized = NormalizePath(path);
        var service = FindByPath(normalized);

        if (service is null)
        {
            if (!Options.AcceptUnlisted)
                return Refuse(normalized, null, $"'{normalized}' is not a bridged service.");
            if (normalized.Length > MaxServiceNameLength)
                return Refuse(normalized, null, "Path too long to bridge.");
            return new RouteDecision(normalized, null, null, OperationMode.Bridge, null, Options.UnlistedOneWay, null,
                                     HoldTimeoutAnswer.Pending, Options.FingerprintIgnore, false, MessagePriority.Normal);
        }

        if (service.SenderSide != _side)
            return Refuse(service.Name, service,
                $"{service.Name} is delivered by this gateway ({_side}); its callers are on the {service.SenderSide} side.");

        if (service.Operations.TryGetValue(operation, out var route))
        {
            if (route.Mode == OperationMode.Reject)
                return Refuse(service.Name, service, $"{service.Name}.{operation} is not bridged.");
            var type = TypeOf(route, businessType);
            var settings = SettingsOf(service, operation, businessType);
            return new RouteDecision(service.Name, service, route, settings.Mode, Profile(route.Reply), route.OneWay, null,
                                     settings.OnHoldTimeout,
                                     [.. Options.FingerprintIgnore, .. route.FingerprintIgnore, .. type?.FingerprintIgnore ?? []],
                                     settings.RecogniseRetries, settings.Priority);
        }

        return service.OtherOperations == OperationMode.Reject
            ? Refuse(service.Name, service, $"{service.Name}.{operation} is not bridged.")
            : new RouteDecision(service.Name, service, null, service.OtherOperations, null, false, null,
                                HoldTimeoutAnswer.Pending, Options.FingerprintIgnore, false,
                                SettingsOf(service, operation, businessType).Priority);
    }

    /// <summary>
    /// The mode of a listed service's operation for one message type, as <see cref="Resolve"/> decides it. The receiving
    /// side uses it to deliver only what the sending side may have bridged.
    /// </summary>
    public static OperationMode ModeOf(ServiceRoute service, string operation, string? businessType) =>
        SettingsOf(service, operation, businessType).Mode;

    /// <summary>
    /// A listed service's settings for one operation and message type, the same on both sides (same routes.json):
    /// the mode, the hold-timeout answer and whether a retry with the same content is recognised.
    /// </summary>
    public static RouteSettings SettingsOf(ServiceRoute service, string operation, string? businessType)
    {
        if (!service.Operations.TryGetValue(operation, out var route))
            return new RouteSettings(service.OtherOperations, HoldTimeoutAnswer.Pending, false, DefaultPriority(service.OtherOperations, HoldTimeoutAnswer.Pending));
        if (route.Mode == OperationMode.Reject)
            return new RouteSettings(OperationMode.Reject, HoldTimeoutAnswer.Pending, false, MessagePriority.Normal);

        var type = TypeOf(route, businessType);
        var mode = type?.Mode ?? route.Mode;
        var onHoldTimeout = type?.OnHoldTimeout ?? route.OnHoldTimeout;
        // D37, D56: by default only state-changing RoundTrip calls (1596 on timeout) attach a retry; a query attached to
        // an earlier one would get a stale (or expired) answer.
        bool recogniseRetries = type?.RecogniseRetries ?? route.RecogniseRetries ??
                                (mode == OperationMode.RoundTrip && onHoldTimeout == HoldTimeoutAnswer.Pending);
        var priority = type?.Priority ?? route.Priority ?? DefaultPriority(mode, onHoldTimeout);
        return new RouteSettings(mode, onHoldTimeout, recogniseRetries, priority);
    }

    /// <summary>
    /// D73: state-changing round trips first (a dispatcher waits for a permit), then queries (a caller is held, the
    /// answer expires with the hold), then Bridge feeds (their callers already got their answer).
    /// </summary>
    private static MessagePriority DefaultPriority(OperationMode mode, HoldTimeoutAnswer onHoldTimeout) => mode switch
    {
        OperationMode.RoundTrip when onHoldTimeout == HoldTimeoutAnswer.Pending => MessagePriority.High,
        OperationMode.RoundTrip => MessagePriority.Normal,
        OperationMode.Bridge => MessagePriority.Low,
        _ => MessagePriority.Normal,
    };

    private static TypeRoute? TypeOf(OperationRoute route, string? businessType) =>
        !string.IsNullOrEmpty(businessType) && route.Types.TryGetValue(businessType, out var type) ? type : null;

    private static RouteDecision Refuse(string name, ServiceRoute? service, string problem) =>
        new(name, service, null, OperationMode.Reject, null, false, problem, HoldTimeoutAnswer.Pending, [], false, MessagePriority.Normal);
}

/// <summary>How the gateway will treat one incoming call.</summary>
/// <param name="ServiceName">Name stored in the message: the route name, or the path for unlisted calls.</param>
/// <param name="Service">The catalogue entry; null for unlisted calls.</param>
/// <param name="Operation">The operation entry; null when the operation is not listed.</param>
/// <param name="Mode">The operation's mode, or its message type's when the type has its own.</param>
/// <param name="Problem">Why the call is refused (Mode = Reject).</param>
/// <param name="OnHoldTimeout">For RoundTrip: the answer when the hold runs out.</param>
/// <param name="FingerprintIgnore">Fields left out of the content fingerprint: catalogue + operation + type.</param>
/// <param name="RecogniseRetries">Attach a retry with the same content to the first message (decision D37).</param>
/// <param name="Priority">The class the message travels in (decision D73).</param>
public sealed record RouteDecision(
    string ServiceName,
    ServiceRoute? Service,
    OperationRoute? Operation,
    OperationMode Mode,
    ReplyProfile? Profile,
    bool OneWay,
    string? Problem,
    HoldTimeoutAnswer OnHoldTimeout,
    IReadOnlyList<string> FingerprintIgnore,
    bool RecogniseRetries,
    MessagePriority Priority);

/// <summary>A listed route's settings for one message type (<see cref="RouteTable.SettingsOf"/>).</summary>
/// <param name="OnHoldTimeout">Unavailable = a read-only query: its caller waits only as long as its hold.</param>
/// <param name="Priority">The class the message travels in (decision D73).</param>
public sealed record RouteSettings(OperationMode Mode, HoldTimeoutAnswer OnHoldTimeout, bool RecogniseRetries, MessagePriority Priority);
