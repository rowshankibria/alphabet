using Microsoft.Extensions.Options;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;

namespace QrBridge.Gateway.Egress;

/// <summary>
/// Is the far side still there? (G-16, decisions D80–D83.) Each side hears the other through whatever arrives over the
/// light; when a side has had nothing to send for Gateway:HeartbeatMinutes it sends an empty Heartbeat message, so
/// silence means "the light or the far gateway is down", never just "nothing to say". A Heartbeat takes a sequence
/// number, so a lost last message shows on the far side as a gap once the Heartbeat after it arrives.
/// Nothing heard for longer than Gateway:FarSideSilentMinutes (counted from start-up until something is heard) =
/// silent: /health unhealthy, and MaintenanceWorker logs a "Light:" warning. Called by MaintenanceWorker and /health.
/// </summary>
public sealed class FarSideMonitor(
    OutboxWriter writer,
    OutboxRepository outbox,
    InboxRepository inbox,
    IOptions<BridgeOptions> bridgeOptions,
    IOptions<GatewayOptions> gatewayOptions)
{
    private readonly DateTime _startedUtc = DateTime.UtcNow;
    private readonly Direction _receiveDirection = bridgeOptions.Value.ReceiveDirection;
    private readonly GatewayOptions _gw = gatewayOptions.Value;

    /// <summary>
    /// Queues a Heartbeat when this side has queued nothing for Gateway:HeartbeatMinutes (counted from start-up at the
    /// latest), unless one is still waiting to be aired: while the light is down they would pile up, and since they go
    /// first they would then hold back real messages when it returns. Returns whether it queued one.
    /// <paramref name="nowUtc"/> is the current time.
    /// </summary>
    public async Task<bool> SendHeartbeatIfIdleAsync(DateTime nowUtc, CancellationToken ct)
    {
        if (_gw.HeartbeatMinutes <= 0) return false;
        DateTime idleSince = await outbox.FindLastQueuedUtcAsync(ct) is { } last && last > _startedUtc ? last : _startedUtc;
        if (nowUtc - idleSince < TimeSpan.FromMinutes(_gw.HeartbeatMinutes)) return false;
        if (await outbox.AnyHeartbeatWaitingAsync(ct)) return false;

        await writer.EnqueueAsync(new MessageHeader
        {
            Kind = MessageKind.Heartbeat,
            ServiceName = MessageHeader.HeartbeatServiceName,
            Operation = MessageHeader.HeartbeatOperation,
            Path = "",
            ContentType = "",
        }, [], ct: ct);
        return true;
    }

    /// <summary>When the far side was last heard (any message) and last confirmed one of ours (a Receipt); silent or not.</summary>
    public async Task<FarSideStatus> GetAsync(DateTime nowUtc, CancellationToken ct)
    {
        var (heard, receipt) = await inbox.FindLastArrivalsAsync(_receiveDirection, ct);
        bool silent = nowUtc - (heard ?? _startedUtc) > TimeSpan.FromMinutes(_gw.FarSideSilentMinutes);
        return new FarSideStatus(heard, receipt, silent, _gw.FarSideSilentMinutes);
    }
}

/// <param name="LastHeardUtc">When anything from the far side last arrived here acceptably; null when never.</param>
/// <param name="LastReceiptUtc">When the far side's last Receipt arrived ("it stored one of ours"); null when never.</param>
/// <param name="Silent">Nothing heard for longer than <paramref name="SilentAfterMinutes"/>.</param>
public sealed record FarSideStatus(DateTime? LastHeardUtc, DateTime? LastReceiptUtc, bool Silent, int SilentAfterMinutes);
