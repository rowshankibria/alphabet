using System.Text;
using System.Xml;
using Microsoft.Extensions.Options;
using QrBridge.Shared;
using QrBridge.Shared.Serialization;

namespace QrBridge.Gateway.Egress;

/// <summary>
/// The Receiver part's HTTP client: the one place the gateway calls a real service over HTTP.
/// Replays a caller's request to the real service on this side: same bytes, same SOAPAction and
/// Content-Type. Only the target URL differs, and it always comes from this side's configuration.
/// Then classifies the answer (<see cref="Classify"/>, decision D9): re-post only when the call surely did not arrive;
/// when it may have arrived, Unknown — never posted again on its own.
/// </summary>
public sealed class SoapForwarderHttpClient(
    IHttpClientFactory httpClientFactory,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<SoapForwarderHttpClient> logger)
{
    public const string HttpClientName = "receiver";
    public const string DefaultCredentialsClientName = "receiver-default-credentials";
    public const string AnonymousClientName = "receiver-anonymous";

    private readonly ReceiverOptions _options = gatewayOptions.Value.Receiver;

    /// <summary>
    /// The HTTP client for a service (decision D75): its target's UseDefaultCredentials when set and different from
    /// Gateway:Receiver:UseDefaultCredentials, else the default client.
    /// </summary>
    public string ClientNameFor(string serviceName) =>
        _options.Targets.TryGetValue(serviceName, out var target) && target.UseDefaultCredentials is { } own &&
        own != _options.UseDefaultCredentials
            ? own ? DefaultCredentialsClientName : AnonymousClientName
            : HttpClientName;

    /// <summary>Targets[service], else DefaultBaseUrl + the caller's path. Null when neither is configured.</summary>
    public (Uri Url, int TimeoutSeconds)? ResolveTarget(MessageHeader header)
    {
        if (_options.Targets.TryGetValue(header.ServiceName, out var target) && !string.IsNullOrWhiteSpace(target.Url))
            return (new Uri(target.Url, UriKind.Absolute), target.TimeoutSeconds ?? _options.TimeoutSeconds);

        if (!string.IsNullOrWhiteSpace(_options.DefaultBaseUrl))
        {
            var baseUri = new Uri(_options.DefaultBaseUrl.TrimEnd('/') + "/", UriKind.Absolute);
            // The path was normalized by the sending gateway ("/a/b.svc"); make it relative so it cannot
            // replace the configured host.
            return (new Uri(baseUri, header.Path.TrimStart('/')), _options.TimeoutSeconds);
        }
        return null;
    }

    /// <summary>
    /// POSTs <paramref name="soapBody"/> (the caller's exact bytes) with the SOAPAction and Content-Type from the header;
    /// an HttpGet message (decision D18) is replayed as a GET with no body.
    /// </summary>
    public async Task<DeliveryResult> ForwardAsync(MessageHeader header, byte[] soapBody, Uri url, int timeoutSeconds,
                                                   ResultKind resultKind, CancellationToken ct)
    {
        using var request = header.PayloadFormat == PayloadFormat.HttpGet
            ? new HttpRequestMessage(HttpMethod.Get, url)
            : PostOf(header, soapBody, url);

        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(Math.Max(1, timeoutSeconds)));

        var client = httpClientFactory.CreateClient(ClientNameFor(header.ServiceName));
        int? status = null;
        try
        {
            using var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, timeout.Token);
            status = (int)response.StatusCode;
            byte[]? reply = await ReadLimitedAsync(response.Content, _options.MaxResponseBytes, timeout.Token);
            string? replyContentType = response.Content.Headers.TryGetValues("Content-Type", out var types)
                ? string.Join(", ", types)
                : null;
            // The real answer travels back in the Reply (decision D43); null when it was too large to read.
            return Classify(status.Value, reply ?? [], resultKind, replyTruncated: reply is null)
                with { ContentType = replyContentType, Body = reply };
        }
        // SocketsHttpHandler's ConnectTimeout: an OCE wrapping a TimeoutException, while our own deadline has not passed.
        catch (OperationCanceledException ex) when (!ct.IsCancellationRequested && !timeout.IsCancellationRequested &&
                                                    ex.InnerException is TimeoutException && status is null)
        {
            return NothingSent($"Could not connect to {url.Host} within {_options.ConnectTimeoutSeconds}s (connect timeout)");
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            return MayHaveArrived(status,
                $"No answer from {url.Host} within {timeoutSeconds}s after the request was sent: the service is slow or hung");
        }
        catch (HttpRequestException ex)
        {
            logger.LogDebug(ex, "Delivery to {Url} failed ({Error})", url, ex.HttpRequestError);
            return ex.HttpRequestError switch
            {
                HttpRequestError.NameResolutionError => NothingSent($"DNS: the name {url.Host} does not resolve"),
                HttpRequestError.ConnectionError => NothingSent($"Could not connect to {url.Host} (connection refused or host unreachable)"),
                HttpRequestError.SecureConnectionError => NothingSent($"TLS handshake with {url.Host} failed (certificate or protocol)"),
                _ => MayHaveArrived(status,
                    $"The connection to {url.Host} was reset or the answer ended early ({ex.HttpRequestError})"),
            };
        }
        catch (IOException)
        {
            return MayHaveArrived(status, $"The connection to {url.Host} was reset while the answer was read");
        }
    }

    private HttpRequestMessage PostOf(MessageHeader header, byte[] soapBody, Uri url)
    {
        byte[] body = _options.RewriteAddressingTo ? RewriteAddressingTo(soapBody, url) : soapBody;
        var request = new HttpRequestMessage(HttpMethod.Post, url) { Content = new ByteArrayContent(body) };
        request.Content.Headers.TryAddWithoutValidation("Content-Type", header.ContentType);
        if (header.SoapActionHeader is not null)
            request.Headers.TryAddWithoutValidation("SOAPAction", header.SoapActionHeader);
        return request;
    }

    /// <summary>D9 "surely not arrived": nothing reached the service, so it is posted again (bounded, with backoff).</summary>
    private static DeliveryResult NothingSent(string reason) =>
        new(DeliveryVerdict.Transient, $"{reason}: nothing was sent, it will be tried again.", null);

    /// <summary>D9 "may have arrived": Unknown + operator alarm, never posted again on its own.</summary>
    private static DeliveryResult MayHaveArrived(int? status, string reason) =>
        new(DeliveryVerdict.Unknown, $"{reason}. The service may have processed it: check before resending.", null, status);

    /// <summary>Turns the real service's HTTP answer into a verdict, keeping its HTTP status code. Public for tests.</summary>
    public static DeliveryResult Classify(int status, byte[] reply, ResultKind kind, bool replyTruncated = false) =>
        ClassifyAnswer(status, reply, kind, replyTruncated) with { HttpStatus = status };

    private static DeliveryResult ClassifyAnswer(int status, byte[] reply, ResultKind kind, bool replyTruncated)
    {
        var soap = replyTruncated ? null : ReadServiceReply(reply, (long)reply.Length * 2 + 1024);

        if (soap is { IsFault: true })
        {
            string fault = $"SOAP fault: {soap.FaultReason ?? "(no reason)"}";
            return new DeliveryResult(DeliveryVerdict.Permanent, $"The service returned a fault (HTTP {status}). {fault}", fault);
        }

        if (status == 202)
            return new DeliveryResult(DeliveryVerdict.Delivered, "Accepted (HTTP 202).", "HTTP 202");

        if (status is >= 200 and < 300)
        {
            string? result = soap?.ResultText;
            switch (kind)
            {
                case ResultKind.FmsResponse when TryReadFmsStatus(result, out long code, out string? errorMessage):
                {
                    string summary = $"RETURN_CODE={code}" + (string.IsNullOrWhiteSpace(errorMessage) ? "" : $"; ERROR_MESSAGE={errorMessage}");
                    return code == 0
                        ? new DeliveryResult(DeliveryVerdict.Delivered, summary, summary)
                        : new DeliveryResult(DeliveryVerdict.Refused, $"The service refused the message: {summary}", summary);
                }
                case ResultKind.ReturnCode when long.TryParse(result?.Trim(), out long code):
                {
                    string summary = $"return code {code}";
                    return code == 0
                        ? new DeliveryResult(DeliveryVerdict.Delivered, summary, summary)
                        : new DeliveryResult(DeliveryVerdict.Refused, $"The service refused the message: {summary}", summary);
                }
                case ResultKind.None:
                    return new DeliveryResult(DeliveryVerdict.Delivered, $"HTTP {status}", $"HTTP {status}");
                default:
                    // 2xx, but the expected result can't be read: the service may have acted on it, so it is not
                    // Done, and a retry could duplicate it (decision 13). An operator checks before requeueing.
                    return new DeliveryResult(DeliveryVerdict.Unknown,
                        $"HTTP {status}, reply not recognised — may have been processed; check before requeue.",
                        $"HTTP {status}; unrecognised reply");
            }
        }

        return status switch
        {
            408 => new DeliveryResult(DeliveryVerdict.Transient,
                "HTTP 408: the server gave up waiting for the request, so it was not processed; it will be tried again.", "HTTP 408"),
            429 => new DeliveryResult(DeliveryVerdict.Transient,
                "HTTP 429: throttled, so it was not processed; it will be tried again later.", "HTTP 429"),
            500 => MayHaveBeenProcessed(status, "the service failed while processing, possibly partway"),
            502 or 504 => MayHaveBeenProcessed(status, "the load balancer or a proxy lost the service's answer"),
            503 => MayHaveBeenProcessed(status, "usually IIS refusing (app pool stopped), but a load balancer or the service can also send it"),
            >= 300 and < 400 => new DeliveryResult(DeliveryVerdict.Permanent,
                $"HTTP {status}: redirected (redirects are not followed), so it was not processed here; check Gateway:Receiver's URL.", $"HTTP {status}"),
            501 or 505 => new DeliveryResult(DeliveryVerdict.Permanent,
                $"HTTP {status}: the server cannot process this request, so it was not processed.", $"HTTP {status}"),
            >= 400 and < 500 => new DeliveryResult(DeliveryVerdict.Permanent,
                $"HTTP {status}: refused before processing (bad request, credentials, URL or Content-Type); check Gateway:Receiver's URL and credentials.", $"HTTP {status}"),
            // D40: any other 5xx, 1xx or anything odd: when in doubt it may have arrived.
            _ => MayHaveBeenProcessed(status, "an unexpected answer"),
        };
    }

    private static DeliveryResult MayHaveBeenProcessed(int status, string reason) =>
        new(DeliveryVerdict.Unknown, $"HTTP {status}: {reason}. The service may have processed it: check before resending.", $"HTTP {status}");

    /// <summary>Reads RETURN_CODE and ERROR_MESSAGE from an FMS &lt;RESPONSE&gt; document.</summary>
    private static bool TryReadFmsStatus(string? responseXml, out long code, out string? errorMessage)
    {
        code = 0;
        errorMessage = null;
        if (string.IsNullOrWhiteSpace(responseXml) || !responseXml.TrimStart().StartsWith('<')) return false;
        try
        {
            var doc = SafeXml.LoadText(responseXml, (long)responseXml.Length * 2 + 1024);
            var returnCode = doc.GetElementsByTagName("RETURN_CODE").OfType<XmlElement>().FirstOrDefault();
            if (returnCode is null || !long.TryParse(returnCode.InnerText.Trim(), out code)) return false;
            errorMessage = doc.GetElementsByTagName("ERROR_MESSAGE").OfType<XmlElement>().FirstOrDefault()?.InnerText.Trim();
            return true;
        }
        catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
        {
            return false;
        }
    }

    /// <summary>
    /// WCF services with WS-Addressing check that wsa:To names them. The caller addressed the load balancer,
    /// so the To header is pointed at the real service. Bodies without WS-Addressing are returned untouched.
    /// </summary>
    private static byte[] RewriteAddressingTo(byte[] body, Uri target)
    {
        // Cheap pre-check: almost every FMS request has no WS-Addressing, and those must stay byte-identical.
        if (body.AsSpan().IndexOf("addressing"u8) < 0) return body;

        XmlDocument doc;
        try
        {
            var settings = SafeXml.Settings(body.LongLength * 2 + 1024);
            settings.IgnoreComments = false;
            using var reader = XmlReader.Create(new MemoryStream(body, writable: false), settings);
            doc = new XmlDocument { XmlResolver = null, PreserveWhitespace = true };
            doc.Load(reader);
        }
        catch (XmlException)
        {
            return body;
        }

        var envelope = doc.DocumentElement;
        if (envelope is null) return body;
        var header = XmlHelpers.ChildElement(envelope, "Header", envelope.NamespaceURI);
        if (header is null) return body;

        XmlElement? to = null;
        foreach (XmlNode node in header.ChildNodes)
            if (node is XmlElement e && e.LocalName == "To" && SoapNamespaces.IsAddressing(e.NamespaceURI))
                to = e;
        if (to is null || to.InnerText.Trim() == target.AbsoluteUri) return body;

        to.InnerText = target.AbsoluteUri;
        using var ms = new MemoryStream();
        var writerSettings = new XmlWriterSettings
        {
            Encoding = new UTF8Encoding(false),
            OmitXmlDeclaration = doc.FirstChild is not XmlDeclaration,
        };
        using (var w = XmlWriter.Create(ms, writerSettings))
            doc.Save(w);
        return ms.ToArray();
    }

    /// <summary>The parts of the real service's SOAP reply that decide the verdict.</summary>
    /// <param name="ResultText">Text of the first element inside the response wrapper (e.g. SendToFMSResult), or null.</param>
    private sealed record ServiceReply(bool IsFault, string? FaultReason, string? ResultText);

    /// <summary>Reads the real service's reply: fault (and why) or result text. Null when it is not a SOAP envelope.</summary>
    private static ServiceReply? ReadServiceReply(byte[] body, long maxCharacters)
    {
        if (body.Length == 0) return null;
        XmlDocument doc;
        try
        {
            doc = SafeXml.Load(body, maxCharacters);
        }
        catch (Exception ex) when (ex is XmlException or InvalidOperationException or ArgumentException)
        {
            return null;
        }

        var envelope = doc.DocumentElement;
        if (envelope is null || envelope.LocalName != "Envelope" ||
            envelope.NamespaceURI is not (SoapNamespaces.Soap11 or SoapNamespaces.Soap12))
            return null;

        string env = envelope.NamespaceURI;
        var bodyElement = XmlHelpers.ChildElement(envelope, "Body", env);
        var first = bodyElement is null ? null : XmlHelpers.FirstChildElement(bodyElement);
        if (first is null) return new ServiceReply(false, null, null);

        if (first.LocalName == "Fault" && first.NamespaceURI == env)
        {
            string? reason = env == SoapNamespaces.Soap11
                ? FindDescendant(first, "faultstring")?.InnerText
                : FindDescendant(first, "Text")?.InnerText;
            return new ServiceReply(true, reason?.Trim(), null);
        }

        return new ServiceReply(false, null, XmlHelpers.FirstChildElement(first)?.InnerText);
    }

    private static XmlElement? FindDescendant(XmlElement parent, string localName) =>
        parent.GetElementsByTagName("*").OfType<XmlElement>().FirstOrDefault(e => e.LocalName == localName);

    private static async Task<byte[]?> ReadLimitedAsync(HttpContent content, int max, CancellationToken ct)
    {
        await using var stream = await content.ReadAsStreamAsync(ct);
        using var buffer = new MemoryStream();
        var chunk = new byte[16 * 1024];
        int read;
        while ((read = await stream.ReadAsync(chunk, ct)) > 0)
        {
            if (buffer.Length + read > max) return null;
            buffer.Write(chunk, 0, read);
        }
        return buffer.ToArray();
    }
}

/// <param name="Summary">One line for the row's ServiceComment / logs. Never contains the request payload.</param>
/// <param name="DownstreamResult">What the service said (return code, error message, fault reason).</param>
/// <param name="HttpStatus">The real service's HTTP status code; null when there was no HTTP answer (network error, timeout).</param>
/// <param name="ContentType">The real answer's Content-Type, as received; null when there was none.</param>
/// <param name="Body">The real answer, byte for byte; null when there was none or it was larger than Gateway:Receiver:MaxResponseBytes.</param>
public sealed record DeliveryResult(DeliveryVerdict Verdict, string Summary, string? DownstreamResult, int? HttpStatus = null,
                                    string? ContentType = null, byte[]? Body = null);
