using System.Globalization;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Exceptions;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;

namespace QrBridge.Gateway.Egress.Workers;

/// <summary>
/// Runs inside the Gateway (IIS). Takes complete messages from the Inbox, checks and unpacks them,
/// and replays the original SOAP request to the real service on this side.
///
/// Outcomes (light group / service group, decision D24; the D9 rule in SoapForwarderHttpClient.Classify):
///   Rejected      light: corrupt message bytes / wrong direction / not in the catalogue / bad payload (never retried)
///   Done          service: the real service accepted it
///   Retrying      service: surely not sent (DNS, refused, connect timeout, TLS, HTTP 408/429), retried with backoff
///                 (a round-trip query is not retried: NotDelivered at once, its caller is waiting)
///   Refused       service: the real service refused it (fault, non-zero return code, 4xx, 3xx, 501, 505)
///   Unknown       service: it may have been processed (timeout after sending, reset, 500/502/503/504, an unreadable 2xx,
///                 a shutdown or crash during the POST)
///   Expired       service: arrived or still waiting after its ExpiresUtc; not posted
///   NotDelivered  service: it surely never reached the service and will not be tried again (out of tries, no target) (D25)
/// Refused, Unknown and NotDelivered need an operator; none is re-posted on its own.
/// Every final outcome, Rejected included, is also sent back to the sending gateway as a Reply with the real answer,
/// written before the row is marked (decisions D43, D45, D46: <see cref="AnswerWriter"/>).
/// </summary>
public sealed class InboxWorker(
    InboxRepository inbox,
    HeartbeatRepository heartbeats,
    MessageSerializer serializer,
    RouteTable routes,
    ArrivalChecks arrival,
    SoapForwarderHttpClient forwarder,
    AnswerWriter answers,
    BridgeSignals signals,
    IOptions<BridgeOptions> bridgeOptions,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<InboxWorker> logger) : BackgroundService
{
    private readonly BridgeOptions _bridge = bridgeOptions.Value;
    private readonly GatewayOptions _gw = gatewayOptions.Value;
    private long _processed;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await Task.Yield(); // don't block host startup
        logger.LogInformation("Inbox worker started ({Side}, expects {Direction})", _bridge.Side, _bridge.ReceiveDirection);
        // D73: one delivery loop per class, so a slow feed never holds back a permit. Each loop delivers one at a time,
        // in order (D74). The doorbell wakes one loop; the others find new work at their next poll.
        await Task.WhenAll(DeliveryClasses.Select(priority => RunLoopAsync(priority, stoppingToken)));
        logger.LogInformation("Inbox worker stopped");
    }

    /// <summary>The classes of Requests, each with its own delivery loop (decision D73).</summary>
    public static readonly IReadOnlyList<MessagePriority> DeliveryClasses = [MessagePriority.High, MessagePriority.Normal, MessagePriority.Low];

    private async Task RunLoopAsync(MessagePriority priority, CancellationToken stoppingToken)
    {
        var pollInterval = TimeSpan.FromSeconds(Math.Max(1, _gw.InboxPollSeconds));
        var lastBeat = DateTime.MinValue;

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                if (DateTime.UtcNow - lastBeat > TimeSpan.FromSeconds(30))
                {
                    await heartbeats.BeatAsync(Components.InboxWorker, $"processed={Interlocked.Read(ref _processed)}", stoppingToken);
                    lastBeat = DateTime.UtcNow;
                }

                InboxMessage? row = await inbox.ClaimNextAsync(priority, stoppingToken);
                if (row is null)
                {
                    // Sleep until the QR receiver rings the doorbell, or poll anyway after the interval.
                    await signals.Inbox.WaitAsync(pollInterval, stoppingToken);
                    continue;
                }

                await ProcessAsync(row, stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Inbox worker ({Priority}) loop error; pausing 5s", priority);
                try { await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken); }
                catch (OperationCanceledException) { break; }
            }
        }
    }

    private async Task ProcessAsync(InboxMessage row, CancellationToken ct)
    {
        // ---- 1. Check + unpack + decide where it goes. Any failure here is permanent. ----
        MessageHeader? header = null;
        byte[] body;
        DeliveryPlan plan;
        try
        {
            (header, body) = serializer.Deserialize(row.MessageBytes);
            await ValidateAsync(header, row);
            plan = Plan(header);
        }
        catch (Exception ex) when (ex is InvalidDataException or BridgeRejectException)
        {
            logger.LogWarning("Rejected {MessageId}: {Reason}", row.MessageId, ex.Message);
            await answers.FinishAsync(row, header, ServiceOutcome.Rejected, null, $"{ex.GetType().Name}: {ex.Message}");
            return;
        }
        catch (PermanentFailureException ex)
        {
            logger.LogError("{MessageId} cannot be delivered: {Reason}", row.MessageId, ex.Message);
            await answers.FinishAsync(row, header, ServiceOutcome.NotDelivered, null, ex.Message);
            return;
        }

        // A request is never delivered after its expiry: the caller has given up (and a dispatcher may have gone verbal).
        if (header.ExpiresUtc is { } expires && expires <= DateTime.UtcNow)
        {
            logger.LogWarning("{MessageId} expired at {Expires:o}: not posted", row.MessageId, expires);
            await answers.FinishAsync(row, header, ServiceOutcome.Expired, null, string.Create(CultureInfo.InvariantCulture, // US format, as the UI shows times
                $"Not posted: the request expired at {expires:MM/dd/yyyy hh:mm:ss tt} UTC (sender's clock); the caller has given up."));
            return;
        }

        if (ct.IsCancellationRequested)
        {
            await inbox.ReleaseAsync(row.MessageId, CancellationToken.None); // stopping before the POST: nothing was sent
            return;
        }

        // ---- Layer 3b (decision D58): the same content that may already have reached the service is not posted again. ----
        if (plan.RecogniseRetries && header.ContentFingerprint is { } fingerprint)
        {
            var earlier = await inbox.FindSameContentAsync(row.MessageId, fingerprint,
                DateTime.UtcNow.AddMinutes(-_gw.RetryWindowMinutes), CancellationToken.None);
            if (earlier.FirstOrDefault(e => e.ServiceStatus == InboxServiceStatus.Done) is { } done)
            {
                await answers.ReuseDoneAsync(row, header, done);
                return;
            }
            if (earlier.FirstOrDefault() is { } unsure) // Unknown, or still Delivering
            {
                logger.LogError("{MessageId} not posted: the same content arrived as {Earlier}, whose outcome is {Status}: Unknown",
                    row.MessageId, unsure.MessageId, unsure.ServiceStatus);
                await answers.FinishAsync(row, header, ServiceOutcome.Unknown, null,
                    $"Not posted: the same content arrived as {unsure.MessageId} within the retry window and its outcome is " +
                    $"{unsure.ServiceStatus}: it may have been processed. Check that one before resending this.");
                return;
            }
        }

        // ---- 2. Deliver. Only failures where nothing was sent are retried (decision D9). ----
        DeliveryResult result;
        try
        {
            result = await forwarder.ForwardAsync(header, body, plan.Url, plan.TimeoutSeconds, plan.ResultKind, ct);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            // Stopping (e.g. app pool recycle) while the POST was in flight: it may already be at the service (D41).
            logger.LogWarning("{MessageId} interrupted by shutdown during delivery: marked Unknown", row.MessageId);
            await answers.FinishAsync(row, header, ServiceOutcome.Unknown, null,
                "The gateway stopped (app pool recycle or shutdown) while posting: the request may have reached the service. Check before resending.");
            throw;
        }

        // ---- 3. Answer over the opposite lane (Reply first, then the row: decision D46). ----
        // D76: who called (never the payload), so an operator can trace a delivery back to its caller.
        string label = $"{header.ServiceName}.{header.Operation} {header.BusinessType}".TrimEnd() + $" from {header.CallerHost ?? "unknown caller"}";
        switch (result.Verdict)
        {
            case DeliveryVerdict.Delivered:
                await Finish(ServiceOutcome.Done, result.Summary);
                Interlocked.Increment(ref _processed);
                logger.LogInformation("Delivered {Label} {MessageId} seq {Sequence}: {Result}",
                    label, header.MessageId, header.Sequence, result.Summary);
                break;

            case DeliveryVerdict.Refused:
            case DeliveryVerdict.Permanent:
                logger.LogError("{Label} {MessageId} refused: {Reason}", label, header.MessageId, result.Summary);
                await Finish(ServiceOutcome.Refused, result.Summary);
                break;

            case DeliveryVerdict.Unknown:
                logger.LogError("{Label} {MessageId} outcome unknown: {Reason}", label, header.MessageId, result.Summary);
                await Finish(ServiceOutcome.Unknown, result.Summary);
                break;

            case DeliveryVerdict.Transient when plan.Query:
                // Fast failure (Uncovered-Services §6): the query's caller is held for an answer now, not after a backoff.
                logger.LogWarning("{Label} {MessageId} not sent: {Reason}; a query is not retried: not delivered",
                    label, header.MessageId, result.Summary);
                await Finish(ServiceOutcome.NotDelivered,
                    $"Not delivered: the service could not be reached and nothing was sent; a query is not retried because its caller is waiting. {result.Summary}");
                break;

            case DeliveryVerdict.Transient when row.Attempts >= _gw.MaxAttempts:
                logger.LogWarning("{Label} {MessageId} not sent (attempt {Attempt}/{Max}): {Reason}; giving up: not delivered",
                    label, header.MessageId, row.Attempts, _gw.MaxAttempts, result.Summary);
                await Finish(ServiceOutcome.NotDelivered,
                    $"Not delivered after {row.Attempts} tries; it surely never reached the service, so it may be sent again. Last: {result.Summary}");
                break;

            default:
                var backoff = Backoff(row.Attempts);
                logger.LogWarning("{Label} {MessageId} not sent (attempt {Attempt}/{Max}): {Reason}; retry in {Backoff}",
                    label, header.MessageId, row.Attempts, _gw.MaxAttempts, result.Summary, backoff);
                await inbox.MarkRetryingAsync(row.MessageId, result.HttpStatus, result.Summary, backoff, CancellationToken.None);
                break;
        }

        Task Finish(ServiceOutcome outcome, string comment) =>
            answers.FinishAsync(row, header, outcome, result.HttpStatus, comment, result.DownstreamResult, result.ContentType, result.Body);
    }

    /// <param name="Query">A read-only round-trip query (hold-timeout answer "not available"): fails fast instead of retrying.</param>
    /// <param name="RecogniseRetries">The same content already handled in the retry window is not posted again (D58).</param>
    private sealed record DeliveryPlan(Uri Url, int TimeoutSeconds, ResultKind ResultKind, bool Query, bool RecogniseRetries);

    /// <summary>Only messages for services this side delivers, and only to URLs from this side's configuration.</summary>
    private DeliveryPlan Plan(MessageHeader header)
    {
        var resultKind = ResultKind.None;
        bool query = false, recogniseRetries = false;
        var service = routes.FindByName(header.ServiceName);
        // D18: a GET is replayed only for the one route marked HttpGet, and that route is never sent a SOAP POST.
        bool httpGet = header.PayloadFormat == PayloadFormat.HttpGet;
        if (httpGet != (service?.HttpGet ?? false))
            throw new BridgeRejectException(httpGet
                ? $"'{header.ServiceName}' is not an HTTP GET interface; an HTTP GET message is never sent to it."
                : $"{header.ServiceName} is an HTTP GET interface; a SOAP message is never sent to it.");
        if (service is not null)
        {
            if (service.SenderSide == _bridge.Side)
                throw new BridgeRejectException($"{service.Name} is received on this side; it cannot arrive from the other side.");

            service.Operations.TryGetValue(header.Operation, out var operation);
            var settings = RouteTable.SettingsOf(service, header.Operation, header.BusinessType);
            // RoundTrip: the sending side holds its caller for this delivery's Reply (step 10a).
            if (settings.Mode is not (OperationMode.Bridge or OperationMode.RoundTrip))
                throw new BridgeRejectException($"{service.Name}.{header.Operation} ({header.BusinessType}) is not a bridged operation.");
            resultKind = routes.Profile(operation?.Reply)?.ResultKind ?? ResultKind.None;
            query = settings.Mode == OperationMode.RoundTrip && settings.OnHoldTimeout == HoldTimeoutAnswer.Unavailable;
            recogniseRetries = settings.RecogniseRetries;
        }
        else if (!routes.Options.AcceptUnlisted)
        {
            throw new BridgeRejectException($"'{header.ServiceName}' is not in this side's route catalogue.");
        }

        var target = forwarder.ResolveTarget(header)
            ?? throw new PermanentFailureException(
                $"No Receiver target for {header.ServiceName}: set Gateway:Receiver:Targets:{header.ServiceName}:Url or Gateway:Receiver:DefaultBaseUrl.");
        return new DeliveryPlan(target.Url, target.TimeoutSeconds, resultKind, query, recogniseRetries);
    }


    /// <summary>The arrival checks every message passes (<see cref="ArrivalChecks"/>); only a Request is ever posted.</summary>
    private async Task ValidateAsync(MessageHeader header, InboxMessage row)
    {
        await arrival.CheckAsync(header, row, CancellationToken.None);
        if (header.Kind != MessageKind.Request)
            throw new BridgeRejectException($"A {header.Kind} is never posted to a service.");
    }

    private TimeSpan Backoff(int attempts)
    {
        double seconds = _gw.BackoffBaseSeconds * Math.Pow(2, Math.Max(0, attempts - 1));
        return TimeSpan.FromSeconds(Math.Min(seconds, _gw.BackoffMaxMinutes * 60));
    }
}
