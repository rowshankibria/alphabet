using Microsoft.Extensions.Options;

namespace QrBridge.Gateway.Egress.Workers;

/// <summary>
/// Sends the Receipts this side owes (decision D44) every Gateway:InboxPollSeconds, independent of deliveries: a slow
/// POST must not hold back the Receipts that stop the other side re-airing.
/// </summary>
public sealed class ReceiptWorker(
    AnswerWriter answers,
    IOptions<GatewayOptions> gatewayOptions,
    ILogger<ReceiptWorker> logger) : BackgroundService
{
    private readonly TimeSpan _interval = TimeSpan.FromSeconds(Math.Max(1, gatewayOptions.Value.InboxPollSeconds));

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await Task.Yield(); // don't block host startup
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                int sent;
                do sent = await answers.SendDueReceiptsAsync(stoppingToken);
                while (sent > 0 && !stoppingToken.IsCancellationRequested);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Receipt worker error");
            }

            try { await Task.Delay(_interval, stoppingToken); }
            catch (OperationCanceledException) { break; }
        }
    }
}
