using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Egress.Workers;

namespace QrBridge.Gateway.Initializer;

/// <summary>
/// The background workers. They run inside IIS; see docs/gateway-to-qrdiode/technical-guide.md §12.4 for app pool settings.
/// </summary>
public static class WorkerRegistration
{
    public static IServiceCollection AddBackgroundWorkers(this IServiceCollection services)
    {
        services.AddSingleton<SequenceGapMonitor>();
        services.AddSingleton<FarSideMonitor>();
        services.AddHostedService<InboxWorker>();
        services.AddHostedService<ReceiptWorker>();
        services.AddHostedService<MaintenanceWorker>();
        services.Configure<HostOptions>(o =>
        {
            o.ShutdownTimeout = TimeSpan.FromSeconds(45);
            // A worker bug must not take the endpoints down with it; workers log and keep going.
            o.BackgroundServiceExceptionBehavior = BackgroundServiceExceptionBehavior.Ignore;
        });
        return services;
    }
}
