using QrBridge.Gateway.Ingress;

namespace QrBridge.Gateway.Initializer;

/// <summary>The Sender part (Ingress/): callers' SOAP requests are checked, saved in the Outbox of qrbridge.db, then answered.</summary>
public static class SenderRegistration
{
    public static IServiceCollection AddSenderPart(this IServiceCollection services)
    {
        services.AddSingleton<RetryCounters>();
        services.AddSingleton<OutboxWriter>();
        services.AddSingleton<WaiterRegistry>(); // held RoundTrip callers, woken by the AnswerReader
        services.AddSingleton<SenderEndpoint>();
        services.AddHostedService<AnswerReader>(); // Receipts and Replies for this side's messages
        return services;
    }
}
