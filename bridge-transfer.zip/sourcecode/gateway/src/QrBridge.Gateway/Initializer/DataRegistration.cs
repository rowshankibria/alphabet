using Microsoft.Extensions.Options;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;

namespace QrBridge.Gateway.Initializer;

/// <summary>What the gateway shares with the QR apps: the SQLite database (qrbridge.db), the message serializer and the doorbells.</summary>
public static class DataRegistration
{
    public static IServiceCollection AddGatewayData(this IServiceCollection services)
    {
        // EF Core + SQLite: qrbridge.db and its repositories.
        services.AddBridgeData();

        // The message bytes are not encrypted here: QrDiode encrypts it on the QR link.
        services.AddSingleton(sp => new MessageSerializer(
            sp.GetRequiredService<IOptions<BridgeOptions>>().Value.MaxPayloadBytes));

        services.AddSingleton<BridgeSignals>();
        return services;
    }
}
