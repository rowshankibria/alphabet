using System.Net;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Egress;

namespace QrBridge.Gateway.Initializer;

/// <summary>The Receiver part (Egress/): the HTTP clients that deliver arrived messages to the real services.</summary>
public static class ReceiverRegistration
{
    public static IServiceCollection AddReceiverPart(this IServiceCollection services)
    {
        services.AddSingleton<SoapForwarderHttpClient>();
        services.AddSingleton<ArrivalChecks>(); // every message from the light, whatever its kind
        services.AddSingleton<AnswerWriter>(); // Receipts and Replies over the opposite lane
        // Timeouts are applied per call by SoapForwarderHttpClient, so the clients have none. The connect timeout is the
        // handler's: when it runs out nothing was sent (decision D9), see SoapForwarderHttpClient.ForwardAsync.
        // "receiver" uses Gateway:Receiver:UseDefaultCredentials; a target that overrides it (decision D75) uses one of
        // the two fixed clients (SoapForwarderHttpClient.ClientNameFor).
        AddReceiverClient(services, SoapForwarderHttpClient.HttpClientName, receiver => receiver.UseDefaultCredentials);
        AddReceiverClient(services, SoapForwarderHttpClient.DefaultCredentialsClientName, _ => true);
        AddReceiverClient(services, SoapForwarderHttpClient.AnonymousClientName, _ => false);
        return services;
    }

    private static void AddReceiverClient(IServiceCollection services, string name, Func<ReceiverOptions, bool> useDefaultCredentials) =>
        services.AddHttpClient(name, client => client.Timeout = Timeout.InfiniteTimeSpan)
            .ConfigurePrimaryHttpMessageHandler(sp =>
            {
                var receiver = sp.GetRequiredService<IOptions<GatewayOptions>>().Value.Receiver;
                return new SocketsHttpHandler
                {
                    ConnectTimeout = TimeSpan.FromSeconds(receiver.ConnectTimeoutSeconds),
                    // The app pool identity (Windows/NTLM/Kerberos); never a password from configuration.
                    Credentials = useDefaultCredentials(receiver) ? CredentialCache.DefaultCredentials : null,
                    AllowAutoRedirect = false, // a redirect would replay the payload somewhere we did not configure
                };
            });
}
