using QrBridge.Gateway.Ingress.Validation;
using QrBridge.Gateway.Routing;

namespace QrBridge.Gateway.Initializer;

/// <summary>The route catalogue (routes.json) and the WSDL contracts it names. Used by both the Sender and Receiver parts.</summary>
public static class RouteCatalogRegistration
{
    public static IServiceCollection AddRouteCatalog(this IServiceCollection services)
    {
        services.AddSingleton<RouteTable>();
        services.AddSingleton(sp => new ContractCatalog(
            sp.GetRequiredService<RouteTable>(),
            Path.Combine(sp.GetRequiredService<IWebHostEnvironment>().ContentRootPath, ContractCatalog.FolderName)));
        return services;
    }
}
