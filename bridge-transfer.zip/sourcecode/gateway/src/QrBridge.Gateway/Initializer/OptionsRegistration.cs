using QrBridge.Shared;

namespace QrBridge.Gateway.Initializer;

/// <summary>Settings: routes.json and the Bridge, Gateway and Routing sections.</summary>
public static class OptionsRegistration
{
    public static WebApplicationBuilder AddGatewayOptions(this WebApplicationBuilder builder)
    {
        // The route catalogue: which services this gateway stands in for, and how it answers them.
        builder.Configuration.AddJsonFile("routes.json", optional: false, reloadOnChange: false);

        // Read only after Build, so environment/test overrides always apply.
        builder.Services.AddOptions<BridgeOptions>().BindConfiguration(BridgeOptions.SectionName);
        builder.Services.AddOptions<GatewayOptions>().BindConfiguration(GatewayOptions.SectionName);
        builder.Services.AddOptions<RoutingOptions>().BindConfiguration(RoutingOptions.SectionName);
        return builder;
    }
}
