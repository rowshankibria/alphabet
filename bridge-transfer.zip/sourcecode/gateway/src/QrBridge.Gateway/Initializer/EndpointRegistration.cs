namespace QrBridge.Gateway.Initializer;

/// <summary>
/// The HTTP endpoints (Controllers/). Thin: the work is in SenderEndpoint.
///   GET  /health     HealthController      (monitoring, load balancer probe, IIS warm-up)
///   POST /{**path}   SenderSoapController  -> SenderEndpoint (every SOAP call)
///   GET  /{**path}   SenderSoapController  -> SenderEndpoint.HandleGetAsync (only a route marked HttpGet, decision D18)
/// Any other GET/HEAD gets 405: the gateway serves no WSDL or help pages (the simulator's clients never fetch them).
/// </summary>
public static class EndpointRegistration
{
    public static IServiceCollection AddGatewayEndpoints(this IServiceCollection services)
    {
        services.AddControllers();
        return services;
    }

    public static WebApplication MapGatewayEndpoints(this WebApplication app)
    {
        app.MapControllers();
        return app;
    }
}
