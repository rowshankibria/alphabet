namespace QrBridge.Gateway.Exceptions;

/// <summary>The outbox has too many undelivered messages; the caller gets the route's Busy reply.</summary>
public sealed class BridgeBacklogFullException(int backlog, int max)
    : Exception($"Bridge backlog is full ({backlog} undelivered, limit {max}). Try again later.");
