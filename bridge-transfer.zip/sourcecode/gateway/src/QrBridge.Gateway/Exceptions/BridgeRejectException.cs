namespace QrBridge.Gateway.Exceptions;

/// <summary>A message that must never be retried (bad signature, wrong direction, not allowed, bad payload).</summary>
public sealed class BridgeRejectException(string reason) : Exception(reason);
