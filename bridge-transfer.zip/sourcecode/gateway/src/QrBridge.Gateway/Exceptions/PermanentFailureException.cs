namespace QrBridge.Gateway.Exceptions;

/// <summary>A message that can never be delivered as configured (e.g. no Receiver target). Goes straight to DeadLetter.</summary>
public sealed class PermanentFailureException(string message, Exception? inner = null) : Exception(message, inner);
