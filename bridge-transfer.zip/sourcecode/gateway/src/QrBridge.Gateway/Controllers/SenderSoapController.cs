using Microsoft.AspNetCore.Mvc;
using QrBridge.Gateway.Ingress;

namespace QrBridge.Gateway.Controllers;

/// <summary>
/// Every SOAP call, to any path: the load balancer sends the callers' unchanged requests here instead of to the
/// real service (e.g. POST /FMS_FC2FMSInterface/FC2FMSInterface.svc). The work is done by <see cref="SenderEndpoint"/>.
///
/// Deliberately thin and NOT an [ApiController]: no model binding, formatters or automatic 400s. The body must stay
/// raw bytes (it is replayed byte for byte) and every error must be a SOAP fault, not JSON.
/// </summary>
[Route("{**path}")]
public sealed class SenderSoapController(SenderEndpoint sender) : ControllerBase
{
    [HttpPost]
    public Task Post() => sender.HandleAsync(HttpContext);

    /// <summary>Only a route marked HttpGet answers (Registered Tags, decision D18); any other GET gets 405.</summary>
    [HttpGet]
    public Task Get() => sender.HandleGetAsync(HttpContext);
}
