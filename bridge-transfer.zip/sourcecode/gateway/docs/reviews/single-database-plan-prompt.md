# Prompt: move the gateway from two SQLite files to one (`qrbridge.db`)

Reusable task prompt. Paste it into a new Copilot session to continue the work, or use it to re-plan if a
session runs out of context. Progress is kept in [single-database-tracker.md](single-database-tracker.md): **read the
tracker first** and continue from the first step that is not ✅.

---

## The request

Rowshan, 25 Nov 2026: replace the two databases on each machine (`send.db` with Outbox + SequenceCounter,
`received.db` with Inbox + Heartbeat + AcknowledgedGap + SequenceWatermark) with **one** SQLite file per machine,
**`qrbridge.db`**, holding all six tables. Same code and schema on Corp and DMZ, one copy on each machine. Change every
relevant place in code, tests and documentation.

This is a mission-critical system (FMS islanding: permits, orders, cards). A mistake can make an operator miss a real
alert or act on wrong data. Rules for this work:

- **Behaviour must not change.** Same tables, columns, indexes, constraints, transactions, statuses and order of
  operations. Only the file they live in, the class that opens it and the names change.
- **Do not combine two existing operations into one transaction** "because we now can". Each repository method keeps
  its own short-lived context and commit. Changing atomicity is a design change for another day, with its own tests.
- **Fail closed on leftovers.** A machine that still has `send.db` or `received.db` may hold messages that were
  accepted but not yet carried or delivered. Starting on a new, empty `qrbridge.db` would silently drop them. The start
  must refuse with a clear message until an operator has checked and moved those files.
- **No guessing.** Every claim in a document must match the code. Say what is built, tested and not tried.
- Follow `.github/copilot-instructions.md` and `.github/instructions/*.md` (one class per file, comment style, never log
  payloads, pinned packages, don't commit).
- Historical documents (the original V6 review, the V6 fix plan, past entries of the V6 fix tracker) describe what was
  true then. Do not rewrite their history; add a dated note where a reader could be misled.

## Design (decided before coding)

| Item | Before | After |
|---|---|---|
| Files per machine | `send.db`, `received.db` | **`qrbridge.db`** |
| `BridgeOptions` | `SendDbPath`, `ReceivedDbPath` | **`DatabasePath`** = `DataFolder\qrbridge.db`; constants for the file names |
| DbContext | `SendDbContext`, `ReceivedDbContext` | **`BridgeDbContext`**: `Outbox`, `SequenceCounters`, `Inbox`, `Heartbeats`, `AcknowledgedGaps`, `SequenceWatermarks`; all six configurations |
| Design-time factory | `SendDesignTimeFactory`, `ReceivedDesignTimeFactory` | **`BridgeDesignTimeFactory`** |
| Repositories | `OutboxRepository`(Send), `InboxRepository`/`HeartbeatRepository`(Received) | Same classes, all on `IDbContextFactory<BridgeDbContext>` |
| `DatabaseInitializer` | creates two files | refuses to start if `send.db` or `received.db` is in the data folder; creates **one** file; WAL; same retries |
| Index and constraint names | `IX_Outbox_*`, `IX_Inbox_*`, `CK_<Table>_*` | Unchanged (already unique across tables: checked) |
| PRAGMAs | WAL, `busy_timeout=5000`, `synchronous=FULL` per connection | Unchanged |
| Doorbells (named events) | Outbox, Inbox | Unchanged |
| QrDiode's own `journal.db` | QrDiode state | **Not touched** (not part of the bridge database) |

Known consequences to document honestly:

1. **One write lock per machine** instead of two: the gateway, the QR Sender and the QR Receiver now queue for the same
   lock. Transactions are short and `busy_timeout` is 5 s; at the light's rate this is not expected to matter, but it
   is a real trade-off and has **not** been measured with the QR apps (they are not connected yet).
2. **Backup and restore cover both directions together.** Restoring `qrbridge.db` from a backup also restores the
   Inbox and the `SequenceWatermark` to that time. The sequence rules (D84) still refuse a reused number, but the
   guide's "restore only a `send.db` whose numbers the far side has not passed" advice must be rewritten for one file.
3. **A damaged or locked file stops both directions** on that machine (before, one could keep working).
4. **Leftover files:** the start refuses while `send.db` or `received.db` exists in the data folder.
5. The schema is still created with `EnsureCreated` (no migrations, known issue 6): delete dev databases.

## Steps (sized so each fits in one working session)

| Step | Scope | Done when |
|---|---|---|
| 0 | This prompt + the tracker; baseline `dotnet test All.slnx` | Baseline result recorded |
| 1 | `QrBridge.Shared`: options, context, design-time factory, DI, initializer (+ leftover guard), repositories, entity/serializer comments | `dotnet build sourcecode\gateway\QrGateway.slnx` builds the Shared project; Gateway/Tests may not yet compile |
| 2 | `QrBridge.Gateway`: `OutboxWriter`, registration comments, `Program.cs`, `.csproj` description | Gateway builds |
| 3 | `QrBridge.Tests`: every `SendDbContext`/`ReceivedDbContext` use; new tests: one file with all six tables and no old files; start refused with leftovers; both PRAGMAs on the one file | `dotnet test All.slnx` green; counts recorded |
| 4 | Living docs: `.github/copilot-instructions.md`, `.github/instructions/*`, `.github/prompts/*`, `docs/handoff.md`, `docs/gateway-to-qrdiode/{architecture,technical-guide,integration-plan}.md`, gateway `README.md`s, `sourcecode/gateway/docs/{gateway.md,q_&_a/*,reference/*,workflows/*}`, QrDiode tutorial line; dated note in the V6 fix tracker | No stale `send.db`/`received.db`/two-database wording outside historical text; links resolve |
| 5 | Final check: repo-wide search for leftovers, full test run, independent code review of the diff, tracker closed | Review findings fixed or reported |

## Commands

```powershell
dotnet build sourcecode\gateway\QrGateway.slnx
dotnet test All.slnx
# Windows PowerShell 5.1: do not run dotnet under $ErrorActionPreference = "Stop" while capturing output.
```

Leftover search (must return only historical text):

```text
send\.db|received\.db|SendDbContext|ReceivedDbContext|SendDbPath|ReceivedDbPath|SendDesignTimeFactory|ReceivedDesignTimeFactory|outbound,inbound|two databases|both databases
```
