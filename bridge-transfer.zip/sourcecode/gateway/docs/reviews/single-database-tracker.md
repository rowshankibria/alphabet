# Tracker: one database per machine (`qrbridge.db`)

Plan and rules: [single-database-plan-prompt.md](single-database-plan-prompt.md). Requested by Rowshan, 25 Nov 2026.

Legend: ✅ done and verified · 🔄 in progress · ⬜ not started · ⚠️ needs Rowshan

## Steps

| Step | Status | Scope | Verification |
|---|---|---|---|
| 0 | ✅ | Prompt, tracker, baseline test run | Baseline `dotnet test All.slnx`: QrBridge.Tests **447 passed**, QrDiode.Core.Tests **75 passed**, 0 failed |
| 1 | ✅ | `QrBridge.Shared` data layer | `QrBridge.Shared` builds, 0 errors (2 warnings: NU1900, an unreachable NuGet feed, also in the baseline) |
| 2 | ✅ | `QrBridge.Gateway` code | `QrBridge.Gateway` builds, 0 errors (warnings: NU1900 only) |
| 3 | ✅ | `QrBridge.Tests` + new tests | `dotnet test All.slnx`: QrBridge.Tests **451 passed** (447 + 4 new), QrDiode.Core.Tests **75 passed**, 0 failed. Mutation check: with the leftover guard disabled, the 3 refusal tests fail; restored |
| 4 | ✅ | Documentation | Living docs updated (instructions, prompts, handoff decision 47 + verification + troubleshooting, architecture, integration plan, technical guide §3.2, §6.1 rewritten, §6.4, §7.1, §8, §11, §12.4 backup/restore rewritten, glossary, Appendix B D3, gateway README, Contracts README, gateway.md, code walkthrough, workflow, q_&_a/* (folder was `files/`), QrDiode WPF tutorial). Dated notes added to the V6 fix plan and tracker (history kept). Link and anchor check over 23 changed Markdown files: 0 problems |
| 5 | ✅ | Final search, full test, independent review | Repo-wide search: every remaining `send.db`/`received.db` mention is history or the start-up guard. Final `dotnet test All.slnx`: **451 + 75 passed**, 0 failed. Independent code review (EF model clashes, shared write lock, guard bypass, start-up order, tests): **no issues found** |

## Log

| Date | Step | What happened |
|---|---|---|
| 25 Nov 2026 | 0 | Scope measured: 290 mentions in 50 files (32 `.cs`, 17 `.md`, 1 `.csproj`). Index names (`IX_Outbox_*`, `IX_Inbox_*`) and CHECK constraint names (`CK_<Table>_*`) are already unique across tables, so one file needs no renames. QrDiode's own `journal.db` is unrelated and stays. |
| 25 Nov 2026 | 1 | `BridgeDbContext` (six tables, the same six configurations) and `BridgeDesignTimeFactory` replace the four old classes. `BridgeOptions.DatabasePath` (+ `DatabaseFileName`) replaces `SendDbPath`/`ReceivedDbPath`. `DatabaseInitializer` creates one file and refuses to start while `send.db` or `received.db` is in the data folder (`FormerDatabaseProblem`, outside the retry loop). Repositories: context type only; every query unchanged. Comments and the operator-visible D84 rejection reason now name `qrbridge.db`. `SequenceCounter`'s backup note now says a restore also brings back the Inbox and SequenceWatermark. |
| 25 Nov 2026 | 2 | `OutboxWriter` uses `BridgeDbContext` (its `BEGIN IMMEDIATE` transaction is unchanged; it now holds the one file's write lock). Comments in `Program.cs`, `DataRegistration`, `SenderRegistration`, `StartupChecks` and the `.csproj` description updated. |
| 25 Nov 2026 | 3 | 9 test files: context type only (20 lines). The G-14 test now checks one connection for `synchronous=FULL` **and** `journal_mode=wal`. New: `One_database_file_holds_every_bridge_table` (only `qrbridge.db` in the folder; exactly the six tables), `The_database_is_not_created_while_a_former_database_is_in_the_data_folder` (send.db, received.db), `A_former_database_in_the_data_folder_stops_the_gateway_from_starting` (real gateway). |
| 25 Nov 2026 | 4 | **Mistake, caught and repaired:** a PowerShell replace script flattened a one-item list and replaced every `i` with `n` in `sourcecode/gateway/docs/reference/uncovered-services.md`. Proven that the damaged file equalled the committed version with exactly that replacement (no other local edits), restored it with `git checkout`, re-applied the one intended anchor change. Other files in that script checked: only the intended diffs. Bulk replaces after this: explicit per-file edits only. |
| 25 Nov 2026 | 5+ | Second sweep before commit, at Rowshan's request: searched every `.md`, `.cs` and `.json` for `send.db`, `received.db`, "databases", "two files", "DbContexts", "each context" and similar. Fixed 13 more current statements still in the plural: V6 tracker release gate §3.2 and a remaining item, integration plan §2.2 (migrations: one context) and §3.4, technical guide map and Appendix B D13, copilot-instructions map, the bundles prompt, `DataRegistration` summary, and three test-helper comments (`GatewayHost`, `FakeLight`, `TwoGatewayBench`). Kept on purpose: "delete dev databases" (one per machine, so plural is right), the former-file guard and its tests, dated history, and the original V6 review and fix plan text (covered by their dated notes). Gateway solution builds; comment-only code changes. |

## Decisions taken during the work

| # | Decision | Why |
|---|---|---|
| S1 | One context, `BridgeDbContext`, with all six tables; repositories unchanged apart from the context type | Smallest change that keeps every query identical |
| S2 | No operations merged into a single transaction | Behaviour must not change; atomicity changes need their own design and tests |
| S3 | Start-up **refuses** when `send.db` or `received.db` is in the data folder | They may hold accepted but undelivered messages; starting empty would drop them silently. Fail closed. ⚠️ Rowshan may prefer a warning: say so and it is a one-line change |

## Open points for Rowshan

- S3 above: refusal (current) or warning.
- The single write lock is not measured with the real QR apps (not connected yet).
- Restoring `qrbridge.db` from a backup now also rolls back this side's Inbox and `SequenceWatermark` (guide §12.4):
  messages that arrived after the backup must be checked, and the "old number" check is weaker above the restored
  watermark until it catches up. Not tested.
- Nothing is committed: review the diff and commit when satisfied.
