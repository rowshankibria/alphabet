# Fix plan for the V6.0 review findings (G-01 … G-17)

Plan only — **nothing in this document is built yet.** Written 24 Nov 2026 from
[qr-proxy-design-review-and-security-audit-v6.0.md](qr-proxy-design-review-and-security-audit-v6.0.md) §4, checked
against the gateway code as it is today. Updated the same day with Rowshan's answers (D1–D24) and the agreed
round-trip design (section 4). Progress, step order and the verification log are in
[gateway-review-v6-fix-tracker.md](gateway-review-v6-fix-tracker.md), the source of truth for progress.

**Status marks.** ✅ checked in the code today · 🔶 planned here · ❓ needs a decision from Rowshan first.

> **Note, 25 Nov 2026:** where this plan says `send.db` or `received.db`, read the Outbox or the Inbox table of
> **`qrbridge.db`**: the two files were merged into one per machine, with the same tables (handoff decision 47,
> [single-database-tracker.md](single-database-tracker.md)). The plan text below is kept as written.

---

## Contents

1. [Read this first](#1-read-this-first)
2. [Each finding against the code](#2-each-finding-against-the-code)
3. [Decisions](#3-decisions)
4. [The agreed design: round trip, statuses, re-sending](#4-the-agreed-design-round-trip-statuses-re-sending)
5. [The plan, finding by finding](#5-the-plan-finding-by-finding)
6. [Order of work](#6-order-of-work)
7. [After each phase](#7-after-each-phase)

---

## 1. Read this first

- **The review did not see the code.** It was written from
  [gateway-qrdiode-workflow.md](../workflows/gateway-qrdiode-workflow.md) only (review §0, "Limit of this review"). Section 2 below
  checks each finding against `sourcecode/gateway/src`. All 17 are still true in substance. Four are partly out of
  date: the review missed something already built or something a later decision changed.
- **Three fixes would reverse settled decisions.** G-05 (encryption at rest) goes against decision 23. G-06
  (three processes) goes against "two programs per machine". G-01/G-02 (receipts, hold-and-return) need answers to
  cross back. Section 3 lists the decisions. Rowshan answered most of them on 24 Nov: G-05 keeps decision 23 (D3),
  and the answers use the **existing opposite QR lane** (D1), so no new hardware is needed. The security sign-off
  (HANDOFF §10 Q7) must now also cover Replies and Receipts carrying data back.
- **The most important finding is G-01.** For permits and orders, the DMZ gateway answers `RETURN_CODE 0` as soon as
  the message is saved. The FMS monitor then deletes its event, so the dispatcher never gets the "issue it verbally"
  message, even if the message is lost later on the light. The only real fix is the round trip (section 4): the
  caller is held until the real service's answer comes back over the opposite lane. Everything before that makes
  losses **visible**. It does not make them **safe**.

---

## 2. Each finding against the code

| # | Sev | Still true in the code? | What the code shows ✅ | Kind of fix |
|---|---|---|---|---|
| G-01 | Critical | **Yes** | `SenderEndpoint.DecideAsync` returns the `Ok` profile (`RETURN_CODE 0`) right after `OutboxWriter.EnqueueAsync` commits | design (section 4) + code |
| G-02 | Critical | **Yes** | `OutboxStatus` has `Acked`, but nothing calls `MarkAckedAsync`. `Sequence` is stored, but nothing looks for gaps | code now (detect) + receipts (D1, D9) |
| G-03 | High | **Yes** | Dedupe only on the gateway's `MessageId`. `ResetStuckAsync` re-POSTs after 5 min; transient failures retry up to 8 times | content fingerprint (D5) + re-post rules (D9) |
| G-04 | High | **Yes** | Known issues 1–3 are still open (Integration-Plan §2.1, §2.4, §2.5) | QrDiode code (already planned) |
| G-05 | High | **Yes** | `MessageBytes` holds the plain body with Brotli compression. This is on purpose since decision 23 | ops: keep decision 23 (D3) |
| G-06 | High | **Partly** | Since decision 23 the gateway holds **no keys**: QrDiode keys live in the Sender/Receiver processes. Egress still uses the app pool identity (`UseDefaultCredentials`) | D4 answered 25 Nov (a): ops in guide §12.4 + admin warning (step 18) |
| G-07 | High | **Yes** | One global `Receiver:UseDefaultCredentials`. No caller host in `MessageHeader` | code + config |
| G-08 | High | **Partly** | FTC **is** in `routes.json` (`FMS2FTC.GetFaultCorrelation` = `Unavailable`, no reply profile, so the caller gets a SOAP fault and returns `-1`). `PortalSyncRequest` and `GetFromFMS` = `Unavailable` (1599) | config now + round trip (D13–D19) |
| G-09 | Medium | **Yes** (config) | `appsettings.Dmz.json` `DefaultBaseUrl = "http://dmz-rr-server"` (a placeholder). No HTTPS check at start-up | config + startup check |
| G-10 | Medium | **Yes** | `Bridge:MaxPayloadBytes` = 1,000,000. Real sizes unknown | measure, then config |
| G-11 | Medium | **Partly** | The gateway is generic on purpose (settled decision 2). The WSDL check (decision 24) covers the body element and the XSD, but **the `SOAPAction` header is not compared with the WSDL** | code |
| G-12 | Medium | **Yes** | One `InboxWorker` claims the lowest ready `Sequence` across all services; 120 s timeout per try | code + `routes.json` |
| G-13 | Medium | **Yes** | `CountBacklogAsync` runs on its own connection **before** the insert transaction. One global `MaxBacklog`. `StartupChecks` does not check `RetentionDays ≥ ReplayWindowDays` | code |
| G-14 | Medium | **Yes** | `SqlitePragmaInterceptor`: `synchronous = NORMAL`. `EnsureCreated`, no migrations. Event ACL: Authenticated Users may signal | code + migrations (planned) |
| G-15 | Medium | **Partly** | The WSDL check runs **before** the content check (`AllowedTypes`). But nothing proves both sides run the same `routes.json`: the header has no catalogue version | code |
| G-16 | Medium | **Yes** | `/health` and the heartbeats exist per side. Nothing crosses the gap | needs the opposite lane (D1) |
| G-17 | Low | **Yes** | `SoapForwarderHttpClient.Classify`, `default:` branch: a 2xx reply with no recognisable result counts as `Delivered` | code |

---

## 3. Decisions

Rowshan answered on 24 Nov 2026. The full wording of every answer is in the tracker
([§2 Decisions](gateway-review-v6-fix-tracker.md#2-decisions)); this is the short form. "Open" decisions block only
the steps named in the last column.

| # | Question | Answer (short) | Gates |
|---|---|---|---|
| D1 | Return path for answers | The **existing opposite lane**: a Reply or Receipt is a normal message going the other way. No new hardware. (Replaces the earlier recommendation of an acknowledgement-only lane) | G-01, G-02, G-08, G-16 |
| D2 | Permit/order routes in real islanding before the round trip is built | **Allowed, risk accepted by Rowshan.** `IssueWorkPermit` stays pilot-only until D12 | G-01 |
| D3 | Encryption at rest (G-05) | Keep decision 23; clear the body of delivered Inbox rows; BitLocker + ACLs | G-05 |
| D4 | Process separation (G-06) | **Answered 25 Nov (Rowshan):** the recommended option — a dedicated app pool identity per side, data-folder ACL, IIS limits, IP restrictions later; the only code is a start-up warning when running as an administrator (step 18) | G-06 (step 18) |
| D5 | How a caller's retry is recognised | **Content fingerprint** (section 4.4), not an id field. Must be checked against captured real retries before it is trusted on permit/order routes | G-03 |
| D6 | DMZ callers that send Negotiate credentials | **Anonymous calls from the intranet** (Rowshan, 25 Nov; IP restrictions may follow). IIS only; against the review's recommendation | G-07 (step 15) |
| D7 | Route catalogue check (G-15) | A catalogue fingerprint in every message | G-15 |
| D8 | What a state-changing caller gets when the hold runs out | Non-zero **`1596`** "sent over the QR bridge, confirmation not yet received" | G-01 |
| D9 | Re-sending | Over the light: re-air until the far side's Receipt arrives. To the real service: re-post **only** when the call surely did not arrive; when it may have arrived, `Unknown` + operator alarm. Every outcome is stored with its HTTP code and a probable reason (section 4.3) | G-02, G-03 |
| D10 | How much may the FMS (DMZ) callers change? | The URL only (registry). They keep the .NET default timeout of 100 s | G-01 |
| D11 | Hold time | In appsettings: Corp routes 270 s, DMZ routes 90 s, per-service overrides | G-01 |
| D12 | `IntMgr.CardCutOut` after a permit's first failed attempt | Rowshan asks the FMS team | `IssueWorkPermit` |
| D13–D19 | Calls that expect data back (uncovered-services.md) | Round trip for the queries and pushes, the polls stay `Unavailable`; per row in [uncovered-services.md](../reference/uncovered-services.md) | G-08 |
| D20–D23 | ReportService, internal services, RTF/Maximo/no-source services, whether XA/21 and BFC cross | **Open** (recommendation: leave them out) | — |
| D24 | Where the status of a message is kept | No new table: **two status groups per row**, light and service (section 4.2) | G-01, G-02, G-16 |

Also still open from the review (§11): real payload sizes (Q4), who calls `GetFromFMS` (Q7), certificates (Q9), and
whether the ~12-minute fallback window is acceptable (Q12).

---

## 4. The agreed design: round trip, statuses, re-sending

🔶 **Planned, not built.** Agreed with Rowshan on 24 Nov 2026 (D1–D24). The tracker's steps 4–14 build it. Until
the QrDiode apps are connected to the databases (Integration-Plan §5 steps 1–4), it can be proven only with a fake
light in the tests; **it does not work on real screens and cameras before then.**

### 4.1 How a call crosses and how its answer comes back (D1)

The two existing QR lanes carry three kinds of message. The new header field `Kind` (step 4) says which one a row is:

| Kind | Made by | Carries | Purpose |
|---|---|---|---|
| `Request` | the Sender part (`OutboxWriter`), from a caller | the caller's SOAP body, byte for byte (today's message) | the call |
| `Receipt` | the far Receiver part, after the Inbox commit (step 9b: one Receipt per stored message) | the `MessageId` stored (`CorrelationId`) | "it crossed the light": stops re-airing |
| `Reply` | the far Receiver part, after the real service answered (or could not be called) | the real HTTP status, Content-Type and body (capped), or "no answer" with the status and the reason | the answer for the waiting caller, or for its retry |

A Reply implies a Receipt. Receipts and Replies are never POSTed to a service: the gateway that sent the Request
consumes them. Every delivered Request gets a Reply, also on routes whose callers are not held, so the sending side
always knows what the real service did (section 4.2).

✅ **Built 24 Nov 2026 (tracker step 9b, D43–D47), the far side's half:** a **Receipt** per arrived message (`Kind =
Receipt`, `CorrelationId` = the message that arrived, empty body; sent again when the same `MessageId` arrives a second
time, Inbox column `ReceiptDueUtc`; a Receipt never gets a Receipt). A **Reply** for every final outcome of a Request
— Done, Refused, Unknown, Expired, NotDelivered and Rejected — in header version 5 (`BRG5`: `Outcome`,
`ServiceHttpStatus`, `ServiceComment`), with the real answer byte for byte (left out above `Bridge:MaxPayloadBytes`),
written before the Inbox row is marked; a row found Delivering after a crash adopts its Reply's outcome, else
Unknown. Both go through `OutboxWriter` and never count against `MaxBacklog`. **Not built:** carrying them over the
real light (QrDiode wiring).

✅ **Built 24 Nov 2026 (tracker step 10a, D49–D56), the sending side's half:** `AnswerReader` reads arriving Receipts
and Replies after the same arrival checks as any message (`ArrivalChecks`: catalogue, direction, replay window,
columns = header), checks that a Reply answers a Request of this side for the same service and operation, stores it
(`MarkReceivedAsync` / `MarkAnsweredAsync`, the first answer, or a newer one after an operator requeue unless the stored one is `Answered`, D59; new Outbox statuses `NotDelivered` and `Rejected`, D51)
and wakes the held callers (`WaiterRegistry`). The far side now delivers RoundTrip Requests. Steps 1–6 below are built
for the routes that are RoundTrip in `routes.json`; proven with two in-memory gateways and a fake light (`HoldTests`).

The life of a held call (`RoundTrip` route):

1. The caller's request reaches the Sender part. Today's checks run unchanged (route, WSDL, `AllowedTypes`, size).
2. The content fingerprint is computed (section 4.4). If the same content was sent in the window, the call
   **attaches** to that first message: no second Outbox row.
3. The waiter is registered, then the Request is committed to the Outbox with `CorrelationId` empty, `ExpiresUtc`,
   `SequenceRunId`, `CatalogFingerprint` and `CallerHost` in its header. Then the database is checked for an answer
   already stored, then the call waits (tracker §4.1 explains the order).
4. The QR Sender airs it. The far QR Receiver stores it in the Inbox; the far Receiver part writes a **Receipt** to
   its own Outbox, which crosses back.
5. The far Receiver part checks it (catalogue fingerprint, expiry, replay window), POSTs it to the real service, and
   classifies the outcome (section 4.3). It writes a **Reply** with `CorrelationId` = the Request's `MessageId`.
6. The Reply crosses back. The Sender part stores it, marks the Outbox row answered and wakes the waiter. The caller
   gets the real service's answer **byte for byte** (status, Content-Type, body). If the hold runs out first, the
   caller gets the route's hold-timeout answer (section 4.5).

The link between a held HTTP call and its answer is the `MessageId`, never `MSG_ID` or `RRMsgID`.

### 4.2 Two status groups per row (D24)

No new table. Today's single `Status` on each table becomes **two groups of columns**, so an operator sees at once
whether a problem is **on the light** or **at the service end**. `LastError` is split into the two comments.

| Table | Group | Columns | Values |
|---|---|---|---|
| Outbox (`send.db`) | **Light** | `LightStatus`, `LightComment`, `LightUpdatedUtc` | `Pending` → `Sending` → `Aired` → `Received` (the far side's Receipt arrived) · `Failed` (out of re-air tries, or expired before a Receipt came; operator alarm; ✅ step 11) |
| Outbox | **Service** (what the far side's real service did) | `ServiceStatus`, `ServiceHttpStatus`, `ServiceComment`, `ServiceUpdatedUtc` | `Waiting` → `Answered` · `Unknown` · `Refused` · `Expired` · `NotAvailable` |
| Inbox (`received.db`) | **Light** (arrival) | `LightStatus`, `LightComment` | `Received` · `Rejected` (bad checksum, catalogue mismatch, replay; a sequence gap is noted in the comment) |
| Inbox | **Service** | `ServiceStatus`, `ServiceHttpStatus`, `ServiceComment`, `ServiceUpdatedUtc`, `DownstreamResult` (kept) | `Pending` → `Delivering` → `Done` · `Retrying` · `Unknown` · `Refused` · `Expired` · `NotDelivered` (D25) |

✅ **Built 24 Nov 2026 (tracker step 5a):** these columns and values exist and replace `Status`, `LastError`,
`AckedUtc` (now `LightUpdatedUtc`) and `ProcessedUtc` (now `ServiceUpdatedUtc`). Rejected Inbox rows keep
`ServiceStatus = Pending` but are never claimed, requeued or counted as service work. Not set yet: `Aired` (QR
sender), Outbox `ServiceStatus` changes (Replies, step 10), Inbox `Expired` (step 9).

✅ **Built 24 Nov 2026 (tracker step 5b):** the header copies `Kind`, `CorrelationId`, `ContentFingerprint`,
`ExpiresUtc` on both tables (indexes on the Outbox fingerprint + time and `CorrelationId`), the Outbox reply columns
`ReplyContentType`, `ReplyBody` (≤ `Bridge:MaxPayloadBytes`), `OutboxRepository.MarkAiredAsync(messageIds)` and
`MarkAnsweredAsync` (first answer wins; a Reply implies a Receipt). The Inbox claims **Requests only**, and
`InboxWorker` rejects a row whose columns disagree with its header or whose header is not a Request.

- `ServiceHttpStatus` holds the real HTTP code (for example 502), null when there was no HTTP answer (DNS, refused
  connection, timeout).
- `ServiceComment` holds the code and its **probable reason** in plain words (section 4.3), for example "HTTP 502:
  the load balancer lost the service's answer; the service may have processed it". Never the payload.
- **Hardware failures** (screen, camera, a QR app not running) have no HTTP code. They show as an Outbox
  `LightStatus` that does not advance (`Aired`, no Receipt), with the reason in `LightComment`, for example "aired 3
  times, no receipt after 120 s: check the screen, the camera and the far QR Receiver".
- `/health` counts the two groups separately ("light problems: n, service problems: m").
- How today's values map: Outbox `Pending`/`Sending`/`Failed` stay in the light group, `Acked` becomes `Received`.
  Inbox `Rejected` moves to the light group; `Processing` → `Delivering`, `Failed` → `Retrying`, `DeadLetter` →
  `Refused` or `Unknown` (depending on the reason, section 4.3).
- ✅ **Answered 24 Nov (D25):** a Request that surely never reached the service and has no tries left (or can never be
  sent as configured, e.g. no Receiver target) ends as `NotDelivered`, with an operator alarm. ✅ Since step 9a only
  "nothing sent" failures are retried, so "out of retries" ends as `NotDelivered` (D26 no longer applies).

Built in step 5a (the two groups, 24 Nov 2026) and 5b (the remaining columns); `/health` in step 6.

### 4.3 What the far side does with the real service's answer (D9)

Rule: **re-post only when the call surely did not arrive.** When in doubt, `Unknown` + operator alarm, never a
silent re-post. Re-posting after a "may have arrived" outcome is how duplicate permits and orders happen.

| Outcome of the POST | Probable reason (goes into `ServiceComment`) | Inbox `ServiceStatus` | Re-post? |
|---|---|---|---|
| 2xx with `RETURN_CODE 0` / return code 0, HTTP 202, or 2xx on a void operation | delivered | `Done` | — |
| 2xx, but the reply cannot be read for a route that expects a result (G-17) | processed, result unknown | `Unknown` + alarm | No |
| SOAP fault, or a non-zero `RETURN_CODE` / return code | the service refused it (its own reason is kept in `DownstreamResult`) | `Refused` | No |
| HTTP 400, 401, 403, 404, 405, 415 and other 4xx (except 408, 429) | bad request, credentials, URL or Content-Type: not processed | `Refused` | No |
| DNS failure | the name does not resolve: nothing sent | `Retrying` | Yes |
| Connection refused / unreachable, connect timeout | service or host down: nothing sent | `Retrying` | Yes |
| TLS handshake failure | certificate or protocol problem: nothing sent | `Retrying` | Yes |
| HTTP **408** | the server gave up waiting for our request: not processed | `Retrying` | Yes |
| HTTP **429** | throttled: not processed | `Retrying` | Yes, with back-off |
| Timeout **after** the request was sent | the service is slow or hung and may have processed it | `Unknown` + alarm | No |
| Connection reset / response ended early | the service or the load balancer dropped the call: may have processed it | `Unknown` + alarm | No |
| HTTP **500** | the service failed while processing, possibly partway | `Unknown` + alarm | No |
| HTTP **502**, **504** | the load balancer or a proxy lost the service's answer: may have processed it | `Unknown` + alarm | No |
| HTTP **503** | usually IIS refusing (app pool stopped), but a load balancer or the service can also send it | `Unknown` + alarm | No |
| A row found `Delivering` after a crash or restart, or a shutdown during the POST (D41) | the POST may have been sent | `Unknown` + alarm | No |
| The Request arrives after its `ExpiresUtc` | the caller has given up (or the dispatcher went verbal) | `Expired`, not posted | No |
| HTTP 3xx (redirects are off), **501**, **505** (D40) | not processed at that URL / the server cannot process it | `Refused` | No |
| Any other 5xx, 1xx or an odd status (D40) | when in doubt, it may have arrived | `Unknown` + alarm | No |

✅ **Built 24 Nov 2026 (tracker step 9a, D39–D42)** for every row above, one test per row
(`DeliveryOutcomeTests`, `DeliveryClassificationTests`, `RepositoryTests`). Out of tries (all of them "nothing sent")
→ `NotDelivered` (D25). The connect timeout is `Gateway:Receiver:ConnectTimeoutSeconds` (15 s, shorter than every
delivery timeout; start-up check). Real-socket tests on 127.0.0.1 prove two rows with .NET's own network stack: a
refused connection arrives as `HttpRequestError.ConnectionError` (→ re-posted), and a service that accepts the
connection and never answers ends `Unknown` after one POST. ✅ The Reply for every outcome is built too (step 9b);
fast failure for queries moved to step 10 (D48).

- Re-posts are **bounded** (count and back-off) and never after `ExpiresUtc`.
- **Queries (fast failure, Uncovered-Services §6):** when the service surely cannot be reached, a "no answer" Reply
  is sent at once instead of retrying, because the caller's hold is short. ✅ **Built 24 Nov 2026 (tracker step 10b):**
  a round-trip query (`OnHoldTimeout: Unavailable`) whose POST surely did not arrive ends `NotDelivered` after one try.
- Every outcome produces a Reply carrying the status and the reason, so the sending side's Outbox shows the same
  `ServiceStatus` (`Done` → `Answered`). ✅ **Step 10b (D59):** after an operator requeue the far side sends a second
  Reply; it replaces the sending side's stored answer unless that one is `Answered`, and only if it is newer (by the
  far side's clock, Outbox column `ReplyCreatedUtc`).
- **Implementation:** .NET reports the kind of network failure in `HttpRequestException.HttpRequestError`
  (`NameResolutionError`, `ConnectionError`, `SecureConnectionError` → nothing sent; anything else, e.g.
  `ResponseEnded`, → `Unknown`). `SocketsHttpHandler.ConnectTimeout` ends a connect attempt with an
  `OperationCanceledException` wrapping a `TimeoutException` before the per-call deadline; any other timeout comes
  after sending. An `IOException` while reading the answer is a reset → `Unknown`.

### 4.4 Caller retries: the content fingerprint (D5)

- A caller's retry is a **new** HTTP call with a new `RRMsgID` (and a new `MSG_ID` or a static one, project rule).
  It is recognised by its **content**: the SHA-256 of the business payload (read with `SafeXml`), with the fields
  that change on every send left out, plus the service, operation and `TYPE`.
- Left-out fields: `MSG_ID`, `GMT_TIME_SENT`, `RRMsgID` by default; the list is configurable per route (step 7).
- Window: 30 min by default. Same fingerprint in the window = the same message.
- No new table: a `ContentFingerprint` column on the Outbox with an index. The check and the insert run in **one
  transaction** (SQLite has one writer), so two identical calls at the same moment create one row.
- A retry attaches to the first `MessageId`: it gets the stored answer, or waits for it. **No second Outbox row.**
- ✅ **Built 24 Nov 2026 (tracker step 8, D37, D38):** `ContentFingerprint.Compute` (service, operation, TYPE, the
  operation element as received and its payload without the `FingerprintIgnore` fields; whitespace kept, SOAP headers
  out) and the attach in `OutboxWriter`, in the same write transaction as the insert (`BEGIN IMMEDIATE`; no unique
  index, which could not express the window). Window `Gateway:RetryWindowMinutes` = 30. **Attach only where the route's
  `RecogniseRetries` is on: default RoundTrip only.** `Bridge` routes (since step 10c only the feeds) still queue the same content
  again; their rows carry the fingerprint and the repeat is counted on `/health` (`retries.sameContentQueued`) as
  evidence for the §3.2 gate. ✅ Since step 10a a RoundTrip caller is held, and an attached retry waits for the first
  message's answer or gets the stored one. **D56 (24 Nov):** the default is on only for RoundTrip routes whose
  hold-timeout answer is 1596; read-only queries are never attached (an earlier, or expired, answer must not be reused).
  **D63 (step 10c):** nor is a retry attached to a message that surely was not done (`Expired`, `NotDelivered`,
  `Rejected`): it is queued as a new message with a fresh expiry.
- On the far side, before a POST: if a Reply for this `CorrelationId` is already in its Outbox, or the same
  fingerprint is already `Done` in the window, it does not POST again. ✅ **Step 10b (D57, D58):** the first case
  needs no check (a `Done` row is never requeued; a row found `Delivering` after a crash adopts its Reply, D46). The
  second, on routes that recognise retries: an earlier same-content Request `Done` → not posted, its answer reused;
  `Unknown` or `Delivering` → not posted, `Unknown`; `Refused`/`NotDelivered`/`Expired` → posted (surely not
  processed). Window `Gateway:RetryWindowMinutes`, by the far side's arrival time. Proven with two Corp gateways
  sending the same content to one DMZ gateway (`FarSideTests`).
- The body is never changed: the fingerprint is computed from a read-only copy.
- Risks (tracker §4.2): too wide (a changing field not left out) misses a retry; too narrow suppresses a real
  second message. Every attach is logged (ids only) and counted on `/health`.

### 4.5 Hold, timeouts and what the caller sees (D8, D10, D11, D19)

| Route kind | Real answer arrives in time | Hold runs out |
|---|---|---|
| State-changing (permits, orders, cards, `WITHDRAW_RFP`, the `GetFrom…` rows with unknown message types) | the real answer, byte for byte | **`1596`** "sent over the QR bridge, confirmation not yet received" (D8) |
| Read-only query (D13) | the real answer | the route's "not available" answer (`1599` or a SOAP fault) |
| DMZ `PortalSyncRequest` (D19) | the real answer | an **empty** `GMT_TIME_STAMP` (new profile `PortalSyncDown`); the monitor exits and tries next cycle |
| Registered Tags GET (D18) | the real status, Content-Type and body | HTTP 504 `text/plain` (D69, step 12) |

- Hold: `Gateway:Hold:DefaultSeconds` plus per-service overrides. Corp routes **270 s** (the simulator's Rapid
  Restore client waits 5 min), DMZ routes **90 s** (the FMS clients keep the .NET default of 100 s, D10).
- `ExpiresUtc` per route, longer than the caller's retries: for the FMS monitors (5 attempts × 180 s) about 10 min,
  so a permit never arrives after the dispatcher has been told to issue it verbally. Uses the sender's clock: both
  sides need a time source while islanded. ✅ **Built 24 Nov 2026 (tracker step 10c, D62):** `Gateway:Expiry`
  (appsettings, per side, like the hold) **600 s** on both sides for state-changing round trips; start-up refuses one
  not longer than the service's hold. Queries expire with their hold (D54); `Bridge` feeds never.
- A retry after `1596` attaches by fingerprint: it gets the stored answer if it has arrived, otherwise it is held
  again.
- IIS runs **one** worker process for the gateway; an app pool recycle drops held calls (their retries find the
  stored answer). The load balancer's and IIS's idle timeouts must be longer than the hold (tracker §3.2 gate).
- Route modes (step 7): `Bridge` (today's immediate answer, "queued"), `RoundTrip` (held), `Unavailable`, set per operation
  and, inside `GetFromFMS` and `ProcessMessage`, per message `TYPE`.
  ✅ **Configured 24 Nov 2026 (tracker step 7):** `RoundTrip`, `OnHoldTimeout` (`Pending` = the profile's new
  `Pending` value, 1596; or `Unavailable`), `Types`, `FingerprintIgnore` (catalogue-wide `MSG_ID`, `GMT_TIME_SENT`,
  `RRMsgID`, plus per route), `Gateway:Hold` (Corp 270 s, DMZ 90 s) and the profile `PortalSyncDown` (1599 + empty
  `GMT_TIME_STAMP`, D34). D13–D19 are applied in `routes.json`. ✅ **The hold is built (tracker step 10a, 24 Nov
  2026):** a RoundTrip call is queued and held; the answer per Reply outcome is D50 (the real answer byte for byte only
  when the service accepted or refused it and its answer came back; 1596 / "not available" otherwise); a query expires
  with its hold (D54); a message that can no longer cross (light `Failed`) gets the hold-timeout answer at once (D55).
  The XA/21 and BFC round-trip types are `Unavailable` until D23 is answered (D52); `PortalSyncDown` got a `Busy`
  value equal to its `Unavailable` (D53). ✅ **Step 10c (D60, D61):** permits, orders, cards and their responses are
  `RoundTrip` + `Pending` (every Corp `SendTo…` route except FTC and Verizon; DMZ FMS2FC incl. `IssueWorkPermit`,
  FMS2FOD, FMS2SSO, TLS2SSO, TOMS2SSO, DSO2SSO); the feeds stay `Bridge` (FMS2FSS, FMS2Dashboard, FMS2SSLog, FMS2VR,
  FTC2FMS `FAULT_CORRELATION`, VZ2TLS).

### 4.6 Calls that expect data back (D13–D19)

The decision for every row is in [uncovered-services.md](../reference/uncovered-services.md). In short:
queries `AUTHORIZE_USERS`, `GET_FEEDER_INFO`, `GET_RELAY_TARGET`, `BUS_FAULT_CORRELATION_REQUEST` and the DMZ FTC
`GetFaultCorrelation` → round trip; `WITHDRAW_RFP` and the `GetFrom…` operations with no known message types → round
trip with the state-changing rules; `DISPLAY_ERROR`, `DEVICE_STATUS_CHANGE` → round trip; the polls `DISPLAY_POLL`
and `BUS_FAULT_OUTAGE_REQUEST` → stay `Unavailable`; Registered Tags GET → round trip (partly reverses decision 21);
`PortalSyncRequest` → round trip with an empty timestamp on timeout.

---

## 5. The plan, finding by finding

File paths are relative to `sourcecode/gateway/`. Tests go in `tests/QrBridge.Tests` (existing files first).

### G-01 — Acknowledgement before delivery (Critical) · Phase 4 · D1, D2, D8, D11 answered

**Change.** Hold-and-return for state-changing routes, as designed in section 4:

1. `routes.json` (step 7): a per-operation mode `Bridge` (today, "queued"), `RoundTrip`, `Unavailable`; inside
   `GetFromFMS` and `ProcessMessage` per message `TYPE`. Permits, orders, cards and responses → `RoundTrip`, with
   `OnHoldTimeout` = `Pending` (1596). ✅ The settings exist since step 7; the permit/order/card routes are switched
   ✅ **in step 10c (D60, D61)**, when the hold works (D33).
2. `SenderEndpoint` (step 10, ✅ built in step 10a): for `RoundTrip`, register a waiter, commit the Outbox row, check for a stored answer,
   then **hold** up to `Gateway:Hold` (Corp 270 s, DMZ 90 s, D11). A Reply wakes the waiter; a database poll is the
   fallback.
   - The Reply arrives: the caller gets the **real** answer from the far side, byte for byte.
   - The hold runs out: the caller gets **`1596`** "sent over the QR bridge, confirmation not yet received" (D8), so
     the monitor counts the attempt and keeps its event.
3. The monitor's retry is a new call with a new `RRMsgID`. The content fingerprint (section 4.4, G-03) attaches it to
   the first message: it gets the stored answer if one has arrived, otherwise it is held again. **No second Outbox
   row.**
4. **Late delivery after the verbal fallback.** `ExpiresUtc` in the header (about 10 min for the FMS monitors, set
   per route). The far Receiver part does not deliver an expired Request (`ServiceStatus = Expired`), and its Reply
   says so. This stops a permit arriving electronically after the dispatcher has issued it verbally. ✅ **Step 10c
   (D62):** `Gateway:Expiry` 600 s on both sides.

**Interim (D2, answered):** permit/order routes may be used in real islanding before the round trip is built; Rowshan
accepts the risk. `IssueWorkPermit` stays pilot-only until the FMS team explains `IntMgr.CardCutOut` (D12). The gap
detection and alarms (G-02, G-16) make a loss visible to the receiving side's operator. **Since step 10c** the
interim is over in the gateway: permits are held and get 1596 instead of a false 0; `IssueWorkPermit` is RoundTrip too
(D61, Rowshan), while D12 stays open.

**Done when:** end-to-end tests with two in-memory gateways and a fake light (step 13) cover each case. Reply in time
→ the caller gets the real code. No Reply → `1596`. A retry with the same content → no second Outbox row and the
stored answer. An expired Request is not delivered. ✅ **Step 13 (24 Nov 2026):** `LightFaultTests` and
`CallerFaultTests` on a shared `TwoGatewayBench` with a `FakeLight` running in both directions cover each case
(happy path, lost request / reply / receipt → re-air, duplicate session, retry after `1596`, late reply, hang-up,
expiry, `Unknown`, identical calls at once, restart during a hold); proven in memory only.

### G-02 — Silent loss on the one-way link (Critical) · Phase 1 (detect) + Phase 4 (repair)

**Detect (step 6; D27–D30):** ✅ **Done 24 Nov 2026 (tracker step 6).**

- `InboxRepository.FindSequenceGapsAsync(direction, arrivedBeforeUtc)`: missing `Sequence` numbers below the highest
  one received, per run of the sender's counter (including a run's first numbers), reported once the message after
  the gap arrived more than `Gateway:GapGraceMinutes` ago (default 5, because bundles may arrive out of order).
- `SequenceGapMonitor` (run by `MaintenanceWorker` once a minute) logs a warning for each new gap (sequence numbers
  and run id only, never payloads). `/health` shows `missingMessages` and `gaps`, counts them as light problems and
  turns unhealthy above zero.
- A sender restart with an empty database starts again at 1: each run of the counter has its own id
  (`SequenceCounter.RunId`, carried in the header and both tables as **`SequenceRunId`**, the name chosen by Rowshan,
  D27), so a restart is not reported as a gap.
- A gap stays until the message arrives, a new run starts, or an operator acknowledges it with
  `InboxRepository.AcknowledgeGapAsync`, kept in the audit table `AcknowledgedGap` (D29, D30).
- Rows are no longer deleted automatically (D28), so gaps are found from the rows themselves.

**Repair (steps 5, 11; D1, D9):** Receipts on the opposite lane. Each `MessageId` stored in the far Inbox is
confirmed; the Outbox row's `LightStatus` goes `Aired` → `Received`. Rows still `Aired` after
`Gateway:ReceiptTimeoutSeconds` go back to `Pending` and are aired again, a bounded number of times; then `Failed`
with the reason in `LightComment` and an operator alarm. Never re-aired after `ExpiresUtc`. Re-airing is safe because
the Inbox ignores a `MessageId` it already has.

**Done when:** a test skips sequence numbers in the Inbox and sees the gap reported (✅ step 6). A test starts a new
counter run and sees no gap reported (✅ step 6). A test loses a Receipt and sees the row re-aired once, then
`Received`; a row past its tries is `Failed` with a `LightComment` (✅ step 11).

✅ **Repair built 24 Nov 2026 (tracker step 11, D65–D68):** `OutboxRepository.ReairUnconfirmedAsync`, run by
`MaintenanceWorker` once a minute. A row `Aired` at least `Gateway:ReceiptTimeoutSeconds` (120) ago with no Receipt
goes back to `Pending`; after `Gateway:MaxAirAttempts` (3) airs in total, or once past its `ExpiresUtc`, it becomes
`Failed` with the reason in `LightComment`, a `Light:` warning and `/health` unhealthy. Receipt rows are never aired
again and no longer count as unconfirmed. A caller's retry of a `Failed` message keeps the D55 answer (D68). **Not
built:** anything that sets `Aired` (the QR Sender, Integration-Plan §2.4), so on real hardware nothing is re-aired yet.

### G-03 — Duplicates at Rapid Restore (High) · Phase 3 · D5, D9 answered

The four layers are in the tracker (§4.2). The plan:

- **Caller retries (step 8):** the content fingerprint of section 4.4, a `ContentFingerprint` column with an index
  on the Outbox (no new table). Left-out fields per route in `routes.json` (`MSG_ID`, `GMT_TIME_SENT`, `RRMsgID` by
  default). **Never dedupe on `MSG_ID` or `RRMsgID` alone**: they are static or new on every retry (project rule).
  Read with `SafeXml` from a read-only copy; never change the body.
- **Re-aired QR sessions:** already safe (`MessageId` is the Inbox primary key).
- **A second delivery attempt (step 9):** before a POST, look for a Reply for this `CorrelationId` in the far
  Outbox, and for the same fingerprint already `Done` in the window. Either one → no POST.
- **Outcome unknown (step 9, D9):** re-post only when the call surely did not arrive (section 4.3). A timeout after
  sending, a reset, HTTP 500/502/503/504 or a row found `Delivering` after a restart → `Unknown` + operator alarm, no
  re-post. Today's `ResetStuckAsync` re-POST of stuck rows and the retry of every transient failure go away.
- Before the fingerprint is trusted on permit/order routes it must be checked against **captured real retries**
  (tracker §3.2 gate).

**Done when:** tests show two calls with the same content and different `RRMsgID`/`MSG_ID` → one Outbox row; two
identical calls at the same moment → one row; different content → two rows; the same content after the window →
two rows; a 502 or a timeout after sending → `Unknown`, no second POST; a refused connection → re-posted.
✅ The first four done 24 Nov 2026 (tracker step 8, `RetryTests`, on a route with `RecogniseRetries` on); the last
two done 24 Nov 2026 (tracker step 9a, `DeliveryOutcomeTests`: 502, a timeout after sending — also on a real socket —
→ `Unknown`, one POST; a refused connection — also a real one — → posted again). `ResetStuckAsync` now marks stuck
rows `Unknown`, and only "nothing sent" failures are retried.

### G-04 — QrDiode weaknesses (High) · Phase 2 (planned) + Phase 5

- Phase 2 = Integration-Plan steps 1–4, already planned: §2.1 stuck receiver (known issue 1), §2.4 no dropped
  queue items (known issue 2), §2.5 anti-replay committed **after** the Inbox transaction (known issue 3, review
  Q-07).
- Phase 5 (QrDiode hardening, its own plan against review V5.0 Parts C/D): authenticate every frame before it can
  change receiver state (Q-02, Q-03, Q-10); provision keys and the trust store properly (S-04, S-07, S-13); add the
  low-S signature check (N-05); fix counter exhaustion and rollback (N-06/Q-08); decide on V2 or V3 as the base
  (review Q5, recommended V3).

### G-05 — Plaintext at rest (High) · Phase 3 · D3 answered (a)

With D3 (a):

- **Code:** after `InboxWorker` marks a row `Done`, clear its body (keep the header, `MessageHash` and
  `DownstreamResult` for reconciliation). Keep the body for `Failed`/`DeadLetter`, because an operator requeue needs
  it. In the Outbox, clear `MessageBytes` once a row is confirmed (Phase 4).
- **Ops (guide §12.4):** BitLocker on the data disk; NTFS ACL on `C:\ProgramData\QrBridge\Data`, only for the app
  pool identity, the kiosk user and Administrators. Since D28 rows are never deleted automatically: archive them
  manually, as the operators and auditors require (never rows younger than `ReplayWindowDays`).
- With D3 (b), encrypt `MessageBytes` with DPAPI (machine scope) in `OutboxWriter` and the QrDiode Receiver, and
  decrypt it in `InboxWorker`. This is a format change: delete the dev databases or add a migration.

**Done when:** a test shows a delivered Inbox row with no body and its hash kept; a dead-lettered row still has its
body and can be requeued. ✅ **Code done 25 Nov 2026 (step 15, D77):** every Inbox row ends `Done` without its body
(Requests and the used Replies/Receipts); Refused/Unknown/NotDelivered/Expired keep it. Outbox bodies are not cleared.
BitLocker and ACLs are operations (step 18).

### G-06 — The gateway as a trusted component (High) · Phase 5 · D4 answered (a)

With D4 (a), recommended: a dedicated app pool identity per side, with only the data-folder ACL and the network
access it needs; IIS request limits (`maxAllowedContentLength` equal to `MaxPayloadBytes`) and IP restrictions in
front of the gateway; patching follows review V5.0. Write it in the guide §12.4. The only code is a start-up warning
if the process runs as an administrator.

✅ **Done 25 Nov 2026 (tracker step 18, D4 = a):** `StartupChecks.AdministratorWarning` logs a warning (never a
refusal) when the process is elevated (test `SenderTests.A_gateway_running_as_an_administrator_is_warned_about_but_still_starts`).
Guide §12.4 now has the app pool identity, the data-folder ACL (`icacls` example), BitLocker, IIS
`maxAllowedContentLength` (about 2 × `MaxPayloadBytes`, so a body just over the limit still gets the gateway's own
SOAP 413 fault; not set in the shipped `web.config`), IP restrictions for later (D6), the Registered Tags GET through
IIS, NTP, and a fixed recycle time. None of it tried on a real server.

### G-07 — One identity for every caller (High) · Phase 3 · ❓ D6

- `ReceiverTarget`: per-target `UseDefaultCredentials` / `CredentialName`, so each route can use its own Windows
  Credential Manager entry. Never a password in `appsettings`. The global setting stays as the default.
- `MessageHeader`: add `CallerHost` (the client address the load balancer forwards, or `RemoteIpAddress`). Log it
  at egress next to the service and operation. It is not sensitive (rule: never log payloads). This is a header
  format change: bump `MessageHeader.CurrentVersion`.
- Do D6 (a) in IIS on the DMZ gateway. Rotate the registry credentials if the gateway ever sees them.

**Done when:** a test checks that two targets with different credential settings get the right `HttpClient` handler;
`CallerHost` survives a serializer round trip. ✅ The second half done 24 Nov 2026 (tracker step 4,
`A_reply_header_round_trips_every_field`; `CallerHost` ≤ 256 characters, no control characters). Filling and logging
it is step 15. ✅ **Done 25 Nov 2026 (step 15, D75, D76):** per-target `UseDefaultCredentials` (no Credential Manager
accounts); `CallerHost` = the first `X-Forwarded-For` address `(via <connection>)`, logged at delivery. D6: the DMZ
gateway accepts anonymous intranet calls (Rowshan).

### G-08 — Calls that return data (High) · Phase 1 (config) + Phase 4 · D13–D19 answered

- **Round trip (steps 7, 9, 10, 12):** every query, push and command listed in section 4.6 and in
  [uncovered-services.md](../reference/uncovered-services.md) gets the round trip: the real answer if it
  comes back within the hold, otherwise the route's hold-timeout answer (section 4.5). The polls `DISPLAY_POLL` and
  `BUS_FAULT_OUTAGE_REQUEST` stay `Unavailable` (D15). Rows 12, 13 and 15 only matter if XA/21 and BFC cross the
  gap (D23, open). ✅ **Configured 24 Nov 2026 (tracker step 7)** in `routes.json`; ✅ **held for the real answer
  since step 10a**; rows 12, 13, 15 set to `Unavailable` until D23 is answered (D52). Test
  `RouteTableTests.Shipped_catalogue_sends_the_decided_calls_on_a_round_trip` (one case per decided row).
- **`PortalSyncRequest` (D19):** a new reply profile `PortalSyncDown` that returns an **empty**
  `GMT_TIME_STAMP`, used when the hold runs out, so the portal monitor exits cleanly ("Network Communication may be
  down") and tries again next cycle (review §3). Before writing it, check the exact reply shape in
  `Contracts/Outbound/FMS2FC` and the simulator. Add a test. ✅ **Done 24 Nov 2026 (tracker step 7, D34):**
  `RETURN_CODE 1599` + empty `<PORTAL_SYNC_RESPONSE><GMT_TIME_STAMP>`, given at once until the hold exists. The WSDL
  only says `PortalSyncRequestResult` is a string, and the simulator has no sample: the shape follows the path the
  caller reads (review §3), not a captured real answer. Test `DmzSenderTests` case "FCR PortalSyncRequest".
- **FTC `GetFaultCorrelation` (D13):** round trip. Until it is built, today's SOAP fault → caller `-1` → the FSS
  monitor deletes the event and refreshes later, which matches review §5 ("fail fast"). Add a test that pins this
  behaviour down.
- **`GetFromFMS` (D13, D14, D17):** per message `TYPE`: queries → round trip; `WITHDRAW_RFP` and unknown types →
  round trip with the state-changing rules (fingerprint, `1596`; D35 for the unknown types of FC2FMS / FTC2FMS). Who
  calls it in real life is still unknown (review Q7).
- **Registered Tags (D18):** one configured GET path as a round trip (step 12). This **partly reverses decision 21**
  ("only `GET /health` answers") for this one path. ✅ **Built 24 Nov 2026 (step 12, D69–D72):** `routes.json` service
  `RegisteredTags` with `"HttpGet": true` (Corp callers), payload format `HttpGet`, replayed as a GET on the DMZ side;
  the real answer byte for byte, else HTTP 504; a query string → 400; every other GET still 405.

### G-09 — `http://` and names (Medium) · Phase 1 (check) + Phase 5 (certificates)

- `StartupChecks`: refuse to start if a Receiver URL is `http://` outside the Development environment (setting
  `Gateway:Receiver:AllowHttp` for test benches). Replace the `http://dmz-rr-server` placeholder with an `https://`
  placeholder. ✅ Done 24 Nov 2026 (tracker step 3); a URL that is not absolute http(s) is refused too. Tests
  `A_receiver_url_without_https_stops_the_gateway_from_starting`, `Https_receiver_urls_or_an_explicit_opt_in_let_the_gateway_start`.
- Phase 5, ops (review Q9): the gateway's own name and certificate from an internal CA limited to those names; the
  registry `*ServiceUrl` points to that name (review §7). The gateway never presents `comp.coned.com`.

### G-10 — Size limits (Medium) · Phase 1 (measure)

- Measure: count and sizes per operation from the gateway logs (they already log `{Bytes}`) on a test run with the
  simulator. Ask the FMS team for production peaks (review Q4).
- Then set `MaxPayloadBytes` per route if needed (new optional `MaxRequestBytes` in `routes.json`; the global
  setting stays the upper limit). Add a start-up warning when the air time for the limit (review §6 formula) is
  longer than the hold deadline of a `RoundTrip` route.
- ✅ **Done 25 Nov 2026 (step 16, D78, D79):** the simulator templates measured per route (largest 12,095 bytes, SSO2FMS
  `RETURN_ORDER`); `MaxRequestBytes` = 10 × the largest template on the 11 routes that have one; optional per-route
  `MaxBacklog`; `Gateway:Light` and the start-up air-time warning. Real production sizes (Q4) are still unknown.

### G-11 — SOAP assumptions (Medium) · Phase 1

The gateway stays generic (settled decision 2). Close the one real gap:

- `ServiceContract` / `ContractCatalog.Check`: if the WSDL gives a `soapAction` for the operation and the request
  has a `SOAPAction` header (SOAP 1.1) or an `action` parameter in `Content-Type` (SOAP 1.2), they must match
  (ignoring quotes). Otherwise: a SOAP fault, and the request is not queued. An empty WSDL `soapAction` is not
  checked.

**Done when:** tests cover the right action → queued; wrong action → fault; no header on a route whose WSDL has an
empty action → queued.

✅ **Done 24 Nov 2026 (tracker step 3).** Case-sensitive, quotes ignored, per SOAP version (each binding's own
`soapAction`). No WSDL in `Contracts/` has an empty `soapAction`, so the "not checked" case is proven with a request
that sends **no** action instead. Tests `ServiceContractTests` (SOAP 1.1 header and SOAP 1.2 Content-Type `action`
against the real XA2FMS contract), `A_request_that_does_not_match_the_wsdl_is_refused_and_not_queued("wrong soapaction")`,
`A_request_without_a_soapaction_header_is_still_bridged`; every simulator template and the real WCF client tests
still pass with their actions.

### G-12 — Head-of-line blocking (Medium) · Phase 3

- `routes.json`: per-service `Priority` (`High` for permits/orders, `Normal`, `Low` for refreshes such as FSS,
  Dashboard, SSLog).
- `InboxWorker`: run one delivery loop per priority class (setting `Gateway:DeliveryWorkers`, default 3). Each loop
  claims only its own class. Within a service, delivery stays one at a time and in order. This includes the
  `OrderingKey` idea in Integration-Plan §4: never overtake a row of the same key that is waiting for a retry.
- `InboxRepository.ClaimNextAsync(priority)` gets the filter. The claim is already optimistic and safe for several
  workers.

**Done when:** a test makes a slow `Low` service (fake service delay) and shows that a `High` message is delivered
first; two messages of the same service still arrive in order. ✅ **Done 25 Nov 2026 (step 14, D73, D74):** header v6
`Priority` (Answer / High / Normal / Low; default from the mode, optional per route); the QR sender airs answers first;
one delivery loop per class (always three, no `Gateway:DeliveryWorkers` setting); strict order per service and class
against `Retrying` rows. The per-order `OrderingKey` (Integration-Plan §4) is not built.

### G-13 — Backlog and clocks (Medium) · Phase 1

- `OutboxWriter.EnqueueAsync`: count the backlog **inside** the insert transaction (same connection, before
  `NextSequenceAsync`). SQLite allows one writer at a time, so the count and the insert can no longer race.
- An optional per-route `MaxBacklog` in `routes.json`; the global one stays.
- `StartupChecks`: refuse to start if `RetentionDays < ReplayWindowDays`, or if `MaxClockSkewMinutes` or
  `ReplayWindowDays` are 0 or negative. *(Step 6, D28: `RetentionDays` and its check were removed again: rows are
  never deleted automatically, so a replayed message is always caught by its `MessageId`.)*
- Clocks (review invariant 7): with G-02's counter run (`SequenceRunId`) and sequence, an old message is recognised by its sequence number
  being lower than the newest one already `Done`, not only by its date. Keep the date window as a second check.
  Write the NTP requirement in the guide.

**Done when:** a test runs many concurrent calls with `MaxBacklog = N` and gets exactly N rows; a test shows start-up
refusing an inconsistent configuration.

✅ **First and third bullets done 24 Nov 2026 (tracker step 2).** Tests
`Concurrent_calls_never_queue_more_than_the_backlog_limit` (30 calls at once, limit 3: before the fix 20 were
queued) and `Inconsistent_replay_settings_stop_the_gateway_from_starting`. Per-route `MaxBacklog` → ✅ step 16;
sequence-based replay check and the NTP note → ✅ **step 17 (25 Nov 2026, D84)**, changed from the bullet above: since
step 14 answers jump the queue and step 11 re-airs, so "lower than the newest Done" would refuse real messages.
Instead, on a row's first check: a number already held by another message of the same run that arrived first →
Rejected; a number at or below the run's watermark (`SequenceWatermark`: every number up to it arrived and was checked)
whose row is gone (archived) → Rejected, whatever its date. The date window stays. Tests
`EndToEndTests.A_message_reusing_a_number_another_message_already_has_is_rejected_not_posted`,
`An_old_message_replayed_after_its_row_was_archived_is_rejected_although_its_date_is_recent` (both delivered the
message on the old code), `Messages_that_arrive_out_of_order_or_are_retried_are_still_delivered`. NTP: guide §7.3 and
§12.4.

### G-14 — Shared files and named events (Medium) · Phase 1 + Phase 2

- Phase 1: `SqlitePragmaInterceptor` → `synchronous = FULL` (the message rate is low; durability matters more).
  Update its comment. ✅ Done 24 Nov 2026 (tracker step 2), test `Every_connection_is_on_disk_before_a_commit_returns`.
- Phase 2: EF migrations, already planned (Integration-Plan §2.2, with the baseline step for `EnsureCreated`
  databases).
- Doorbell ACL: leave as is and write down why. A wrong signal only wakes a poll early; it carries no data
  (`BridgeSignal` comment). Narrow it only if the security review asks. ✅ Written in the guide §6.5 (step 18).
- Ops: back up `send.db` (with its `SequenceCounter` and run id) with the data folder. A restored backup **keeps** its
  run (`SequenceRunId`), so restore only a `send.db` whose numbers the far side has not already passed; otherwise
  delete it so a new run starts (G-02, step 6). ✅ Guide §12.4 (step 18): back up both databases together; since step 17
  a reused number is Rejected on the far side, so a wrongly restored `send.db` now loses its queued messages instead of
  hiding gaps.

### G-15 — Route table driven by content (Medium) · Phase 1 · D7 answered (a)

With D7 (a):

- `RouteTable`: compute a SHA-256 fingerprint of the loaded catalogue (normalised JSON) and log it at start-up.
- `MessageHeader`: add `CatalogFingerprint` (header format change; same version bump as G-07, done once).
- `InboxWorker.Validate`: a different fingerprint → `Rejected` with "route catalogue differs from the sender's".
  `/health` shows the local fingerprint so operators can compare both sides.

**Done when:** a test sends a message with another fingerprint and gets `Rejected`; the same fingerprint → delivered.

✅ **Done 24 Nov 2026 (tracker step 6, D31):** the fingerprint covers the services and reply profiles (not the local
test switches); a different or missing one → `Rejected`; `/health` shows `catalogFingerprint`. Tests
`A_message_from_a_gateway_with_another_route_catalogue_is_rejected_not_posted` (on the old code it was delivered),
`Every_message_carries_the_sender_catalogue_and_counter_run`; the same fingerprint → every existing end-to-end test.

### G-16 — Failure nobody sees (Medium) · Phase 1 (local) + Phase 4 (across)

- Phase 1: `/health` adds the G-02 gaps, `DeadLetter`/`Rejected` counts and the oldest undelivered age. Most of this
  is the `/status` endpoint in Integration-Plan §3.3; build it there once. ✅ **Done 24 Nov 2026 (steps 5a, 6):**
  `lightProblems` (Outbox `Failed` + missing messages), `serviceProblems` (Inbox `Unknown`/`Refused`/`NotDelivered`),
  `missingMessages`, `gaps`, `outbox`/`inbox` counts with `oldestUndeliveredUtc`, `catalogFingerprint`.
- Phase 4: a heartbeat in every receipt and an empty heartbeat session every N minutes, so each side shows "far side
  last seen". The dispatcher-facing alarm (review REQ-22, Q12) is an ops decision. ✅ **Done 25 Nov 2026 (tracker
  step 17, D80–D83):** every arrival counts as "heard" (Receipts, Replies, Requests); an idle side sends an empty
  `Heartbeat` message (header v7, `BRG7`) every `Gateway:HeartbeatMinutes` (5), with a sequence number (a lost last
  message becomes a gap), no Receipt and no re-air; `/health` `farSide` (`lastHeardUtc`, `lastReceiptUtc`, `silent`)
  and `healthy = false` + a `Light:` warning after `Gateway:FarSideSilentMinutes` (15). Tests `HeartbeatTests` (3).
  The dispatcher-facing alarm is still open.

### G-17 — An unrecognised 2xx counts as Done (Low) · Phase 1

- `SoapForwarderHttpClient.Classify`, `default:` branch (the result kind is `FmsResponse` or `ReturnCode` but the
  reply cannot be read) → `DeliveryVerdict.Permanent`, `DeadLetter`, with the summary "HTTP {status}, reply not
  recognised — may have been processed; check before requeue". **Not `Failed`:** a retry could duplicate a message
  that the service did process (decision 13). `ResultKind.None` (void operations such as `FMS2VR`) stays
  `Delivered`.

**Done when:** a `Classify` test with 200 and an HTML body for `FmsResponse` → `Permanent`; for `None` → `Delivered`.
Step 5 later stores this outcome as `ServiceStatus = Unknown` with an operator alarm (section 4.3).

✅ **Done 24 Nov 2026 (tracker step 2):** `Classify` → `Permanent`, "reply not recognised — may have been processed;
check before requeue". Tests `A_2xx_reply_that_cannot_be_read_is_dead_lettered_not_done` (no `RETURN_CODE`, HTML,
empty body, non-numeric return code), `A_2xx_reply_too_large_to_read_is_dead_lettered_not_done`,
`Accepted_and_one_way_replies_are_delivered`.

---

## 6. Order of work

The tracker's step list ([§3](gateway-review-v6-fix-tracker.md#3-steps)) is the order actually followed, one step
per session. The phases below are the original grouping.

| Phase | What | Needs | Done when |
|---|---|---|---|
| **0** | Answer D1–D7 (section 3) | Rowshan, Rapid Restore team, security | ✅ Answered 24 Nov (D1–D3, D5, D7–D19, D24); D6 and D4 answered 25 Nov; D20–D23 open. Written in HANDOFF §3 (decisions 26–31) |
| **1** | Safe fixes, no decision needed: G-17, G-13, G-14 (`FULL`), G-11, G-09 check, G-02 detect, G-16 local, G-08 config + test, G-10 measure. G-15 when D7 is answered (cheap; join it to the G-07 header bump if both come together) | — | Each item's test passes; `dotnet test All.slnx` green |
| **2** | Integration-Plan §5 steps 1–4 (receiver fix, data model + migrations + bundles, Sender ↔ Outbox, Receiver ↔ Inbox) | — | As in Integration-Plan §5 |
| **3** | G-03 content fingerprint + re-post rules, G-12 priorities, G-07 credentials + `CallerHost`, G-05 per D3 | D3, D5, D9 (answered), D6 (open) | Tests in section 5 pass; end-to-end test still green |
| **4** | Round trip over the opposite lane (section 4): receipts, G-01 hold-and-return + expiry, G-02 repair, G-16 across, G-08 round trips | D1 (answered) + security sign-off | Fault-injection tests: lost session, reorder, late receipt, expired message, receiver restart |
| **5** | Hardening: G-04 QrDiode items, G-06 accounts/IIS limits, G-09 certificates; then Integration-Plan §5 step 7 (load, soak, failure tests) | D4, certificates | Rollout one route at a time: FTC/portal → FSS/Dashboard/SSLog → orders → permits (review §10) |

Phase 1 can start now. It changes no caller-visible behaviour except G-11 (a wrong `SOAPAction` is refused).
Callers see the round trip's changes (real answers, `1596`, the empty portal timestamp) only from phase 4.

---

## 7. After each phase

1. `dotnet test All.slnx` (all tests green; note the new count).
2. Update [../../../docs/handoff.md](../../../../docs/handoff.md) (state, decisions log, known issues), the
   known-issues list in `.github/copilot-instructions.md`, and
   [gateway-qrdiode-workflow.md](../workflows/gateway-qrdiode-workflow.md) §7 (remove a weak point once it is fixed).
3. Mark the finding here as done (✅, with the date and test names), and in
   [../../../docs/gateway-to-qrdiode/integration-plan.md](../../../../docs/gateway-to-qrdiode/integration-plan.md) where the step is shared.
4. Header format changes (G-02 counter run, G-07, G-15): bump `MessageHeader.CurrentVersion` once per phase and delete the
   dev databases, or add a migration once migrations exist (known issue 6).
