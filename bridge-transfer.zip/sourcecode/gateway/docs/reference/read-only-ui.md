# Read-only web UI (gateway folder `Ui/`)

**Built 25 Nov 2026 (handoff decision 48).** A read-only web view of the Outbox and Inbox of one gateway's
`qrbridge.db`, served by the gateway itself under `/qrbridge-ui`, behind one login. It shows each message in plain
words: the service URL, the SOAP request, the FMS message inside it, the real service's answer, and both status
groups. Nobody can change, resend or delete anything from it.

It is part of the gateway project (`sourcecode/gateway/src/QrBridge.Gateway/Ui/`): one project, one `dotnet publish`,
one IIS site. Tested with in-memory gateways (68 tests, one of them a whole busy day on both sides), and the published
folder was run once on one PC.
**Not tried on a real IIS server.**

## 1. What you see

| Page | URL | Shows |
|---|---|---|
| Sign in | `/qrbridge-ui/login` | Only the sign-in panel, centred (no top bar or footer): "QrGateway", "Read-only view · Corp side", username and password (`Ui:Username` / `Ui:Password`, admin / admin by default) |
| Overview | `/qrbridge-ui` | What `GET /health` says, in words: healthy or not and why (missing messages included), QrData and service counts per status (each count opens the filtered list), far side last heard, callers held now, the 8 newest Requests sent and arrived, component heartbeats |
| Outbox | `/qrbridge-ui/outbox` | What this side sends: callers' Requests, this side's Receipts, Replies and Heartbeats. Filters: kind (Requests by default), QrData status, service status, service, search (a message or correlation id — whole, or its first characters such as the 8 the list shows —, or text in service / operation / business type) |
| Inbox | `/qrbridge-ui/inbox` | What arrived from the far side, with the same filters |
| One message | `/qrbridge-ui/outbox/{id}`, `/qrbridge-ui/inbox/{id}` | The whole round trip, top to bottom: the message id and correlation id; the QrData and Service status; the call (request line, SOAPAction, Content-Type); the request (FMS message, SOAP envelope, bytes as stored); the **response** of the real service (SOAP envelope and the message in its result, both open); then **one section per other message of the round trip** (below); then every field of this message and, last, the **Related messages** table (both in the DETAILS band) |

**Paging** happens in the database: the filter and the search run in SQL, then only the page's rows are read. The
footer under the list is always shown: rows shown ("Showing 1–50 of 312"), rows per page (10, 25, 50, 100, 200;
`Ui:PageSize` is the default), first / previous / page number / next / last. The list fills the window: the table
scrolls under its sticky header, the footer stays in view.

**Every text box says what it is** in one plain line under its title (visible even when the box is closed). For a
SOAP call, the request (and the response) is shown three ways:

| Box | What it is |
|---|---|
| "the message in sXML" (or the parameter's name) | the message itself, the part a person reads: taken out of the envelope and indented |
| "SOAP envelope, indented" | the same message in the wrapper it travels in, which names the function and its parameter. The message is text inside the parameter, so its `<` and `>` are written `&lt;` and `&gt;`: that is why it looks messy |
| "exactly as stored (N bytes)" | the exact bytes, untouched: only for comparing with logs or an audit |

**Receipt and Reply, in business words.** For every Request two things come back, and the pages name both:

| Kind | In business words | It says |
|---|---|---|
| **Receipt** | it arrived safely | "it reached the other side and is saved there" (so the sender stops sending it). Nothing about what the service did |
| **Reply** | what the real service did | the real service's answer (accepted, refused…), or why the request was never sent to it (it arrived too late, the service could not be reached) |

Like a registered letter: the Receipt is the signed delivery slip, the Reply is the answer letter. Hovering a kind chip
(Request, Receipt, Reply, Heartbeat) shows its meaning (`Display.Meaning`).

**Bands.** A detail page reads in three bands, each opened by a coloured strip (theme colours, both themes):
**REQUEST** (blue, "what was asked": the call, the request boxes, and the Request a Reply or Receipt answers),
**RESPONSE** (purple, "what came back": the real service's response, the Reply and the Receipt, and notes such as
"nothing has come back yet"), **DETAILS** (grey: every field, then the Related messages table). Clicking a strip folds its
band away and clicking again opens it (a `<details>` element: no script); all bands start open. The Reply / Receipt card is
the partial `Ui/Pages/Shared/_RoundTripPart.cshtml`; response-side notes are `MessageDetail.ResponseNotes`.

**The round trip on one page.** A detail page shows the other messages of its round trip, each in its own section
with a title, one plain line saying what it means, its id (a link), its two statuses and its times, before the Related
messages table:

| Page | Its sections |
|---|---|
| A Request this side sent (Outbox) | "Reply from the DMZ side: what the real service did" (outcome, HTTP status, reason; its response is the one shown above) and "Receipt from the DMZ side: it arrived safely", read from this side's Inbox. Nothing back yet: a note says so |
| A Request that arrived (Inbox) | "Reply sent back by this side: what the real service did" and "Receipt sent back by this side: it arrived safely", read from this side's Outbox |
| A Reply | "The Request it answers" (from the other table of the same gateway), then the Receipt for this Reply |
| A Receipt | "The Request it confirms" or "The Reply it confirms" (a Receipt confirms either) |

The titles and lines come from `MessageQueries.AnswerText` / `AnsweredTitle` / `AnsweredText`.

The other gateway's rows are in the other gateway's database: its UI shows them.

**QrData** is the UI's word for the first status group (the `LightStatus` / `LightComment` columns, called "light
status" in the design documents): has the message crossed the air gap as QR codes? The filters still use `light=` in
the URL.

**Correlation id:** the id of a round trip. For a Request it is its own message id: its Receipts and its Reply carry it
as their `CorrelationId`, and the far gateway stores the Request under the same message id. So search for one id on
both gateways' Outbox and Inbox to see the whole round trip. A Heartbeat answers nothing and has none.

**Times** are exact, in US format on a 12-hour clock, in US Eastern time (`11/25/2026 05:05:39 PM EST`, EDT in summer;
`Ui:TimeZone`; the format is `Display.UsDateTime`); the tooltip gives
UTC and "3 minutes ago". The database keeps UTC (section 7).

Each list row shows its message id, its correlation id, its time, its **service URL** and one line of **content**:

| Table | Service URL | Content |
|---|---|---|
| Outbox Request | `POST /FMS_…/X.svc`: the path the caller called on this gateway (the far side posts it to its own `Gateway:Receiver` target + this path; this side cannot know that host) | the FMS `<MESSAGE …>` from `sXML` / `XMLMsg`, unescaped |
| Outbox Reply | the URL this side posted the Request it answers to | the outcome, HTTP status and the real answer |
| Inbox Request | `POST https://dmz-rr-server/FMS_…/X.svc`: the URL this gateway posts it to (`Gateway:Receiver:Targets[service].Url`, else `DefaultBaseUrl` + path) | the FMS message |
| Inbox Request, delivered (Done) | the same URL, the path from `routes.json` | "Body cleared after delivery (decision D77)" + what the service answered. The request itself is still in the sending side's Outbox, and the detail page shows the answer from this side's Reply |
| Receipts, Heartbeats | — | what they confirm |

Interactive parts, all without any framework: light / dark theme (follows Windows; the moon/sun button switches and
remembers it in the browser), clickable rows, filters and page size that apply on change, copy and wrap buttons on
every text block, XML colouring, and an auto-refresh toggle (off by default, every `Ui:RefreshSeconds`).

Not shown on purpose: the priority class and the sequence number (internal: the order messages take on the light, and
how a lost one is found), the caller's address, the route catalogue fingerprint. They are still in the database and
in `GET /health`.

## 2. Run it

**On one PC:**

```powershell
dotnet run --project sourcecode\gateway\src\QrBridge.Gateway --launch-profile "Gateway (Corp)"
# open http://localhost:5080/qrbridge-ui and sign in with admin / admin
```

In **Visual Studio** (`sourcecode\gateway\QrGateway.slnx`): make `QrBridge.Gateway` the startup project, pick
`Gateway (Corp)` or `Gateway (Dmz)` in the run button's list and press F5; the browser opens at `/qrbridge-ui`
(`launchUrl` in `Properties/launchSettings.json`). Visual Studio runs one profile at a time: for both sides at once,
start the second one from a terminal with `dotnet run … --launch-profile "Gateway (Dmz)"`.

**Sample data** (to see every page, both themes and every status): fill both dev databases with a busy islanding
day, then start both gateways. Stop any running gateway first. An existing `qrbridge.db` there is moved to a
`previous-…` folder beside it, never deleted.

```powershell
$env:QRBRIDGE_DEMO_ROOT = "C:\QrBridgeDev"
dotnet test sourcecode\gateway\tests\QrBridge.Tests --filter "FullyQualifiedName~UiDemoDataTests"
Remove-Item Env:QRBRIDGE_DEMO_ROOT
dotnet run --project sourcecode\gateway\src\QrBridge.Gateway --launch-profile "Gateway (Corp)"   # http://localhost:5080/qrbridge-ui
dotnet run --project sourcecode\gateway\src\QrBridge.Gateway --launch-profile "Gateway (Dmz)"    # http://localhost:5090/qrbridge-ui (second terminal)
```

It takes about 20 seconds. Both gateways (the real Program, in memory) exchange real calls over the fake light, with
fake real services behind them (`tests/QrBridge.Tests/Ui/Infrastructure/DemoTraffic.cs`), so every row is written by
the gateways themselves:

| On the Corp UI (`:5080`) | On the DMZ UI (`:5090`) |
|---|---|
| Outbox: 14 Requests — permits, a withdrawal and a query **Answered** with the real answer; an order **Refused** (RETURN_CODE 1501); a call **Unknown** (HTTP 500); one **NotDelivered** (service unreachable); one **Expired**; one **Failed** on the light (aired 3 times, never confirmed); feeds; a legacy RPC call; the Registered Tags report | Inbox: the same 13 that arrived — **Done**, **Refused**, **Unknown**, **NotDelivered**, **Expired** — each with the URL it was posted to; number 6 is **missing** (the lost one: listed in the overview's banner); the Corp side's Receipts, Replies and Heartbeat (**Used**), and two **Rejected** answers (to the Corp side's Rejected arrival) |
| Inbox: the DMZ's cards, work permit, refused RFP link, portal sync and feeds, delivered here (**Done** / **Refused**); the DMZ's Receipts, Replies and a Heartbeat (**Used**); one **Rejected** arrival (a sender with another `routes.json`) | Outbox: the DMZ callers' Requests, and its Receipts, Replies and Heartbeat |

Both overviews say **Needs attention** at once, on purpose: the day holds a Failed message, Refused / Unknown /
NotDelivered rows and (on the DMZ) a missing number, and the banner lists each one. Once running, each gateway behaves
normally on this data; after 15 minutes each also reports the far side **silent** (nothing crosses without the QR
apps). Run the commands again for a fresh day.

Without the variable, the same test runs in a temporary folder and checks that every page of both UIs renders for
every message (part of `dotnet test All.slnx`).

**On IIS:** nothing extra to install or copy. The UI is part of the gateway project, so the usual publish of the
gateway (technical guide §12.3) is the whole deployment:

```powershell
dotnet publish sourcecode\gateway\src\QrBridge.Gateway -c Release -o publish\gateway
```

The pages, the stylesheet and the scripts are compiled into `QrBridge.Gateway.dll`: no `wwwroot`, no second site, no
second app pool. Copy `publish\gateway\` to the IIS site as before. Before go-live, per site:

1. Set your own `Ui:Username` and `Ui:Password` in `appsettings.{Side}.json` (a start with admin / admin logs a warning).
   Don't commit a real password.
2. Serve the site over **https**: the pages show permits and orders in clear (decision 23), and the password is sent
   on sign-in. The cookie is marked `Secure` automatically over https.
3. Restrict `/qrbridge-ui` with IIS "IP and Domain Restrictions" to the operators' machines. On Corp the gateway sits
   behind the corporate load balancer: make sure the load balancer does not forward `/qrbridge-ui` from callers.
4. Or turn it off with `Ui:Enabled = false`: its paths then get 405 like any other GET.

## 3. How it is built (for an Angular developer)

```
browser ──GET /qrbridge-ui/outbox──► IIS ► QrBridge.Gateway (one project, one process)
                                              ├─ SenderSoapController  POST/GET {**path}   (callers; unchanged)
                                              ├─ HealthController      GET /health          (unchanged)
                                              └─ Ui/ Razor Pages       /qrbridge-ui/**      (login cookie)
                                                   PageModel ─► MessageQueries ─► ReadOnlyBridgeDb ─► qrbridge.db (read-only)
                                                             └► UiGatewayInfo (routes, delivery URL, /health figures; reads only)
```

| Angular | Here (all under `sourcecode/gateway/src/QrBridge.Gateway/`) |
|---|---|
| Component template (`.html`) | `Ui/Pages/X.cshtml` (Razor: HTML with `@value` and `@if` / `@foreach`) |
| Component class (`.ts`) | `Ui/Pages/X.cshtml.cs`, the **PageModel**: `OnGetAsync` loads the data, public properties feed the template |
| `AppComponent` shell | `Ui/Pages/Shared/_Layout.cshtml` (top bar, navigation, theme button) |
| Child component | a **partial**: `Ui/Pages/Shared/_MessageTable.cshtml`, `_Code.cshtml`, `_Facts.cshtml`, `_Status.cshtml`, `_Refresh.cshtml` |
| Service injected into a component | `MessageQueries`, `UiGatewayInfo`, injected into the PageModel's constructor |
| Router (`routes`) | `@page "/qrbridge-ui/…"` at the top of each `.cshtml` |
| Route guard | the cookie login: `Initializer/UiRegistration.cs` makes every page need it, except `Login` and `Assets` |
| `{{ value }}` (escaped) | `@value` (HTML-encoded too). Never `Html.Raw` |
| `styles.css`, `main.js` | `Ui/Assets/ui.css`, `Ui/Assets/ui.js`, `Ui/Assets/theme.js` (embedded in the dll, served by `Ui/Pages/Assets`) |

The big difference: Razor Pages render HTML **on the server**. There is no JSON API and no separate build step:
`dotnet build` compiles the pages into the gateway's dll.

### Code map (in `sourcecode/gateway/src/QrBridge.Gateway/`)

| File | Job |
|---|---|
| `Initializer/UiRegistration.cs` | `AddGatewayUi` (services, login, pages in `Ui/Pages`) and `MapGatewayUi` (security headers, login middleware, pages; only when `Ui:Enabled`). `Program.cs` calls both |
| `Ui/UiGatewayInfo.cs` | the UI's one way to the rest of the gateway: routes, delivery URL, the `/health` figures (its repositories run on the read-only connection) |
| `Ui/Data/ReadOnlyBridgeDb.cs` | the UI's only connection to `qrbridge.db`, opened `Mode=ReadOnly` (SQLite refuses writes) |
| `Ui/Data/MessageQueries.cs` | lists, the detail page, service URL and preview per row; the records the pages use |
| `Ui/Reading/MessageReader.cs` | stored bytes → header + text + indented XML + the FMS message inside the first SOAP parameter (through `SafeXml`) |
| `Ui/Display.cs` | sizes, ids, status words and colours (`StatusView`) |
| `Ui/UiTime.cs` | every time on the pages, in `Ui:TimeZone` (Eastern: EST / EDT) |
| `Ui/Security/UiAuthentication.cs`, `Ui/Security/UiSecurityHeaders.cs` | the login check and the response headers |
| `Ui/Pages/…`, `Ui/Assets/…` | the pages (section 1), the stylesheet and scripts |
| `Configurations/Options/UiOptions.cs`, `Configurations/Enums/Enums.cs` (`MessageBox`, `Tone`), `Configurations/Helpers/Utility.cs` (`UiPaths`) | the UI's settings, enums and URLs, in the gateway's usual places |

## 4. Rules that keep it safe

The full list is in [read-only-ui.instructions.md](../../../../.github/instructions/read-only-ui.instructions.md). In short:

- **Read-only**: only `ReadOnlyBridgeDb`, `MessageQueries` and `UiGatewayInfo`; no POST that changes data. Because the
  UI shares the gateway project, a test (`UiReadOnlyTests.No_ui_class_depends_on_code_that_writes`) fails if any UI
  class or page takes a writer (`OutboxWriter`, a repository, the read-write connection factory…). Requeue,
  acknowledge a gap or archive from the UI is a decision for Rowshan (the methods exist in `QrBridge.Shared`;
  operators use SQL today, technical guide §8.4).
- **Payloads are untrusted and in clear**: shown only through Razor's encoding, coloured in `ui.js` with text nodes
  only, parsed only through `SafeXml`, never logged. A test proves a `<script>` inside a payload shows as text.
- **Only under `/qrbridge-ui`**: every other GET still gets 405, and the gateway refuses to start if a route in
  `routes.json` uses that prefix. SOAP callers and `/health` need no login and never get the UI's cookie.
- **Content security policy**: only the UI's own CSS and JS run; so no inline script, no `style="…"`, no CDN.

## 5. How to change it

| I want to… | Do this |
|---|---|
| show another field on the detail page | add a `Fact` in `MessageQueries.MessageFacts` / `RouteFacts` / `IntegrityFacts` (or the Times group in `OutboxDetailAsync` / `InboxDetailAsync`) |
| show more about a Receipt / Reply / answered Request in its round-trip section | add a `Fact` in `MessageQueries.AddArrivedAnswersAsync` / `AddSentAnswersAsync` / `AddArrivedAnsweredAsync` / `AddSentAnsweredAsync` (rendered by `Ui/Pages/Shared/_Facts.cshtml`) |
| add a column to the lists | add the value to `MessageRow` (bottom of `Ui/Data/MessageQueries.cs`), fill it in `ListAsync`, show it in `Ui/Pages/Shared/_MessageTable.cshtml` |
| add a filter | a parameter on `MessagesModel.OnGetAsync`, a field on `MessageFilter`, the `Where` in `MessageQueries`, a `<select>` in `Messages.cshtml`, and the key in `MessagesModel.PageUrl` |
| show something the gateway knows | a read-only member on `Ui/UiGatewayInfo.cs` |
| add a page | `Ui/Pages/X.cshtml` with `@page "/qrbridge-ui/x"` + `Ui/Pages/X.cshtml.cs` (an `OnGetAsync(…, CancellationToken ct)` that returns `EmptyResult` when the browser left, like `MessagesModel`); a link in `_Layout.cshtml`; a test in `tests/QrBridge.Tests/Ui/` |
| change a colour | the tokens at the top of `Ui/Assets/ui.css` (light in `:root`; dark twice: the `prefers-color-scheme` block and `[data-theme="dark"]`) |
| explain a status differently | `Display.Light` / `Display.Service` in `Ui/Display.cs` |
| change a text box's one-line explanation | `Explain:` in `MessageQueries.AddContent` (the request / response boxes) or in `Message.cshtml` (the call box) |
| show times in another zone | `Ui:TimeZone` in appsettings (no code) |

Copilot prompt: `/extend-read-only-ui`. Then `dotnet test All.slnx`.

## 6. Settings (`Ui` section of the gateway's appsettings)

| Setting | Default | Meaning |
|---|---|---|
| `Enabled` | `true` | Serve the UI. `false`: nothing is mapped; its paths get 405 |
| `Username`, `Password` | `admin`, `admin` | The one login. Set your own per site; a start with the default logs a warning; empty values stop the start |
| `SessionMinutes` | `480` | How long a login lasts; each page view extends it |
| `PageSize` | `50` | Rows per list page until the viewer picks 10, 25, 50, 100 or 200 (1–500) |
| `TimeZone` | `Eastern Standard Time` | The zone every time is shown in (a Windows or IANA id, e.g. `America/New_York`); EST / EDT follow the date. An unknown id stops the start |
| `RefreshSeconds` | `10` | Auto-refresh interval when a viewer turns it on |

## 7. Limits

- One user, from configuration. No roles, no audit of who looked at what (sign-ins are logged with the address).
- The login cookie is protected by ASP.NET's default key ring. On IIS without "Load User Profile" the keys are kept in
  memory, so an app pool recycle signs everyone out (they sign in again). Nothing else is lost.
- A delivered Inbox Request keeps no body (decision D77): its detail page shows the URL, the outcome and the answer,
  not the request. The sending side's Outbox has the full request.
- The Outbox side cannot show the far side's host: it shows the path, and the far gateway's UI shows the full URL.
- Searching inside message content is not possible (the bodies are compressed in the database); search by message or
  correlation id, service, operation or business type.
- **Times stay UTC in the database** (decided 25 Nov 2026 when a `DateTimeOffset` column was asked for): SQLite has no
  date-time type at all (it stores text), EF Core cannot compare or order `DateTimeOffset` on SQLite, and the gateway's
  queues compare and order these columns everywhere (claims, re-air, expiry, retry window, gap check). UTC also has no
  repeated hour when the clocks go back in November, and is the same on both networks. The UI shows Eastern time
  instead. In DB Browser for SQLite, on a machine set to Eastern time, `datetime(CreatedUtc, 'localtime')` shows a
  column in local time.
- **What the gateway itself answered a caller is not stored** — only the real service's response is (on the Outbox
  Request, from the far side's Reply). For a RoundTrip call that got the real answer the two are the same bytes; a
  hold-timeout answer (1596 / "not available") or a feed's immediate `RETURN_CODE 0` is not kept. Storing it would be a
  schema change.
- A Content fingerprint exists only on a caller's SOAP Request (it is how a caller's retry is recognised); Receipts,
  Replies, Heartbeats and the Registered Tags GET have none, and the page says why.
