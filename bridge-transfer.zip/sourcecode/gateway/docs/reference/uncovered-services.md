# Unimplemented work and unresolved service coverage

**Updated: 25 Nov 2026.** This page lists only unfinished work and services that are not enabled or onboarded.
It does not repeat implemented query, Registered Tags, Receipt or Reply handling.

**These items are not all impossible to implement.** Some need development work; others need a scope decision,
real service contracts or deployment details before we can implement them correctly.

## 1. Connecting QrDiode to the message queues

| Unfinished work | Why it is not ready | What is needed |
|---|---|---|
| QrDiode Sender reads the gateway Outbox; QrDiode Receiver writes the gateway Inbox | The QR apps still transfer simulator payloads or files independently. They do not reference `QrBridge.Shared` or use the gateway queues. Gateway round trips have been tested with a fake light, not through these apps and real screens/cameras. This is missing integration work, not a limitation of SOAP. | Follow the [integration plan](../../../../docs/gateway-to-qrdiode/integration-plan.md#2-connecting-qrdiode-to-the-shared-message-database): receiver-session fix, shared data/bundle work, Sender queue connection, Receiver queue connection and deferred replay commit. Then test both directions on real hardware. |

Until this is connected, a configured RoundTrip route cannot return a real service answer over the actual QR link.
Do not confuse gateway implementation with a completed optical deployment.

## 2. XA/21 and BFC operations awaiting a scope decision

These message types are currently `Unavailable` under `ProcessMessage` in
[routes.json](../../src/QrBridge.Gateway/routes.json). They return a SOAP fault and are not queued.

| Service / message type | Why it is not enabled | What is needed |
|---|---|---|
| XA2FMS: `DISPLAY_ERROR` | It is not confirmed that XA/21 crosses the CorpNet/DMZ boundary. The real `ProcessMessage` response shape is also unknown, so we cannot invent a caller-compatible pending/error reply. | Rowshan confirms XA/21 is in scope (D23); obtain the real response shape and caller timeout; configure a reply profile and RoundTrip treatment, with tests. |
| XA2FMS: `DEVICE_STATUS_CHANGE` | The same scope and response-shape questions apply. It changes state, so enabling it without correct response and retry behaviour would be unsafe. | The same confirmation and contract evidence as `DISPLAY_ERROR`; validate state-changing behaviour with the service team. |
| IR2BFC: `BUS_FAULT_CORRELATION_REQUEST` | It is not confirmed that BFC crosses the gap. Its real `ProcessMessage` result shape must be known before a caller-compatible query response can be configured. | Rowshan confirms BFC is in scope (D23); obtain the response contract and timeout; configure the query's RoundTrip and unavailable-answer treatment, with tests. |

**Not an unfinished feature:** `DISPLAY_POLL` and `BUS_FAULT_OUTAGE_REQUEST` are intentionally unavailable while
islanded (D15). They should not be implemented as cross-gap polls without a new decision.

## 3. Interfaces not onboarded

| Interface | Why it is not implemented | What is needed |
|---|---|---|
| ReportService: `IFMSInterface.ProcessRequest` | A proxy exists in the simulator, but its screens do not use it. No real cross-gap caller has been confirmed, and there is no route for it. Adding it now would guess the requirement. | Confirm a real caller, which side it runs on, the endpoint, request/response contract and timeout (D20). Then add the configured route, contract validation and tests. |
| `DatabaseService.svc` / `ServerService.svc` | They are used by the simulator's internal diagnostic tool. There is no confirmed requirement to expose them through the SOAP Gateway, and they are not in the route catalogue. | Confirm an actual cross-gap use case before onboarding them (D21). Otherwise leave them outside the system. |
| RTF: `GetPQForFeeders` (`FMS_RTFService`) | The client is late-bound MSSOAP; URL, service and port come from the registry. No WSDL is available in the supplied source. We cannot configure and validate the exact call from an operation name alone. | Obtain the endpoint/registry settings, a real WSDL or equivalent verified contract evidence, sample requests/replies, caller timeout and scope approval (D22). |
| Maximo (`FMS_FMS2SSLService` / `MaximoInterface`) | The supplied client sends plain XML through API Management, not SOAP. The current SOAP Gateway does not implement this POST interface; treating it as SOAP would change what the caller sends or expects. | Confirm scope and obtain the API Management endpoint, authentication requirements and exact request/response format. Agree a separate HTTP handling design before implementation (D22); do not alter the existing caller contract. |
| OSS / NRI | They are named in the original architecture, but their interfaces and payloads are not supplied in the simulator. There is not enough evidence to define routes or validate messages. | Obtain owners, direction, protocols, endpoints, contracts, payload samples and islanding requirements (D22). |
| Additional "Feeder Status" interface from the architecture | The named requirement has not been mapped to a verified interface. Do not assume it is another service, or that it is the existing FMS2FSS feed. | Ask the service owner whether it is already covered by FMS2FSS or is a separate interface; obtain its contract and requirements if separate. |

The scope questions are recorded in [HANDOFF §10](../../../../docs/handoff.md#10-open-questions-for-rowshan).
The catalogue exclusions for RTF and Maximo are also recorded at the end of
[routes.json](../../src/QrBridge.Gateway/routes.json).

## 4. Deployment inputs still missing

These are unfinished deployment prerequisites, not missing gateway routing features.

| Missing input | Why it prevents a real deployment | What is needed |
|---|---|---|
| Corporate receiver URLs for DMZ → Corp services | [appsettings.Corp.json](../../src/QrBridge.Gateway/appsettings.Corp.json) has an empty `Gateway:Receiver:DefaultBaseUrl` and no `Targets`. The gateway cannot deliver to a real service without a configured destination; it must not take a URL from the message. | Supply the real HTTPS corporate service URLs and per-target credential settings, then verify delivery. |
| Real DMZ receiver URLs | [appsettings.Dmz.json](../../src/QrBridge.Gateway/appsettings.Dmz.json) still uses the placeholder `https://dmz-rr-server`. | Replace it with the real DMZ service host(s), using per-service targets where needed. |
| Confirmed DMZ → Corp paths and contracts | The catalogue exists, but many contracts were derived from client proxies and the configured paths need confirming. A guessed path or contract can fail against the real service even when tests pass. | Confirm paths against the actual endpoint/load-balancer configuration; obtain and compare the real contracts, response shapes and caller timeouts; test with the service owners. |
| Security approval and physical round-trip validation | A software-only fake-light test does not prove delivery time, capacity or operational safety over two real optical lanes. Real service behaviour and caller timeout compatibility remain to be verified. | Obtain security sign-off and run hardware, backlog and failure drills before islanding use. See the [release gates](../reviews/gateway-review-v6-fix-tracker.md#32-before-any-real-islanding-use-gates-not-code). |

## 5. Recommended next action

1. Continue the QrDiode queue integration in the agreed order; it is required for every real optical round trip.
2. Collect receiver URLs and real contract/timeout evidence with the service owners.
3. Ask Rowshan about XA/21, BFC and the unconfirmed interfaces before enabling or expanding scope.
4. Add an interface only after its protocol, caller-compatible replies and islanding treatment are agreed.
