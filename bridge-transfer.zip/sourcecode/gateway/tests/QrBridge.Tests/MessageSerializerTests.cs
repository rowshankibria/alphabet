using QrBridge.Shared;
using QrBridge.Shared.Serialization;

namespace QrBridge.Tests;

public class MessageSerializerTests
{
    private static MessageSerializer Serializer(int max = 1_000_000) => new(max);

    private static MessageHeader Header() => new()
    {
        MessageId = Guid.NewGuid(),
        Direction = Direction.CorpToDmz,
        ServiceName = "FC2FMS",
        Operation = "SendToFMS",
        BusinessType = "REQUEST_FOR_PERMIT",
        Path = "/FMS_FC2FMSInterface/FC2FMSInterface.svc",
        SoapActionHeader = "\"http://tempuri.org/IFC2FMSInterface/SendToFMS\"",
        ContentType = "text/xml; charset=utf-8",
        PayloadFormat = PayloadFormat.RawSoap,
        Sequence = 42,
        CreatedUtc = new DateTime(2026, 11, 19, 12, 0, 0, DateTimeKind.Utc),
    };

    [Fact]
    public void Serialize_then_deserialize_round_trips_header_and_body()
    {
        var serializer = Serializer();
        var header = Header();
        byte[] body = "hello bridge"u8.ToArray();

        var (back, backBody) = serializer.Deserialize(serializer.Serialize(header, body));

        Assert.Equal(header, back);
        Assert.Equal(body, backBody);
    }

    [Fact]
    public void Missing_soap_action_stays_null()
    {
        // SOAP 1.2 requests carry the action in Content-Type and have no SOAPAction header.
        var serializer = Serializer();
        var header = Header() with { SoapActionHeader = null, ContentType = "application/soap+xml; charset=utf-8; action=\"urn:x\"" };
        var (back, _) = serializer.Deserialize(serializer.Serialize(header, [1]));
        Assert.Null(back.SoapActionHeader);
        Assert.Equal(header.ContentType, back.ContentType);
    }

    [Fact]
    public void Body_bytes_are_not_reinterpreted()
    {
        // Not UTF-8, not XML: must still come back byte for byte.
        var serializer = Serializer();
        byte[] body = [0xFF, 0x00, 0xFE, 0x3C, 0x41];
        Assert.Equal(body, serializer.Deserialize(serializer.Serialize(Header(), body)).Body);
    }

    [Fact]
    public void Header_without_id_or_with_too_long_path_is_refused()
    {
        Assert.Throws<ArgumentException>(() => Serializer().Serialize(Header() with { MessageId = Guid.Empty }, [1]));
        Assert.Throws<ArgumentException>(() => Serializer().Serialize(Header() with { Kind = 0 }, [1]));
        Assert.Throws<InvalidDataException>(() => Serializer().Serialize(Header() with { Path = "/" + new string('a', 5000) }, [1]));
    }

    [Fact]
    public void Empty_business_type_round_trips()
    {
        var serializer = Serializer();
        var header = Header() with { BusinessType = "" };
        var (opened, _) = serializer.Deserialize(serializer.Serialize(header, [1]));
        Assert.Equal("", opened.BusinessType);
    }

    [Fact]
    public void Peek_reads_header()
    {
        var header = Header();
        byte[] messageBytes = Serializer().Serialize(header, [1, 2, 3]);
        Assert.Equal(header, MessageSerializer.PeekHeader(messageBytes));
    }

    [Fact]
    public void Corrupted_header_fails_the_checksum()
    {
        var serializer = Serializer();
        byte[] messageBytes = serializer.Serialize(Header(), [1, 2, 3]);
        int seqOffset = 4 + 4 + 4 + 16; // magic, headerLen, version/direction/format/compression, MessageId -> Sequence
        messageBytes[seqOffset] ^= 0x01;
        var ex = Assert.Throws<InvalidDataException>(() => serializer.Deserialize(messageBytes));
        Assert.Contains("checksum", ex.Message);
    }

    [Fact]
    public void Corrupted_body_fails_the_checksum()
    {
        var serializer = Serializer();
        byte[] messageBytes = serializer.Serialize(Header(), new byte[100]);
        messageBytes[^1] ^= 0x01;
        var ex = Assert.Throws<InvalidDataException>(() => serializer.Deserialize(messageBytes));
        Assert.Contains("checksum", ex.Message);
    }

    [Fact]
    public void Truncated_message_is_rejected()
    {
        byte[] messageBytes = Serializer().Serialize(Header(), new byte[50]);
        Assert.ThrowsAny<Exception>(() => Serializer().Deserialize(messageBytes[..^10]));
    }

    [Fact]
    public void Oversized_payload_is_refused()
    {
        Assert.Throws<ArgumentException>(() => Serializer(max: 10).Serialize(Header(), new byte[11]));
    }

    [Fact]
    public void Decompression_bomb_is_stopped()
    {
        // 5 MB of zeros compresses to almost nothing; the opener's limit is 1 MB.
        var big = Serializer(max: 10_000_000).Serialize(Header(), new byte[5_000_000]);
        Assert.Throws<InvalidDataException>(() => Serializer(max: 1_000_000).Deserialize(big));
    }

    [Fact]
    public void Compression_makes_soap_much_smaller()
    {
        string xml = string.Concat(Enumerable.Repeat("<MOVE><FMS_MOVE_ID>11467104</FMS_MOVE_ID><MOVE_STATUS>COMPLETE</MOVE_STATUS></MOVE>", 200));
        byte[] payload = System.Text.Encoding.UTF8.GetBytes(xml);
        byte[] messageBytes = Serializer().Serialize(Header(), payload);
        Assert.True(messageBytes.Length < payload.Length / 5, $"{messageBytes.Length} vs {payload.Length}");
    }

    // ---------------- header v4 (V6 review fix, step 4) ----------------

    private const string Fingerprint = "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08";

    /// <summary>A FC2FMS request written by the 24 Nov 2026 serializer (format BRG3, header version 3), before step 4.</summary>
    private const string Brg3Message =
        "QlJHM7oAAAADAQEBERERESIiMzNERFVVVVVVVSoAAAAAAAAAAGAwozRG3wgGRkMyRk1TCVNlbmRUb0ZNUxJSRVFVRVNUX0ZPUl9QRVJNSVQoL0ZNU19GQzJG" +
        "TVNJbnRlcmZhY2UvRkMyRk1TSW50ZXJmYWNlLnN2YwEvImh0dHA6Ly90ZW1wdXJpLm9yZy9JRkMyRk1TSW50ZXJmYWNlL1NlbmRUb0ZNUyIXdGV4dC94bWw7" +
        "IGNoYXJzZXQ9dXRmLTia7+p+S+LR6TflRpmebbXBzaY8sVk2iTHnPAoCa3Cy1hEAAAALBoA8czpFbnZlbG9wZS8+Aw==";

    [Fact]
    public void A_reply_header_round_trips_every_field()
    {
        var serializer = Serializer();
        var header = Header() with
        {
            Kind = MessageKind.Reply,
            CorrelationId = Guid.NewGuid(),
            ContentFingerprint = Fingerprint,
            ExpiresUtc = new DateTime(2026, 11, 19, 12, 10, 0, DateTimeKind.Utc),
            SequenceRunId = Guid.NewGuid(),
            CatalogFingerprint = Fingerprint.Replace('9', '0'),
            CallerHost = "10.20.30.40",
            Outcome = ServiceOutcome.Refused,
            ServiceHttpStatus = 500,
            ServiceComment = "The service returned a fault (HTTP 500). SOAP fault: Card is not active",
        };

        byte[] messageBytes = serializer.Serialize(header, [1, 2, 3]);

        Assert.Equal(header, serializer.Deserialize(messageBytes).Header);
        Assert.Equal(header, MessageSerializer.PeekHeader(messageBytes)); // the QR Receiver reads Kind/CorrelationId without unpacking
    }

    [Fact]
    public void A_request_without_the_new_fields_reads_back_as_absent()
    {
        var serializer = Serializer();
        var (back, _) = serializer.Deserialize(serializer.Serialize(Header(), [1]));

        Assert.Equal(MessageKind.Request, back.Kind);
        Assert.Null(back.CorrelationId);
        Assert.Null(back.ContentFingerprint);
        Assert.Null(back.ExpiresUtc);
        Assert.Equal(Guid.Empty, back.SequenceRunId);
        Assert.Null(back.CatalogFingerprint);
        Assert.Null(back.CallerHost);
        Assert.Null(back.Outcome);
        Assert.Null(back.ServiceHttpStatus);
        Assert.Null(back.ServiceComment);
    }

    [Fact]
    public void The_priority_travels_in_the_header_and_a_request_is_never_an_answer()
    {
        // D73: the QR Receiver files every message by its priority without the catalogue, so it must survive the light.
        var serializer = Serializer();
        foreach (var priority in new[] { MessagePriority.High, MessagePriority.Normal, MessagePriority.Low })
            Assert.Equal(priority, serializer.Deserialize(serializer.Serialize(Header() with { Priority = priority }, [1])).Header.Priority);
        var reply = Header() with { Kind = MessageKind.Reply, CorrelationId = Guid.NewGuid(), Outcome = ServiceOutcome.Done, Priority = MessagePriority.Answer };
        Assert.Equal(MessagePriority.Answer, MessageSerializer.PeekHeader(serializer.Serialize(reply, [])).Priority);

        Assert.Throws<InvalidDataException>(() => serializer.Serialize(Header() with { Priority = MessagePriority.Answer }, [1]));
        Assert.Throws<InvalidDataException>(() => serializer.Serialize(Header() with { Priority = (MessagePriority)9 }, [1]));
    }

    [Fact]
    public void An_http_get_request_carries_no_body_content_type_or_soap_action()
    {
        // D18: a plain GET crosses as an empty HttpGet Request; anything that could carry content is refused.
        var serializer = Serializer();
        var get = Header() with { PayloadFormat = PayloadFormat.HttpGet, Operation = "GET", ContentType = "", SoapActionHeader = null };
        Assert.Equal(get, serializer.Deserialize(serializer.Serialize(get, [])).Header);

        Assert.Throws<InvalidDataException>(() => serializer.Serialize(get, [1]));
        Assert.Throws<InvalidDataException>(() => serializer.Serialize(get with { ContentType = "text/xml" }, []));
        Assert.Throws<InvalidDataException>(() => serializer.Serialize(get with { SoapActionHeader = "\"x\"" }, []));
        Assert.Throws<InvalidDataException>(() => serializer.Serialize(get with { Kind = MessageKind.Receipt, CorrelationId = Guid.NewGuid() }, []));
    }

    [Fact]
    public void A_receipt_and_a_reply_without_an_answer_need_no_path_or_content_type()
    {
        // D44: a Receipt only names the message that arrived; D43: a Reply without an HTTP answer has no Content-Type.
        var serializer = Serializer();
        var receipt = Header() with { Kind = MessageKind.Receipt, CorrelationId = Guid.NewGuid(), Path = "", ContentType = "", SoapActionHeader = null };
        var reply = receipt with { Kind = MessageKind.Reply, Outcome = ServiceOutcome.NotDelivered, ServiceComment = "Could not connect" };

        Assert.Equal(receipt, serializer.Deserialize(serializer.Serialize(receipt, [])).Header);
        Assert.Equal(reply, serializer.Deserialize(serializer.Serialize(reply, [])).Header);
    }

    [Fact]
    public void A_heartbeat_names_no_message_carries_nothing_and_goes_first()
    {
        // D80 (step 17): "this side is alive" — nothing in it can be mistaken for a message, an answer or content.
        var serializer = Serializer();
        var heartbeat = Header() with
        {
            Kind = MessageKind.Heartbeat, Priority = MessagePriority.Answer, Path = "", ContentType = "", SoapActionHeader = null,
            ServiceName = MessageHeader.HeartbeatServiceName, Operation = MessageHeader.HeartbeatOperation, BusinessType = "",
        };
        var (read, body) = serializer.Deserialize(serializer.Serialize(heartbeat, []));
        Assert.Equal(heartbeat, read);
        Assert.Empty(body);

        Assert.Throws<InvalidDataException>(() => serializer.Serialize(heartbeat, [1]));
        Assert.Throws<InvalidDataException>(() => serializer.Serialize(heartbeat with { CorrelationId = Guid.NewGuid() }, []));
        Assert.Throws<InvalidDataException>(() => serializer.Serialize(heartbeat with { ContentFingerprint = Fingerprint }, []));
        Assert.Throws<InvalidDataException>(() => serializer.Serialize(heartbeat with { ExpiresUtc = heartbeat.CreatedUtc.AddMinutes(1) }, []));
        Assert.Throws<InvalidDataException>(() => serializer.Serialize(heartbeat with { Priority = MessagePriority.Low }, []));
    }

    [Theory]
    [InlineData("reply without outcome")]
    [InlineData("request with outcome")]
    [InlineData("receipt without correlation id")]
    [InlineData("receipt with http status")]
    [InlineData("http status 99")]
    [InlineData("http status 600")]
    [InlineData("comment too long")]
    [InlineData("comment with a line break")]
    [InlineData("request without path")]
    [InlineData("request without content type")]
    public void An_inconsistent_v5_header_is_refused(string problem)
    {
        var reply = Header() with { Kind = MessageKind.Reply, CorrelationId = Guid.NewGuid(), Outcome = ServiceOutcome.Done };
        var header = problem switch
        {
            "reply without outcome" => reply with { Outcome = null },
            "request with outcome" => Header() with { Outcome = ServiceOutcome.Done },
            "receipt without correlation id" => Header() with { Kind = MessageKind.Receipt },
            "receipt with http status" => Header() with { Kind = MessageKind.Receipt, CorrelationId = Guid.NewGuid(), ServiceHttpStatus = 200 },
            "http status 99" => reply with { ServiceHttpStatus = 99 },
            "http status 600" => reply with { ServiceHttpStatus = 600 },
            "comment too long" => reply with { ServiceComment = new string('a', 1025) },
            "comment with a line break" => reply with { ServiceComment = "ok\r\nFAKE LOG LINE" }, // shown to operators, logged
            "request without path" => Header() with { Path = "" },
            _ => Header() with { ContentType = " " },
        };
        Assert.Throws<InvalidDataException>(() => Serializer().Serialize(header, [1]));
    }

    [Theory]
    [InlineData("reply without correlation id")]
    [InlineData("request with correlation id")]
    [InlineData("fingerprint not sha-256 hex")]
    [InlineData("upper-case fingerprint")]
    [InlineData("expires before created")]
    [InlineData("caller host too long")]
    [InlineData("caller host with a line break")]
    public void An_inconsistent_v4_header_is_refused(string problem)
    {
        var header = problem switch
        {
            "reply without correlation id" => Header() with { Kind = MessageKind.Reply },
            "request with correlation id" => Header() with { CorrelationId = Guid.NewGuid() },
            "fingerprint not sha-256 hex" => Header() with { ContentFingerprint = "abc" },
            "upper-case fingerprint" => Header() with { CatalogFingerprint = Fingerprint.ToUpperInvariant() },
            "expires before created" => Header() with { ExpiresUtc = Header().CreatedUtc.AddSeconds(-1) },
            "caller host too long" => Header() with { CallerHost = new string('a', 257) },
            _ => Header() with { CallerHost = "10.0.0.1\r\nFAKE LOG LINE" }, // it is logged at delivery (step 15)
        };
        Assert.Throws<InvalidDataException>(() => Serializer().Serialize(header, [1]));
    }

    [Fact]
    public void Peek_refuses_an_unknown_kind_or_a_bad_presence_flag()
    {
        // PeekHeader skips the checksum, and the QR Receiver will route on Kind: the new bytes must be checked on read.
        byte[] good = Serializer().Serialize(Header(), [1]);
        int headerEnd = 8 + BitConverter.ToInt32(good, 4);
        // Tail of a request header: Kind, CorrelationId flag, ContentFingerprint flag, ExpiresUtc flag, SequenceRunId (16),
        // CatalogFingerprint flag, CallerHost flag, then (version 5) Outcome, ServiceHttpStatus and ServiceComment flags,
        // then (version 6) Priority.
        int kindOffset = headerEnd - 26;

        byte[] unknownKind = (byte[])good.Clone();
        unknownKind[kindOffset] = 9;
        Assert.Contains("MessageKind", Assert.Throws<InvalidDataException>(() => MessageSerializer.PeekHeader(unknownKind)).Message);

        byte[] badFlag = (byte[])good.Clone();
        badFlag[kindOffset + 1] = 2;
        Assert.Contains("presence", Assert.Throws<InvalidDataException>(() => MessageSerializer.PeekHeader(badFlag)).Message);
    }

    [Fact]
    public void A_message_in_the_previous_format_is_refused_with_a_clear_reason()
    {
        // Rows written before step 4 (dev databases) must not be half-read as the new format.
        byte[] brg3 = Convert.FromBase64String(Brg3Message);
        Assert.Contains("BRG3", Assert.Throws<InvalidDataException>(() => Serializer().Deserialize(brg3)).Message);
        Assert.Contains("BRG3", Assert.Throws<InvalidDataException>(() => MessageSerializer.PeekHeader(brg3)).Message);

        // Version 4 (before step 9b): the magic alone decides, so nothing after it is half-read.
        byte[] brg4 = Serializer().Serialize(Header(), [1]);
        "BRG4"u8.CopyTo(brg4);
        Assert.Contains("BRG4", Assert.Throws<InvalidDataException>(() => Serializer().Deserialize(brg4)).Message);
        Assert.Contains("BRG4", Assert.Throws<InvalidDataException>(() => MessageSerializer.PeekHeader(brg4)).Message);

        // Version 5 (before step 14): no Priority byte.
        byte[] brg5 = Serializer().Serialize(Header(), [1]);
        "BRG5"u8.CopyTo(brg5);
        Assert.Contains("BRG5", Assert.Throws<InvalidDataException>(() => Serializer().Deserialize(brg5)).Message);
        Assert.Contains("BRG5", Assert.Throws<InvalidDataException>(() => MessageSerializer.PeekHeader(brg5)).Message);

        // Version 6 (before step 17): no Heartbeat kind; same layout, still refused by its magic.
        byte[] brg6 = Serializer().Serialize(Header(), [1]);
        "BRG6"u8.CopyTo(brg6);
        Assert.Contains("BRG6", Assert.Throws<InvalidDataException>(() => Serializer().Deserialize(brg6)).Message);
        Assert.Contains("BRG6", Assert.Throws<InvalidDataException>(() => MessageSerializer.PeekHeader(brg6)).Message);
    }
}
