using Microsoft.EntityFrameworkCore;
using QrBridge.Gateway;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Tests.Gateway.Infrastructure;
using QrBridge.Tests.Ui.Infrastructure;

namespace QrBridge.Tests.Ui;

/// <summary>
/// A busy islanding day on both gateways (<see cref="DemoTraffic"/>), then every page of both UIs: every kind of message
/// and every status renders. It is also how to get sample data for looking at the UI: with QRBRIDGE_DEMO_ROOT set (e.g.
/// C:\QrBridgeDev, the launch profiles' folders) the two databases are written there and kept (read-only-ui.md §2).
/// </summary>
public sealed class UiDemoDataTests
{
    [Fact]
    public async Task A_busy_day_renders_on_both_sides_with_every_kind_and_status()
    {
        string? keep = Environment.GetEnvironmentVariable(DemoTraffic.RootVariable);
        string root = string.IsNullOrWhiteSpace(keep) ? GatewayHost.NewRoot() : keep;
        try
        {
            await using var demo = await DemoTraffic.RunAsync(root);

            // The day really produced every outcome, on the side where it belongs.
            await using (var corp = await demo.Corp.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync())
            {
                var outbox = await corp.Outbox.AsNoTracking().Select(m => new { m.Kind, m.LightStatus, m.ServiceStatus }).ToListAsync();
                foreach (var status in new[] { OutboxServiceStatus.Answered, OutboxServiceStatus.Refused, OutboxServiceStatus.Unknown,
                                               OutboxServiceStatus.NotDelivered, OutboxServiceStatus.Expired })
                    Assert.True(outbox.Any(m => m.Kind == MessageKind.Request && m.ServiceStatus == status),
                        $"No Corp Outbox Request is {status}: " +
                        string.Join(", ", outbox.Where(m => m.Kind == MessageKind.Request).Select(m => $"{m.ServiceStatus}/{m.LightStatus}")));
                Assert.Contains(outbox, m => m.LightStatus == OutboxLightStatus.Failed);
                foreach (var kind in Enum.GetValues<MessageKind>())
                    Assert.Contains(outbox, m => m.Kind == kind);
                // Every caller's SOAP Request has a content fingerprint; only the plain HTTP GET (a query, no body) has none.
                Assert.Empty(await corp.Outbox.Where(m => m.Kind == MessageKind.Request && m.ContentFingerprint == null &&
                                                         m.PayloadFormat != PayloadFormat.HttpGet).Select(m => m.ServiceName).ToListAsync());
                Assert.True(await corp.Inbox.AnyAsync(m => m.LightStatus == InboxLightStatus.Rejected));
                Assert.True(await corp.Inbox.AnyAsync(m => m.Kind == MessageKind.Request && m.ServiceStatus == InboxServiceStatus.Done));
                Assert.True(await corp.Inbox.AnyAsync(m => m.Kind == MessageKind.Request && m.ServiceStatus == InboxServiceStatus.Refused));
                Assert.True(await corp.Inbox.AnyAsync(m => m.Kind == MessageKind.Heartbeat && m.ServiceStatus == InboxServiceStatus.Done));
            }
            await using (var dmz = await demo.Dmz.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync())
            {
                var inbox = await dmz.Inbox.AsNoTracking().Select(m => new { m.Kind, m.LightStatus, m.ServiceStatus }).ToListAsync();
                foreach (var status in new[] { InboxServiceStatus.Done, InboxServiceStatus.Refused, InboxServiceStatus.Unknown,
                                               InboxServiceStatus.NotDelivered, InboxServiceStatus.Expired })
                    Assert.True(inbox.Any(m => m.Kind == MessageKind.Request && m.LightStatus == InboxLightStatus.Received && m.ServiceStatus == status),
                        $"No DMZ Inbox Request is {status}: " +
                        string.Join(", ", inbox.Where(m => m.Kind == MessageKind.Request).Select(m => $"{m.ServiceStatus}/{m.LightStatus}")));
                Assert.Contains(inbox, m => m.LightStatus == InboxLightStatus.Rejected);
            }

            // Every page of both UIs answers, for every message.
            foreach (var host in new[] { demo.Corp, demo.Dmz })
            {
                using var ui = await new UiBrowser(host).SignedInAsync();
                await ui.PageAsync(UiPaths.Prefix);
                await using var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
                foreach (var (box, ids) in new[]
                         {
                             (MessageBox.Outbox, await db.Outbox.Select(m => m.MessageId).ToListAsync()),
                             (MessageBox.Inbox, await db.Inbox.Select(m => m.MessageId).ToListAsync()),
                         })
                {
                    string list = UiBrowser.Text(await ui.PageAsync(UiPaths.Box(box) + "?kind=all&size=200"));
                    Assert.Contains($"Showing 1–{ids.Count} of {ids.Count}", list);
                    foreach (var id in ids)
                        await ui.PageAsync(UiPaths.Message(box, id));
                }
            }
        }
        finally
        {
            if (string.IsNullOrWhiteSpace(keep)) GatewayHost.DeleteRoot(root);
        }
    }
}
