using QrBridge.Gateway;

namespace QrBridge.Tests.Ui;

/// <summary>The UI's prefix (decision 48) and the return URLs it accepts after a login.</summary>
public sealed class UiPathsTests
{
    [Theory]
    [InlineData("/qrbridge-ui", true)]
    [InlineData("/QRBRIDGE-UI/outbox", true)] // paths are matched without case
    [InlineData("/qrbridge-ui/assets/ui.css", true)]
    [InlineData("/qrbridge-ui-other", false)]
    [InlineData("/health", false)]
    [InlineData("/", false)]
    [InlineData(null, false)]
    public void The_ui_owns_its_prefix_and_nothing_else(string? path, bool expected) =>
        Assert.Equal(expected, UiPaths.IsUiPath(path));

    [Theory]
    [InlineData("/qrbridge-ui/inbox?kind=all", true)]
    [InlineData("/qrbridge-ui", true)]
    [InlineData("https://evil.example/qrbridge-ui", false)]
    [InlineData("//evil.example/qrbridge-ui", false)]
    [InlineData("/\\evil.example/qrbridge-ui", false)]
    [InlineData("/health", false)]
    [InlineData("", false)]
    [InlineData(null, false)]
    public void Only_a_local_page_of_the_ui_is_a_safe_return_url(string? url, bool expected) =>
        Assert.Equal(expected, UiPaths.IsSafeReturnUrl(url));
}
