using QrBridge.Gateway;
using QrBridge.Shared;
using QrBridge.Tests.Gateway.Infrastructure;
using QrBridge.Tests.Ui.Infrastructure;

namespace QrBridge.Tests.Ui;

/// <summary>
/// The lists are paged in the database: the filter and the search run in SQL, then only one page of rows is read. The
/// pager footer is always shown (rows shown, rows per page, page n of m, previous and next), also for a single page.
/// </summary>
public sealed class UiPagingTests
{
    private const int Feeds = 12;

    [Fact]
    public async Task Pages_follow_the_page_size_and_the_search_and_the_pager_is_always_shown()
    {
        string root = GatewayHost.NewRoot();
        var host = GatewayHost.Start(BridgeSide.Corp, root);
        try
        {
            using (var caller = host.CreateClient())
                for (int i = 0; i < Feeds; i++) // Bridge feeds: stored and answered at once; the same content is queued again
                    (await SoapCalls.PostAsync(caller, FmsEndpoint.FTC2FMS, "SendToFMS",
                        SoapCalls.Build(FmsEndpoint.FTC2FMS, "SendToFMS", SoapCalls.Sample("FAULT_CORRELATION.txt")))).Response.Dispose();
            using var ui = await new UiBrowser(host).SignedInAsync();
            string outbox = UiPaths.Box(MessageBox.Outbox);

            string first = await ui.PageAsync($"{outbox}?size=10");
            Assert.Equal(10, Rows(first));
            Assert.Contains("Showing 1–10 of 12", UiBrowser.Text(first));
            Assert.Contains("of 2</span>", first);
            Assert.Contains($"href=\"{outbox}?size=10&amp;p=2\"", first); // Next keeps the page size

            string second = await ui.PageAsync($"{outbox}?size=10&p=2");
            Assert.Equal(2, Rows(second));
            Assert.Contains("Showing 11–12 of 12", UiBrowser.Text(second));

            // A page beyond the last shows the last; a search is paged the same way (in the database).
            Assert.Contains("Showing 11–12 of 12", UiBrowser.Text(await ui.PageAsync($"{outbox}?size=10&p=9")));
            string searched = await ui.PageAsync($"{outbox}?q=fault_corr&size=10&p=2");
            Assert.Equal(2, Rows(searched));
            Assert.Contains($"name=\"q\" value=\"fault_corr\"", searched); // the pager keeps the search

            // One page: the pager is still there, with Prev and Next disabled.
            string all = UiBrowser.Text(await ui.PageAsync(outbox));
            Assert.Contains("Showing 1–12 of 12", all);
            Assert.Contains("Rows per page", all);
            Assert.Contains("of 1", all);
        }
        finally
        {
            await host.DisposeAsync();
            GatewayHost.DeleteRoot(root);
        }
    }

    private static int Rows(string html) => html.Split("<tr data-href=").Length - 1;
}
