using Microsoft.EntityFrameworkCore;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Tests.Gateway.Infrastructure;
using QrBridge.Tests.Ui.Infrastructure;
using QrBridge.Gateway;

namespace QrBridge.Tests.Ui;

/// <summary>
/// One round trip (Corp caller → DMZ real service → answer back, over the fake light), checked on both sides' UI:
/// the Corp Outbox shows the call as received and the real answer; the DMZ Inbox shows the URL it posted to (from
/// Gateway:Receiver) and, once the body is cleared after delivery (D77), the answer from its own Reply.
/// </summary>
public sealed class UiRoundTripTests
{
    private const string Fc2FmsPath = "/FMS_FC2FMSInterface/FC2FMSInterface.svc";

    [Fact]
    public async Task Both_sides_show_the_request_and_the_real_answer_in_plain_words()
    {
        await using var bench = TwoGatewayBench.Start((_, _) => TwoGatewayBench.Answer(200, TwoGatewayBench.RealAnswer),
            new Dictionary<string, string?> { ["Gateway:Hold:DefaultSeconds"] = "20" });
        using var caller = bench.Corp.CreateClient();
        var (response, reply) = await SoapCalls.PostAsync(caller, FmsEndpoint.FC2FMS, "GetFromFMS", TwoGatewayBench.WithdrawRfp());
        Assert.Equal(0, TwoGatewayBench.Code(reply)); // the real answer came back to the caller
        var id = Guid.Parse(response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());
        await TwoGatewayBench.WaitForInboxAsync(bench.Dmz, id, r => r.ServiceStatus == InboxServiceStatus.Done);
        await WaitForUsedReplyAsync(bench.Corp, id);

        // Corp, the sending side: the call as received, its FMS message and the real service's answer.
        using var corp = await new UiBrowser(bench.Corp).SignedInAsync();
        string sent = UiBrowser.Text(await corp.PageAsync(UiPaths.Box(MessageBox.Outbox)));
        Assert.Contains($"POST {Fc2FmsPath}", sent);
        Assert.Contains("<MESSAGE TYPE=\"WITHDRAW_RFP\"", sent);

        var replyId = await ReplyIdAsync(bench.Corp, id);
        string requestHtml = await corp.PageAsync(UiPaths.Message(MessageBox.Outbox, id));
        string request = UiBrowser.Text(requestHtml);
        Assert.Contains("SOAPAction: \"http://tempuri.org/IFC2FMSInterface/GetFromFMS\"", request);
        Assert.Contains("Request: the message in sXML", request);
        Assert.Contains("Answered", request);
        Assert.Contains("Response: the message in GetFromFMSResult", request);
        Assert.Contains("Response: SOAP envelope, indented", request);
        Assert.Contains("<GetFromFMSResponse xmlns=\"http://tempuri.org/\">", request); // the response's SOAP body
        Assert.Contains("<RETURN_CODE>0</RETURN_CODE>", request);

        // The whole round trip on the Request's page: the far side's Reply in its own section, before Related messages.
        Assert.Contains("Reply from the DMZ side: what the real service did", request);
        Assert.Contains("The real service's answer (accepted, refused…)", request); // in business words
        Assert.Contains("Answered · HTTP 200", request);
        Assert.Contains("shown above", request);
        Assert.Contains($"href=\"{UiPaths.Message(MessageBox.Inbox, replyId)}\"", requestHtml);
        Assert.True(requestHtml.IndexOf("class=\"band band-response\"", StringComparison.Ordinal) <
                    requestHtml.IndexOf("Reply from the DMZ side", StringComparison.Ordinal)); // under RESPONSE
        Assert.True(request.IndexOf("Reply from the DMZ side", StringComparison.Ordinal) <
                    request.IndexOf("Related messages", StringComparison.Ordinal));
        // Related messages close the DETAILS band (they fold away with it): after its strip, before its end.
        int details = requestHtml.IndexOf("class=\"band band-details\"", StringComparison.Ordinal);
        int related = requestHtml.IndexOf("Related messages", StringComparison.Ordinal);
        Assert.True(details < related && related < requestHtml.LastIndexOf("</details>", StringComparison.Ordinal));

        string answers = UiBrowser.Text(await corp.PageAsync(UiPaths.Box(MessageBox.Inbox) + "?kind=all"));
        Assert.Contains("Reply", answers);
        Assert.Contains("Used", answers);

        // The far side's Reply in this Inbox: used (its body cleared, D77), and still shows the response, with the
        // correlation id of the round trip (the Request's id) and the Request it answers.
        string used = await corp.PageAsync(UiPaths.Message(MessageBox.Inbox, replyId));
        string usedText = UiBrowser.Text(used);
        Assert.Contains("kept on the Outbox Request it answers", usedText);
        Assert.Contains("<GetFromFMSResponse xmlns=\"http://tempuri.org/\">", usedText);
        Assert.Contains($"<code id=\"correlation-id\">{id:D}</code>", used);
        Assert.Contains("The Request it answers (sent by this side)", usedText);
        Assert.Contains("The original request. This Reply tells what was done with it.", usedText);
        Assert.Contains($"href=\"{UiPaths.Message(MessageBox.Outbox, id)}\"", used);

        // DMZ, the receiving side: where it was posted, that its body was cleared, and the answer from its Reply.
        using var dmz = await new UiBrowser(bench.Dmz).SignedInAsync();
        string arrived = UiBrowser.Text(await dmz.PageAsync(UiPaths.Box(MessageBox.Inbox)));
        Assert.Contains($"POST http://real-service.test{Fc2FmsPath}", arrived);
        Assert.Contains("path from routes.json", arrived);

        string delivered = UiBrowser.Text(await dmz.PageAsync(UiPaths.Message(MessageBox.Inbox, id)));
        Assert.Contains($"POST http://real-service.test{Fc2FmsPath}", delivered);
        Assert.Contains("cleared once the real service accepted it", delivered);
        Assert.Contains("<RETURN_CODE>0</RETURN_CODE>", delivered);
        Assert.Contains("Done", delivered);
        Assert.Contains("Reply sent back by this side", delivered); // the Reply this side wrote, in its own section
        Assert.Contains("Done · HTTP 200", delivered);

        string replies = UiBrowser.Text(await dmz.PageAsync(UiPaths.Box(MessageBox.Outbox) + "?kind=Reply"));
        Assert.Contains($"POST http://real-service.test{Fc2FmsPath}", replies); // the call this Reply answers
        Assert.Contains("Done · HTTP 200", replies);

        var sentReplyId = await SentReplyIdAsync(bench.Dmz, id);
        string sentReply = UiBrowser.Text(await dmz.PageAsync(UiPaths.Message(MessageBox.Outbox, sentReplyId)));
        Assert.Contains("The Request it answers (arrived from the Corp side)", sentReply);
        Assert.Contains("FC2FMS.GetFromFMS", sentReply);
    }

    private static async Task<Guid> SentReplyIdAsync(GatewayHost host, Guid requestId)
    {
        await using var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        return await db.Outbox.Where(m => m.Kind == MessageKind.Reply && m.CorrelationId == requestId).Select(m => m.MessageId).FirstAsync();
    }

    private static async Task<Guid> ReplyIdAsync(GatewayHost host, Guid requestId)
    {
        await using var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        return await db.Inbox.Where(m => m.Kind == MessageKind.Reply && m.CorrelationId == requestId).Select(m => m.MessageId).SingleAsync();
    }

    /// <summary>The Corp gateway has read the far side's Reply for <paramref name="requestId"/> (Inbox row Done = used).</summary>
    private static async Task WaitForUsedReplyAsync(GatewayHost host, Guid requestId)
    {
        var deadline = DateTime.UtcNow.AddSeconds(30);
        while (true)
        {
            await using (var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync())
            {
                if (await db.Inbox.AnyAsync(m => m.Kind == MessageKind.Reply && m.CorrelationId == requestId &&
                                                 m.ServiceStatus == InboxServiceStatus.Done))
                    return;
            }
            if (DateTime.UtcNow > deadline) throw new TimeoutException("The Corp gateway never used the far side's Reply.");
            await Task.Delay(100);
        }
    }
}
