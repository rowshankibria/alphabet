using System.Reflection;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using QrBridge.Gateway;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Ingress;
using QrBridge.Gateway.Ui;
using QrBridge.Gateway.Ui.Data;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Tests.Gateway.Infrastructure;
using QrBridge.Tests.Ui.Infrastructure;

namespace QrBridge.Tests.Ui;

/// <summary>
/// The UI is read-only (decision 48): no UI class can reach code that writes, its connections to qrbridge.db are
/// opened read-only so SQLite refuses any write made through them, and looking at every page leaves every row as it was.
/// </summary>
public sealed class UiReadOnlyTests(UiCorpFixture fixture) : IClassFixture<UiCorpFixture>
{
    /// <summary>What writes to qrbridge.db (or calls a real service): never a dependency of the UI.</summary>
    private static readonly Type[] Writers =
    [
        typeof(OutboxWriter), typeof(AnswerWriter), typeof(SenderEndpoint), typeof(SoapForwarderHttpClient),
        typeof(IDbContextFactory<BridgeDbContext>), typeof(OutboxRepository), typeof(InboxRepository), typeof(HeartbeatRepository),
    ];

    /// <summary>
    /// The UI lives in the gateway project (Ui/), so the build no longer keeps it away from the code that writes: this
    /// test does. Every UI class (namespace QrBridge.Gateway.Ui…) and every generated page view (its @inject members)
    /// takes only read-only things. UiGatewayInfo is the one way to the rest of the gateway; it takes the forwarder only
    /// to resolve a URL, and builds its repositories on the read-only connection.
    /// </summary>
    [Fact]
    public void No_ui_class_depends_on_code_that_writes()
    {
        var types = typeof(UiGatewayInfo).Assembly.GetTypes()
            .Where(t => t.Namespace?.StartsWith("QrBridge.Gateway.Ui", StringComparison.Ordinal) == true ||
                        (t.Namespace == "AspNetCoreGeneratedDocument" && t.Name.StartsWith("Ui_Pages_", StringComparison.Ordinal)))
            .ToList();
        const BindingFlags all = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

        var problems = new List<string>();
        foreach (var type in types)
        {
            var needs = type.GetConstructors(all).SelectMany(c => c.GetParameters()).Select(p => p.ParameterType)
                .Concat(type.GetProperties(all)
                    .Where(p => p.GetCustomAttributes(true).Any(a => a.GetType().Name == "RazorInjectAttribute"))
                    .Select(p => p.PropertyType));
            foreach (var need in needs.Where(Writers.Contains).Distinct())
                if (!(type == typeof(UiGatewayInfo) && need == typeof(SoapForwarderHttpClient)))
                    problems.Add($"{type.Name} depends on {need.Name}");
        }

        Assert.Empty(problems);
        Assert.Contains(types, t => t.Name == "Ui_Pages_Index");       // the generated page views are really checked
        Assert.Contains(types, t => t == typeof(QrBridge.Gateway.Ui.Pages.LoginModel));
    }

    [Fact]
    public async Task The_uis_database_connection_refuses_every_write()
    {
        await using var db = await fixture.Host.Get<ReadOnlyBridgeDb>().CreateDbContextAsync();

        Assert.True(await db.Outbox.AnyAsync()); // reading works
        var ex = await Assert.ThrowsAsync<SqliteException>(() => db.Database.ExecuteSqlRawAsync("UPDATE Outbox SET Attempts = Attempts + 1"));
        Assert.Equal(8, ex.SqliteErrorCode); // SQLITE_READONLY
    }

    [Fact]
    public async Task Looking_at_every_page_changes_no_row()
    {
        string before = await SnapshotAsync(fixture.Host);
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        foreach (string path in new[]
                 {
                     UiPaths.Prefix,
                     UiPaths.Box(MessageBox.Outbox), UiPaths.Box(MessageBox.Outbox) + "?kind=all&light=Pending",
                     UiPaths.Box(MessageBox.Inbox), UiPaths.Box(MessageBox.Inbox) + "?kind=all",
                     UiPaths.Message(MessageBox.Outbox, fixture.FeedId),
                 })
            await ui.PageAsync(path);

        Assert.Equal(before, await SnapshotAsync(fixture.Host));
    }

    /// <summary>Every row of every message table, through the gateway's own (read-write) connection. Heartbeat rows are left out: the workers write them.</summary>
    private static async Task<string> SnapshotAsync(GatewayHost host)
    {
        await using var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        return JsonSerializer.Serialize(new
        {
            outbox = await db.Outbox.AsNoTracking().OrderBy(m => m.Sequence).ToListAsync(),
            inbox = await db.Inbox.AsNoTracking().OrderBy(m => m.ReceivedUtc).ToListAsync(),
            counters = await db.SequenceCounters.AsNoTracking().OrderBy(c => c.Direction).ToListAsync(),
            watermarks = await db.SequenceWatermarks.AsNoTracking().ToListAsync(),
            gaps = await db.AcknowledgedGaps.AsNoTracking().ToListAsync(),
        });
    }
}
