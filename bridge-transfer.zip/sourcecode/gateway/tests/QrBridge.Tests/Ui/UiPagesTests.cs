using System.Net;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using QrBridge.Gateway.Routing;
using QrBridge.Gateway.Ui;
using QrBridge.Gateway.Ui.Data;
using QrBridge.Gateway.Ui.Pages;
using QrBridge.Tests.Ui.Infrastructure;
using QrBridge.Gateway;

namespace QrBridge.Tests.Ui;

/// <summary>
/// The Outbox in plain words, never as bytes: the list shows the message and correlation ids, the exact time in Eastern
/// time, the service URL the caller called and the FMS message; the detail page shows the ids, the request line with
/// its SOAPAction and Content-Type, the message, the SOAP envelope and the bytes exactly as stored. Markup inside a
/// payload is shown as text.
/// </summary>
public sealed partial class UiPagesTests(UiCorpFixture fixture) : IClassFixture<UiCorpFixture>
{
    private const string FeedPath = "/FMS_FTC2FMSInterface/FTC2FMSInterface.svc";

    [Fact]
    public async Task The_outbox_list_shows_the_ids_the_time_the_service_url_and_the_message_in_plain_words()
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        string html = await ui.PageAsync(UiPaths.Box(MessageBox.Outbox));
        string text = UiBrowser.Text(html);

        Assert.Contains($"POST {FeedPath}", text);
        Assert.Contains("FTC2FMS", text);
        Assert.Contains("FAULT_CORRELATION", text);
        Assert.Contains("<MESSAGE TYPE=\"FAULT_CORRELATION\" MSG_ID=\"9876\"", text); // the business message, unescaped
        Assert.Contains(UiPaths.Message(MessageBox.Outbox, fixture.FeedId), html);
        Assert.Contains("Correlation id", text);
        Assert.Contains($"title=\"{fixture.FeedId:D} (this Request's own id)\"", html); // a Request's correlation id is its own id
        Assert.Matches(EasternTime(), text);                                          // the exact time, in Eastern time
        Assert.DoesNotContain("Priority", text);                                       // transport order only: not shown
        Assert.DoesNotContain("System.Byte[]", text);
    }

    [Fact]
    public async Task The_detail_shows_the_ids_the_call_and_every_form_of_its_content()
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        string html = await ui.PageAsync(UiPaths.Message(MessageBox.Outbox, fixture.FeedId));
        string text = UiBrowser.Text(html);

        Assert.Contains($"POST {FeedPath}", text);
        Assert.Contains("SOAPAction: \"http://tempuri.org/IFTC2FMSInterface/SendToFMS\"", text);
        Assert.Contains("Content-Type: text/xml; charset=utf-8", text);
        Assert.Contains("Request: the message in sXML", text);
        Assert.Contains("Request: SOAP envelope, indented", text);
        Assert.Contains("Request: exactly as stored", text);
        // Each box says in one plain line what it is.
        Assert.Contains("The message itself, the part a person reads", text);
        Assert.Contains("which names the function and its parameter sXML. Inside it, < and > are written as &lt; and &gt;", text);
        Assert.Contains("The exact bytes of the message, untouched", text);
        Assert.Contains("\n  <MSG_HEADER>", text);                       // indented for reading
        Assert.Contains("Fault Correlation -> FMS", text);                // the route's description
        Assert.Contains("Bridge: the caller was answered at once", text); // what the gateway does with it
        Assert.Contains($"<code id=\"correlation-id\">{fixture.FeedId:D}</code>", html);
        Assert.Contains($"{UiPaths.Box(MessageBox.Inbox)}?kind=all&amp;q={fixture.FeedId:D}", html); // find its Receipt and Reply here
        Assert.Matches(EasternTime(), text);
        foreach (string hidden in new[] { "<dt>Priority</dt>", "<dt>Sequence</dt>", "<dt>Caller</dt>" })
            Assert.DoesNotContain(hidden, html);
        Assert.Matches("<dt>Content fingerprint</dt>\\s*<dd[^>]*>\\s*<code[^>]*>[0-9a-f]{64}</code>", html); // a caller's Request has one
        Assert.Contains("Nothing has come back from the DMZ side yet: no Receipt (it arrived safely) and no Reply (what the real service did)", text);
        Assert.Contains("title=\"Request: a caller&#x27;s call to a service on the other side.\"", html); // what the kind chip means
    }

    [Fact]
    public async Task The_detail_page_reads_in_bands_request_then_response_then_details_each_open_and_foldable()
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        string html = await ui.PageAsync(UiPaths.Message(MessageBox.Outbox, fixture.FeedId));

        int request = html.IndexOf("class=\"band band-request\" open", StringComparison.Ordinal);
        int content = html.IndexOf("Request: the message in sXML", StringComparison.Ordinal);
        int response = html.IndexOf("class=\"band band-response\" open", StringComparison.Ordinal);
        int nothingYet = html.IndexOf("Nothing has come back from the DMZ side yet", StringComparison.Ordinal);
        int details = html.IndexOf("class=\"band band-details\" open", StringComparison.Ordinal);
        Assert.True(request >= 0 && request < content && content < response && response < nothingYet && nothingYet < details,
            $"bands out of order: request {request}, content {content}, response {response}, note {nothingYet}, details {details}");
    }

    [Fact]
    public async Task The_pages_say_QrData_not_light()
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        foreach (string path in new[] { UiPaths.Prefix, UiPaths.Box(MessageBox.Outbox), UiPaths.Message(MessageBox.Outbox, fixture.FeedId) })
        {
            string text = UiBrowser.Text(await ui.PageAsync(path));
            Assert.Contains("QrData", text);
            Assert.DoesNotMatch(@"\bLight\b(?! / dark)", text); // the theme switch keeps its name
        }
    }

    [Fact]
    public async Task Markup_inside_a_payload_is_shown_as_text_and_never_runs()
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        foreach (string path in new[] { UiPaths.Box(MessageBox.Outbox), UiPaths.Message(MessageBox.Outbox, fixture.FeedId) })
        {
            string html = await ui.PageAsync(path);
            Assert.Contains("&lt;script&gt;alert(", html);
            Assert.DoesNotContain("<script>alert", html);
            Assert.Equal(2, Regex.Matches(html, "<script", RegexOptions.IgnoreCase).Count); // theme.js and ui.js only
        }
    }

    [Theory]
    [InlineData("?kind=all", true)]
    [InlineData("?kind=Receipt", false)]
    [InlineData("?light=Received", false)]
    [InlineData("?light=Pending&service=Waiting", true)]
    [InlineData("?name=FTC2FMS", true)]
    [InlineData("?name=FC2FMS", false)]
    [InlineData("?q=fault_corr", true)] // business type, any case
    [InlineData("?q=no-such-thing", false)]
    public async Task Filters_narrow_the_list(string query, bool found)
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        string html = await ui.PageAsync(UiPaths.Box(MessageBox.Outbox) + query);

        Assert.Equal(found, html.Contains(UiPaths.Message(MessageBox.Outbox, fixture.FeedId)));
        if (!found) Assert.Contains("No messages match.", html);
    }

    [Theory]
    [InlineData(36)] // the whole id
    [InlineData(8)]  // the short id the lists show
    public async Task A_search_by_message_or_correlation_id_finds_it(int characters)
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        string html = await ui.PageAsync($"{UiPaths.Box(MessageBox.Outbox)}?q={fixture.FeedId.ToString("D")[..characters].ToUpperInvariant()}");

        Assert.Contains(UiPaths.Message(MessageBox.Outbox, fixture.FeedId), html);
    }

    [Fact]
    public async Task The_overview_reads_like_health_without_the_technical_sections()
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        string text = UiBrowser.Text(await ui.PageAsync(UiPaths.Prefix));

        Assert.Contains("The Corp gateway", text);
        Assert.Contains("Latest requests sent", text);
        Assert.Contains("FTC2FMS", text);
        Assert.Contains("Components", text);
        Assert.DoesNotContain("Missing messages", text);   // the banner still lists missing messages when there are any
        Assert.DoesNotContain("This gateway", text);
        Assert.DoesNotContain(fixture.Host.Get<RouteTable>().CatalogFingerprint, text);
    }

    [Fact]
    public async Task The_banner_says_QrGateway()
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        string html = await ui.PageAsync(UiPaths.Prefix);

        Assert.Contains("<span class=\"brand-name\">QrGateway</span>", html);
        Assert.Contains("· QrGateway Corp</title>", html);
    }

    /// <summary>
    /// The browser left before the page was ready (another click, a filter change, a refresh): ASP.NET cancels the
    /// request's token and the query stops. Each page then ends quietly instead of throwing (Visual Studio used to
    /// stop on a TaskCanceledException there).
    /// </summary>
    [Fact]
    public async Task A_page_the_browser_left_stops_quietly()
    {
        using var left = new CancellationTokenSource();
        await left.CancelAsync();
        var queries = fixture.Host.Get<MessageQueries>();

        var list = new MessagesModel(queries, fixture.Host.Get<IOptions<UiOptions>>());
        Assert.IsType<EmptyResult>(await list.OnGetAsync(MessageBox.Outbox, null, null, null, null, null, ct: left.Token));
        Assert.IsType<EmptyResult>(await new MessageModel(queries).OnGetAsync(MessageBox.Outbox, fixture.FeedId, left.Token));
        Assert.IsType<EmptyResult>(await new IndexModel(fixture.Host.Get<UiGatewayInfo>(), queries).OnGetAsync(left.Token));
    }

    [Fact]
    public async Task An_unknown_message_is_a_404_page()
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync();

        using var response = await ui.Client.GetAsync(UiPaths.Message(MessageBox.Inbox, Guid.NewGuid()));

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        Assert.Contains("No such message", await response.Content.ReadAsStringAsync());
    }

    /// <summary>"11/25/2026 05:05:39 PM EST": US format, 12-hour clock (EDT in summer).</summary>
    [GeneratedRegex(@"(0[1-9]|1[0-2])/(0[1-9]|[12]\d|3[01])/\d{4} (0[1-9]|1[0-2]):\d{2}:\d{2} [AP]M E[SD]T")]
    private static partial Regex EasternTime();

    [Fact]
    public void Times_are_written_the_US_way_on_a_12_hour_clock()
    {
        var time = fixture.Host.Get<UiTime>();
        var winter = new DateTime(2026, 11, 25, 22, 5, 39, DateTimeKind.Utc); // 5:05:39 PM in New York (EST)
        var summer = new DateTime(2026, 7, 4, 13, 0, 0, DateTimeKind.Utc);    // 9:00:00 AM in New York (EDT)

        Assert.Equal("11/25/2026 05:05:39 PM EST", time.Format(winter));
        Assert.Equal("07/04/2026 09:00:00 AM EDT", time.Format(summer));
        Assert.Equal("11/25/2026 10:05:39 PM UTC", Display.Utc(winter)); // the tooltip
    }
}
