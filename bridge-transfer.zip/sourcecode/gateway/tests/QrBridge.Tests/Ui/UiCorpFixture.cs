using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Ui;

/// <summary>
/// A Corp gateway (UI on, admin / admin) whose Outbox holds one Request: the FTC fault-correlation feed (a Bridge route,
/// so it is stored and answered at once, with no far side). Its FMS message starts with an element named script (early
/// enough to be in the list's one-line preview too), to prove the UI shows markup inside a payload as text.
/// </summary>
public sealed class UiCorpFixture : IAsyncLifetime
{
    private readonly string _root = GatewayHost.NewRoot();

    public GatewayHost Host { get; private set; } = null!;

    /// <summary>The stored feed's MessageId.</summary>
    public Guid FeedId { get; private set; }

    public static string FeedPayload =>
        SoapCalls.Sample("FAULT_CORRELATION.txt").Replace("<MSG_HEADER>", "<script>alert('ui')</script><MSG_HEADER>", StringComparison.Ordinal);

    public async Task InitializeAsync()
    {
        Host = GatewayHost.Start(BridgeSide.Corp, _root);
        using var client = Host.CreateClient();
        var (response, _) = await SoapCalls.PostAsync(client, FmsEndpoint.FTC2FMS, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.FTC2FMS, "SendToFMS", FeedPayload));
        FeedId = Guid.Parse(response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());
    }

    public async Task DisposeAsync()
    {
        await Host.DisposeAsync();
        GatewayHost.DeleteRoot(_root);
    }
}
