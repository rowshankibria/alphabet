using System.Net;
using System.Text;
using QrBridge.Shared;
using QrBridge.Tests.Gateway.Infrastructure;
using QrBridge.Tests.Ui.Infrastructure;
using QrBridge.Gateway;

namespace QrBridge.Tests.Ui;

/// <summary>
/// The UI adds GET pages only under /qrbridge-ui (decision 48, a narrow change to decision 21): every other GET still
/// gets 405, SOAP calls and /health are unchanged, Ui:Enabled = false removes it, and no route may use its prefix.
/// </summary>
public sealed class UiRoutingTests(UiCorpFixture fixture) : IClassFixture<UiCorpFixture>
{
    [Theory]
    [InlineData("/qrbridge-ui/nothing-here")]
    [InlineData("/qrbridge-ui/outbox/not-a-message-id")]
    [InlineData("/qrbridge-ui-other")]
    [InlineData("/FMS_FC2FMSInterface/FC2FMSInterface.svc?wsdl")]
    [InlineData("/")]
    public async Task Every_other_get_still_gets_405_while_the_ui_is_on(string path)
    {
        using var ui = await new UiBrowser(fixture.Host).SignedInAsync(); // even with a login

        using var response = await ui.Client.GetAsync(path);

        Assert.Equal(HttpStatusCode.MethodNotAllowed, response.StatusCode);
    }

    [Fact]
    public async Task Soap_calls_and_health_need_no_login_and_are_unchanged()
    {
        using var client = fixture.Host.CreateClient();

        string health = await client.GetStringAsync("/health");
        Assert.Contains("\"side\":\"Corp\"", health);

        var (response, body) = await SoapCalls.PostAsync(client, FmsEndpoint.FC2FMS, "EchoString",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "EchoString", "ping", "sValue"));
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal("ping", SoapCalls.Result(body));
        Assert.False(response.Headers.Contains("Set-Cookie")); // the UI's cookies never reach a SOAP caller
    }

    [Fact]
    public async Task With_the_ui_off_its_paths_answer_like_any_unknown_path()
    {
        string root = GatewayHost.NewRoot();
        var host = GatewayHost.Start(BridgeSide.Corp, root, new Dictionary<string, string?> { ["Ui:Enabled"] = "false" });
        try
        {
            using var client = host.CreateClient();
            foreach (string path in new[] { UiPaths.Prefix, UiPaths.Login, UiPaths.Box(MessageBox.Outbox), $"{UiPaths.Prefix}/assets/ui.css" })
            {
                using var get = await client.GetAsync(path);
                Assert.Equal(HttpStatusCode.MethodNotAllowed, get.StatusCode);
            }

            // A POST goes to the SOAP endpoint, which refuses a form: no login page answers.
            using var post = await client.PostAsync(UiPaths.Login, new StringContent("Username=admin&Password=admin", Encoding.UTF8,
                "application/x-www-form-urlencoded"));
            Assert.Equal(HttpStatusCode.BadRequest, post.StatusCode);
            using var health = await client.GetAsync("/health");
            Assert.Equal(HttpStatusCode.OK, health.StatusCode);
        }
        finally
        {
            await host.DisposeAsync();
            GatewayHost.DeleteRoot(root);
        }
    }

    [Fact]
    public void A_route_under_the_ui_prefix_stops_the_gateway_from_starting()
    {
        string root = GatewayHost.NewRoot();
        var ex = Assert.ThrowsAny<Exception>(() => GatewayHost.Start(BridgeSide.Corp, root,
            new Dictionary<string, string?> { ["Routing:Services:0:Paths:0"] = "/QrBridge-UI/FC2FMSInterface.svc" }));
        Assert.Contains("belongs to the read-only UI", ex.ToString());
        GatewayHost.DeleteRoot(root);
    }
}
