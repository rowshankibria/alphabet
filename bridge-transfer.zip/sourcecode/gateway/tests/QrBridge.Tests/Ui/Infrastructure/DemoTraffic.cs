using System.Net;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Ingress;
using QrBridge.Gateway.Ingress.Soap;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Ui.Infrastructure;

/// <summary>
/// A busy islanding day in about fifteen seconds, to have something real to look at in the read-only UI: a Corp and a
/// DMZ gateway (the real Program), fake real services behind both, the fake light between them, and real calls from
/// both sides' callers. The gateways write every row themselves, so the data is what production would hold:
///   Corp → DMZ   permits, a withdrawal, a query with data, an order the service refuses (RETURN_CODE 1501), a call
///                the service answers with HTTP 500 (Unknown), one it cannot reach (NotDelivered), one lost on the
///                light until it is Failed (and a missing number on the DMZ), feeds (one arriving twice), a legacy
///                RPC call, the Registered Tags report;
///   DMZ → Corp   cards and a work permit, an RFP link the service refuses, a portal sync query, feeds;
///   both sides   Receipts, Replies, Heartbeats.
/// Two arrivals stand in for faults the fake light cannot make: a request that waited past its expiry (Expired), and a
/// message from a sender with another routes.json (Rejected). The hosts keep running until disposed.
/// </summary>
public sealed partial class DemoTraffic : IAsyncDisposable
{
    /// <summary>Set to a folder (e.g. C:\QrBridgeDev) to keep the databases there: {folder}\Corp\Data and {folder}\Dmz\Data.</summary>
    public const string RootVariable = "QRBRIDGE_DEMO_ROOT";

    /// <summary>The one service whose sessions never reach the far side (FakeLight.Copies = 0): Failed after its airs.</summary>
    private const string LostService = "SSO2TLS";

    private const string Fc2FmsPath = "/FMS_FC2FMSInterface/FC2FMSInterface.svc";

    private readonly FakeLight _light;

    private DemoTraffic(GatewayHost corp, GatewayHost dmz)
    {
        Corp = corp;
        Dmz = dmz;
        _light = new FakeLight(side => side == BridgeSide.Corp ? Corp : Dmz, on: true)
        {
            Copies = row => row.Kind == MessageKind.Request && row.ServiceName == LostService ? 0
                : row.Kind == MessageKind.Request && row.ServiceName == "VZ2TLS" && row.Attempts == 1 ? 2 // a duplicate session
                : 1,
        };
    }

    public GatewayHost Corp { get; }
    public GatewayHost Dmz { get; }

    /// <summary>Plays the day into <paramref name="root"/>; an existing qrbridge.db there is moved aside first, never deleted.</summary>
    public static async Task<DemoTraffic> RunAsync(string root)
    {
        SetAside(root, BridgeSide.Corp);
        SetAside(root, BridgeSide.Dmz);

        // Held callers get their real answer within the hold; the DMZ gives up on an unreachable service after 2 tries and
        // reports a missing number at once (no grace).
        var corp = GatewayHost.Start(BridgeSide.Corp, root, new Dictionary<string, string?>
        {
            ["Gateway:Hold:DefaultSeconds"] = "20",
        }, receiverHandler: () => new ScriptedHandler((_, request, ct) => CorpServiceAsync(request, ct)));
        var dmz = GatewayHost.Start(BridgeSide.Dmz, root, new Dictionary<string, string?>
        {
            ["Gateway:Hold:DefaultSeconds"] = "20",
            ["Gateway:MaxAttempts"] = "2",
            ["Gateway:GapGraceMinutes"] = "0",
        }, receiverHandler: () => new ScriptedHandler((_, request, ct) => DmzServiceAsync(request, ct)));

        var demo = new DemoTraffic(corp, dmz);
        try
        {
            await demo.PlayAsync();
            return demo;
        }
        catch
        {
            await demo.DisposeAsync();
            throw;
        }
    }

    private async Task PlayAsync()
    {
        using var rapidRestore = Caller(Corp, "10.20.30.41");
        using var fms = Caller(Dmz, "172.16.8.12");

        var lost = Task.Run(ReairUntilFailedAsync);
        await Task.WhenAll(
            // Corp → DMZ
            Soap(rapidRestore, FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("REQUEST_FOR_PERMIT.txt")),
            Soap(rapidRestore, FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("RETURN_PERMITS.txt")),
            Soap(rapidRestore, FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("LIFT_CAUTION.TXT")),
            Soap(rapidRestore, FmsEndpoint.FC2FMS, "GetFromFMS", SoapCalls.Sample("WITHDRAW_RFP.txt")),
            Soap(rapidRestore, FmsEndpoint.FC2FMS, "GetFromFMS", SoapCalls.Sample("AUTHORIZE_USERS.txt")),
            Soap(rapidRestore, FmsEndpoint.SSO2FMS, "SendToFMS", SoapCalls.Sample("RETURN_ORDER.txt")),
            Soap(rapidRestore, FmsEndpoint.SSO2TOMS, "SendToTOMS", SoapCalls.Sample("VOLTAGE_REDUCTION_REQUEST.txt")),
            Soap(rapidRestore, FmsEndpoint.FOD2FMS, "SendToFMS", SoapCalls.Sample("RETURN_TAGS.txt")),
            Soap(rapidRestore, FmsEndpoint.SSO2TLS, "SendToTLS", SoapCalls.Sample("TLS_RETURN_ORDER.txt")),
            Soap(rapidRestore, FmsEndpoint.FTC2FMS, "SendToFMS", SoapCalls.Sample("FAULT_CORRELATION.txt")),
            Soap(rapidRestore, FmsEndpoint.VZ2TLS, "SendToTLS", SoapCalls.Sample("CreateTicketResponse.txt")),
            Soap(rapidRestore, FmsEndpoint.DSS2FMS, "SendToFMS", SoapCalls.Sample("NO9_MOVE_RESPONSE.txt")),
            Get(rapidRestore, "/FMS_ReportService/RegisteredTags.asmx/GetData"),
            // DMZ → Corp
            Soap(fms, FmsEndpoint.FMS2FC, "CreateCard", FmsMessage("CARD_CREATE", 30117, "FCR",
                "<CARD><FMS_CARD_ID>20241</FMS_CARD_ID><FEEDER>1Q14</FEEDER><NETWORK>Grasslands</NETWORK><CARD_TYPE>OA</CARD_TYPE></CARD>")),
            Soap(fms, FmsEndpoint.FMS2FC, "IssueWorkPermit", FmsMessage("ISSUE_WORK_PERMIT", 30118, "FCR",
                "<WORK_PERMIT><WP_NUMBER>WP-77310</WP_NUMBER><FMS_CARD_ID>20241</FMS_CARD_ID><FEEDER>1Q14</FEEDER><ISSUED_TO>Crew 14</ISSUED_TO></WORK_PERMIT>")),
            Soap(fms, FmsEndpoint.FMS2FC, "LinkRFP", FmsMessage("LINK_RFP", 30119, "FCR",
                "<RFP><RFP_NUMBER>88231</RFP_NUMBER><FMS_CARD_ID>20241</FMS_CARD_ID></RFP>")),
            Soap(fms, FmsEndpoint.FMS2FC, "PortalSyncRequest", FmsMessage("PORTAL_SYNC_REQUEST", 30120, "FCR", "<PORTAL_SYNC_REQUEST />")),
            Soap(fms, FmsEndpoint.FMS2FSS, "fms2fss", FmsMessage("FEEDER_CARD", 30121, "FSS",
                "<FEEDER_CARD><FEEDER>5B33</FEEDER><STATUS>OPEN AUTO</STATUS><FMS_CARD_ID>20242</FMS_CARD_ID></FEEDER_CARD>")),
            Soap(fms, FmsEndpoint.FMS2VR, "VRRequestAck", FmsMessage("VOLTAGE_REDUCTION_REQUEST_ACK", 30122, "VR",
                "<VOLTAGE_REDUCTION><NETWORK>Ridgewood</NETWORK><PERCENT>5</PERCENT><ACK>Y</ACK></VOLTAGE_REDUCTION>")));
        await lost;

        await ExpiredRequestAsync();
        await ForeignCatalogueArrivalAsync();
        await WaitUntilSettledAsync();

        // Heartbeats: FarSideMonitor takes the current time, so "ten minutes from now" makes both sides idle.
        await Corp.Get<FarSideMonitor>().SendHeartbeatIfIdleAsync(DateTime.UtcNow.AddMinutes(10), CancellationToken.None);
        await Dmz.Get<FarSideMonitor>().SendHeartbeatIfIdleAsync(DateTime.UtcNow.AddMinutes(10), CancellationToken.None);
        await WaitUntilSettledAsync();

        await Dmz.Get<SequenceGapMonitor>().CheckAsync(CancellationToken.None); // the lost number shows on the DMZ overview
        await Corp.Get<SequenceGapMonitor>().CheckAsync(CancellationToken.None);
    }

    // =================== The callers ===================

    private static HttpClient Caller(GatewayHost host, string address)
    {
        var client = host.CreateClient();
        client.DefaultRequestHeaders.Add("X-Forwarded-For", address); // the caller's address, as the load balancer forwards it
        return client;
    }

    private static async Task Soap(HttpClient caller, FmsEndpoint endpoint, string operation, string payload)
    {
        var (response, _) = await SoapCalls.PostAsync(caller, endpoint, operation, SoapCalls.Build(endpoint, operation, payload));
        response.Dispose();
    }

    private static async Task Get(HttpClient caller, string path) => (await caller.GetAsync(path)).Dispose();

    /// <summary>An FMS message as the DMZ interface services send it.</summary>
    private static string FmsMessage(string type, int msgId, string target, string data) =>
        $"<MESSAGE TYPE=\"{type}\" MSG_ID=\"{msgId}\" GMT_TIME_SENT=\"{DateTime.UtcNow:MM/dd/yyyy HH:mm:ss}\">" +
        $"<MSG_HEADER><SOURCE_APPLICATION>FMS</SOURCE_APPLICATION><TARGET_APPLICATION>{target}</TARGET_APPLICATION>" +
        $"<SOURCE_SERVER>ECC-FMS-APP1</SOURCE_SERVER></MSG_HEADER><MSG_DATA>{data}</MSG_DATA></MESSAGE>";

    // =================== The faults the fake light cannot make ===================

    /// <summary>
    /// The lost service's session never arrives: the Corp side airs it again when no Receipt came within 2 s (what
    /// MaintenanceWorker does every minute, here every half second), then light Failed after 3 airs; its held caller
    /// then gets 1596 at once.
    /// </summary>
    private async Task ReairUntilFailedAsync()
    {
        var outbox = Corp.Get<OutboxRepository>();
        var deadline = DateTime.UtcNow.AddSeconds(60);
        while (DateTime.UtcNow < deadline)
        {
            await outbox.ReairUnconfirmedAsync(TimeSpan.FromSeconds(2), maxAirAttempts: 3, CancellationToken.None);
            if ((await TwoGatewayBench.OutboxAsync(Corp, MessageKind.Request))
                .Any(m => m.ServiceName == LostService && m.LightStatus == OutboxLightStatus.Failed))
                return;
            await Task.Delay(500);
        }
        throw new TimeoutException($"The {LostService} request never became light Failed.");
    }

    /// <summary>
    /// A feeder ETC update that waits on the light past its expiry (here 2 s instead of Gateway:Expiry's 600 s): the
    /// Corp → DMZ lane is held until then, so the DMZ side does not post it (Expired).
    /// </summary>
    private async Task ExpiredRequestAsync()
    {
        await _light.PauseAsync(BridgeSide.Corp); // not just the flag: an air already under way would take the row before it expires
        byte[] body = SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("FEEDER_ETC_UPDATE.TXT"));
        // The content fingerprint exactly as SenderEndpoint computes it for a caller's call (the route's ignore list).
        var route = Corp.Get<RouteTable>().Resolve(Fc2FmsPath, "SendToFMS", "FEEDER_ETC_UPDATE");
        string? fingerprint = ContentFingerprint.Compute("FC2FMS", "FEEDER_ETC_UPDATE", body, route.FingerprintIgnore, 2_000_000);
        await Corp.Get<OutboxWriter>().EnqueueAsync(new MessageHeader
        {
            ServiceName = "FC2FMS",
            Operation = "SendToFMS",
            BusinessType = "FEEDER_ETC_UPDATE",
            Path = Fc2FmsPath,
            SoapActionHeader = "\"http://tempuri.org/IFC2FMSInterface/SendToFMS\"",
            ContentType = "text/xml; charset=utf-8",
            ContentFingerprint = fingerprint,
            ExpiresUtc = DateTime.UtcNow.AddSeconds(2),
            Priority = MessagePriority.High,
            CallerHost = "10.20.30.42",
        }, body);
        await Task.Delay(TimeSpan.FromSeconds(3));
        _light.CorpToDmzOn = true;
    }

    /// <summary>
    /// A copy of a DMZ feed as a DMZ gateway with an older routes.json would send it: the Corp side Rejects it (decision
    /// D31), and its Reply and Receipt are Rejected on the DMZ side in turn (they answer a message the DMZ never sent).
    /// </summary>
    private async Task ForeignCatalogueArrivalAsync()
    {
        var feed = (await TwoGatewayBench.OutboxAsync(Dmz, MessageKind.Request)).First(m => m.ServiceName == "FMS2FSS");
        var serializer = Dmz.Get<MessageSerializer>();
        var (header, body) = serializer.Deserialize(feed.MessageBytes);
        byte[] bytes = serializer.Serialize(header with
        {
            MessageId = Guid.NewGuid(),
            CatalogFingerprint = Hashing.Sha256Hex("routes.json of an older deployment"u8.ToArray()),
        }, body);
        await Corp.Get<InboxRepository>().AddMessageAsync(MessageSerializer.PeekHeader(bytes), bytes, CancellationToken.None);
        Corp.Get<BridgeSignals>().Inbox.Set();
    }

    /// <summary>Until nothing is waiting to be aired, confirmed, delivered or read on either side.</summary>
    private async Task WaitUntilSettledAsync()
    {
        var deadline = DateTime.UtcNow.AddSeconds(90);
        while (!(await SettledAsync(Corp) && await SettledAsync(Dmz) && await LandedAsync(Corp, Dmz) && await LandedAsync(Dmz, Corp)))
        {
            if (DateTime.UtcNow > deadline) throw new TimeoutException("The demo traffic never settled.");
            await Task.Delay(200);
        }
    }

    /// <summary>
    /// Every Receipt and Heartbeat <paramref name="from"/> aired is in <paramref name="to"/>'s Inbox. Nothing confirms
    /// them, so <see cref="SettledAsync"/> does not wait for them, and the fake light marks a row Aired before it stores
    /// it on the far side: without this, one can land while the pages are being counted.
    /// </summary>
    private static async Task<bool> LandedAsync(GatewayHost from, GatewayHost to)
    {
        await using var sent = await from.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        var aired = await sent.Outbox
            .Where(m => m.LightStatus == OutboxLightStatus.Aired && (m.Kind == MessageKind.Receipt || m.Kind == MessageKind.Heartbeat))
            .Select(m => m.MessageId).ToListAsync();
        if (aired.Count == 0) return true;
        await using var arrived = await to.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        return await arrived.Inbox.CountAsync(m => aired.Contains(m.MessageId)) == aired.Count;
    }

    private static async Task<bool> SettledAsync(GatewayHost host)
    {
        await using var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        bool airing = await db.Outbox.AnyAsync(m =>
            m.LightStatus == OutboxLightStatus.Pending || m.LightStatus == OutboxLightStatus.Sending ||
            (m.LightStatus == OutboxLightStatus.Aired && m.Kind != MessageKind.Receipt && m.Kind != MessageKind.Heartbeat));
        bool working = await db.Inbox.AnyAsync(m => m.ReceiptDueUtc != null ||
            (m.LightStatus == InboxLightStatus.Received &&
             (m.ServiceStatus == InboxServiceStatus.Pending || m.ServiceStatus == InboxServiceStatus.Delivering ||
              m.ServiceStatus == InboxServiceStatus.Retrying)));
        return !airing && !working;
    }

    // =================== The real services ===================

    /// <summary>The services on the DMZ (FMS, the RR servers), by path and message type.</summary>
    private static async Task<HttpResponseMessage> DmzServiceAsync(HttpRequestMessage request, CancellationToken ct)
    {
        string path = request.RequestUri!.AbsolutePath;
        if (request.Method == HttpMethod.Get)
            return Answer(200, """
                <?xml version="1.0" encoding="utf-8"?><DataSet xmlns="http://tempuri.org/"><TAG ID="7" FEEDER="1Q14" STRUCTURE="V-4471" TYPE="RED" ISSUED="11/25/2026 06:40" /><TAG ID="9" FEEDER="5B33" STRUCTURE="M-2210" TYPE="YELLOW" ISSUED="11/25/2026 07:12" /><TAG ID="12" FEEDER="2W61" STRUCTURE="V-0912" TYPE="RED" ISSUED="11/25/2026 08:03" /></DataSet>
                """);
        if (path.StartsWith("/FMS_FOD2FMSInterface/", StringComparison.OrdinalIgnoreCase))
            throw new HttpRequestException(HttpRequestError.ConnectionError,
                "No connection could be made because the target machine actively refused it.");
        if (path.StartsWith("/FMS_SSO2TOMSInterface/", StringComparison.OrdinalIgnoreCase))
            return Answer(500, "<html><body><h1>500 - Internal server error.</h1></body></html>", "text/html");
        if (path.StartsWith("/VZ2TLSWebService/", StringComparison.OrdinalIgnoreCase))
            return Answer(200, Envelope("<SendToTLSResponse xmlns=\"http://tempuri.org/\"><SendToTLSResult>0</SendToTLSResult></SendToTLSResponse>"));
        if (path.StartsWith("/FMSInterface/", StringComparison.OrdinalIgnoreCase)) // legacy SOAP Toolkit, RPC/encoded
            return Answer(200, Envelope("<m:SendToFMSResponse xmlns:m=\"http://tempuri.org/message/\"><Result>0</Result></m:SendToFMSResponse>"));

        var (operation, type) = Read(await request.Content!.ReadAsStringAsync(ct));
        return type switch
        {
            "RETURN_ORDER" => Answer(200, FakeSoapService.FmsReply(operation, 1501, "Order 4711 is not open in FMS: it cannot be returned.")),
            "AUTHORIZE_USERS" => Answer(200, FmsAnswer(operation,
                "<RESPONSE><STATUS><RETURN_CODE>0</RETURN_CODE><ERROR_MESSAGE></ERROR_MESSAGE></STATUS><USERS>" +
                "<USER ID=\"jdoe\" NAME=\"J. Doe\" ROLE=\"DISPATCHER\" AUTHORIZED=\"Y\" />" +
                "<USER ID=\"asmith\" NAME=\"A. Smith\" ROLE=\"FIELD_OPS\" AUTHORIZED=\"Y\" /></USERS></RESPONSE>")),
            _ => Answer(200, FakeSoapService.FmsReply(operation, 0)),
        };
    }

    /// <summary>The corporate services (Rapid Restore, Feeder Status, Voltage Reduction), by path and message type.</summary>
    private static async Task<HttpResponseMessage> CorpServiceAsync(HttpRequestMessage request, CancellationToken ct)
    {
        string path = request.RequestUri!.AbsolutePath;
        if (path.Equals("/feederstatusws/fms2fssinterface.asmx", StringComparison.OrdinalIgnoreCase))
            return Answer(200, Envelope("<fms2fssResponse xmlns=\"http://tempuri.org/\"><fms2fssResult>0</fms2fssResult></fms2fssResponse>"));
        if (path.Equals("/eldisws/fms2vrinterface.asmx", StringComparison.OrdinalIgnoreCase))
            return Answer(200, Envelope("<VRRequestAckResponse xmlns=\"http://tempuri.org/\" />"));

        var (operation, type) = Read(await request.Content!.ReadAsStringAsync(ct));
        return type switch
        {
            "LINK_RFP" => Answer(200, FakeSoapService.FmsReply(operation, 1502, "RFP 88231 is already linked to card 19870.")),
            "PORTAL_SYNC_REQUEST" => Answer(200, FmsAnswer(operation,
                "<RESPONSE><STATUS><RETURN_CODE>0</RETURN_CODE><ERROR_MESSAGE></ERROR_MESSAGE></STATUS>" +
                $"<PORTAL_SYNC_RESPONSE><GMT_TIME_STAMP>{DateTime.UtcNow:MM/dd/yyyy HH:mm:ss}</GMT_TIME_STAMP></PORTAL_SYNC_RESPONSE></RESPONSE>")),
            _ => Answer(200, FakeSoapService.FmsReply(operation, 0)),
        };
    }

    /// <summary>The SOAP operation (first Body element) and the FMS MESSAGE TYPE (escaped inside the parameter).</summary>
    private static (string Operation, string? Type) Read(string soap) =>
        (OperationPattern().Match(soap).Groups[1].Value,
         TypePattern().Match(soap) is { Success: true } type ? type.Groups[1].Value : null);

    [GeneratedRegex(@"<(?:[\w.-]+:)?Body[^>]*>\s*<(?:[\w.-]+:)?([\w.-]+)")]
    private static partial Regex OperationPattern();

    [GeneratedRegex(@"TYPE=(?:""|&quot;)(\w+)")]
    private static partial Regex TypePattern();

    private static string Envelope(string body) =>
        $"<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"><s:Body>{body}</s:Body></s:Envelope>";

    /// <summary>An FMS answer with its own &lt;RESPONSE&gt; document (data, not just a code), as the string result.</summary>
    private static string FmsAnswer(string operation, string response) =>
        Envelope($"<{operation}Response xmlns=\"http://tempuri.org/\"><{operation}Result>{SecurityElement.Escape(response)}</{operation}Result></{operation}Response>");

    private static HttpResponseMessage Answer(int status, string body, string contentType = "text/xml") =>
        new((HttpStatusCode)status) { Content = new StringContent(body, Encoding.UTF8, contentType) };

    /// <summary>An existing qrbridge.db (and its -wal, -shm) goes to a "previous-…" folder beside it: nothing is deleted.</summary>
    private static void SetAside(string root, BridgeSide side)
    {
        string folder = Path.Combine(root, side.ToString(), "Data");
        string database = Path.Combine(folder, BridgeOptions.DatabaseFileName);
        if (!File.Exists(database)) return;

        string aside = Path.Combine(folder, $"previous-{DateTime.Now:yyyyMMdd-HHmmss}");
        Directory.CreateDirectory(aside);
        try
        {
            foreach (string file in new[] { database, database + "-wal", database + "-shm" }.Where(File.Exists))
                File.Move(file, Path.Combine(aside, Path.GetFileName(file)));
        }
        catch (IOException ex)
        {
            throw new InvalidOperationException($"Stop the gateway that uses {folder} first: {ex.Message}", ex);
        }
    }

    public async ValueTask DisposeAsync()
    {
        await _light.DisposeAsync();
        await Corp.DisposeAsync();
        await Dmz.DisposeAsync();
    }
}
