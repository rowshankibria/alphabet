using System.Net;
using System.Text.RegularExpressions;
using QrBridge.Tests.Gateway.Infrastructure;
using QrBridge.Gateway;

namespace QrBridge.Tests.Ui.Infrastructure;

/// <summary>
/// A browser for the read-only UI of one in-memory gateway: keeps its cookies (login, antiforgery) and signs in through
/// the login form with the token the page carries, as a person would.
/// </summary>
public sealed partial class UiBrowser(GatewayHost host) : IDisposable
{
    public HttpClient Client { get; } = host.CreateClient();

    /// <summary>Posts the login form; the answer is a redirect when the login was accepted.</summary>
    public async Task<HttpResponseMessage> SignInAsync(string username = "admin", string password = "admin", string? returnUrl = null)
    {
        string page = await Client.GetStringAsync(UiPaths.Login);
        var form = new Dictionary<string, string>
        {
            ["Username"] = username,
            ["Password"] = password,
            ["__RequestVerificationToken"] = Token(page),
        };
        if (returnUrl is not null) form["ReturnUrl"] = returnUrl;
        return await Client.PostAsync(UiPaths.Login, new FormUrlEncodedContent(form));
    }

    /// <summary>Signs in with admin / admin; fails the test when that does not work.</summary>
    public async Task<UiBrowser> SignedInAsync()
    {
        using var response = await SignInAsync();
        Assert.Equal(HttpStatusCode.Redirect, response.StatusCode);
        return this;
    }

    /// <summary>The HTML of a page that must answer 200.</summary>
    public async Task<string> PageAsync(string path)
    {
        using var response = await Client.GetAsync(path);
        Assert.True(response.StatusCode == HttpStatusCode.OK, $"GET {path} answered {(int)response.StatusCode}");
        return await response.Content.ReadAsStringAsync();
    }

    /// <summary>What a person reads: the HTML with its character references decoded (Razor encodes every value).</summary>
    public static string Text(string html) => WebUtility.HtmlDecode(html);

    /// <summary>The antiforgery token of the first form on a page.</summary>
    public static string Token(string html) =>
        TokenPattern().Match(html) is { Success: true } match
            ? match.Groups[1].Value
            : throw new Xunit.Sdk.XunitException("The page has no antiforgery token.");

    [GeneratedRegex("name=\"__RequestVerificationToken\"[^>]*value=\"([^\"]+)\"")]
    private static partial Regex TokenPattern();

    public void Dispose() => Client.Dispose();
}
