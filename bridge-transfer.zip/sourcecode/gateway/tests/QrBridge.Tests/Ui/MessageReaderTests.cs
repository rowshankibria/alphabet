using System.Text;
using Microsoft.Extensions.Options;
using QrBridge.Shared;
using QrBridge.Shared.Serialization;
using QrBridge.Tests.Gateway.Infrastructure;
using QrBridge.Gateway.Ui.Reading;

namespace QrBridge.Tests.Ui;

/// <summary>
/// The UI's reading of a stored message: header fields, the body as text, indented, and the FMS message inside the
/// first SOAP parameter. Untrusted XML goes through SafeXml (a DTD is never expanded); damaged bytes say so.
/// </summary>
public sealed class MessageReaderTests
{
    private static readonly MessageSerializer Serializer = new();

    private static MessageReader Reader() => new(Serializer, Options.Create(new BridgeOptions()));

    private static MessageHeader Header() => new()
    {
        MessageId = Guid.NewGuid(),
        Direction = Direction.CorpToDmz,
        ServiceName = "FC2FMS",
        Operation = "SendToFMS",
        BusinessType = "REQUEST_FOR_PERMIT",
        Path = "/FMS_FC2FMSInterface/FC2FMSInterface.svc",
        SoapActionHeader = "\"http://tempuri.org/IFC2FMSInterface/SendToFMS\"",
        ContentType = "text/xml; charset=utf-8",
        Sequence = 7,
        Priority = MessagePriority.High,
    };

    [Fact]
    public void A_stored_request_reads_as_its_header_its_envelope_and_its_fms_message()
    {
        byte[] body = SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("REQUEST_FOR_PERMIT.txt"));

        var message = Reader().Read(Serializer.Serialize(Header(), body));

        Assert.Null(message.Problem);
        Assert.Equal("/FMS_FC2FMSInterface/FC2FMSInterface.svc", message.Header!.Path);
        var content = message.Body!;
        Assert.Equal(Encoding.UTF8.GetString(body), content.Text); // exactly as stored
        Assert.Equal("sXML", content.ParameterName);
        Assert.StartsWith("<MESSAGE TYPE=\"REQUEST_FOR_PERMIT\"", content.Payload);
        Assert.Contains("\n  <", content.Payload);                   // indented
        Assert.Contains("<sXML", content.Indented);
        Assert.Equal(content.Payload, content.Best);
    }

    [Fact]
    public void A_row_cleared_after_delivery_reads_as_nothing()
    {
        var message = Reader().Read([]);

        Assert.Null(message.Header);
        Assert.Null(message.Body);
        Assert.Null(message.Problem);
    }

    [Fact]
    public void Damaged_bytes_say_so_and_still_show_the_header()
    {
        byte[] bytes = Serializer.Serialize(Header(), "<x/>"u8);
        bytes[^1] ^= 0xFF;

        var message = Reader().Read(bytes);

        Assert.Contains("cannot be unpacked", message.Problem);
        Assert.Equal("FC2FMS", message.Header!.ServiceName);
        Assert.Null(message.Body);
    }

    [Fact]
    public void A_dtd_is_never_expanded()
    {
        var content = Reader().ReadContent(Encoding.UTF8.GetBytes("<!DOCTYPE x [<!ENTITY e \"expanded\">]><x>&e;</x>"));

        Assert.Null(content.Indented);
        Assert.Null(content.Payload);
        Assert.StartsWith("Not shown as XML", content.Note);
        Assert.Contains("&e;", content.Text);
        Assert.DoesNotContain("<x>expanded</x>", content.Best);
    }

    [Fact]
    public void Json_plain_text_and_plain_parameter_values_are_shown_as_they_are()
    {
        var reader = Reader();

        Assert.Contains("\"answer\": 42", reader.ReadContent("{\"answer\":42}"u8.ToArray()).Indented);
        Assert.Equal("not xml", reader.ReadContent("not xml"u8.ToArray()).Best);
        var echo = reader.ReadContent(SoapCalls.Build(FmsEndpoint.FC2FMS, "EchoString", "ping", "sValue"));
        Assert.Equal("sValue", echo.ParameterName);
        Assert.Equal("ping", echo.Payload);
    }
}
