using System.Net;
using System.Text;
using System.Xml.Linq;
using QrBridge.Gateway;
using QrBridge.Gateway.Exceptions;
using QrBridge.Gateway.Ingress;
using QrBridge.Gateway.Initializer;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// The Corp gateway, receiving exactly what the corporate apps send today. Every message template of the
/// fms-interface-simulator goes to its real interface, and must get the answer that caller expects.
/// </summary>
public sealed class SenderTests(CorpGatewayFixture fixture, Xunit.Abstractions.ITestOutputHelper output) : IClassFixture<CorpGatewayFixture>
{
    public enum Expect { Accepted, HeldUnavailable, HeldPending, Refused, Fault, Echo }

    /// <param name="Numeric">The operation returns a number (ASMX long / SOAP Toolkit int), not an FMS &lt;RESPONSE&gt;.</param>
    public sealed record Case(FmsEndpoint Endpoint, string Operation, Expect Expect, bool Numeric = false, string? Parameter = null);

    private static readonly Dictionary<string, Case> Cases = new(StringComparer.OrdinalIgnoreCase)
    {
        // D60: permits, orders, cards and their responses are RoundTrip: queued and held; with no far side here the hold
        // (1 s in tests) runs out and the caller gets 1596. FTC FAULT_CORRELATION and Verizon stay Bridge (0 at once).
        // FCR -> FMS
        ["REQUEST_FOR_PERMIT.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.HeldPending),
        ["RFP_FCR_RESPONSE.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.HeldPending),
        ["WP_FCR_RESPONSE.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.HeldPending),
        ["RETURN_PERMITS.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.HeldPending),
        ["FIELD_GROUNDS_ONLY.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.HeldPending),
        ["FGO_FCR_RESPONSE.txt"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.HeldPending),
        ["LIFT_CAUTION.TXT"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.HeldPending),
        ["FAULT_RESPONSE.TXT"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.HeldPending),
        ["WP_ETC_UPDATE.TXT"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.HeldPending),
        ["FEEDER_ETC_UPDATE.TXT"] = new(FmsEndpoint.FC2FMS, "SendToFMS", Expect.HeldPending),
        // GetFromFMS is RoundTrip (D13, D14): queued and held; with no far side here the hold (1 s in tests) runs out
        ["AUTHORIZE_USERS.txt"] = new(FmsEndpoint.FC2FMS, "GetFromFMS", Expect.HeldUnavailable),
        ["GET_FEEDER_INFO.txt"] = new(FmsEndpoint.FC2FMS, "GetFromFMS", Expect.HeldUnavailable),
        ["WITHDRAW_RFP.txt"] = new(FmsEndpoint.FC2FMS, "GetFromFMS", Expect.HeldPending),
        ["Echo_String.txt"] = new(FmsEndpoint.FC2FMS, "EchoString", Expect.Echo, Parameter: "sValue"),
        // FOD -> FMS
        ["FOD_MOVE_RESPONSE.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.HeldPending),
        ["RETURN_MOVE.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.HeldPending),
        ["RETURN_FAULT.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.HeldPending),
        ["FOD_FAULT_RESPONSE.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.HeldPending),
        ["RETURN_TAGS.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.HeldPending),
        ["FOD_TAG_RESPONSE.txt"] = new(FmsEndpoint.FOD2FMS, "SendToFMS", Expect.HeldPending),
        // DSS / No. 9 -> FMS (legacy SOAP Toolkit, RPC/encoded, int reply)
        ["NO9_MOVE_RESPONSE.txt"] = new(FmsEndpoint.DSS2FMS, "SendToFMS", Expect.HeldPending, Numeric: true),
        // SSO -> FMS / TOMS / TLS / DSO
        ["SSO_RESPONSE.txt"] = new(FmsEndpoint.SSO2FMS, "SendToFMS", Expect.HeldPending),
        ["RETURN_ORDER.txt"] = new(FmsEndpoint.SSO2FMS, "SendToFMS", Expect.HeldPending),
        ["TOMS_SSO_RESPONSE.txt"] = new(FmsEndpoint.SSO2TOMS, "SendToTOMS", Expect.HeldPending),
        ["TOMS_RETURN_ORDER.txt"] = new(FmsEndpoint.SSO2TOMS, "SendToTOMS", Expect.HeldPending),
        ["VOLTAGE_REDUCTION_REQUEST.txt"] = new(FmsEndpoint.SSO2TOMS, "SendToTOMS", Expect.HeldPending),
        ["TLS_SSO_RESPONSE.txt"] = new(FmsEndpoint.SSO2TLS, "SendToTLS", Expect.HeldPending),
        ["TLS_RETURN_ORDER.txt"] = new(FmsEndpoint.SSO2TLS, "SendToTLS", Expect.HeldPending),
        ["DSO_SSO_RESPONSE.txt"] = new(FmsEndpoint.SSO2DSO, "SendToDSO", Expect.HeldPending),
        ["DSO_RETURN_ORDER.txt"] = new(FmsEndpoint.SSO2DSO, "SendToDSO", Expect.HeldPending),
        // FTC -> FMS
        ["FAULT_CORRELATION.txt"] = new(FmsEndpoint.FTC2FMS, "SendToFMS", Expect.Accepted),
        ["GET_RELAY_TARGET.txt"] = new(FmsEndpoint.FTC2FMS, "GetFromFMS", Expect.HeldUnavailable),
        // Verizon -> TLS (ASMX, long reply). The real handler accepts only the two eBonding SOAP replies.
        ["CreateTicketResponse.txt"] = new(FmsEndpoint.VZ2TLS, "SendToTLS", Expect.Accepted, Numeric: true),
        ["GetTicketResponse.txt"] = new(FmsEndpoint.VZ2TLS, "SendToTLS", Expect.Accepted, Numeric: true),
        ["CancelTroubleReportResponse.txt"] = new(FmsEndpoint.VZ2TLS, "SendToTLS", Expect.Refused, Numeric: true),
        ["RequestTroubleReportCreationResponse.txt"] = new(FmsEndpoint.VZ2TLS, "SendToTLS", Expect.Refused, Numeric: true),
        ["RetrieveAttributesByTroubleReportIdResponse.txt"] = new(FmsEndpoint.VZ2TLS, "SendToTLS", Expect.Refused, Numeric: true),
        // XA/21 and BFC: the polls stay "not available" (D15); so do the round-trip types until D23 says whether they
        // cross at all (D52): a SOAP fault, nothing queued
        ["DISPLAY_POLL.txt"] = new(FmsEndpoint.XA2FMS, "ProcessMessage", Expect.Fault),
        ["DISPLAY_ERROR.txt"] = new(FmsEndpoint.XA2FMS, "ProcessMessage", Expect.Fault),
        ["DEVICE_STATUS_CHANGE.txt"] = new(FmsEndpoint.XA2FMS, "ProcessMessage", Expect.Fault),
        ["BUS_FAULT_OUTAGE_REQUEST.txt"] = new(FmsEndpoint.IR2BFC, "ProcessMessage", Expect.Fault),
        ["BUS_FAULT_CORRELATION_REQUEST.txt"] = new(FmsEndpoint.IR2BFC, "ProcessMessage", Expect.Fault),
    };

    /// <summary>Plain HTTP GET interface (Registered Tags): no request body, see RegisteredTagsTests.</summary>
    private static readonly string[] NotSoap = ["REGISTERED_TAG_REQUEST.txt"];

    [Fact]
    public void Every_simulator_message_fits_its_routes_size_limit()
    {
        // Step 16 (G-10, D78): the request sizes per route, measured on the simulator's templates, and the limits set from
        // them (MaxRequestBytes = 10 × the largest template). Printed so the tracker can quote them.
        var routes = Host.Get<RouteTable>();
        int global = Host.Get<Microsoft.Extensions.Options.IOptions<BridgeOptions>>().Value.MaxPayloadBytes;
        foreach (var group in Cases.GroupBy(c => routes.FindByPath(c.Value.Endpoint.Path)!.Name).OrderBy(g => g.Key))
        {
            var service = routes.FindByName(group.Key)!;
            int limit = service.MaxRequestBytes ?? global;
            var sizes = group.Select(c => (File: c.Key, Bytes: SoapCalls.Build(c.Value.Endpoint, c.Value.Operation,
                                                                                SoapCalls.Sample(c.Key), c.Value.Parameter).Length)).ToList();
            var largest = sizes.MaxBy(s => s.Bytes);
            output.WriteLine($"{group.Key}: {sizes.Count} templates, largest {largest.Bytes} bytes ({largest.File}), limit {limit}");
            Assert.All(sizes, s => Assert.True(s.Bytes <= limit, $"{s.File} ({s.Bytes} bytes) is over {group.Key}'s limit of {limit}"));
        }
    }

    public static TheoryData<string> SampleFiles()
    {
        var data = new TheoryData<string>();
        foreach (string file in Cases.Keys) data.Add(file);
        return data;
    }

    private GatewayHost Host => fixture.Host;
    private HttpClient Client => fixture.Client;

    [Fact]
    public void Every_simulator_template_is_covered()
    {
        var files = Directory.GetFiles(Path.Combine(AppContext.BaseDirectory, "Samples")).Select(Path.GetFileName).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var covered = Cases.Keys.Concat(NotSoap).ToHashSet(StringComparer.OrdinalIgnoreCase);
        Assert.Equal(43, files.Count);
        Assert.True(files.SetEquals(covered), "Uncovered: " + string.Join(", ", files.Except(covered)));
    }

    [Theory]
    [MemberData(nameof(SampleFiles))]
    public async Task Every_simulator_message_gets_the_answer_its_caller_expects(string file)
    {
        var c = Cases[file];
        string payload = SoapCalls.Sample(file);
        byte[] request = SoapCalls.Build(c.Endpoint, c.Operation, payload, c.Parameter);

        var (response, reply) = await SoapCalls.PostAsync(Client, c.Endpoint, c.Operation, request);

        if (c.Expect == Expect.Fault)
        {
            Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);
            Assert.True(SoapCalls.IsFault(reply));
            Assert.False(response.Headers.Contains(SenderEndpoint.MessageIdHeader)); // nothing queued
            return;
        }

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        string? result = SoapCalls.Result(reply);

        if (c.Expect == Expect.Echo)
        {
            Assert.Equal(payload.TrimEnd(), result!.TrimEnd());
            return;
        }

        int code = c.Numeric ? int.Parse(result!) : SoapCalls.ReturnCode(result);
        switch (c.Expect)
        {
            case Expect.Accepted:
                Assert.Equal(0, code);
                await AssertStoredVerbatimAsync(response, request, c);
                break;
            case Expect.HeldUnavailable: // a query: "not available" when its hold runs out (D13)
                Assert.Equal(1599, code);
                Assert.True(response.Headers.Contains(SenderEndpoint.MessageIdHeader)); // queued: it may still cross
                break;
            case Expect.HeldPending: // state-changing: "sent, confirmation not yet received" (D8)
                Assert.Equal(1596, code);
                await AssertStoredVerbatimAsync(response, request, c);
                break;
            case Expect.Refused:
                Assert.Equal(1597, code);
                Assert.False(response.Headers.Contains(SenderEndpoint.MessageIdHeader));
                break;
        }
    }

    private async Task AssertStoredVerbatimAsync(HttpResponseMessage response, byte[] request, Case c)
    {
        var messageId = Guid.Parse(response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());
        var row = await Host.Get<OutboxRepository>().FindAsync(messageId, CancellationToken.None);
        Assert.NotNull(row);
        Assert.Equal(PayloadFormat.RawSoap, row!.PayloadFormat);

        // The stored bytes open back to the caller's exact request and the details needed to replay it.
        var (header, body) = Host.Get<MessageSerializer>().Deserialize(row.MessageBytes);
        Assert.Equal(request, body);
        Assert.Equal(c.Endpoint.Path, header.Path, ignoreCase: true);
        Assert.Equal($"\"{c.Endpoint.ActionPrefix}{c.Operation}\"", header.SoapActionHeader);
        Assert.Equal(c.Operation, header.Operation);
        Assert.Equal(Direction.CorpToDmz, header.Direction);
        Assert.Equal(row.BusinessType, string.IsNullOrEmpty(header.BusinessType) ? null : header.BusinessType);
        Assert.NotNull(row.BusinessType);
    }

    [Fact]
    public async Task The_fms_reply_echoes_the_message_type_and_id()
    {
        var (_, reply) = await SoapCalls.PostAsync(Client, FmsEndpoint.FC2FMS, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("REQUEST_FOR_PERMIT.txt")));
        var response = XDocument.Parse(SoapCalls.Result(reply)!).Root!;
        Assert.Equal("REQUEST_FOR_PERMIT", response.Attribute("MSG_TYPE")!.Value);
        Assert.Equal("679", response.Attribute("MSG_ID")!.Value);
    }

    [Fact]
    public async Task The_same_message_sent_twice_is_queued_twice()
    {
        // MSG_ID is a static template value ("456") in the callers: it is a label, never an identity. A Bridge route
        // (FTC fault correlation, a feed, D60) queues every call; RoundTrip routes recognise retries by content (D56).
        byte[] request = SoapCalls.Build(FmsEndpoint.FTC2FMS, "SendToFMS", SoapCalls.Sample("FAULT_CORRELATION.txt"));
        var (first, _) = await SoapCalls.PostAsync(Client, FmsEndpoint.FTC2FMS, "SendToFMS", request);
        var (second, _) = await SoapCalls.PostAsync(Client, FmsEndpoint.FTC2FMS, "SendToFMS", request);
        Assert.NotEqual(first.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single(),
                        second.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());
    }

    [Fact]
    public async Task A_message_type_the_interface_does_not_take_is_refused_like_fms_would()
    {
        // RETURN_ORDER belongs to SSO2FMS, not FC2FMS
        var (response, reply) = await SoapCalls.PostAsync(Client, FmsEndpoint.FC2FMS, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("RETURN_ORDER.txt")));
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal(1597, SoapCalls.ReturnCode(SoapCalls.Result(reply)));
    }

    [Fact]
    public async Task A_malformed_payload_is_refused()
    {
        var (_, reply) = await SoapCalls.PostAsync(Client, FmsEndpoint.FC2FMS, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", "<MESSAGE TYPE=\"REQUEST_FOR_PERMIT\"><MSG_DATA></MESSAGE>"));
        Assert.Equal(1597, SoapCalls.ReturnCode(SoapCalls.Result(reply)));
    }

    public static TheoryData<string> WsdlMismatches() => ["wrong parameter", "wrong namespace", "extra element", "rpc wrong part", "soap 1.2", "wrong soapaction"];

    [Theory]
    [MemberData(nameof(WsdlMismatches))]
    public async Task A_request_that_does_not_match_the_wsdl_is_refused_and_not_queued(string mismatch)
    {
        string permit = SoapCalls.Sample("REQUEST_FOR_PERMIT.txt");
        var (endpoint, body) = mismatch switch
        {
            "wrong parameter" => (FmsEndpoint.FC2FMS, SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", permit, parameter: "XMLMsg")),
            "wrong namespace" => (FmsEndpoint.FC2FMS,
                SoapCalls.Build(FmsEndpoint.FC2FMS with { Namespace = "http://example.org/" }, "SendToFMS", permit)),
            "extra element" => (FmsEndpoint.FC2FMS, Encoding.UTF8.GetBytes(
                "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"><s:Body><SendToFMS xmlns=\"http://tempuri.org/\">" +
                $"<sXML>{System.Security.SecurityElement.Escape(permit)}</sXML><Extra>1</Extra></SendToFMS></s:Body></s:Envelope>")),
            "rpc wrong part" => (FmsEndpoint.SSO2FMSLegacy,
                SoapCalls.Build(FmsEndpoint.SSO2FMSLegacy, "SendToFMS", SoapCalls.Sample("RETURN_ORDER.txt"), parameter: "sXML")),
            // G-11: a valid FC2FMS body, but SSO2FMS's SOAPAction (the real WCF service would not dispatch it)
            "wrong soapaction" => (FmsEndpoint.FC2FMS with { ActionPrefix = "http://tempuri.org/ISSO2FMSInterface/" },
                SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", permit)),
            _ => (FmsEndpoint.FC2FMS, Encoding.UTF8.GetBytes( // WCF basicHttpBinding takes SOAP 1.1 only
                "<s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\"><s:Body><SendToFMS xmlns=\"http://tempuri.org/\">" +
                $"<sXML>{System.Security.SecurityElement.Escape(permit)}</sXML></SendToFMS></s:Body></s:Envelope>")),
        };

        var (response, reply) = await SoapCalls.PostAsync(Client, endpoint, "SendToFMS", body);

        Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);
        Assert.Contains("WSDL", Encoding.UTF8.GetString(reply));
        Assert.False(response.Headers.Contains(SenderEndpoint.MessageIdHeader));
    }

    [Fact]
    public async Task A_request_without_a_soapaction_header_is_still_bridged()
    {
        // The check compares the action only when the caller sends one: a missing header is not a mismatch.
        using var request = new HttpRequestMessage(HttpMethod.Post, FmsEndpoint.FC2FMS.Path)
        {
            Content = new ByteArrayContent(SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("REQUEST_FOR_PERMIT.txt"))),
        };
        request.Content.Headers.ContentType = System.Net.Http.Headers.MediaTypeHeaderValue.Parse("text/xml; charset=utf-8");

        var response = await Client.SendAsync(request);

        Assert.Equal(1596, SoapCalls.ReturnCode(SoapCalls.Result(await response.Content.ReadAsByteArrayAsync()))); // accepted and held (D60)
        Assert.True(response.Headers.Contains(SenderEndpoint.MessageIdHeader));
    }

    [Fact]
    public void A_route_whose_operations_are_not_in_its_wsdl_stops_the_gateway_from_starting()
    {
        string root = GatewayHost.NewRoot();
        // Services:0 is FC2FMS (SendToFMS, GetFromFMS); the SSO2DSO WSDL has SendToDSO only.
        var ex = Assert.ThrowsAny<Exception>(() => GatewayHost.Start(BridgeSide.Corp, root,
            new Dictionary<string, string?> { ["Routing:Services:0:Contract"] = "SSO2DSO" }));
        Assert.Contains("FC2FMS.SendToFMS is not an operation of contract 'Inbound/SSO2DSO'", ex.ToString());
        GatewayHost.DeleteRoot(root);
    }

    [Fact]
    public async Task Legacy_soap_toolkit_endpoint_is_bridged_with_an_int_reply()
    {
        var (response, reply) = await SoapCalls.PostAsync(Client, FmsEndpoint.SSO2FMSLegacy, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.SSO2FMSLegacy, "SendToFMS", SoapCalls.Sample("RETURN_ORDER.txt")));
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        // RPC shape: <m:SendToFMSResponse xmlns:m="http://tempuri.org/message/"><Result>1596</Result> (held, D60: the
        // ReturnCode profile's Pending value; no far side here)
        var wrapper = XDocument.Parse(Encoding.UTF8.GetString(reply)).Root!.Element(SoapCalls.Soap11 + "Body")!.Elements().Single();
        Assert.Equal(XName.Get("SendToFMSResponse", "http://tempuri.org/message/"), wrapper.Name);
        Assert.Equal("1596", wrapper.Element("Result")!.Value);
        Assert.True(response.Headers.Contains(SenderEndpoint.MessageIdHeader));
    }

    [Fact]
    public async Task Unknown_service_and_unknown_operation_are_refused_with_a_fault()
    {
        var unknownService = FmsEndpoint.FC2FMS with { Path = "/Somewhere/Else.svc" };
        var (r1, b1) = await SoapCalls.PostAsync(Client, unknownService, "SendToFMS",
            SoapCalls.Build(unknownService, "SendToFMS", SoapCalls.Sample("REQUEST_FOR_PERMIT.txt")));
        Assert.Equal(HttpStatusCode.InternalServerError, r1.StatusCode);
        Assert.True(SoapCalls.IsFault(b1));

        var (r2, b2) = await SoapCalls.PostAsync(Client, FmsEndpoint.FC2FMS, "DeleteEverything",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "DeleteEverything", "x"));
        Assert.Equal(HttpStatusCode.InternalServerError, r2.StatusCode);
        Assert.True(SoapCalls.IsFault(b2));
    }

    [Fact]
    public async Task Requests_that_are_not_soap_or_too_large_are_refused()
    {
        var notSoap = await Client.PostAsync(FmsEndpoint.FC2FMS.Path, new StringContent("hello", Encoding.UTF8, "text/xml"));
        Assert.Equal(HttpStatusCode.BadRequest, notSoap.StatusCode);

        var huge = await Client.PostAsync(FmsEndpoint.FC2FMS.Path, new ByteArrayContent(new byte[1_000_001]));
        Assert.Equal(HttpStatusCode.RequestEntityTooLarge, huge.StatusCode);
    }

    [Fact]
    public async Task Only_health_answers_get_requests()
    {
        string health = await Client.GetStringAsync("/health");
        Assert.Contains("\"side\":\"Corp\"", health);
        // D24: light and service problems are counted separately.
        Assert.Contains("\"lightProblems\":0", health);
        Assert.Contains("\"serviceProblems\":0", health);

        // No WSDL, help pages or other GET-only interfaces: the simulator's clients never fetch them. Registered Tags is
        // the one GET that answers (D18, RegisteredTagsTests).
        foreach (string path in new[] { FmsEndpoint.SSO2FMS.Path, FmsEndpoint.FC2FMS.Path + "?wsdl", FmsEndpoint.DSS2FMS.Path,
                                        "/FMS_ReportService/Other.asmx/GetData", "/" })
        {
            var response = await Client.GetAsync(path);
            Assert.Equal(HttpStatusCode.MethodNotAllowed, response.StatusCode);
        }
    }

    [Fact]
    public async Task A_call_over_its_routes_size_limit_is_refused_before_anything_else()
    {
        // D78: SSO2TLS allows 12,720 bytes (10 × its largest template); FC2FMS more. The same body is too large only for SSO2TLS.
        byte[] body = new byte[13_000];
        using var tooLarge = await Client.PostAsync(FmsEndpoint.SSO2TLS.Path, new ByteArrayContent(body));
        using var notSoap = await Client.PostAsync(FmsEndpoint.FC2FMS.Path, new ByteArrayContent(body));

        Assert.Equal(HttpStatusCode.RequestEntityTooLarge, tooLarge.StatusCode);
        Assert.Contains("12720 bytes", await tooLarge.Content.ReadAsStringAsync());
        Assert.Equal(HttpStatusCode.BadRequest, notSoap.StatusCode); // within FC2FMS's limit, refused only as not SOAP
    }

    [Fact]
    public async Task A_route_with_its_own_backlog_limit_refuses_only_its_own_calls()
    {
        // D78: one flooded service cannot fill the Outbox. Services:6 is FTC2FMS (a Bridge feed: answered 0 at once).
        string root = GatewayHost.NewRoot();
        try
        {
            await using var host = GatewayHost.Start(BridgeSide.Corp, root, new Dictionary<string, string?> { ["Routing:Services:6:MaxBacklog"] = "1" });
            using var client = host.CreateClient();
            byte[] feed = SoapCalls.Build(FmsEndpoint.FTC2FMS, "SendToFMS", SoapCalls.Sample("FAULT_CORRELATION.txt"));

            var (_, first) = await SoapCalls.PostAsync(client, FmsEndpoint.FTC2FMS, "SendToFMS", feed);
            var (_, second) = await SoapCalls.PostAsync(client, FmsEndpoint.FTC2FMS, "SendToFMS", feed);
            var (other, _) = await SoapCalls.PostAsync(client, FmsEndpoint.VZ2TLS, "SendToTLS",
                SoapCalls.Build(FmsEndpoint.VZ2TLS, "SendToTLS", SoapCalls.Sample("CreateTicketResponse.txt")));

            Assert.Equal(0, SoapCalls.ReturnCode(SoapCalls.Result(first)));
            Assert.Equal(1598, SoapCalls.ReturnCode(SoapCalls.Result(second))); // the route's Busy answer: NOT accepted
            Assert.True(other.Headers.Contains(SenderEndpoint.MessageIdHeader)); // another service is still queued
        }
        finally
        {
            GatewayHost.DeleteRoot(root);
        }
    }

    [Fact]
    public void A_round_trip_route_whose_size_limit_takes_longer_to_air_than_its_hold_is_warned_about()
    {
        // D79: 1 MB (no MaxRequestBytes, e.g. the legacy FC2FMS endpoint) takes about 151 s at 6,700 bytes/s: longer
        // than a 90 s hold. FC2FMS itself is limited to 38,440 bytes, about 7.5 s on air.
        var routes = Host.Get<RouteTable>();
        var bridge = new BridgeOptions { Side = BridgeSide.Corp, MaxPayloadBytes = 1_000_000 };
        var warnings = StartupChecks.AirTimeWarnings(routes, bridge, new GatewayOptions { Hold = { DefaultSeconds = 90 } }).ToList();

        Assert.Contains(warnings, w => w.StartsWith("FC2FMS-Legacy:") && w.Contains("151 s") && w.Contains("90 s hold"));
        Assert.DoesNotContain(warnings, w => w.StartsWith("FC2FMS:"));
        Assert.DoesNotContain(warnings, w => w.StartsWith("VZ2TLS:")); // a Bridge feed: no caller is held
        Assert.Empty(StartupChecks.AirTimeWarnings(routes, bridge, new GatewayOptions { Hold = { DefaultSeconds = 270 } }));
    }

    [Fact]
    public void A_gateway_running_as_an_administrator_is_warned_about_but_still_starts()
    {
        // D4 (step 18, G-06): it should run as its own app pool identity; a warning, never a refusal.
        string? warning = StartupChecks.AdministratorWarning(elevated: true, account: "CORP\\svc-admin");
        Assert.NotNull(warning);
        Assert.Contains("CORP\\svc-admin", warning);
        Assert.Contains("app pool identity", warning);
        Assert.Contains("technical-guide.md §12.4", warning);
        Assert.Null(StartupChecks.AdministratorWarning(elevated: false, account: "IIS APPPOOL\\QrBridge"));
    }

    [Fact]
    public async Task A_full_backlog_refuses_new_calls_instead_of_queueing_them()
    {
        string root = GatewayHost.NewRoot();
        await using (var host = GatewayHost.Start(BridgeSide.Corp, root, new Dictionary<string, string?> { ["Gateway:MaxBacklog"] = "1" }))
        {
            var client = host.CreateClient();
            // A Bridge feed (D60): a RoundTrip route would attach the identical second call to the first instead.
            byte[] request = SoapCalls.Build(FmsEndpoint.FTC2FMS, "SendToFMS", SoapCalls.Sample("FAULT_CORRELATION.txt"));

            var (_, first) = await SoapCalls.PostAsync(client, FmsEndpoint.FTC2FMS, "SendToFMS", request);
            var (secondResponse, second) = await SoapCalls.PostAsync(client, FmsEndpoint.FTC2FMS, "SendToFMS", request);

            Assert.Equal(0, SoapCalls.ReturnCode(SoapCalls.Result(first)));
            Assert.Equal(1598, SoapCalls.ReturnCode(SoapCalls.Result(second)));
            Assert.False(secondResponse.Headers.Contains(SenderEndpoint.MessageIdHeader));
        }
        GatewayHost.DeleteRoot(root);
    }

    [Fact]
    public async Task Concurrent_calls_never_queue_more_than_the_backlog_limit()
    {
        // G-13: the backlog is counted inside the insert transaction, so simultaneous calls cannot all see room.
        const int limit = 3;
        string root = GatewayHost.NewRoot();
        await using (var host = GatewayHost.Start(BridgeSide.Corp, root,
                         new Dictionary<string, string?> { ["Gateway:MaxBacklog"] = limit.ToString() }))
        {
            var writer = host.Get<OutboxWriter>();
            var header = new MessageHeader
            {
                ServiceName = "SSO2FMS", Operation = "SendToFMS", BusinessType = "RETURN_ORDER",
                Path = FmsEndpoint.SSO2FMS.Path, ContentType = "text/xml; charset=utf-8",
            };

            var outcomes = await Task.WhenAll(Enumerable.Range(0, 30).Select(_ => Task.Run(async () =>
            {
                try { await writer.EnqueueAsync(header, "<s:Envelope/>"u8.ToArray()); return true; }
                catch (BridgeBacklogFullException) { return false; }
            })));

            var counts = await host.Get<OutboxRepository>().GetCountsAsync(CancellationToken.None);
            Assert.Equal(limit, outcomes.Count(accepted => accepted));
            Assert.Equal(limit, counts.Light[OutboxLightStatus.Pending] + counts.Light[OutboxLightStatus.Sending]);
        }
        GatewayHost.DeleteRoot(root);
    }

    [Fact]
    public async Task The_outbox_row_copies_the_round_trip_header_fields()
    {
        string root = GatewayHost.NewRoot();
        await using (var host = GatewayHost.Start(BridgeSide.Corp, root))
        {
            var expires = DateTime.UtcNow.AddMinutes(10);
            var header = new MessageHeader
            {
                ServiceName = "SSO2FMS", Operation = "SendToFMS", BusinessType = "RETURN_ORDER",
                Path = FmsEndpoint.SSO2FMS.Path, ContentType = "text/xml; charset=utf-8",
                ContentFingerprint = new string('b', 64), ExpiresUtc = expires,
            };

            Guid id = (await host.Get<OutboxWriter>().EnqueueAsync(header, "<s:Envelope/>"u8.ToArray())).MessageId;

            var row = await host.Get<OutboxRepository>().FindAsync(id, CancellationToken.None);
            Assert.Equal(MessageKind.Request, row!.Kind);
            Assert.Null(row.CorrelationId);
            Assert.Equal(new string('b', 64), row.ContentFingerprint);
            Assert.Equal(expires, row.ExpiresUtc);
            Assert.Equal(OutboxServiceStatus.Waiting, row.ServiceStatus);
            Assert.Null(row.ReplyBody);
        }
        GatewayHost.DeleteRoot(root);
    }

    [Theory]
    [InlineData("Gateway:GapGraceMinutes", "-1", "Gateway:GapGraceMinutes")]
    [InlineData("Gateway:ReplayWindowDays", "0", "Gateway:ReplayWindowDays")]
    [InlineData("Gateway:ReplayWindowDays", "-1", "Gateway:ReplayWindowDays")]
    [InlineData("Gateway:MaxClockSkewMinutes", "0", "Gateway:MaxClockSkewMinutes")]
    [InlineData("Gateway:RetryWindowMinutes", "0", "Gateway:RetryWindowMinutes")]
    [InlineData("Gateway:ReceiptTimeoutSeconds", "0", "Gateway:ReceiptTimeoutSeconds")] // step 11: re-air at once, forever
    [InlineData("Gateway:MaxAirAttempts", "0", "Gateway:MaxAirAttempts")]
    [InlineData("Gateway:Light:BytesPerSecond", "0", "Gateway:Light")] // step 16: the air-time warning needs a speed
    [InlineData("Gateway:HeartbeatMinutes", "-1", "Gateway:HeartbeatMinutes")] // step 17 (D81): 0 = off, never negative
    [InlineData("Gateway:FarSideSilentMinutes", "0", "Gateway:FarSideSilentMinutes")]
    [InlineData("Gateway:FarSideSilentMinutes", "5", "Gateway:FarSideSilentMinutes")] // D82: not longer than the 5-minute heartbeat
    public void Inconsistent_replay_settings_stop_the_gateway_from_starting(string key, string value, string named)
    {
        string root = GatewayHost.NewRoot();
        var ex = Assert.ThrowsAny<Exception>(() => GatewayHost.Start(BridgeSide.Corp, root,
            new Dictionary<string, string?> { [key] = value }));
        Assert.Contains(named, ex.ToString());
        GatewayHost.DeleteRoot(root);
    }

    // Step 7: a hold that cannot work, or one set for a service with no callers on this side, is a typo: fail the start.
    [Theory]
    [InlineData("Gateway:Hold:DefaultSeconds", "0", "Gateway:Hold:DefaultSeconds")]
    [InlineData("Gateway:Hold:Services:FC2FMS", "-5", "Gateway:Hold:Services:FC2FMS")]
    [InlineData("Gateway:Hold:Services:NoSuchService", "60", "NoSuchService")]
    [InlineData("Gateway:Hold:Services:FMS2FC", "60", "FMS2FC")] // a DMZ -> Corp service: its callers are not here
    // D62: a state-changing call must not expire before its caller's hold is over
    [InlineData("Gateway:Expiry:DefaultSeconds", "0", "Gateway:Expiry:DefaultSeconds")]
    [InlineData("Gateway:Expiry:DefaultSeconds", "1", "Gateway:Expiry")] // the test host holds 1 s: not longer
    [InlineData("Gateway:Expiry:Services:FC2FMS", "1", "Gateway:Expiry:Services:FC2FMS")]
    [InlineData("Gateway:Expiry:Services:NoSuchService", "600", "NoSuchService")]
    [InlineData("Gateway:Expiry:Services:FMS2FC", "600", "FMS2FC")]
    public void Invalid_hold_settings_stop_the_gateway_from_starting(string key, string value, string named)
    {
        string root = GatewayHost.NewRoot();
        var ex = Assert.ThrowsAny<Exception>(() => GatewayHost.Start(BridgeSide.Corp, root,
            new Dictionary<string, string?> { [key] = value }));
        Assert.Contains(named, ex.ToString());
        GatewayHost.DeleteRoot(root);
    }

    // Step 7: round-trip settings that could not give the caller its agreed answer fail the start.
    [Theory]
    [InlineData("Routing:ReplyProfiles:FmsResponse:Pending", "", "Pending")] // RoundTrip routes must be able to answer 1596
    [InlineData("Routing:Services:0:Operations:GetFromFMS:OneWay", "true", "OneWay")] // nothing to hold a one-way call for
    [InlineData("Routing:Services:0:Operations:GetFromFMS:Types:AUTHORIZE_USERS:Mode", "Echo", "AUTHORIZE_USERS")]
    [InlineData("Routing:Services:0:Operations:SendToFMS:Types:NOT_A_PERMIT_TYPE:Mode", "Bridge", "NOT_A_PERMIT_TYPE")] // not in AllowedTypes
    public void Invalid_round_trip_routes_stop_the_gateway_from_starting(string key, string value, string named)
    {
        string root = GatewayHost.NewRoot();
        var ex = Assert.ThrowsAny<Exception>(() => GatewayHost.Start(BridgeSide.Corp, root,
            new Dictionary<string, string?> { [key] = value }));
        Assert.Contains("Invalid route catalogue", ex.ToString());
        Assert.Contains(named, ex.ToString());
        GatewayHost.DeleteRoot(root);
    }

    // D42: "never connected" (safe to re-post) can only be told from "sent, no answer" when the connect timeout ends first.
    [Theory]
    [InlineData("0", null)]
    [InlineData("10", null)] // equal to the delivery timeout (10 s in the test host)
    [InlineData("5", "4")]   // longer than one service's own delivery timeout
    public void A_connect_timeout_not_shorter_than_the_delivery_timeout_stops_the_gateway_from_starting(string connect, string? targetTimeout)
    {
        string root = GatewayHost.NewRoot();
        var settings = new Dictionary<string, string?> { ["Gateway:Receiver:ConnectTimeoutSeconds"] = connect };
        if (targetTimeout is not null)
        {
            settings["Gateway:Receiver:Targets:FC2FMS:Url"] = "http://other-rr-server/FMS_FC2FMSInterface/FC2FMSInterface.svc";
            settings["Gateway:Receiver:Targets:FC2FMS:TimeoutSeconds"] = targetTimeout;
        }
        var ex = Assert.ThrowsAny<Exception>(() => GatewayHost.Start(BridgeSide.Dmz, root, settings));
        Assert.Contains("Gateway:Receiver:ConnectTimeoutSeconds", ex.ToString());
        GatewayHost.DeleteRoot(root);
    }

    // A former send.db or received.db may hold accepted but undelivered messages; starting empty beside it would drop them.
    [Fact]
    public void A_former_database_in_the_data_folder_stops_the_gateway_from_starting()
    {
        string root = GatewayHost.NewRoot();
        string data = Path.Combine(root, nameof(BridgeSide.Corp), "Data");
        Directory.CreateDirectory(data);
        File.WriteAllBytes(Path.Combine(data, "send.db"), [1]);

        var ex = Assert.ThrowsAny<Exception>(() => GatewayHost.Start(BridgeSide.Corp, root));
        Assert.Contains("send.db", ex.ToString());
        Assert.False(File.Exists(Path.Combine(data, BridgeOptions.DatabaseFileName)));
        GatewayHost.DeleteRoot(root);
    }

    // G-09: requests (permits, orders) must not leave the gateway in clear text, unless a test bench says so.
    [Theory]
    [InlineData("Gateway:Receiver:DefaultBaseUrl", "http://dmz-rr-server")]
    [InlineData("Gateway:Receiver:Targets:FC2FMS:Url", "http://other-rr-server/FMS_FC2FMSInterface/FC2FMSInterface.svc")]
    [InlineData("Gateway:Receiver:DefaultBaseUrl", "dmz-rr-server")] // not an absolute URL
    public void A_receiver_url_without_https_stops_the_gateway_from_starting(string key, string url)
    {
        string root = GatewayHost.NewRoot();
        var ex = Assert.ThrowsAny<Exception>(() => GatewayHost.Start(BridgeSide.Dmz, root, new Dictionary<string, string?>
        {
            ["Gateway:Receiver:AllowHttp"] = "false",
            ["Gateway:Receiver:DefaultBaseUrl"] = "https://dmz-rr-server",
            [key] = url,
        }));
        Assert.Contains(url, ex.ToString());
        GatewayHost.DeleteRoot(root);
    }

    [Theory]
    [InlineData("Dmz", "https://dmz-rr-server", "false")]  // the production setting
    [InlineData("Dmz", "http://test-bench", "true")]       // a test bench that opts in
    [InlineData("Development", "http://localhost:5080", "false")]
    public async Task Https_receiver_urls_or_an_explicit_opt_in_let_the_gateway_start(string environment, string url, string allowHttp)
    {
        string root = GatewayHost.NewRoot();
        await using (var host = GatewayHost.Start(BridgeSide.Dmz, root, new Dictionary<string, string?>
                     {
                         ["Gateway:Receiver:AllowHttp"] = allowHttp,
                         ["Gateway:Receiver:DefaultBaseUrl"] = url,
                     }, environment: environment))
        {
            Assert.Contains("\"side\":\"Dmz\"", await host.CreateClient().GetStringAsync("/health"));
        }
        GatewayHost.DeleteRoot(root);
    }
}
