using System.Net;
using System.Text;
using System.Xml.Linq;
using QrBridge.Gateway.Ingress;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// The DMZ gateway, receiving what the DMZ interface services send to the corporate systems (DMZ -> Corp, the
/// "Outbound" direction of the fms-interface-simulator docs). Each call must match the corporate service's WSDL
/// (Contracts/Outbound/) and carry a MESSAGE TYPE the DMZ caller really sends with that operation.
/// </summary>
public sealed class DmzSenderTests(DmzGatewayFixture fixture) : IClassFixture<DmzGatewayFixture>
{
    public enum Expect { ReturnCode0, Pending1596, StringZero, Empty, Unavailable, PortalSyncDown, Fault, WsdlFault, Refused1597, RefusedString1597 }

    /// <param name="Held">A RoundTrip call: queued and held; with no far side here it gets its hold-timeout answer (1 s in tests).</param>
    public sealed record Case(FmsEndpoint Endpoint, string Operation, string Type, Expect Expect, string? Parameter = null, bool Held = false);

    private static readonly Dictionary<string, Case> Cases = new()
    {
        ["FCR CreateCard"] = new(FmsEndpoint.FMS2FC, "CreateCard", "CARD_CREATE", Expect.Pending1596, Held: true), // D60
        ["FCR PortalSyncRequest"] = new(FmsEndpoint.FMS2FC, "PortalSyncRequest", "PORTAL_SYNC_REQUEST", Expect.PortalSyncDown, Held: true),
        ["FSS fms2fss"] = new(FmsEndpoint.FMS2FSS, "fms2fss", "FEEDER_CARD", Expect.StringZero),
        ["VR VRRequestAck"] = new(FmsEndpoint.FMS2VR, "VRRequestAck", "VOLTAGE_REDUCTION_REQUEST_ACK", Expect.Empty),
        ["FTC GetFaultCorrelation"] = new(FmsEndpoint.FMS2FTC, "GetFaultCorrelation", "GET_FAULT_CORRELATION", Expect.Fault, Held: true),
        ["FCR wrong parameter"] = new(FmsEndpoint.FMS2FC, "CreateCard", "CARD_CREATE", Expect.WsdlFault, Parameter: "XMLMsg"),
        ["FSS wrong parameter"] = new(FmsEndpoint.FMS2FSS, "fms2fss", "FEEDER_CARD", Expect.WsdlFault, Parameter: "sXML"),
        ["FCR type of another operation"] = new(FmsEndpoint.FMS2FC, "CreateCard", "ISSUE_WORK_PERMIT", Expect.Refused1597),
        ["FSS type of the HV operation"] = new(FmsEndpoint.FMS2FSS, "fms2fss", "HIGH_VOLTAGE", Expect.RefusedString1597),
    };

    public static TheoryData<string> CaseNames()
    {
        var data = new TheoryData<string>();
        foreach (string name in Cases.Keys) data.Add(name);
        return data;
    }

    [Theory]
    [MemberData(nameof(CaseNames))]
    public async Task Dmz_callers_get_the_answer_they_expect_and_only_valid_calls_are_queued(string name)
    {
        var c = Cases[name];
        string payload = $"<MESSAGE TYPE=\"{c.Type}\" MSG_ID=\"1\"><MSG_HEADER /><MSG_DATA /></MESSAGE>";
        var (response, reply) = await SoapCalls.PostAsync(fixture.Client, c.Endpoint, c.Operation,
            SoapCalls.Build(c.Endpoint, c.Operation, payload, c.Parameter));
        bool queued = response.Headers.Contains(SenderEndpoint.MessageIdHeader);

        switch (c.Expect)
        {
            case Expect.ReturnCode0: // caller reads /RESPONSE/STATUS/RETURN_CODE
                Assert.Equal(0, SoapCalls.ReturnCode(SoapCalls.Result(reply)));
                break;
            case Expect.Pending1596: // held, no far side here: "sent, confirmation not yet received" (D8)
                Assert.Equal(1596, SoapCalls.ReturnCode(SoapCalls.Result(reply)));
                break;
            case Expect.StringZero: // caller treats only "0" as success
                Assert.Equal("0", SoapCalls.Result(reply));
                break;
            case Expect.Empty: // void operation: empty <OpResponse/>
                Assert.Equal(HttpStatusCode.OK, response.StatusCode);
                Assert.Null(SoapCalls.Result(reply));
                break;
            case Expect.Unavailable: // the caller needs data from the reply
                Assert.Equal(1599, SoapCalls.ReturnCode(SoapCalls.Result(reply)));
                break;
            case Expect.PortalSyncDown: // D19/D34: the portal monitor reads an empty time stamp and stops until its next cycle
                var portal = XElement.Parse(SoapCalls.Result(reply)!);
                Assert.Equal(1599, SoapCalls.ReturnCode(portal.ToString()));
                Assert.Equal("", portal.Element("PORTAL_SYNC_RESPONSE")!.Element("GMT_TIME_STAMP")!.Value);
                break;
            case Expect.Fault:
                Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);
                break;
            case Expect.WsdlFault:
                Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);
                Assert.Contains("WSDL", Encoding.UTF8.GetString(reply));
                break;
            case Expect.Refused1597:
                Assert.Equal(1597, SoapCalls.ReturnCode(SoapCalls.Result(reply)));
                break;
            case Expect.RefusedString1597:
                Assert.Equal("1597", SoapCalls.Result(reply));
                break;
        }
        Assert.Equal(c.Held || c.Expect is Expect.ReturnCode0 or Expect.StringZero or Expect.Empty, queued);
    }
}
