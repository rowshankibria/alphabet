using System.Diagnostics;
using System.Text;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Tests.Gateway.Infrastructure;
using static QrBridge.Tests.Gateway.Infrastructure.TwoGatewayBench;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Step 13 (G-01, G-03): end-to-end faults around the caller, with two real gateways and the QR link in both
/// directions (<see cref="FakeLight"/>): retries, late answers, hang-ups, expiry, an unknown outcome, identical calls at
/// once and a gateway restart. The real service is never called twice for the same business action, and a caller is
/// never told "done" without the real service's answer.
/// </summary>
public sealed class CallerFaultTests
{
    private static readonly byte[] RealAnswerBytes = Encoding.UTF8.GetBytes(RealAnswer);

    private static Dictionary<string, string?> Hold(int seconds) => new() { ["Gateway:Hold:DefaultSeconds"] = seconds.ToString() };

    private static TwoGatewayBench Start(Dictionary<string, string?> corp, bool lightOn = true, int realStatus = 200) =>
        TwoGatewayBench.Start((_, _) => Answer(realStatus, realStatus == 200 ? RealAnswer : "<html>Bad Gateway</html>"), corp, lightOn: lightOn);

    private static async Task<OutboxMessage> TheRequestAsync(TwoGatewayBench bench) =>
        Assert.Single(await OutboxAsync(bench.Corp, MessageKind.Request));

    [Fact]
    public async Task A_retry_after_1596_waits_for_and_gets_the_real_answer_without_a_second_message()
    {
        await using var bench = Start(Hold(8), lightOn: false);
        Assert.Equal(1596, Code((await bench.CallAsync(WithdrawRfp(attempt: 0))).Body)); // nothing crossed in time

        var retry = bench.CallAsync(WithdrawRfp(attempt: 1)); // new MSG_ID and GMT_TIME_SENT, same content
        bench.Light.On = true;

        Assert.Equal(RealAnswerBytes, (await retry).Body);
        await TheRequestAsync(bench); // attached: still one message
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task A_reply_that_comes_back_after_the_hold_is_kept_for_the_next_retry()
    {
        await using var bench = Start(Hold(2));
        bench.Light.DmzToCorpOn = false; // the answer is late

        Assert.Equal(1596, Code((await bench.CallAsync(WithdrawRfp(attempt: 0))).Body));
        var request = await TheRequestAsync(bench);
        await WaitForInboxAsync(bench.Dmz, request.MessageId, r => r.ServiceStatus == InboxServiceStatus.Done);
        bench.Light.DmzToCorpOn = true;
        await WaitForOutboxAsync(bench.Corp, request.MessageId, r => r.ServiceStatus == OutboxServiceStatus.Answered);

        var clock = Stopwatch.StartNew();
        Assert.Equal(RealAnswerBytes, (await bench.CallAsync(WithdrawRfp(attempt: 1))).Body);
        Assert.True(clock.Elapsed < TimeSpan.FromSeconds(1.5), $"the stored answer took {clock.Elapsed}");
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task A_caller_that_hangs_up_leaves_its_message_to_be_delivered_once_and_its_retry_gets_the_answer()
    {
        await using var bench = Start(Hold(30), lightOn: false);
        using var hangUp = new CancellationTokenSource(TimeSpan.FromSeconds(1));

        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => bench.CallAsync(WithdrawRfp(attempt: 0), hangUp.Token));
        var request = await TheRequestAsync(bench);
        bench.Light.On = true;
        await WaitForOutboxAsync(bench.Corp, request.MessageId, r => r.ServiceStatus == OutboxServiceStatus.Answered);

        Assert.Equal(RealAnswerBytes, (await bench.CallAsync(WithdrawRfp(attempt: 1))).Body);
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task A_message_that_expires_on_the_light_is_not_posted_and_its_retry_is_sent_as_a_new_message()
    {
        var settings = Hold(1);
        settings["Gateway:Expiry:DefaultSeconds"] = "2";
        await using var bench = Start(settings, lightOn: false);

        Assert.Equal(1596, Code((await bench.CallAsync(WithdrawRfp(attempt: 0))).Body));
        var expired = await TheRequestAsync(bench);
        await Task.Delay(TimeSpan.FromSeconds(2)); // the light was down past the expiry (D62)
        bench.Light.On = true;
        await WaitForOutboxAsync(bench.Corp, expired.MessageId, r => r.ServiceStatus == OutboxServiceStatus.Expired);
        Assert.Equal(0, bench.Network.Calls);

        await bench.CallAsync(WithdrawRfp(attempt: 1)); // D63: surely not done, so a new message
        var rows = await OutboxAsync(bench.Corp, MessageKind.Request);
        Assert.Equal(2, rows.Count);
        await WaitForOutboxAsync(bench.Corp, rows[1].MessageId, r => r.ServiceStatus == OutboxServiceStatus.Answered);
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task An_unknown_outcome_is_never_posted_again_and_every_retry_gets_1596()
    {
        await using var bench = Start(Hold(30), realStatus: 502); // the load balancer lost the answer: may have been processed

        Assert.Equal(1596, Code((await bench.CallAsync(WithdrawRfp(attempt: 0))).Body));
        var request = await WaitForOutboxAsync(bench.Corp, (await TheRequestAsync(bench)).MessageId,
            r => r.ServiceStatus == OutboxServiceStatus.Unknown);
        Assert.Equal(502, request.ServiceHttpStatus);

        Assert.Equal(1596, Code((await bench.CallAsync(WithdrawRfp(attempt: 1))).Body)); // attached, answered at once
        await Task.Delay(TimeSpan.FromSeconds(2));
        await TheRequestAsync(bench);
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task Two_identical_calls_at_once_make_one_message_and_both_get_the_real_answer()
    {
        await using var bench = Start(Hold(30));

        var answers = await Task.WhenAll(bench.CallAsync(WithdrawRfp(attempt: 0)), bench.CallAsync(WithdrawRfp(attempt: 1)));

        Assert.All(answers, a => Assert.Equal(RealAnswerBytes, a.Body));
        await TheRequestAsync(bench);
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task A_gateway_restart_during_a_hold_loses_only_the_held_connection()
    {
        await using var bench = Start(Hold(30), lightOn: false);
        var held = bench.CallAsync(WithdrawRfp(attempt: 0));
        await WaitUntilAsync(() => OutboxAsync(bench.Corp, MessageKind.Request).Result.Count == 1);

        await bench.RestartCorpAsync().WaitAsync(TimeSpan.FromSeconds(60)); // app pool recycle
        var lost = await Record.ExceptionAsync(() => held.WaitAsync(TimeSpan.FromSeconds(60)));
        Assert.True(lost is not null || Code(held.Result.Body) != 0, "a held call must never be answered as done by a dying gateway");

        bench.Light.On = true;
        var request = await TheRequestAsync(bench); // the committed message survived the restart
        await WaitForOutboxAsync(bench.Corp, request.MessageId, r => r.ServiceStatus == OutboxServiceStatus.Answered);
        Assert.Equal(RealAnswerBytes, (await bench.CallAsync(WithdrawRfp(attempt: 1))).Body);
        Assert.Equal(1, bench.Network.Calls);
    }
}
