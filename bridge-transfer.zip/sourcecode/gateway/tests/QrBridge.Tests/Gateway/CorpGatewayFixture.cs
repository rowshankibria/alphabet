using QrBridge.Shared;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

public sealed class CorpGatewayFixture : IAsyncLifetime
{
    private readonly string _root = GatewayHost.NewRoot();
    public GatewayHost Host { get; private set; } = null!;
    public HttpClient Client { get; private set; } = null!;

    public Task InitializeAsync()
    {
        Host = GatewayHost.Start(BridgeSide.Corp, _root);
        Client = Host.CreateClient();
        return Task.CompletedTask;
    }

    public async Task DisposeAsync()
    {
        Client.Dispose();
        await Host.DisposeAsync();
        GatewayHost.DeleteRoot(_root);
    }
}
