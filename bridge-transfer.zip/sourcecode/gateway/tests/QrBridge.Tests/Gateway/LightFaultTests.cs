using System.Text;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Tests.Gateway.Infrastructure;
using static QrBridge.Tests.Gateway.Infrastructure.TwoGatewayBench;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Step 13 (G-01, G-02, G-03): end-to-end faults on the light itself, with two real gateways and the QR link running
/// in both directions (<see cref="FakeLight"/>): sessions lost or duplicated. Whatever happens on the light, the real
/// service is called once and the held caller gets the real answer, or the honest 1596.
/// </summary>
public sealed class LightFaultTests
{
    private static readonly byte[] RealAnswerBytes = Encoding.UTF8.GetBytes(RealAnswer);

    // The maintenance run re-airs a row with no Receipt 1 s after it aired (step 11); it runs at start and every 10 s.
    private static Dictionary<string, string?> Settings(int holdSeconds = 30, bool reAir = false)
    {
        var settings = new Dictionary<string, string?> { ["Gateway:Hold:DefaultSeconds"] = holdSeconds.ToString() };
        if (reAir)
        {
            settings["Gateway:ReceiptTimeoutSeconds"] = "1";
            settings["Gateway:MaintenanceIntervalSeconds"] = "10";
        }
        return settings;
    }

    private static TwoGatewayBench Start(Dictionary<string, string?>? corp = null, Dictionary<string, string?>? dmz = null) =>
        TwoGatewayBench.Start((_, _) => Answer(200, RealAnswer), corp ?? Settings(), dmz);

    private static async Task<OutboxMessage> TheRequestAsync(TwoGatewayBench bench) =>
        Assert.Single(await OutboxAsync(bench.Corp, MessageKind.Request));

    [Fact]
    public async Task Happy_path_the_caller_gets_the_real_answer_and_both_lanes_confirm_what_they_carried()
    {
        await using var bench = Start();

        var (status, body) = await bench.CallAsync(WithdrawRfp());

        Assert.Equal(200, status);
        Assert.Equal(RealAnswerBytes, body);
        var request = await WaitForOutboxAsync(bench.Corp, (await TheRequestAsync(bench)).MessageId,
            r => r.LightStatus == OutboxLightStatus.Received);
        Assert.Equal(OutboxServiceStatus.Answered, request.ServiceStatus);
        var reply = Assert.Single(await OutboxAsync(bench.Dmz, MessageKind.Reply));
        await WaitForOutboxAsync(bench.Dmz, reply.MessageId, r => r.LightStatus == OutboxLightStatus.Received); // the Reply got its Receipt
        Assert.Equal(1, bench.Light.AirsOf(BridgeSide.Corp, MessageKind.Request));
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task A_lost_request_is_aired_again_and_the_held_caller_still_gets_the_real_answer()
    {
        await using var bench = Start(Settings(reAir: true));
        bench.Light.Copies = r => r.Kind == MessageKind.Request && r.Attempts == 1 ? 0 : 1; // the first session is lost

        var (status, body) = await bench.CallAsync(WithdrawRfp());

        Assert.Equal(200, status);
        Assert.Equal(RealAnswerBytes, body);
        Assert.Equal(2, bench.Light.AirsOf(BridgeSide.Corp, MessageKind.Request));
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task A_lost_reply_is_aired_again_by_the_far_side_and_still_reaches_the_held_caller()
    {
        await using var bench = Start(dmz: Settings(reAir: true));
        bench.Light.Copies = r => r.Kind == MessageKind.Reply && r.Attempts == 1 ? 0 : 1;

        var (status, body) = await bench.CallAsync(WithdrawRfp());

        Assert.Equal(200, status);
        Assert.Equal(RealAnswerBytes, body);
        Assert.Equal(2, bench.Light.AirsOf(BridgeSide.Dmz, MessageKind.Reply));
        Assert.Equal(1, bench.Network.Calls); // the Reply is aired again, the request is never posted again
    }

    [Fact]
    public async Task A_lost_receipt_makes_the_message_air_again_but_never_post_again()
    {
        // The first Receipt and the Reply are both lost (the Reply would also confirm it); the far side does not re-air.
        int lost = 0;
        await using var bench = Start(Settings(holdSeconds: 1, reAir: true));
        bench.Light.Copies = r => r.Direction == Direction.DmzToCorp && Interlocked.Increment(ref lost) <= 2 ? 0 : 1;

        var (_, body) = await bench.CallAsync(WithdrawRfp());
        Assert.Equal(1596, Code(body)); // no answer within the hold
        var request = await TheRequestAsync(bench);
        await WaitUntilAsync(() => Volatile.Read(ref lost) >= 2);

        var confirmed = await WaitForOutboxAsync(bench.Corp, request.MessageId, r => r.LightStatus == OutboxLightStatus.Received);
        Assert.Equal(2, confirmed.Attempts);
        Assert.Equal(2, bench.Light.AirsOf(BridgeSide.Corp, MessageKind.Request));
        Assert.Equal(2, bench.Light.AirsOf(BridgeSide.Dmz, MessageKind.Receipt, request.MessageId)); // one per arrival (D44)
        Assert.Equal(1, bench.Network.Calls);
    }

    [Fact]
    public async Task A_duplicate_session_is_stored_once_and_posted_once()
    {
        await using var bench = Start();
        bench.Light.Copies = r => r.Kind == MessageKind.Request ? 2 : 1;

        var (status, body) = await bench.CallAsync(WithdrawRfp());

        Assert.Equal(200, status);
        Assert.Equal(RealAnswerBytes, body);
        Assert.Single(await OutboxAsync(bench.Dmz, MessageKind.Reply));
        Assert.Equal(1, bench.Network.Calls);
    }
}
