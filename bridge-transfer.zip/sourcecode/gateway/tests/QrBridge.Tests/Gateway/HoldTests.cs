using System.Diagnostics;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using Microsoft.EntityFrameworkCore;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Step 10a: a RoundTrip caller is held until the far side's Reply comes back over the opposite lane, and gets the real
/// answer, or the route's hold-timeout answer (fix plan §4.1, §4.5; decisions D49–D56). The light is simulated by
/// copying the message bytes between the two gateways, as the QR apps will.
/// FC2FMS.GetFromFMS: WITHDRAW_RFP is state-changing (1596 on timeout, retries attached), AUTHORIZE_USERS a read-only
/// query (1599 on timeout, expires with the hold, never attached).
/// </summary>
public sealed class HoldTests
{
    private const string RealAnswerContentType = "text/xml; charset=utf-8";

    private sealed class Bench(string root, GatewayHost corp, GatewayHost dmz, ScriptedHandler network) : IAsyncDisposable
    {
        public GatewayHost Corp { get; } = corp;
        public GatewayHost Dmz { get; } = dmz;
        public ScriptedHandler Network { get; } = network;

        public async ValueTask DisposeAsync()
        {
            await Corp.DisposeAsync();
            await Dmz.DisposeAsync();
            GatewayHost.DeleteRoot(root);
        }
    }

    private static Bench Start(int holdSeconds, Func<int, Task<HttpResponseMessage>>? realService = null)
    {
        string root = GatewayHost.NewRoot();
        var network = new ScriptedHandler((call, _, _) => (realService ?? (_ => Answer(200, FakeSoapService.FmsReply("GetFromFMS", 0))))(call));
        var corp = GatewayHost.Start(BridgeSide.Corp, root,
            new Dictionary<string, string?> { ["Gateway:Hold:DefaultSeconds"] = holdSeconds.ToString() });
        var dmz = GatewayHost.Start(BridgeSide.Dmz, root, receiverHandler: () => network);
        return new Bench(root, corp, dmz, network);
    }

    private static Task<HttpResponseMessage> Answer(int status, string body) =>
        Task.FromResult(new HttpResponseMessage((HttpStatusCode)status) { Content = new StringContent(body, Encoding.UTF8, "text/xml") });

    /// <summary>One caller attempt: the per-send fields differ between attempts, the business content does not.</summary>
    private static byte[] Call(string sample, int attempt = 0)
    {
        string payload = SoapCalls.Sample(sample);
        payload = Regex.Replace(payload, "MSG_ID=\"[^\"]*\"", $"MSG_ID=\"{456 + attempt}\"");
        payload = Regex.Replace(payload, "GMT_TIME_SENT=\"[^\"]*\"", $"GMT_TIME_SENT=\"02/16/2004 14:0{attempt}:10\"");
        return SoapCalls.Build(FmsEndpoint.FC2FMS, "GetFromFMS", payload);
    }

    private static Task<(HttpResponseMessage Response, byte[] Body)> PostAsync(GatewayHost corp, byte[] request, CancellationToken ct = default) =>
        SoapCalls.PostAsync(corp.CreateClient(), FmsEndpoint.FC2FMS, "GetFromFMS", request, ct);

    private static int Code(byte[] reply) => SoapCalls.ReturnCode(SoapCalls.Result(reply));

    private static async Task<List<OutboxMessage>> RequestsAsync(GatewayHost host)
    {
        await using var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        return await db.Outbox.AsNoTracking().Where(m => m.Kind == MessageKind.Request).OrderBy(m => m.Sequence).ToListAsync();
    }

    private static async Task<OutboxMessage> WaitForRequestAsync(GatewayHost corp, int count = 1)
    {
        var deadline = DateTime.UtcNow.AddSeconds(10);
        while (true)
        {
            var rows = await RequestsAsync(corp);
            if (rows.Count >= count) return rows[count - 1];
            if (DateTime.UtcNow > deadline) throw new TimeoutException($"The held call was never queued ({rows.Count} Request rows).");
            await Task.Delay(50);
        }
    }

    private static async Task<OutboxMessage> WaitForOutboxAsync(GatewayHost host, Func<OutboxMessage, bool> condition)
    {
        var deadline = DateTime.UtcNow.AddSeconds(20);
        while (true)
        {
            await using (var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync())
            {
                var rows = await db.Outbox.AsNoTracking().ToListAsync();
                if (rows.FirstOrDefault(condition) is { } row) return row;
            }
            if (DateTime.UtcNow > deadline) throw new TimeoutException("No Outbox row reached the expected state.");
            await Task.Delay(100);
        }
    }

    private static async Task<InboxMessage> WaitForInboxAsync(GatewayHost host, Guid messageId, Func<InboxMessage, bool> condition)
    {
        var deadline = DateTime.UtcNow.AddSeconds(20);
        while (true)
        {
            var row = await host.Get<InboxRepository>().FindAsync(messageId, CancellationToken.None);
            if (row is not null && condition(row)) return row;
            if (DateTime.UtcNow > deadline)
                throw new TimeoutException($"Inbox row never reached the expected state (last: {row?.LightStatus}/{row?.ServiceStatus}).");
            await Task.Delay(100);
        }
    }

    /// <summary>The fake light: one message from one gateway's Outbox into the other's Inbox, optionally altered on the way.</summary>
    private static async Task CarryAsync(GatewayHost from, GatewayHost to, Guid messageId, Func<MessageHeader, MessageHeader>? alter = null)
    {
        var row = await from.Get<OutboxRepository>().FindAsync(messageId, CancellationToken.None);
        byte[] bytes = row!.MessageBytes;
        var header = MessageSerializer.PeekHeader(bytes);
        if (alter is not null)
        {
            var serializer = from.Get<MessageSerializer>();
            var (original, body) = serializer.Deserialize(bytes);
            header = alter(original);
            bytes = serializer.Serialize(header, body);
        }
        await to.Get<InboxRepository>().AddMessageAsync(header, bytes, CancellationToken.None);
        to.Get<BridgeSignals>().Inbox.Set();
    }

    /// <summary>The far side's Reply for <paramref name="request"/>, written by the DMZ gateway and carried to Corp.</summary>
    private static async Task ReplyAsync(Bench bench, OutboxMessage request, ServiceOutcome outcome, int? httpStatus, byte[]? answer,
                                         Func<MessageHeader, MessageHeader>? alter = null, Guid? correlationId = null)
    {
        var reply = await bench.Dmz.Get<OutboxWriter>().EnqueueAsync(new MessageHeader
        {
            Kind = MessageKind.Reply,
            CorrelationId = correlationId ?? request.MessageId,
            ServiceName = request.ServiceName,
            Operation = request.Operation,
            BusinessType = request.BusinessType ?? "",
            Path = "",
            ContentType = answer is null ? "" : RealAnswerContentType,
            Outcome = outcome,
            ServiceHttpStatus = httpStatus,
            ServiceComment = $"test: {outcome}",
        }, answer ?? []);
        await CarryAsync(bench.Dmz, bench.Corp, reply.MessageId, alter);
    }

    // ---------------------------------------------------------------- the answer comes back in time

    [Fact]
    public async Task A_held_call_gets_the_real_answer_byte_for_byte_when_it_comes_back_in_time()
    {
        string realAnswer = FakeSoapService.FmsReply("GetFromFMS", 0, "the real service's own words");
        await using var bench = Start(holdSeconds: 30, _ => Answer(200, realAnswer));

        var call = PostAsync(bench.Corp, Call("AUTHORIZE_USERS.txt"));
        var request = await WaitForRequestAsync(bench.Corp);
        await CarryAsync(bench.Corp, bench.Dmz, request.MessageId);     // the request crosses
        var reply = await WaitForOutboxAsync(bench.Dmz, m => m.Kind == MessageKind.Reply && m.CorrelationId == request.MessageId);
        await CarryAsync(bench.Dmz, bench.Corp, reply.MessageId);       // the far side's Reply crosses back
        var (response, body) = await call;

        Assert.Equal(1, bench.Network.Calls); // the far side posted the RoundTrip request to the real service, once
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal(RealAnswerContentType, response.Content.Headers.ContentType!.ToString());
        Assert.Equal(Encoding.UTF8.GetBytes(realAnswer), body);
        Assert.Equal(request.MessageId.ToString("D"), response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());

        var answered = (await RequestsAsync(bench.Corp)).Single();
        Assert.Equal("Answered", answered.ServiceStatus.ToString());
        Assert.Equal(OutboxLightStatus.Received, answered.LightStatus); // a Reply implies a Receipt
        Assert.Equal(200, answered.ServiceHttpStatus);
        await WaitForInboxAsync(bench.Corp, reply.MessageId, r => r.ServiceStatus == InboxServiceStatus.Done); // the Reply was used
    }

    // ---------------------------------------------------------------- the hold runs out

    [Theory]
    [InlineData("WITHDRAW_RFP.txt", 1596, 600)]   // state-changing: "sent, confirmation not yet received" (D8); expires after Gateway:Expiry (D62)
    [InlineData("AUTHORIZE_USERS.txt", 1599, 1)]  // read-only query: "not available" (D13), never run after its hold (D54)
    public async Task A_held_call_gets_the_hold_timeout_answer_when_no_answer_comes_back(string sample, int expectedCode, int expiresAfterSeconds)
    {
        await using var bench = Start(holdSeconds: 1);

        var clock = Stopwatch.StartNew();
        var (response, body) = await PostAsync(bench.Corp, Call(sample));

        Assert.True(clock.Elapsed >= TimeSpan.FromSeconds(0.9), $"answered after {clock.Elapsed}, before the hold ran out");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Equal(expectedCode, Code(body));
        var request = (await RequestsAsync(bench.Corp)).Single(); // it was queued: it may still cross and be answered
        Assert.Equal(request.MessageId.ToString("D"), response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());
        Assert.Equal(OutboxServiceStatus.Waiting, request.ServiceStatus);
        Assert.Equal(request.CreatedUtc.AddSeconds(expiresAfterSeconds), request.ExpiresUtc!.Value, TimeSpan.FromMilliseconds(500));
    }

    // ---------------------------------------------------------------- what each outcome gives the caller (D50, D51)

    public static TheoryData<string, int?, string?, int, int?, string> Outcomes() => new()
    {
        // outcome, real HTTP status, real answer carried, expected caller status, expected RETURN_CODE (null = the real body), Outbox status
        { "Done", 200, "fms0", 200, null, "Answered" },
        { "Refused", 500, "fault", 500, null, "Refused" },        // the real service's own SOAP fault, byte for byte
        { "Refused", 404, null, 200, 1596, "Refused" },           // no answer carried: the hold-timeout answer
        { "Unknown", 502, "html", 200, 1596, "Unknown" },         // may have been processed: never "not available"
        { "Done", 200, null, 200, 1596, "Answered" },             // answer too large to carry back
        { "Expired", null, null, 200, 1599, "Expired" },          // surely not done: "not available"
        { "NotDelivered", null, null, 200, 1599, "NotDelivered" },
        { "Rejected", null, null, 200, 1599, "Rejected" },
    };

    [Theory]
    [MemberData(nameof(Outcomes))]
    public async Task Each_outcome_gives_the_held_caller_the_agreed_answer(string outcome, int? httpStatus, string? answer,
                                                                           int expectedStatus, int? expectedCode, string outboxStatus)
    {
        string? realAnswer = answer switch
        {
            "fms0" => FakeSoapService.FmsReply("GetFromFMS", 0),
            "fault" => """<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><s:Fault><faultcode>s:Server</faultcode><faultstring>FMS says no</faultstring></s:Fault></s:Body></s:Envelope>""",
            "html" => "<html>Bad Gateway</html>",
            _ => null,
        };
        await using var bench = Start(holdSeconds: 30);

        var call = PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt"));
        var request = await WaitForRequestAsync(bench.Corp);
        await ReplyAsync(bench, request, Enum.Parse<ServiceOutcome>(outcome), httpStatus,
                         realAnswer is null ? null : Encoding.UTF8.GetBytes(realAnswer));
        var (response, body) = await call;

        Assert.Equal(expectedStatus, (int)response.StatusCode);
        if (expectedCode is { } code)
            Assert.Equal(code, Code(body));
        else
            Assert.Equal(Encoding.UTF8.GetBytes(realAnswer!), body);

        var row = (await RequestsAsync(bench.Corp)).Single();
        Assert.Equal(outboxStatus, row.ServiceStatus.ToString());
        Assert.Equal(httpStatus, row.ServiceHttpStatus);
        Assert.Equal($"test: {outcome}", row.ServiceComment);
    }

    // ---------------------------------------------------------------- caller retries (D38, D55, D56)

    [Fact]
    public async Task A_retry_waits_for_and_gets_the_same_answer_without_a_second_message()
    {
        byte[] realAnswer = Encoding.UTF8.GetBytes(FakeSoapService.FmsReply("GetFromFMS", 0));
        await using var bench = Start(holdSeconds: 30);
        using var health = bench.Corp.CreateClient();

        var first = PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt", attempt: 0));
        var request = await WaitForRequestAsync(bench.Corp);
        var retry = PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt", attempt: 1)); // new MSG_ID and GMT_TIME_SENT
        var deadline = DateTime.UtcNow.AddSeconds(10);
        while (!(await health.GetStringAsync("/health")).Contains("\"attached\":1") && DateTime.UtcNow < deadline)
            await Task.Delay(50);

        await ReplyAsync(bench, request, ServiceOutcome.Done, 200, realAnswer);

        Assert.Equal(realAnswer, (await first).Body);
        Assert.Equal(realAnswer, (await retry).Body); // woken by the same Reply
        var clock = Stopwatch.StartNew();
        var later = await PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt", attempt: 2));
        Assert.Equal(realAnswer, later.Body);          // the stored answer, at once
        Assert.True(clock.Elapsed < TimeSpan.FromSeconds(5), $"the stored answer took {clock.Elapsed}");
        Assert.Single(await RequestsAsync(bench.Corp)); // never a second message for the far side to deliver
    }

    [Fact]
    public async Task A_call_whose_message_cannot_cross_gets_the_hold_timeout_answer_at_once()
    {
        await using var bench = Start(holdSeconds: 60);

        var clock = Stopwatch.StartNew();
        var first = PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt", attempt: 0));
        var request = await WaitForRequestAsync(bench.Corp);
        // The QR sender gives up on it (out of re-air tries): nothing can come back without an operator (D55).
        var outbox = bench.Corp.Get<OutboxRepository>();
        Assert.Equal(request.MessageId, (await outbox.ClaimNextAsync(CancellationToken.None))!.MessageId);
        await outbox.ReleaseAsync(request.MessageId, "no receipt after 3 airings", maxAttempts: 1, TimeSpan.Zero, CancellationToken.None);

        Assert.Equal(1596, Code((await first).Body));
        Assert.Equal(1596, Code((await PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt", attempt: 1))).Body));
        Assert.True(clock.Elapsed < TimeSpan.FromSeconds(20), $"held for {clock.Elapsed} although nothing could come back");
        Assert.Single(await RequestsAsync(bench.Corp));
    }

    [Fact]
    public async Task A_caller_that_hangs_up_leaves_its_message_queued_and_its_retry_gets_the_answer()
    {
        byte[] realAnswer = Encoding.UTF8.GetBytes(FakeSoapService.FmsReply("GetFromFMS", 0));
        await using var bench = Start(holdSeconds: 30);

        using var hangUp = new CancellationTokenSource();
        var first = PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt", attempt: 0), hangUp.Token);
        var request = await WaitForRequestAsync(bench.Corp);
        await hangUp.CancelAsync();
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => first);
        var waiters = bench.Corp.Get<WaiterRegistry>();
        for (var until = DateTime.UtcNow.AddSeconds(10); waiters.Count > 0 && DateTime.UtcNow < until;) await Task.Delay(50);
        Assert.Equal(0, waiters.Count); // the hold ended with the call
        Assert.Equal(OutboxLightStatus.Pending, (await RequestsAsync(bench.Corp)).Single().LightStatus); // still queued

        await ReplyAsync(bench, request, ServiceOutcome.Done, 200, realAnswer);
        await WaitForOutboxAsync(bench.Corp, m => m.MessageId == request.MessageId && m.ServiceStatus == OutboxServiceStatus.Answered);

        Assert.Equal(realAnswer, (await PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt", attempt: 1))).Body);
        Assert.Single(await RequestsAsync(bench.Corp));
    }

    [Fact]
    public async Task Read_only_queries_are_never_attached_to_an_earlier_call()
    {
        await using var bench = Start(holdSeconds: 1);

        var first = await PostAsync(bench.Corp, Call("AUTHORIZE_USERS.txt", attempt: 0));
        var second = await PostAsync(bench.Corp, Call("AUTHORIZE_USERS.txt", attempt: 1));

        // D56: a stored (or expired) answer to a query is never reused: every query asks the real service again.
        Assert.NotEqual(first.Response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single(),
                        second.Response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());
        Assert.Equal(2, (await RequestsAsync(bench.Corp)).Count);
    }

    [Fact]
    public async Task The_database_is_the_truth_even_when_nothing_wakes_the_held_call()
    {
        byte[] realAnswer = Encoding.UTF8.GetBytes(FakeSoapService.FmsReply("GetFromFMS", 0));
        await using var bench = Start(holdSeconds: 30);

        var call = PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt"));
        var request = await WaitForRequestAsync(bench.Corp);
        // Stored without going through the Reply reader, so no waiter is woken: the hold's poll must find it.
        Assert.True(await bench.Corp.Get<OutboxRepository>().MarkAnsweredAsync(request.MessageId, OutboxServiceStatus.Answered, 200,
            "stored directly", RealAnswerContentType, realAnswer, DateTime.UtcNow, CancellationToken.None));

        var clock = Stopwatch.StartNew();
        Assert.Equal(realAnswer, (await call).Body);
        Assert.True(clock.Elapsed < TimeSpan.FromSeconds(10), $"found after {clock.Elapsed}");
    }

    // ---------------------------------------------------------------- arriving answers are checked before use

    public static TheoryData<string> BadAnswers() => ["another catalogue", "wrong direction", "unknown request", "another service"];

    [Theory]
    [MemberData(nameof(BadAnswers))]
    public async Task A_reply_that_fails_a_check_is_rejected_and_never_reaches_the_caller(string problem)
    {
        await using var bench = Start(holdSeconds: 3);
        byte[] fake = Encoding.UTF8.GetBytes(FakeSoapService.FmsReply("GetFromFMS", 0));

        var call = PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt"));
        var request = await WaitForRequestAsync(bench.Corp);
        Func<MessageHeader, MessageHeader>? alter = problem switch
        {
            "another catalogue" => h => h with { CatalogFingerprint = new string('0', 64) },
            "wrong direction" => h => h with { Direction = Direction.CorpToDmz },
            "another service" => h => h with { ServiceName = "FOD2FMS" },
            _ => null,
        };
        await ReplyAsync(bench, request, ServiceOutcome.Done, 200, fake, alter,
                         correlationId: problem == "unknown request" ? Guid.NewGuid() : null);

        Assert.Equal(1596, Code((await call).Body)); // the hold ran out: the Reply was not used
        await using var db = await bench.Corp.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        var arrived = await db.Inbox.AsNoTracking().SingleAsync();
        await WaitForInboxAsync(bench.Corp, arrived.MessageId, r => r.LightStatus == InboxLightStatus.Rejected);
        Assert.Equal(OutboxServiceStatus.Waiting, (await RequestsAsync(bench.Corp)).Single().ServiceStatus);
    }

    // ---------------------------------------------------------------- Receipts, and Bridge rows learn their outcome

    [Fact]
    public async Task Receipts_and_replies_for_a_bridge_message_update_the_sending_side()
    {
        await using var bench = Start(holdSeconds: 1, _ => Answer(200, FakeSoapService.FmsReply("SendToFMS", 0)));
        using var client = bench.Corp.CreateClient();
        var (response, _) = await SoapCalls.PostAsync(client, FmsEndpoint.FC2FMS, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("LIFT_CAUTION.TXT")));
        var id = Guid.Parse(response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());
        await CarryAsync(bench.Corp, bench.Dmz, id);

        var receipt = await WaitForOutboxAsync(bench.Dmz, m => m.Kind == MessageKind.Receipt && m.CorrelationId == id);
        await CarryAsync(bench.Dmz, bench.Corp, receipt.MessageId);
        await WaitForOutboxAsync(bench.Corp, m => m.MessageId == id && m.LightStatus == OutboxLightStatus.Received);
        await WaitForInboxAsync(bench.Corp, receipt.MessageId, r => r.ServiceStatus == InboxServiceStatus.Done);

        var reply = await WaitForOutboxAsync(bench.Dmz, m => m.Kind == MessageKind.Reply && m.CorrelationId == id);
        await CarryAsync(bench.Dmz, bench.Corp, reply.MessageId);
        var answered = await WaitForOutboxAsync(bench.Corp, m => m.MessageId == id && m.ServiceStatus == OutboxServiceStatus.Answered);
        Assert.Equal(200, answered.ServiceHttpStatus);
    }

    // ---------------------------------------------------------------- permits are held too (D60, D62, D63)

    [Fact]
    public async Task A_held_permit_gets_1596_and_expires_after_the_configured_time_not_its_hold()
    {
        await using var bench = Start(holdSeconds: 1);

        var (_, body) = await SoapCalls.PostAsync(bench.Corp.CreateClient(), FmsEndpoint.FC2FMS, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("REQUEST_FOR_PERMIT.txt")));

        Assert.Equal(1596, Code(body)); // D60: held like any state-changing call; no far side here
        var request = (await RequestsAsync(bench.Corp)).Single();
        Assert.Equal(request.CreatedUtc.AddSeconds(600), request.ExpiresUtc!.Value, TimeSpan.FromSeconds(1)); // D62: Gateway:Expiry
    }

    [Theory]
    [InlineData("Expired", true)]       // surely not done: the caller still wants it, so it is sent again (D63)
    [InlineData("NotDelivered", true)]
    [InlineData("Rejected", true)]
    [InlineData("Unknown", false)]      // may have been done: the retry gets the first answer, never a second message
    public async Task A_retry_of_a_message_that_surely_was_not_done_is_sent_as_a_new_message(string outcome, bool sentAgain)
    {
        await using var bench = Start(holdSeconds: 30);

        var first = PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt", attempt: 0));
        var request = await WaitForRequestAsync(bench.Corp);
        await ReplyAsync(bench, request, Enum.Parse<ServiceOutcome>(outcome), null, null);
        Assert.Equal(outcome == "Unknown" ? 1596 : 1599, Code((await first).Body));

        using var hangUp = new CancellationTokenSource();
        var retry = PostAsync(bench.Corp, Call("WITHDRAW_RFP.txt", attempt: 1), hangUp.Token);
        if (sentAgain)
        {
            var second = await WaitForRequestAsync(bench.Corp, count: 2);
            await hangUp.CancelAsync();
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => retry);
            Assert.NotEqual(request.MessageId, second.MessageId);
            Assert.Equal(request.ContentFingerprint, second.ContentFingerprint);
            Assert.True(second.ExpiresUtc > request.ExpiresUtc); // a fresh expiry
        }
        else
        {
            Assert.Equal(1596, Code((await retry).Body));
            Assert.Single(await RequestsAsync(bench.Corp));
        }
    }

    // ---------------------------------------------------------------- PortalSyncRequest with a full Outbox (D53)

    [Fact]
    public async Task A_full_outbox_gives_the_portal_monitor_its_no_data_answer()
    {
        string root = GatewayHost.NewRoot();
        try
        {
            await using var dmz = GatewayHost.Start(BridgeSide.Dmz, root, new Dictionary<string, string?> { ["Gateway:MaxBacklog"] = "0" });
            var (response, reply) = await SoapCalls.PostAsync(dmz.CreateClient(), FmsEndpoint.FMS2FC, "PortalSyncRequest",
                SoapCalls.Build(FmsEndpoint.FMS2FC, "PortalSyncRequest", "<MESSAGE TYPE=\"PORTAL_SYNC_REQUEST\" MSG_ID=\"1\"><MSG_HEADER /><MSG_DATA /></MESSAGE>"));

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var portal = XElement.Parse(SoapCalls.Result(reply)!);
            Assert.Equal(1599, SoapCalls.ReturnCode(portal.ToString()));
            Assert.Equal("", portal.Element("PORTAL_SYNC_RESPONSE")!.Element("GMT_TIME_STAMP")!.Value);
            Assert.False(response.Headers.Contains(SenderEndpoint.MessageIdHeader));
        }
        finally
        {
            GatewayHost.DeleteRoot(root);
        }
    }
}
