using System.Text;
using QrBridge.Gateway.Ingress.Soap;
using QrBridge.Gateway.Ingress.Validation;

namespace QrBridge.Tests.Gateway;

/// <summary>The SOAPAction check (G-11) against a real contract that has both a SOAP 1.1 and a SOAP 1.2 binding.</summary>
public class ServiceContractTests
{
    private const string Action = "http://www.coned.com/FMSWebService/ProcessMessage";

    private static readonly ServiceContract XaContract = ServiceContract.Load(
        Path.Combine(AppContext.BaseDirectory, ContractCatalog.FolderName, "Inbound", "XA2FMS"), "Inbound/XA2FMS");

    private static SoapRequest Parse(string envelopeNs, string contentType, string? soapActionHeader)
    {
        byte[] body = Encoding.UTF8.GetBytes(
            $"""<s:Envelope xmlns:s="{envelopeNs}"><s:Body><ProcessMessage xmlns="http://www.coned.com/FMSWebService"><XMLMsg>x</XMLMsg></ProcessMessage></s:Body></s:Envelope>""");
        Assert.True(SoapRequest.TryParse(body, contentType, soapActionHeader, 1_000_000, out var request, out string error), error);
        return request!;
    }

    private static SoapRequest Soap11(string? soapActionHeader) =>
        Parse("http://schemas.xmlsoap.org/soap/envelope/", "text/xml; charset=utf-8", soapActionHeader);

    private static SoapRequest Soap12(string? action) =>
        Parse("http://www.w3.org/2003/05/soap-envelope",
              action is null ? "application/soap+xml; charset=utf-8" : $"application/soap+xml; charset=utf-8; action=\"{action}\"", null);

    [Fact]
    public void The_wsdl_soap_action_is_accepted_quoted_or_not()
    {
        Assert.Null(XaContract.Check(Soap11($"\"{Action}\"")));
        Assert.Null(XaContract.Check(Soap11(Action)));
        Assert.Null(XaContract.Check(Soap12(Action)));
    }

    [Fact]
    public void Another_soap_action_is_refused()
    {
        Assert.Contains("SOAPAction", XaContract.Check(Soap11("\"http://www.coned.com/FMSWebService/EchoString\"")));
        Assert.Contains("SOAPAction", XaContract.Check(Soap12("http://tempuri.org/ProcessMessage")));
    }

    [Fact]
    public void A_request_without_an_action_is_not_checked()
    {
        Assert.Null(XaContract.Check(Soap11(null)));
        Assert.Null(XaContract.Check(Soap11("\"\"")));
        Assert.Null(XaContract.Check(Soap12(null)));
    }
}
