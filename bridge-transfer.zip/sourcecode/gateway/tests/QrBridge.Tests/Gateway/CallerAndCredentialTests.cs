using System.Net;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using QrBridge.Gateway;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Tests.Gateway.Infrastructure;
using static QrBridge.Tests.Gateway.Infrastructure.TwoGatewayBench;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Step 15 (G-07, G-05; decisions D75–D77): who called travels with the message and is logged at delivery; a target
/// can be called with or without the app pool identity; a delivered message keeps no body on either side.
/// </summary>
public sealed class CallerAndCredentialTests
{
    [Theory]
    [InlineData("10.0.0.9", "10.1.2.3, 10.5.5.5", "10.1.2.3 (via 10.0.0.9)")] // first address of the chain, labelled
    [InlineData("10.0.0.9", "2001:db8::1", "2001:db8::1 (via 10.0.0.9)")]
    [InlineData("10.0.0.9", null, "10.0.0.9")]
    [InlineData("10.0.0.9", "evil\r\nFAKE LOG LINE", "10.0.0.9")] // only address characters reach the logs
    [InlineData(null, "10.1.2.3", "10.1.2.3")]
    [InlineData(null, null, null)]
    public void The_caller_host_is_the_forwarded_address_labelled_with_the_connection(string? remote, string? forwarded, string? expected)
    {
        var context = new DefaultHttpContext();
        if (remote is not null) context.Connection.RemoteIpAddress = IPAddress.Parse(remote);
        if (forwarded is not null) context.Request.Headers["X-Forwarded-For"] = forwarded;

        Assert.Equal(expected, SenderEndpoint.CallerHostOf(context));
    }

    [Fact]
    public async Task The_caller_travels_with_the_message_and_nothing_delivered_keeps_its_body()
    {
        await using var bench = TwoGatewayBench.Start((_, _) => Answer(200, RealAnswer),
            new Dictionary<string, string?> { ["Gateway:Hold:DefaultSeconds"] = "20" });
        using var client = bench.Corp.CreateClient();
        using var call = new HttpRequestMessage(HttpMethod.Post, FmsEndpoint.FC2FMS.Path) { Content = new ByteArrayContent(WithdrawRfp()) };
        call.Content.Headers.TryAddWithoutValidation("Content-Type", "text/xml; charset=utf-8");
        call.Headers.TryAddWithoutValidation("SOAPAction", "\"http://tempuri.org/IFC2FMSInterface/GetFromFMS\"");
        call.Headers.TryAddWithoutValidation("X-Forwarded-For", "10.1.2.3");

        using var response = await client.SendAsync(call);
        Assert.Equal(Encoding.UTF8.GetBytes(RealAnswer), await response.Content.ReadAsByteArrayAsync());

        var request = Assert.Single(await OutboxAsync(bench.Corp, MessageKind.Request));
        Assert.StartsWith("10.1.2.3", MessageSerializer.PeekHeader(request.MessageBytes).CallerHost);

        // D77: the far side's delivered request and this side's used Reply keep no body, only their hash.
        var delivered = await WaitForInboxAsync(bench.Dmz, request.MessageId, r => r.ServiceStatus == InboxServiceStatus.Done);
        Assert.Empty(delivered.MessageBytes);
        Assert.Equal(request.MessageHash, delivered.MessageHash);
        var reply = Assert.Single(await OutboxAsync(bench.Dmz, MessageKind.Reply));
        var used = await WaitForInboxAsync(bench.Corp, reply.MessageId, r => r.ServiceStatus == InboxServiceStatus.Done);
        Assert.Empty(used.MessageBytes);
    }

    [Fact]
    public async Task A_target_can_be_called_with_or_without_the_app_pool_identity()
    {
        string root = GatewayHost.NewRoot();
        try
        {
            await using var host = GatewayHost.Start(BridgeSide.Dmz, root, new Dictionary<string, string?>
            {
                ["Gateway:Receiver:UseDefaultCredentials"] = "false",
                ["Gateway:Receiver:Targets:FC2FMS:Url"] = "http://fc.test/FC2FMSInterface.svc",
                ["Gateway:Receiver:Targets:FC2FMS:UseDefaultCredentials"] = "true",
                ["Gateway:Receiver:Targets:SSO2FMS:Url"] = "http://sso.test/SSO2FMSInterface.svc",
                ["Gateway:Receiver:Targets:SSO2FMS:UseDefaultCredentials"] = "false",
            });
            var forwarder = host.Get<SoapForwarderHttpClient>();
            var handlers = host.Get<IHttpMessageHandlerFactory>();

            Assert.Equal(SoapForwarderHttpClient.DefaultCredentialsClientName, forwarder.ClientNameFor("FC2FMS"));
            Assert.Equal(SoapForwarderHttpClient.HttpClientName, forwarder.ClientNameFor("SSO2FMS")); // same as the global setting
            Assert.Equal(SoapForwarderHttpClient.HttpClientName, forwarder.ClientNameFor("FOD2FMS")); // no override
            Assert.Same(CredentialCache.DefaultCredentials, Primary(handlers, SoapForwarderHttpClient.DefaultCredentialsClientName).Credentials);
            Assert.Null(Primary(handlers, SoapForwarderHttpClient.HttpClientName).Credentials);
            Assert.Null(Primary(handlers, SoapForwarderHttpClient.AnonymousClientName).Credentials);
            Assert.False(Primary(handlers, SoapForwarderHttpClient.DefaultCredentialsClientName).AllowAutoRedirect);
        }
        finally
        {
            GatewayHost.DeleteRoot(root);
        }

        // The other way round: the gateway calls as its identity, one target anonymously.
        var options = new GatewayOptions { Receiver = { UseDefaultCredentials = true } };
        options.Receiver.Targets["FC2FMS"] = new ReceiverTarget { Url = "http://fc.test", UseDefaultCredentials = false };
        var anonymous = new SoapForwarderHttpClient(null!, Options.Create(options), null!);
        Assert.Equal(SoapForwarderHttpClient.AnonymousClientName, anonymous.ClientNameFor("FC2FMS"));
    }

    private static SocketsHttpHandler Primary(IHttpMessageHandlerFactory factory, string name)
    {
        HttpMessageHandler handler = factory.CreateHandler(name);
        while (handler is DelegatingHandler delegating) handler = delegating.InnerHandler!;
        return Assert.IsType<SocketsHttpHandler>(handler);
    }
}
