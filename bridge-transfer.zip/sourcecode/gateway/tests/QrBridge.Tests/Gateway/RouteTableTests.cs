using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using QrBridge.Gateway;
using QrBridge.Gateway.Routing;
using QrBridge.Shared;

namespace QrBridge.Tests.Gateway;

public class RouteTableTests
{
    private static RouteTable Table(RoutingOptions routing, BridgeSide side = BridgeSide.Corp) =>
        new(Options.Create(routing), Options.Create(new BridgeOptions { Side = side }));

    private static RoutingOptions Sample(bool acceptUnlisted = false) => new()
    {
        AcceptUnlisted = acceptUnlisted,
        ReplyProfiles = { ["Fms"] = new ReplyProfile { ResultKind = ResultKind.FmsResponse, Ok = "ok" } },
        Services =
        {
            new ServiceRoute
            {
                Name = "FC2FMS",
                Paths = { "/FMS_FC2FMSInterface/FC2FMSInterface.svc" },
                Operations =
                {
                    ["SendToFMS"] = new OperationRoute { Mode = OperationMode.Bridge, Reply = "Fms" },
                    ["GetFromFMS"] = new OperationRoute { Mode = OperationMode.Unavailable, Reply = "Fms" },
                },
            },
        },
    };

    /// <summary>The catalogue that ships with the gateway (copied next to the tests at build time).</summary>
    private static RoutingOptions ShippedCatalogue(IDictionary<string, string?>? changes = null)
    {
        var config = new ConfigurationBuilder()
            .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "routes.json"), optional: false)
            .AddInMemoryCollection(changes ?? new Dictionary<string, string?>())
            .Build();
        return config.GetSection(RoutingOptions.SectionName).Get<RoutingOptions>()!;
    }

    [Theory]
    [InlineData("Routing:FingerprintIgnore:0", "TYPE")] // the fields left out of the content fingerprint
    [InlineData("Routing:Services:0:Operations:GetFromFMS:Types:AUTHORIZE_USERS:OnHoldTimeout", "Pending")]
    public void Round_trip_settings_are_part_of_the_catalogue_fingerprint(string key, string value)
    {
        // D31: both sides must agree on them, so a gateway with other values must be detected.
        Assert.NotEqual(Table(ShippedCatalogue()).CatalogFingerprint,
                        Table(ShippedCatalogue(new Dictionary<string, string?> { [key] = value })).CatalogFingerprint);
    }

    [Theory]
    [InlineData(null, "/")]
    [InlineData("", "/")]
    [InlineData("/FMS_FC2FMSInterface/FC2FMSInterface.svc", "/FMS_FC2FMSInterface/FC2FMSInterface.svc")]
    [InlineData("/FMS_FC2FMSInterface//FC2FMSInterface.svc/", "/FMS_FC2FMSInterface/FC2FMSInterface.svc")]
    [InlineData("/x.svc?wsdl", "/x.svc")]
    public void Paths_are_normalized(string? input, string expected) => Assert.Equal(expected, RouteTable.NormalizePath(input));

    [Fact]
    public void Listed_operation_resolves_with_its_reply_profile()
    {
        var d = Table(Sample()).Resolve("/fms_fc2fmsinterface/FC2FMSINTERFACE.svc", "SendToFMS", null); // case-insensitive path
        Assert.Equal(OperationMode.Bridge, d.Mode);
        Assert.Equal("FC2FMS", d.ServiceName);
        Assert.Equal("ok", d.Profile!.Ok);
    }

    [Fact]
    public void Unlisted_operation_on_a_listed_service_is_refused()
    {
        var d = Table(Sample()).Resolve("/FMS_FC2FMSInterface/FC2FMSInterface.svc", "DropTables", null);
        Assert.Equal(OperationMode.Reject, d.Mode);
        Assert.Contains("not bridged", d.Problem);
    }

    [Fact]
    public void Unlisted_path_is_refused_unless_explicitly_allowed()
    {
        Assert.Equal(OperationMode.Reject, Table(Sample()).Resolve("/Other/Service.svc", "DoWork", null).Mode);

        var open = Table(Sample(acceptUnlisted: true)).Resolve("/Other/Service.svc", "DoWork", null);
        Assert.Equal(OperationMode.Bridge, open.Mode);
        Assert.Equal("/Other/Service.svc", open.ServiceName);
        Assert.Null(open.Service);
    }

    [Fact]
    public void A_gateway_does_not_accept_services_whose_callers_are_on_the_other_side()
    {
        var d = Table(Sample(), BridgeSide.Dmz).Resolve("/FMS_FC2FMSInterface/FC2FMSInterface.svc", "SendToFMS", null);
        Assert.Equal(OperationMode.Reject, d.Mode);
    }

    [Fact]
    public void Invalid_catalogues_fail_at_startup()
    {
        var duplicate = Sample();
        duplicate.Services.Add(new ServiceRoute { Name = "Other", Paths = { "/FMS_FC2FMSInterface/FC2FMSInterface.svc" } });
        Assert.Throws<InvalidOperationException>(() => Table(duplicate));

        var badProfile = Sample();
        badProfile.Services[0].Operations["SendToFMS"].Reply = "Typo";
        Assert.Throws<InvalidOperationException>(() => Table(badProfile));
    }

    [Fact]
    public void Shipped_catalogue_is_valid_and_covers_the_fms_interfaces()
    {
        var table = Table(ShippedCatalogue());

        Assert.False(table.Options.AcceptUnlisted); // production default: allow-list
        // Which operations are Bridge and which RoundTrip (D60, D61): Shipped_catalogue_holds_permits_orders_and_cards…

        // Polls stay "not available" (D15); so do ProcessMessage types nobody decided on
        Assert.Equal(OperationMode.Unavailable, table.Resolve("/FMSWebService/ECC_XAFMSService.asmx", "ProcessMessage", "DISPLAY_POLL").Mode);
        Assert.Equal(OperationMode.Unavailable, table.Resolve("/ECC_BFCWebService/ECC_BFCWebService.asmx", "ProcessMessage", "BUS_FAULT_OUTAGE_REQUEST").Mode);
        Assert.Equal(OperationMode.Unavailable, table.Resolve("/FMSWebService/ECC_XAFMSService.asmx", "ProcessMessage", "SOMETHING_ELSE").Mode);

        // D52: the XA/21 and BFC round-trip types stay "not available" until D23 says whether they cross at all
        Assert.Equal(OperationMode.Unavailable, table.Resolve("/FMSWebService/ECC_XAFMSService.asmx", "ProcessMessage", "DISPLAY_ERROR").Mode);
        Assert.Equal(OperationMode.Unavailable, table.Resolve("/FMSWebService/ECC_XAFMSService.asmx", "ProcessMessage", "DEVICE_STATUS_CHANGE").Mode);
        Assert.Equal(OperationMode.Unavailable,
                     table.Resolve("/ECC_BFCWebService/ECC_BFCWebService.asmx", "ProcessMessage", "BUS_FAULT_CORRELATION_REQUEST").Mode);
    }

    [Theory]
    // D60: permits, orders, cards and their responses are held for the real answer; 1596 when it does not come back
    [InlineData(BridgeSide.Corp, "/FMS_FC2FMSInterface/FC2FMSInterface.svc", "SendToFMS", "REQUEST_FOR_PERMIT", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Corp, "/FMS_FOD2FMSInterface/FOD2FMSInterface.svc", "SendToFMS", "RETURN_MOVE", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Corp, "/FMS_SSO2FMSInterface/SSO2FMSInterface.svc", "SendToFMS", "RETURN_ORDER", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Corp, "/FMS_SSO2TOMSInterface/SSO2TOMSInterface.svc", "SendToTOMS", "TOMS_RETURN_ORDER", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Corp, "/FMS_SSO2TLSInterface/SSO2TLSInterface.svc", "SendToTLS", "TLS_RETURN_ORDER", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Corp, "/FMS_SSO2DSOInterface/SSO2DSOInterface.svc", "SendToDSO", "DSO_RETURN_ORDER", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Corp, "/FMSInterface/RR_DSSFMSService.wsdl", "SendToFMS", "NO9_MOVE_RESPONSE", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Corp, "/FMSInterface/RR_FCFMSService.WSDL", "SendToFMS", "REQUEST_FOR_PERMIT", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Corp, "/FMSInterface/RR_SSOFMSService.WSDL", "SendToFMS", "RETURN_ORDER", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Dmz, "/FMSRRFCInterface/FMS2RRFCInterface.svc", "CreateCard", "CARD_CREATE", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Dmz, "/FMSRRFCInterface/FMS2RRFCInterface.svc", "IssueWorkPermit", "ISSUE_WORK_PERMIT", OperationMode.RoundTrip)] // D61
    [InlineData(BridgeSide.Dmz, "/FMSRRFODInterface/FMSRRFODInterface.svc", "IssueOrder", "ISSUE_ORDER", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Dmz, "/FMSRRInterface/FMS2SSOInterface.svc", "SendPage", "SEND_PAGE", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Dmz, "/FMSRRInterface/TLS2SSOInterface.svc", "IssueOrder", "TLS_ISSUE_ORDER", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Dmz, "/FMSRRInterface/TOMS2SSOInterface.svc", "SetOrderPriority", "ORDER_PRIORITY", OperationMode.RoundTrip)]
    [InlineData(BridgeSide.Dmz, "/FMSRRInterface/DSO2SSOInterface.svc", "SMResponse", "DSO_SM_RESPONSE", OperationMode.RoundTrip)]
    // Feeds stay Bridge: answered 0 at once and delivered later
    [InlineData(BridgeSide.Corp, "/FMS_FTC2FMSInterface/FTC2FMSInterface.svc", "SendToFMS", "FAULT_CORRELATION", OperationMode.Bridge)]
    [InlineData(BridgeSide.Corp, "/FMSInterface/RR_FTCFMSService.WSDL", "SendToFMS", "FAULT_CORRELATION", OperationMode.Bridge)]
    [InlineData(BridgeSide.Corp, "/VZ2TLSWebService/VZ2TLSInterface.asmx", "SendToTLS", "createTicketResponse", OperationMode.Bridge)]
    [InlineData(BridgeSide.Dmz, "/feederstatusws/fms2fssinterface.asmx", "fms2fss", "FEEDER_CARD", OperationMode.Bridge)]
    [InlineData(BridgeSide.Dmz, "/substationdashboardws/fms2dashboard.asmx", "FMS2FSS", "FEEDER_CARD", OperationMode.Bridge)]
    [InlineData(BridgeSide.Dmz, "/SubstationLog/services/FMS2SSLogInterface.asmx", "fms2ssLog", "BREAKER_STATUS_CHANGE", OperationMode.Bridge)]
    [InlineData(BridgeSide.Dmz, "/eldisws/fms2vrinterface.asmx", "VRCompletion", "VOLTAGE_REDUCTION_COMPLETE", OperationMode.Bridge)]
    public void Shipped_catalogue_holds_permits_orders_and_cards_and_keeps_feeds_bridged(BridgeSide side, string path, string operation,
                                                                                       string type, OperationMode expected)
    {
        var d = Table(ShippedCatalogue(), side).Resolve(path, operation, type);
        Assert.Equal(expected, d.Mode);
        if (expected == OperationMode.RoundTrip)
        {
            Assert.Equal(HoldTimeoutAnswer.Pending, d.OnHoldTimeout);
            Assert.Contains("1596", d.Profile!.Pending);
            Assert.True(d.RecogniseRetries); // a retry after 1596 gets the first message's answer, never a second delivery
        }
        else
        {
            Assert.False(d.RecogniseRetries);
        }
    }

    [Theory]
    // D13: read-only queries get the "not available" answer when the hold runs out
    [InlineData(BridgeSide.Corp, "/FMS_FC2FMSInterface/FC2FMSInterface.svc", "GetFromFMS", "AUTHORIZE_USERS", HoldTimeoutAnswer.Unavailable)]
    [InlineData(BridgeSide.Corp, "/FMS_FC2FMSInterface/FC2FMSInterface.svc", "GetFromFMS", "GET_FEEDER_INFO", HoldTimeoutAnswer.Unavailable)]
    [InlineData(BridgeSide.Corp, "/FMS_FTC2FMSInterface/FTC2FMSInterface.svc", "GetFromFMS", "GET_RELAY_TARGET", HoldTimeoutAnswer.Unavailable)]
    [InlineData(BridgeSide.Dmz, "/eldisws/FMS2FTCInterface.asmx", "GetFaultCorrelation", "GET_FAULT_CORRELATION", HoldTimeoutAnswer.Unavailable)]
    // D14: WITHDRAW_RFP changes data; D35: a GetFromFMS type nobody listed is treated the same way
    [InlineData(BridgeSide.Corp, "/FMS_FC2FMSInterface/FC2FMSInterface.svc", "GetFromFMS", "WITHDRAW_RFP", HoldTimeoutAnswer.Pending)]
    [InlineData(BridgeSide.Corp, "/FMS_FC2FMSInterface/FC2FMSInterface.svc", "GetFromFMS", "SOMETHING_NEW", HoldTimeoutAnswer.Pending)]
    [InlineData(BridgeSide.Corp, "/FMS_FTC2FMSInterface/FTC2FMSInterface.svc", "GetFromFMS", null, HoldTimeoutAnswer.Pending)]
    // D17: the GetFrom… operations with no known message types, legacy endpoints included
    [InlineData(BridgeSide.Corp, "/FMS_FOD2FMSInterface/FOD2FMSInterface.svc", "GetFromFMS", "ANY", HoldTimeoutAnswer.Pending)]
    [InlineData(BridgeSide.Corp, "/FMS_SSO2TOMSInterface/SSO2TOMSInterface.svc", "GetFromTOMS", "ANY", HoldTimeoutAnswer.Pending)]
    [InlineData(BridgeSide.Corp, "/FMSInterface/RR_DSSFMSService.wsdl", "GetFromFMS", "ANY", HoldTimeoutAnswer.Pending)]
    [InlineData(BridgeSide.Corp, "/FMSInterface/RR_FCFMSService.WSDL", "GetFromFMS", "AUTHORIZE_USERS", HoldTimeoutAnswer.Pending)]
    // D19: the empty time stamp
    [InlineData(BridgeSide.Dmz, "/FMSRRFCInterface/FMS2RRFCInterface.svc", "PortalSyncRequest", "PORTAL_SYNC_REQUEST", HoldTimeoutAnswer.Unavailable)]
    public void Shipped_catalogue_sends_the_decided_calls_on_a_round_trip(BridgeSide side, string path, string operation, string? type,
                                                                         HoldTimeoutAnswer onTimeout)
    {
        var d = Table(ShippedCatalogue(), side).Resolve(path, operation, type);
        Assert.Equal(OperationMode.RoundTrip, d.Mode);
        Assert.Equal(onTimeout, d.OnHoldTimeout);
        if (onTimeout == HoldTimeoutAnswer.Pending)
            Assert.Contains("1596", d.Profile!.Pending);
        Assert.Equal(new[] { "MSG_ID", "GMT_TIME_SENT", "RRMsgID" }, d.FingerprintIgnore);
    }

    [Fact]
    public void Retries_are_recognised_on_state_changing_round_trip_routes_unless_a_route_says_otherwise()
    {
        // D37, D56: on for RoundTrip routes answering 1596 on timeout; off for Bridge (a Bridge caller already got
        // RETURN_CODE 0) and for queries (a query must ask the real service again, not get an earlier answer)
        var routing = Sample(acceptUnlisted: true);
        routing.ReplyProfiles["Fms"].Pending = "1596";
        var getFrom = routing.Services[0].Operations["GetFromFMS"];
        getFrom.Mode = OperationMode.RoundTrip;
        getFrom.Types["AUTHORIZE_USERS"] = new TypeRoute { RecogniseRetries = false };
        getFrom.Types["GET_FEEDER_INFO"] = new TypeRoute { OnHoldTimeout = HoldTimeoutAnswer.Unavailable };
        getFrom.Types["SOME_QUERY"] = new TypeRoute { OnHoldTimeout = HoldTimeoutAnswer.Unavailable, RecogniseRetries = true };
        const string path = "/FMS_FC2FMSInterface/FC2FMSInterface.svc";

        Assert.True(Table(routing).Resolve(path, "GetFromFMS", "WITHDRAW_RFP").RecogniseRetries);
        Assert.False(Table(routing).Resolve(path, "GetFromFMS", "AUTHORIZE_USERS").RecogniseRetries);
        Assert.False(Table(routing).Resolve(path, "GetFromFMS", "GET_FEEDER_INFO").RecogniseRetries);
        Assert.True(Table(routing).Resolve(path, "GetFromFMS", "SOME_QUERY").RecogniseRetries); // a route can still opt in
        Assert.False(Table(routing).Resolve(path, "SendToFMS", "REQUEST_FOR_PERMIT").RecogniseRetries);
        Assert.False(Table(routing).Resolve("/Other/Service.svc", "DoWork", null).RecogniseRetries);

        routing.Services[0].Operations["SendToFMS"].RecogniseRetries = true; // a Bridge route that opts in
        Assert.True(Table(routing).Resolve(path, "SendToFMS", "REQUEST_FOR_PERMIT").RecogniseRetries);

        // The shipped catalogue sets it nowhere: since step 10c permits are RoundTrip (D60), so they recognise retries
        var shipped = Table(ShippedCatalogue());
        Assert.True(shipped.Resolve(path, "SendToFMS", "REQUEST_FOR_PERMIT").RecogniseRetries);
        Assert.True(shipped.Resolve(path, "GetFromFMS", "WITHDRAW_RFP").RecogniseRetries);
        Assert.False(shipped.Resolve(path, "GetFromFMS", "AUTHORIZE_USERS").RecogniseRetries);
        Assert.False(Table(ShippedCatalogue(), BridgeSide.Dmz)
            .Resolve("/FMSRRFCInterface/FMS2RRFCInterface.svc", "PortalSyncRequest", "PORTAL_SYNC_REQUEST").RecogniseRetries);
    }

    [Fact]
    public void A_message_type_can_have_its_own_mode_inside_an_operation()
    {
        var routing = Sample();
        routing.ReplyProfiles["Fms"].Pending = "1596";
        routing.FingerprintIgnore.Add("MSG_ID");
        var getFrom = routing.Services[0].Operations["GetFromFMS"];
        getFrom.Mode = OperationMode.RoundTrip;
        getFrom.FingerprintIgnore.Add("RRMsgID");
        getFrom.Types["AUTHORIZE_USERS"] = new TypeRoute { OnHoldTimeout = HoldTimeoutAnswer.Unavailable, FingerprintIgnore = { "STAMP" } };
        getFrom.Types["DISPLAY_POLL"] = new TypeRoute { Mode = OperationMode.Unavailable };
        var table = Table(routing);
        const string path = "/FMS_FC2FMSInterface/FC2FMSInterface.svc";

        var query = table.Resolve(path, "GetFromFMS", "AUTHORIZE_USERS");
        Assert.Equal(OperationMode.RoundTrip, query.Mode); // the type's mode follows the operation
        Assert.Equal(HoldTimeoutAnswer.Unavailable, query.OnHoldTimeout);
        Assert.Equal(new[] { "MSG_ID", "RRMsgID", "STAMP" }, query.FingerprintIgnore); // catalogue + operation + type

        Assert.Equal(OperationMode.Unavailable, table.Resolve(path, "GetFromFMS", "DISPLAY_POLL").Mode);
        Assert.Equal(OperationMode.Unavailable, RouteTable.ModeOf(routing.Services[0], "GetFromFMS", "DISPLAY_POLL"));

        // Types are matched exactly, like AllowedTypes; anything else follows the operation
        foreach (string? other in new[] { "authorize_users", "", null })
        {
            var d = table.Resolve(path, "GetFromFMS", other);
            Assert.Equal(OperationMode.RoundTrip, d.Mode);
            Assert.Equal(HoldTimeoutAnswer.Pending, d.OnHoldTimeout);
            Assert.Equal(new[] { "MSG_ID", "RRMsgID" }, d.FingerprintIgnore);
        }
    }

    [Fact]
    public void Round_trip_settings_that_could_not_give_the_agreed_answer_fail_at_startup()
    {
        static RoutingOptions RoundTrip(Action<RoutingOptions> change)
        {
            var routing = Sample();
            routing.ReplyProfiles["Fms"].Pending = "1596";
            routing.Services[0].Operations["GetFromFMS"].Mode = OperationMode.RoundTrip;
            change(routing);
            return routing;
        }
        _ = Table(RoundTrip(_ => { })); // the valid baseline starts

        foreach (var (change, named) in new (Action<RoutingOptions>, string)[]
                 {
                     (r => r.ReplyProfiles["Fms"].Pending = null, "Pending"),
                     (r => r.Services[0].Operations["GetFromFMS"].Reply = null, "Pending"), // no profile at all
                     (r => r.Services[0].Operations["GetFromFMS"].OneWay = true, "OneWay"),
                     (r => { var send = r.Services[0].Operations["SendToFMS"]; send.AllowedTypes.Add("A"); send.Types["X"] = new TypeRoute(); }, "AllowedTypes"),
                     (r => r.Services[0].Operations["GetFromFMS"].Types["X"] = new TypeRoute { Mode = OperationMode.Reject }, "'X'"),
                     (r => r.Services[0].Operations["GetFromFMS"].Types[" "] = new TypeRoute(), "empty message type"),
                     (r => r.FingerprintIgnore.Add(""), "FingerprintIgnore"),
                     (r => r.Services[0].Operations["GetFromFMS"].Types["X"] = new TypeRoute { FingerprintIgnore = { " " } }, "FingerprintIgnore"),
                     (r => r.Services[0].OtherOperations = OperationMode.RoundTrip, "OtherOperations"),
                 })
        {
            var ex = Assert.Throws<InvalidOperationException>(() => Table(RoundTrip(change)));
            Assert.Contains(named, ex.Message);
        }
    }

    [Fact]
    public void A_get_route_is_a_read_only_round_trip_for_one_path_or_the_gateway_does_not_start()
    {
        // D18: one configured GET path, nothing that could fetch other pages or answer "accepted" without the real answer.
        static RoutingOptions Get(Action<ServiceRoute> change)
        {
            var routing = Sample();
            var service = new ServiceRoute
            {
                Name = "RegisteredTags", HttpGet = true, Paths = { "/FMS_ReportService/RegisteredTags.asmx/GetData" },
                Operations = { ["GET"] = new OperationRoute { Mode = OperationMode.RoundTrip, OnHoldTimeout = HoldTimeoutAnswer.Unavailable } },
            };
            change(service);
            routing.Services.Add(service);
            return routing;
        }
        _ = Table(Get(_ => { }));
        Assert.True(Table(ShippedCatalogue()).FindByPath("/fms_reportservice/registeredtags.asmx/getdata") is
            { HttpGet: true, SenderSide: BridgeSide.Corp, Name: "RegisteredTags" });

        foreach (var (change, named) in new (Action<ServiceRoute>, string)[]
                 {
                     (s => s.Paths.Add("/other"), "exactly one path"),
                     (s => s.Contract = "FC2FMS", "no WSDL"),
                     (s => s.OtherOperations = OperationMode.Bridge, "OtherOperations"),
                     (s => s.Operations["SendToFMS"] = new OperationRoute(), "exactly one operation"),
                     (s => { s.Operations.Clear(); s.Operations["GetData"] = new OperationRoute(); }, "exactly one operation"),
                     (s => s.Operations["GET"].Mode = OperationMode.Bridge, "RoundTrip or Unavailable"),
                     (s => s.Operations["GET"].OnHoldTimeout = HoldTimeoutAnswer.Pending, "read-only"),
                     (s => s.Operations["GET"].RecogniseRetries = true, "read-only"),
                     (s => s.Operations["GET"].Reply = "Fms", "no Reply profile"),
                 })
        {
            var ex = Assert.Throws<InvalidOperationException>(() => Table(Get(change)));
            Assert.Contains(named, ex.Message);
        }
    }

    [Theory]
    [InlineData(BridgeSide.Corp, "/FMS_FC2FMSInterface/FC2FMSInterface.svc", "SendToFMS", "REQUEST_FOR_PERMIT", MessagePriority.High)]
    [InlineData(BridgeSide.Corp, "/FMS_FC2FMSInterface/FC2FMSInterface.svc", "GetFromFMS", "WITHDRAW_RFP", MessagePriority.High)]
    [InlineData(BridgeSide.Corp, "/FMS_FC2FMSInterface/FC2FMSInterface.svc", "GetFromFMS", "AUTHORIZE_USERS", MessagePriority.Normal)]
    [InlineData(BridgeSide.Corp, "/FMS_ReportService/RegisteredTags.asmx/GetData", "GET", null, MessagePriority.Normal)]
    [InlineData(BridgeSide.Corp, "/FMS_FTC2FMSInterface/FTC2FMSInterface.svc", "SendToFMS", "FAULT_CORRELATION", MessagePriority.Low)]
    [InlineData(BridgeSide.Corp, "/VZ2TLSWebService/VZ2TLSInterface.asmx", "SendToTLS", "createTicketResponse", MessagePriority.Low)]
    [InlineData(BridgeSide.Dmz, "/FMSRRFCInterface/FMS2RRFCInterface.svc", "CreateCard", "CARD_CREATE", MessagePriority.High)]
    [InlineData(BridgeSide.Dmz, "/feederstatusws/fms2fssinterface.asmx", "fms2fss", "FEEDER_CARD", MessagePriority.Low)]
    public void Shipped_catalogue_sends_permits_first_then_queries_then_feeds(BridgeSide side, string path, string operation, string? type,
                                                                            MessagePriority expected)
    {
        // D73: the default class from the mode; nothing in routes.json overrides it today.
        Assert.Equal(expected, Table(ShippedCatalogue(), side).Resolve(path, operation, type).Priority);
    }

    [Fact]
    public void A_route_can_choose_its_class_but_never_the_answers_class()
    {
        var routing = Sample();
        routing.Services[0].Operations["SendToFMS"].Priority = MessagePriority.High;
        Assert.Equal(MessagePriority.High, Table(routing).Resolve("/FMS_FC2FMSInterface/FC2FMSInterface.svc", "SendToFMS", null).Priority);
        Assert.Equal(MessagePriority.Low, Table(Sample()).Resolve("/FMS_FC2FMSInterface/FC2FMSInterface.svc", "SendToFMS", null).Priority);

        routing.Services[0].Operations["SendToFMS"].Priority = MessagePriority.Answer;
        Assert.Contains("reserved for Receipts and Replies", Assert.Throws<InvalidOperationException>(() => Table(routing)).Message);
    }

    [Theory]
    [InlineData(0, null, "MaxRequestBytes")]
    [InlineData(-1, null, "MaxRequestBytes")]
    [InlineData(null, 0, "MaxBacklog")]
    public void Route_size_and_backlog_limits_must_make_sense(int? maxRequestBytes, int? maxBacklog, string named)
    {
        var routing = Sample();
        routing.Services[0].MaxRequestBytes = maxRequestBytes;
        routing.Services[0].MaxBacklog = maxBacklog;
        Assert.Contains(named, Assert.Throws<InvalidOperationException>(() => Table(routing)).Message);
    }
}
