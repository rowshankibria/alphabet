using System.Text;
using QrBridge.Gateway.Ingress.Soap;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// The content fingerprint (decisions D5, D38). Too wide (a per-send field counted) and a caller's retry is delivered
/// twice; too narrow (a business difference ignored) and a real second message is taken for a retry. Both directions
/// are pinned here.
/// </summary>
public class ContentFingerprintTests
{
    private static readonly string[] Ignore = ["MSG_ID", "GMT_TIME_SENT", "RRMsgID"];

    private const string Payload =
        "<MESSAGE TYPE=\"SSO_RESPONSE\" MSG_ID=\"456\" GMT_TIME_SENT=\"02/16/2004 14:00:10\">\n" +
        "\t<MSG_HEADER>\n\t\t<RRMsgID>9001</RRMsgID>\n\t\t<SOURCE_APPLICAION>SSO</SOURCE_APPLICAION>\n\t</MSG_HEADER>\n" +
        "\t<MSG_DATA><SSO_RESPONSE RESPONSE_TYPE=\"ORDER_ACCEPT\"><FMS_ORDER_NUMBER>36505</FMS_ORDER_NUMBER>" +
        "<COMMENTS>Accepted by SSO</COMMENTS></SSO_RESPONSE></MSG_DATA>\n</MESSAGE>";

    private static string? Of(string payload, string service = "SSO2FMS", string? type = "SSO_RESPONSE",
                              string operation = "SendToFMS", IReadOnlyCollection<string>? ignore = null) =>
        ContentFingerprint.Compute(service, type, SoapCalls.Build(FmsEndpoint.SSO2FMS, operation, payload), ignore ?? Ignore, 2_000_000);

    [Fact]
    public void The_per_send_fields_are_left_out_wherever_they_are()
    {
        string expected = Of(Payload)!;
        Assert.Matches("^[0-9a-f]{64}$", expected);

        Assert.Equal(expected, Of(Payload.Replace("MSG_ID=\"456\"", "MSG_ID=\"457\"")));
        Assert.Equal(expected, Of(Payload.Replace("14:00:10", "14:03:10")));
        Assert.Equal(expected, Of(Payload.Replace("<RRMsgID>9001</RRMsgID>", "<RRMsgID>9002</RRMsgID>")));
        Assert.Equal(expected, Of(Payload.Replace("<FMS_ORDER_NUMBER>", "<FMS_ORDER_NUMBER RRMsgID=\"7\">"))); // as an attribute too
    }

    [Fact]
    public void Soap_headers_are_left_out()
    {
        // A WCF caller sends a new WS-Addressing MessageID on every call.
        byte[] body = SoapCalls.Build(FmsEndpoint.SSO2FMS, "SendToFMS", Payload);
        byte[] withHeader = Encoding.UTF8.GetBytes(Encoding.UTF8.GetString(body).Replace("<s:Body>",
            "<s:Header><a:MessageID xmlns:a=\"http://www.w3.org/2005/08/addressing\">urn:uuid:1</a:MessageID></s:Header><s:Body>"));

        Assert.Equal(Of(Payload), ContentFingerprint.Compute("SSO2FMS", "SSO_RESPONSE", withHeader, Ignore, 2_000_000));
    }

    [Fact]
    public void Any_business_difference_makes_another_fingerprint()
    {
        string expected = Of(Payload)!;
        foreach (string? other in new[]
                 {
                     Of(Payload.Replace("36505", "36506")),                               // an element's text
                     Of(Payload.Replace("ORDER_ACCEPT", "ORDER_REJECT")),                 // an attribute that is not left out
                     Of(Payload.Replace("Accepted by SSO", "Accepted by  SSO")),          // whitespace inside a value
                     Of(Payload.Replace("\t<MSG_DATA>", "\t\t<MSG_DATA>")),               // formatting: errs on "too wide"
                     Of(Payload.Replace("<COMMENTS>Accepted by SSO</COMMENTS>", "")),      // a field missing
                     Of(Payload, service: "SSO2FMS-Legacy"),
                     Of(Payload, type: "RETURN_ORDER"),
                     Of(Payload, operation: "GetFromFMS"),
                     Of(Payload, ignore: []),                                              // the ignore list is what makes retries match
                 })
        {
            Assert.NotNull(other);
            Assert.NotEqual(expected, other);
        }
        Assert.NotEqual(Of(Payload.Replace("MSG_ID=\"456\"", "MSG_ID=\"457\""), ignore: []), Of(Payload, ignore: []));
    }

    [Fact]
    public void A_plain_text_parameter_counts_as_it_is()
    {
        Assert.Equal(Of("hello"), Of("hello"));
        Assert.NotEqual(Of("hello"), Of("hello "));
    }

    [Fact]
    public void What_cannot_be_read_safely_has_no_fingerprint_and_so_is_never_attached()
    {
        Assert.Null(Of("<MESSAGE TYPE=\"SSO_RESPONSE\"><MSG_DATA></MESSAGE>"));                       // payload not well-formed
        Assert.Null(Of("<!DOCTYPE m [<!ENTITY x \"y\">]><MESSAGE TYPE=\"SSO_RESPONSE\">&x;</MESSAGE>")); // DTDs prohibited
        Assert.Null(ContentFingerprint.Compute("SSO2FMS", null, "not xml"u8.ToArray(), Ignore, 2_000_000));
    }

    [Fact]
    public void The_body_is_never_changed()
    {
        byte[] body = SoapCalls.Build(FmsEndpoint.SSO2FMS, "SendToFMS", Payload);
        byte[] copy = body.ToArray();
        _ = ContentFingerprint.Compute("SSO2FMS", "SSO_RESPONSE", body, Ignore, 2_000_000);
        Assert.Equal(copy, body);
    }
}
