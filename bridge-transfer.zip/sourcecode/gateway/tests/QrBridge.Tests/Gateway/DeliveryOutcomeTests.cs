using System.Net;
using System.Net.Sockets;
using System.Text;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Step 9a, decision D9 (fix plan §4.3): what the receiving gateway does with each outcome of its POST to the real
/// service. Re-post only when the call surely did not arrive; when it may have arrived: Unknown, never posted again.
/// One test per row of the table. A permit (FC2FMS LIFT_CAUTION) crosses from a Corp to a DMZ gateway; the network to
/// the real service is a <see cref="ScriptedHandler"/>, or a real socket on 127.0.0.1.
/// </summary>
public sealed class DeliveryOutcomeTests
{
    /// <summary>Longer than the retry backoff (1 s in the test host): a re-post would have happened by then.</summary>
    private static readonly TimeSpan NoRepostWait = TimeSpan.FromSeconds(2.5);

    private static readonly Dictionary<string, string?> DmzSettings = new()
    {
        ["Gateway:Receiver:TimeoutSeconds"] = "2",
        ["Gateway:Receiver:ConnectTimeoutSeconds"] = "1",
    };

    private static Task<HttpResponseMessage> Respond(int status, string body = "<html>error page</html>") =>
        Task.FromResult(new HttpResponseMessage((HttpStatusCode)status) { Content = new StringContent(body, Encoding.UTF8, "text/xml") });

    private static Task<HttpResponseMessage> Accept() => Respond(200, FakeSoapService.FmsReply("SendToFMS", 0));

    /// <summary>Posts a permit to a Corp gateway, carries it to a DMZ gateway and waits for its Inbox row.</summary>
    private static async Task<InboxMessage> DeliverAsync(Func<HttpMessageHandler>? network, Func<InboxMessage, bool> until,
                                                         Dictionary<string, string?>? dmzSettings = null,
                                                         Func<MessageHeader, MessageHeader>? alter = null)
    {
        string root = GatewayHost.NewRoot();
        try
        {
            await using var corp = GatewayHost.Start(BridgeSide.Corp, root);
            await using var dmz = GatewayHost.Start(BridgeSide.Dmz, root, dmzSettings ?? DmzSettings, receiverHandler: network);
            Guid messageId = await CallCorpAsync(corp);
            await CarryAsync(corp, dmz, messageId, alter);
            return await WaitForAsync(dmz, messageId, until);
        }
        finally
        {
            GatewayHost.DeleteRoot(root);
        }
    }

    private static async Task<Guid> CallCorpAsync(GatewayHost corp)
    {
        using var client = corp.CreateClient();
        var (response, _) = await SoapCalls.PostAsync(client, FmsEndpoint.FC2FMS, "SendToFMS",
            SoapCalls.Build(FmsEndpoint.FC2FMS, "SendToFMS", SoapCalls.Sample("LIFT_CAUTION.TXT")));
        return Guid.Parse(response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());
    }

    private static async Task CarryAsync(GatewayHost from, GatewayHost to, Guid messageId, Func<MessageHeader, MessageHeader>? alter)
    {
        var row = await from.Get<OutboxRepository>().FindAsync(messageId, CancellationToken.None);
        byte[] bytes = row!.MessageBytes;
        var header = MessageSerializer.PeekHeader(bytes);
        if (alter is not null)
        {
            var serializer = from.Get<MessageSerializer>();
            var (original, body) = serializer.Deserialize(bytes);
            header = alter(original);
            bytes = serializer.Serialize(header, body);
        }
        Assert.True(await to.Get<InboxRepository>().AddMessageAsync(header, bytes, CancellationToken.None));
        to.Get<BridgeSignals>().Inbox.Set();
    }

    private static async Task<InboxMessage> WaitForAsync(GatewayHost host, Guid messageId, Func<InboxMessage, bool> condition)
    {
        var inbox = host.Get<InboxRepository>();
        var deadline = DateTime.UtcNow.AddSeconds(20);
        while (true)
        {
            var row = await inbox.FindAsync(messageId, CancellationToken.None);
            if (row is not null && condition(row)) return row;
            if (DateTime.UtcNow > deadline)
                throw new TimeoutException($"Inbox row never reached the expected state (last: {row?.ServiceStatus} " +
                                           $"after {row?.Attempts} tries, HTTP {row?.ServiceHttpStatus}: {row?.ServiceComment}).");
            await Task.Delay(100);
        }
    }

    private static Func<InboxMessage, bool> Is(InboxServiceStatus status) => r => r.ServiceStatus == status;

    // ---------------------------------------------------------------- surely not arrived: re-posted

    public static TheoryData<string> NothingSent => ["dns", "refused", "connect timeout", "tls", "408", "429"];

    [Theory]
    [MemberData(nameof(NothingSent))]
    public async Task A_call_that_surely_did_not_arrive_is_posted_again(string failure)
    {
        var network = new ScriptedHandler((call, _, _) => call > 1 ? Accept() : failure switch
        {
            "dns" => throw new HttpRequestException(HttpRequestError.NameResolutionError, "No such host is known."),
            "refused" => throw new HttpRequestException(HttpRequestError.ConnectionError, "No connection could be made."),
            // What SocketsHttpHandler throws when ConnectTimeout runs out: an OCE wrapping a TimeoutException.
            "connect timeout" => throw new TaskCanceledException("The connection attempt timed out.", new TimeoutException()),
            "tls" => throw new HttpRequestException(HttpRequestError.SecureConnectionError, "The SSL connection could not be established."),
            _ => Respond(int.Parse(failure)),
        });

        var row = await DeliverAsync(() => network, Is(InboxServiceStatus.Done));

        Assert.Equal(2, network.Calls);
        Assert.Equal(2, row.Attempts);
    }

    // ---------------------------------------------------------------- may have arrived: Unknown, never posted again

    public static TheoryData<string, int?, string> MayHaveArrived => new()
    {
        { "timeout after sending", null, "may have processed" },
        { "reset", null, "may have processed" },
        { "reset while reading the answer", 200, "may have processed" },
        { "500", 500, "HTTP 500" },
        { "502", 502, "HTTP 502" },
        { "503", 503, "HTTP 503" },
        { "504", 504, "HTTP 504" },
        { "507", 507, "HTTP 507" }, // D40: another 5xx
    };

    [Theory]
    [MemberData(nameof(MayHaveArrived))]
    public async Task A_call_that_may_have_arrived_is_unknown_and_never_posted_again(string failure, int? httpStatus, string comment)
    {
        var network = new ScriptedHandler(async (_, _, ct) =>
        {
            switch (failure)
            {
                case "timeout after sending":
                    await Task.Delay(Timeout.Infinite, ct);
                    throw new InvalidOperationException("unreachable");
                case "reset":
                    throw new HttpRequestException(HttpRequestError.ResponseEnded, "The response ended prematurely.");
                case "reset while reading the answer":
                    return new HttpResponseMessage(HttpStatusCode.OK) { Content = new StreamContent(new BrokenStream()) };
                default:
                    return await Respond(int.Parse(failure));
            }
        });

        var row = await DeliverAsync(() => network, Is(InboxServiceStatus.Unknown));
        await Task.Delay(NoRepostWait);

        Assert.Equal(1, network.Calls);
        Assert.Equal(httpStatus, row.ServiceHttpStatus);
        Assert.Contains(comment, row.ServiceComment);
    }

    // ---------------------------------------------------------------- refused: not processed, never posted again

    [Theory]
    [InlineData(400)]
    [InlineData(401)]
    [InlineData(403)]
    [InlineData(404)]
    [InlineData(405)]
    [InlineData(415)]
    [InlineData(301)] // D40: redirects are off
    [InlineData(501)] // D40
    [InlineData(505)] // D40
    public async Task A_refusal_is_kept_with_its_http_code_and_never_posted_again(int status)
    {
        var network = new ScriptedHandler((_, _, _) => Respond(status));

        var row = await DeliverAsync(() => network, Is(InboxServiceStatus.Refused));
        await Task.Delay(NoRepostWait);

        Assert.Equal(1, network.Calls);
        Assert.Equal(status, row.ServiceHttpStatus);
        Assert.Contains($"HTTP {status}", row.ServiceComment);
    }

    // ---------------------------------------------------------------- expiry, limits, restarts

    [Fact]
    public async Task An_expired_request_is_not_posted()
    {
        var network = new ScriptedHandler((_, _, _) => Accept());

        var row = await DeliverAsync(() => network, Is(InboxServiceStatus.Expired),
            alter: h => h with { CreatedUtc = DateTime.UtcNow.AddMinutes(-15), ExpiresUtc = DateTime.UtcNow.AddMinutes(-1) });
        await Task.Delay(NoRepostWait);

        Assert.Equal(0, network.Calls);
        Assert.Contains("expired", row.ServiceComment);
    }

    [Fact]
    public async Task Out_of_tries_a_call_that_never_arrived_is_not_delivered_for_an_operator()
    {
        // D25: every try surely failed before anything was sent, so an operator may safely send it again.
        var network = new ScriptedHandler((_, _, _) => throw new HttpRequestException(HttpRequestError.ConnectionError, "refused"));

        var row = await DeliverAsync(() => network, Is(InboxServiceStatus.NotDelivered),
            new Dictionary<string, string?>(DmzSettings) { ["Gateway:MaxAttempts"] = "2" });
        await Task.Delay(NoRepostWait);

        Assert.Equal(2, network.Calls);
        Assert.Contains("2 tries", row.ServiceComment);
    }

    [Fact]
    public async Task A_shutdown_during_a_post_leaves_it_unknown_and_the_next_start_does_not_post_it_again()
    {
        // D41: an app pool recycle while the POST is in flight; the request may already be at the service.
        string root = GatewayHost.NewRoot();
        try
        {
            var posting = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var hanging = new ScriptedHandler(async (_, _, ct) =>
            {
                posting.TrySetResult();
                await Task.Delay(Timeout.Infinite, ct);
                throw new InvalidOperationException("unreachable");
            });
            Guid messageId;
            await using (var corp = GatewayHost.Start(BridgeSide.Corp, root))
            {
                var dmz = GatewayHost.Start(BridgeSide.Dmz, root,
                    new Dictionary<string, string?> { ["Gateway:Receiver:TimeoutSeconds"] = "60", ["Gateway:Receiver:ConnectTimeoutSeconds"] = "5" },
                    receiverHandler: () => hanging);
                messageId = await CallCorpAsync(corp);
                await CarryAsync(corp, dmz, messageId, null);
                await posting.Task.WaitAsync(TimeSpan.FromSeconds(20));
                await dmz.DisposeAsync(); // stops the worker in the middle of the POST
            }

            var next = new ScriptedHandler((_, _, _) => Accept());
            await using var restarted = GatewayHost.Start(BridgeSide.Dmz, root, DmzSettings, receiverHandler: () => next);
            var row = await WaitForAsync(restarted, messageId, _ => true);
            await Task.Delay(NoRepostWait);

            Assert.Equal(InboxServiceStatus.Unknown, row.ServiceStatus);
            Assert.Contains("may have", row.ServiceComment);
            Assert.Equal(0, next.Calls);
        }
        finally
        {
            GatewayHost.DeleteRoot(root);
        }
    }

    // ---------------------------------------------------------------- the real .NET network stack, on 127.0.0.1

    [Fact]
    public async Task A_real_refused_connection_is_recognised_as_nothing_sent()
    {
        var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        int closedPort = ((IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop(); // nothing listens there now

        // Windows answers a closed loopback port only after its SYN retries (~2 s): the connect timeout is longer here,
        // so this proves .NET reports a refusal as HttpRequestError.ConnectionError, not as a timeout.
        var row = await DeliverAsync(null, r => r.ServiceStatus is InboxServiceStatus.Retrying or InboxServiceStatus.NotDelivered,
            new Dictionary<string, string?>
            {
                ["Gateway:Receiver:DefaultBaseUrl"] = $"http://127.0.0.1:{closedPort}",
                ["Gateway:Receiver:TimeoutSeconds"] = "10",
                ["Gateway:Receiver:ConnectTimeoutSeconds"] = "5",
            });

        Assert.Null(row.ServiceHttpStatus);
        Assert.Contains("connection refused", row.ServiceComment);
        Assert.Contains("nothing was sent", row.ServiceComment);
    }

    [Fact]
    public async Task A_real_service_that_never_answers_is_unknown_not_posted_again()
    {
        var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        int port = ((IPEndPoint)listener.LocalEndpoint).Port;
        int connections = 0;
        using var stop = new CancellationTokenSource();
        var silent = Task.Run(async () =>
        {
            var clients = new List<TcpClient>();
            try
            {
                while (true)
                {
                    var client = await listener.AcceptTcpClientAsync(stop.Token);
                    Interlocked.Increment(ref connections);
                    clients.Add(client); // reads nothing back, never answers: the request was sent
                }
            }
            catch (OperationCanceledException) { }
            finally
            {
                clients.ForEach(c => c.Dispose());
            }
        });

        try
        {
            var row = await DeliverAsync(null, Is(InboxServiceStatus.Unknown),
                new Dictionary<string, string?>(DmzSettings) { ["Gateway:Receiver:DefaultBaseUrl"] = $"http://127.0.0.1:{port}" });
            await Task.Delay(NoRepostWait);

            Assert.Equal(1, Volatile.Read(ref connections));
            Assert.Contains("may have processed", row.ServiceComment);
        }
        finally
        {
            stop.Cancel();
            listener.Stop();
            await silent;
        }
    }

    /// <summary>A response body whose connection drops after the headers arrived.</summary>
    private sealed class BrokenStream : Stream
    {
        public override bool CanRead => true;
        public override bool CanSeek => false;
        public override bool CanWrite => false;
        public override long Length => throw new NotSupportedException();
        public override long Position { get => 0; set => throw new NotSupportedException(); }
        public override int Read(byte[] buffer, int offset, int count) => throw new IOException("Connection reset by peer.");
        public override ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken cancellationToken = default) =>
            throw new IOException("Connection reset by peer.");
        public override void Flush() { }
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
        public override void SetLength(long value) => throw new NotSupportedException();
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
    }
}
