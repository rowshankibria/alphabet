using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// G-03, step 8: a caller's retry (same business content, new MSG_ID / GMT_TIME_SENT / RRMsgID) is recognised by its
/// content fingerprint and attached to the first message instead of being queued again (decisions D5, D37, D38).
/// These tests pin the attach mechanics of <see cref="OutboxWriter"/> without a hold: SSO2FMS.SendToFMS is set back to
/// Bridge here (it is RoundTrip since step 10c, D60), so retries are attached only where a test switches RecogniseRetries on.
/// </summary>
public sealed class RetryTests
{
    private const string RecogniseRetries = "Routing:Services:2:Operations:SendToFMS:RecogniseRetries"; // SSO2FMS
    private const string BridgeMode = "Routing:Services:2:Operations:SendToFMS:Mode";

    /// <summary>The SSO_RESPONSE template as one caller attempt: the per-send fields differ, the business content not.</summary>
    private static byte[] Attempt(int attempt, string orderNumber = "36505")
    {
        string payload = SoapCalls.Sample("SSO_RESPONSE.txt");
        payload = Regex.Replace(payload, "MSG_ID=\"[^\"]*\"", $"MSG_ID=\"{456 + attempt}\"");
        payload = Regex.Replace(payload, "GMT_TIME_SENT=\"[^\"]*\"", $"GMT_TIME_SENT=\"02/16/2004 14:0{attempt}:10\"");
        payload = payload.Replace("<MSG_HEADER>", $"<MSG_HEADER>\n\t   <RRMsgID>{9000 + attempt}</RRMsgID>", StringComparison.Ordinal);
        payload = payload.Replace("36505", orderNumber, StringComparison.Ordinal);
        return SoapCalls.Build(FmsEndpoint.SSO2FMS, "SendToFMS", payload);
    }

    private static async Task<(string MessageId, int Code)> PostAsync(HttpClient client, byte[] request)
    {
        var (response, reply) = await SoapCalls.PostAsync(client, FmsEndpoint.SSO2FMS, "SendToFMS", request);
        int code = SoapCalls.ReturnCode(SoapCalls.Result(reply));
        string id = response.Headers.TryGetValues(SenderEndpoint.MessageIdHeader, out var ids) ? ids.Single() : "";
        return (id, code);
    }

    private static async Task<int> OutboxRowsAsync(GatewayHost host)
    {
        await using var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
        return await db.Outbox.CountAsync(m => m.ServiceName == "SSO2FMS");
    }

    private static async Task<T> WithHostAsync<T>(Dictionary<string, string?> settings, Func<GatewayHost, HttpClient, Task<T>> test)
    {
        string root = GatewayHost.NewRoot();
        try
        {
            settings[BridgeMode] = "Bridge";
            await using var host = GatewayHost.Start(BridgeSide.Corp, root, settings);
            using var client = host.CreateClient();
            return await test(host, client);
        }
        finally
        {
            GatewayHost.DeleteRoot(root);
        }
    }

    [Fact]
    public Task A_retry_with_new_ids_is_attached_to_the_first_message() =>
        WithHostAsync(new() { [RecogniseRetries] = "true" }, async (host, client) =>
        {
            var first = await PostAsync(client, Attempt(0));
            var retry = await PostAsync(client, Attempt(1));

            Assert.Equal((first.MessageId, 0), retry); // the same answer, for the same message
            Assert.Equal(1, await OutboxRowsAsync(host));
            Assert.Contains("\"attached\":1", await client.GetStringAsync("/health"));
            return 0;
        });

    [Fact]
    public Task Identical_calls_at_the_same_moment_make_one_row() =>
        WithHostAsync(new() { [RecogniseRetries] = "true" }, async (host, client) =>
        {
            var answers = await Task.WhenAll(Enumerable.Range(0, 12).Select(i => PostAsync(client, Attempt(i % 3))));

            Assert.All(answers, a => Assert.Equal(0, a.Code));
            Assert.Single(answers.Select(a => a.MessageId).Distinct());
            Assert.Equal(1, await OutboxRowsAsync(host));
            return 0;
        });

    [Fact]
    public Task Different_business_content_is_queued_as_a_new_message() =>
        WithHostAsync(new() { [RecogniseRetries] = "true" }, async (host, client) =>
        {
            var first = await PostAsync(client, Attempt(0));
            var other = await PostAsync(client, Attempt(0, orderNumber: "36506"));

            Assert.NotEqual(first.MessageId, other.MessageId);
            Assert.Equal(2, await OutboxRowsAsync(host));
            return 0;
        });

    [Fact]
    public Task The_same_content_after_the_window_is_queued_as_a_new_message() =>
        WithHostAsync(new() { [RecogniseRetries] = "true", ["Gateway:RetryWindowMinutes"] = "30" }, async (host, client) =>
        {
            var first = await PostAsync(client, Attempt(0));
            await using (var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync())
            {
                var row = await db.Outbox.SingleAsync(m => m.MessageId == Guid.Parse(first.MessageId));
                row.CreatedUtc = DateTime.UtcNow.AddMinutes(-31);
                await db.SaveChangesAsync();
            }

            var later = await PostAsync(client, Attempt(1));

            Assert.NotEqual(first.MessageId, later.MessageId);
            Assert.Equal(2, await OutboxRowsAsync(host));
            return 0;
        });

    [Fact]
    public Task A_retry_is_attached_even_when_the_backlog_is_full() =>
        WithHostAsync(new() { [RecogniseRetries] = "true", ["Gateway:MaxBacklog"] = "1" }, async (host, client) =>
        {
            var first = await PostAsync(client, Attempt(0));
            var retry = await PostAsync(client, Attempt(1));
            var other = await PostAsync(client, Attempt(0, orderNumber: "36506"));

            Assert.Equal((first.MessageId, 0), retry); // already queued: not "busy"
            Assert.Equal(("", 1598), other);           // new content: the backlog limit still applies
            return 0;
        });

    [Fact]
    public Task A_bridge_route_queues_the_same_content_twice_and_counts_it() =>
        WithHostAsync(new(), async (host, client) =>
        {
            // D37: Bridge routes do not attach (a too-narrow fingerprint must never answer 0 for a message that is not
            // delivered), but both rows carry the same fingerprint and the repeat is counted as evidence.
            var first = await PostAsync(client, Attempt(0));
            var second = await PostAsync(client, Attempt(1));

            Assert.NotEqual(first.MessageId, second.MessageId);
            await using var db = await host.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
            var fingerprints = await db.Outbox.Select(m => m.ContentFingerprint).ToListAsync();
            Assert.Equal(2, fingerprints.Count);
            Assert.NotNull(fingerprints[0]);
            Assert.Equal(fingerprints[0], fingerprints[1]);
            Assert.Contains("\"sameContentQueued\":1", await client.GetStringAsync("/health"));
            return 0;
        });
}
