using System.ServiceModel;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>
/// The WCF service FC2FMSInterface.svc, exactly as the simulator's generated proxy describes it.
/// </summary>
[ServiceContract(Namespace = "http://tempuri.org/", Name = "IFC2FMSInterface")]
public interface IFC2FMSInterface
{
    [OperationContract(Name = "SendToFMS", Action = "http://tempuri.org/IFC2FMSInterface/SendToFMS",
        ReplyAction = "http://tempuri.org/IFC2FMSInterface/SendToFMSResponse")]
    Task<string> SendToFMSAsync(string sXML);

    [OperationContract(Name = "GetFromFMS", Action = "http://tempuri.org/IFC2FMSInterface/GetFromFMS",
        ReplyAction = "http://tempuri.org/IFC2FMSInterface/GetFromFMSResponse")]
    Task<string> GetFromFMSAsync(string sXML);

    [OperationContract(Name = "EchoString", Action = "http://tempuri.org/IFC2FMSInterface/EchoString",
        ReplyAction = "http://tempuri.org/IFC2FMSInterface/EchoStringResponse")]
    Task<string> EchoStringAsync(string sValue);
}
