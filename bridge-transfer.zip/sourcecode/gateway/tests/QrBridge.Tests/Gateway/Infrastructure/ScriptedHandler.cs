namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>
/// Stands in for the network between the receiving gateway and the real service: each call runs the script with its
/// 1-based number, so a test can fail the way a real network fails (DNS, refused, reset, timeout) and count re-posts.
/// </summary>
public sealed class ScriptedHandler(Func<int, HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> script)
    : HttpMessageHandler
{
    private int _calls;

    public int Calls => Volatile.Read(ref _calls);

    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken) =>
        script(Interlocked.Increment(ref _calls), request, cancellationToken);

    // The host's HttpClientFactory may dispose handlers it created; this one is shared by the test, so it stays usable.
    protected override void Dispose(bool disposing) { }
}
