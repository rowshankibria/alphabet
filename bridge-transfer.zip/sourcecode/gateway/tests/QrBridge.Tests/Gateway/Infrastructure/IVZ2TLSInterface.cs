using System.ServiceModel;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>
/// The ASMX service VZ2TLSInterface.asmx, as an XmlSerializer (ASMX-style) client sees it — exactly as the
/// simulator's generated proxy describes it.
/// </summary>
[ServiceContract(Namespace = "http://tempuri.org/", Name = "TLSInterfaceSoapPort")]
[XmlSerializerFormat]
public interface IVZ2TLSInterface
{
    [OperationContract(Name = "SendToTLS", Action = "http://tempuri.org/SendToTLS", ReplyAction = "*")]
    Task<long> SendToTLSAsync(string XMLMsg);
}
