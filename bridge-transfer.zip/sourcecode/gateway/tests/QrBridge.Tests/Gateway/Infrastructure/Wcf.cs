using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>Creates real WCF client channels that talk to an in-memory gateway.</summary>
public static class Wcf
{
    public static (T Channel, ChannelFactory<T> Factory) Create<T>(GatewayHost host, Binding binding, string path)
    {
        var factory = new ChannelFactory<T>(binding, new EndpointAddress("http://localhost" + path));
        factory.Endpoint.EndpointBehaviors.Add(new InMemoryTransport(host.CreateHandler));
        return (factory.CreateChannel(), factory);
    }

    /// <summary>WCF's HTTP transport lets a binding parameter replace its HttpMessageHandler.</summary>
    private sealed class InMemoryTransport(Func<HttpMessageHandler> createHandler) : IEndpointBehavior
    {
        public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters) =>
            bindingParameters.Add(new Func<HttpClientHandler, HttpMessageHandler>(_ => createHandler()));

        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime) { }
        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher) { }
        public void Validate(ServiceEndpoint endpoint) { }
    }
}
