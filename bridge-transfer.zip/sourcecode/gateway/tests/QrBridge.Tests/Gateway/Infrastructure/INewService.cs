using System.ServiceModel;

namespace QrBridge.Tests.Gateway.Infrastructure;

/// <summary>A service the catalogue has never heard of, called over SOAP 1.2 + WS-Addressing (WSHttpBinding).</summary>
[ServiceContract(Namespace = "urn:qrbridge:test", Name = "INewService")]
public interface INewService
{
    [OperationContract(Name = "DoWork")]
    Task<string> DoWorkAsync(string input);
}
