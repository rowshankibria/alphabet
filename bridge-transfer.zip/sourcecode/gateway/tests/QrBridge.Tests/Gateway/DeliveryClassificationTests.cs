using System.Security;
using System.Text;
using QrBridge.Gateway;
using QrBridge.Gateway.Egress;

namespace QrBridge.Tests.Gateway;

public class DeliveryClassificationTests
{
    private static byte[] Wrapped(string result) => Encoding.UTF8.GetBytes(
        $"""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><SendToFMSResponse xmlns="http://tempuri.org/"><SendToFMSResult>{SecurityElement.Escape(result)}</SendToFMSResult></SendToFMSResponse></s:Body></s:Envelope>""");

    private static byte[] FmsResponse(int code, string message = "") =>
        Wrapped($"<RESPONSE><STATUS><RETURN_CODE>{code}</RETURN_CODE><ERROR_MESSAGE>{message}</ERROR_MESSAGE></STATUS></RESPONSE>");

    [Fact]
    public void Return_code_zero_is_delivered()
    {
        var r = SoapForwarderHttpClient.Classify(200, FmsResponse(0), ResultKind.FmsResponse);
        Assert.Equal(DeliveryVerdict.Delivered, r.Verdict);
        Assert.Equal("RETURN_CODE=0", r.DownstreamResult);
    }

    [Fact]
    public void Non_zero_return_code_is_refused_with_the_reason()
    {
        var r = SoapForwarderHttpClient.Classify(200, FmsResponse(1501, "Invalid card id"), ResultKind.FmsResponse);
        Assert.Equal(DeliveryVerdict.Refused, r.Verdict);
        Assert.Contains("1501", r.DownstreamResult);
        Assert.Contains("Invalid card id", r.DownstreamResult);
    }

    [Theory]
    [InlineData("0", DeliveryVerdict.Delivered)]
    [InlineData("1500", DeliveryVerdict.Refused)]
    public void Numeric_return_codes(string code, DeliveryVerdict expected) =>
        Assert.Equal(expected, SoapForwarderHttpClient.Classify(200, Wrapped(code), ResultKind.ReturnCode).Verdict);

    [Fact]
    public void Soap_fault_is_permanent()
    {
        byte[] fault = Encoding.UTF8.GetBytes("""<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><s:Fault><faultcode>s:Server</faultcode><faultstring>Object reference not set</faultstring></s:Fault></s:Body></s:Envelope>""");
        var r = SoapForwarderHttpClient.Classify(500, fault, ResultKind.FmsResponse);
        Assert.Equal(DeliveryVerdict.Permanent, r.Verdict);
        Assert.Contains("Object reference not set", r.DownstreamResult);
    }

    [Theory]
    [InlineData(408)] // the server gave up waiting for our request: not processed
    [InlineData(429)] // throttled: not processed
    public void Http_408_and_429_were_not_processed_and_are_retried(int status)
    {
        var r = SoapForwarderHttpClient.Classify(status, Encoding.UTF8.GetBytes("<html>Too many requests</html>"), ResultKind.FmsResponse);
        Assert.Equal(DeliveryVerdict.Transient, r.Verdict);
        Assert.Equal(status, r.HttpStatus); // kept for the row's ServiceHttpStatus (D24)
    }

    // D9: a server error without a SOAP fault may come after the service acted on the message. D40: also any other
    // 5xx and anything odd. Never retried: an operator checks first.
    [Theory]
    [InlineData(500)] // an IIS error page, not a SOAP fault
    [InlineData(502)]
    [InlineData(503)]
    [InlineData(504)]
    [InlineData(507)]
    [InlineData(100)]
    public void Server_trouble_without_a_fault_may_have_been_processed(int status)
    {
        var r = SoapForwarderHttpClient.Classify(status, Encoding.UTF8.GetBytes("<html>Service Unavailable</html>"), ResultKind.FmsResponse);
        Assert.Equal(DeliveryVerdict.Unknown, r.Verdict);
        Assert.Equal(status, r.HttpStatus);
        Assert.Contains("may have", r.Summary);
    }

    [Theory]
    [InlineData(400)]
    [InlineData(401)]
    [InlineData(403)]
    [InlineData(404)]
    [InlineData(405)]
    [InlineData(415)]
    [InlineData(301)] // D40: redirects are off, so it was not processed here
    [InlineData(307)]
    [InlineData(501)] // D40: the server cannot process it
    [InlineData(505)]
    public void Configuration_problems_are_permanent(int status) =>
        Assert.Equal(DeliveryVerdict.Permanent, SoapForwarderHttpClient.Classify(status, [], ResultKind.FmsResponse).Verdict);

    [Fact]
    public void Accepted_and_one_way_replies_are_delivered()
    {
        Assert.Equal(DeliveryVerdict.Delivered, SoapForwarderHttpClient.Classify(202, [], ResultKind.FmsResponse).Verdict);
        Assert.Equal(DeliveryVerdict.Delivered, SoapForwarderHttpClient.Classify(200, "not soap"u8.ToArray(), ResultKind.None).Verdict);
    }

    // G-17: the service answered 2xx, so it may well have acted on the message, but we cannot read whether it
    // accepted it. That is neither a success nor safe to retry: Unknown, for an operator (D26).
    public static TheoryData<byte[], ResultKind> UnreadableTwoHundreds => new()
    {
        { Wrapped("OK"), ResultKind.FmsResponse },                                  // no RETURN_CODE
        { Encoding.UTF8.GetBytes("<html>Welcome</html>"), ResultKind.FmsResponse }, // not a SOAP envelope
        { [], ResultKind.FmsResponse },                                             // empty body
        { Wrapped("true"), ResultKind.ReturnCode },                                 // not a number
    };

    [Theory]
    [MemberData(nameof(UnreadableTwoHundreds))]
    public void A_2xx_reply_that_cannot_be_read_is_unknown_not_done(byte[] reply, ResultKind kind)
    {
        var r = SoapForwarderHttpClient.Classify(200, reply, kind);
        Assert.Equal(DeliveryVerdict.Unknown, r.Verdict); // D26: may have been processed, so not retried either
        Assert.Contains("may have been processed", r.Summary);
        Assert.Contains("HTTP 200", r.DownstreamResult);
        Assert.Equal(200, r.HttpStatus);
    }

    [Fact]
    public void A_2xx_reply_too_large_to_read_is_unknown_not_done() =>
        Assert.Equal(DeliveryVerdict.Unknown,
            SoapForwarderHttpClient.Classify(200, [], ResultKind.FmsResponse, replyTruncated: true).Verdict);
}
