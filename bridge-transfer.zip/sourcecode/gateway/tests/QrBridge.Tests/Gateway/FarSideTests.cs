using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using QrBridge.Gateway.Egress;
using QrBridge.Gateway.Ingress;
using QrBridge.Shared;
using QrBridge.Shared.Data;
using QrBridge.Shared.Data.Entities;
using QrBridge.Shared.Data.Repositories;
using QrBridge.Shared.Serialization;
using QrBridge.Shared.Signals;
using QrBridge.Tests.Gateway.Infrastructure;

namespace QrBridge.Tests.Gateway;

/// <summary>
/// Step 10b: what the receiving (far) gateway does before and after posting a round-trip request (decisions D57–D59).
///   - layer 3b: the same content already handled in the window is not posted twice (D58);
///   - queries fail fast when the real service surely cannot be reached (Uncovered-Services §6);
///   - a second Reply after an operator requeue reaches the sending side (D59).
/// Duplicates reach the far side the way they would with two Corp sites: two Corp gateways send the same content.
/// </summary>
public sealed class FarSideTests
{
    private const string RealAnswerContentType = "text/xml; charset=utf-8";
    private static readonly TimeSpan NoPostWait = TimeSpan.FromSeconds(2.5);

    private sealed class Bench(string[] roots, GatewayHost corp, GatewayHost corp2, GatewayHost dmz, ScriptedHandler network)
        : IAsyncDisposable
    {
        public GatewayHost Corp { get; } = corp;
        public GatewayHost Corp2 { get; } = corp2; // a second Corp site with its own qrbridge.db
        public GatewayHost Dmz { get; } = dmz;
        public ScriptedHandler Network { get; } = network;

        public async ValueTask DisposeAsync()
        {
            await Corp.DisposeAsync();
            await Corp2.DisposeAsync();
            await Dmz.DisposeAsync();
            foreach (string root in roots) GatewayHost.DeleteRoot(root);
        }
    }

    private static Bench Start(Func<int, Task<HttpResponseMessage>> realService, Dictionary<string, string?>? dmzSettings = null)
    {
        string root = GatewayHost.NewRoot(), root2 = GatewayHost.NewRoot();
        var network = new ScriptedHandler((call, _, _) => realService(call));
        return new Bench([root, root2],
            GatewayHost.Start(BridgeSide.Corp, root),
            GatewayHost.Start(BridgeSide.Corp, root2),
            GatewayHost.Start(BridgeSide.Dmz, root, dmzSettings, receiverHandler: () => network),
            network);
    }

    private static Task<HttpResponseMessage> Answer(int status, string body) =>
        Task.FromResult(new HttpResponseMessage((HttpStatusCode)status) { Content = new StringContent(body, Encoding.UTF8, "text/xml") });

    private static readonly string RealAnswer = FakeSoapService.FmsReply("GetFromFMS", 0, "withdrawn");

    /// <summary>One caller's call (held 1 s by the test host, so it ends on its own); returns the queued message.</summary>
    private static async Task<Guid> CallAsync(GatewayHost corp, FmsEndpoint endpoint, string operation, string sample, int attempt = 0)
    {
        string payload = Regex.Replace(SoapCalls.Sample(sample), "MSG_ID=\"[^\"]*\"", $"MSG_ID=\"{456 + attempt}\"");
        var (response, _) = await SoapCalls.PostAsync(corp.CreateClient(), endpoint, operation, SoapCalls.Build(endpoint, operation, payload));
        return Guid.Parse(response.Headers.GetValues(SenderEndpoint.MessageIdHeader).Single());
    }

    private static Task<Guid> WithdrawAsync(GatewayHost corp, int attempt = 0) =>
        CallAsync(corp, FmsEndpoint.FC2FMS, "GetFromFMS", "WITHDRAW_RFP.txt", attempt);

    private static async Task CarryAsync(GatewayHost from, GatewayHost to, Guid messageId, Func<MessageHeader, MessageHeader>? alter = null)
    {
        var row = await from.Get<OutboxRepository>().FindAsync(messageId, CancellationToken.None);
        byte[] bytes = row!.MessageBytes;
        var header = MessageSerializer.PeekHeader(bytes);
        if (alter is not null)
        {
            var serializer = from.Get<MessageSerializer>();
            var (original, body) = serializer.Deserialize(bytes);
            header = alter(original);
            bytes = serializer.Serialize(header, body);
        }
        await to.Get<InboxRepository>().AddMessageAsync(header, bytes, CancellationToken.None);
        to.Get<BridgeSignals>().Inbox.Set();
    }

    private static async Task<InboxMessage> WaitForInboxAsync(GatewayHost host, Guid messageId, Func<InboxMessage, bool> condition)
    {
        var deadline = DateTime.UtcNow.AddSeconds(20);
        while (true)
        {
            var row = await host.Get<InboxRepository>().FindAsync(messageId, CancellationToken.None);
            if (row is not null && condition(row)) return row;
            if (DateTime.UtcNow > deadline)
                throw new TimeoutException($"Inbox row never reached the expected state (last: {row?.LightStatus}/{row?.ServiceStatus}, " +
                                           $"{row?.Attempts} tries: {row?.ServiceComment}).");
            await Task.Delay(100);
        }
    }

    private static Func<InboxMessage, bool> Final =>
        r => r.ServiceStatus is not (InboxServiceStatus.Pending or InboxServiceStatus.Delivering or InboxServiceStatus.Retrying);

    /// <summary>The Replies the far side wrote for <paramref name="requestId"/>, oldest first, opened.</summary>
    private static async Task<List<(Guid Id, MessageHeader Header, byte[] Body)>> RepliesAsync(GatewayHost dmz, Guid requestId, int count = 1)
    {
        var deadline = DateTime.UtcNow.AddSeconds(20);
        while (true)
        {
            await using (var db = await dmz.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync())
            {
                var rows = await db.Outbox.AsNoTracking().Where(m => m.Kind == MessageKind.Reply && m.CorrelationId == requestId)
                    .OrderBy(m => m.Sequence).ToListAsync();
                if (rows.Count >= count)
                    return rows.Select(r =>
                    {
                        var (h, b) = dmz.Get<MessageSerializer>().Deserialize(r.MessageBytes);
                        return (r.MessageId, h, b);
                    }).ToList();
            }
            if (DateTime.UtcNow > deadline) throw new TimeoutException($"Fewer than {count} Replies for {requestId}.");
            await Task.Delay(100);
        }
    }

    // ---------------------------------------------------------------- layer 3b (D58)

    public static TheoryData<string, bool, InboxServiceStatus> EarlierOutcomes() => new()
    {
        // what happened to the earlier one, is the later one posted, what the later one ends as
        { "done", false, InboxServiceStatus.Done },           // reuse its answer: never the same command twice
        { "unknown", false, InboxServiceStatus.Unknown },     // it may have been done: an operator decides
        { "refused", true, InboxServiceStatus.Done },         // surely not processed: posting again cannot duplicate
        { "not delivered", true, InboxServiceStatus.Done },
        { "expired", true, InboxServiceStatus.Done },
        { "done, outside the window", true, InboxServiceStatus.Done },
    };

    [Theory]
    [MemberData(nameof(EarlierOutcomes))]
    public async Task The_same_content_from_another_site_is_posted_only_if_the_earlier_one_surely_was_not_processed(
        string earlier, bool posted, InboxServiceStatus laterStatus)
    {
        await using var bench = Start(call => (earlier, call) switch
        {
            ("unknown", 1) => Answer(502, "<html>Bad Gateway</html>"),
            ("refused", 1) => Answer(200, FakeSoapService.FmsReply("GetFromFMS", 1501, "no such permit")),
            ("not delivered", 1) => throw new HttpRequestException(HttpRequestError.ConnectionError, "No connection could be made."),
            _ => Answer(200, RealAnswer),
        }, new Dictionary<string, string?> { ["Gateway:MaxAttempts"] = "1" });

        Guid first = await WithdrawAsync(bench.Corp);
        await CarryAsync(bench.Corp, bench.Dmz, first, earlier == "expired"
            ? h => h with { CreatedUtc = DateTime.UtcNow.AddMinutes(-10), ExpiresUtc = DateTime.UtcNow.AddMinutes(-5) }
            : null);
        await WaitForInboxAsync(bench.Dmz, first, Final);
        int callsBefore = bench.Network.Calls;
        if (earlier.EndsWith("outside the window", StringComparison.Ordinal))
        {
            await using var db = await bench.Dmz.Get<IDbContextFactory<BridgeDbContext>>().CreateDbContextAsync();
            var row = await db.Inbox.SingleAsync(m => m.MessageId == first);
            row.ReceivedUtc = DateTime.UtcNow.AddMinutes(-31);
            await db.SaveChangesAsync();
        }

        Guid second = await WithdrawAsync(bench.Corp2, attempt: 1); // the same business content from the other site
        await CarryAsync(bench.Corp2, bench.Dmz, second);
        var later = await WaitForInboxAsync(bench.Dmz, second, Final);
        await Task.Delay(posted ? TimeSpan.Zero : NoPostWait);

        Assert.Equal(posted ? callsBefore + 1 : callsBefore, bench.Network.Calls);
        Assert.Equal(laterStatus, later.ServiceStatus);
        var reply = (await RepliesAsync(bench.Dmz, second)).Single();
        if (earlier == "done")
        {
            Assert.Equal(ServiceOutcome.Done, reply.Header.Outcome);
            Assert.Equal(Encoding.UTF8.GetBytes(RealAnswer), reply.Body); // the earlier answer, reused byte for byte
            Assert.Contains(first.ToString("D"), later.ServiceComment);
        }
        if (earlier == "unknown")
            Assert.Equal(ServiceOutcome.Unknown, reply.Header.Outcome);
    }

    [Fact]
    public async Task A_bridge_route_posts_the_same_content_twice()
    {
        // D37: a Bridge caller already got RETURN_CODE 0 for each call, so neither side may swallow the second one.
        // FTC2FMS FAULT_CORRELATION is one of the feeds that stay Bridge (D60).
        await using var bench = Start(_ => Answer(200, FakeSoapService.FmsReply("SendToFMS", 0)));

        Guid first = await CallAsync(bench.Corp, FmsEndpoint.FTC2FMS, "SendToFMS", "FAULT_CORRELATION.txt");
        await CarryAsync(bench.Corp, bench.Dmz, first);
        await WaitForInboxAsync(bench.Dmz, first, Final);
        Guid second = await CallAsync(bench.Corp2, FmsEndpoint.FTC2FMS, "SendToFMS", "FAULT_CORRELATION.txt", attempt: 1);
        await CarryAsync(bench.Corp2, bench.Dmz, second);
        await WaitForInboxAsync(bench.Dmz, second, Final);

        Assert.Equal(2, bench.Network.Calls);
    }

    // ---------------------------------------------------------------- fast failure for queries

    [Fact]
    public async Task A_query_whose_service_cannot_be_reached_is_answered_not_delivered_at_once()
    {
        await using var bench = Start(_ => throw new HttpRequestException(HttpRequestError.ConnectionError, "No connection could be made."));

        Guid query = await CallAsync(bench.Corp, FmsEndpoint.FC2FMS, "GetFromFMS", "AUTHORIZE_USERS.txt");
        await CarryAsync(bench.Corp, bench.Dmz, query, h => h with { ExpiresUtc = DateTime.UtcNow.AddMinutes(5) }); // still wanted
        var row = await WaitForInboxAsync(bench.Dmz, query, r => r.ServiceStatus != InboxServiceStatus.Pending &&
                                                                 r.ServiceStatus != InboxServiceStatus.Delivering);

        Assert.Equal(InboxServiceStatus.NotDelivered, row.ServiceStatus); // not Retrying: its caller is waiting
        Assert.Equal(1, bench.Network.Calls);
        Assert.Equal(ServiceOutcome.NotDelivered, (await RepliesAsync(bench.Dmz, query)).Single().Header.Outcome);
    }

    // ---------------------------------------------------------------- a requeued POST interrupted by a crash (D64)

    [Fact]
    public async Task A_requeued_request_found_stuck_is_unknown_not_its_previous_answer()
    {
        var hung = new TaskCompletionSource<HttpResponseMessage>(TaskCreationOptions.RunContinuationsAsynchronously);
        await using var bench = Start(call => call == 1 ? Answer(400, "<html>Bad Request</html>") : hung.Task,
            new Dictionary<string, string?> { ["Gateway:Receiver:TimeoutSeconds"] = "60" });
        try
        {
            Guid request = await WithdrawAsync(bench.Corp);
            await CarryAsync(bench.Corp, bench.Dmz, request);
            await WaitForInboxAsync(bench.Dmz, request, r => r.ServiceStatus == InboxServiceStatus.Refused); // first attempt: Reply "Refused"
            Assert.Equal(1, await bench.Dmz.Get<InboxRepository>().RequeueAsync(request, CancellationToken.None)); // the operator
            bench.Dmz.Get<BridgeSignals>().Inbox.Set();
            await WaitForInboxAsync(bench.Dmz, request, r => r.ServiceStatus == InboxServiceStatus.Delivering); // re-post in flight

            // The gateway dies here; the next start finds the row still Delivering.
            Assert.Equal(1, await bench.Dmz.Get<AnswerWriter>().RecoverStuckAsync(TimeSpan.Zero, CancellationToken.None));

            // The re-post may have reached the service: it must not be settled as the previous attempt's "Refused".
            var row = await bench.Dmz.Get<InboxRepository>().FindAsync(request, CancellationToken.None);
            Assert.Equal(InboxServiceStatus.Unknown, row!.ServiceStatus);
            var replies = await RepliesAsync(bench.Dmz, request, count: 2);
            Assert.Equal(ServiceOutcome.Refused, replies[0].Header.Outcome);
            Assert.Equal(ServiceOutcome.Unknown, replies[^1].Header.Outcome); // the sending side learns it too
        }
        finally
        {
            hung.TrySetResult(new HttpResponseMessage(HttpStatusCode.InternalServerError));
        }
    }

    // ---------------------------------------------------------------- a second Reply after an operator requeue (D59)

    [Theory]
    [InlineData(200, false, OutboxServiceStatus.Answered)] // Unknown, requeued, Done: the Done answer reaches the sending side
    [InlineData(200, true, OutboxServiceStatus.Answered)]  // Done arrives first: the older Unknown never overwrites it
    [InlineData(400, true, OutboxServiceStatus.Refused)]   // the newer answer stays, even when the older one arrives last
    [InlineData(400, false, OutboxServiceStatus.Refused)]
    public async Task A_reply_after_an_operator_requeue_replaces_an_earlier_answer_that_was_not_done(
        int secondStatus, bool reversed, OutboxServiceStatus expected)
    {
        await using var bench = Start(call => call == 1
            ? Answer(502, "<html>Bad Gateway</html>")
            : Answer(secondStatus, secondStatus == 200 ? RealAnswer : "<html>Bad Request</html>"));

        Guid request = await WithdrawAsync(bench.Corp);
        await CarryAsync(bench.Corp, bench.Dmz, request);
        await WaitForInboxAsync(bench.Dmz, request, r => r.ServiceStatus == InboxServiceStatus.Unknown);
        Assert.Equal(1, await bench.Dmz.Get<InboxRepository>().RequeueAsync(request, CancellationToken.None)); // the operator
        bench.Dmz.Get<BridgeSignals>().Inbox.Set();
        var replies = await RepliesAsync(bench.Dmz, request, count: 2);

        // One at a time, each read before the next arrives: the reader takes the lowest sequence first, so carrying both
        // together would not change the order they are used in.
        foreach (var reply in reversed ? replies.AsEnumerable().Reverse() : replies)
        {
            await CarryAsync(bench.Dmz, bench.Corp, reply.Id);
            await WaitForInboxAsync(bench.Corp, reply.Id, r => r.ServiceStatus == InboxServiceStatus.Done);
        }
        var row = await bench.Corp.Get<OutboxRepository>().FindAsync(request, CancellationToken.None);

        Assert.Equal(expected, row!.ServiceStatus);
        Assert.Equal(secondStatus, row.ServiceHttpStatus);
        if (secondStatus == 200)
        {
            Assert.Equal(Encoding.UTF8.GetBytes(RealAnswer), row.ReplyBody);
            var (_, body) = await SoapCalls.PostAsync(bench.Corp.CreateClient(), FmsEndpoint.FC2FMS, "GetFromFMS",
                SoapCalls.Build(FmsEndpoint.FC2FMS, "GetFromFMS",
                    Regex.Replace(SoapCalls.Sample("WITHDRAW_RFP.txt"), "MSG_ID=\"[^\"]*\"", "MSG_ID=\"999\"")));
            Assert.Equal(Encoding.UTF8.GetBytes(RealAnswer), body); // the caller's retry gets the requeued result
        }
    }
}
