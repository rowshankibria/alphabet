using System.Text;
using System.Xml.Linq;
using QrBridge.Gateway;
using QrBridge.Gateway.Ingress.Soap;

namespace QrBridge.Tests.Gateway;

public class SoapReplyWriterTests
{
    private static readonly XNamespace S11 = SoapNamespaces.Soap11;
    private static readonly XNamespace S12 = SoapNamespaces.Soap12;
    private static readonly XNamespace Wsa = SoapNamespaces.Addressing10;

    private static SoapRequest Request(string operation = "SendToFMS", string ns = "http://tempuri.org/",
                                       SoapVersion version = SoapVersion.Soap11, AddressingInfo? addressing = null,
                                       string? action = null) => new()
    {
        Version = version,
        Operation = operation,
        OperationNamespace = ns,
        ParametersUnqualified = false,
        Action = action,
        Addressing = addressing,
    };

    private static XDocument Parse(SoapReply reply) => XDocument.Parse(Encoding.UTF8.GetString(reply.Body));

    [Fact]
    public void Document_result_is_wrapped_and_qualified_like_wcf_expects()
    {
        const string value = "<RESPONSE><STATUS><RETURN_CODE>0</RETURN_CODE></STATUS></RESPONSE>";
        var reply = SoapReplyWriter.Result(Request(), MessageStyle.Document, null, value);
        var doc = Parse(reply);

        XNamespace tns = "http://tempuri.org/";
        var result = doc.Root!.Element(S11 + "Body")!.Element(tns + "SendToFMSResponse")!.Element(tns + "SendToFMSResult")!;
        Assert.Equal(value, result.Value); // escaped on the wire, identical after parsing
        Assert.Equal(200, reply.StatusCode);
        Assert.Equal("text/xml; charset=utf-8", reply.ContentType);
    }

    [Fact]
    public void Rpc_result_uses_an_unqualified_Result_part()
    {
        var reply = SoapReplyWriter.Result(Request(ns: "http://tempuri.org/message/"), MessageStyle.Rpc, null, "0");
        XNamespace m = "http://tempuri.org/message/";
        var wrapper = Parse(reply).Root!.Element(S11 + "Body")!.Element(m + "SendToFMSResponse")!;
        Assert.Equal("0", wrapper.Element("Result")!.Value);
    }

    [Fact]
    public void Soap12_reply_with_addressing_correlates_to_the_request()
    {
        var addressing = new AddressingInfo(SoapNamespaces.Addressing10, "urn:test/INewService/DoWork", "urn:uuid:1", null);
        var reply = SoapReplyWriter.EmptyResponse(Request("DoWork", "urn:test", SoapVersion.Soap12, addressing, "urn:test/INewService/DoWork"));
        var doc = Parse(reply);

        Assert.Equal(S12 + "Envelope", doc.Root!.Name);
        Assert.Equal("application/soap+xml; charset=utf-8", reply.ContentType);
        var header = doc.Root.Element(S12 + "Header")!;
        Assert.Equal("urn:test/INewService/DoWorkResponse", header.Element(Wsa + "Action")!.Value);
        Assert.Equal("urn:uuid:1", header.Element(Wsa + "RelatesTo")!.Value);
        var wrapper = doc.Root.Element(S12 + "Body")!.Element((XNamespace)"urn:test" + "DoWorkResponse")!;
        Assert.False(wrapper.HasElements); // no result: WCF reads null / default / void completion
    }

    [Fact]
    public void Soap11_fault()
    {
        var reply = SoapReplyWriter.Fault(SoapVersion.Soap11, null, senderFault: true, "nope");
        var fault = Parse(reply).Root!.Element(S11 + "Body")!.Element(S11 + "Fault")!;
        Assert.Equal(500, reply.StatusCode);
        Assert.Equal("s:Client", fault.Element("faultcode")!.Value);
        Assert.Equal("nope", fault.Element("faultstring")!.Value);
    }

    [Fact]
    public void Soap12_fault()
    {
        var reply = SoapReplyWriter.Fault(SoapVersion.Soap12, null, senderFault: false, "busy", statusCode: 503);
        var fault = Parse(reply).Root!.Element(S12 + "Body")!.Element(S12 + "Fault")!;
        Assert.Equal(503, reply.StatusCode);
        Assert.Equal("s:Receiver", fault.Element(S12 + "Code")!.Element(S12 + "Value")!.Value);
        Assert.Equal("busy", fault.Element(S12 + "Reason")!.Element(S12 + "Text")!.Value);
    }

    [Fact]
    public void One_way_reply_is_an_empty_202()
    {
        var reply = SoapReplyWriter.Accepted();
        Assert.Equal(202, reply.StatusCode);
        Assert.Empty(reply.Body);
        Assert.Null(reply.ContentType);
    }
}
