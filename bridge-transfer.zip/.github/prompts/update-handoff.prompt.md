---
description: 'Bring handoff.md, the Copilot instructions and the plan up to date after a change'
agent: 'agent'
---

Update the living documents, so the next person (or agent) starts from the truth. First look at what changed
(`git status` and `git diff`, or the files touched in this chat). Then:

1. Run `dotnet test All.slnx` and note the exact test counts.
2. `docs/handoff.md`:
   - §2 history: add one row (date, what was done);
   - §3 decisions log: any new decision, with its reason;
   - §4 what was built and §5 verification: new features, test counts, which manual checks were run and their
     results;
   - §8 known issues: mark fixed ones as fixed (keep the number and say how) and add new ones;
   - §9 next steps and §10 open questions.
3. `.github/copilot-instructions.md`: update the "Known issues" list and "Next steps" (same numbering as HANDOFF §8),
   and the expected test counts in "Build and check". Keep the top part short: Copilot code review reads only the
   first ~4,000 characters.
4. `.github/instructions/*.instructions.md`: remove known-issue bullets that are now fixed, and update the test
   counts.
5. `docs/gateway-to-qrdiode/integration-plan.md`: mark finished steps in §1 and §5, and correct the design text wherever the code
   now differs.
6. `docs/gateway-to-qrdiode/technical-guide.md` and `sourcecode/gateway/docs/gateway.md`: update them when behaviour, configuration or the
   catalogue changed.
7. Check that every relative link you added or changed in the docs resolves.

Write plainly. Say what is built and verified, what is planned, and what was not tried. Show Rowshan a short summary
of the doc changes. Don't commit.
