---
description: 'Do the next open step of the V6.0 review fix (round trip, idempotency, hardening), then update the tracker'
agent: 'agent'
---

You are fixing the findings of the V6.0 design review in a **safety-critical** system: permits and switching orders
for live electrical equipment. A wrong "success" can make a dispatcher believe that a permit exists when it does not.
Work slowly and prove every change with a test.

## Read first (every session)

1. [gateway-review-v6-fix-tracker.md](../../sourcecode/gateway/docs/reviews/gateway-review-v6-fix-tracker.md): the step
   list, the decisions, the design notes and the verification log. **It is the source of truth for progress.**
2. [gateway-review-v6-fix-plan.md](../../sourcecode/gateway/docs/reviews/gateway-review-v6-fix-plan.md): the what and the why
   of each finding.
3. The instructions that apply to the files you will touch: `.github/instructions/bridge-gateway.instructions.md`,
   `tests.instructions.md`, `documentation.instructions.md`.

## Do exactly one step

1. Take the **first** step in the tracker whose status is `Not started` or `In progress`. Don't skip ahead.
2. Check its "Needs" column. If a decision it needs is not `Answered`, **stop** and ask Rowshan (ask_user tool). Do
   not pick an answer yourself.
3. Set the step to `In progress` in the tracker before editing code.
4. Read the code you will change, and its tests, **before** editing. Quote file and line facts in the tracker, not
   memory.
5. Implement only that step. If you find a bug outside it, write it in the tracker's "Found on the way" list; don't
   fix it now.
6. Tests: for every behaviour this step adds or changes, add a test that **fails without the change**. Before writing
   the fix, run it once against the unchanged code and note that it failed. Include the edge cases listed for the
   step.
7. Run `dotnet test All.slnx` (Windows PowerShell 5.1: no `$ErrorActionPreference = "Stop"`; check
   `$LASTEXITCODE`). Everything must pass. Record both counts.
8. Update the tracker:
   - the step's status (`Done` only if every "Done when" item is proven by a test or by a command you ran);
   - the verification log: date, test counts, the new test names;
   - **"Not verified"**: anything you could not prove (real Rapid Restore/FMS behaviour, real timeouts, camera,
     IIS). Never write "works" for something you did not run.
9. Stop and summarise for Rowshan in plain English: what changed, what callers would see differently, what is still
   unproven, and what the next step is. Don't commit or push.

## Rules that must never be broken

- A caller gets `RETURN_CODE 0` (or the route's `Ok`) **only** when the rules agreed in the tracker say so. When in
  doubt, answer non-zero: a false failure leads to the manual fallback; a false success can kill.
- Never deliver the same business action twice on purpose. When the outcome of a delivery is **unknown** (timeout,
  crash after the POST), follow the tracker's decision D9. Never retry silently "just in case".
- Never weaken an existing check (size caps, `SafeXml`, WSDL check, allow-list, direction, replay window, target URL
  from configuration only, no redirects).
- Never log payloads: only service, operation, label, ids, sizes, codes.
- The caller's SOAP body passes through byte for byte. Never parse-and-rewrite it, and never dedupe on `MSG_ID` or
  `RRMsgID`.
- Reply codes are what callers see: add or change them only as decided in the tracker.
- One class per file, settings in `Configurations/Options/`, enums in `Configurations/Enums/Enums.cs`, exceptions in
  `Exceptions/`.
- Entity or header format change: bump `MessageHeader.CurrentVersion` at most once per step and write "delete dev
  databases" in the tracker (no migrations yet, known issue 6).
- If you are not sure what the real system does, **say so and ask**. Don't guess.
