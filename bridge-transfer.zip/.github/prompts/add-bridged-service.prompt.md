---
description: 'Add or change a forwarded SOAP/WCF interface: routes.json, receiver target, sample, tests and docs'
agent: 'agent'
---

Add or change one interface that the gateway stands in for. Services are **configuration, not code**: don't add C#
per service. The user's message names the service. Ask for anything on this list that is missing:

- the caller and the real service, the **path** the caller uses (as the load balancer forwards it), and which side
  the callers are on;
- the operations (SOAP Body element names), and for each one: RoundTrip, `Bridge`, Echo, Unavailable or Reject (see
  "Choosing the mode" below);
- the reply shape: an FMS `<RESPONSE>` document, a number, or nothing (one-way);
- for forwarded operations, the accepted message types (`MESSAGE/@TYPE` or the root element);
- a real request sample;
- the real service's URL on the delivering side.

Background:
- [Technical guide §4.4 and §13](../../docs/gateway-to-qrdiode/technical-guide.md) (route catalogue, reply profiles, how to
  add a service);
- [gateway.md](../../sourcecode/gateway/docs/gateway.md);
- the existing interface documentation in the separate fms-interface-simulator project. Ask Rowshan where it is
  if you need it; the gateway's current contracts are in `sourcecode/gateway/src/QrBridge.Gateway/Contracts/`.

## Choosing the mode

Decide by what the caller does with the answer (decision D60, 24 Nov 2026). When in doubt, ask Rowshan.

| The call… | Mode | When the real answer does not come back within `Gateway:Hold` |
|---|---|---|
| changes state on the other side: a permit, order, card, or a response to one (most `SendTo…`, `IssueOrder`, `CreateCard`…) | `RoundTrip`, `OnHoldTimeout: Pending` (the default) | `RETURN_CODE 1596` "sent, confirmation not yet received"; a retry with the same content attaches to the first message (D56); not posted on the far side after `Gateway:Expiry` (D62) |
| only reads data (a query) | `RoundTrip`, `OnHoldTimeout: Unavailable` | "not available" (1599); never posted after its hold (D54) |
| is a feed whose caller needs nothing but "received" (FSS, Dashboard, SSLog, VR, FTC `FAULT_CORRELATION`, Verizon) | `Bridge` | — (answered `Ok` at once, delivered later; no expiry) |
| needs a live answer that must not cross (polls) | `Unavailable` | — (answered at once) |

Never use `Bridge` for a permit, order or card: its `RETURN_CODE 0` would say "done" when nothing has reached the
other side yet. Until the QrDiode apps carry messages, every `RoundTrip` call waits the full hold and gets its
hold-timeout answer.

## Steps

1. **`sourcecode/gateway/src/QrBridge.Gateway/routes.json`**: add or change the entry under `Routing:Services`, following the existing
   ones.
   - Service fields:
     - `Name`: short and stable, because it is stored in every message;
     - `Description`, `SenderSide`, `Paths`;
     - `Style`: `Document` or `Rpc`;
     - `Contract`: the folder under `QrBridge.Gateway/Contracts/` holding the service's real `service.wsdl` (+ the
       `*.xsd` it imports, for WCF). Copy them unchanged from the fms-interface-simulator's
       `simulator/FMSServiceProxies/Service References/` into `Contracts/Inbound/<folder>/` (callers on CorpNet) or `Contracts/Outbound/<folder>/` (callers in the DMZ) and add a row to `Contracts/README.md`;
     - `ResultElement`: only when the reply element is not `{Op}Result` / `Result`;
     - `OtherOperations`.
   - Each operation: `Mode`, `Reply` (`FmsResponse` or `ReturnCode`), `OneWay`, `AllowedTypes`; for `RoundTrip`
     (calls that need the real answer back) also `OnHoldTimeout` (`Pending` = 1596 for state-changing calls,
     `Unavailable` for read-only queries) and, when one operation carries several kinds of message, `Types`
     (per MESSAGE TYPE). A RoundTrip caller is held for `Gateway:Hold` seconds (appsettings, per service if needed);
     retries are attached only on `Pending` routes (unless the first message surely was not done: then a new message,
     D63). A `Pending` call expires on the far side after `Gateway:Expiry` (600 s; a per-service override in
     `Gateway:Expiry:Services:<Name>` on the side of the callers must stay longer than its hold, or the gateway refuses
     to start); an `Unavailable` (query) route expires with its hold. Every listed
     operation must exist in the WSDL, with the same style, or the gateway refuses to start.
   - Optional: `Priority` (`High`/`Normal`/`Low`, only to override the route's default class), and per service `MaxRequestBytes` (D78: 10 × the largest sample request; bigger calls get 413) and `MaxBacklog`.
   - A **plain HTTP GET** interface (not SOAP, like Registered Tags) uses `"HttpGet": true`: exactly one path, no
     `Contract`, `OtherOperations: Reject`, one operation `"GET"` with `Mode: RoundTrip` (or `Unavailable`) and
     `OnHoldTimeout: Unavailable`, `RecogniseRetries` off, and no `Reply`, `OneWay`, `AllowedTypes` or `Types` —
     start-up refuses anything else (`RouteTable.CheckHttpGet`). The caller gets the real answer, or HTTP 504.

   The same file is deployed on both sides. The gateway serves no WSDL (it only reads `Contracts/` to check
   requests): don't add WSDL serving.
2. **Delivering side:** `Gateway:Receiver:DefaultBaseUrl` plus the same path already covers services on that host.
   Otherwise add `Gateway:Receiver:Targets:<Name>:Url` (and `TimeoutSeconds` if needed) in `appsettings.Dmz.json` or
   `appsettings.Corp.json`. `LockTimeoutMinutes` must stay longer than every timeout plus 30 s, or the gateway refuses
   to start.
3. **Tests** (`sourcecode/gateway/tests/QrBridge.Tests`):
   - Add the sample to `Samples/`.
   - For a new endpoint, add a static `FmsEndpoint` in `Gateway/Infrastructure/SoapCalls.cs`, for example
     `Svc("FMS_X2YInterface", "X2YInterface")`.
   - Add a case in `SenderTests.Cases` (a `RoundTrip` + `Pending` operation expects `1596` with no far side, and the
     request stored verbatim), and update the file count asserted in
     `Every_simulator_template_is_covered`. Add an `InlineData` with the operation's expected mode (`RoundTrip` for a
     permit, order or card, `Bridge` for a feed) to
     `RouteTableTests.Shipped_catalogue_holds_permits_orders_and_cards_and_keeps_feeds_bridged`.
   - If a WCF client calls the service, add a real-WCF-client test like those in `WcfClientTests`.
4. Run `dotnet test All.slnx`.
5. **Docs:** update the catalogue in `docs/gateway-to-qrdiode/technical-guide.md`, `sourcecode/gateway/docs/gateway.md` if it lists services, and
   `docs/handoff.md` (what changed, and any open question it answers or raises).

Never route by SOAPAction alone, and never re-serialize the caller's request. Ask Rowshan before changing reply codes
or anything existing callers already depend on. Don't commit.
