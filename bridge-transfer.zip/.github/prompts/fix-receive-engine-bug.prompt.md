---
description: 'Fix the ReceiveEngine stuck-session bug (Integration Plan step 1), with regression tests'
agent: 'agent'
---

Fix known issue 1: after one partly received QR session, the receiver silently ignores every later session until it
is restarted. Design: [Integration Plan §2.1](../../docs/gateway-to-qrdiode/integration-plan.md). Read
`sourcecode/qrdiode/src/QrDiode.Core/Pipeline/ReceiveEngine.cs` and `sourcecode/qrdiode/tests/QrDiode.Core.Tests/LiveStreamTests.cs` first.

## The cause

`FeedManifest` starts with `if (_manifest is not null) return FeedResult.Ignored;`. Once the engine is locked on a
session, every other manifest is ignored. If the camera misses part of session A and the sender moves on, the engine
waits for A forever.

## Required behaviour (`ReceiveEngine`)

1. **Not locked on a session: unchanged.** All existing tests must still pass (for example
   `UnverifiedRejections_StillSurfaceEveryTime` and `CarouselTail_AfterReset_IsIgnored_NotReJudged`).
2. **Locked, same session** (the frame's `SessionTag` equals `_sessionTag`): `Ignored`, with no parsing or signature
   work. The carousel repeats the manifest all the time.
3. **Locked, different session:** run the same checks in the same order as today: parse → signature from a trusted
   sender → addressed to this receiver → not already settled → anti-replay `Check` returns `Fresh`.
   - **Any failure returns `FeedResult.Ignored`, never `Rejected`, and leaves the current session untouched.**
     Reason: the Receiver window calls `engine.Reset()` after every `Rejected` result (`HandleRejection` in
     `sourcecode/qrdiode/src/QrDiode.Receiver/MainWindow.xaml.cs`). A `Rejected` here would let a forged or replayed manifest knock out
     the session in progress. A replay failure may still add the candidate to `_settled`, as today.
   - **All checks pass:** abandon the current session. Add its id to `_settled`, capture an `AbandonedSession` record
     (session id, filename, sender signing key id, counter, `K`, decoded source blocks, unique symbols received),
     clear the partial state, then lock onto the new session exactly as the not-locked path does and return
     `ManifestAccepted`.
4. Report it with `public event Action<AbandonedSession>? SessionAbandoned`. **Raise it after leaving `_lock`**
   (capture inside the lock, invoke after it), so a handler can never deadlock or re-enter the engine under the lock.
5. Don't change the verification order, what is committed to the replay guard, or `Reset()`.

## Receiver UI (`sourcecode/qrdiode/src/QrDiode.Receiver/MainWindow.xaml.cs`)

- Subscribe to `SessionAbandoned` where `_engine` is created. The event arrives on the camera thread: marshal it with
  `Dispatcher.BeginInvoke` (never `Invoke`). **Don't call `engine.Reset()`** in the handler: the engine is already on
  the new session.
- Add `InboxOutcome.Incomplete` (`Inbox/InboxEntry.cs`) and handle it in every `switch` over `InboxOutcome`. Search
  for `InboxOutcome.`: `Inbox/InboxEntry.cs`, `Storage/ArchiveRecord.cs`, `Storage/SqliteJournal.cs`,
  `MainWindow.xaml.cs`, `MainWindow.Archive.cs`. Use the warning pill.
- Add an inbox row: "Incomplete: `{filename}` was NOT received ({decoded}/{K} blocks). It must be re-sent." Write an
  audit event `receive.abandoned` with session, file, counter and progress, in the same `_audit.Append` style as
  `receive.rejected`.

## Tests: new `sourcecode/qrdiode/tests/QrDiode.Core.Tests/SessionAbandonTests.cs`

Copy the fixture set-up of `LiveStreamTests` (trust store, sender/receiver keys, `SendSession.Create`,
`session.Carousel()`). Cover:

1. Partial session A (its manifest and some symbols, not complete), then session B's carousel → B completes,
   `SessionAbandoned` is raised once with A's session id, and A's frames after that are `Ignored`.
2. While locked on A, a manifest from an untrusted sender (an `EphemeralEndpointKeys` not in the trust store) →
   `Ignored`, no event, and A still completes when its frames continue.
3. While locked on A, a replayed manifest (a session already completed against the same `InMemoryReplayGuard` by
   another engine) → `Ignored`, no event, and A still completes.
4. Repeats of A's own manifest while locked → `Ignored`.

## Done when

`dotnet test sourcecode\qrdiode\tests\QrDiode.Core.Tests` and `dotnet test All.slnx` pass (75 + the new tests). Then run the
[update-handoff](update-handoff.prompt.md) prompt: known issue 1 resolved, new test counts, Integration Plan step 1
done. Explain the change to Rowshan in plain English. Don't commit.
