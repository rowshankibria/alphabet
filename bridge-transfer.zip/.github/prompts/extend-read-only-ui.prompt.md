---
description: 'Change the read-only web UI (gateway folder Ui/): a page, a column, a field, a filter or the look'
agent: 'agent'
---

Change the read-only web UI that the gateway serves under `/qrbridge-ui`. The user's message says what to show or
change. Read first:

- [read-only-ui.md](../../sourcecode/gateway/docs/reference/read-only-ui.md): how the UI is built (with Angular analogies)
  and where each kind of change goes;
- [read-only-ui.instructions.md](../instructions/read-only-ui.instructions.md): the rules that must stay true.

## Before you start

- If the change would let a user **change** anything (requeue, acknowledge a gap, archive, resend, edit settings),
  stop and ask Rowshan: the UI is read-only by decision 48, and an action on an `Unknown` message can duplicate a permit.
- If it needs something only the gateway knows (routes, delivery URLs, monitors, counters), add a read-only member to
  `sourcecode/gateway/src/QrBridge.Gateway/Ui/UiGatewayInfo.cs`, the UI's one way to the rest of the gateway. Never
  give a page or a UI class a writer (`OutboxWriter`, a repository, `IDbContextFactory<BridgeDbContext>`…):
  `UiReadOnlyTests.No_ui_class_depends_on_code_that_writes` will fail.
- If it needs data from `qrbridge.db`, read it in `Ui/Data/MessageQueries.cs` through `ReadOnlyBridgeDb` only.

## Steps

All paths below are in `sourcecode/gateway/src/QrBridge.Gateway/`.

1. Data: add the query or field to `Ui/Data/MessageQueries.cs` (and its records at the bottom of that file).
2. Page: change the `.cshtml` (markup) and its `.cshtml.cs` (PageModel) in `Ui/Pages/`. Shared pieces are partials in
   `Ui/Pages/Shared/`. Values through `@value` only (Razor encodes them); no `Html.Raw`, no inline `<script>` or
   `style="…"` (the content security policy blocks them). New routes start with `/qrbridge-ui/`.
3. Look: classes and colour tokens in `Ui/Assets/ui.css` (keep the light tokens and both dark blocks in step);
   behaviour in `Ui/Assets/ui.js` with `textContent`, never `innerHTML`.
4. Tests in `sourcecode/gateway/tests/QrBridge.Tests/Ui/`: assert what a person reads (`UiBrowser.Text`), add a case
   to `UiReadOnlyTests.Looking_at_every_page_changes_no_row` for a new page, and keep `UiRoutingTests` green (every other
   GET still 405).
5. Run `dotnet test sourcecode\gateway\tests\QrBridge.Tests --filter "FullyQualifiedName~QrBridge.Tests.Ui"`, then
   `dotnet test All.slnx`.
6. Try it on sample data (read-only-ui.md §2: set `QRBRIDGE_DEMO_ROOT` and run `UiDemoDataTests`), then `dotnet run --project sourcecode\gateway\src\QrBridge.Gateway --launch-profile "Gateway (Corp)"`, open
   `http://localhost:5080/qrbridge-ui`, sign in, and check both themes (the moon/sun button).
7. Docs: update `read-only-ui.md` if the structure changed, and the test count in `docs/handoff.md` §5 and
   `.github/copilot-instructions.md`.

Never log or show a payload outside Razor's encoding. Don't commit.
