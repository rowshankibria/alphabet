---
description: 'Read-only web UI: Razor Pages in the gateway project (Ui/), served under /qrbridge-ui'
applyTo: 'sourcecode/gateway/src/QrBridge.Gateway/Ui/**,sourcecode/gateway/src/QrBridge.Gateway/Initializer/UiRegistration.cs,sourcecode/gateway/tests/QrBridge.Tests/Ui/**'
---

# The read-only web UI (`QrBridge.Gateway/Ui/`)

Guide (structure, Angular analogies, how to add a page or a field): `sourcecode/gateway/docs/reference/read-only-ui.md`.
Decision 48 in `docs/handoff.md`.

## What it is

Razor Pages inside the gateway project (folder `Ui/`, `RootDirectory = "/Ui/Pages"`): one project, one publish, one IIS
site, one process. Pages under `/qrbridge-ui`, behind one login (`Ui:Username` / `Ui:Password`, default admin / admin).
It shows the Outbox and Inbox of `qrbridge.db` in plain words: header fields, the service URL, the SOAP request, the FMS
message inside `sXML`/`XMLMsg` (unescaped, indented), the real service's answer, both status groups. `Ui:Enabled =
false` maps nothing. Wiring: `Initializer/UiRegistration.cs` (`AddGatewayUi`, `MapGatewayUi`).

## Invariants — keep them

- **Read-only.** All database access goes through `Ui/Data/ReadOnlyBridgeDb` (SQLite `Mode=ReadOnly`: SQLite itself
  refuses writes) and `Ui/Data/MessageQueries`. The rest of the gateway is reached only through `Ui/UiGatewayInfo`
  (it builds its repositories on the read-only connection, and uses the forwarder only to resolve a URL). Never give a
  UI class `OutboxWriter`, `AnswerWriter`, `SenderEndpoint`, `SoapForwarderHttpClient`,
  `IDbContextFactory<BridgeDbContext>` or a repository: `UiReadOnlyTests.No_ui_class_depends_on_code_that_writes`
  fails the build's tests if you do (the UI shares the project, so only that test keeps it away). Never add a POST that
  changes data (requeue, acknowledge a gap, archive, resend) without asking Rowshan: an `Unknown` requeue can
  duplicate a permit.
- **Everything under `/qrbridge-ui`** (`UiPaths.Prefix`, in `Configurations/Helpers/Utility.cs`). Every page has an
  absolute `@page "/qrbridge-ui/…"` route. Every other GET of the gateway must still get 405;
  `StartupChecks.CheckUiPaths` refuses a route in `routes.json` under the prefix. No `wwwroot`, no static-file
  middleware: CSS/JS are embedded resources (`Ui/Assets/`, see the csproj) served by `Ui/Pages/Assets`.
- **Payloads are untrusted and in clear.** Show them only through Razor's encoding (`@value`), never `Html.Raw`, never
  `innerHTML` in `ui.js` (use `textContent` / text nodes). Parse XML only through `SafeXml` (in `QrBridge.Shared`).
  Never log a payload; log only user name, address, ids.
- **Security headers stay** (`Ui/Security/UiSecurityHeaders`): `no-store`, `X-Frame-Options: DENY`, and a content
  security policy that allows only the UI's own script and style. So: no inline `<script>`, no `style="…"` attributes,
  no CDN, no web fonts. CSS in `Ui/Assets/ui.css`, script in `Ui/Assets/ui.js` (theme picking in `Ui/Assets/theme.js`).
- **Login:** own cookie scheme and policy (`Ui/Security/UiAuthentication`), cookie path `/qrbridge-ui`, no default
  scheme and no fallback policy — the SOAP endpoints and `/health` must stay anonymous. Return URLs only to UI pages
  (`UiPaths.IsSafeReturnUrl`).
- **Themes:** every colour is a token at the top of `ui.css` (light in `:root`, dark in `[data-theme="dark"]` and the
  `prefers-color-scheme` block — keep both dark blocks in step). Tones: `tone-good/info/warn/bad/neutral`.
- **Status words** come from `Ui/Display.cs` (`Display.Light` / `Display.Service`): the real enum names plus a
  plain-words meaning. A new status in `QrBridge.Shared` needs a line there.
- **Say "QrData", never "light", on the pages** (Rowshan, 26 Nov): the first status group (`LightStatus` columns) is
  labelled "QrData" everywhere a person reads it. Code names (`LightStatus`, `Display.Light`, the `light=` query) stay.
  The theme switch keeps "light / dark".
- **A detail page shows the whole round trip** (Rowshan, 26 Nov): after the request and the response, one section per
  other message of the round trip (a Request's Reply and Receipts; a Reply's Request and Receipt; a Receipt's Request
  or Reply), built by `MessageQueries.AddArrivedAnswersAsync` / `AddSentAnswersAsync` / `AddArrivedAnsweredAsync` /
  `AddSentAnsweredAsync` as `RoundTripPart`s; then this message's facts and the Related messages table, both inside the DETAILS band.
- **Bands on the detail page** (Rowshan, 26 Nov): REQUEST (blue) / RESPONSE (purple) / DETAILS (grey), each a
  `<details class="band …" open>` whose `<summary class="band-head">` strip folds it (no script; `ui.css`, theme tokens only). Request content and a part of kind Request go under REQUEST; the
  response, Replies, Receipts and `ResponseNotes` under RESPONSE. Keep that split when adding to the page.
- **Plain words for people** (Rowshan, 26 Nov): every text box and every round-trip section has one plain line saying
  what it is (`CodeBlock.Explain`, `RoundTripPart.Explain`). A Receipt is "**it arrived safely**", a Reply
  "**what the real service did**" (`MessageQueries.AnswerText`, `Display.Meaning` for the kind chips' tooltip). Avoid transport words
  such as "air" on the pages; say "send".
- `"page"` is a reserved Razor Pages route value: the list's page number is the query `p`, the page size `size`.
- **A page whose browser left stops quietly:** pass the handler's `CancellationToken` to every query, and wrap the
  loading in `catch (OperationCanceledException) when (ct.IsCancellationRequested) { return new EmptyResult(); }`
  (handlers return `Task<IActionResult>`, `Page()` at the end). Without it, a click or filter change during a load
  throws `TaskCanceledException` out of the page, and Visual Studio stops on it (`UiPagesTests.A_page_the_browser_left_stops_quietly`).
- **Paging stays in the database** (filter and search in SQL, then `Skip`/`Take`): never read a whole table into memory.
- **Times:** the database keeps UTC; show every time through `UiTime.Format` (`Ui:TimeZone`, Eastern by default),
  with UTC in the tooltip (`Display.Utc`). **US format, 12-hour clock** (Rowshan, 26 Nov): `11/25/2026 05:05:39 PM EST`
  (`Display.UsDateTime`). Reasons the gateway saves for operators that contain a time use the same layout, in UTC. Don't change columns to `DateTimeOffset` (decided 25 Nov 2026: SQLite has no such type and
  EF Core cannot order or compare it there; see read-only-ui.md §7).
- **Not shown on purpose** (Rowshan, 25 Nov): priority, sequence number, caller address, catalogue fingerprint, the
  overview's missing-messages and this-gateway sections. Ask before showing them again.

## Style

- Razor Pages with a PageModel per page (`X.cshtml` + `X.cshtml.cs`), like an Angular component's template + class.
  Shared markup in `Ui/Pages/Shared/_*.cshtml` partials. No JavaScript framework, no MVVM, no new packages without asking.
- The gateway's file layout: one class per file, records in their class's file; `UiOptions` in
  `Configurations/Options/`, the UI's enums (`MessageBox`, `Tone`) in `Configurations/Enums/Enums.cs`, `UiPaths` in
  `Configurations/Helpers/Utility.cs`; everything else in `Ui/` (namespaces `QrBridge.Gateway.Ui.*`).

## Tests

`sourcecode/gateway/tests/QrBridge.Tests/Ui/`: `UiBrowser` (signs in through the form with its antiforgery token),
`UiCorpFixture` (a Corp gateway with one stored feed), `TwoGatewayBench` for a full round trip. Assert what a person
reads (`UiBrowser.Text` decodes the HTML) and that it stays read-only (`UiReadOnlyTests`). Run
`dotnet test sourcecode\gateway\tests\QrBridge.Tests --filter "FullyQualifiedName~QrBridge.Tests.Ui"`, then `dotnet test All.slnx`.
