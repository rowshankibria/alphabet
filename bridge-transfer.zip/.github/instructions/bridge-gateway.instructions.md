---
description: 'Generic SOAP gateway (IIS) and shared data layer: sender, receiver, route catalogue, envelope, SQLite'
applyTo: 'sourcecode/gateway/src/QrBridge.Gateway/**,sourcecode/gateway/src/QrBridge.Shared/**'
---

# QrBridge.Gateway and QrBridge.Shared

How it works: `docs/gateway-to-qrdiode/technical-guide.md` (§4 = how each WCF problem is solved). Quick reference: `sourcecode/gateway/docs/gateway.md`.

## Invariants — keep them

- **Controllers stay thin** (`Controllers/`): `SenderSoapController` (POST and GET `{**path}`) only calls `SenderEndpoint`.
  Never `[ApiController]`, never bind parameters (`[FromBody]` would parse or reject the raw SOAP body; automatic 400s
  would be JSON, not SOAP faults). GETs: `HealthController` (`/health`) and **one** plain-GET route, Registered Tags
  (decision D18, `"HttpGet": true` in `routes.json`; `SenderEndpoint.HandleGetAsync`); the read-only UI's Razor Pages
  under `/qrbridge-ui` (decision 48, folder `Ui/`, `Initializer/UiRegistration.cs`; rules in
  `read-only-ui.instructions.md`); every other GET/HEAD gets 405.
  Don't add WSDL or help-page serving — the callers (per the fms-interface-simulator) never download a WSDL.
- **Plain GET route** (D18, D69–D72): an `HttpGet` service has one path and one operation `"GET"`, RoundTrip (or
  Unavailable) with `OnHoldTimeout: Unavailable`, no Contract/profile/types (start-up refuses anything else). The call
  crosses as `PayloadFormat.HttpGet` (empty body, no Content-Type/SOAPAction; the serializer refuses anything else) and
  is held like a query; the caller gets the real answer byte for byte (Done/Refused with an answer) or **HTTP 504**
  `text/plain`. A query string → 400, nothing queued. The far side replays it as a GET, and rejects an HttpGet message for
  a SOAP route or a SOAP message for the GET route. Never let a GET carry a query string, body or another path across.
- **Sender part order** (`Ingress/SenderEndpoint.cs`): body cap (413) → `SoapRequest.TryParse` (400) →
  `PayloadInspector.Inspect` (MESSAGE/@TYPE) → `RouteTable.Resolve(path, operation, type)` → mode (Reject / Echo /
  Unavailable answer locally) →
  WSDL check (`ContractCatalog.Check`, SOAP fault) → allow-list →
  `OutboxWriter.EnqueueAsync` (same-content check in the retry window: attach on `RecogniseRetries` routes, D37 —
  never on `MSG_ID`/`RRMsgID`; then backlog check + commit, all in one write transaction) → **then** reply. Never reply OK before the commit; a failure
  before it must return a SOAP fault ("NOT accepted") or the profile's Busy/Rejected value.
- **The hold** (RoundTrip, decisions D49–D56): after the commit, register a waiter (`WaiterRegistry`), then read the
  Outbox row (`OutboxRepository.FindStateAsync`), then wait — woken by `AnswerReader` or every 2 s (the database is
  the truth). Answer per D50: Done/Refused **with** the real answer → that answer byte for byte; Unknown or no answer
  carried → the route's hold-timeout answer (`Pending` 1596, or "not available"); Expired/NotDelivered/Rejected →
  "not available". Hold runs out (`Gateway:Hold`) or the row is light `Failed` (D55) → hold-timeout answer. Never
  pass on anything else as success. A query (`OnHoldTimeout: Unavailable`) gets `ExpiresUtc` = now + hold (D54) and
  is never attached to an earlier call (D56); a state-changing call (`Pending`) gets now + `Gateway:Expiry` (600 s,
  D62; start-up refuses an expiry not longer than the hold). A retry of a message that surely was not done
  (`Expired`, `NotDelivered`, `Rejected`) is queued as a new message, never attached (D63). A caller that hangs up
  leaves its message queued. **Which routes:** permits, orders, cards and their responses are RoundTrip + `Pending`
  (D60, `IssueWorkPermit` included, D61); feeds stay `Bridge` (FMS2FSS, FMS2Dashboard, FMS2SSLog, FMS2VR, FTC
  `FAULT_CORRELATION`, VZ2TLS). Never switch a state-changing route back to `Bridge` without asking Rowshan: `Bridge`
  answers 0 before anything was delivered.
- **Routing:** service by request **path** (case-insensitive, normalized), operation by the **first SOAP Body element**
  — not by SOAPAction (five legacy endpoints share one SOAPAction). An operation's `Types` can set `Mode`,
  `OnHoldTimeout` and `FingerprintIgnore` per MESSAGE/@TYPE (exact match); unset values follow the operation.
- **Caller retries** (decisions D5, D37, D38): `ContentFingerprint.Compute` hashes a read-only copy of the body (via
  `SafeXml`, whitespace kept, SOAP headers out, the route's `FingerprintIgnore` names removed). Same fingerprint
  within `Gateway:RetryWindowMinutes` → attached to the first message only where the route's `RecogniseRetries` is on
  (default: RoundTrip routes whose `OnHoldTimeout` is `Pending`, D56); elsewhere queued again and counted on `/health`. Never attach on `MSG_ID` / `RRMsgID`
  alone, and never turn it on for a `Bridge` route without asking Rowshan: a too-narrow fingerprint would answer 0 for
  a message that is then never delivered.
- **Verbatim:** the body is stored exactly; `MessageHeader` keeps the SOAPAction header as received (quotes included) and the
  Content-Type. The Receiver part replays them unchanged; only a WS-Addressing `To` header may be rewritten.
- **Replies** (`Ingress/Soap/SoapReplyWriter.cs`) follow WCF/ASMX conventions: `{Op}Response` / `{Op}Result` in the operation
  namespace (document), unqualified `Result` (RPC), same SOAP version, WS-Addressing `Action` = request action +
  "Response" and `RelatesTo`. Values come from reply profiles in `routes.json` — don't hard-code reply XML in C#.
- **Receiver part delivery** (`Egress/SoapForwarderHttpClient.cs`): target = `Gateway:Receiver:Targets[service].Url` or `DefaultBaseUrl` + original
  path; never from the message; no redirects. **Decision D9: re-post only when the call surely did not arrive.**
  `Classify` / `ForwardAsync` → Inbox `ServiceStatus`: SOAP fault (any status) → `Refused`; 202 → `Done`; 2xx →
  `Done` when the return code is 0, `Refused` when it is not, `Unknown` when the expected result can't be read;
  DNS failure, connection refused (`HttpRequestError.ConnectionError`), connect timeout
  (`Gateway:Receiver:ConnectTimeoutSeconds`, shorter than every delivery timeout), TLS failure, HTTP 408/429 →
  `Retrying` + backoff (`NotDelivered` after `MaxAttempts`, D25; a round-trip **query** — `OnHoldTimeout: Unavailable`
  — is `NotDelivered` at once, its caller is waiting: fast failure); timeout after sending, reset / response ended
  early, HTTP 500/502/503/504, any other 5xx, 1xx or odd status → `Unknown` (D40); other 4xx, 3xx, 501, 505 →
  `Refused`. A row still `Delivering` after a crash, or a shutdown during the POST → `Unknown` (D41). A request past
  its `ExpiresUtc` → `Expired`, not posted. No Receiver target → `NotDelivered` (D25). **Layer 3b** (D58, routes that
  recognise retries): another Request with the same `ContentFingerprint` arrived within `Gateway:RetryWindowMinutes`
  and is `Done` → not posted, `Done` with its Reply's answer reused (`AnswerWriter.ReuseDoneAsync`); `Unknown` or
  `Delivering` → not posted, `Unknown`; `Refused`/`NotDelivered`/`Expired` → posted normally. `Refused`, `Unknown`,
  `Expired` and `NotDelivered` are never re-posted automatically; an operator decides. The real service's HTTP code
  goes in `ServiceHttpStatus`, the probable reason in `ServiceComment`. Never add a re-post for a "may have arrived"
  outcome: that is how duplicate permits happen.
- **Worker checks** (`Egress/ArrivalChecks.cs`, used by `InboxWorker` and `AnswerReader`): envelope checksum passes; MessageId/service/operation/type columns
  and `Kind`/`CorrelationId`/`SequenceRunId`/`ContentFingerprint`/`ExpiresUtc`/`Priority` match the header; the header's `CatalogFingerprint` equals this side's
  `RouteTable.CatalogFingerprint` (decision D31: **both sides run the same `routes.json`**); direction is this side's
  inbound; payload is `RawSoap` (or `HttpGet`, only for the `HttpGet` route; `InboxWorker.Plan` checks the match); created within `ReplayWindowDays` and not more
  than `MaxClockSkewMinutes` in the future. **Old messages by number** (`CheckAsync`, step 17, D84), on a row's
  **first** check only (not yet `Verified`; a row posted again after a "surely not sent" failure, or requeued, may itself
  have moved the watermark): its (direction, `SequenceRunId`, `Sequence`) already held by **another** message that
  arrived earlier → `Rejected` ("already used", a restored or copied `qrbridge.db`); its number ≤ the run's
  `SequenceWatermark.ContiguousTo` with no other row holding it → `Rejected` ("an old message shown again", the original
  was archived), whatever its date. The date window stays as a second check. When everything passes, `ArrivalChecks`
  marks the row `Verified` (`InboxWorker` no longer does). Never use "lower than the newest Done = old": answers jump
  the queue (step 14) and re-airs (step 11) make lower numbers arriving later normal. `InboxWorker` also needs `Kind = Request` (**a Receipt, Reply or Heartbeat is never
  posted to a service**), a listed service with its `SenderSide` on the **other** side and the
  operation — or its message type, `RouteTable.ModeOf` — in `Bridge` or RoundTrip mode; an unlisted service needs `Routing:AcceptUnlisted`.
- **Answers over the opposite lane** (`Egress/AnswerWriter.cs`, decisions D43–D47): every final outcome of a Request
  (Done, Refused, Unknown, Expired, NotDelivered, and Rejected) sends a **Reply** (header v5 `Outcome`,
  `ServiceHttpStatus`, `ServiceComment`; body = the real answer byte for byte, left out above `Bridge:MaxPayloadBytes`)
  — **written before the Inbox row is marked**, so a row found Delivering after a crash adopts its Reply's outcome
  (`RecoverStuckAsync`; only a Reply written after the row's current claim, `LockedUtc` — an older one belongs to an
  attempt before an operator requeue, D64), else Unknown with an Unknown Reply. Every arrived message is owed a **Receipt**
  (`ReceiptDueUtc`, set again when the same `MessageId` arrives twice); `ReceiptWorker` sends them. A Receipt never gets
  a Receipt. Receipts and Replies go through `OutboxWriter` (one way in), are never refused for a full Outbox, never
  counted in `MaxBacklog`, and never posted to a service. On the sending side `Ingress/AnswerReader.cs` reads them
  (step 10a): after the arrival checks, a Receipt sets the Outbox row light `Received`; a Reply must answer a Request
  of this side for the same service and operation, sets its service group through `MarkAnsweredAsync` (the first
  answer, or a newer one unless `Answered`, D59) and wakes the held callers; the Inbox row then ends `Done`, or `Rejected` when a check failed.
  `AnswerReader` also consumes **Heartbeats** (after the same checks → `Done`, "the far side is alive"); a Receipt or
  Reply naming a Heartbeat is `Rejected`, like one naming a Receipt.
- **Far side and Heartbeat messages** (`Egress/FarSideMonitor.cs`, step 17, D80–D83): when this side has queued nothing
  (any kind) for `Gateway:HeartbeatMinutes` (5; 0 = off; counted from start-up at the latest), `MaintenanceWorker`
  queues a `Heartbeat` message through `OutboxWriter` — but not while an earlier one still waits to be aired (Outbox
  light `Pending`/`Sending`, `OutboxRepository.AnyHeartbeatWaitingAsync`), so they never pile up while the light is
  down and then go out ahead of real messages. It takes a sequence number on its lane, so a lost **last**
  message becomes a gap once the Heartbeat after it arrives. No Receipt is owed for it (Inbox `ReceiptDueUtc` null),
  it is never re-aired and never counted as unconfirmed. Far side **silent** = nothing acceptable arrived from it
  (any kind, Heartbeats included) for longer than `Gateway:FarSideSilentMinutes` (15; counted from start-up until
  something is heard): `/health` `farSide.silent`, `healthy = false`, and a `Light:` warning each maintenance run.
  Use the same two settings on both sides. Don't confuse these messages with the component heartbeats in the
  `Heartbeat` table of `qrbridge.db` (`HeartbeatRepository`, "this loop is alive").
- **Untrusted XML** only via `SafeXml` (in `QrBridge.Shared`, `Configurations/Helpers/Utility.cs`, shared with the UI). **Never log payloads.**
- **No gateway encryption** (decision 23): `MessageSerializer` packs header + SHA-256 checksum + Brotli body. QrDiode is
  the only encryption layer. Don't add keys back without asking Rowshan.
- **Start-up lives in `Initializer/`**: `Program.cs` stays a short list of calls; register new services in the
  `Initializer/*Registration.cs` of their area (or a new one), and put start-up checks in `StartupChecks.cs`.
- The gateway refuses to start on an invalid catalogue (including a RoundTrip route that could not give its
  `OnHoldTimeout` answer: `Pending` needs a profile `Pending` value; no `OneWay`; type modes only `Bridge` / RoundTrip /
  Unavailable; `Types` keys inside `AllowedTypes`), `LockTimeoutMinutes` not longer
  than every Receiver delivery timeout (+30 s), a `Gateway:Receiver:ConnectTimeoutSeconds` ≤ 0 or not shorter than
  every delivery timeout, a replay window, clock-skew limit or `RetryWindowMinutes` ≤ 0, `GapGraceMinutes` < 0, a
  `ReceiptTimeoutSeconds` or `MaxAirAttempts` ≤ 0, a route `MaxRequestBytes` / `MaxBacklog` ≤ 0 or `Priority` `Answer`,
  `Gateway:Light:BytesPerSecond` ≤ 0, `HeartbeatMinutes` < 0, `FarSideSilentMinutes` ≤ 0 or not longer than
  `HeartbeatMinutes`, a
  `Gateway:Hold` ≤ 0 or for a service with no callers on this side, a `Gateway:Expiry` ≤ 0, for an unknown or
  other-side service, or not longer than the service's hold (D62), or a
  Receiver URL that is not absolute https:// (plain http:// only in Development or with
  `Gateway:Receiver:AllowHttp` on a test bench). Keep those checks. A gateway process running **elevated** (as an
  administrator) gets a start-up **warning**, never a refusal (`StartupChecks.AdministratorWarning`, step 18, D4); the
  app pool identity, data-folder ACL and IIS limits are operations (guide §12.4).
- **Rows are never deleted automatically** (decision D28): `MaintenanceWorker` settles stuck rows (their Reply's outcome
  or Unknown, never re-posted), re-airs unconfirmed Outbox rows (below), checks for sequence
  gaps (`SequenceGapMonitor`, which also moves the watermarks up), sends idle Heartbeat messages, warns when the far
  side is silent, and writes component heartbeats — no purge. Don't add one back: an Inbox row is what stops a
  replayed `MessageId`, and the gap check needs every number. Operators archive rows manually. **Never archive
  `SequenceWatermark` or `AcknowledgedGap`** (both tiny): without the watermark an archived message shown again is no
  longer recognised by its number.
- **Re-airing** (step 11, decisions D9, D65–D68): `OutboxRepository.ReairUnconfirmedAsync`, once a minute. A row
  `Aired` at least `Gateway:ReceiptTimeoutSeconds` (120) ago with no Receipt → `Pending` (aired again; safe, the far
  Inbox skips a known `MessageId` and owes a new Receipt); after `Gateway:MaxAirAttempts` (3) airs in total (`Attempts`)
  or past its `ExpiresUtc` → `Failed` + `Light:` warning (never aired again). Each row is one conditional UPDATE, so a
  Receipt arriving at the same moment wins. **Receipt and Heartbeat rows are never re-aired** (they never get a
  Receipt) and don't count as unconfirmed. Re-airing never causes a second POST; never "fix" a lost Receipt by re-posting.
- **Lost messages** (decision D29): `InboxRepository.FindSequenceGapsAsync` finds missing numbers per run of the
  sender's counter (`SequenceRunId`, D27), after `Gateway:GapGraceMinutes`. `/health` reads the cached
  `SequenceGapMonitor.Current`; never run the gap query per probe. An operator stops a gap being reported with
  `AcknowledgeGapAsync` (table `AcknowledgedGap`, D30, kept for audit). Each run, `SequenceGapMonitor.CheckAsync` also
  calls `InboxRepository.AdvanceSequenceWatermarksAsync`: `SequenceWatermark.ContiguousTo` = every number up to it
  arrived and was checked (Verified or Rejected) or was acknowledged as a gap. It only ever goes up.
- **Priorities** (step 14, D73, D74): `RouteTable.SettingsOf` gives each Request a class — High = RoundTrip + `Pending`
  (state-changing), Normal = RoundTrip queries, Low = `Bridge` feeds; a route may set `"Priority"` (never `Answer`, which
  is Receipts, Replies and Heartbeats). The QR sender airs answers first, then by class; `InboxWorker` runs **one delivery loop per
  class** (`DeliveryClasses`), each one at a time and in order, so a stuck feed never holds back a permit. Keep strict
  order inside a service and class: don't let a Request overtake an earlier `Retrying` one.
- **Who called and with which identity** (step 15, D75, D76): `SenderEndpoint.CallerHostOf` fills `CallerHost` (first
  `X-Forwarded-For` address labelled `(via <connection>)`, only address characters accepted); `InboxWorker` logs it at
  delivery. A target may override `UseDefaultCredentials` (`Gateway:Receiver:Targets:{service}`), served by the named
  clients `receiver` / `receiver-default-credentials` / `receiver-anonymous` (`SoapForwarderHttpClient.ClientNameFor`).
  Never put a password in configuration.
- **Size limits** (step 16, D78, D79): per service `MaxRequestBytes` (413 before parsing; the smaller of it and
  `Bridge:MaxPayloadBytes` applies; set to 10 × the largest simulator template — check against real sizes) and
  `MaxBacklog` (the route's Busy answer). `Gateway:Light` only feeds the start-up air-time **warning**
  (`StartupChecks.AirTimeWarnings`); it never refuses a call.
- The WSDL check includes the SOAPAction (SOAP 1.1 header / SOAP 1.2 Content-Type `action`) when the caller sends one
  and the WSDL gives one; compare it unquoted and case-sensitive. Never relax it to accept another operation's action.
- **Naming:** for each message the **Sender** machine is where the caller is and the **Receiver** machine is where the
  real service is. The gateway's Sender part lives in `Ingress/`, its Receiver part in `Egress/`. Keep those two folder
  names (and their namespaces), but name everything else Sender/Receiver (`SenderEndpoint`, `SenderSide`,
  `Gateway:Receiver`, `ReceiverOptions`). Don't add new `Ingress`/`Egress` identifiers. **Inbound/Outbound** means the
  interface direction only (Inbound = Corp → DMZ, Outbound = DMZ → Corp; `Contracts/Inbound`, `Contracts/Outbound`).

## Data layer (`QrBridge.Shared/Data`)

- EF Core with short-lived contexts from `IDbContextFactory`; repositories are singletons. Enums stored as names, Guids as
  lower-case text, times UTC (`SqliteConventions`). CHECK constraints are generated from the enums.
- One file per entity (`Data/Entities/{Entity}.cs`) and one per configuration
  (`Data/Configurations/{Entity}Configuration.cs`) — and in general one class per file, exception classes in `Exceptions/`, a class's records in its file, all
  settings classes in `Configurations/Options/` (one file per section), all enums in `Configurations/Enums/Enums.cs`,
  cross-project static helpers in `Configurations/Helpers/Utility.cs` (see `.github/copilot-instructions.md`).
- Two status groups per row (decision D24): `LightStatus` (did it cross the light?) and `ServiceStatus` (what did the
  real service do?), with `LightComment` / `ServiceComment` / `ServiceHttpStatus` for operators. Outbox: light
  `Pending/Sending/Aired/Received/Failed`, service `Waiting/Answered/Unknown/Refused/Expired/NotAvailable/NotDelivered/Rejected`
  (the last two since step 10a, D51). Inbox: light
  `Received/Rejected`, service `Pending/Delivering/Done/Retrying/Unknown/Refused/Expired/NotDelivered`. Keep a light
  problem out of the service group and the other way round; `Rejected` Inbox rows are never delivered or requeued.
- Queue pattern: atomic claim (Outbox: `UPDATE … WHERE MessageId=@id AND LightStatus='Pending'`, **Receipts, Replies and
  Heartbeats first, then by `Priority` class, lowest `Sequence` within a class**; Inbox: `LightStatus='Received'`, `Kind='Request'`,
  one `Priority` class per delivery loop and `ServiceStatus` `Pending` or due `Retrying`; runs of the sender's counter in
  the order they started, then `Sequence`; **strict order** D74: never a Request while an earlier one of the same service
  and class is `Retrying`), `MessageId` is the primary key, idempotent Inbox
  insert (a duplicate re-owes a Receipt), per-direction sequence via `UPDATE … RETURNING` in the insert's transaction (the same statement sets the
  counter's `RunId` on first use; it never changes after that; Receipts, Replies and Heartbeats take numbers on their lane too). The Outbox service group changes
  only through `MarkAnsweredAsync` (the first answer; a later Reply replaces it only when the stored one is not
  `Answered` and the Reply is newer by its `CreatedUtc`, column `ReplyCreatedUtc`, D59). `MaxBacklog` counts `Kind = Request` rows only
  (a route's own `MaxBacklog` counts that service's Requests, in the same transaction). `Priority` is the one enum stored
  as its number (0–3), so the claims can order by it. A `Done` Inbox row's `MessageBytes` is cleared (D77; hash kept);
  rows waiting for an operator keep it.
- **Message format `BRG7`** (header version 7; v6 added `Priority`, v7 the kind `Heartbeat` with no new field;
  `BRG3`–`BRG6` are refused with "previous format … Delete old dev databases"): `Path` and `Content-Type` are required for a Request only; a Reply needs
  `CorrelationId` + `Outcome`; a Receipt needs `CorrelationId` and carries no outcome; a **Heartbeat** has an empty
  body, no `CorrelationId`, `ContentFingerprint`, `ExpiresUtc` or outcome, priority `Answer` and `RawSoap` (checked on
  write and read); `FarSideMonitor` names it `QrBridge`/`Heartbeat` (`MessageHeader.HeartbeatServiceName`/`HeartbeatOperation`, never a route); a Request is High/Normal/Low,
  never `Answer` (`OutboxWriter` sets `Answer` on Receipts, Replies and Heartbeats). Bump `MessageHeader.CurrentVersion`
  at most once per change and say "delete dev databases".
- Schema is `EnsureCreated` today; any entity/enum change needs an EF migration once migrations exist
  (`docs/gateway-to-qrdiode/integration-plan.md` §2.2). Delete dev databases after changing entities until then.
- **One database per machine, `qrbridge.db`** (`BridgeOptions.DatabasePath`, one `BridgeDbContext`, decision 47 of
  `docs/handoff.md`), holding Outbox, SequenceCounter, Inbox, Heartbeat, AcknowledgedGap and SequenceWatermark. Keep the
  ownership by table: the Outbox is written by the gateway and aired by the QR sender; the Inbox is written by the QR
  receiver and used by the gateway. Each repository method keeps its own short-lived context and commit: don't merge
  operations into one transaction just because the tables now share a file. `DatabaseInitializer` refuses to start
  while a former `send.db` or `received.db` is in the data folder — keep that guard.

## Changing behaviour

- New or changed interface → `routes.json` (+ its WSDL in `Contracts/{direction}/{Contract}/`, by the route's `SenderSide`) + a case in
  `sourcecode/gateway/tests/QrBridge.Tests/Gateway/SenderTests.cs`. See the `add-bridged-service` prompt.
- Reply codes 1596/1597/1598/1599 are reply-profile values in `routes.json`; changing them changes what callers see — ask first.
- Run `dotnet test All.slnx` after every change; for hosting changes also start the gateway exe and POST a sample.
