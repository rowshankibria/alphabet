---
description: 'QrDiode optical link: Core protocol library and the WPF Sender/Receiver apps'
applyTo: 'sourcecode/qrdiode/src/QrDiode.Core/**,sourcecode/qrdiode/src/QrDiode.Sender/**,sourcecode/qrdiode/src/QrDiode.Receiver/**,sourcecode/qrdiode/src/QrDiode.KeyCeremony/**,sourcecode/qrdiode/src/Shared/**'
---

# QrDiode (Core, Sender, Receiver, KeyCeremony)

Background: `sourcecode/qrdiode/docs/protocol-development-notes.md` (historical protocol design and as-built notes), `sourcecode/qrdiode/docs/user-guide.md` (operating the apps),
`sourcecode/qrdiode/docs/wpf-tutorial.md` (WPF for an Angular developer). The work to connect these apps to the shared message database (`qrbridge.db`) is
designed in `docs/gateway-to-qrdiode/integration-plan.md` §2.

## Structure rules

- **Keep the project structure** (folders, project names, the linked `sourcecode/qrdiode/src/Shared/PayloadView.cs`). Add features inside
  the existing projects; don't split or rename them. These projects belong to `sourcecode/qrdiode/QrDiode.slnx`; when the
  Sender/Receiver need `QrBridge.Shared`, reference `..\..\..\gateway\src\QrBridge.Shared\QrBridge.Shared.csproj` and
  add that project to `QrDiode.slnx` too (one copy of the code, never a duplicate).
- **`QrDiode.Core` stays independent of the SOAP Gateway and UI-free:** no EF, SQLite, SOAP or WPF references. It may reference only
  the BCL, `System.IO.Hashing` and `ProtectedData`. Gateway and shared data code (repositories, envelope, bundles) lives in `QrBridge.Shared`,
  which the Sender and Receiver may reference.
- Never weaken the receive verification order in `ReceiveEngine`: CRC → manifest signature → addressed-to-us →
  anti-replay → LT decode → ciphertext hash → AES-GCM → decompression cap → plaintext hash → content gate.

## WPF rules

- Never block the UI thread: database, file and camera work is `async`; never `.Result` / `.Wait()`.
- Only the UI thread touches UI objects: from background loops use `Dispatcher.Invoke`/`BeginInvoke` (an
  `ObservableCollection` changed off the UI thread throws).
- Long-running loops (sender pump, camera) are tasks with a `CancellationToken`, stopped on window close / app exit.
- Follow the existing code-behind style of each window; don't introduce an MVVM framework without asking.

## Known issues to keep in mind

- `ReceiveEngine.FeedManifest` ignores all manifests while locked on a partial session (fix: Integration-Plan §2.1).
- `TransmitEngine.TrimQueue` drops queued items beyond 14 — never do that for Outbox items.
- `ReceiveEngine` commits anti-replay before the host stores the payload — move the commit after the store.
- Receiver pins `Microsoft.Data.Sqlite` 10.0.10 / `SQLitePCLRaw.bundle_e_sqlite3` 3.0.5; align with EF Core 10.0.15
  (SQLitePCLRaw 2.1.13) when the Receiver references `QrBridge.Shared`.
- Keys and state are per Windows user (`%LocalAppData%\QrDiode`, CNG user store): run the apps as the kiosk user.
- Native `ZXing.dll` fails to load from very deep folders (MAX_PATH): keep the solution at a short path.

## Tests

`sourcecode/qrdiode/tests/QrDiode.Core.Tests` (75 tests) must stay green; add tests for every protocol change (see
`OpticalLoopbackTests` for a camera-free end-to-end through real QR images).
