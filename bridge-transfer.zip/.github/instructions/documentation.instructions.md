---
description: 'Keeping the Gateway-to-QrDiode system documentation accurate, self-contained and in plain English'
applyTo: 'docs/**/*.md,sourcecode/gateway/docs/**/*.md,sourcecode/qrdiode/docs/**/*.md,*.md,.github/**/*.md'
---

# Documentation conventions

- **Self-contained:** this repository is moved between machines. Use relative links to files within the repository.
  Gateway-specific documents live in `sourcecode/gateway/docs/`; QrDiode-specific documents live in
  `sourcecode/qrdiode/docs/`. The single current system architecture, handoff, operations reference and
  integration plan stay in `docs/`. The fms-interface-simulator is a separate project, not a required local copy.
- **Plain, direct English** for Rowshan: short sentences, concrete examples, tables for comparisons. Explain WPF with
  Angular analogies.
- **Naming:** use **Gateway-to-QrDiode** for the overall system, **SOAP Gateway** for the IIS component and
  **QrDiode optical link** for the screen/camera transfer. Keep technical identifiers, configuration values,
  filenames and quoted responses unchanged; `Bridge` is still an actual route-mode value, not the system name.
- **Documentation filenames:** use lowercase names with hyphens instead of spaces or underscores in the shared
  and project documentation folders. Keep special repository instruction filenames outside those folders unchanged.
- **Keep the living documents current** after every change:
  - `docs/gateway-to-qrdiode/architecture.md` — the single system architecture, with built/planned status;
  - `docs/handoff.md` — state, verification results, known issues, next steps, open questions;
  - `.github/copilot-instructions.md` — known-issues list and next steps (keep its first ~4,000 characters for the
    most important rules: Copilot code review reads only that much);
  - `docs/gateway-to-qrdiode/technical-guide.md` — when behaviour, configuration or the catalogue changes;
  - `docs/gateway-to-qrdiode/integration-plan.md` — mark steps done, adjust the design to what was built;
  - `sourcecode/gateway/docs/gateway.md` — one-page reference.
- Say what is **built and verified**, what is **planned**, and what was **not tried** — never present a plan as done.
- After editing docs, check that every relative link you touched resolves.
